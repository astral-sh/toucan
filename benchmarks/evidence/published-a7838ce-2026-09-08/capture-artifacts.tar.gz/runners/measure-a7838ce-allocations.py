from pathlib import Path
import hashlib,json,os,random,shutil,statistics,subprocess
root=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark');out=root/'allocations';out.mkdir();preflight=json.loads((root/'preflight/evidence.json').read_text());timings=json.loads((root/'timings/evidence.json').read_text());assert preflight['status']==timings['status']=='passed';available=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,set(timings['affinity']));env={**os.environ,**preflight['environment']};env.pop('LD_PRELOAD',None);binaries={}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for label in ['baseline','candidate']:
 binary=root/(label+'-allocation-target/release/toucan-inprocess-benchmark');target=root/(label+'-allocations');shutil.copy2(binary,target);binaries[label]=target
report=dict(status='running',baseline_commit='a3256d6',candidate_commit='a7838ce9d741c8659e428c8a3b2e7f33897bf6fa',allocator='Counter delegates every GlobalAlloc operation unchanged to System; production source is unmodified',method='Three randomized process pairs per project, each with one discarded warmup and five repeated generations. Setup, parse_file, and binding generation have separate counter resets. Counts are alloc/alloc_zeroed/realloc requests and the sum of requested sizes, including full realloc sizes. They are allocation traffic, not live/peak heap; native libclang C++ allocations are not measured. Instrumented samples are excluded from timing evidence.',affinity=timings['affinity'],random_seed=202609082324,phase_order=['setup','parse','bindings'],binaries={label:dict(path=str(path),sha256=sha(path),harness_sha256=sha(root/(label+'-allocation-source/src/main.rs')),cargo_lock_sha256=sha(root/(label+'-allocation-source/Cargo.lock')))for label,path in binaries.items()},identity=[],rows=[])
def save():(out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for label,binary in binaries.items():
  output=out/(label+'-identity.rs');command=[str(binary),str(root/'preflight/identity.request.json'),'3',str(output)];run=subprocess.run(command,capture_output=True,text=True,env=env,check=True,timeout=120);assert sha(output)==sha(root/'preflight'/(label+'-identity.rs'));report['identity'].append(dict(variant=label,command=command,stdout=run.stdout,stderr=run.stderr,output_sha256=sha(output)))
 rng=random.Random(202609082324)
 for round_index in range(3):
  projects=['zlib','sqlite','zstd','libgit2'];rng.shuffle(projects)
  for project_index,project in enumerate(projects):
   labels=['baseline','candidate'];rng.shuffle(labels);reference=timings['requests'][project];request=Path(reference['path']);assert sha(request)==reference['sha256']
   for label_index,label in enumerate(labels):
    output=out/f'{project}-{label}-{round_index}.rs';command=[str(binaries[label]),str(request),'5',str(output)];run=subprocess.run(command,capture_output=True,text=True,env=env,check=True,timeout=120);row=json.loads(run.stdout);assert len(row['samples'])==5;assert sha(output)==sha(root/'preflight'/f'{project}-{label}.rs');row.update(project=project,variant=label,round=round_index,project_order=project_index,variant_order=label_index,command=command,stderr=run.stderr,output_sha256=sha(output));report['rows'].append(row)
   print(round_index,project,flush=True);save()
 summary={}
 for project in ['zlib','sqlite','zstd','libgit2']:
  result={}
  for phase_index,phase in enumerate(report['phase_order']):
   counts={}
   for label in binaries:
    samples=[sample[phase_index]for row in report['rows']if row['project']==project and row['variant']==label for sample in row['samples']];counts[label]={key:dict(median=statistics.median(s[key]for s in samples),minimum=min(s[key]for s in samples),maximum=max(s[key]for s in samples))for key in ['requests','requested_bytes','reallocations']}
   result[phase]=dict(variants=counts,delta={key:counts['candidate'][key]['median']-counts['baseline'][key]['median']for key in counts['baseline']},candidate_over_baseline={key:counts['candidate'][key]['median']/counts['baseline'][key]['median']if counts['baseline'][key]['median']else None for key in counts['baseline']})
  summary[project]=result
 assert all(sha(item['path'])==item['sha256']for item in report['binaries'].values());assert timings['dependency_sha256']=={path:sha(path)for path in timings['dependency_sha256']};report.update(status='passed',summary=summary);print(json.dumps(summary,indent=2))
except BaseException as error:report.update(status='failed',failure=repr(error));raise
finally:save()
