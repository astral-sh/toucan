from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark');out=root/'header-inventory-final';out.mkdir();env={**os.environ,'LIBCLANG_PATH':'/usr/lib/llvm-18/lib','CLANG_PATH':'/usr/bin/clang-18'};binaries={}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for label in ['baseline','candidate']:
 source=root/(label+'-allocation-target/release/header-inputs');target=root/(label+'-header-inputs');shutil.copy2(source,target);binaries[label]=target
report=dict(status='running',method='Untimed Toucan Preprocessed.dependencies and bindgen ParseCallbacks.include_file inventory; root header added explicitly. Callback inventory must preserve each engine output exactly before measuring with the unmodified in-process harness.',binaries={label:dict(path=str(path),sha256=sha(path))for label,path in binaries.items()},harness_sha256=sha(root/'candidate-allocation-source/src/bin/header-inputs.rs'),rows=[],dependency_sha256={})
def save():(out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for project in ['zlib','sqlite','zstd','libgit2']:
  request=root/'preflight'/(project+'.request.json')
  for label,engine in [('baseline','toucan'),('candidate','toucan'),('bindgen','bindgen')]:
   binary=binaries['baseline'if label=='baseline'else'candidate'];output=out/f'{project}-{label}.rs';command=[str(binary),engine,str(request),str(output)];run=subprocess.run(command,capture_output=True,text=True,env=env,check=True,timeout=120);value=json.loads(run.stdout);assert sha(output)==sha(root/'preflight'/f'{project}-{label}.rs');files={}
   for name in value['files']:
    path=Path(name).resolve(strict=True);files[str(path)]=sha(path)
   report['dependency_sha256'].update(files);value.update(project=project,variant=label,command=command,stderr=run.stderr,dependency_sha256=files,output_sha256=sha(output));cpp=Path(str(output)+'.i')
   if cpp.exists():value['preprocessed_sha256']=sha(cpp)
   report['rows'].append(value);print(project,label,len(files),value.get('metadata'),flush=True)
 report['libclang']=dict(path='/usr/lib/llvm-18/lib/libclang.so.1',resolved_path=str(Path('/usr/lib/llvm-18/lib/libclang.so.1').resolve()),sha256=sha('/usr/lib/llvm-18/lib/libclang.so.1'));report['status']='passed'
except BaseException as error:report.update(status='failed',failure=repr(error));raise
finally:save()
