#define REVISION_GNU_MAJOR __GNUC__
#if __has_builtin(__builtin_prefetch)
typedef int revision_prefetch;
#else
typedef char revision_prefetch;
#endif
