typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int x ; int x = 3 ; int x ; int main ( ) ; void * foo ( ) { return & main ; } int main ( ) { if ( x != 3 ) return 0 ; x = 0 ; return x ; }
