typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int foo ( int a , int b ) { return 2 + a - b ; } int main ( ) { return foo ( 1 , 3 ) ; }
