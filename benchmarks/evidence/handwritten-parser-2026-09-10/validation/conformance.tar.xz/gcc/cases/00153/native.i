typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
typedef struct { int f ; } S ; int main ( ) { S s ; s . f = 0 ; return s . f ; }
