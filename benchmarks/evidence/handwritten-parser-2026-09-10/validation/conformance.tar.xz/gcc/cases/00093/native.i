typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int a [ ] = { 1 , 2 , 3 , 4 } ; int main ( ) { if ( sizeof ( a ) != 4 * sizeof ( int ) ) return 1 ; return 0 ; }
