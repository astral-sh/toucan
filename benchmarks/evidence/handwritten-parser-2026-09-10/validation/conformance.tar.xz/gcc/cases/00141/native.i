typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( void ) { int foo , bar , foobar ; foobar = foo + bar ; foobar = foo + bar ; return 0 ; }
