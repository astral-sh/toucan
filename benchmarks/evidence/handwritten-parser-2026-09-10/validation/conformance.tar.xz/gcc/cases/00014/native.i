typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x ; int * p ; x = 1 ; p = & x ; p [ 0 ] = 0 ; return x ; }
