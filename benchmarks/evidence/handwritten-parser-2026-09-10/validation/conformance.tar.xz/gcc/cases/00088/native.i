typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int ( * fptr ) ( ) = 0 ; int main ( ) { if ( fptr ) return 1 ; return 0 ; }
