typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x , * p , * * pp ; x = 0 ; p = & x ; pp = & p ; return * * pp ; }
