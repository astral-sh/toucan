typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { struct T { int x ; } ; { struct T s ; s . x = 0 ; return s . x ; } }
