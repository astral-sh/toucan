typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { if ( 1 + 2 + 3 != 6 ) return 1 ; return 0 + 0 + 0 ; }
