typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { start : goto next ; return 1 ; success : return 0 ; next : foo : goto success ; return 1 ; }
