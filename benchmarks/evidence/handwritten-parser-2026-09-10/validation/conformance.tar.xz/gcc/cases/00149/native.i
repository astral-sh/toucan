typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
struct S { int a ; int b ; } ; struct S * s = & ( struct S ) { 1 , 2 } ; int main ( ) { if ( s -> a != 1 ) return 1 ; if ( s -> b != 2 ) return 2 ; return 0 ; }
