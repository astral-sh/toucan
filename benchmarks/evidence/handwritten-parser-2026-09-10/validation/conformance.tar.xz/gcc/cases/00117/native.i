typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x [ ] = { 1 , 0 } ; return x [ 1 ] ; }
