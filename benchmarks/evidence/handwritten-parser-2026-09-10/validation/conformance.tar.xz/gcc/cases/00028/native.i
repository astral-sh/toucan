typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x ; x = 1 ; x = x & 3 ; return x - 1 ; }
