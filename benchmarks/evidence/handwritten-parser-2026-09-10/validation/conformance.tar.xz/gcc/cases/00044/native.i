typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
struct T ; struct T { int x ; } ; int main ( ) { struct T v ; { struct T { int z ; } ; } v . x = 2 ; if ( v . x != 2 ) return 1 ; return 0 ; }
