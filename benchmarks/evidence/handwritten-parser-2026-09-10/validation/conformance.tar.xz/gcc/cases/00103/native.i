typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x ; void * foo ; void * * bar ; x = 0 ; foo = ( void * ) & x ; bar = & foo ; return * * ( int * * ) bar ; }
