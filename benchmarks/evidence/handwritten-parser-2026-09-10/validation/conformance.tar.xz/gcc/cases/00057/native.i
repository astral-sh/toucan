typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { char a [ 16 ] , b [ 16 ] ; if ( sizeof ( a ) != sizeof ( b ) ) return 1 ; return 0 ; }
