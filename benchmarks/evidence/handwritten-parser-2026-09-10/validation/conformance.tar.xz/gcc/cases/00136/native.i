typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int a ; int b ;
int c ; int d ;
int e ; int f ;
int e_ ; int f_ ;
int e_ ; int f_ ; int main ( ) { return 0 ; }
