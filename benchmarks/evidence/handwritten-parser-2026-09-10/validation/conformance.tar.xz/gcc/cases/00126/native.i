typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x ; x = 3 ; x = ! x ; x = ! x ; x = ~ x ; x = - x ; if ( x != 2 ) return 1 ; return 0 ; }
