typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
typedef int myint ; myint x = ( myint ) 1 ; int main ( void ) { return x - 1 ; }
