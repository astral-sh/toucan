typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
typedef struct { int n ; } Vec ; static void vecresize ( Vec * v , int cap ) { return ; } int main ( ) { return 0 ; }
