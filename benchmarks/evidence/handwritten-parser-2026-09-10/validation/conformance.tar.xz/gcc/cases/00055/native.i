typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
enum E { x , y = 2 , z , } ; int main ( ) { enum E e ; if ( x != 0 ) return 1 ; if ( y != 2 ) return 2 ; if ( z != 3 ) return 3 ; e = x ; return e ; }
