typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int f ( int f ) { return f ; } int main ( ) { return f ( 0 ) ; }
