typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int foo ( void ) { return 0 ; } int main ( ) { return foo ( ) ; }
