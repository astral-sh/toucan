typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
void voidfn ( ) { return ; } int main ( ) { voidfn ( ) ; return 0 ; }
