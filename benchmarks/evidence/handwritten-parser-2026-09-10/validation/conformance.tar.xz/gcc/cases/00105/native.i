typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int i ; for ( i = 0 ; i < 10 ; i ++ ) if ( ! i ) continue ; return 0 ; }
