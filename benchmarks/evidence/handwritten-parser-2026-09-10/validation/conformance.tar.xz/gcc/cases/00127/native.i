typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int c ; int main ( ) { if ( 0 ) { return 1 ; } else if ( 0 ) { } else { if ( 1 ) { if ( c ) return 1 ; else return 0 ; } else { return 1 ; } } return 1 ; }
