typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( void ) { char * p ; p = "hello" " is better than bye" ; return ( * p == 'h' ) ? 0 : 1 ; }
