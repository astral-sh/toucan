typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int f ( int a ) , g ( int a ) , a ; int main ( ) { return f ( 1 ) - g ( 1 ) ; } int f ( int a ) { return a ; } int g ( int a ) { return a ; }
