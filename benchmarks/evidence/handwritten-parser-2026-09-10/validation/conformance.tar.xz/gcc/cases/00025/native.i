typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int strlen ( char * ) ; int main ( ) { char * p ; p = "hello" ; return strlen ( p ) - 5 ; }
