typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
typedef struct s s ; struct s { struct s1 { int s ; struct s2 { int s ; } s1 ; } s ; } s2 ;
int main ( void ) {
goto s ; struct s s ; { int s ; return s ; } return s . s . s + s . s . s1 . s ; s : { return 0 ; } return 1 ; }
