typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int arr [ 2 ] ; int * p ; p = & arr [ 1 ] ; p -= 1 ; * p = 123 ; if ( arr [ 0 ] != 123 ) return 1 ; return 0 ; }
