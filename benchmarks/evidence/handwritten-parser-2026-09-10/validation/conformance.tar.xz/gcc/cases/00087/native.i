typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
struct S { int ( * fptr ) ( ) ; } ; int foo ( ) { return 0 ; } int main ( ) { struct S v ; v . fptr = foo ; return v . fptr ( ) ; }
