typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { if ( 0 ) return 1 ; if ( 0 ) return 1 ; if ( 0 ) return 1 ; if ( 0 ) return 1 ; if ( 0 ) return 1 ; if ( 0 ) return 1 ; if ( 0 ) return 1 ; return 0 ; }
