typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int x ; int y ; y = 0 ; x = ( ( y ) + 1 ) ; if ( x != 1 ) return 1 ; return 0 ; }
