typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { void * p ; int x ; x = 2 ; p = & x ; if ( * ( ( int * ) p ) != 2 ) return 1 ; return 0 ; }
