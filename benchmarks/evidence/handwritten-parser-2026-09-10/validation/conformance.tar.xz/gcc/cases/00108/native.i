typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int foo ( void ) ; int foo ( void ) ;
int main ( ) { return 0 ; }
