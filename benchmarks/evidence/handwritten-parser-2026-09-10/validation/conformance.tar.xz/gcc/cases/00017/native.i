typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { struct { int x ; int y ; } s ; s . x = 3 ; s . y = 5 ; return s . y - s . x - 2 ; }
