typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { int arr [ 2 ] ; arr [ 0 ] = 1 ; arr [ 1 ] = 2 ; return arr [ 0 ] + arr [ 1 ] - 3 ; }
