typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int f ( ) { return 100 ; } int main ( ) { if ( f ( ) > 1000 ) return 1 ; if ( f ( ) >= 1000 ) return 1 ; if ( 1000 < f ( ) ) return 1 ; if ( 1000 <= f ( ) ) return 1 ; if ( 1000 == f ( ) ) return 1 ; if ( 100 != f ( ) ) return 1 ; return 0 ; }
