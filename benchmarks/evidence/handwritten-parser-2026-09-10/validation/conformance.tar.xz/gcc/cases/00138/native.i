typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( void ) { char * a = "hi" ; return ( a [ 1 ] == 'i' ) ? 0 : 1 ; }
