typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
int main ( ) { struct S { struct S * p ; int x ; } s ; s . x = 0 ; s . p = & s ; return s . p -> p -> p -> p -> p -> x ; }
