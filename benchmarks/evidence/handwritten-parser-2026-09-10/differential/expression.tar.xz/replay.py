#!/usr/bin/env python3
"""Regenerate the expression corpus and replay parser or native compiler checks."""

import argparse
import hashlib
import itertools
import json
import subprocess
from pathlib import Path

BINARY = "* / % + - << >> < <= > >= == != & ^ | && ||".split()
ASSIGNMENT = "= *= /= %= += -= <<= >>= &= ^= |=".split()
PREFIX = (
    "struct S{int v;int arr[4];};int call(int,int);"
    "int f(int a,int b,int c,int*p,struct S s,struct S*sp,__builtin_va_list ap){return "
)

EXTRA = ['a ? b : c ? a : b',
 'a ? b,c : c',
 'a = b = c',
 '(a+b)=c',
 '(int)a+b*c',
 '(long)(int)(a+b)',
 'sizeof(a+b)',
 '_Alignof(int)',
 '__alignof__(a)',
 '__builtin_choose_expr(1,a,b)',
 '__builtin_types_compatible_p(int,long)',
 '_Generic(a,int:b,default:c)',
 '__extension__ (a ?: b)',
 '__builtin_offsetof(struct S,arr[a+1])',
 '__builtin_va_arg(ap,int)',
 'p[a+b]++',
 's.v++ + ++sp->v',
 '(struct S){.v=a,.arr={b,c}}.arr[0]',
 'call(a,b+1)',
 'a+++b',
 'a---b',
 'a+++--b',
 '(a,b,c)',
 '~!-a',
 '*p++',
 '(*p)++',
 '__real__ a',
 '__imag__ a']
INVALID = ['a+b=c',
 '(int)a=c',
 'a ? : b',
 'call(a,)',
 'p[]',
 '_Generic(a,int:b,)',
 '__builtin_choose_expr(1,a,)',
 '0x',
 '08',
 '1uu',
 '1lL',
 '0x1.2',
 '1e+',
 '1.0ffi',
 "'\\q'",
 '"\\x"',
 "u8'a'",
 'a+++++b']


def generate():
    expressions = [f"a {left} b {right} c" for left, right in itertools.product(BINARY, repeat=2)]
    expressions += [f"a {left} b {right} c" for left, right in itertools.product(ASSIGNMENT, BINARY)]
    expressions += EXTRA
    cases = [
        {
            "name": f"valid-{index:04d}",
            "source": PREFIX + expression + ";}",
            "expression": expression,
            "native_expected": expression != "(a+b)=c",
            "flavor": "gnu",
        }
        for index, expression in enumerate(expressions)
    ]
    cases += [
        {
            "name": f"invalid-{index:04d}",
            "source": PREFIX + expression + ";}",
            "expression": expression,
            "flavor": "std" if expression == "a ? : b" else "gnu",
            "native_expected": False,
        }
        for index, expression in enumerate(INVALID)
    ]
    requests = [
        {
            "id": mode_index * len(cases) + index,
            "source": case["source"],
            "mode": "std" if case["flavor"] == "std" else mode,
        }
        for mode_index, mode in enumerate(("gnu", "clang"))
        for index, case in enumerate(cases)
    ]
    return cases, requests


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare(output, requests, binaries):
    request_bytes = "".join(json.dumps(case) + "\n" for case in requests).encode()
    results = {}
    for name, binary in binaries.items():
        result = subprocess.run([str(binary)], input=request_bytes, capture_output=True, check=True)
        (output / f"{name}.jsonl").write_bytes(result.stdout)
        (output / f"{name}.stderr").write_bytes(result.stderr)
        values = [json.loads(line) for line in result.stdout.splitlines()]
        assert [value["id"] for value in values] == [case["id"] for case in requests]
        results[name] = values
    differences = []
    for before, after in zip(results["baseline"], results["candidate"]):
        if (before["accepted"], before["tree"]) != (after["accepted"], after["tree"]):
            differences.append({"id": before["id"], "baseline": before, "candidate": after})
    report = {
        "requests": len(requests),
        "outputs": {name: len(values) for name, values in results.items()},
        "binaries": {name: {"path": str(binary), "sha256": digest(binary)} for name, binary in binaries.items()},
        "differences": differences,
    }
    write_json(output / "comparison.json", report)
    return not differences


def native(output, cases):
    compilers = ("gcc", "clang")
    versions = {
        compiler: subprocess.check_output([compiler, "--version"], text=True).splitlines()[0]
        for compiler in compilers
    }
    results, strict = [], []
    for case in cases:
        checks = {}
        for compiler in compilers:
            command = [compiler, "-std=c11" if case["flavor"] == "std" else "-std=gnu11", "-fsyntax-only", "-x", "c", "-"]
            result = subprocess.run(command, input=case["source"], text=True, capture_output=True)
            checks[compiler] = {"accepted": result.returncode == 0, "stderr": result.stderr}
            if case["expression"] in ("a ? : b", "'\\q'"):
                strict_command = [compiler, "-std=c11", "-pedantic-errors", "-fsyntax-only", "-x", "c", "-"]
                checked = subprocess.run(strict_command, input=case["source"] + "\n", text=True, capture_output=True)
                strict.append({"expression": case["expression"], "compiler": compiler, "accepted": checked.returncode == 0, "stderr": checked.stderr})
        results.append({"name": case["name"], "expression": case["expression"], "expected": case["native_expected"], "results": checks})
    write_json(output / "native.json", {"versions": versions, "results": results})
    write_json(output / "native-strict.json", strict)
    strict_by_case = {(value["expression"], value["compiler"]): value["accepted"] for value in strict}
    return all(
        check["accepted"] == case["native_expected"]
        or (not case["native_expected"] and strict_by_case.get((case["expression"], compiler)) is False)
        for case, result in zip(cases, results)
        for compiler, check in result["results"].items()
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--native", action="store_true")
    args = parser.parse_args()
    if bool(args.baseline) != bool(args.candidate):
        parser.error("--baseline and --candidate must be supplied together")
    args.output.mkdir(parents=True, exist_ok=False)
    cases, requests = generate()
    write_json(args.output / "cases.json", cases)
    (args.output / "requests.jsonl").write_text("".join(json.dumps(case) + "\n" for case in requests))
    passed = True
    if args.baseline:
        passed &= compare(args.output, requests, {"baseline": args.baseline.resolve(), "candidate": args.candidate.resolve()})
    if args.native:
        passed &= native(args.output, cases)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
