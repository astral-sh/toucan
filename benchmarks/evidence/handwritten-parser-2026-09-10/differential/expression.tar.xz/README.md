# Expression parser differential evidence

568 C sources were compared against the generated parser at `f1e8dc89acc74675cf81475fdc3402a76a3d09e9`, with 1,136 parser calls and zero acceptance or AST Printer differences. The corpus is replayed under GNU and Clang flavors, except the ISO-only omitted-conditional case, which uses the standard flavor in each pass.

The corpus covers 324 pairs of the 18 binary operators, 198 assignment/binary operator pairs, 28 casts, parentheses, postfix operations and builtin expressions, and 18 malformed expressions. AST Printer preserves node structure, names, operators and literal/type data; it omits source spans. This does not establish exact span equality. Rejected-input diagnostics are preserved but are not compared as an equality claim.

All 549 intended-valid sources pass GCC 13.3 and Clang 18.1 syntax and constraint checks. Both compilers reject the 19 intentionally invalid sources after promoting the two extension/escape diagnostics with `-pedantic-errors`. The ordinary syntax checks accept an unknown escape and GNU's omitted conditional operand as extensions. Two sources, `(a+b)=c` and `a+++++b`, preserve their ASTs in both parsers but fail native compiler constraints. Native checks do not execute programs or prove runtime behavior.

## Reproduce

`replay.py` regenerates every source from operator products and explicit edge cases. This reproduction script was written after the initial experiment and verified to reproduce both input files byte-for-byte. Its actual parser and native reruns also reproduced all recorded output files byte-for-byte.

Use `python3 replay.py --output /tmp/expression-inputs` to regenerate just the corpus. To rerun checks:

```console
python3 replay.py --output /tmp/expression-replay --baseline /path/to/baseline-driver --candidate /path/to/candidate-driver --native
```

The output directory must not exist. The script returns nonzero if parser AST/acceptance differs or native outcomes disagree with the recorded intent. It does not normalize AST data.

`driver.rs` is the complete batch parser driver. To build each executable, copy `Cargo.toml.example` to `Cargo.toml` in a separate directory, point its `toucan_parser` dependency at the baseline or candidate source, and copy `driver.rs` and `Cargo.lock` beside it. Run `cargo +ohm build --manifest-path /path/to/Cargo.toml` with distinct target directories and the shared Ohm build directory. The same driver and source snapshots are also preserved in the sibling declaration evidence archive. `source-freeze.json` records the parser source inventory; `comparison.json` records the exact executables used and SHA-256 hashes.

`cases.json` contains the complete sources and native expectations. `requests.jsonl` contains the exact batch requests; `baseline.jsonl` and `candidate.jsonl` retain every complete parser response. `native.json` and `native-strict.json` retain compiler versions and diagnostics. `summary.json` records counts, scope, the current expression source hash, and reproduction validation. `manifest.json` hashes every other file in this archive.
