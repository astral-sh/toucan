from pathlib import Path
import hashlib,json,shutil,subprocess,os,tarfile
root=Path(__file__).parent
src=Path('/home/dev-user/.codex/worktrees/c877/toucan')
base=Path('/home/dev-user/code/oss/toucan-handwritten-baseline')
original_files=['cases.jsonl','baseline.jsonl','candidate.jsonl','mismatches.json','summary.json','native-results.json']
prior_count=len((root/'cases.jsonl').read_text().splitlines())
with tarfile.open(root/f'initial-{prior_count}.tar.xz','w:xz') as tar:
 for name in original_files:tar.add(root/name,arcname=name)
def inventory():
 paths=sorted((src/'crates/toucan_parser/src').rglob('*.rs'))+[src/'crates/toucan_parser/Cargo.toml',src/'Cargo.toml',src/'Cargo.lock']
 return {str(p.relative_to(src)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=inventory()
env=dict(os.environ,CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_TARGET_DIR='/home/dev-user/.cache/toucan/declaration-fuzz-candidate-target',CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/toucan/ohm-shared-build',CARGO_PROFILE_DEV_DEBUG='0')
with (root/'final-build.log').open('w') as log:
 subprocess.run(['cargo','+ohm','build','--manifest-path',str(root/'candidate/Cargo.toml'),'--offline','--locked'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
after=inventory()
assert before==after,'source changed during batch runner build'
for side,checkout in [('baseline',base),('candidate',src)]:
 destination=root/(side+'-source')
 destination.mkdir(exist_ok=True)
 for p in sorted((checkout/'crates/toucan_parser/src').rglob('*.rs'))+[checkout/'crates/toucan_parser/Cargo.toml',checkout/'crates/toucan_parser/LICENSE-MIT',checkout/'crates/toucan_parser/LICENSE-APACHE',checkout/'Cargo.toml',checkout/'Cargo.lock']:
  target=destination/p.relative_to(checkout);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
(root/'candidate-source-inventory.json').write_text(json.dumps(after,indent=2))
(root/'source-freeze.json').write_text(json.dumps({'base_git':subprocess.check_output(['git','-C',str(base),'rev-parse','HEAD'],text=True).strip(),'candidate_base_git':subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip(),'candidate_inventory':after,'build_unchanged':before==after,'rustc':subprocess.check_output(['rustc','+ohm','-Vv'],text=True),'command':['cargo','+ohm','build','--manifest-path',str(root/'candidate/Cargo.toml'),'--offline','--locked'],'env':{k:env[k] for k in ('CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_BUILD_DIR','CARGO_PROFILE_DEV_DEBUG')}},indent=2))
print('source freeze passed',len(after),'files')
