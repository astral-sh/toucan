# Declaration parser differential

The handwritten parser and the parser at `f1e8dc89acc74675cf81475fdc3402a76a3d09e9` agree on acceptance and AST-printer output for all 6,688 generated cases: 5,354 accepted and 1,334 rejected. The final run has no mismatches. `resolved-differences.json` records two earlier minimized context differences fixed before this capture.

The deterministic matrix covers arithmetic and named types; 21 declarator shapes; typedef shadowing; pointer/array qualifier placement; parameter scopes and trailing attributes; C90 implicit declarations; designated/range/aggregate initialization; punctuation deletion; and GNU `__extension__` declaration versus expression dispatch; and parameter/storage/inferred-type specifier combinations; disabled GNU/MSVC aliases; Clang floating typedef names; and GNU/Clang C99/C17 modes with bare keywords disabled. Each source is tried with relevant combinations of core C11, core C90, GNU, Clang, GNU with Clang syntax, Microsoft-enabled Clang grammar, and ISO C99/C17 keyword profiles.

A batch driver parses each source through the public library entry point. `baseline.jsonl` and `candidate.jsonl` retain exact AST-printer strings or complete failure records. Comparison checks acceptance and complete printed AST structure, not matching diagnostic text/offsets or byte spans. Node-span preservation and integrated semantic behavior need the separate existing tests and full-source corpus. This is a finite generated test matrix, not a sustained random fuzz campaign.

## Direct tag-attribute correction

An additional 30-case matrix in `tag-attributes.json` checks GNU attributes directly after `struct`, `union`, and `enum`, including repeated lists, whitespace, and expression arguments. All 30 now produce tagged declarations. The old direct parser misclassified 16 struct/union cases as function definitions and rejected the other 14 cases (the enum cases and whitespace between attribute parentheses). The former semantic source normalizer hid this parser defect by rewriting attributes before parsing. Both GCC and Clang accept all 30 cases (60 native checks). These intentional parser corrections are separate from the 6,688 unchanged-output cases above. `tag_attributes.py` reproduces them.

## Native reference sample

GCC 13.3.0 and Clang 18.1.3 ran syntax/semantic checking on 360 selected case/configuration pairs, for 720 processes. All results and diagnostic text are retained.

- 319 reference runs accepted source also accepted by both parser revisions.
- 58 accepted source rejected by both parser revisions. `native-differences.json` classifies these retained differences, including disabled extension profiles, GCC implicit-int acceptance, array-bracket attributes, and omitted struct-member semicolons.
- 137 rejected source whose syntax both parser revisions accepted. Parser acceptance does not claim semantic validity.
- 206 rejected source also rejected by both parser revisions.
- No process crash, timeout, or compiler infrastructure failure was observed.

These categories are not summed into a complete-conformance pass rate. Comparing a core parser flavor with a compiler that still accepts underscore extensions under pedantic flags does not establish a regression.

## Reproduction and provenance

`driver.rs`, the two driver manifests and identical lockfiles, `generate.py`, `native.py`, `freeze.py`, and `package.py` preserve the commands and inputs. Baseline and candidate parser source snapshots are included. `source-freeze.json` checks 23 candidate source/configuration files before and after building the final batch executable. `summary.json` contains executable hashes; compiled binaries are excluded from this archive. Debug-build durations printed by the generator are not performance measurements.

The paths in driver manifests and scripts identify this capture's workspace. To reproduce elsewhere, point each driver dependency at the corresponding parser source snapshot in an existing compatible Toucan workspace, build using the recorded toolchain/lockfile, and update the two binary paths in the generator. `cases.jsonl` is sufficient to replay the exact input set without regenerating it.

The earlier 6,249-case capture is retained in `initial-6249.tar.xz`; the 6,333-case intermediate capture is retained in `initial-6333.tar.xz`. The final expanded run includes the regression derived from GCC's unmodified `stdatomic.h`, context-specific specifier cases, and disabled extension keyword cases. The prior 6,432-case snapshot is retained in `initial-6432.tar.xz`. Native declaration-suite logs and isolated scope probes are included separately.
