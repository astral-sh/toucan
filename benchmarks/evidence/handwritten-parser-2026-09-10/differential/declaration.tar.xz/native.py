from pathlib import Path
import json,subprocess,concurrent.futures,collections,hashlib
root=Path(__file__).parent
cases=[json.loads(l) for l in (root/'cases.jsonl').read_text().splitlines()]
after={r['id']:r for r in map(json.loads,(root/'candidate.jsonl').read_text().splitlines())}
groups=collections.defaultdict(list)
for c in cases:
 if c['mode'] in ('std','gnu','clang','c90','gnu_iso99','clang_iso99','gnu_iso17','clang_iso17'):
  groups[c['category'],c['mode']].append(c)
selected=[]
for key,group in sorted(groups.items()):
 count=min(8,len(group))
 selected.extend(group[(i*(len(group)-1))//max(1,count-1)] for i in range(count))
def check(task):
 case,compiler=task
 standard = 'c90' if case['mode']=='c90' else 'c99' if case['mode'].endswith('iso99') else 'c17' if case['mode'].endswith('iso17') else 'c11' if case['mode']=='std' else 'gnu11'
 flags=['-x','c','-fsyntax-only','-std='+standard]
 if case['mode'] in ('std','c90'):flags.append('-pedantic-errors')
 result=subprocess.run([compiler,*flags,'-'],input=case['source'],text=True,capture_output=True,timeout=10)
 return dict(id=case['id'],compiler=compiler,args=flags,exit=result.returncode,diagnostics=result.stderr,parser_accepted=after[case['id']]['accepted'])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(check,((c,compiler) for c in selected for compiler in ('gcc','clang'))))
(root/'native-results.json').write_text(json.dumps(results,indent=2))
summary={'cases':len(cases),'differential_mismatches':len(json.loads((root/'mismatches.json').read_text())), 'native_selected_cases':len(selected),'native_runs':len(results), 'native_results':dict(collections.Counter('compiler_accept_parser_accept' if r['exit']==0 and r['parser_accepted'] else 'compiler_accept_parser_reject' if r['exit']==0 else 'compiler_reject_parser_accept' if r['parser_accepted'] else 'compiler_reject_parser_reject' for r in results)),'infrastructure_errors':[r for r in results if r['exit'] not in (0,1)], 'versions':{cc:subprocess.check_output([cc,'--version'],text=True).splitlines()[0] for cc in ('gcc','clang')}, 'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'driver.rs',root/'generate.py',root/'cases.jsonl',root/'baseline/Cargo.lock',root/'candidate/Cargo.lock',Path('/home/dev-user/.cache/toucan/declaration-fuzz-baseline-target/debug/toucan-declaration-fuzz'),Path('/home/dev-user/.cache/toucan/declaration-fuzz-candidate-target/debug/toucan-declaration-fuzz')]}}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
for r in results:
 if r['exit']==0 and not r['parser_accepted']:
  print('compiler-only accepted',r['compiler'],cases[r['id']]['mode'],cases[r['id']]['source'])
