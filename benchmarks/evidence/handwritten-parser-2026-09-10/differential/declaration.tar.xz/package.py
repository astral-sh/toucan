from pathlib import Path
import json,hashlib,tarfile,shutil,collections
root=Path(__file__).parent
cases={c['id']:c for c in map(json.loads,(root/'cases.jsonl').read_text().splitlines())}
results=json.loads((root/'native-results.json').read_text())
differences=[]
for result in results:
 if result['exit']==0 and not result['parser_accepted']:
  case=cases[result['id']]
  if case['mode'] in ('std','c90'):
   reason='Compiler accepts underscore extensions even with pedantic ISO flags; parser core mode disables extensions.'
  elif case['category']=='implicit_int':
   reason='GCC accepts implicit int as an extension outside C90; both parser revisions reject this configuration.'
  elif case['category']=='punctuation_deletion' and 'int x[3] }' in case['source']:
   reason='Both compilers accept omitted final struct-member semicolon as an extension; both parser revisions require it.'
  elif '[__attribute__' in case['source']:
   reason='GCC accepts array-bracket GNU attributes; neither parser revision implements this grammar placement.'
  else:
   reason='Reference compiler differs from selected parser extension profile; both parser revisions agree.'
  differences.append(dict(case=case,reference=result,classification=reason))
(root/'native-differences.json').write_text(json.dumps(differences,indent=2))
summary=json.loads((root/'summary.json').read_text())
parsed=[json.loads(l) for l in (root/'candidate.jsonl').read_text().splitlines()]
summary['parser_accepted']=sum(r['accepted'] for r in parsed)
summary['parser_rejected']=sum(not r['accepted'] for r in parsed)
summary['native_difference_classification']=dict(collections.Counter(r['classification'] for r in differences))
summary['source_freeze']='source-freeze.json'
summary['tag_attribute_corrections']={'cases':30,'baseline_function_misclassifications':16,'baseline_rejections':14,'candidate_tagged_declarations':30,'native_checks':60,'native_acceptances':60}
summary['infrastructure_errors']=[r for r in results if r['exit'] not in (0,1) or any(s in r['diagnostics'].lower() for s in ('internal compiler error','please submit a bug report','frontend command failed','segmentation fault'))]
assert not summary['infrastructure_errors']
(root/'summary.json').write_text(json.dumps(summary,indent=2))
(root/'README.md').write_text(f'''# Declaration parser differential

The handwritten parser and the parser at `f1e8dc89acc74675cf81475fdc3402a76a3d09e9` agree on acceptance and AST-printer output for all {summary['cases']:,} generated cases: {summary['parser_accepted']:,} accepted and {summary['parser_rejected']:,} rejected. The final run has no mismatches. `resolved-differences.json` records two earlier minimized context differences fixed before this capture.

The deterministic matrix covers arithmetic and named types; 21 declarator shapes; typedef shadowing; pointer/array qualifier placement; parameter scopes and trailing attributes; C90 implicit declarations; designated/range/aggregate initialization; punctuation deletion; and GNU `__extension__` declaration versus expression dispatch; and parameter/storage/inferred-type specifier combinations; disabled GNU/MSVC aliases; Clang floating typedef names; and GNU/Clang C99/C17 modes with bare keywords disabled. Each source is tried with relevant combinations of core C11, core C90, GNU, Clang, GNU with Clang syntax, Microsoft-enabled Clang grammar, and ISO C99/C17 keyword profiles.

A batch driver parses each source through the public library entry point. `baseline.jsonl` and `candidate.jsonl` retain exact AST-printer strings or complete failure records. Comparison checks acceptance and complete printed AST structure, not matching diagnostic text/offsets or byte spans. Node-span preservation and integrated semantic behavior need the separate existing tests and full-source corpus. This is a finite generated test matrix, not a sustained random fuzz campaign.

## Direct tag-attribute correction

An additional 30-case matrix in `tag-attributes.json` checks GNU attributes directly after `struct`, `union`, and `enum`, including repeated lists, whitespace, and expression arguments. All 30 now produce tagged declarations. The old direct parser misclassified 16 struct/union cases as function definitions and rejected the other 14 cases (the enum cases and whitespace between attribute parentheses). The former semantic source normalizer hid this parser defect by rewriting attributes before parsing. Both GCC and Clang accept all 30 cases (60 native checks). These intentional parser corrections are separate from the {summary['cases']:,} unchanged-output cases above. `tag_attributes.py` reproduces them.

## Native reference sample

GCC 13.3.0 and Clang 18.1.3 ran syntax/semantic checking on {summary['native_selected_cases']} selected case/configuration pairs, for {summary['native_runs']} processes. All results and diagnostic text are retained.

- {summary['native_results']['compiler_accept_parser_accept']} reference runs accepted source also accepted by both parser revisions.
- {summary['native_results']['compiler_accept_parser_reject']} accepted source rejected by both parser revisions. `native-differences.json` classifies these retained differences, including disabled extension profiles, GCC implicit-int acceptance, array-bracket attributes, and omitted struct-member semicolons.
- {summary['native_results']['compiler_reject_parser_accept']} rejected source whose syntax both parser revisions accepted. Parser acceptance does not claim semantic validity.
- {summary['native_results']['compiler_reject_parser_reject']} rejected source also rejected by both parser revisions.
- No process crash, timeout, or compiler infrastructure failure was observed.

These categories are not summed into a complete-conformance pass rate. Comparing a core parser flavor with a compiler that still accepts underscore extensions under pedantic flags does not establish a regression.

## Reproduction and provenance

`driver.rs`, the two driver manifests and identical lockfiles, `generate.py`, `native.py`, `freeze.py`, and `package.py` preserve the commands and inputs. Baseline and candidate parser source snapshots are included. `source-freeze.json` checks 23 candidate source/configuration files before and after building the final batch executable. `summary.json` contains executable hashes; compiled binaries are excluded from this archive. Debug-build durations printed by the generator are not performance measurements.

The paths in driver manifests and scripts identify this capture's workspace. To reproduce elsewhere, point each driver dependency at the corresponding parser source snapshot in an existing compatible Toucan workspace, build using the recorded toolchain/lockfile, and update the two binary paths in the generator. `cases.jsonl` is sufficient to replay the exact input set without regenerating it.

The earlier 6,249-case capture is retained in `initial-6249.tar.xz`; the 6,333-case intermediate capture is retained in `initial-6333.tar.xz`. The final expanded run includes the regression derived from GCC's unmodified `stdatomic.h`, context-specific specifier cases, and disabled extension keyword cases. The prior 6,432-case snapshot is retained in `initial-6432.tar.xz`. Native declaration-suite logs and isolated scope probes are included separately.
''')
shutil.copyfile('/tmp/toucan-handwritten-declaration-tests.log',root/'declaration-tests.log')
shutil.copyfile('/tmp/toucan-handwritten-declaration-oracles.json',root/'scope-oracles.json')
files=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.name in ('declaration-evidence.tar.xz','archive-manifest.json'):continue
 files.append(p)
manifest={str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}
(root/'archive-manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(root/'declaration-evidence.tar.xz','w:xz',preset=6) as tar:
 for p in files+[root/'archive-manifest.json']:
  info=tar.gettarinfo(str(p),arcname=str(p.relative_to(root)));info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
  with p.open('rb') as handle:tar.addfile(info,handle)
archive=root/'declaration-evidence.tar.xz'
print(json.dumps({'files':len(files)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'parser_accepted':summary['parser_accepted'],'parser_rejected':summary['parser_rejected']},indent=2))
