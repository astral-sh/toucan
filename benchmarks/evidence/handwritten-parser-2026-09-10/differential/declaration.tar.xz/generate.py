import itertools,json,re,subprocess,time,hashlib
from pathlib import Path
root=Path(__file__).parent
cases=[]
def add(category,source,modes=('std','gnu','clang','gnu_clang','msvc','c90')):
 for mode in modes:
  cases.append(dict(id=len(cases),category=category,source=source,mode=mode))
base_types=['int','unsigned long','signed char','const int','volatile unsigned','_Atomic(int)','_Atomic int','struct S { int x; }','union U { int x; float y; }','enum E { A=1, B=2 }','T','long double','_Complex double','typeof(1)','__typeof__(T)','_Float32','__bf16','__int32']
declarators=['value','*value','**value','(value)','(*value)','value[3]','*value[3]','(*value)[3]','value(int)','(*value)(int)','(*value(void))[3]','(*value[3])(int)','(*(*value)(int))[3]','value(int (*cb)(int), int a[static 3])','*const value','*volatile *restrict value','value(int [*])','value(int (*)[3])','value(int (T))','value(T T)','value(int T, int (*cb)(int T))']
for base,decl in itertools.product(base_types,declarators):
 for prefix in ('','typedef '):
  add('declarator',f'typedef int T; {prefix}{base} {decl};')
qualifiers=['','const','volatile','restrict','_Atomic','__const','__restrict__','_Nonnull','__ptr32','__stdcall','__attribute__((nonnull))']
for q,template in itertools.product(qualifiers,['int *Q value;','void f(int *Q value);','typedef int *Q value;','void f(int value[Q 3]);','void f(int value[Q static 3]);']):
 add('qualifier',template.replace('Q',q))
attrs=['','__attribute__((unused))','__attribute__((aligned(8)))','__attribute__((aligned(sizeof(__typeof__(T)))))','__attribute__((availability(macos,introduced=10.15.1,message="x")))','__declspec(align(8))']
heads=['int f(int T)','int (*f(int T))(int)','int f(int (*cb)(int T))','int f(enum {T} arg)','int f(void)','int f(T arg)']
for head,attr in itertools.product(heads,attrs):
 for tail in (';','{ return 0; }'):
  add('parameter_scope',f'typedef int T; {head} {attr} {tail}')
for q,decl in itertools.product(['int','unsigned','_Bool','T','int __attribute__((aligned(8)))'],['T','(T)','*T','(*T)(T)','T[3]','T(int)','(*T[3])(int)']):
 add('typedef_shadow',f'typedef int T; void f(void){{ {q} {decl}; __typeof__(T) next; }}')
initializers=['{0}','{1,2}','{[2]=1}','{[2] 1}','{[0 ... 2]=1}','{.x=1}','{x:1}','{{1}}','{}','{[0].x=1}','{.x[1]=2}','{[2]=1,[0]=2,[2]=3}']
targets=['int value[4]','struct S { int x; } value','struct S { int x; } value[4]','struct S { int x[3]; } value','union U {int x;float y;} value']
for target,init in itertools.product(targets,initializers):
 add('initializer',f'{target} = {init};')
for prefix in ('','static ','extern ','typedef ','register ','inline '):
 for typename in ('','int','T','const'):
  add('implicit_int',f'typedef int T; {prefix}{typename} value;')
seeds=[
 'typedef int T; int (*f(int T))(int) { return 0; }',
 'struct S { int a:3; unsigned :2; int x[3]; };',
 'int f(int n, int a[static n]) { return a[0]; }',
 'int a[4] = {[1]=2,[3]=4};',
 'int f(int (*cb)(int,int), int (*p)[3]);',
 'int f(int T) __attribute__((aligned(8))) {return T;}',
]
for seed in seeds:
 add('seed',seed)
 for m in re.finditer(r'[(){}\[\],;:*]',seed):
  add('punctuation_deletion',seed[:m.start()]+seed[m.end():],('std','gnu','clang'))
for statement in [
 'int value;', 'typedef int U;', 'const T value = 0;',
 'struct S { int x; } value;', '_Static_assert(sizeof(T)>0,"type");',
 '({ int local = n; local; });', '++n;', '--n;', 'n++;', '(T)n;',
 'sizeof(T);', '__typeof__(n) value;', '__auto_type value = n;',
 '__extension__ ++n;',
]:
 add('extension_dispatch', 'typedef int T; void f(void) { int n = 0; __extension__ '+statement+' }')
for storage in ['typedef','static','extern','inline','_Noreturn','register','auto','_Thread_local','__thread']:
 for source in ['int f('+storage+' int x);','int f('+storage+' x);','void f(void){'+storage+' int x;}']:
  add('specifier_context',source,('gnu','clang','c90'))
for source in ['__auto_type int x=1;','__auto_type unsigned x=1;','__auto_type const int x=1;','__auto_type int typedef x=1;','int f(__auto_type int x);','typedef __auto_type int T;']:
 add('specifier_context',source,('gnu','clang','c90'))
for name in ['__signed','__signed__','__complex','__complex__','__auto_type','__bf16','__typeof','__typeof__','__const','__restrict','__inline','__thread','__attribute__','__extension__']:
 for template in ['typedef int N; N value;','typedef int N; void f(void){ N value; }','typedef int N; int f(N value);','typedef int N; int f(void){ return sizeof(N); }','typedef int N; N int value;']:
  add('inactive_keyword',template.replace('N',name),('std','c90'))
for name in ['asm','typeof']:
 for template in ['typedef int N; N value;','typedef int N; void f(void){ N value; }','typedef int N; int f(N value);','typedef int N; int f(void){ return sizeof(N); }']:
  add('inactive_keyword',template.replace('N',name),('gnu_iso99','clang_iso99','gnu_iso17','clang_iso17'))
for name in ['_int8','__int8','__int16','__int32','__int64','__declspec','__forceinline','__unaligned']:
 add('inactive_keyword',f'typedef int {name}; {name} value;',('std','gnu','clang','gnu_clang','msvc','c90'))
for name in ['_Float32','_Float64','_Float32x','_Float64x','_Float128','__float128']:
 add('inactive_keyword',f'typedef int {name}; {name} value;',('std','gnu','clang','gnu_clang','msvc','c90'))
(root/'cases.jsonl').write_text(''.join(json.dumps(c)+'\n' for c in cases))
print(len(cases),'cases',flush=True)
results={}
for side in ('baseline','candidate'):
 binary=Path(f'/home/dev-user/.cache/toucan/declaration-fuzz-{side}-target/debug/toucan-declaration-fuzz')
 started=time.monotonic()
 with (root/'cases.jsonl').open() as inp,(root/f'{side}.jsonl').open('w') as out:
  p=subprocess.run([str(binary)],stdin=inp,stdout=out,stderr=subprocess.PIPE,text=True,timeout=240)
 assert p.returncode==0,(side,p.returncode,p.stderr)
 results[side]=[json.loads(line) for line in (root/f'{side}.jsonl').read_text().splitlines()]
 assert len(results[side])==len(cases)
 print(side,round(time.monotonic()-started,2),flush=True)
mismatches=[]
for case,before,after in zip(cases,results['baseline'],results['candidate']):
 assert case['id']==before['id']==after['id']
 if (before['accepted'],before['tree'])!=(after['accepted'],after['tree']):
  mismatches.append(dict(case=case,baseline=before,candidate=after))
(root/'mismatches.json').write_text(json.dumps(mismatches,indent=2))
from collections import Counter
print('mismatches',len(mismatches),Counter((m['case']['category'],m['baseline']['accepted'],m['candidate']['accepted']) for m in mismatches),flush=True)
for m in mismatches[:30]:print(m['case']['mode'],m['baseline']['accepted'],m['candidate']['accepted'],m['case']['source'])
