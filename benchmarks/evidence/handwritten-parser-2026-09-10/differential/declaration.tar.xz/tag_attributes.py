from pathlib import Path
import json,subprocess,concurrent.futures,hashlib
root=Path(__file__).parent
cases=[]
for tag,body in [('struct','int x;'),('union','int x;'),('enum','A')]:
 for attrs in ['__attribute__((packed))','__attribute__((aligned(8)))','__attribute__((aligned(sizeof(int))))','  __attribute__ ( ( aligned ( 8 ) ) )','__attribute__((packed)) __attribute__((aligned(8)))']:
  for mode in ['gnu','clang']:
   cases.append(dict(id=len(cases),source=f'{tag} {attrs} Tag {{ {body} }};',mode=mode))
request=''.join(json.dumps(c)+'\n' for c in cases)
outputs={}
for side in ['baseline','candidate']:
 binary=f'/home/dev-user/.cache/toucan/declaration-fuzz-{side}-target/debug/toucan-declaration-fuzz'
 result=subprocess.run([binary],input=request,text=True,capture_output=True,check=True,timeout=30)
 outputs[side]=[json.loads(line) for line in result.stdout.splitlines()]
assert sum(row['accepted'] for row in outputs['baseline']) == 16
assert all('FunctionDefinition' in row['tree'] for row in outputs['baseline'] if row['accepted'])
assert all(row['accepted'] and 'FunctionDefinition' not in row['tree'] for row in outputs['candidate'])
def check(pair):
 case,cc=pair
 flags=['-x','c','-std=gnu11','-fsyntax-only','-']
 result=subprocess.run([cc,*flags],input=case['source'],text=True,capture_output=True,timeout=10)
 return dict(id=case['id'],compiler=cc,args=flags,exit=result.returncode,diagnostics=result.stderr)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 native=list(pool.map(check,((case,cc) for case in cases for cc in ['gcc','clang'])))
assert all(row['exit']==0 for row in native)
record=dict(description='Direct GNU tag attributes now attach to the tag AST without semantic source rewriting. The old direct parser misparses 16 struct and union declarations as FunctionDefinition nodes, rejects four struct/union cases with whitespace between attribute parentheses, and rejects the 10 enum declarations. The new parser returns tagged Declaration nodes for all cases; both native compilers accept them.',cases=cases,baseline=outputs['baseline'],candidate=outputs['candidate'],native=native)
(root/'tag-attributes.json').write_text(json.dumps(record,indent=2))
print(len(cases),'intentional parser corrections;',len(native),'native checks accepted')
