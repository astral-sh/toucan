from pathlib import Path
import hashlib,json,tarfile
p=Path(__file__).parent/'declaration-evidence.tar.xz'
with tarfile.open(p) as tar:
 manifest=json.load(tar.extractfile('archive-manifest.json'))
 names=set(tar.getnames())
 assert names==set(manifest)|{'archive-manifest.json'}
 for name,expected in manifest.items():
  content=tar.extractfile(name).read()
  assert len(content)==expected['bytes'],name
  assert hashlib.sha256(content).hexdigest()==expected['sha256'],name
print(json.dumps({'verified':len(manifest),'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'archive_bytes':p.stat().st_size}))
