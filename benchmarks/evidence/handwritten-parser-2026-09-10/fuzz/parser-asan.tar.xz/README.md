# Direct parser AddressSanitizer evidence

The main result is `parser-asan-final4-2026-09-10/evidence.json`: a completed 900-second mutation campaign with the saved, instrumented parser executable. `summary.json` records the measured duration, execution count, coverage counters, peak RSS, source hash and binary hash. The campaign exited successfully, produced no failure artifacts, and passed its source-unchanged guard. The input size limit was 16 KiB, per-input timeout five seconds, and RSS limit 1 GiB.

The same executable passed all 768 hostile depth inputs (12 source families across 64 parser settings), with evidence, sources and starting corpus under `hostile-replay/`. This is bounded fuzzing evidence, not a proof of C conformance or memory safety for every input.

AddressSanitizer was enabled. The positive control under `sanitizer-probes/` detected an intentional heap buffer overflow. LeakSanitizer could not inspect processes in this environment, so leak checking was disabled. These results make no leak-checking claim.

The campaign directory retains the binary, exact source snapshot, runner, dictionary, original and final corpora, build log, mutation log, manifests and sanitizer options. The original worktree was dirty when the campaign began; its base Git commit alone does not identify the tested source. Use the source manifest and archive hashes. `reproduction.md` explains replay with the saved executable.

The other four campaign directories preserve startup failures and an interrupted attempt. They are not counted as completed campaigns. The first could not locate cargo-fuzz; the next failed compilation while a stale reference was being fixed. The final2 attempt was interrupted after a test-formatting change invalidated its conservative source guard; its log reports 467,940 executions before interruption. The final3 attempt did not run mutations because the interrupted wrapper had left a child changing the shared corpus. That exact child was stopped before final4 started. The interrupted attempt's original evidence file says running; its final outcome is recorded separately in interruption.json and the log. The main campaign was restarted after all source and test changes were frozen.

`manifest.json` hashes every other file in this archive. All archived source, initial-corpus and final-corpus entries were checked against their recorded hashes before packaging. Saved executable hashes identify the tested artifacts; differential and benchmark measurements are recorded separately.
