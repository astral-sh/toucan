#include <stdlib.h>
int main(void){volatile char *p=malloc(1);p[8]=1;free((void*)p);}
