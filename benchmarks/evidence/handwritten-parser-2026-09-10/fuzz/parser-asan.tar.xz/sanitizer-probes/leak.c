#include <stdlib.h>
__attribute__((noinline)) void leak(void){volatile char *p=malloc(12345);p[0]=1;}
int main(void){leak();}
