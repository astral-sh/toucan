# Direct parser sanitizer campaign

The saved `parser` executable was built with Ohm and libFuzzer AddressSanitizer instrumentation. Ohm does not ship the compiler-rt ASan runtime in this environment, so the build links Clang 18’s runtime using `RUSTFLAGS="-Zexternal-clangrt -Clinker=clang -Clink-arg=-fsanitize=address"`. `build.log` and `evidence.json` record the exact build command, compiler version, environment, and binary SHA-256.

## Sanitizer coverage

AddressSanitizer is enabled. A separate positive control intentionally overflowing a heap buffer was detected by the Clang runtime; its source, binary, and log are saved in `../sanitizer-probes/`. LeakSanitizer could not inspect processes in this environment, so campaigns use `ASAN_OPTIONS=detect_leaks=0:detect_odr_violation=0` and provide **no leak-checking evidence**.

## Inputs and source

`initial-corpus.tar.gz` preserves the exact starting corpus. It includes all nine curated parser seeds expanded across 64 language/extension selections, the invalid UTF-8 seed, and discoveries retained from the earlier interrupted campaign. `source.json` records every workspace crate and Cargo build input; `source-snapshot.tar.gz` archives those exact files, and `source-archive.json` records its hash. `runner.py` preserves the runner used. The original workspace was dirty; `source_commit` alone does not identify the tested source.

`hostile-replay/` preserves 768 generated inputs: 12 deeply nested expression/declaration/statement forms across all 64 parser settings, with a maximum of 13,088 bytes. Its `sources/` directory contains the unpadded base sources. The replay uses the same saved sanitizer binary as the sustained campaign.

## Replay

Extract `initial-corpus.tar.gz` into a new directory. Run the saved executable with the command in `evidence.json`, replacing the corpus, dictionary, and artifact paths with the extracted corpus, saved `c.dict`, and a new empty artifact directory. Preserve the recorded sanitizer options. Use `-runs=0` instead of `-max_total_time=900` to replay without mutations.

For the hostile cases, extract `hostile-replay/initial-corpus.tar.gz` into another new directory and use the command in `hostile-replay/evidence.json` with the extracted corpus path. Do not write into the archived starting corpus.

## Earlier attempts

The sibling directories retain failed or interrupted attempts. The first could not find cargo-fuzz; the second failed to compile while a removed semantic-normalizer reference was being fixed. `parser-asan-final2-2026-09-10` was interrupted after an integration-test formatting change invalidated its conservative source guard. It executed 467,940 inputs without a finding before interruption, but is not a completed campaign. `parser-asan-final3-2026-09-10` failed before fuzzing when that earlier fuzzer’s child was still changing the shared corpus. The child was stopped before this campaign began. Only the final `evidence.json` status determines whether this sustained campaign passed.
