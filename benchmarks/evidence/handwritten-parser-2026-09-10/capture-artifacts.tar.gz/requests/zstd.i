typedef long int ptrdiff_t;
typedef long unsigned int size_t;
typedef int wchar_t;
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;

typedef enum {
  ZSTD_error_no_error = 0,
  ZSTD_error_GENERIC = 1,
  ZSTD_error_prefix_unknown = 10,
  ZSTD_error_version_unsupported = 12,
  ZSTD_error_frameParameter_unsupported = 14,
  ZSTD_error_frameParameter_windowTooLarge = 16,
  ZSTD_error_corruption_detected = 20,
  ZSTD_error_checksum_wrong = 22,
  ZSTD_error_literals_headerWrong = 24,
  ZSTD_error_dictionary_corrupted = 30,
  ZSTD_error_dictionary_wrong = 32,
  ZSTD_error_dictionaryCreation_failed = 34,
  ZSTD_error_parameter_unsupported = 40,
  ZSTD_error_parameter_combination_unsupported = 41,
  ZSTD_error_parameter_outOfBound = 42,
  ZSTD_error_tableLog_tooLarge = 44,
  ZSTD_error_maxSymbolValue_tooLarge = 46,
  ZSTD_error_maxSymbolValue_tooSmall = 48,
  ZSTD_error_cannotProduce_uncompressedBlock = 49,
  ZSTD_error_stabilityCondition_notRespected = 50,
  ZSTD_error_stage_wrong = 60,
  ZSTD_error_init_missing = 62,
  ZSTD_error_memory_allocation = 64,
  ZSTD_error_workSpace_tooSmall= 66,
  ZSTD_error_dstSize_tooSmall = 70,
  ZSTD_error_srcSize_wrong = 72,
  ZSTD_error_dstBuffer_null = 74,
  ZSTD_error_noForwardProgress_destFull = 80,
  ZSTD_error_noForwardProgress_inputEmpty = 82,
  ZSTD_error_frameIndex_tooLarge = 100,
  ZSTD_error_seekableIO = 102,
  ZSTD_error_dstBuffer_wrong = 104,
  ZSTD_error_srcBuffer_wrong = 105,
  ZSTD_error_sequenceProducer_failed = 106,
  ZSTD_error_externalSequences_invalid = 107,
  ZSTD_error_maxCode = 120
} ZSTD_ErrorCode;
__attribute__ ((visibility ("default"))) const char* ZSTD_getErrorString(ZSTD_ErrorCode code);
__attribute__ ((visibility ("default"))) unsigned ZSTD_versionNumber(void);
__attribute__ ((visibility ("default"))) const char* ZSTD_versionString(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_compress( void* dst, size_t dstCapacity,
                            const void* src, size_t srcSize,
                                  int compressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompress( void* dst, size_t dstCapacity,
                              const void* src, size_t compressedSize);
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_getFrameContentSize(const void *src, size_t srcSize);
__attribute__((deprecated("Replaced by ZSTD_getFrameContentSize")))
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_getDecompressedSize(const void* src, size_t srcSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_findFrameCompressedSize(const void* src, size_t srcSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBound(size_t srcSize);
__attribute__ ((visibility ("default"))) unsigned ZSTD_isError(size_t result);
__attribute__ ((visibility ("default"))) ZSTD_ErrorCode ZSTD_getErrorCode(size_t functionResult);
__attribute__ ((visibility ("default"))) const char* ZSTD_getErrorName(size_t result);
__attribute__ ((visibility ("default"))) int ZSTD_minCLevel(void);
__attribute__ ((visibility ("default"))) int ZSTD_maxCLevel(void);
__attribute__ ((visibility ("default"))) int ZSTD_defaultCLevel(void);
typedef struct ZSTD_CCtx_s ZSTD_CCtx;
__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_createCCtx(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCCtx(ZSTD_CCtx* cctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_compressCCtx(ZSTD_CCtx* cctx,
                                     void* dst, size_t dstCapacity,
                               const void* src, size_t srcSize,
                                     int compressionLevel);
typedef struct ZSTD_DCtx_s ZSTD_DCtx;
__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_createDCtx(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDCtx(ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressDCtx(ZSTD_DCtx* dctx,
                                       void* dst, size_t dstCapacity,
                                 const void* src, size_t srcSize);
typedef enum { ZSTD_fast=1,
               ZSTD_dfast=2,
               ZSTD_greedy=3,
               ZSTD_lazy=4,
               ZSTD_lazy2=5,
               ZSTD_btlazy2=6,
               ZSTD_btopt=7,
               ZSTD_btultra=8,
               ZSTD_btultra2=9
} ZSTD_strategy;
typedef enum {
    ZSTD_c_compressionLevel=100,
    ZSTD_c_windowLog=101,
    ZSTD_c_hashLog=102,
    ZSTD_c_chainLog=103,
    ZSTD_c_searchLog=104,
    ZSTD_c_minMatch=105,
    ZSTD_c_targetLength=106,
    ZSTD_c_strategy=107,
    ZSTD_c_targetCBlockSize=130,
    ZSTD_c_enableLongDistanceMatching=160,
    ZSTD_c_ldmHashLog=161,
    ZSTD_c_ldmMinMatch=162,
    ZSTD_c_ldmBucketSizeLog=163,
    ZSTD_c_ldmHashRateLog=164,
    ZSTD_c_contentSizeFlag=200,
    ZSTD_c_checksumFlag=201,
    ZSTD_c_dictIDFlag=202,
    ZSTD_c_nbWorkers=400,
    ZSTD_c_jobSize=401,
    ZSTD_c_overlapLog=402,
     ZSTD_c_experimentalParam1=500,
     ZSTD_c_experimentalParam2=10,
     ZSTD_c_experimentalParam3=1000,
     ZSTD_c_experimentalParam4=1001,
     ZSTD_c_experimentalParam5=1002,
     ZSTD_c_experimentalParam7=1004,
     ZSTD_c_experimentalParam8=1005,
     ZSTD_c_experimentalParam9=1006,
     ZSTD_c_experimentalParam10=1007,
     ZSTD_c_experimentalParam11=1008,
     ZSTD_c_experimentalParam12=1009,
     ZSTD_c_experimentalParam13=1010,
     ZSTD_c_experimentalParam14=1011,
     ZSTD_c_experimentalParam15=1012,
     ZSTD_c_experimentalParam16=1013,
     ZSTD_c_experimentalParam17=1014,
     ZSTD_c_experimentalParam18=1015,
     ZSTD_c_experimentalParam19=1016,
     ZSTD_c_experimentalParam20=1017
} ZSTD_cParameter;
typedef struct {
    size_t error;
    int lowerBound;
    int upperBound;
} ZSTD_bounds;
__attribute__ ((visibility ("default"))) ZSTD_bounds ZSTD_cParam_getBounds(ZSTD_cParameter cParam);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParameter(ZSTD_CCtx* cctx, ZSTD_cParameter param, int value);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setPledgedSrcSize(ZSTD_CCtx* cctx, unsigned long long pledgedSrcSize);
typedef enum {
    ZSTD_reset_session_only = 1,
    ZSTD_reset_parameters = 2,
    ZSTD_reset_session_and_parameters = 3
} ZSTD_ResetDirective;
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_reset(ZSTD_CCtx* cctx, ZSTD_ResetDirective reset);
__attribute__ ((visibility ("default"))) size_t ZSTD_compress2( ZSTD_CCtx* cctx,
                                   void* dst, size_t dstCapacity,
                             const void* src, size_t srcSize);
typedef enum {
    ZSTD_d_windowLogMax=100,
     ZSTD_d_experimentalParam1=1000,
     ZSTD_d_experimentalParam2=1001,
     ZSTD_d_experimentalParam3=1002,
     ZSTD_d_experimentalParam4=1003,
     ZSTD_d_experimentalParam5=1004,
     ZSTD_d_experimentalParam6=1005
} ZSTD_dParameter;
__attribute__ ((visibility ("default"))) ZSTD_bounds ZSTD_dParam_getBounds(ZSTD_dParameter dParam);
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_setParameter(ZSTD_DCtx* dctx, ZSTD_dParameter param, int value);
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_reset(ZSTD_DCtx* dctx, ZSTD_ResetDirective reset);
typedef struct ZSTD_inBuffer_s {
  const void* src;
  size_t size;
  size_t pos;
} ZSTD_inBuffer;
typedef struct ZSTD_outBuffer_s {
  void* dst;
  size_t size;
  size_t pos;
} ZSTD_outBuffer;
typedef ZSTD_CCtx ZSTD_CStream;
__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_createCStream(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCStream(ZSTD_CStream* zcs);
typedef enum {
    ZSTD_e_continue=0,
    ZSTD_e_flush=1,
    ZSTD_e_end=2
} ZSTD_EndDirective;
__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream2( ZSTD_CCtx* cctx,
                                         ZSTD_outBuffer* output,
                                         ZSTD_inBuffer* input,
                                         ZSTD_EndDirective endOp);
__attribute__ ((visibility ("default"))) size_t ZSTD_CStreamInSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_CStreamOutSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_initCStream(ZSTD_CStream* zcs, int compressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output, ZSTD_inBuffer* input);
__attribute__ ((visibility ("default"))) size_t ZSTD_flushStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output);
__attribute__ ((visibility ("default"))) size_t ZSTD_endStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output);
typedef ZSTD_DCtx ZSTD_DStream;
__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_createDStream(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDStream(ZSTD_DStream* zds);
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream(ZSTD_DStream* zds);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressStream(ZSTD_DStream* zds, ZSTD_outBuffer* output, ZSTD_inBuffer* input);
__attribute__ ((visibility ("default"))) size_t ZSTD_DStreamInSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_DStreamOutSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_compress_usingDict(ZSTD_CCtx* ctx,
                                           void* dst, size_t dstCapacity,
                                     const void* src, size_t srcSize,
                                     const void* dict,size_t dictSize,
                                           int compressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompress_usingDict(ZSTD_DCtx* dctx,
                                             void* dst, size_t dstCapacity,
                                       const void* src, size_t srcSize,
                                       const void* dict,size_t dictSize);
typedef struct ZSTD_CDict_s ZSTD_CDict;
__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict(const void* dictBuffer, size_t dictSize,
                                         int compressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCDict(ZSTD_CDict* CDict);
__attribute__ ((visibility ("default"))) size_t ZSTD_compress_usingCDict(ZSTD_CCtx* cctx,
                                            void* dst, size_t dstCapacity,
                                      const void* src, size_t srcSize,
                                      const ZSTD_CDict* cdict);
typedef struct ZSTD_DDict_s ZSTD_DDict;
__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict(const void* dictBuffer, size_t dictSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDDict(ZSTD_DDict* ddict);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompress_usingDDict(ZSTD_DCtx* dctx,
                                              void* dst, size_t dstCapacity,
                                        const void* src, size_t srcSize,
                                        const ZSTD_DDict* ddict);
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromDict(const void* dict, size_t dictSize);
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromCDict(const ZSTD_CDict* cdict);
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromDDict(const ZSTD_DDict* ddict);
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromFrame(const void* src, size_t srcSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary(ZSTD_CCtx* cctx, const void* dict, size_t dictSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refPrefix(ZSTD_CCtx* cctx,
                                 const void* prefix, size_t prefixSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refDDict(ZSTD_DCtx* dctx, const ZSTD_DDict* ddict);
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refPrefix(ZSTD_DCtx* dctx,
                                 const void* prefix, size_t prefixSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CCtx(const ZSTD_CCtx* cctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DCtx(const ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CStream(const ZSTD_CStream* zcs);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DStream(const ZSTD_DStream* zds);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CDict(const ZSTD_CDict* cdict);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DDict(const ZSTD_DDict* ddict);
