import copy,importlib.util,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',ROOT/'comparison.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def snapshot(ast,source):return {'outcome':'ok','ast':ast,'counts':{'declarations':1},'source_bytes':len(source)}
def compare(a,b,source):return module.compare_parser(snapshot(a,source),snapshot(b,source),source)
checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
check('trim accepted',compare('N { span: 0…3 }','N { span: 0…1 }',b'a  ')['accepted'])
check('UTF8 byte offsets accepted',compare('N { span: 0…4 }','N { span: 0…2 }','é  '.encode())['accepted'])
check('start change rejected',not compare('N { span: 0…3 }','N { span: 1…2 }',b'a  ')['accepted'])
check('token deletion rejected',not compare('N { span: 0…3 }','N { span: 0…1 }',b'a+ ')['accepted'])
check('span extension rejected',not compare('N { span: 0…1 }','N { span: 0…3 }',b'a  ')['accepted'])
check('out of bounds rejected',not compare('N { span: 0…4 }','N { span: 0…1 }',b'a  ')['accepted'])
check('quoted span text preserved',not compare('N { name: "span: 0…3", span: 0…3 }','N { name: "span: 0…1", span: 0…1 }',b'a  ')['accepted'])
check('escaped quote text preserved',not compare('N { name: "\\\"span: 0…3", span: 0…3 }','N { name: "\\\"span: 0…1", span: 0…1 }',b'a  ')['accepted'])
a=snapshot('N { span: 0…3 }',b'a  ');b=copy.deepcopy(a);b['counts']['declarations']=2
check('changed count rejected',not module.compare_parser(a,b,b'a  ')['accepted'])
rows=json.loads((ROOT/'statement-differential/summary.json').read_text())['span_differences']
for row in rows:
 source=row['case']['source'].encode();result=compare(row['baseline']['ast'],row['candidate']['ast'],source)
 assert result['accepted'] and not result['exact_spans'],row['case']['id']
check('184 reviewed AST differences accepted',len(rows)==184)
(ROOT/'comparison-validation.json').write_text(json.dumps({'status':'passed','checks':checks},indent=2)+'\n')
print('passed',len(checks),'checks')
