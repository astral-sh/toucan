import hashlib,json,subprocess
from pathlib import Path
R=Path('/tmp/toucan-handwritten-parser');out=R/'record-attribute-review'
sources={
 'struct':'struct __attribute__((packed)) S { char c; int x; }; struct S value;',
 'union':'union __attribute__((aligned(8))) U { char c; int x; }; union U value;',
 'enum':'enum __attribute__((packed)) E { A, B }; enum E value;',
 'spaced_struct':'struct __attribute__ ( ( packed ) ) S { char c; int x; }; struct S value;',
 'attribute_expression':'struct __attribute__((aligned(sizeof(int)))) S { char c; }; struct S value;',
}
rows=[]
for name,source in sources.items():
 header=out/(name+'.h');header.write_text(source+'\n')
 request={'header':str(header),'target':'x86_64-unknown-linux-gnu','include_dirs':[],'sysroot':'/','policy':'builder','allowlist_files':[str(header)]}
 request_path=out/(name+'.json');request_path.write_text(json.dumps(request))
 for label,binary in [('baseline',R/'bin/baseline'),('candidate',R/'candidate-first/normal')]:
  output=out/(name+'.'+label+'.output.json')
  command=[str(binary),'checked',str(request_path),'1',str(output)]
  process=subprocess.run(command,capture_output=True,text=True,timeout=60)
  (out/(name+'.'+label+'.stdout')).write_text(process.stdout)
  (out/(name+'.'+label+'.stderr')).write_text(process.stderr)
  rows.append({'name':name,'variant':label,'command':command,'exit_code':process.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
  print(name,label,process.returncode)
(out/'processes.json').write_text(json.dumps(rows,indent=2)+'\n')
