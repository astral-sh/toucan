use toucan_parser::driver::{Config, parse_preprocessed_with_limits};
use toucan_parser::limits::ParseLimits;
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let n: usize = args[2].parse().unwrap();
    let depth: usize = args[3].parse().unwrap();
    let source = match args[1].as_str() {
        "choose" => format!("int x={}0{};", "__builtin_choose_expr(1,".repeat(n), ",0)".repeat(n)),
        "control" => format!("int f(int x) {{ {}return x; }}", "if(x)".repeat(n)),
        "auto" => format!("void f(void){{{}1{};}}", "__auto_type x=({".repeat(n), ";x;})".repeat(n)),
        "parentheses" => format!("int f(int x) {{ return {}x{}; }}", "(".repeat(n), ")".repeat(n)),
        "declarator" => format!("int {}x{};", "(".repeat(n), ")".repeat(n)),
        "blocks" => format!("int f(void) {{ {}int x = 0;{} return 0; }}", "{".repeat(n), "}".repeat(n)),
        "records" => format!("{}int x;{};", "struct S {".to_owned() + &"struct {".repeat(n), "} x;".repeat(n) + "}"),
        "pointer" => format!("int {}p;", "*".repeat(n)),
        _ => panic!("unknown case"),
    };
    let outcome = parse_preprocessed_with_limits(&Config::with_gcc(), source, ParseLimits { max_rule_depth: depth, ..ParseLimits::default() });
    match outcome {
        Ok(parsed) => println!("OK {:?}", parsed.statistics),
        Err(error) => println!("ERROR {:?} {:?}", error.resource, error.statistics),
    }
}
