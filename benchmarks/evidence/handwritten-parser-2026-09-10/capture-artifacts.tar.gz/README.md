# Handwritten parser comparison

Baseline: `f1e8dc89acc74675cf81475fdc3402a76a3d09e9` in `/home/dev-user/code/oss/toucan-handwritten-baseline`.
The source checkout is clean. Baseline binaries and their hashes are frozen in `baseline-build.json`.

## Prepared evidence

- Normal and System allocation-counter builds use the same external harness. Both use fat LTO, one codegen unit, debug=0, and no incremental compilation. Ohm experimental defaults are disabled. All 32 registry dependencies preserve baseline lockfile versions/checksums.
- 151 physical inputs and request files are SHA256-pinned by `workloads.json`.
- 14 workloads: four Builder headers, five retained semantic compilations, five direct parser inputs. Projects are zlib 1.3.1, SQLite 3.45.1, zstd 1.5.7, and libgit2 1.9.1. The fifth source is untouched zlib `adler32.c`.
- 18 normal preflight processes passed, including four complete Builder reports. All 14 counter processes produce byte-identical outputs to normal baseline. Comparator self-check passed all 14 workloads and four reports against the baseline binary.
- These preflight timings were collected while other work was running. They are not performance evidence.

Direct parser inputs come from one frozen Clang 18 `-E -P` preprocessing of each untouched source. They are not Toucan's raw preprocessor output: the semantic frontend performs internal normalization before calling the generated parser. This distinction is recorded in `attempts/raw-preprocessor-input`, where the initial direct-input harness correctly rejected a spaced attribute. Both parser variants receive the same frozen `.i` bytes. Checked and Builder workloads exercise Toucan's preprocessing and normalization end to end.

Successful direct parser output includes every AST value and span in derived Debug representation, plus independent visitor counts for external declarations, declarations, declarators, expressions, statements, and function definitions. The untouched `adler32.c` fixture has 5 function definitions, 229 statements, and 666 expressions. Count summaries are in `baseline-counts.json`.

Checked output includes the semantic translation unit, checked graph, preprocessed source, and dependencies. Builder output and normalized reports must match exactly. This does not claim coverage of every optional semantic catalog or preprocessor macro map.

Resource statistics are deterministic within each parser variant but are recorded separately from AST equivalence: rule, cache, clone, and backtracking totals necessarily change when the algorithm changes. Existing independent resource-limit tests remain required; a zero-cache implementation must not fabricate cache allocation to preserve a generated-parser counter value.

## Candidate build

Copy `harness/baseline` to a candidate harness directory. Change only the three absolute Toucan path dependencies to the candidate checkout. Preserve source bytes, lockfile registry versions, profile settings and toolchain. Use a distinct candidate CARGO_TARGET_DIR and the shared Ohm build directory.

```
CARGO_HOME=/home/dev-user/.cache/toucan/cargo \
CARGO_TARGET_DIR=/home/dev-user/.cache/toucan/handwritten-candidate-target \
CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/toucan/ohm-shared-build \
CARGO_INCREMENTAL=0 \
cargo +ohm -Zohm-defaults=no build --manifest-path /tmp/toucan-handwritten-parser/harness/candidate/Cargo.toml --release --locked --offline
```

Freeze the normal binary before rebuilding with `--features allocations`. Record the candidate source tree or exact source-file hashes and binary SHA256. Do not rebuild either frozen binary during comparisons.

## Comparisons

Run candidate correctness preflight first:

```
python3 /tmp/toucan-handwritten-parser/compare.py --mode preflight --candidate /absolute/path/to/candidate --output /tmp/toucan-handwritten-parser/candidate-preflight
```

Preflight retains all output captures and mismatches. Builder Rust and normalized reports must match exactly. Checked snapshots may pass only the independently reviewed source-range policy below. Direct parser snapshots may additionally pass the reviewed span policy: every AST value and range start stays identical, every changed range end moves earlier, and the removed UTF-8 byte suffix contains only ASCII whitespace. Each changed span is recorded, and qualification then explicitly records `exact_parser_spans: false`. Checked snapshots require identical non-range values and only contiguous, non-synthetic whitespace range trims at the reviewed paths, plus the 19 exact source-pinned closing-delimiter restorations in reviewed-checked-span-corrections.json. All other changes fail; exact_checked_outputs stays false and nonwhitespace_fix_count records 19 for this candidate.

Timing and allocation runs require a successful frozen preflight. They verify every measured output against that variant's own approved SHA256 and retain the preflight qualifications. Allocation runs additionally verify the build manifest ties the counter binary to the exact normal binary in preflight.

After all native builds and checks have stopped, run timing and counters sequentially:

```
python3 /tmp/toucan-handwritten-parser/compare.py --mode timing --candidate /absolute/path/to/candidate --preflight /tmp/toucan-handwritten-parser/candidate-preflight/capture.json --output /tmp/toucan-handwritten-parser/timing --rounds 7 --iterations 5 --cpu 3 --native-work-complete
python3 /tmp/toucan-handwritten-parser/compare.py --mode allocations --candidate /absolute/path/to/candidate-counter --preflight /tmp/toucan-handwritten-parser/candidate-preflight/capture.json --candidate-build /absolute/path/to/build.json --output /tmp/toucan-handwritten-parser/allocations --rounds 5 --iterations 3 --cpu 3 --native-work-complete
```

The runner randomizes workload and variant order, records all per-call samples and warmups, and calculates paired ratios of process medians. Both variants rerun in every pair. It checks input/output hashes before accepting results. CPU selection must be available in the process's affinity mask. Whole-process maximum RSS includes output verification and serialization; requested allocation bytes are cumulative requests, not live heap. Parser and checked timings include the public owned-input API and construction; snapshotting and destruction occur after the timer. Builder includes rendering.

## Additional correctness gates

- Existing 139 parser reftests retain every golden output and typedef-environment check.
- All focused parser integration tests, semantic parser-extension tests, full workspace tests and Clippy.
- Existing native GCC/Clang conformance and corpus layout/FFI probes.
- Adversarial accepted/rejected grammar fixtures and resource tests, including malformed literals, Unicode, typedef shadowing, nested declarators, expression precedence, dangling-else, designated initializers, C90/C99/C11/C17 modes and GNU/MSVC extensions.
- Isolated process timeouts and stack limits for hostile nesting; successful AST clone/drop on ordinary caller stacks.
- Differential fuzzing should compare acceptance and successful ASTs, separately classify diagnostics and intentional corrections, and minimize every mismatch. Changed diagnostic expected-token sets are evidence for review, not a reason to silently discard a case.
