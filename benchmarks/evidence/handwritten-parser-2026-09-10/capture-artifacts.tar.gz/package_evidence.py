#!/usr/bin/env python3
"""Archive exact validation inputs and output captures without compiled executables."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=Path('/home/dev-user/.codex/worktrees/c877/toucan/benchmarks/evidence/handwritten-parser-2026-09-10')
selections=[
 'README.md','baseline-build.json','baseline-counts.json','workloads.json','inputs.json',
 'reviewed-checked-span-corrections.json','comparison.py','compare.py','compare.strict-initial.py',
 'capture_baseline.py','build_candidate.py','diagnose_checked_spans.py','test_comparison.py',
 'test_checked_comparison.py','comparison-validation.json','checked-comparison-validation.json',
 'package_evidence.py','harness/baseline','candidate-validated/harness','candidate-validated/build.json',
 'candidate-validated/metadata.json','candidate-validated/normal.build.log','candidate-validated/allocations.build.log',
 'logs/build-baseline.log','logs/build-baseline-allocations.log','baseline-preflight',
 'baseline-counter-preflight','candidate-first-preflight','candidate-validated-preflight-strict',
 'candidate-validated-preflight-reviewed','record-attribute-review','record-attribute-review-validated',
 'requests','statement-differential','adversarial',
]
files=set()
for selection in selections:
 path=ROOT/selection
 assert path.exists(),selection
 candidates=path.rglob('*') if path.is_dir() else [path]
 for candidate in candidates:
  if not candidate.is_file() or '__pycache__' in candidate.parts or 'target' in candidate.parts:continue
  files.add(candidate)
records=[]
archive=OUT/'capture-artifacts.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for path in sorted(files):
    data=path.read_bytes();name=str(path.relative_to(ROOT))
    assert not data.startswith(b'\x7fELF'),name
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data))
    records.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'member_count':len(records),'uncompressed_bytes':sum(r['bytes'] for r in records),'members':records}
(OUT/'capture-artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 for record,member in zip(records,tar.getmembers()):
  assert record['path']==member.name
  data=tar.extractfile(member).read()
  assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
print(json.dumps({key:value for key,value in manifest.items() if key!='members'}))
