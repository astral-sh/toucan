from pathlib import Path
import subprocess,json,random,re,hashlib,resource
ROOT=Path(__file__).resolve().parent
bodies=[
 ';','return 0;',
 'if (x) if (y) return 1; else return 2; return 3;',
 'if (x) { typedef int U; U y; } else { int U; } return 0;',
 'while (x) { if (y) break; else continue; } return x;',
 'do { x++; } while (x < 4); return x;',
 'for (int i = 0; i < 4; ++i) { x += i; } return x;',
 'for (;;) break; return 0;',
 'for (x = 0; x < 4; x++) y += x; return y;',
 'typedef int T; { int T = 1; T = 2; } T a; return x;',
 'typedef int T; for (int T = 0; T < 1; ++T) { T = 2; } T a = 0; return a;',
 'switch (x) { case 0: x++; break; case 1: return 2; default: ; } return 0;',
 'switch (x) { case 1 ... 3: return 2; default: return 0; }',
 'label: goto label;',
 '_Static_assert(1, "ok"); return 0;',
 'for (_Static_assert(1, "ok"); ; ) break; return 0;',
 '__attribute__((unused)); return 0;',
 '__asm__ volatile ("" : "=r" (x) : "r" (y) : "memory"); return x;',
 '__asm__ ("" : : :); return 0;',
 'return ({ int y = 1; y; });',
 'int a[3] = { [1] = 2 }; return a[x];',
 'return _Generic(x, int: x, default: y);',
 'return sizeof (x) + _Alignof(int);',
 'return sizeof (int){1};',
 'typedef int T; return __typeof__((T)) + 1;',
 'int a[1]; return sizeof(a)[0];',
 'if (x) int invalid; return 0;',
 'case 1: return 0;',
 'int else = 1; return else;',
 'return "é𝄞"[0];',
 'return "bad\\z"[0];',
 'return 0x1e+1;',
 'return x + = y;',
 'return x < < y;',
 'return x >> = y;',
 'return x +/**/+ y;',
]
cases=[]
for index,body in enumerate(bodies):
 for mode in ['std','gnu','clang','msvc','c90']:
  source='int f(int x, int y) { '+body+' }'
  variants=[source, '\n\t'+source+'\n', source.replace(';','; \n\t'),source.replace('{','{\n').replace('}','\n}')]
  for whitespace,variant in enumerate(variants):cases.append({'id':len(cases),'source':variant,'mode':mode,'family':index,'whitespace':whitespace})
for spelling in ['0x','09','0b','1e+','0x1p-','1.0.0','123name',"''","'\\x'",'"unfinished','💥','é','u8"x"','u\'x\'','L\'x\'']:
 for mode in ['std','gnu','clang','c90']:
  source='int f(void) { return '+spelling+'; }'
  cases.append({'id':len(cases),'source':source,'mode':mode,'family':'lexical','whitespace':0})
payload=''.join(json.dumps({key:case[key] for key in ['id','source','mode']})+'\n' for case in cases)
(ROOT/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
outputs={}
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for variant in ['baseline','candidate']:
 binary=Path('/home/dev-user/.cache/toucan/handwritten-statement-'+variant+'-target/debug/toucan-statement-differential')
 process=subprocess.run([str(binary)],input=payload,text=True,capture_output=True,timeout=180,preexec_fn=no_core)
 (ROOT/(variant+'.jsonl')).write_text(process.stdout);(ROOT/(variant+'.stderr')).write_text(process.stderr)
 process.check_returncode();outputs[variant]=[json.loads(line) for line in process.stdout.splitlines()];assert len(outputs[variant])==len(cases)
summary={'total':len(cases),'same':0,'acceptance_differences':[],'tree_differences':[],'span_differences':[],'rejected_by_both':0}
for case,b,c in zip(cases,outputs['baseline'],outputs['candidate']):
 assert case['id']==b['id']==c['id']
 entry={'case':case,'baseline':b,'candidate':c}
 if b['accepted']!=c['accepted']:summary['acceptance_differences'].append(entry)
 elif not b['accepted']:summary['rejected_by_both']+=1
 elif b['tree']!=c['tree']:summary['tree_differences'].append(entry)
 elif b['ast']!=c['ast']:summary['span_differences'].append(entry)
 else:summary['same']+=1
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in summary.items()}))
for key in ['acceptance_differences','tree_differences','span_differences']:
 print(key,[(x['case']['id'],x['case']['family'],x['case']['mode']) for x in summary[key]][:40])
