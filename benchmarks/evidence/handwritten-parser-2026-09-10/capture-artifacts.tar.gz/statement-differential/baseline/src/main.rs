use std::io::{self, BufRead, Write};
use serde::{Deserialize, Serialize};
use toucan_parser::{driver::{Config, Flavor, Standard, parse_preprocessed}, print::Printer, visit::Visit};
#[derive(Deserialize)]
struct Case { id: usize, source: String, mode: String }
#[derive(Serialize)]
struct Result { id: usize, accepted: bool, tree: Option<String>, ast: Option<String>, offset: Option<usize>, error: Option<String> }
fn main() {
 let stdout = io::stdout();
 let mut output = io::BufWriter::new(stdout.lock());
 for line in io::stdin().lock().lines() {
  let case: Case = serde_json::from_str(&line.unwrap()).unwrap();
  let config = match case.mode.as_str() {
   "gnu"=>Config::with_gcc(),
   "clang"=>Config::with_clang(),
   "gnu_clang"=>Config{flavor:Flavor::GnuC11WithClangExtensions,..Config::with_gcc()},
   "msvc"=>Config{extensions_msvc:true,..Config::with_clang()},
   "c90"=>Config{standard:Standard::C90,gnu_keywords:false,flavor:Flavor::StdC11,..Config::with_gcc()},
   "std"=>Config{gnu_keywords:false,flavor:Flavor::StdC11,..Config::with_gcc()},
   _=>panic!("unknown mode")
  };
  let result=match parse_preprocessed(&config,case.source) {
   Ok(parsed)=>{let mut tree=String::new();Printer::new(&mut tree).visit_translation_unit(&parsed.unit);Result{id:case.id,accepted:true,tree:Some(tree),ast:Some(format!("{:?}",parsed.unit)),offset:None,error:None}},
   Err(error)=>Result{id:case.id,accepted:false,tree:None,ast:None,offset:Some(error.offset),error:Some(error.to_string())}
  };
  serde_json::to_writer(&mut output,&result).unwrap();
  writeln!(output).unwrap();
 }
}
