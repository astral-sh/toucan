#!/usr/bin/env python3
"""Compare frozen parser, retained semantic, and Builder workloads against baseline."""
import argparse,hashlib,json,os,pathlib,random,statistics,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--candidate',type=pathlib.Path,required=True)
 p.add_argument('--mode',choices=['preflight','timing','allocations'],required=True)
 p.add_argument('--output',type=pathlib.Path,required=True)
 p.add_argument('--rounds',type=int,default=7)
 p.add_argument('--iterations',type=int,default=5)
 p.add_argument('--cpu',type=int,default=min(os.sched_getaffinity(0)))
 p.add_argument('--native-work-complete',action='store_true')
 a=p.parse_args()
 if a.mode!='preflight' and not a.native_work_complete: p.error('timing requires --native-work-complete')
 if a.mode!='preflight' and a.rounds<5: p.error('at least five process pairs required')
 if a.iterations<3: p.error('at least three iterations required')
 if a.cpu not in os.sched_getaffinity(0): p.error('CPU not available')
 spec=json.loads((ROOT/'workloads.json').read_text())
 baseline=json.loads((ROOT/'baseline-build.json').read_text())
 baseline_binary=pathlib.Path(baseline['allocation_binary' if a.mode=='allocations' else 'binary'])
 assert sha(baseline_binary)==baseline['allocation_sha256' if a.mode=='allocations' else 'sha256']
 binaries={'baseline':baseline_binary,'candidate':a.candidate.resolve()}
 fingerprints={name:sha(path) for name,path in binaries.items()}
 expected={r['name']:r['output_sha256'] for r in json.loads((ROOT/'baseline-preflight/processes.json').read_text())}
 for path,digest in spec['inputs'].items(): assert sha(path)==digest,path
 a.output.mkdir(exist_ok=False,parents=True)
 rows=[];result={'status':'failed','mode':a.mode,'random_seed':20260910,'cpu':a.cpu,'binary_sha256':fingerprints,'baseline_commit':baseline['head'],'rows':rows,'qualification':'Warm repeated calls; inputs and complete successful outputs checked. Parser/checked return owned results before timing ends; output verification, serialization, and destruction follow outside timing. Builder includes rendering. RSS covers the entire process. Allocation bytes are cumulative requests, not peak live heap.'}
 env=os.environ.copy()
 for key in ['MALLOC_CONF','JEMALLOC_CONF','_RJEM_MALLOC_CONF','MIMALLOC_VERBOSE','MIMALLOC_SHOW_STATS']: env.pop(key,None)
 randomizer=random.Random(20260910)
 try:
  for pair in range(1 if a.mode=='preflight' else a.rounds):
   workloads=list(spec['workloads']);randomizer.shuffle(workloads)
   for workload in workloads:
    names=['candidate'] if a.mode=='preflight' else ['baseline','candidate'];randomizer.shuffle(names)
    for order,name in enumerate(names):
     label=f"{workload['name']}-{pair}-{name}";output=a.output/(label+'.output');rss=a.output/(label+'.rss.txt')
     command=['taskset','-c',str(a.cpu),'/usr/bin/time','-v','-o',str(rss),str(binaries[name]),workload['engine'],workload['request'],str(a.iterations),str(output)]
     start=time.time();process=subprocess.run(command,capture_output=True,text=True,timeout=180,env=env)
     (a.output/(label+'.stdout')).write_text(process.stdout);(a.output/(label+'.stderr')).write_text(process.stderr)
     row={'workload':workload['name'],'variant':name,'pair':pair,'order':order,'command':command,'exit_code':process.returncode,'process_seconds':time.time()-start};rows.append(row)
     process.check_returncode();data=json.loads(process.stdout)
     assert data['instrumented']==(a.mode=='allocations'),'incorrect instrumentation'
     assert sha(output)==expected[workload['name']],f"{label}: output differs"
     row.update(samples_ms=data['samples_ms'],warmup_ms=data['warmup_ms'],allocations=data['allocations'],output_sha256=sha(output),statistics=data.get('statistics'))
     row['peak_rss_kib']=int(next(line.split(':',1)[1] for line in rss.read_text().splitlines() if 'Maximum resident set size (kbytes)' in line))
     (a.output/'capture.json').write_text(json.dumps(result,indent=2)+'\n')
  if a.mode=='preflight':
   for project in ['zlib','sqlite','zstd','libgit2']:
    output=a.output/(project+'.report.json');process=subprocess.run([str(binaries['candidate']),'toucan-report',str(ROOT/'requests'/(project+'.json')),'capture',str(output)],capture_output=True,text=True,timeout=180,env=env);process.check_returncode()
    report=json.loads(output.read_text());report.pop('timings',None)
    assert report==json.loads((ROOT/'baseline-preflight'/(project+'.report.normalized.json')).read_text()),f'{project}: report differs'
  for path,digest in spec['inputs'].items(): assert sha(path)==digest,path
  for name,path in binaries.items(): assert sha(path)==fingerprints[name]
  summary={}
  if a.mode!='preflight':
   for workload in spec['workloads']:
    pairs=[]
    for pair in range(a.rounds):
     both={r['variant']:r for r in rows if r['pair']==pair and r['workload']==workload['name']};assert set(both)=={'baseline','candidate'}
     b,c=both['baseline'],both['candidate'];item={'pair':pair,'latency_ratio':statistics.median(c['samples_ms'])/statistics.median(b['samples_ms']),'rss_ratio':c['peak_rss_kib']/b['peak_rss_kib']}
     if a.mode=='allocations':
      item.update(allocation_calls_ratio=statistics.median(x[0] for x in c['allocations'])/statistics.median(x[0] for x in b['allocations']),requested_bytes_ratio=statistics.median(x[1] for x in c['allocations'])/statistics.median(x[1] for x in b['allocations']))
     pairs.append(item)
    summary[workload['name']]={'pairs':pairs,'median_ratios':{key:statistics.median(item[key] for item in pairs) for key in pairs[0] if key!='pair'}}
  result.update(status='passed',summary=summary)
 finally: (a.output/'capture.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'process_count':len(rows),'summary':result.get('summary')}))
if __name__=='__main__': main()
