struct __attribute__((aligned(sizeof(int)))) S { char c; }; struct S value;
