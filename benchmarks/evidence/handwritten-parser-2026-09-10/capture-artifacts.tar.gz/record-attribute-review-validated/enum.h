enum __attribute__((packed)) E { A, B }; enum E value;
