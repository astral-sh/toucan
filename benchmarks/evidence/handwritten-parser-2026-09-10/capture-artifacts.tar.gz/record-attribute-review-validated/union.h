union __attribute__((aligned(8))) U { char c; int x; }; union U value;
