struct __attribute__ ( ( packed ) ) S { char c; int x; }; struct S value;
