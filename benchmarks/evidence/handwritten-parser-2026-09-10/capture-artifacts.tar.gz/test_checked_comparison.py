import copy,importlib.util,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('comparison',ROOT/'comparison.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def snapshot(source='é  ',end=4):
    return {'source':source,'unit':{'constant':7},'dependencies':['input.h'],'checked':{'occurrences':[{'kind':'Expression','source':{'range':{'start':0,'end':end},'synthetic':False,'fragments':[]}}]}}

def pair():
    a=snapshot();b=copy.deepcopy(a);b['checked']['occurrences'][0]['source']['range']['end']=2;return a,b

checks=[]
def check(name,condition):
    assert condition,name
    checks.append(name)

a,b=pair();r=m.compare_checked(a,b);check('UTF8 whitespace trim accepted',r['accepted'] and not r['exact_spans'] and r['changed_span_count']==1)
a,b=pair();b['unit']['constant']=8;check('semantic value change rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();b['dependencies'].append('extra.h');check('dependency change rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();b['source']='é+ ';check('source change rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();b['checked']['occurrences'][0]['source']['range']['start']=1;check('range start change rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();a['source']=b['source']='é+ ';check('removed punctuation rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();b['checked']['occurrences'][0]['source']['range']['end']=5;check('range extension rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();a['checked']['occurrences'][0]['source']['synthetic']=b['checked']['occurrences'][0]['source']['synthetic']=True;check('synthetic source rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();a['checked']['occurrences'][0]['source']['fragments']=b['checked']['occurrences'][0]['source']['fragments']=[{'start':0,'end':4}];check('fragmented source rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();a['unit']['range']={'start':0,'end':4};b['unit']['range']={'start':0,'end':2};check('unreviewed range location rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();b['checked']['occurrences'][0]['kind']='Declarator';check('occurrence kind change rejected',not m.compare_checked(a,b)['accepted'])
a,b=pair();b['checked']['occurrences'][0]['source']['range']['end']=True;check('boolean offset rejected',not m.compare_checked(a,b)['accepted'])
preflight=ROOT/'candidate-validated-preflight-strict';references={r['name']:r for r in json.loads((ROOT/'baseline-preflight/processes.json').read_text())}
for name,reference in references.items():
    if reference['engine']!='checked':continue
    baseline=json.loads(pathlib.Path(reference['output']).read_text());candidate=json.loads((preflight/(name+'-0-candidate.output')).read_text())
    result=m.compare_checked(baseline,candidate)
    assert not result['accepted'] and result['kind']=='checked_change_is_not_a_suffix_trim',name
check('all5 current checked outputs reject unapproved delimiter extensions',True)
manifest=json.loads((ROOT/'reviewed-checked-span-corrections.json').read_text())
restored=0;whitespace=0
for name,reference in references.items():
    if reference['engine']!='checked':continue
    baseline=json.loads(pathlib.Path(reference['output']).read_text());candidate=json.loads((preflight/(name+'-0-candidate.output')).read_text())
    result=m.compare_checked(baseline,candidate,name,manifest)
    assert result['accepted'] and not result['exact_spans'],(name,result)
    restored+=result['restored_delimiter_count'];whitespace+=result['whitespace_trim_count']
check('exact19 reviewed restorations accepted',restored==19)
check('all17133 whitespace trims proved',whitespace==17133)
name='zlib-checked';baseline=json.loads(pathlib.Path(references[name]['output']).read_text());candidate=json.loads((preflight/(name+'-0-candidate.output')).read_text())
index=next(i for i,item in enumerate(manifest['corrections']) if item['workload']==name)
for field,replacement in [('workload','other'),('source_sha256','0'*64),('path',[]),('baseline',{'start':0,'end':1}),('candidate',{'start':0,'end':2}),('occurrence_kind','Expression'),('restored_bytes_hex','20'),('candidate_spelling','other')]:
    altered=copy.deepcopy(manifest);altered['corrections'][index][field]=replacement
    check('correction '+field+' mismatch rejected',not m.compare_checked(baseline,candidate,name,altered)['accepted'])
altered=copy.deepcopy(manifest);altered['corrections'].append(copy.deepcopy(altered['corrections'][index]));altered['count']+=1
check('duplicate correction rejected',not m.compare_checked(baseline,candidate,name,altered)['accepted'])
(ROOT/'checked-comparison-validation.json').write_text(json.dumps({'status':'passed','checks':checks},indent=2)+'\n')
print('passed',len(checks),'checks')
