#!/usr/bin/env python3
"""Build and freeze candidate normal/counter binaries; abort if source changes mid-build."""
import argparse,hashlib,json,os,pathlib,shutil,subprocess,time,tomllib
ROOT=pathlib.Path(__file__).resolve().parent
BASELINE='/home/dev-user/code/oss/toucan-handwritten-baseline'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def inputs(source):
 paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','--','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml'],cwd=source,text=True).splitlines()
 return {p:sha(source/p) for p in sorted(set(paths)) if (source/p).is_file()}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--tag',required=True);a=p.parse_args()
 if not a.tag.replace('-','').replace('_','').isalnum(): p.error('tag must contain letters, digits, - or _')
 source=a.source.resolve();out=ROOT/('candidate-'+a.tag);out.mkdir(exist_ok=False)
 harness=out/'harness';shutil.copytree(ROOT/'harness/baseline',harness)
 manifest=harness/'Cargo.toml';manifest.write_text(manifest.read_text().replace(BASELINE,str(source)))
 before=inputs(source);metadata={'status':'failed','source':str(source),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'source_files':before,'harness_main_sha256':sha(harness/'src/main.rs'),'counter_sha256':sha(harness/'src/counter.rs'),'started_at':time.time()}
 env=os.environ.copy();env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_TARGET_DIR='/home/dev-user/.cache/toucan/handwritten-candidate-target',CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/toucan/ohm-shared-build',CARGO_INCREMENTAL='0')
 for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']: env.pop(key,None)
 cargo=['cargo','+ohm','-Zohm-defaults=no']
 try:
  with (out/'metadata.json').open('w') as log: subprocess.run(cargo+['metadata','--manifest-path',str(manifest),'--offline','--format-version','1'],stdout=log,check=True,env=env,cwd=source)
  baseline_lock=tomllib.loads((ROOT/'harness/baseline/Cargo.lock').read_text());candidate_lock=tomllib.loads((harness/'Cargo.lock').read_text())
  registry=lambda x:{(i['name'],i['version'],i['source']):i.get('checksum') for i in x['package'] if 'source' in i}
  assert registry(baseline_lock)==registry(candidate_lock),'registry dependency graph changed; review before comparison'
  for mode,features in [('normal',[]),('allocations',['--features','allocations'])]:
   command=cargo+['build','--manifest-path',str(manifest),'--release','--locked','--offline',*features]
   with (out/(mode+'.build.log')).open('w') as log: subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,env=env,cwd=source)
   assert inputs(source)==before,'candidate source changed during build; retry with stable source'
   binary=out/mode;shutil.copy2(pathlib.Path(env['CARGO_TARGET_DIR'])/'release/toucan-parser-comparison',binary)
   metadata[mode]={'binary':str(binary),'sha256':sha(binary),'command':command}
  metadata['status']='passed'
 finally: (out/'build.json').write_text(json.dumps(metadata,indent=2)+'\n')
 print(json.dumps({'status':metadata['status'],'output':str(out),'normal':str(out/'normal'),'allocations':str(out/'allocations')}))
if __name__=='__main__':main()
