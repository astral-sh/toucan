#!/usr/bin/env python3
"""Freeze preflight outputs and preprocessed inputs; these are not performance claims."""
import hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
PROJECTS=['zlib','sqlite','zstd','libgit2']
PRIOR=pathlib.Path('/home/dev-user/.cache/toucan/builder-refresh-66c8739-2026-09-09/timing')

def sha(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def main():
 binary=pathlib.Path(sys.argv[1]).resolve()
 out=ROOT/'baseline-preflight';out.mkdir(exist_ok=False)
 req=ROOT/'requests';req.mkdir(exist_ok=True)
 rows=[];workloads=[]
 def run(name,engine,request,iterations='3'):
  output=out/(name+'.output.json' if engine!='toucan-builder' else name+'.rs')
  log=out/(name+'.process.json');rss=out/(name+'.rss.txt')
  command=['/usr/bin/time','-v','-o',str(rss),str(binary),engine,str(request),iterations,str(output)]
  start=time.time();p=subprocess.run(command,capture_output=True,text=True,timeout=180)
  (out/(name+'.stdout')).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr)
  row={'name':name,'engine':engine,'request':str(request),'command':command,'exit_code':p.returncode,'elapsed_seconds':time.time()-start,'binary_sha256':sha(binary)}
  rows.append(row);(out/'processes.json').write_text(json.dumps(rows,indent=2)+'\n')
  if p.returncode: raise RuntimeError(f'{name}: {p.stderr}')
  data=json.loads(p.stdout);log.write_text(json.dumps(data,indent=2)+'\n')
  row.update(output=str(output),output_sha256=sha(output),process=str(log))
  return output
 for project in PROJECTS:
  request=req/(project+'.json');request.write_bytes((PRIOR/(project+'.reference.request.json')).read_bytes())
  run(project+'-builder','toucan-builder',request)
  report=run(project+'-report','toucan-report',request,'capture')
  normalized=json.loads(report.read_text());normalized.pop('timings',None)
  (out/(project+'.report.normalized.json')).write_text(json.dumps(normalized,sort_keys=True,indent=2)+'\n')
  workloads.append({'name':project+'-builder','engine':'toucan-builder','request':str(request)})
 adler=req/'zlib-adler32.json';adler.write_bytes(pathlib.Path('/tmp/toucan-optimization-drafts-2026-09-09/checked-sources/zlib-adler32.request.json').read_bytes())
 for project in PROJECTS+['zlib-adler32']:
  request=req/(project+'.json');checked=run(project+'-checked','checked',request)
  snapshot=json.loads(checked.read_text())
  source=req/(project+'.i')
  config=json.loads(request.read_text())
  cpp=['clang-18','-E','-P','-x','c','-std=c11','--target='+config['target'],'--sysroot='+config['sysroot']]
  for include in config['include_dirs']: cpp.extend(['-I',include])
  cpp.append(config['header'])
  preprocessed=subprocess.run(cpp,capture_output=True,text=True,timeout=60)
  (out/(project+'.cpp.stderr')).write_text(preprocessed.stderr)
  preprocessed.check_returncode();source.write_text(preprocessed.stdout)
  (out/(project+'.cpp.json')).write_text(json.dumps({'command':cpp,'output_sha256':sha(source),'version':subprocess.check_output(['clang-18','--version'],text=True)},indent=2)+'\n')
  parser_request=req/(project+'.parser.json');parser_request.write_text(json.dumps({'source':str(source),'flavor':'clang','standard':'c11','gnu_keywords':False,'extensions_msvc':False},indent=2)+'\n')
  parser_output=run(project+'-parser','parser',parser_request)
  parsed=json.loads(parser_output.read_text());assert parsed['outcome']=='ok'
  workloads.extend([{'name':project+'-checked','engine':'checked','request':str(request)},{'name':project+'-parser','engine':'parser','request':str(parser_request)}])
 (out/'processes.json').write_text(json.dumps(rows,indent=2)+'\n')
 inventory=json.loads((ROOT/'inputs.json').read_text())['inputs']
 for file in req.iterdir(): inventory[str(file)]=sha(file)
 for path,digest in inventory.items(): assert sha(path)==digest,path
 (ROOT/'workloads.json').write_text(json.dumps({'status':'passed','qualification':'Preflight only; elapsed samples were taken alongside other work and are not benchmark evidence.','binary':str(binary),'binary_sha256':sha(binary),'workloads':workloads,'inputs':inventory},indent=2)+'\n')
 print(json.dumps({'status':'passed','processes':len(rows),'workloads':len(workloads),'inputs':len(inventory)}))
if __name__=='__main__': main()
