#!/usr/bin/env python3
"""Retain proof or counterexamples for checked source-range changes; grants no equivalence."""
import argparse, hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def follow(value, path):
    for key in path:
        value = value[key]
    return value

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('preflight', type=Path)
    args = parser.parse_args()
    references = {row['name']: row for row in json.loads((ROOT / 'baseline-preflight/processes.json').read_text())}
    results = []
    for difference_file in sorted(args.preflight.glob('*-checked-0-candidate.differences.json')):
        name = difference_file.name.split('-0-candidate')[0]
        baseline_path = Path(references[name]['output'])
        candidate_path = args.preflight / (name + '-0-candidate.output')
        assert sha(baseline_path) == references[name]['output_sha256']
        baseline = json.loads(baseline_path.read_text())
        candidate = json.loads(candidate_path.read_text())
        source = baseline['source'].encode()
        differences = json.loads(difference_file.read_text())['differences']
        verified, unproven = [], []
        for difference in differences:
            path = difference['path']
            if difference['kind'] != 'value' or path[-2:] != ['range', 'end']:
                unproven.append(difference)
                continue
            old = follow(baseline, path[:-1])
            new = follow(candidate, path[:-1])
            suffix = source[new['end']:old['end']]
            valid = (old['start'] == new['start'] and
                     0 <= old['start'] <= new['end'] < old['end'] <= len(source) and
                     suffix.isspace())
            evidence = {'path': path, 'baseline': old, 'candidate': new,
                        'removed_bytes_hex': suffix.hex()}
            (verified if valid else unproven).append(evidence)
        report = {
            'name': name,
            'baseline_sha256': sha(baseline_path),
            'candidate_sha256': sha(candidate_path),
            'source_sha256': hashlib.sha256(source).hexdigest(),
            'source_bytes': len(source),
            'exact_source': baseline['source'] == candidate['source'],
            'all_non_end_values_exact': all(d['kind'] == 'value' and d['path'][-2:] == ['range', 'end'] for d in differences),
            'changed_range_count': len(verified),
            'unproven_changes': unproven,
            'changes': verified,
        }
        (args.preflight / (name + '.span-diagnosis.json')).write_text(json.dumps(report, indent=2) + '\n')
        results.append({key: value for key, value in report.items() if key != 'changes'})
        print(f'{name}: {len(verified)} proven whitespace trims; {len(unproven)} unproven changes')
    (args.preflight / 'checked-span-diagnosis-summary.json').write_text(json.dumps(results, indent=2) + '\n')

if __name__ == '__main__':
    main()
