//! Counts allocation requests while delegating every operation to std::alloc::System.
use serde::{Deserialize, Serialize};
use std::{
    alloc::{GlobalAlloc, Layout, System},
    path::PathBuf,
    sync::atomic::{AtomicUsize, Ordering},
};
static CALLS: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);
static REALLOCATIONS: AtomicUsize = AtomicUsize::new(0);
struct Counter;
// Every pointer/layout operation is forwarded unchanged to System. Counter
// updates neither allocate nor unwind. Requested bytes include realloc sizes;
// these counters do not describe live heap size or native libclang allocations.
unsafe impl GlobalAlloc for Counter {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(size, Ordering::Relaxed);
        REALLOCATIONS.fetch_add(1, Ordering::Relaxed);
        unsafe { System.realloc(ptr, layout, size) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}
#[global_allocator]
static ALLOCATOR: Counter = Counter;

#[derive(Clone, Copy, Debug, Serialize)]
struct Counts {
    requests: usize,
    requested_bytes: usize,
    reallocations: usize,
}
fn reset() {
    CALLS.store(0, Ordering::Relaxed);
    BYTES.store(0, Ordering::Relaxed);
    REALLOCATIONS.store(0, Ordering::Relaxed);
}
fn counts() -> Counts {
    Counts {
        requests: CALLS.load(Ordering::Relaxed),
        requested_bytes: BYTES.load(Ordering::Relaxed),
        reallocations: REALLOCATIONS.load(Ordering::Relaxed),
    }
}
#[derive(Deserialize)]
struct Request {
    header: PathBuf,
    target: String,
    include_dirs: Vec<PathBuf>,
    sysroot: PathBuf,
    allowlist: Vec<String>,
}
fn generate(request: &Request) -> Result<(String, [Counts; 3]), Box<dyn std::error::Error>> {
    reset();
    let mut config = toucan::Config::new(toucan::Target::parse(&request.target)?);
    config
        .preprocessor
        .include_dirs
        .clone_from(&request.include_dirs);
    let include = request.sysroot.join("usr/include");
    let multiarch = match request.target.as_str() {
        "x86_64-unknown-linux-gnu" => Some("x86_64-linux-gnu"),
        "aarch64-unknown-linux-gnu" => Some("aarch64-linux-gnu"),
        "x86_64-unknown-linux-musl" => Some("x86_64-linux-musl"),
        "aarch64-unknown-linux-musl" => Some("aarch64-linux-musl"),
        _ => None,
    };
    if let Some(multiarch) = multiarch {
        config
            .preprocessor
            .include_dirs
            .push(include.join(multiarch));
    }
    config.preprocessor.include_dirs.push(include);
    let setup = counts();
    reset();
    let compilation = toucan::parse_file(&request.header, &config)?;
    let parse = counts();
    reset();
    let (source, _) = compilation.bindings(&toucan::BindingOptions {
        allowlist: request.allowlist.clone(),
        ..Default::default()
    })?;
    let bindings = counts();
    Ok((source, [setup, parse, bindings]))
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    if args.len() != 4 {
        return Err("usage: allocations REQUEST ITERATIONS OUTPUT".into());
    }
    let request: Request = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    let iterations: usize = args[2].parse()?;
    if iterations < 3 {
        return Err("at least three iterations required".into());
    }
    let expected = generate(&request)?.0;
    let mut samples = Vec::with_capacity(iterations);
    for _ in 0..iterations {
        let (output, phases) = generate(&request)?;
        assert_eq!(
            output, expected,
            "allocation instrumentation changed output"
        );
        samples.push(phases);
    }
    std::fs::write(&args[3], &expected)?;
    println!(
        "{}",
        serde_json::json!({"phase_order":["setup","parse","bindings"],"samples":samples,"output_bytes":expected.len(),"unit_size":std::mem::size_of::<toucan::semantic::TranslationUnit>(),"profile_size":std::mem::size_of::<toucan::CompilerProfile>()})
    );
    Ok(())
}
