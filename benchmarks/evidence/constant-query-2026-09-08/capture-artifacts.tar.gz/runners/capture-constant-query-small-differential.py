from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path('/home/dev-user/.cache/toucan/constant-query-optimization');out=root/'query-small-differential';out.mkdir();os.sched_setaffinity(0,{30})
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
report={'status':'running','baseline_commit':'a215c7efc695a3ad330cb752962b2c9aa490b1fa','input_sha256':sha(root/'query-small-cases.json'),'runner_sha256':sha(__file__),'rows':[]}
for variant in ['baseline','candidate']:
 binary=root/(variant+'-driver-target/release/query-differential');target=root/(variant+'-queries');shutil.copy2(binary,target);command=[str(target),str(root/'query-small-cases.json')];start=time.monotonic()
 with (out/(variant+'.jsonl')).open('w')as stdout,(out/(variant+'.stderr')).open('w')as stderr:run=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=300)
 report['rows'].append({'variant':variant,'command':command,'returncode':run.returncode,'elapsed_seconds':time.monotonic()-start,'binary_sha256':sha(target),'driver_sha256':sha(root/(variant+'-driver-source/src/bin/query-differential.rs')),'output_sha256':sha(out/(variant+'.jsonl'))});assert run.returncode==0,variant
 print(variant,'completed',flush=True)
before=[json.loads(line)for line in (out/'baseline.jsonl').read_text().splitlines()];after=[json.loads(line)for line in (out/'candidate.jsonl').read_text().splitlines()];assert len(before)==len(after)
differences=[{'index':i,'baseline':a,'candidate':b}for i,(a,b)in enumerate(zip(before,after))if a!=b]
(out/'differences.json').write_text(json.dumps(differences,indent=2)+'\n');report.update(status='passed'if not differences else'failed',profile_case_pairs=len(before),parsed_case_pairs=sum('rows'in row for row in before),queries=sum(len(row.get('rows',[]))for row in before),query_entrypoints=['integer','arithmetic','vector'],differences=len(differences));(out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert not differences
