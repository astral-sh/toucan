from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path('/home/dev-user/.cache/toucan/constant-query-optimization');out=root/'preflight';out.mkdir();old=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark');env={**os.environ,'LIBCLANG_PATH':'/usr/lib/llvm-18/lib','CLANG_PATH':'/usr/bin/clang-18'};env.pop('LD_PRELOAD',None);os.sched_setaffinity(0,{30})
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
source=Path('/home/dev-user/.codex/worktrees/toucan-constant-query')
manifest={p.relative_to(source).as_posix():sha(p)for area in ['crates','benchmarks/inprocess']for p in sorted((source/area).rglob('*'))if p.is_file()};manifest.update({name:sha(source/name)for name in ['Cargo.toml','Cargo.lock']});diff=subprocess.check_output(['git','diff'],cwd=source);(root/'candidate-source.patch').write_bytes(diff);(root/'candidate-source.json').write_text(json.dumps({'baseline':'a215c7efc695a3ad330cb752962b2c9aa490b1fa','files':manifest,'diff_sha256':hashlib.sha256(diff).hexdigest()},indent=2)+'\n')
binaries={}
for label in ['baseline','candidate']:
 for name,suffix in [('benchmark',label+'-target/release/toucan-inprocess-benchmark'),('allocations',label+'-driver-target/release/toucan-inprocess-benchmark'),('report',label+'-driver-target/release/binding-report')]:
  target=root/(label+'-'+name);shutil.copy2(root/suffix,target);binaries[label+'-'+name]={'path':str(target),'sha256':sha(target)}
report={'status':'running','binaries':binaries,'environment':{k:env[k]for k in ['LIBCLANG_PATH','CLANG_PATH']},'runner_sha256':sha(__file__),'rows':[],'symbol_controls':[]}
for label in ['baseline','candidate']:
 run=subprocess.run(['nm','-C',binaries[label+'-benchmark']['path']],capture_output=True,text=True,check=True)
 selected=[line for line in run.stdout.splitlines()if 'analyze::literal_expression'in line or 'analyze::value_expression'in line];assert len(selected)==1,selected;assert ('literal_expression'if label=='baseline'else'value_expression')in selected[0];report['symbol_controls'].append({'variant':label,'symbols':selected})
for project in ['zlib','sqlite','zstd','libgit2']:
 request=old/'preflight'/(project+'.request.json');shutil.copy2(request,out/request.name)
 for label,engine in [('baseline','toucan'),('candidate','toucan'),('bindgen','bindgen')]:
  binary=binaries[('candidate'if label=='bindgen'else label)+'-benchmark']['path'];output=out/f'{project}-{label}.rs';command=[binary,engine,str(request),'3',str(output)];run=subprocess.run(command,capture_output=True,text=True,check=True,env=env);assert sha(output)==sha(old/'preflight'/f'{project}-{label}.rs');report['rows'].append({'project':project,'variant':label,'kind':'benchmark','command':command,'result':json.loads(run.stdout),'stderr':run.stderr,'output_sha256':sha(output)})
 values=[]
 for label in ['baseline','candidate']:
  output=out/f'{project}-{label}-report.rs';command=[binaries[label+'-report']['path'],str(request),str(output)];run=subprocess.run(command,capture_output=True,text=True,check=True,env=env);value=json.loads(run.stdout);assert sha(output)==sha(out/f'{project}-{label}.rs');values.append(value);(out/f'{project}-{label}-report.json').write_text(json.dumps(value,indent=2)+'\n');report['rows'].append({'project':project,'variant':label,'kind':'report','command':command,'stderr':run.stderr,'output_sha256':sha(output),'report_sha256':sha(out/f'{project}-{label}-report.json')})
 assert values[0]==values[1],project
 print(project,'outputs and complete reports match',flush=True)
report['status']='passed';(out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n');print('preflight passed',flush=True)
