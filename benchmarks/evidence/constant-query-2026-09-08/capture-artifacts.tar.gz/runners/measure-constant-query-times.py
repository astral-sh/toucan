from pathlib import Path
import hashlib,json,math,os,platform,random,statistics,subprocess,time
root=Path('/home/dev-user/.cache/toucan/constant-query-optimization');out=root/'timings';out.mkdir();preflight=json.loads((root/'preflight/evidence.json').read_text());inventory=json.loads((root/'header-inventory/evidence.json').read_text());assert preflight['status']==inventory['status']=='passed';binaries={label:preflight['binaries'][label+'-benchmark']for label in ['baseline','candidate']};available=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{30});env={**os.environ,**preflight['environment']};env.pop('LD_PRELOAD',None)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def capture(command):
 run=subprocess.run(command,capture_output=True,text=True,check=True);return {'command':command,'stdout':run.stdout,'stderr':run.stderr}
assert inventory['dependency_sha256']=={name:sha(name)for name in inventory['dependency_sha256']}
# Observe this executable's actual loaded library in a separate untimed control.
output=out/'loaded-library-control.rs';command=[binaries['candidate']['path'],'bindgen',str(root/'preflight/zlib.request.json'),'20',str(output)];child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env);libraries=set()
while child.poll()is None:
 try:
  for line in Path(f'/proc/{child.pid}/maps').read_text().splitlines():
   if '/libclang-'in line:libraries.add(line.split()[-1])
 except FileNotFoundError:pass
 time.sleep(0.01)
stdout,stderr=child.communicate();assert child.returncode==0;assert libraries=={inventory['libclang']['resolved_path']},libraries;assert sha(output)==sha(root/'preflight/zlib-bindgen.rs')
control={'command':command,'libraries':sorted(libraries),'stdout':stdout,'stderr':stderr,'output_sha256':sha(output)};(out/'loaded-library.json').write_text(json.dumps(control,indent=2)+'\n')
report={'status':'running','baseline_commit':'a215c7efc695a3ad330cb752962b2c9aa490b1fa','candidate_patch_sha256':sha(root/'candidate-source.patch'),'bindgen_version':'0.72.1','allocator':'std::alloc::System; no LD_PRELOAD','qualification':'Seven randomized interleaved project/engine rounds, five timed library calls after one discarded warmup per process. Includes configuration,preprocessing,analysis,Rust string generation; excludes process startup,request decoding,first libclang initialization. Shared host; CPU30 affinity, no exclusive frequency/memory-bandwidth/other-process control.','random_seed':202609082359,'affinity':[30],'available_affinity':available,'binaries':binaries,'runner_sha256':sha(__file__),'harness_sha256':sha(root/'baseline-source/benchmarks/inprocess/src/main.rs'),'input_inventory_sha256':sha(root/'header-inventory/evidence.json'),'libclang':inventory['libclang'],'loaded_library_control_sha256':sha(out/'loaded-library.json'),'dependency_sha256':inventory['dependency_sha256'],'cpu':capture(['lscpu','--json']),'rustc':capture(['rustc','-Vv']),'gcc':capture(['gcc','--version']),'clang':capture(['clang','--version']),'platform':platform.platform(),'environment':{key:env.get(key)for key in ['LIBCLANG_PATH','CLANG_PATH','LD_PRELOAD','LANG','LC_ALL','CPATH','C_INCLUDE_PATH','BINDGEN_EXTRA_CLANG_ARGS']},'requests':{project:{'path':str(root/'preflight'/(project+'.request.json')),'sha256':sha(root/'preflight'/(project+'.request.json')),'value':json.loads((root/'preflight'/(project+'.request.json')).read_text())}for project in ['zlib','sqlite','zstd','libgit2']},'rows':[]}
rng=random.Random(report['random_seed'])
def save():(out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for round_index in range(7):
  projects=list(report['requests']);rng.shuffle(projects)
  for project_index,project in enumerate(projects):
   variants=['baseline','candidate','bindgen'];rng.shuffle(variants)
   for variant_index,variant in enumerate(variants):
    binary=binaries['baseline'if variant=='baseline'else'candidate']['path'];engine='bindgen'if variant=='bindgen'else'toucan';output=out/f'{project}-{variant}-{round_index}.rs';command=[binary,engine,report['requests'][project]['path'],'5',str(output)];start=time.perf_counter_ns();run=subprocess.run(command,capture_output=True,text=True,env=env,check=True,timeout=120);wall=time.perf_counter_ns()-start;row=json.loads(run.stdout);assert len(row['samples_ms'])==5 and all(math.isfinite(v)and v>0 for v in row['samples_ms']);assert sha(output)==sha(root/'preflight'/f'{project}-{variant}.rs');assert variant!='bindgen'or'18.1.3'in row['libclang'];row.update(project=project,variant=variant,round=round_index,project_order=project_index,variant_order=variant_index,command=command,stderr=run.stderr,process_wall_ns=wall,output_sha256=sha(output));report['rows'].append(row)
   print(round_index,project,flush=True);save()
 summary={}
 for project in report['requests']:
  rows=[row for row in report['rows']if row['project']==project];medians={label:statistics.median(value for row in rows if row['variant']==label for value in row['samples_ms'])for label in ['baseline','candidate','bindgen']};pairs=[]
  for index in range(7):
   pair={row['variant']:statistics.median(row['samples_ms'])for row in rows if row['round']==index};pairs.append({'round':index,'median_ms':pair,'candidate_over_baseline':pair['candidate']/pair['baseline'],'bindgen_over_candidate':pair['bindgen']/pair['candidate']})
  ratios=[pair['candidate_over_baseline']for pair in pairs];boot=random.Random(202609090001);estimates=sorted(statistics.median(boot.choices(ratios,k=len(ratios)))for _ in range(10000));summary[project]={'median_ms':medians,'candidate_over_baseline':medians['candidate']/medians['baseline'],'bindgen_over_candidate':medians['bindgen']/medians['candidate'],'rounds':pairs,'paired_median_ratio':statistics.median(ratios),'paired_ratio_bootstrap_percentile_95':[estimates[249],estimates[9749]],'sample_range_ms':{label:[min(value for row in rows if row['variant']==label for value in row['samples_ms']),max(value for row in rows if row['variant']==label for value in row['samples_ms'])]for label in medians}}
 assert report['dependency_sha256']=={name:sha(name)for name in report['dependency_sha256']};assert sha(inventory['libclang']['path'])==inventory['libclang']['sha256'];assert all(sha(item['path'])==item['sha256']for item in binaries.values());report.update(status='passed',summary=summary);print(json.dumps(summary,indent=2))
except BaseException as error:report.update(status='failed',error=repr(error));raise
finally:save()
