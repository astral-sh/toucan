from pathlib import Path
import gzip,hashlib,io,json,re,tarfile,subprocess
root=Path('/home/dev-user/.cache/toucan/constant-query-optimization');source=Path('/home/dev-user/.codex/worktrees/toucan-constant-query');out=source/'benchmarks/evidence/constant-query-2026-09-08';out.mkdir(parents=True)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def packed(path,data):path.write_bytes(gzip.compress(data,compresslevel=9,mtime=0))
reports={}
for label,relative in {'timings':'timings/evidence.json','allocations':'allocations/evidence.json','queries':'query-differential/evidence.json','portable-queries':'query-small-differential/evidence.json','outputs':'preflight/evidence.json','header-inputs':'header-inventory/evidence.json','loaded-library':'timings/loaded-library.json','baseline-source':'baseline-source.json','candidate-source':'candidate-source.json','baseline-profile':'profile-baseline/evidence.json','candidate-profile':'profile-candidate/evidence.json','asan':'asan/evidence.json','asan-source':'asan/source.json'}.items():
 data=(root/relative).read_bytes();reports[label]=json.loads(data);packed(out/(label+'.json.gz'),data)
for name in ['timings','allocations','queries','portable-queries','outputs','header-inputs','baseline-profile','candidate-profile','asan']:assert reports[name]['status']=='passed',name
assert reports['asan']['source_unchanged'];assert not reports['asan']['artifacts']
verification={'source_files':{},'binaries':{},'headers':{},'omitted_patch_sha256':sha('/tmp/toucan-omitted-conditional.patch'),'published_performance_patch_sha256':sha('/tmp/toucan-a7838ce-performance.patch')}
for variant,path in [('baseline',root/'baseline-source'),('candidate',source)]:
 manifest=reports[variant+'-source']['files'];assert all(sha(path/name)==digest for name,digest in manifest.items());verification['source_files'][variant]={'checked':len(manifest),'changed':0}
for key,item in reports['outputs']['binaries'].items():assert sha(item['path'])==item['sha256'];verification['binaries'][key]=item
for name,digest in reports['timings']['dependency_sha256'].items():assert sha(name)==digest;verification['headers'][name]=digest
library=reports['timings']['libclang'];assert sha(library['path'])==library['sha256'];verification['libclang']=library
seed=(source/'fuzz/seeds/bindings/constant-value-queries.h').read_bytes();settings=set();seed_inputs=[]
with tarfile.open(root/'asan/initial-corpus.tar.gz')as tar:
 for member in tar:
  data=tar.extractfile(member).read()
  if data.startswith(seed):
   total=sum(data);settings.add((total%11,(total>>8)&7));seed_inputs.append({'name':member.name,'sha256':hashlib.sha256(data).hexdigest(),'profile':total%11,'mode':(total>>8)&7})
assert settings=={(p,m)for p in range(11)for m in range(8)}
(out/'seed-coverage.json').write_text(json.dumps({'status':'passed','seed_sha256':hashlib.sha256(seed).hexdigest(),'settings':88,'inputs':seed_inputs},indent=2)+'\n')
packed(out/'freeze-verification.json.gz',(json.dumps(verification,indent=2)+'\n').encode())
(out/'timing-source.patch').write_bytes((root/'candidate-source.patch').read_bytes())

artifacts={}
for area in ['preflight','allocations','timings','query-differential','query-small-differential','header-inventory','profile-baseline','profile-candidate']:
 for path in sorted((root/area).rglob('*')):
  if path.is_file():artifacts[path.relative_to(root).as_posix()]=path
for name in ['query-cases.json','query-small-cases.json']:artifacts[name]=root/name
for variant in ['baseline','candidate']:
 for path in sorted((root/(variant+'-driver-source')).rglob('*')):
  if path.is_file():artifacts['drivers/'+variant+'/'+path.relative_to(root/(variant+'-driver-source')).as_posix()]=path
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:artifacts['drivers/inprocess/'+name]=root/'baseline-source/benchmarks/inprocess'/name
for path in Path('/tmp').glob('*constant-query*.py'):artifacts['runners/'+path.name]=path
for path in Path('/tmp').glob('toucan-constant-query-*.log'):artifacts['logs/'+path.name]=path
for name in ['evidence.json','source.json','build.log','fuzz.log','initial-corpus.tar.gz','c.dict']:artifacts['asan/'+name]=root/'asan'/name
artifacts['asan/run_fuzz_campaign.py']=source/'scripts/run_fuzz_campaign.py'
artifacts['asan/bindings.rs']=source/'fuzz/fuzz_targets/bindings.rs'
artifacts['profile-tools/package.json']=Path('/home/dev-user/.cache/toucan/profiling-tools/package.json')
# Preserve the initial a7838ce investigation separately from matched a215c7e profiles.
old=Path('/home/dev-user/.cache/toucan/libgit2-profile-a7838ce')
for name in ['evidence.json','callgrind.out','self.txt','inclusive.txt','calling.txt','phase-times.json','macro-queries.json','clone-expressions.json','stdout.log','stderr.log']:artifacts['initial-a7838ce-profile/'+name]=old/name
for path in sorted((old/'phase-source').rglob('*')):
 if path.is_file():artifacts['initial-a7838ce-profile/driver/'+path.relative_to(old/'phase-source').as_posix()]=path
for name in ['profile-a7838ce-libgit2.py','capture-libgit2-phase-times.py','create-libgit2-macro-probe.py']:artifacts['initial-a7838ce-profile/'+name]=Path('/tmp')/name
archive=io.BytesIO()
with tarfile.open(fileobj=archive,mode='w')as tar:
 for name,path in sorted(artifacts.items()):
  data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
packed(out/'capture-artifacts.tar.gz',archive.getvalue())
(out/'capture-artifacts.json').write_text(json.dumps({name:{'sha256':sha(path),'bytes':path.stat().st_size}for name,path in sorted(artifacts.items())},indent=2)+'\n')
workspace=Path('/tmp/toucan-constant-query-workspace.log').read_text();counts=[tuple(map(int,row))for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',workspace)]
profiles={}
for variant in ['baseline','candidate']:
 text=(root/('profile-'+variant)/'calling.txt').read_text();total=int(re.search(r'([0-9,]+) \(100\.0%\)  PROGRAM TOTALS',text).group(1).replace(',',''));clones=sum(int(m.group(1).replace(',',''))for m in re.finditer(r'>[^\n]+TranslationUnit as core::clone::Clone[^\n]+\(([0-9,]+)x\)',text));profiles[variant]={'instructions':total,'unit_clone_calls':clones,'generations':4}
summary={'status':'passed','baseline_commit':'a215c7efc695a3ad330cb752962b2c9aa490b1fa','timing_implementation_patch_sha256':sha(root/'candidate-source.patch'),'scope':'Bounded value-expression proof using referenced IntegerValue snapshots; all existing source/public-metadata/parser/semantic validation preserved; type-dependent or unknown expressions retain full unit fallback.','workspace':dict(zip(['passed','failed','ignored'],map(sum,zip(*counts)))),'native_enum_tests':6,'query_comparisons':sum(reports[k]['queries']for k in ['queries','portable-queries'])*3,'queries':sum(reports[k]['queries']for k in ['queries','portable-queries']),'profile_mode_settings':88,'query_profile_case_pairs':sum(reports[k]['profile_case_pairs']for k in ['queries','portable-queries']),'query_parsed_case_pairs':sum(reports[k]['parsed_case_pairs']for k in ['queries','portable-queries']),'query_result_differences':0,'output_projects':4,'complete_binding_reports_equal_except_timings':True,'cross_generator_api_equality_claimed':False,'timed_calls':sum(len(row['samples_ms'])for row in reports['timings']['rows']),'timing_processes':len(reports['timings']['rows']),'instrumented_generations':sum(len(row['samples'])for row in reports['allocations']['rows']),'unique_header_inputs':len(reports['timings']['dependency_sha256']),'timings':reports['timings']['summary'],'allocations':reports['allocations']['summary'],'profiles':profiles,'asan':{key:reports['asan'][key]for key in ['elapsed_seconds','statistics','source_unchanged','artifacts','sanitizer_options']},'qualifications':[reports['timings']['qualification'],reports['allocations']['method'],'Callgrind instruction counts are distinct from native elapsed-time samples. Shared host. Original a7838ce profiling is archived separately; all optimization comparisons use matched a215c7e source.','ASan was configured for60seconds and completed in80.88seconds including startup/initial corpus work; this is a bounded smoke run, not broad input-space coverage.'],'artifacts_sha256':{path.name:sha(path)for path in sorted(out.iterdir())if path.is_file()}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'directory':str(out),'members':len(artifacts),'archive_bytes':(out/'capture-artifacts.tar.gz').stat().st_size,'summary':{key:summary[key]for key in ['workspace','query_comparisons','profiles','asan']}},indent=2))
