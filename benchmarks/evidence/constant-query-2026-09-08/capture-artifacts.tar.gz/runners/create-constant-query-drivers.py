from pathlib import Path
import shutil
root=Path('/home/dev-user/.cache/toucan/constant-query-optimization')
for variant,source in [('baseline',root/'baseline-source'),('candidate',Path('/home/dev-user/.codex/worktrees/toucan-constant-query'))]:
 out=root/(variant+'-driver-source');(out/'src/bin').mkdir(parents=True,exist_ok=True)
 manifest=(source/'benchmarks/inprocess/Cargo.toml').read_text().replace('../../crates/toucan',str(source/'crates/toucan')).replace('unsafe_code = "forbid"','')
 (out/'Cargo.toml').write_text(manifest)
 shutil.copy2(source/'benchmarks/inprocess/Cargo.lock',out/'Cargo.lock')
 shutil.copy2('/tmp/constant-query-differential.rs',out/'src/bin/query-differential.rs')
 shutil.copy2('/home/dev-user/.cache/toucan/published-a7838ce-benchmark/candidate-allocation-source/src/main.rs',out/'src/main.rs')
