from pathlib import Path
import hashlib,json,os,random,statistics,subprocess
root=Path('/home/dev-user/.cache/toucan/constant-query-optimization');out=root/'allocations';out.mkdir();preflight=json.loads((root/'preflight/evidence.json').read_text());assert preflight['status']=='passed';os.sched_setaffinity(0,{30})
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
report={'status':'running','baseline_commit':'a215c7efc695a3ad330cb752962b2c9aa490b1fa','candidate_patch_sha256':sha(root/'candidate-source.patch'),'runner_sha256':sha(__file__),'method':'System-backed counter,three randomized process pairs per project,one discarded warmup and five measured generations. Allocation requests and sum of requested bytes (including realloc full sizes),not live heap or peak RSS. Instrumented runs excluded from latency results.','binaries':{label:preflight['binaries'][label+'-allocations']for label in ['baseline','candidate']},'phase_order':['setup','parse','bindings'],'rows':[]}
rng=random.Random(202609082355)
for index in range(3):
 projects=['zlib','sqlite','zstd','libgit2'];rng.shuffle(projects)
 for project in projects:
  labels=['baseline','candidate'];rng.shuffle(labels)
  for label in labels:
   binary=report['binaries'][label]['path'];request=root/'preflight'/(project+'.request.json');output=out/f'{project}-{label}-{index}.rs';command=[binary,str(request),'5',str(output)];run=subprocess.run(command,capture_output=True,text=True,check=True,timeout=90);row=json.loads(run.stdout);assert sha(output)==sha(root/'preflight'/f'{project}-{label}.rs');row.update(project=project,variant=label,round=index,command=command,stderr=run.stderr,output_sha256=sha(output));report['rows'].append(row)
summary={}
for project in ['zlib','sqlite','zstd','libgit2']:
 phases={}
 for index,phase in enumerate(report['phase_order']):
  counts={}
  for label in report['binaries']:
   samples=[sample[index]for row in report['rows']if row['project']==project and row['variant']==label for sample in row['samples']];counts[label]={key:{'median':statistics.median(s[key]for s in samples),'minimum':min(s[key]for s in samples),'maximum':max(s[key]for s in samples)}for key in ['requests','requested_bytes','reallocations']}
  phases[phase]={'variants':counts,'delta':{key:counts['candidate'][key]['median']-counts['baseline'][key]['median']for key in counts['baseline']}}
 summary[project]=phases
assert all(sha(item['path'])==item['sha256']for item in report['binaries'].values());report.update(status='passed',summary=summary);(out/'evidence.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary,indent=2))
