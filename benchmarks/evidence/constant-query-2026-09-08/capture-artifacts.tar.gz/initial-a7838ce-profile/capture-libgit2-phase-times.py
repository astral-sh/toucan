from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
root=Path('/home/dev-user/.cache/toucan/libgit2-profile-a7838ce');binary=root/'phase-target/release/toucan-inprocess-benchmark';frozen=root/'phase-benchmark';shutil.copy2(binary,frozen)
request=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark/preflight/libgit2.request.json');os.sched_setaffinity(0,{30})
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
report=dict(status='running',source_commit='a7838ce9d741c8659e428c8a3b2e7f33897bf6fa',binary_sha256=sha(frozen),driver_sha256=sha(root/'phase-source/src/main.rs'),runner_sha256=sha(__file__),affinity=[30],method='Uninstrumented System allocator, three processes with a discarded warmup and ten phase-timed generations each. Does not time compilation/output drops after generate returns. Shared host, diagnostic phase breakdown only.',rows=[])
for index in range(3):
 output=root/f'phase-output-{index}.rs';command=[str(frozen),str(request),'10',str(output)];run=subprocess.run(command,check=True,capture_output=True,text=True,timeout=90);row=json.loads(run.stdout);row.update(command=command,stderr=run.stderr,output_sha256=sha(output));assert row['output_sha256']=='505d0d94f08f7df439571edeea1ffdad21a32578a3abd4d9a7da4004418a22bc';report['rows'].append(row)
report.update(status='passed',median_ms={phase:statistics.median(sample[index]for row in report['rows']for sample in row['samples'])for index,phase in enumerate(['setup','parse','bindings'])});(root/'phase-times.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['median_ms'],indent=2))
