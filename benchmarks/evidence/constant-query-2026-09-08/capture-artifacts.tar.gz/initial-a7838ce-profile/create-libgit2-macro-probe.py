from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/libgit2-profile-a7838ce')
original=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark/candidate-allocation-source/src/main.rs').read_text()
prefix=original[:original.index('fn generate(')]
start=original.index('    let mut config =');end=original.index('    let setup = counts();')
configure=original[start:end]
source=prefix+'''fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    let request: Request = serde_json::from_slice(&std::fs::read(&args[1])?)?;
'''+configure+'''
    let compilation = toucan::parse_file(&request.header, &config)?;
    let options = toucan::BindingOptions {allowlist: request.allowlist, ..Default::default()};
    let (output, report) = compilation.bindings(&options)?;
    std::fs::write(&args[2], output)?;
    let rows = toucan::semantic::with_parser_stack(|| {
        let mut rows = Vec::new();
        for (name, definition) in &compilation.preprocessed().macros {
            if !options.includes(name) || definition.parameters.is_some() {continue;}
            let Ok(Some(expression)) = compilation.preprocessed().expand_object_macro(name) else {continue;};
            if expression.trim().is_empty() || expression.trim() == name && compilation.unit().constants.contains_key(name) {continue;}
            // This diagnostic inventory skips the simple string replacements in
            // the pinned libgit2 header; complete facade output is checked above.
            if expression.trim_start().starts_with('"') {continue;}
            reset();
            let start = std::time::Instant::now();
            let integer = toucan::semantic::evaluate_integer(compilation.unit(), &expression);
            let integer_elapsed_ns = start.elapsed().as_nanos();
            let integer_counts = counts();
            let arithmetic = if integer.is_err() {
                reset();
                let start = std::time::Instant::now();
                let value = toucan::semantic::evaluate_arithmetic(compilation.unit(), &expression);
                let elapsed_ns = start.elapsed().as_nanos();
                let counts = counts();
                Some(serde_json::json!({"result":format!("{value:?}"),"elapsed_ns":elapsed_ns,"counts":counts}))
            } else {None};
            rows.push(serde_json::json!({"name":name,"expression":expression,"integer_result":format!("{integer:?}"),"integer_elapsed_ns":integer_elapsed_ns,"integer_counts":integer_counts,"arithmetic":arithmetic}));
        }
        rows
    })?;
    println!("{}", serde_json::json!({"method":"Separate diagnostic query inventory; System allocation counter; timings include counter overhead and are excluded from published latency measurements","rows":rows,"report":report}));
    Ok(())
}
'''
(root/'phase-source/src/bin').mkdir(exist_ok=True)
(root/'phase-source/src/bin/macro-queries.rs').write_text(source)
