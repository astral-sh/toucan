from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/dev-user/.cache/toucan/libgit2-profile-a7838ce');root.mkdir(exist_ok=True)
benchmark=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark/candidate-benchmark')
request=Path('/home/dev-user/.cache/toucan/published-a7838ce-benchmark/preflight/libgit2.request.json')
valgrind=Path('/home/dev-user/.cache/toucan/profiling-tools/valgrind/usr/bin/valgrind')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
expected='505d0d94f08f7df439571edeea1ffdad21a32578a3abd4d9a7da4004418a22bc'
env={**os.environ,'VALGRIND_LIB':'/home/dev-user/.cache/toucan/profiling-tools/valgrind/usr/libexec/valgrind'};env.pop('LD_PRELOAD',None);os.sched_setaffinity(0,{30})
command=[str(valgrind),'--tool=callgrind','--cache-sim=no','--branch-sim=no','--collect-jumps=yes','--callgrind-out-file='+str(root/'callgrind.out'),str(benchmark),'toucan',str(request),'3',str(root/'output.rs')]
report=dict(status='running',source_commit='a7838ce9d741c8659e428c8a3b2e7f33897bf6fa',affinity=[30],method='Callgrind instruction counts on the exact uninstrumented release executable; includes startup, one warmup and three generated-output library calls. Counts identify executed instruction and call hotspots; elapsed time under instrumentation is not a generation-latency benchmark.',command=command,binary_sha256=sha(benchmark),request_sha256=sha(request),runner_sha256=sha(__file__))
path=root/'evidence.json';path.write_text(json.dumps(report,indent=2)+'\n');start=time.monotonic()
with (root/'stdout.log').open('w') as stdout,(root/'stderr.log').open('w') as stderr:
 run=subprocess.run(command,env=env,stdout=stdout,stderr=stderr,timeout=300)
report.update(returncode=run.returncode,elapsed_seconds=time.monotonic()-start)
if run.returncode==0:
 report['output_sha256']=sha(root/'output.rs');assert report['output_sha256']==expected
 report.update(status='passed',profile_sha256=sha(root/'callgrind.out'))
else:report['status']='failed'
path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
