use serde::Deserialize;
use std::{path::PathBuf,time::Instant};
#[derive(Deserialize)]
struct Request {
    header: PathBuf,
    target: String,
    include_dirs: Vec<PathBuf>,
    sysroot: PathBuf,
    allowlist: Vec<String>,
}
fn generate(request: &Request) -> Result<(String, [f64; 3]), Box<dyn std::error::Error>> {
    let start = Instant::now();
    let mut config = toucan::Config::new(toucan::Target::parse(&request.target)?);
    config
        .preprocessor
        .include_dirs
        .clone_from(&request.include_dirs);
    let include = request.sysroot.join("usr/include");
    let multiarch = match request.target.as_str() {
        "x86_64-unknown-linux-gnu" => Some("x86_64-linux-gnu"),
        "aarch64-unknown-linux-gnu" => Some("aarch64-linux-gnu"),
        "x86_64-unknown-linux-musl" => Some("x86_64-linux-musl"),
        "aarch64-unknown-linux-musl" => Some("aarch64-linux-musl"),
        _ => None,
    };
    if let Some(multiarch) = multiarch {
        config
            .preprocessor
            .include_dirs
            .push(include.join(multiarch));
    }
    config.preprocessor.include_dirs.push(include);
    let setup = start.elapsed().as_secs_f64() * 1_000.0;
    let start = Instant::now();
    let compilation = toucan::parse_file(&request.header, &config)?;
    let parse = start.elapsed().as_secs_f64() * 1_000.0;
    let start = Instant::now();
    let (source, _) = compilation.bindings(&toucan::BindingOptions {
        allowlist: request.allowlist.clone(),
        ..Default::default()
    })?;
    let bindings = start.elapsed().as_secs_f64() * 1_000.0;
    Ok((source, [setup, parse, bindings]))
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    if args.len() != 4 {
        return Err("usage: phases REQUEST ITERATIONS OUTPUT".into());
    }
    let request: Request = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    let iterations: usize = args[2].parse()?;
    if iterations < 3 {
        return Err("at least three iterations required".into());
    }
    let expected = generate(&request)?.0;
    let mut samples = Vec::with_capacity(iterations);
    for _ in 0..iterations {
        let (output, phases) = generate(&request)?;
        assert_eq!(
            output, expected,
            "phase instrumentation changed output"
        );
        samples.push(phases);
    }
    std::fs::write(&args[3], &expected)?;
    println!(
        "{}",
        serde_json::json!({"phase_order":["setup","parse","bindings"],"samples":samples,"output_bytes":expected.len(),"unit_size":std::mem::size_of::<toucan::semantic::TranslationUnit>(),"profile_size":std::mem::size_of::<toucan::CompilerProfile>()})
    );
    Ok(())
}
