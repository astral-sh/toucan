from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path('/home/dev-user/code/oss/toucan')
old = Path('/home/dev-user/.cache/toucan/compiler-version-probes')
out = Path('/home/dev-user/.cache/toucan/enumerator-root-projects')
out.mkdir(exist_ok=True)
binary = root / 'target/release/toucan'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(command):
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True, text=True, timeout=300)
    return dict(command=command, exit_code=result.returncode, stdout=result.stdout,
                stderr=result.stderr, seconds=time.monotonic() - start)

report = dict(binary_sha256=sha(binary), headers=[], musl=[])

for original in json.loads((old / 'headers.json').read_text()):
    command = [str(binary)] + [value.replace(str(old), str(out)) for value in original['command'][1:]]
    row = run(command)
    (out / (original['name'] + '.rs')).write_text(row['stdout'])
    row['name'] = original['name']
    row['source_sha256'] = sha(Path(command[2]))
    row['output_sha256'] = hashlib.sha256(row['stdout'].encode()).hexdigest()
    row['unchanged_output'] = row['output_sha256'] == original['stdout_sha256']
    report['headers'].append(row)
    assert row['exit_code'] == 0 and row['unchanged_output'], row
    print('header', row['name'], 'passed', flush=True)

for original in json.loads((old / 'musl.json').read_text()):
    command = [str(binary)] + [value.replace(str(old), str(out)) for value in original['command'][1:]]
    row = run(command)
    row.update(name=original['name'], source_sha256=sha(Path(command[2])))
    row['output_sha256'] = sha(Path(command[command.index('-o') + 1]))
    row['unchanged_output'] = row['output_sha256'] == original['sha256']
    report['musl'].append(row)
    assert row['exit_code'] == 0 and row['unchanged_output'], row
    print('musl', row['name'], 'passed', flush=True)

report['status'] = 'passed'
(out / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')
