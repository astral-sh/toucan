from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
root=Path('/home/dev-user/code/oss/toucan');cache=Path('/home/dev-user/.cache/toucan/macro-definition-probes');out=root/'corpus/evidence/macro-definitions-2026-09-08';out.mkdir(exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
projects=json.loads((cache/'projects.json').read_text());replay=json.loads((cache/'replay.json').read_text())
assert projects['status']=='passed' and replay['exit_code']==0
assert len(projects['comparisons'])==9 and all(r['all_outputs_equal'] and r['allocation_deltas']['off']=={'allocation_calls':0,'allocation_bytes':0} for r in projects['comparisons'])
files={}
for name in ['check','tests','preprocessor','clippy','fuzz-clippy','rustdoc','release','projects','python','replay-80']:
 path=Path(f'/tmp/toucan-macro-definitions-{name}.log');files['logs/'+path.name]=path.read_bytes()
 assert b'test result: FAILED' not in files['logs/'+path.name] and b'error:' not in files['logs/'+path.name],name
for name in ['baseline-build.json','projects.rs','projects.json','replay.json','preprocess-replay.rs']:
 files[name]=(cache/name).read_bytes()
for path in cache.glob('*-baseline.*'):
 if path.suffix in ['.i','.unit','.rs']:files['outputs/'+path.name]=path.read_bytes()
for path in cache.glob('*-history.definitions'):files['outputs/'+path.name]=path.read_bytes()
for path in (cache/'preprocess-inputs-80').iterdir():files['preprocess-inputs/'+path.name]=path.read_bytes()
for name in ['toucan-macro-definition-projects.py','toucan-macro-definition-replay.py','package-toucan-macro-definitions.py']:files['drivers/'+name]=Path('/tmp',name).read_bytes()
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
source={name:sha((root/name).read_bytes()) for name in sorted(set(changed)) if name.startswith(('crates/','fuzz/fuzz_targets/','fuzz/seeds/','scripts/'))}
for name in source:files['source/'+name]=(root/name).read_bytes()
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())}
with (out/'evidence.tar.gz').open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
(out/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',Path('/tmp/toucan-macro-definitions-preprocessor.log').read_text())
summary={'schema_version':1,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':source,'preprocessor_tests':{'passed':sum(int(a) for a,b,c in rows),'failed':sum(int(b) for a,b,c in rows),'ignored':sum(int(c) for a,b,c in rows)},'new_focused_tests':4,'python_tests':5,'workspace_and_fuzz_clippy':True,'public_rustdoc':True,'preprocessor_selector_version':4,'preprocessor_policy_settings':80,'seed_replay_inputs':720,'real_header_routes':9,'real_project_runs':36,'preprocessed_and_semantic_outputs_equal':True,'rust_binding_outputs_equal':8,'default_allocation_deltas':{'calls':0,'requested_bytes':0},'allocation_comparisons':projects['comparisons'],'aws_lc_history_entries':10254,'archive_sha256':sha((out/'evidence.tar.gz').read_bytes()),'limitations':['Native host is Linux x86-64; these project routes use GNU/Clang target profiles and the recorded include paths.','Allocation counters measure allocation traffic and requested bytes, not live heap or RSS; one run per project/mode, no timing claim.','The source token/byte budgets and optional conservative history data budget are separate checks, not process-memory caps.','This layer captures ordered written definitions; it does not yet change bindgen-compatible macro evaluation or implement push_macro/pop_macro.','The archived replay is deterministic input execution, not a sanitizer mutation campaign.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'tests':summary['preprocessor_tests'],'replay_inputs':720,'archive_bytes':(out/'evidence.tar.gz').stat().st_size,'archive_files':len(files)},indent=2))
