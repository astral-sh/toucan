from pathlib import Path
import hashlib,importlib.util,json,subprocess
root=Path('/home/dev-user/code/oss/toucan');out=Path('/home/dev-user/.cache/toucan/macro-definition-probes')
pp=(root/'fuzz/fuzz_targets/preprocess.rs').read_text().removeprefix('#![no_main]\n').replace('use libfuzzer_sys::fuzz_target;\n','').replace('fuzz_target!(|bytes: &[u8]| {','fn check_input(bytes: &[u8]) {')
assert pp.endswith('});\n');pp=pp[:-4]+'}\n'
pp+='fn main(){let mut count=0;for path in std::fs::read_dir(std::env::args().nth(1).unwrap()).unwrap(){let path=path.unwrap().path();let data=std::fs::read(path).unwrap();check_input(&data);count+=1;}println!("preprocessor history/origin inputs={count}");}\n'
spec=importlib.util.spec_from_file_location('campaign',root/'scripts/run_fuzz_campaign.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
corpus=out/'preprocess-inputs-80';corpus.mkdir(exist_ok=True)
for path in (root/'fuzz/seeds/preprocess').iterdir():
 for data in campaign.seed_preprocessor_policies(path.read_bytes()):
  (corpus/hashlib.sha256(data).hexdigest()).write_bytes(data)
source=out/'preprocess-replay.rs';source.write_text(pp);binary=out/'preprocess-replay'
lib=max((root/'target/release/deps').glob('libtoucan-*.rlib'),key=lambda path:path.stat().st_mtime_ns)
build=['rustc','--edition=2024','-O',str(source),'-L',f'dependency={lib.parent}','--extern',f'toucan={lib}','-o',str(binary)]
subprocess.run(build,check=True)
command=[str(binary),str(corpus)];run=subprocess.run(command,text=True,capture_output=True)
report={'build':build,'command':command,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
(out/'replay.json').write_text(json.dumps(report,indent=2)+'\n');print(run.stdout,run.stderr);assert run.returncode==0
