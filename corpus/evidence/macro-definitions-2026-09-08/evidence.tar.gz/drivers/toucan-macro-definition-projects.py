from pathlib import Path
import gzip,hashlib,json,subprocess,time
root=Path('/home/dev-user/code/oss/toucan');out=Path('/home/dev-user/.cache/toucan/macro-definition-probes')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
lib=max((root/'target/release/deps').glob('libtoucan-*.rlib'),key=lambda path:path.stat().st_mtime_ns)
build=['rustc','--edition=2024','-O','--cfg','candidate','--cfg','history',str(out/'projects.rs'),'--extern','toucan='+str(lib),'-L','dependency='+str(lib.parent),'-o',str(out/'projects-candidate')]
subprocess.run(build,check=True)
previous=json.loads(gzip.decompress((root/'corpus/evidence/accessed-header-paths-2026-09-08.json.gz').read_bytes()))
rows={}
for row in previous['timings']['rows']:
 if row['build']=='candidate' and row['iteration']==0:rows[row['name']]=row
report={'build':build,'candidate_sha256':sha(out/'projects-candidate'),'library_sha256':sha(lib),'rows':[],'comparisons':[]}
for name,row in sorted(rows.items()):
 args=row['command'][4:]
 results={}
 for mode in ['baseline','off','history','combined']:
  prefix=out/(name+'-'+mode)
  binary=out/('projects-baseline' if mode=='baseline' else 'projects-candidate')
  command=[str(binary),args[0],'off' if mode=='baseline' else mode,args[2],str(prefix),*args[4:]]
  start=time.monotonic();p=subprocess.run(command,capture_output=True,text=True,timeout=120)
  item={'name':name,'mode':mode,'command':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'elapsed_seconds':time.monotonic()-start}
  report['rows'].append(item)
  assert p.returncode==0,item
  counts=p.stdout.splitlines()[0].split();item.update(allocation_calls=int(counts[1]),allocation_bytes=int(counts[2]))
  item['outputs']={extension:sha(Path(str(prefix)+extension)) for extension in ['.i','.unit','.rs','.definitions'] if Path(str(prefix)+extension).exists()}
  results[mode]=item
 expected={k:v for k,v in results['baseline']['outputs'].items() if k!='.definitions'}
 for mode,item in results.items():assert {k:v for k,v in item['outputs'].items() if k!='.definitions'}==expected,(name,mode)
 delta={mode:{key:results[mode][key]-results['baseline'][key] for key in ['allocation_calls','allocation_bytes']} for mode in ['off','history','combined']}
 report['comparisons'].append({'name':name,'all_outputs_equal':True,'allocation_deltas':delta})
 print(name,'equal',delta,flush=True)
report['status']='passed';(out/'projects.json').write_text(json.dumps(report,indent=2)+'\n')
