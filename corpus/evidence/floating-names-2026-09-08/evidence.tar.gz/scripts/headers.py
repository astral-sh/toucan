import hashlib,json,subprocess
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/floating-name-conformance');out=root/'headers';out.mkdir(exist_ok=True)
old=Path('/home/dev-user/.cache/toucan/compiler-version-probes')
binary=root/'final-frozen/toucan';rows=[]
for original in json.loads((old/'headers.json').read_text()):
 command=[str(binary)]+[value.replace(str(old),str(out)) for value in original['command'][1:]]
 p=subprocess.run(command,text=True,capture_output=True,timeout=120)
 output_sha=hashlib.sha256(p.stdout.encode()).hexdigest()
 row={'name':original['name'],'command':command,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'source_sha256':hashlib.sha256(Path(command[2]).read_bytes()).hexdigest(),'output_sha256':output_sha,'unchanged':output_sha==original['stdout_sha256']}
 rows.append(row)
 print(row['name'],row['status'],'unchanged',row['unchanged'],flush=True)
 assert p.returncode==0 and row['unchanged'],row
(root/'headers.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
# The real glibc branch selected by a caller-supplied old GNU version also fails
# in native GCC; keep the untouched system header and exact overrides.
source='#define _GNU_SOURCE\n#include <stdlib.h>\n'
path=out/'old-version.c';path.write_text(source)
rows=[]
for compiler in ['gcc','clang']:
 for old_version in [False,True]:
  flags=['-U__GNUC__','-U__GNUC_MINOR__','-U__GNUC_PATCHLEVEL__','-D__GNUC__=4','-D__GNUC_MINOR__=2','-D__GNUC_PATCHLEVEL__=1'] if old_version else []
  native=[compiler,'-std=gnu11','-fsyntax-only',str(path)]+flags
  p=subprocess.run(native,text=True,capture_output=True,timeout=60)
  command=[str(binary),'inspect',str(path),'--compiler',compiler,'--sysroot','/','-I','/usr/lib/gcc/x86_64-linux-gnu/13/include']
  if old_version:
   command+=['-D','__GNUC__=4','-D','__GNUC_MINOR__=2','-D','__GNUC_PATCHLEVEL__=1']
  q=subprocess.run(command,text=True,capture_output=True,timeout=60)
  rows.append({'compiler':compiler,'old_version':old_version,'native_command':native,'native_status':p.returncode,'native_stderr':p.stderr,'command':command,'status':q.returncode,'stderr':q.stderr,'match':(p.returncode==0)==(q.returncode==0)})
  print(compiler,'oldversion',old_version,'native',p.returncode,'candidate',q.returncode,flush=True)
  assert (p.returncode==0)==(q.returncode==0),rows[-1]
(root/'glibc-version-overrides.json').write_text(json.dumps(rows,indent=2)+'\n')
