import concurrent.futures,json,subprocess
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/floating-name-conformance');root.mkdir(exist_ok=True)
names=['_Float16','_Float32','_Float64','_Float32x','_Float64x','_Float128','__float128']
modes=['c90','gnu90','c99','gnu99','c11','gnu11','c17','gnu17']
compilers=[('gcc-x64',['gcc'],'x86_64-unknown-linux-gnu'),('gcc-arm',['/home/dev-user/.cache/toucan/aarch64-gcc-13/usr/bin/aarch64-linux-gnu-gcc-13'],'aarch64-unknown-linux-gnu')]
for target in ['x86_64-unknown-linux-gnu','aarch64-unknown-linux-gnu','x86_64-unknown-linux-musl','aarch64-unknown-linux-musl','x86_64-apple-darwin','aarch64-apple-darwin','x86_64-pc-windows-msvc']:
 compilers.append(('clang-'+target,['clang-18','--target='+target],target))
cases={
 'builtin_alias':'typedef NAME Alias; Alias value;',
 'float_typedef':'typedef float NAME; NAME value;',
 'int_typedef':'typedef int NAME; NAME value;_Static_assert(sizeof(value)==sizeof(int),"alias");',
 'pointer_typedef':'typedef int *NAME; NAME value;',
 'self_typedef':'typedef NAME NAME; NAME value;',
 'repeat_typedef':'typedef int NAME;typedef int NAME;NAME value;',
 'conflicting_typedef':'typedef int NAME;typedef double NAME;NAME value;',
 'prior_builtin':'NAME before;typedef int NAME;NAME after;_Static_assert(sizeof(after)==sizeof(int),"new alias");',
 'file_object':'int NAME=1;int f(void){return NAME;}',
 'block_object':'int f(void){int NAME=1;return NAME;}',
 'parameter':'int f(int NAME){return NAME;}',
 'prototype':'void f(int NAME);',
 'prototype_restores':'void f(int NAME);NAME after;',
 'callback_restores':'void (*f)(int NAME);NAME after;',
 'block_typedef':'int f(void){typedef int NAME;NAME value=1;return value;}',
 'nested_typedef':'typedef int NAME; int f(void){typedef char NAME;NAME value=1;return value;}NAME after;_Static_assert(sizeof(after)==sizeof(int),"outer");',
 'tag':'struct NAME{int field;};struct NAME value;',
 'field':'struct S{int NAME;};int f(struct S value){return value.NAME;}',
 'enumerator':'enum E{NAME=1};int f(void){return NAME;}',
 'label':'int f(void){goto NAME;NAME:return 1;}',
 'function':'int NAME(void){return 1;}',
 'macro':'#define NAME int\nNAME value;_Static_assert(sizeof(value)==sizeof(int),"macro");',
}
jobs=[]
for compiler,command,target in compilers:
 for mode in modes:
  for name in names:
   for kind,template in cases.items():
    jobs.append((compiler,command,target,mode,name,kind,template.replace('NAME',name)))
def run(job):
 compiler,command,target,mode,name,kind,source=job
 path=root/f'{compiler}-{mode}-{name}-{kind}.c';path.write_text(source+'\n')
 argv=command+['-std='+mode,'-ffreestanding','-fsyntax-only','-x','c',str(path)]
 p=subprocess.run(argv,text=True,capture_output=True,timeout=30)
 assert p.returncode in [0,1],(argv,p.returncode,p.stderr)
 assert not any(s in p.stderr.lower() for s in ['internal compiler error','please submit a bug report','stack dump:']),(argv,p.stderr)
 return {'compiler':compiler,'target':target,'mode':mode,'name':name,'kind':kind,'source':source,'command':argv,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 rows=list(pool.map(run,jobs))
(root/'native.json').write_text(json.dumps(rows,indent=2)+'\n')
print(len(rows),'native floating-name observations')
for compiler,_,_ in compilers:
 print(compiler)
 for name in names:
  subset=[r for r in rows if r['compiler']==compiler and r['name']==name]
  patterns={tuple((r['kind'],r['status']==0) for r in subset if r['mode']==mode) for mode in modes}
  print(name, 'mode patterns',len(patterns),'accept:',','.join(kind for kind,status in next(iter(patterns)) if status))
