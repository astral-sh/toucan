from pathlib import Path
import json,subprocess,shutil,hashlib
p=Path('/home/dev-user/.cache/toucan/floating-name-conformance/glibc');p.mkdir(exist_ok=True);binary=Path('/home/dev-user/.cache/toucan/floating-name-conformance/final-frozen/toucan');old=json.loads(Path('/home/dev-user/.cache/toucan/modern-header-probes/float-api/report.json').read_text());rows=[]
for original in old:
 r=dict(original);cmd=list(r['command']);cmd[0]=str(binary);cmd=[x for i,x in enumerate(cmd) if not(x=='-D' and i+1<len(cmd) and cmd[i+1].split('=')[0] in {'__GNUC__','__GNUC_MINOR__','__GNUC_PATCHLEVEL__','__clang_major__','__clang_minor__','__clang_patchlevel__'}) and not(i>0 and cmd[i-1]=='-D' and x.split('=')[0] in {'__GNUC__','__GNUC_MINOR__','__GNUC_PATCHLEVEL__','__clang_major__','__clang_minor__','__clang_patchlevel__'})];cmd+=['--rust-target','1.64'];out=subprocess.run(cmd,text=True,capture_output=True,timeout=60);r['prior_exit_code']=r['exit_code'];r.update(command=cmd,exit_code=out.returncode,stdout=out.stdout,stderr=out.stderr);rows.append(r);print(r['modern'],r['name'],out.returncode,flush=True)
 expected=0 if r['name']in['strtof32','strtof64','strtof32x','cosf32']else 1
 assert out.returncode==expected,(r,out.stderr)
(p/'modern-api.json').write_text(json.dumps(dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
# All selected modern APIs in one generated Rust module, built without modifying the header.
cmd=[str(binary),'bindgen','/home/dev-user/.cache/toucan/modern-header-probes/float-api/math.h','--sysroot','/','-I','/usr/lib/gcc/x86_64-linux-gnu/13/include','-D','_GNU_SOURCE','--allowlist','strtof32','--allowlist','strtof64','--allowlist','strtof32x','--allowlist','cosf32','--rust-target','1.64'];out=subprocess.run(cmd,text=True,capture_output=True,timeout=60);assert out.returncode==0,out.stderr
for name in ['strtof32','strtof64','strtof32x','cosf32']:assert 'pub fn '+name+'(' in out.stdout
f=p/'glibc.rs';f.write_text(out.stdout+'\nfn main(){unsafe{let p=b"1.25tail\\0".as_ptr().cast();let mut end=core::ptr::null_mut();assert_eq!(strtof32(p,&mut end),1.25f32);assert_eq!(*end,116);assert_eq!(strtof64(p,&mut end),1.25f64);assert_eq!(strtof32x(p,&mut end),1.25f64);assert_eq!(cosf32(0.0),1.0f32);}}\n')
runs=[]
for rustc in ['rustc','/home/dev-user/.cache/toucan/msrv-rustup/toolchains/1.64.0-x86_64-unknown-linux-gnu/bin/rustc']:
 for opt in ['0','3']:
  exe=p/('glibc-'+('current'if rustc=='rustc'else'1.64')+'-'+opt);rcmd=[rustc,'--edition=2021','-C','opt-level='+opt,str(f),'-l','m','-o',str(exe)];r=subprocess.run(rcmd,text=True,capture_output=True,timeout=60);assert r.returncode==0,r.stderr;run=subprocess.run([str(exe)],text=True,capture_output=True,timeout=10);assert run.returncode==0,run.stderr;runs.append(dict(command=rcmd,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),execution=dict(exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr)))
(p/'glibc-runtime.json').write_text(json.dumps(dict(generate_command=cmd,generated_source_sha256=hashlib.sha256(out.stdout.encode()).hexdigest(),source=f.read_text(),runs=runs),indent=2)+'\n');print('glibc current+1.64 O0/O3 passed')
