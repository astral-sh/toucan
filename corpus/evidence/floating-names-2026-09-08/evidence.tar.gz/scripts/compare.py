import concurrent.futures,hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/floating-name-conformance')
binary=Path(sys.argv[1]);output=Path(sys.argv[2])
rows=json.loads((root/'native.json').read_text())
def run(pair):
 index,native=pair
 command=[str(binary),'inspect',native['command'][-1],'--checked-code','--target',native['target'],'--compiler','gcc' if native['compiler'].startswith('gcc') else 'clang','--std',native['mode']]
 p=subprocess.run(command,text=True,capture_output=True,timeout=45)
 match=(p.returncode==0)==(native['status']==0)
 if not match:print(native['compiler'],native['mode'],native['name'],native['kind'],'native',native['status'],'candidate',p.returncode,p.stderr.strip(),flush=True)
 return {'native_index':index,'command':command,'status':p.returncode,'native_status':native['status'],'match':match,'stderr':p.stderr}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 results=list(pool.map(run,enumerate(rows)))
output.write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'cases':results},indent=2)+'\n')
print(len(results),'comparisons,',sum(not r['match'] for r in results),'mismatches')
