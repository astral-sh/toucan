from pathlib import Path
import subprocess,json,hashlib
root=Path('/home/dev-user/.codex/worktrees/toucan-msvc-declspec')
out=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/declspec-validation');out.mkdir(exist_ok=True)
s=(root/'crates/toucan/tests/declspec.rs').read_text();api=s.split('const API: &str = r#"')[1].split('"#;')[0];(out/'api.h').write_text(api)
cli='/home/dev-user/.cache/toucan/msvc-declarations-target/debug/toucan'
commands=[]
def run(cmd):
 p=subprocess.run(cmd,cwd=out,text=True,capture_output=True);commands.append({'command':cmd,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,(cmd,p.stderr);return p
run([cli,'bindgen',str(out/'api.h'),'--target','x86_64-pc-windows-msvc','--rust-target','1.64','-o',str(out/'bindings.rs'),'--report',str(out/'report.json')])
(out/'consumer.rs').write_text('''#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals)]
include!("bindings.rs");
#[no_mangle] pub unsafe extern "C" fn forward(value: Pair) -> Pair {exchange(value)}
const _: [(); 16] = [(); core::mem::size_of::<Pair>()];
const _: [(); 16] = [(); core::mem::align_of::<Pair>()];
''')
(out/'consumer.c').write_text('#include "api.h"\nstruct Pair forward(struct Pair value) {return exchange(value);}\n_Static_assert(sizeof(struct Pair)==16 && __alignof(struct Pair)==16,"layout");\n')
for level in ['0','2']:
 run(['clang','--target=x86_64-pc-windows-msvc','-std=gnu11','-O'+level,'-S','-emit-llvm','consumer.c','-o',f'clang-O{level}.ll'])
compilers={'current':'/home/dev-user/.cache/toucan/msrv-rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc','1.64':'/home/dev-user/.cache/toucan/msrv-rustup/toolchains/1.64.0-x86_64-unknown-linux-gnu/bin/rustc'}
for name,compiler in compilers.items():
 run([compiler,'--version','--verbose'])
 for level in ['0','3']:
  run([compiler,'--edition=2021','--crate-type=lib','--target=x86_64-pc-windows-msvc','--emit=llvm-ir,metadata','-C','opt-level='+level,'consumer.rs','--out-dir',str(out/name/level)])
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('validated',len(commands),'generation and Clang/current Rust/Rust1.64 commands; cross output only, no Windows execution')
