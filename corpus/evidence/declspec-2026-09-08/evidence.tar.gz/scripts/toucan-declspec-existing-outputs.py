import hashlib,json,subprocess
from pathlib import Path
cache=Path('/home/dev-user/.cache/toucan');out=cache/'declspec-existing-outputs';out.mkdir(exist_ok=True);binary=Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/toucan');rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for arch in ['x86_64','aarch64']:
 for compiler in ['gcc','clang']:
  original=cache/f'musl-validation/portable-{arch}-{compiler}/evidence.json';d=json.loads(original.read_text());command=next(r['command'] for r in d['commands'] if r['name']=='bindings').copy();command[0]=str(binary);command[command.index('-o')+1]=str(out/f'{arch}-{compiler}.rs');command[command.index('--report')+1]=str(out/f'{arch}-{compiler}.json');p=subprocess.run(command,cwd=original.parent,capture_output=True,check=True,timeout=60);assert sha(out/f'{arch}-{compiler}.rs')==d['bindings_sha256'];rows.append(dict(arch=arch,compiler=compiler,command=command,sha256=d['bindings_sha256'],stderr=p.stderr.decode(),original_evidence_sha256=sha(original)))
for project in ['zlib','sqlite','zstd','libgit2']:
 d=json.loads((cache/f'benchmarks-bb6a401/{project}.json').read_text());command=d['commands']['toucan'].copy();command[0]=str(binary);p=subprocess.run(command,capture_output=True,check=True,timeout=60);digest=hashlib.sha256(p.stdout).hexdigest();previous=cache/f'feature-catalog-probes/{project}-bindings.rs';assert digest==sha(previous);rows.append(dict(project=project,command=command,sha256=digest,stderr=p.stderr.decode()))
(out/'evidence.json').write_text(json.dumps(dict(binary_sha256=sha(binary),status='passed',rows=rows),indent=2)+'\n');print('Four musl ABI binding artifacts and four original GNU-header artifacts are byte-identical.')
