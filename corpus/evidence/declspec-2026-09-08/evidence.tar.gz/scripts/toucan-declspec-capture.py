from pathlib import Path
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
repo=Path('/home/dev-user/.codex/worktrees/toucan-msvc-declspec')
cache=Path('/home/dev-user/.cache/toucan/windows-arm64-probes')
out=repo/'corpus/evidence/declspec-2026-09-08';out.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
files=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{p:sha((repo/p).read_bytes()) for p in sorted(set(files)) if not p.startswith('corpus/evidence/')}}
write(out/'source.json',source)
archive={}
for pattern in ['declspec*.json','declspec*.rs','declspec*.txt']:
 for p in (cache/'msvc-syntax').glob(pattern):archive['probes/'+p.name]=p.read_bytes()
for p in (cache/'declspec-validation').rglob('*'):
 if p.is_file():archive['output/'+str(p.relative_to(cache/'declspec-validation'))]=p.read_bytes()
for name in ['declspec.rs']:
 archive['regression/'+name]=(repo/'crates/toucan/tests'/name).read_bytes()
archive['regression/parser-msvc.rs']=(repo/'crates/toucan_parser/tests/msvc.rs').read_bytes()
archive['probes/checked_invariants.rs']=(repo/'fuzz/fuzz_targets/checked_invariants.rs').read_bytes()
for name in ['matrix','output','existing-outputs','capture']:
 p=Path('/tmp/toucan-declspec-'+name+'.py');archive['scripts/'+p.name]=p.read_bytes()
archive['existing/evidence.json']=Path('/home/dev-user/.cache/toucan/declspec-existing-outputs/evidence.json').read_bytes()
logs={}
for name in ['workspace-final','tests','parser-tests','clippy','regeneration','matrix','existing-outputs','cli-build']:
 p=Path('/tmp/toucan-declspec-'+name+'.log');data=p.read_bytes();archive['logs/'+p.name]=data;logs[name]={'path':str(p),'sha256':sha(data),'text':data.decode()}
counts=[tuple(map(int,m)) for m in re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',logs['workspace-final']['text'])]
assert tuple(map(sum,zip(*counts)))==(723,0,189),tuple(map(sum,zip(*counts)))
assert 'test result: ok. 5 passed; 0 failed; 0 ignored' in logs['tests']['text']
assert 'error:' not in logs['clippy']['text'] and 'Finished' in logs['clippy']['text']
assert 'FAILED' not in logs['workspace-final']['text']
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
 for name,data in sorted(archive.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(),mtime=0))
write(out/'files.json',{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(archive.items())})
write(out/'checks.json',logs)
write(out/'summary.json',{'base':source['base'],'source_manifest_sha256':sha((out/'source.json').read_bytes()),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes()),'parser':{'loops':83,'guarded_branches':541,'rules':243},'workspace':{'passed':723,'failed':0,'ignored':189},'focused':{'tests':5,'native_clang_cases':46,'test_template_cases':44,'profiles':11},'checked_matrix':{'pairs':486,'accepted':202,'matching_rejections':276,'explicit_enum_alignment_limits':8,'retained_graph_invariants':'passed'},'seed_matrix':{'pairs':22,'accepted':2,'rejected':20,'retained_graph_invariants':'passed'},'bindings':{'equivalent_gnu_attributes':'byte-identical','existing_project_and_musl_outputs':8,'existing_outputs_byte_identical':True,'rust_versions':['1.64.0','1.98.1'],'rust_optimizations':[0,3],'clang_optimizations':[0,2],'cross_target':'x86_64-pc-windows-msvc','generated_llvm_and_metadata':'passed'},'remaining':['enum-tag alignment','alignment on void or function typedefs','DLL import/export, thread storage, selectany and other Microsoft attributes','actual Windows SDK parsing and native Windows execution'],'not_claimed':['native Windows execution','performance measurements','sanitizer campaign']})
# Preserve only final test/CLI binaries before reclaiming incremental compilation.
frozen=cache/'declspec-frozen-binaries';frozen.mkdir(exist_ok=True)
paths=[Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/toucan')]
for stem in ['declspec-','msvc-']:
 candidates=[p for p in Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/deps').glob(stem+'*') if p.is_file() and p.suffix=='']
 paths.append(max(candidates,key=lambda p:p.stat().st_mtime))
manifest={}
for p in paths:
 destination=frozen/p.name;shutil.copy2(p,destination);manifest[p.name]={'source':str(p),'bytes':destination.stat().st_size,'sha256':sha(destination.read_bytes())}
write(frozen/'manifest.json',manifest)
print(json.dumps({'source_manifest':sha((out/'source.json').read_bytes()),'archive':sha((out/'evidence.tar.gz').read_bytes()),'binaries':manifest},indent=2))
