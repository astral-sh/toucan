from pathlib import Path
import subprocess,json
repo=Path('/home/dev-user/.codex/worktrees/toucan-msvc-declspec')
cache=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-syntax')
deps=Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/deps')
src='''#[path="/home/dev-user/.codex/worktrees/toucan-msvc-declspec/fuzz/fuzz_targets/checked_invariants.rs"] mod checked_invariants;
use std::io::BufRead;
fn main(){for line in std::io::stdin().lock().lines(){let line=line.unwrap(); let input:serde_json::Value=serde_json::from_str(&line).unwrap();let source=input["source"].as_str().unwrap();for mode in toucan::LanguageMode::ALL {let profile=toucan::CompilerProfile::default_for(toucan::Target::X86_64PcWindowsMsvc).with_language_mode(mode);let a=toucan::semantic::analyze_with_profile(source,profile,&Default::default());let b=toucan::semantic::analyze_with_profile(source,profile,&toucan::AnalysisOptions{retain_code:true,..Default::default()});let result=match (a,b){(Ok(a),Ok(b))=>{assert_eq!(format!("{:?}",a.unit()),format!("{:?}",b.unit()));checked_invariants::check(&b,source);serde_json::json!({"accepted":true})},(Err(a),Err(b))=>{assert_eq!((a.offset,&a.message),(b.offset,&b.message));serde_json::json!({"accepted":false,"diagnostic":a.message,"offset":a.offset})}, v=>panic!("{v:?}")};println!("{}",serde_json::json!({"source":source,"mode":format!("{mode:?}"),"result":result}));}}}
'''
p=cache/'declspec-checked.rs';p.write_text(src)
cmd=['rustc','--edition=2024',str(p),'-L','dependency='+str(deps)]
for name in ['toucan','serde_json']:
 path=max(deps.glob('lib'+name+'-*.rlib'),key=lambda x:x.stat().st_mtime)
 cmd.extend(['--extern',name+'='+str(path)])
exe=cache/'declspec-checked';cmd+=['-o',str(exe)];subprocess.run(cmd,check=True)
rows=[r for r in json.loads((cache/'declspec-check-matrix.json').read_text()) if r['attribute'].split('(')[0] in ['align','noinline','noreturn','deprecated']]
rows += sum([json.loads((cache/name).read_text()) for name in ['declspec-ice.json','declspec-string-operands.json']], [])
inputs=''.join(json.dumps(r)+'\n' for r in rows)
p=subprocess.run([str(exe)],input=inputs,text=True,capture_output=True);(cache/'declspec-checked-stderr.txt').write_text(p.stderr);assert p.returncode==0,p.stderr
checked=[json.loads(x) for x in p.stdout.splitlines()]
lookup={r['source']:r for r in rows}
diffs=[]
for r in checked:
 n=lookup[r['source']]
 if r['result']['accepted'] != (n['status']==0):
  diffs.append(r)
record={'compile':cmd,'checked':checked,'differences':diffs,'pair_count':len(checked)}
(cache/'declspec-checked-matrix.json').write_text(json.dumps(record,indent=2)+'\n')
print('pairs',len(checked),'accepted',sum(x['result']['accepted'] for x in checked),'differences',len(diffs))
for r in diffs: print(r)
