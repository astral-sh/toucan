; ModuleID = 'consumer.f7f57611ce5e34b2-cgu.0'
source_filename = "consumer.f7f57611ce5e34b2-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

; Function Attrs: nounwind uwtable
define void @forward(ptr dead_on_unwind noalias nofree noundef writable sret([16 x i8]) align 16 captures(address) dereferenceable(16) %_0, ptr dead_on_return noalias nofree noundef align 16 captures(address) dereferenceable(16) %value) unnamed_addr #0 {
start:
  tail call void @exchange(ptr noalias nofree noundef nonnull sret([16 x i8]) align 16 captures(address) dereferenceable(16) %_0, ptr noalias nofree noundef nonnull align 16 captures(address) dereferenceable(16) %value) #1
  ret void
}

; Function Attrs: nounwind uwtable
declare void @exchange(ptr dead_on_unwind noalias nofree noundef writable sret([16 x i8]) align 16 captures(address) dereferenceable(16), ptr dead_on_return noalias nofree noundef align 16 captures(address) dereferenceable(16)) unnamed_addr #0

attributes #0 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
