
struct __declspec(align(16)) Pair { unsigned long long a, b; };
__declspec(noreturn) typedef void (*Stop)(int);
__declspec(noreturn) void (*make_callback(void))(void);
__declspec(noinline) struct Pair exchange(struct Pair value);
__declspec(align(32)) extern int required;
