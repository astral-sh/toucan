#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals)]
include!("bindings.rs");
#[no_mangle] pub unsafe extern "C" fn forward(value: Pair) -> Pair {exchange(value)}
const _: [(); 16] = [(); core::mem::size_of::<Pair>()];
const _: [(); 16] = [(); core::mem::align_of::<Pair>()];
