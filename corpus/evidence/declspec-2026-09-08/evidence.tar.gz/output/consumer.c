#include "api.h"
struct Pair forward(struct Pair value) {return exchange(value);}
_Static_assert(sizeof(struct Pair)==16 && __alignof(struct Pair)==16,"layout");
