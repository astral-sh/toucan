; ModuleID = 'consumer.26609c7a-cgu.0'
source_filename = "consumer.26609c7a-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

%Pair = type { i64, i64 }

; Function Attrs: uwtable
define void @forward(%Pair* noalias nocapture noundef sret(%Pair) dereferenceable(16) %0, %Pair* noalias nocapture noundef readonly dereferenceable(16) %value) unnamed_addr #0 {
start:
  %_2 = alloca %Pair, align 16
  %1 = bitcast %Pair* %_2 to i8*
  call void @llvm.lifetime.start.p0i8(i64 16, i8* nonnull %1)
  %2 = bitcast %Pair* %value to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* noundef nonnull align 16 dereferenceable(16) %1, i8* noundef nonnull align 16 dereferenceable(16) %2, i64 16, i1 false)
  call void @exchange(%Pair* noalias nocapture noundef nonnull sret(%Pair) dereferenceable(16) %0, %Pair* noalias nocapture noundef nonnull dereferenceable(16) %_2)
  call void @llvm.lifetime.end.p0i8(i64 16, i8* nonnull %1)
  ret void
}

; Function Attrs: argmemonly mustprogress nofree nosync nounwind willreturn
declare void @llvm.lifetime.start.p0i8(i64 immarg, i8* nocapture) #1

; Function Attrs: argmemonly mustprogress nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: uwtable
declare void @exchange(%Pair* noalias nocapture noundef sret(%Pair) dereferenceable(16), %Pair* noalias nocapture noundef dereferenceable(16)) unnamed_addr #0

; Function Attrs: argmemonly mustprogress nofree nosync nounwind willreturn
declare void @llvm.lifetime.end.p0i8(i64 immarg, i8* nocapture) #1

attributes #0 = { uwtable "target-cpu"="x86-64" }
attributes #1 = { argmemonly mustprogress nofree nosync nounwind willreturn }
attributes #2 = { argmemonly mustprogress nofree nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 7, !"PIC Level", i32 2}
