#![allow(dead_code, non_camel_case_types, non_snake_case, non_upper_case_globals)]
include!("bindings.rs");

unsafe extern "C" fn callback(input: Pair) -> ::core::ffi::c_long {
    input.tag + input.value as ::core::ffi::c_long
}

fn main() {
    assert_eq!((::core::mem::size_of::<Pair>(), ::core::mem::align_of::<Pair>()), (16, 8));
    assert_eq!(::core::mem::offset_of!(Pair, value), 8);
    assert_eq!((::core::mem::size_of::<Natural128>(), ::core::mem::align_of::<Natural128>()), (48, 16));
    assert_eq!(::core::mem::offset_of!(Natural128, second), 16);
    assert_eq!((::core::mem::size_of::<Packed128>(), ::core::mem::align_of::<Packed128>()), (24, 8));
    assert_eq!(::core::mem::offset_of!(Packed128, second), 8);
    let answer = unsafe { call_pair(Pair { tag: 7, value: 2.5 }, Some(callback)) };
    assert_eq!((answer.tag, answer.value), (16, 5.75));
    assert_eq!(unsafe { inspect_pair(answer) }, 1);
    println!("native Windows ARM64 C/Rust callback, record passing, and return passed");
}
