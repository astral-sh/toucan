#if !defined(_M_ARM64) || !defined(_WIN64) || defined(_M_X64)
#error expected Windows ARM64
#endif

typedef struct Pair { long tag; double value; } Pair;
#pragma pack(push, 8)
typedef struct PackedPair { char first; double value; } PackedPair;
#pragma pack(pop)
typedef long (*Callback)(Pair);

#ifdef __clang__
typedef struct Natural128 { char first; __int128 second; unsigned __int128 third; } Natural128;
#pragma pack(push, 8)
typedef struct Packed128 { char first; __int128 second; } Packed128;
#pragma pack(pop)
#endif

#ifdef ARM64_PROBE_EXPORT
#define ARM64_PROBE_API __declspec(dllexport)
#else
#define ARM64_PROBE_API __declspec(dllimport)
#endif
ARM64_PROBE_API Pair call_pair(Pair input, Callback callback);
ARM64_PROBE_API int inspect_pair(Pair input);
