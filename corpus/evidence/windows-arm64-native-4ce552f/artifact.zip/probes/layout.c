#include <stddef.h>
#include <windows.h>
#include "abi.h"
_Static_assert(sizeof(long) == 4 && sizeof(void *) == 8, "Windows LL64");
_Static_assert(sizeof(DWORD) == 4 && sizeof(SIZE_T) == 8 && sizeof(WCHAR) == 2,
               "Windows SDK scalar types");
_Static_assert(sizeof(Pair) == 16 && _Alignof(Pair) == 8 &&
               offsetof(Pair, value) == 8, "Pair layout");
_Static_assert(sizeof(PackedPair) == 16 && _Alignof(PackedPair) == 8 &&
               offsetof(PackedPair, value) == 8, "packed Pair layout");
#ifdef __clang__
_Static_assert(sizeof(Natural128) == 48 && _Alignof(Natural128) == 16 &&
               offsetof(Natural128, second) == 16 &&
               offsetof(Natural128, third) == 32, "natural int128 layout");
_Static_assert(sizeof(Packed128) == 24 && _Alignof(Packed128) == 8 &&
               offsetof(Packed128, second) == 8, "pack(8) int128 layout");
#endif
