#define ARM64_PROBE_EXPORT
#include "abi.h"
Pair call_pair(Pair input, Callback callback) {
    Pair result = { input.tag + callback(input), input.value + 3.25 };
    return result;
}
int inspect_pair(Pair input) { return input.tag == 16 && input.value == 5.75; }
