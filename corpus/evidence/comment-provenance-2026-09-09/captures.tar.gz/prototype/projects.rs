use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering};
static CALLS: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);
struct Counter;
unsafe impl GlobalAlloc for Counter {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(size, Ordering::Relaxed);
        unsafe { System.realloc(ptr, layout, size) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { unsafe { System.dealloc(ptr, layout) } }
}
#[global_allocator]
static ALLOCATOR: Counter = Counter;


fn main() {
 let args: Vec<String>=std::env::args().skip(1).collect();
 let mut config=toucan::Config::with_profile(toucan_target::CompilerProfile::new(toucan_target::Target::X86_64UnknownLinuxGnu,if args[0]=="clang" {toucan_target::Compiler::Clang} else {toucan_target::Compiler::Gnu}).unwrap());
 for item in args[4].split(';').filter(|s|!s.is_empty()){config.preprocessor.include_dirs.push(item.into());}
 config.preprocessor.include_dirs.extend(["/usr/include/x86_64-linux-gnu".into(),"/usr/include".into()]);
 #[cfg(candidate)] if args[1]=="on" { config.analysis.retain_declaration_origins=true; config.preprocessor.record_file_origins=true; }
 #[cfg(candidate)] if args[1]=="doc" {config.preprocessor.documentation=Some(Default::default());}
 let options=toucan::BindingOptions{allowlist:args[5].split(';').filter(|s|!s.is_empty()).map(str::to_owned).collect(),..Default::default()};
 let start=std::time::Instant::now();
 CALLS.store(0,Ordering::Relaxed); BYTES.store(0,Ordering::Relaxed);
 let c=toucan::parse_file(std::path::Path::new(&args[2]),&config).unwrap();
 let calls=CALLS.load(Ordering::Relaxed);let bytes=BYTES.load(Ordering::Relaxed);
 println!("analysis {calls} {bytes} {} {} {}",start.elapsed().as_nanos(),c.unit().declarations.len(),c.preprocessed().source.len());
 #[cfg(candidate)] if args[1]=="on" {
  let origins=c.declaration_origins().unwrap(); let files=c.preprocessed().file_origins().unwrap();
  let mut missing=0;
  for o in origins.entries() { assert!(o.source().range().end<=c.preprocessed().source.len()); if files.source_file(o.source().range().start).is_none(){missing+=1;} }
  println!("origins {} {} {missing}",origins.entries().len(),files.mappings().len());
 }
 #[cfg(candidate)] if args[1]=="doc" {let counts=c.preprocessed().documentation().map(|docs|(docs.sources().len(),docs.mappings().len(),docs.sources().map(|(_,s)|s.comments().len()).sum::<usize>())).unwrap_or_default();println!("documentation {} {} {}",counts.0,counts.1,counts.2);}
 std::fs::write(format!("{}.unit",args[3]),format!("{:?}",c.unit())).unwrap();
 std::fs::write(format!("{}.i",args[3]),&c.preprocessed().source).unwrap();
 if !args[5].is_empty() { let (source,_)=c.bindings(&options).unwrap();std::fs::write(format!("{}.rs",args[3]),source).unwrap(); }
}
