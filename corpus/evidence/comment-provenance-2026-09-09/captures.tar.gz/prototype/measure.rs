use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering};
static CALLS: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);
struct Counter;
unsafe impl GlobalAlloc for Counter {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size(), Ordering::Relaxed);
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(size, Ordering::Relaxed);
        unsafe { System.realloc(ptr, layout, size) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) { unsafe { System.dealloc(ptr, layout) } }
}
#[global_allocator]
static ALLOCATOR: Counter = Counter;

fn measure(label: &str, f: impl Fn() -> String) {
 drop(f()); CALLS.store(0,Ordering::Relaxed); BYTES.store(0,Ordering::Relaxed);
 let output=f();let calls=CALLS.load(Ordering::Relaxed);let bytes=BYTES.load(Ordering::Relaxed);
 println!("{label}: {calls} {bytes} {}",output.len());
 let root=std::env::args().nth(1).unwrap();std::fs::write(format!("{root}/{label}.rs"),output).unwrap();
}
fn main() {
 let root=std::env::args().nth(1).unwrap();std::fs::create_dir_all(&root).unwrap();
 for count in [1,100,1000] {
  let source=format!("typedef struct Record {{int value;}} Record;\n{}",(0..count).map(|i|format!("extern int f{i}(Record*);\n")).collect::<String>());
  let path=std::path::PathBuf::from(&root).join(format!("input-{count}.h"));std::fs::write(&path,&source).unwrap();
  measure(&format!("builder-{count}"),|| bindgen::Builder::default().header(path.to_str().unwrap()).clang_arg("--target=x86_64-unknown-linux-gnu").layout_tests(false).generate().unwrap().to_string());
  measure(&format!("facade-{count}"),|| toucan::parse_source(std::path::Path::new("input.h"),&source,&toucan::Config::new(toucan::Target::X86_64UnknownLinuxGnu)).unwrap().bindings(&Default::default()).unwrap().0);
  #[cfg(candidate)] measure(&format!("facade-docs-{count}"),|| {let mut config=toucan::Config::new(toucan::Target::X86_64UnknownLinuxGnu);config.preprocessor.documentation=Some(Default::default());toucan::parse_source(std::path::Path::new("input.h"),&source,&config).unwrap().bindings(&Default::default()).unwrap().0});

 }
}
