use toucan_parser::ast::*;
use toucan_preprocessor::*;
fn identifier(d:&Declarator)->Option<(&str,usize)>{match &d.kind.node{DeclaratorKind::Identifier(id)=>Some((&id.node.name,id.span.start)),DeclaratorKind::Declarator(inner)=>identifier(&inner.node),_=>None}}
fn leading(docs:&Documentation,location:DocumentationLocation)->Option<String>{
 let file=docs.source(location.source()).unwrap();
 let comment=file.comments().iter().filter(|c|c.range().end<=location.offset() && file.is_system_at(c.range().start)==Some(false)).last()?;
 (!comment.is_trailing() && comment.following_barrier()>=location.offset()).then(||comment.text().to_owned())
}
fn main(){let path=std::env::args().nth(1).unwrap();let mut cfg=Config{documentation:Some(DocumentationOptions::default()),..Default::default()};cfg.defines.insert("__clang__".into(),"1".into());
 let out=Preprocessor::new(cfg).preprocess(std::path::Path::new(&path)).unwrap();let parsed=toucan_parser::driver::parse_preprocessed(&toucan_parser::driver::Config::with_clang(),out.source.clone()).unwrap();let mut rows:std::collections::BTreeMap<String,Option<String>>=std::collections::BTreeMap::new();
 for external in parsed.unit.0 {
  if let ExternalDeclaration::Declaration(decl)=external.node{
   let is_typedef=decl.node.specifiers.iter().any(|s|matches!(&s.node,DeclarationSpecifier::StorageClass(s) if matches!(s.node,StorageClassSpecifier::Typedef)));
   for init in &decl.node.declarators{
    if let Some((name,offset))=identifier(&init.node.declarator.node){
     let selected=out.documentation().and_then(|docs|{
      let loc=if is_typedef{decl.span.start}else{offset};
      let origin=docs.resolve(loc)?;
      let invocation=origin.invocation().and_then(|location|leading(docs,location));
      invocation.or_else(||docs.resolve(decl.span.start).and_then(|begin|begin.spelling()).and_then(|location|leading(docs,location)))
     });
     if rows.get(name).is_none_or(Option::is_none){rows.insert(name.to_owned(),selected);}
    }
   }
  }
 }
 for (name,raw) in rows { let raw=raw.map(|s|s.bytes().map(|b|format!("{b:02x}")).collect::<String>()).unwrap_or_else(||"-".into()); println!("{name}\t{raw}"); }
}
