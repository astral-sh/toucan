#!/usr/bin/env python3
"""Read-only independent audit of the recorded September 9 native C testsuite run."""
import collections, datetime, hashlib, json, pathlib, re, subprocess, tarfile
BASE=pathlib.Path('/home/dev-user/.cache/toucan/native-conformance-9d8901b')
REPO=pathlib.Path('/home/dev-user/code/oss/toucan')
CANDIDATE=pathlib.Path('/home/dev-user/.codex/worktrees/toucan-native-conformance')
OUTPUT=pathlib.Path('/tmp/toucan-native-conformance-independent-verification.json')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def require(ok,why):
 if not ok:raise RuntimeError(why)
def accepted(c):return c['exit_code']==0 and not c['timeout'] and 'start_error' not in c
seen_logs={};command_count=0
crashes=['internal compiler error:','please submit a bug report',"thread 'main' panicked at"]
def command(c):
 global command_count
 command_count+=1
 require(isinstance(c['command'],list) and c['command'],'missing argv')
 require(c['environment_overrides']=={'LC_ALL':'C','SOURCE_DATE_EPOCH':'0'},'environment')
 require(not c['timeout'] and 'start_error' not in c,'command infrastructure failure')
 require(type(c['exit_code']) is int and c['exit_code'] in (0,1),'unexpected command exit')
 for stream in ['stdout','stderr']:
  p=pathlib.Path(c[stream]);require(p.is_file(),'missing '+str(p));seen_logs[str(p)]=sha(p)
  if stream+'_sha256' in c:require(sha(p)==c[stream+'_sha256'],'recorded log hash')
 diagnostic=pathlib.Path(c['stderr']).read_text(errors='replace').lower()
 require(c['crash_diagnostic']==any(x in diagnostic for x in crashes),'crash classification')
 require(not c['crash_diagnostic'],'crash diagnostic')
def walk_commands(v):
 if isinstance(v,dict):
  if {'command','stdout','stderr','exit_code','timeout'} <= v.keys():command(v)
  else:
   for x in v.values():walk_commands(x)
 elif isinstance(v,list):
  for x in v:walk_commands(x)
build=load(BASE/'build.json');require(build['exit_code']==0 and build['source_unchanged'],'build status')
require(build['source_before']==build['source_after'],'build inventory drift')
source=build['source_before'];require(len(source)==630,'source count')
frozen=load(REPO/'corpus/consumers/zstd-optin/source-digests.json');require(source==frozen,'frozen inventory drift')
refs=['66c87396bbe03b22085339a87b8c350c90be280b','85bf1ad6dcbc5840ade11bf8798785b6da13260a',build['source_commit']]
ref_checks=[]
for ref in refs:
 paths=list(source)
 data=subprocess.run(['git','cat-file','--batch'],input=''.join(ref+':'+p+'\n' for p in paths).encode(),stdout=subprocess.PIPE,check=True,cwd=REPO).stdout
 pos=0
 for p in paths:
  end=data.index(b'\n',pos);header=data[pos:end].split();require(header[1]==b'blob','not blob')
  size=int(header[2]);blob=data[end+1:end+1+size];pos=end+2+size
  require(hashlib.sha256(blob).hexdigest()==source[p],ref+':'+p+' hash')
 ref_checks.append({'revision':ref,'matched_files':len(paths)})
for p,v in source.items():require(sha(CANDIDATE/p)==v,'current source changed '+p)
for b in build['binaries'].values():require(sha(b['path'])==b['sha256'],'binary changed')
profiles={};strict_names=[]
for profile in ['gcc','clang']:
 directory=BASE/(profile+'-full');d=load(directory/'evidence.json');config=d['configuration'];native=d['native_source_configuration']
 require(d['schema_version']==2 and config['native_source'],'native schema')
 require(config['compiler']==config['preprocessor']==profile and config['target']=='x86_64-unknown-linux-gnu' and config['dialect']=='c11','profile config')
 require(not config['case'] and config['limit'] is None,'case filter')
 require(config['fail_on_strict_difference'] and not config['fail_on_difference'],'gate policy')
 require(all(config[k]==[] for k in ['cc_arg','gcc_arg','clang_arg']),'caller flags')
 require(sha(CANDIDATE/'scripts/audit_c_testsuite.py')==d['runner_sha256'],'driver changed')
 require(sha(CANDIDATE/'corpus/conformance/c-testsuite.json')==d['manifest_sha256'],'manifest changed')
 require(sha(d['archive'])==d['manifest']['archive_sha256'],'archive hash')
 archive_sources={}
 with tarfile.open(d['archive']) as tar:
  for m in tar:
   if m.isfile() and m.name.startswith(d['manifest']['archive_root']+'/'+d['manifest']['tests_directory']+'/'):
    archive_sources[pathlib.PurePosixPath(m.name).name]=hashlib.sha256(tar.extractfile(m).read()).hexdigest()
 require(len([p for p in archive_sources if p.endswith('.c')])==220,'archive count')
 for name,t in d['tools'].items():
  require(sha(t['path'])==t['sha256'],'tool drift '+name)
  if name=='toucan':require(t['sha256']==build['binaries']['toucan']['sha256'],'CLI build provenance')
  if name=='native_probe':
   require(t['sha256']==build['binaries']['examples/audit_translation_unit']['sha256'],'probe build provenance')
   require(sha(t['protocol_source']['path'])==t['protocol_source']['sha256'],'protocol source')
  walk_commands(t)
 walk_commands(native)
 for k in ['include_search_command','compiler_definitions_command','probe_control']:require(accepted(native[k]),'native control')
 control=load(native['probe_control']['stdout']);require(control==native['probe_configuration'],'control JSON')
 require(control['status']=='preprocessed' and control['compiler']==profile,'control status')
 require(control['feature_queries']=={'compiler':profile,'configured_attribute':True,'configured_builtin':True,'language_mode':'c11'},'feature profile')
 require(native['definitions']==[] and native['timestamp']['unix_seconds']==0,'native fixed configuration')
 compiler_macros={}
 for line in pathlib.Path(native['compiler_definitions_command']['stdout']).read_text().splitlines():
  require(line.startswith('#define '),'macro dump line');parts=line[8:].split(maxsplit=1)
  require(parts[0] not in compiler_macros,'duplicate macro');compiler_macros[parts[0]]=parts[1] if len(parts)>1 else ''
 require(compiler_macros==native['compiler_definitions'],'recorded compiler macros')
 shipped=control['definitions'];diff={'compiler_only':{k:compiler_macros[k] for k in compiler_macros.keys()-shipped.keys()},'toucan_only':{k:shipped[k] for k in shipped.keys()-compiler_macros.keys()},'different':{k:{'compiler':compiler_macros[k],'toucan':shipped[k]} for k in shipped.keys()&compiler_macros.keys() if shipped[k]!=compiler_macros[k]}}
 require(diff==native['macro_differences'],'macro differences')
 include_text=pathlib.Path(native['include_search_command']['stderr']).read_text();section=include_text.split('#include <...> search starts here:\n',1)[1].split('End of search list.',1)[0]
 require([x.strip() for x in section.splitlines() if x.strip()]==native['include_dirs'],'include order')
 all_inputs={};both_counts=collections.Counter();accepted_old=[];accepted_native=[];strict=[];differences=[]
 require(len(d['cases'])==220 and len({c['name'] for c in d['cases']})==220,'case coverage')
 for c in d['cases']:
  name=c['name'];src=pathlib.Path(c['source']);require(sha(src)==c['source_sha256']==archive_sources[name],'original source '+name)
  for suffix,s in c['sidecars'].items():require(sha(s['path'])==s['sha256']==archive_sources[name+'.'+suffix] and pathlib.Path(s['path']).read_text()==s['text'],'sidecar')
  case_dir=directory/'cases'/src.stem;require(load(case_dir/'result.json')==c,'case sidecar synchronization')
  walk_commands(c)
  both={m:all(accepted(c['compilers'][cc][m]) for cc in ['gcc','clang']) for m in c['both_accept']}
  require(both==c['both_accept'],'oracle acceptance booleans')
  for m,v in both.items():both_counts[m]+=v
  for cc,modes in c['compilers'].items():
   for mode,cmd in modes.items():
    argv=cmd['command'];require(argv[0]==d['tools'][cc]['path'] and argv[-2:]==['-fsyntax-only',str(src)],'original compiler argv')
    if mode=='strict_c11':require('-std=c11' in argv and '-pedantic-errors' in argv,'strict flags')
    else:require('-std='+mode in argv,'mode flag')
  require(accepted(c['preprocess']) and accepted(c['preprocessed_oracle']),'compiler pipeline')
  pp=case_dir/'source.i';require(sha(pp)==c['preprocessed_sha256'] and pp.stat().st_size==c['preprocessed_bytes'],'preprocessed output')
  require(c['preprocess']['command']==[d['tools'][profile]['path'],'-std=c11','-E','-P',str(src),'-o',str(pp)],'preprocess command')
  require(c['preprocessed_oracle']['command']==[d['tools'][profile]['path'],'-std=c11','-fsyntax-only',str(pp)],'oracle command')
  require(c['toucan']['command']==[d['tools']['toucan']['path'],'check','--target',config['target'],'--compiler',profile,str(pp)],'CLI profile')
  require(c['eligible']==both['c11'] and c['eligible'],'eligible set')
  require(c['difference']==(not accepted(c['toucan'])),'difference flag')
  require(not c['tool_failure'] and not c['oracle_pipeline_failure'],'case infrastructure')
  n=c['native_source'];require(n['source_before']==n['source_after']==c['source_sha256'],'native source stability')
  require(not n['changed_dependencies'] and n['dependencies_before']==n['dependencies_after'],'native dependency stability')
  for p,h in n['dependencies_before'].items():
   require(sha(p)==h,'native dependency current bytes '+p)
   if p in all_inputs:require(all_inputs[p]==h,'native dependency percase drift')
   all_inputs[p]=h
  require(str(src) in n['dependencies_before'],'source in native dependencies')
  for op,key,result_key in [('preprocess','preprocess','preprocessing_result'),('analyze','analysis','analysis_result')]:
   cmd=n[key];result=load(cmd['stdout']);require(result==n[result_key],'probe raw JSON agreement')
   req_path=pathlib.Path(cmd['command'][1]);require(cmd['command'][0]==d['tools']['native_probe']['path'] and sha(req_path)==cmd['request_sha256'],'probe argv/request digest')
   req=load(req_path);require(req['operation']==op and req['input']==str(src) and req['target']==config['target'] and req['compiler']==profile and req['language_mode']=='c11' and req['include_dirs']==native['include_dirs'] and req['definitions']==[] and not req['retain_code'],'native request scope')
   require(cmd['exit_code']=={'preprocessed':0,'accepted':0,'rejected':1}[result['status']],'probe status/exit')
   if result['status']!='rejected':
    out=cmd['output'];require(req['output']==out['path'] and sha(out['path'])==out['sha256'] and pathlib.Path(out['path']).stat().st_size==out['bytes'],'native output')
    require(set(result['dependencies'])==set(n['dependencies_before']),'native dependency set')
    require(result['compiler']==profile,'probe compiler')
   if op=='preprocess':require(result['status']=='preprocessed' and result['definitions']==shipped and result['embedded_headers']==control['embedded_headers'] and result['feature_queries']==control['feature_queries'],'percase shipped configuration')
   elif result['status']=='accepted':require(result['language_mode']=='c11' and not result['retained'],'analysis mode')
  actual_native='accepted' if n['analysis_result']['status']=='accepted' else n['analysis_result']['stage']+'_rejected'
  require(n['status']==actual_native and n['difference']==(actual_native!='accepted'),'native final status')
  if accepted(c['toucan']):accepted_old.append(name)
  if n['status']=='accepted':accepted_native.append(name)
  if both['strict_c11']:strict.append(name)
  if c['difference'] or n['difference']:differences.append(name)
 require(set(accepted_old)==set(accepted_native),'route acceptance mismatch')
 require(len(strict)==211 and set(strict)<=set(accepted_old),'strict acceptance')
 require(differences==['00144.c'] and len(accepted_old)==219,'exploratory difference')
 require(all_inputs==d['native_dependency_hashes'] and not d['changed_native_dependencies'],'final inventory')
 require(dict(both_counts)==d['summary']['both_accept'],'summary oracles')
 s=d['summary'];require(s['source_count']==220 and s['eligible_count']==220 and s['toucan_accepted']==219 and s['strict_eligible_count']==211 and s['strict_toucan_accepted']==211 and s['differences']==differences and s['strict_differences']==[],'legacy summary')
 require(s['native_source']['accepted']==219 and s['native_source']['strict_accepted']==211 and s['native_source']['differences']==differences and s['native_source']['strict_differences']==[],'native summary')
 require(not any(s[k] for k in ['tool_failures','oracle_pipeline_failures','changed_tools']),'summary infrastructure')
 strict_names.append(strict)
 profiles[profile]={'evidence_sha256':sha(directory/'evidence.json'),'cases':220,'strict_positive':211,'compiler_preprocessed_accepted':219,'native_accepted':219,'differences':differences,'native_inputs':len(all_inputs),'native_non_source_inputs':len(all_inputs)-220,'macro_differences':{k:len(v) for k,v in diff.items()},'include_dirs':native['include_dirs'],'raw_requests_checked':440,'raw_probe_results_checked':440,'source_archive_sha256':d['manifest']['archive_sha256']}
require(strict_names[0]==strict_names[1],'strict profile sets differ')
log_manifest_digest=hashlib.sha256(json.dumps(seen_logs,sort_keys=True,separators=(',',':')).encode()).hexdigest()
report={'status':'passed','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'audit_script_sha256':sha(__file__),'read_only':True,'compiler_or_build_reruns':False,'profiles':profiles,'commands_checked':command_count,'unique_logs_hashed':len(seen_logs),'log_digest_map_sha256':log_manifest_digest,'build_record_sha256':sha(BASE/'build.json'),'build_log_sha256':sha(BASE/'build.log'),'build_command':build['command'],'build_exit_code':build['exit_code'],'build_source_unchanged':True,'source_revision_checks':ref_checks,'working_source_matches':630,'build_binaries':build['binaries'],'candidate_driver_sha256':sha(CANDIDATE/'scripts/audit_c_testsuite.py'),'candidate_gate_tests_sha256':sha(CANDIDATE/'tools/binding_compare/tests/test_c_testsuite.py'),'gate_tests':{'command':['python3','-B','-m','unittest','discover','-s','tools/binding_compare/tests','-p','test_c_testsuite.py'],'passed':14},'review':{'material_false_pass_findings':[],'limitations':['Acceptance-only: no execution, ABI, invalid-program rejection or complete C conformance proof.','Strict-positive membership is determined by both recorded compiler results; the generic gate does not pin the count211. This audit independently requires211 in each full profile.','Native route uses shipped macros and recorded include order; macro/preprocessed-text equality and exact system-header warning semantics are not claimed.','Command exit codes are recorded process observations, not independently reproducible from stdout alone. This audit rehashes logs and validates consistency without rerunning compilers.','Build uses trusted local Ohm experimental reuse; these results are local conformance evidence, not stable-toolchain CI or performance evidence.','Current byte hashes verify recorded before/after stability and archive lineage; this audit cannot exclude transient mutations reverted between original hash observations.']}}
OUTPUT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
