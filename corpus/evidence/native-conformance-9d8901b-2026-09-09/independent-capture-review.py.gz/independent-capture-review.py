#!/usr/bin/env python3
import gzip,hashlib,json,pathlib
PACKAGE=pathlib.Path('/home/dev-user/.codex/worktrees/toucan-native-conformance/corpus/evidence/native-conformance-9d8901b-2026-09-09')
BASE=pathlib.Path('/home/dev-user/.cache/toucan/native-conformance-9d8901b')
CANDIDATE=pathlib.Path('/home/dev-user/.codex/worktrees/toucan-native-conformance')
OUTPUT=pathlib.Path('/tmp/toucan-native-conformance-independent-verification.json')
def digest(b):return hashlib.sha256(b).hexdigest()
def require(ok,why):
 if not ok:raise RuntimeError(why)
capture=json.loads(gzip.decompress((PACKAGE/'capture.json.gz').read_bytes()))
for h,text in capture['contents'].items():require(digest(text.encode())==h,'contents address')
counts={'retained_files_hashed':0,'retained_files_match_original':0,'excluded_files_match_original':0,'unique_texts_hashed':len(capture['contents'])}
for kind in ['files','excluded_artifacts']:
 for name,info in capture[kind].items():
  prefix,rel=name.split('/',1)
  original=None
  if prefix in ['gcc','clang']:original=BASE/(prefix+'-full')/rel
  elif prefix=='candidate':original=CANDIDATE/rel
  elif prefix=='build':original=BASE/rel
  elif prefix=='packaging':original=pathlib.Path('/tmp/toucan-package-native-conformance.py')
  if kind=='files':
   content=capture['contents'][info['sha256']].encode();require(len(content)==info['bytes'],'retained size');counts['retained_files_hashed']+=1
   if original is not None:require(original.read_bytes()==content,'retained original '+name);counts['retained_files_match_original']+=1
  else:
   require(original is not None,'unknown exclusion');b=original.read_bytes();require(len(b)==info['bytes'] and digest(b)==info['sha256'],'excluded original '+name);counts['excluded_files_match_original']+=1
summary=json.loads((PACKAGE/'summary.json').read_text())
for name,info in summary['files'].items():
 b=(PACKAGE/name).read_bytes();require(len(b)==info['bytes'] and digest(b)==info['sha256'],'summary file '+name)
for p in ['gcc','clang']:
 require(gzip.decompress((PACKAGE/(p+'.json.gz')).read_bytes())==(BASE/(p+'-full')/'evidence.json').read_bytes(),'report exactbytes')
 require(summary['profiles'][p]['summary']==json.loads((BASE/(p+'-full')/'evidence.json').read_text())['summary'],'package summary')
require(gzip.decompress((PACKAGE/'build.json.gz').read_bytes())==(BASE/'build.json').read_bytes(),'build exactbytes')
report=json.loads(OUTPUT.read_text());report['capture_verification']={'status':'passed','capture_sha256':digest((PACKAGE/'capture.json.gz').read_bytes()),'capture_compressed_bytes':(PACKAGE/'capture.json.gz').stat().st_size,**counts,'exact_raw_reports':['gcc','clang','build'],'packaging_driver_original':'/tmp/toucan-package-native-conformance.py'};OUTPUT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['capture_verification'],indent=2))
