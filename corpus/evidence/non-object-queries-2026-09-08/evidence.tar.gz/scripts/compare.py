import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('binary', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
root = Path('/home/dev-user/.cache/toucan/void-function-query-probes')
args.output.mkdir(parents=True, exist_ok=True)
rows = []
aliases = {
    'gcc-x64': 'x86_64-unknown-linux-gnu',
    'gcc-arm': 'aarch64-unknown-linux-gnu',
    'gcc': 'x86_64-unknown-linux-gnu',
    'clang-18': 'x86_64-unknown-linux-gnu',
    'gcc-x64-musl': 'x86_64-unknown-linux-musl',
    'gcc-arm-musl': 'aarch64-unknown-linux-musl',
    'clang-arm': 'aarch64-unknown-linux-gnu',
    'clang-mac': 'aarch64-apple-darwin',
    'clang-win': 'x86_64-pc-windows-msvc',
}
for evidence in ['initial.json', 'boundary.json', 'deref.json', 'musl.json', 'function-low.json', 'function-low-targets.json']:
    data = json.loads((root / evidence).read_text())
    for index, native in enumerate(data):
        profile = native.get('profile', native.get('compiler'))
        target = aliases.get(profile, profile.removeprefix('clang-'))
        compiler = 'gcc' if profile.startswith('gcc') else 'clang'
        source = native['source']
        value = native.get('value')
        if value is None and 'unsigned long long answer=' in source and native['status'] == 0:
            match = re.search(r'(?:\.(?:quad|xword)\s+|@answer = .*?global i64 )(\d+)', native['stdout'])
            assert match, native
            value = int(match.group(1))
        if value is not None:
            prefix, expression = source.split('unsigned long long answer=')
            source = prefix + '_Static_assert(' + expression.strip().removesuffix(';') + ' == ' + str(value) + ',"native");\n'
        path = args.output / f'{evidence.removesuffix(".json")}-{index}.c'
        path.write_text(source)
        command = [str(args.binary), 'inspect', str(path), '--checked-code', '--target', target, '--compiler', compiler, '--std', native.get('mode', 'gnu11')]
        output = subprocess.run(command, capture_output=True, text=True, timeout=30)
        row = {'evidence': evidence, 'index': index, 'native_status': native['status'], 'native_value': value, 'status': output.returncode, 'stderr': output.stderr, 'command': command}
        row['match'] = (native['status'] == 0) == (output.returncode == 0)
        rows.append(row)
        if not row['match']:
            print(profile, native.get('mode'), source.strip(), row['stderr'].strip(), flush=True)
report = {'binary_sha256': hashlib.sha256(args.binary.read_bytes()).hexdigest(), 'cases': rows}
(args.output / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
failures = sum(not row['match'] for row in rows)
print(len(rows), 'comparisons,', failures, 'mismatches')
raise SystemExit(bool(failures))
