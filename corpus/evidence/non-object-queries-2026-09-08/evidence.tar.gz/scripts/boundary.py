import json,re,subprocess
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/void-function-query-probes')
operands=[('voidderef','*p','void*p;'),('qualifiedvoidderef','*p','const volatile void*p;'),('aliasedvoidcast','(V)0','typedef void V __attribute__((aligned(32)));'),('aliasfunctionexpr','f','typedef void F(void)__attribute__((aligned(32))); F f;'),('aliasfunctionlower','f','typedef void F(void)__attribute__((aligned(32))); F f __attribute__((aligned(8)));'),('aliasfunctiontype','__typeof__(f)','typedef void F(void)__attribute__((aligned(32))); F f __attribute__((aligned(8)));'),('aliasfunctionderef','*p','typedef void F(void)__attribute__((aligned(32))); F*p;'),('builtinname','__builtin_prefetch',''),('builtincall','__builtin_prefetch((void*)0)',''),('allocationname','__builtin_malloc',''),('freecall','__builtin_free((void*)0)',''),('voidcomma','(p++, (void)0)','int*p;'),('functioncomma','(1,f)','void f(void);')]
rows=[]
for compiler in ['gcc','clang-18']:
 for kind,operand,pre in operands:
  for query in ['sizeof','_Alignof','__alignof__']:
   source=pre+'\nunsigned long long answer='+query+'('+operand+');\n'
   file=root/f'boundary-{len(rows)}.c';file.write_text(source)
   cmd=[compiler,'-std=gnu11','-ffreestanding','-S','-x','c',str(file),'-o','-']
   if compiler.startswith('clang'):cmd.insert(1,'-emit-llvm')
   p=subprocess.run(cmd,capture_output=True,text=True)
   m=re.search(r'@answer = .*?i64 (\d+)',p.stdout) if compiler.startswith('clang') else re.search(r'answer:\s+\.(?:quad|xword)\s+(\d+)',p.stdout)
   rows.append({'compiler':compiler,'kind':kind,'query':query,'source':source,'command':cmd,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'value':int(m[1]) if m else None})
   print(compiler,kind,query,p.returncode,int(m[1]) if m else None)
(root/'boundary.json').write_text(json.dumps(rows,indent=2)+'\n')
