import json,subprocess
from pathlib import Path
p=Path('/home/dev-user/.cache/toucan/void-function-query-probes')
rows=[]
for cc in ['gcc','clang-18']:
 for body in ['*p;','(void)*p;','*p=(void)0;','++*p;','int x=*p;','if(*p){}','&*p;','__typeof__(*p) *q;','sizeof(*p);','_Alignof(*p);','__alignof__(*p);','sizeof((*p,(void)0));','__builtin_prefetch(*p);','(void)sizeof((void)*(int(*)[n++])p);','(void)sizeof(int(int[n++]));']:
  source='void f(volatile void*p,int n){'+body+'}'
  file=p/f'deref-{len(rows)}.c';file.write_text(source)
  cmd=[cc,'-std=gnu11','-fsyntax-only','-x','c',str(file)]
  if cc=='clang-18':cmd.extend(['-Xclang','-ast-dump=json'])
  proc=subprocess.run(cmd,capture_output=True,text=True)
  row={'compiler':cc,'source':source,'command':cmd,'status':proc.returncode,'stdout':proc.stdout,'stderr':proc.stderr};rows.append(row)
  print(cc,body,proc.returncode)
(p/'deref.json').write_text(json.dumps(rows,indent=2)+'\n')
