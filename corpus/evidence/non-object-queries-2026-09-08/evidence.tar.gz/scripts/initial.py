import json,re,subprocess
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/void-function-query-probes')
profiles=[('gcc-x64',['gcc']),('gcc-arm',['/home/dev-user/.cache/toucan/aarch64-gcc-13/usr/bin/aarch64-linux-gnu-gcc-13'])]
for target in ['x86_64-unknown-linux-gnu','aarch64-unknown-linux-gnu','x86_64-apple-darwin','aarch64-apple-darwin','x86_64-pc-windows-msvc','x86_64-unknown-linux-musl','aarch64-unknown-linux-musl']:
 profiles.append(('clang-'+target,['clang-18','--target='+target]))
operands=[('voidtype','void',''),('cvvoidtype','const volatile void',''),('voidvalue','(void)0',''),('voidcall','f()','void f(void);'),('functiontype','void(void)',''),('functionname','f','void f(void);'),('functionderef','*p','void(*p)(void);'),('functionaligned','f','void f(void)__attribute__((aligned(32)));'),('functionalias','F','typedef void F(void);'),('voidalias','V','typedef void V;'),('alignedfunctionalias','F','typedef void F(void)__attribute__((aligned(32)));'),('alignedvoidalias','V','typedef void V __attribute__((aligned(32)));')]
rows=[]
for prof,cc in profiles:
 for mode in ['c90','gnu90','c11','gnu11']:
  for kind,operand,pre in operands:
   for query in ['sizeof','_Alignof','__alignof__']:
    source=pre+'\nunsigned long long answer='+query+'('+operand+');\n'
    file=root/f'{len(rows)}.c';file.write_text(source)
    cmd=[*cc,'-std='+mode,'-ffreestanding','-S','-x','c',str(file),'-o','-']
    if prof.startswith('clang'):cmd.insert(len(cc),'-emit-llvm')
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
    if p.returncode<0 or 'PLEASE submit a bug report' in p.stderr:raise RuntimeError(prof)
    match=re.search(r'@answer = .*?i64 (\d+)',p.stdout) if prof.startswith('clang') else re.search(r'answer:\s+\.(?:quad|xword)\s+(\d+)',p.stdout)
    row={'profile':prof,'mode':mode,'kind':kind,'query':query,'source':source,'command':cmd,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'value':int(match[1]) if match else None}
    rows.append(row)
(root/'initial.json').write_text(json.dumps(rows,indent=2)+'\n')
for kind,_,_ in operands:
 print(kind,{(r['profile'],r['query'],r['status'],r['value']) for r in rows if r['kind']==kind and r['mode']=='gnu11'})
print('cases',len(rows))
