
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals)]
include!("bindings.rs");
unsafe extern "C" fn plain_callback(value: i32) -> i32 { value * 13 }
unsafe extern "win64" fn microsoft_callback(value: i32) -> i32 { value * 17 }
fn main() {
    for value in 0..1000 {
        unsafe {
            assert_eq!(plain_factory(0).unwrap()(value), value * 3 + 1);
            assert_eq!(microsoft_factory(0).unwrap()(value), value * 7 + 2);
            assert_eq!(invoke(Some(plain_callback), value), value * 13 + 5);
            assert_eq!(invoke_microsoft(Some(microsoft_callback), value), value * 17 + 9);
        }
    }
}
