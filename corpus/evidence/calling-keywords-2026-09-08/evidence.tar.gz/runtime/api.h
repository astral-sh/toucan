
typedef int __attribute__((ms_abi)) Microsoft(int);
Microsoft *__cdecl plain_factory(int);
int (__attribute__((ms_abi)) *microsoft_factory(int))(int);
int __cdecl invoke(int (*__cdecl callback)(int), int value);
int invoke_microsoft(Microsoft callback, int value);
