
#include "api.h"
static int plain(int value) { return value * 3 + 1; }
static int __attribute__((ms_abi)) microsoft(int value) { return value * 7 + 2; }
Microsoft *__cdecl plain_factory(int unused) { return plain; }
int (__attribute__((ms_abi)) *microsoft_factory(int unused))(int) { return microsoft; }
int __cdecl invoke(int (*__cdecl callback)(int), int value) { return callback(value) + 5; }
int invoke_microsoft(Microsoft callback, int value) { return callback(value) + 9; }
