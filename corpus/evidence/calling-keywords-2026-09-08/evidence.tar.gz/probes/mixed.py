from pathlib import Path
import itertools
import json
import subprocess

root = Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-syntax')
attributes = ['__cdecl', '__attribute__((ms_abi))', '__attribute__((sysv_abi))']
sources = []
for first, second in itertools.product(attributes, repeat=2):
    for template in [
        'int FIRST SECOND f(int);',
        'int (FIRST *SECOND pointer)(int);',
        'typedef int FIRST M(int); M *SECOND pointer;',
        'typedef int FIRST M(int); M SECOND *pointer;',
        'typedef int (FIRST *M)(int); M SECOND pointer;',
    ]:
        source = template.replace('FIRST', first).replace('SECOND', second)
        sources.append(source)
        if 'pointer' in source:
            for convention in ['ms_abi', 'sysv_abi']:
                sources.append(source + f'typedef int __attribute__(({convention})) Expected(int); _Static_assert(__builtin_types_compatible_p(__typeof__(pointer), Expected *), "call convention");')
results = []
for target in ['x86_64-unknown-linux-gnu', 'x86_64-pc-windows-msvc']:
    command = [str(root/'calling-driver'), target]
    result = subprocess.run(command, input='\n'.join(sources)+'\n', text=True, capture_output=True, check=True)
    frontend = result.stdout.splitlines()
    assert len(frontend) == len(sources)
    for index, source in enumerate(sources):
        command = ['clang', '--target='+target, '-std=gnu11', '-fsyntax-only', '-xc', '-']
        native = subprocess.run(command, input=source, text=True, capture_output=True)
        assert native.returncode >= 0
        ours = frontend[index].split('\t')[1] == 'OK'
        row = {'target': target, 'source': source, 'command': command, 'native_status': native.returncode, 'native_stderr': native.stderr, 'frontend': frontend[index]}
        results.append(row)
        if ours != (native.returncode == 0):
            print(target, 'FALSE ACCEPT' if ours else 'REJECT', source, frontend[index])
(root/'calling-mixed.json').write_text(json.dumps(results, indent=2)+'\n')
print(len(results), 'comparisons')
