import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

repo = Path('/home/dev-user/.codex/worktrees/toucan-msvc-declarations')
cache = Path('/home/dev-user/.cache/toucan/windows-arm64-probes')
output = repo/'corpus/evidence/calling-keywords-2026-09-08'
output.mkdir(parents=True, exist_ok=True)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

files = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=repo, text=True).splitlines()
files += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo, text=True).splitlines()
source = {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
          'files': {name: sha((repo/name).read_bytes()) for name in sorted(set(files)) if not name.startswith('corpus/evidence/')}}
write(output/'source.json', source)

generation = json.loads((cache/'calling-validation/generate.json').read_text())
result = subprocess.run(generation['command'], text=True, capture_output=True, check=True)
generation.update(status=result.returncode, stdout=result.stdout, stderr=result.stderr)
write(cache/'calling-validation/generate.json', generation)

archive = {}
for path in (cache/'calling-validation').iterdir():
    archive['runtime/'+path.name] = path.read_bytes()
for name in ['calling-keywords.json', 'calling-placement.json', 'calling-return-placement.json', 'calling-mixed.json', 'calling-checked.rs', 'calling-checked-expanded-input.txt', 'calling-checked-expanded.json', 'calling-rust164.json']:
    archive['probes/'+name] = (cache/'msvc-syntax'/name).read_bytes()
archive['regression/calling_keywords.rs'] = (repo/'crates/toucan/tests/calling_keywords.rs').read_bytes()
archive['probes/mixed.py'] = Path('/tmp/toucan-calling-mixed.py').read_bytes()
archive['capture.py'] = Path(__file__).read_bytes()
versions = []
for command in [['clang', '--version'], ['rustc', '--version', '--verbose'], ['/home/dev-user/.cache/toucan/msrv-rustup/toolchains/1.64.0-x86_64-unknown-linux-gnu/bin/rustc', '--version', '--verbose']]:
    result = subprocess.run(command, text=True, capture_output=True, check=True)
    versions.append({'command': command, 'stdout': result.stdout, 'stderr': result.stderr})
archive['versions.json'] = (json.dumps(versions, indent=2)+'\n').encode()
stream = io.BytesIO()
with tarfile.open(fileobj=stream, mode='w') as tar:
    for name, data in sorted(archive.items()):
        info = tarfile.TarInfo(name)
        info.mode = 0o644
        info.size = len(data)
        tar.addfile(info, io.BytesIO(data))
(output/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(), mtime=0))
write(output/'files.json', {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(archive.items())})
logs = {}
for name, filename in {
    'workspace': '/tmp/toucan-calling-workspace.log',
    'clippy': '/tmp/toucan-calling-clippy.log',
    'calling-tests': '/tmp/toucan-calling-keyword-tests.log',
    'existing-conventions': '/tmp/toucan-calling-existing-tests.log',
    'rust164': '/tmp/toucan-calling-rust164.log',
    'regeneration': '/tmp/toucan-msvc-calling-regenerate.log',
}.items():
    data = Path(filename).read_bytes()
    (output/(name+'.log.gz')).write_bytes(gzip.compress(data, mtime=0))
    logs[name] = {'bytes': len(data), 'sha256': sha(data)}
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', Path('/tmp/toucan-calling-workspace.log').read_text())
mixed = json.loads((cache/'msvc-syntax/calling-mixed.json').read_text())
for row in mixed:
    assert row['native_status'] in [0, 1]
    assert (row['native_status'] == 0) == (row['frontend'].split('\t')[1] == 'OK')
    assert not any(marker in row['native_stderr'].lower() for marker in ['internal compiler error', 'frontend command failed', 'please submit a bug report', 'llvm error', 'fatal error'])
write(output/'summary.json', {
    'date': '2026-09-08',
    'source_manifest_sha256': sha((output/'source.json').read_bytes()),
    'archive_sha256': sha((output/'evidence.tar.gz').read_bytes()),
    'logs': logs,
    'workspace_reported_executions': {key: sum(int(row[i]) for row in counts) for i, key in enumerate(['passed', 'failed', 'ignored'])},
    'workspace_count_note': 'Reported executions can include child harness output. Ignored tests are not counted as executed; explicit calling-convention oracles run separately.',
    'placement_oracle': {'templates': 18, 'keywords': 5, 'clang_profiles': 5, 'comparisons': 450, 'returned_callback_type_unit': 1, 'differences': 0},
    'mixed_keyword_attribute_oracle': {'comparisons': len(mixed), 'accepted': sum(row['native_status']==0 for row in mixed), 'rejected': sum(row['native_status']!=0 for row in mixed), 'differences': 0},
    'retained_graph': {'pairs': 1378, 'accepted': 1082, 'matching_diagnostics': 296, 'modes': ['c11', 'gnu11'], 'invariants': 'passed'},
    'runtime': {'host': 'x86_64-unknown-linux-gnu', 'c_compiler': 'Clang18.1.3', 'rust_compilers': ['1.64.0', '1.98.1'], 'c_optimization': [0, 2], 'rust_optimization': [0, 3], 'executables': 8, 'rounds_each': 1000, 'assertions_each_round': 4, 'call_conventions': ['System V x64', 'Microsoft x64'], 'generated_rust_minimum': '1.64', 'directions': ['Rust calls C', 'C calls Rust', 'C returns C function pointers to Rust']},
    'limits': ['The runtime host was Linux; no Windows executable or Windows SDK header ran.', 'x86-64 vectorcall and regcall remain explicit unsupported-feature diagnostics. AArch64 ignores these keywords.', 'No benchmark or sanitizer campaign was run for this slice.'],
})
print(json.dumps({'source': sha((output/'source.json').read_bytes()), 'archive': sha((output/'evidence.tar.gz').read_bytes()), 'archive_files': len(archive)}, indent=2))
