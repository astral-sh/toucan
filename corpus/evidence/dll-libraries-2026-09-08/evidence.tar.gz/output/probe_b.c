__declspec(dllexport) int b_value=7;
__declspec(dllexport) int a_special=23;
__declspec(dllexport) int b_function(int x){return b_value*x;}
