int ordinary=5;
