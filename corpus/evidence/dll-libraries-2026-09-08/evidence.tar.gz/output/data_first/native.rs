include!("bindings.rs");
extern "C" {fn c_probe()->i32;}
#[no_mangle]
pub unsafe extern "C" fn entry()->i32 {
    if c_probe()!=0 {return 10;}
    if a_value!=11 || b_value!=7 || a_special!=23 || ordinary!=5 {return 11;}
    if a_function(2)!=13 || b_function(4)!=28 {return 12;}
    if a_address_data()!=core::ptr::addr_of_mut!(a_value) {return 13;}
    match a_address_function() {
        Some(callback) => if callback as usize!=a_function as usize {return 14;},
        None => return 14,
    }
    a_value=17;
    if a_function(2)!=19 {return 15;}
    a_value=11;
    0
}

fn main(){assert_eq!(unsafe{entry()},0);}
