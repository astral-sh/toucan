__declspec(dllimport) int guarded;
