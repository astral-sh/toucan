__declspec(dllimport) extern int first __asm__("shared"); __declspec(dllimport) extern int second __asm__("shared");
