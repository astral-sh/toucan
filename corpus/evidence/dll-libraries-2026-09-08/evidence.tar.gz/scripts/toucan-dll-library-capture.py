from pathlib import Path
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
repo=Path('/home/dev-user/.codex/worktrees/toucan-msvc-dll-library')
cache=Path('/home/dev-user/.cache/toucan/windows-arm64-probes')
out=repo/'corpus/evidence/dll-libraries-2026-09-08';out.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
files=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{p:sha((repo/p).read_bytes()) for p in sorted(set(files)) if not p.startswith('corpus/evidence/')}}
write(out/'source.json',source)
archive={}
root=cache/'dll-library-frozen-output'
artifacts={}
for p in root.rglob('*'):
 if p.is_file():
  key=str(p.relative_to(root));data=p.read_bytes();artifacts[key]={'sha256':sha(data),'bytes':len(data)}
  if p.suffix in {'.json','.c','.h','.rs','.ll'}:archive['output/'+key]=data
write(out/'artifacts.json',artifacts)
for name in ['manifest.json','distinguishing-feature.json','alias.h']:
 archive['frozen-binary/'+name]=(cache/'dll-library-frozen-binaries'/name).read_bytes()
for f in ['crates/toucan/tests/dll_libraries.rs','crates/toucan_cli/tests/dll_libraries.rs','crates/toucan_bindgen/tests/builder.rs','scripts/verify_windows_dll_imports.py']:
 archive['source/'+f]=(repo/f).read_bytes()
for name in ['dll-library-capture','dll-library-existing-outputs']:
 p=Path('/tmp/toucan-'+name+'.py');archive['scripts/'+p.name]=p.read_bytes()
archive['existing/evidence.json']=Path('/home/dev-user/.cache/toucan/dll-library-existing-outputs/evidence.json').read_bytes()
logs={}
for name in ['workspace-final','clippy-final','fuzz-clippy','windows-check-final','frozen-output','existing-outputs','fmt','python','python-format','diff']:
 p=Path('/tmp/toucan-dll-library-'+name+'.log');data=p.read_bytes();archive['logs/'+p.name]=data;logs[name]={'sha256':sha(data),'text':data.decode()}
counts=[tuple(map(int,m)) for m in re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',logs['workspace-final']['text'])]
assert tuple(map(sum,zip(*counts)))==(765,0,199)
for name in ['clippy-final','fuzz-clippy','windows-check-final']:assert 'error:' not in logs[name]['text'] and 'Finished' in logs[name]['text']
assert 'FAILED' not in logs['workspace-final']['text']
native=json.loads((root/'evidence.json').read_text());assert native['status']=='passed' and len(native['cases'])==12 and native['quoted_library_rust_parsing']=='passed' and native['native_execution'] is False
frozen=json.loads((cache/'dll-library-frozen-binaries/manifest.json').read_text());assert frozen['toucan']['sha256']==native['toucan_sha256']
feature=json.loads((cache/'dll-library-frozen-binaries/distinguishing-feature.json').read_text());assert feature['binary_sha256']==native['toucan_sha256'] and 'conflicting library rules' in feature['stderr']
existing=json.loads(archive['existing/evidence.json']);assert existing['binary_sha256']==native['toucan_sha256'] and existing['status']=='passed' and len(existing['rows'])==8
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
 for name,data in sorted(archive.items()):
  info=tarfile.TarInfo(name);info.mode=0o755 if name.endswith('verify_windows_dll_imports.py') else 0o644;info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(),mtime=0))
write(out/'files.json',{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(archive.items())})
write(out/'checks.json',logs)
write(out/'summary.json',{'base':source['base'],'source_manifest_sha256':sha((out/'source.json').read_bytes()),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes()),'frozen_cli':frozen['toucan'],'workspace':{'passed':765,'failed':0,'ignored':199},'clippy':['workspace/all-targets/all-features','fuzz/all-targets'],'windows_native_test_hook':'cross-target cargo check passed; executable not run','configuration':['exact names then longest prefix','last value replaces identical pattern','same linker symbol cannot choose conflicting libraries','unselected and ordinary declarations remain outside DLL blocks','empty/control library names rejected; other strings Rust-escaped'],'coff':{'consumers':12,'header_orders':['data_first','function_first','type_first'],'rustc_versions':['1.64.0','1.98.1'],'optimization_levels':[0,3],'libraries':['probe_a.dll','probe_b.dll'],'imported_data_llvm':'dllimport verified','imported_function_llvm':'dllimport verified','per_library_import_table_membership':'verified','ordinary_object':'linked without DLL import','quoted_library_rust_metadata':'both compiler versions passed','actual_frozen_cli_used':True,'native_execution':False},'existing_binding_outputs':{'count':8,'byte_identical':True,'actual_frozen_cli_used':True},'native_runtime_gate':{'command':'cargo test -p toucan_cli --test dll_libraries native_windows_dll_data_calls_and_addresses -- --ignored --exact','host':'x86_64 Windows','requires':['Clang','llvm-readobj','Python','Rust MSVC toolchain'],'output_env':'TOUCAN_WINDOWS_DLL_OUTPUT','status':'not run locally'},'not_claimed':['native Windows execution','Windows ARM target','performance measurement','sanitizer campaign']})
# Preserve the relevant current test executables alongside the already-probed CLI.
frozen_dir=cache/'dll-library-frozen-binaries'
candidates=[p for p in Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/deps').glob('dll_libraries-*') if p.is_file() and p.suffix=='']
for p in sorted(candidates,key=lambda p:p.stat().st_mtime,reverse=True)[:2]:
 dest=frozen_dir/p.name;shutil.copy2(p,dest);frozen[p.name]={'source':str(p),'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes())}
write(frozen_dir/'manifest.json',frozen)
print(json.dumps({'source_manifest':sha((out/'source.json').read_bytes()),'archive':sha((out/'evidence.tar.gz').read_bytes()),'archive_files':len(archive),'archive_bytes':(out/'evidence.tar.gz').stat().st_size,'frozen_cli':frozen['toucan']['sha256']},indent=2))
