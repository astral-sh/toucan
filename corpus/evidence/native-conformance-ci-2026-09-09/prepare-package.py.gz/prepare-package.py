import gzip
import hashlib
import json
import subprocess
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'package'
REPO = Path('/home/dev-user/code/oss/toucan')
HEAD = 'ca8924413da6fc01e44192f548bef0a18050ffd0'
ARCHIVE = Path('/home/dev-user/.cache/toucan/conformance/c-testsuite-5c7275656d751de0e68b2d340a95b5681858ed07.tar.gz')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def compressed(name, data):
    (PACKAGE / name).write_bytes(gzip.compress(data, mtime=0))

def write_json(name, value):
    (PACKAGE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

capture = {'schema_version': 1, 'contents': {}, 'files': {}, 'excluded_artifacts': {}, 'policy': 'Downloaded source trees, all preprocessed .i files and derived declaration bodies are excluded. Only hashes and byte lengths of excluded payloads are preserved. Own compiler-probe.c, Toucan built-in header strings, recorded diagnostics and upstream origin tags are retained.'}
def add(name, data, excluded=False):
    entry = {'sha256': sha(data), 'bytes': len(data)}
    if excluded:
        capture['excluded_artifacts'][name] = entry
    else:
        capture['contents'][entry['sha256']] = data.decode()
        capture['files'][name] = entry

metadata = {}
for name in ['run', 'jobs', 'artifacts']:
    metadata[name] = json.loads((ROOT / f'{name}.json').read_text())
assert metadata['run']['head_sha'] == HEAD
assert metadata['run']['conclusion'] == 'success'
write_json('metadata.json', metadata)
artifacts = {a['name'].removeprefix('c-testsuite-conformance-'): a for a in metadata['artifacts']['artifacts']}
verification = {'schema_version': 1, 'status': 'pass', 'archive': {'path_at_verification': str(ARCHIVE), 'sha256': sha(ARCHIVE.read_bytes())}, 'profiles': {}}
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for profile in ['gcc', 'clang']:
        archive_data = (ROOT / 'downloads' / f'{profile}.zip').read_bytes()
        assert f'sha256:{sha(archive_data)}' == artifacts[profile]['digest']
        assert len(archive_data) == artifacts[profile]['size_in_bytes']
        with zipfile.ZipFile(ROOT / 'downloads' / f'{profile}.zip') as zipped:
            report_data = zipped.read('evidence.json')
            report = json.loads(report_data)
            compressed(f'{profile}.json.gz', report_data)
            assert verification['archive']['sha256'] == report['manifest']['archive_sha256']
            fixture_inventory = {}
            for case in report['cases']:
                relative = case['source'].split('/corpus/results/conformance/', 1)[1]
                source = zipped.read(relative)
                member = relative.removeprefix('source/')
                with archive.extractfile(member) as file:
                    assert file.read() == source
                assert sha(source) == case['source_sha256']
                fixture_inventory[case['name']] = sha(source)
            assert len(fixture_inventory) == 220
            for name in zipped.namelist():
                if name.endswith('/') or name == 'evidence.json':
                    continue
                excluded = name.startswith('source/') or name.endswith('.i') or name.endswith('native-declarations.txt')
                add(f'{profile}/{name}', zipped.read(name), excluded)
            verification['profiles'][profile] = {'artifact_sha256': sha(archive_data), 'artifact_bytes': len(archive_data), 'source_archive_comparisons': len(fixture_inventory), 'source_hashes': fixture_inventory}
with zipfile.ZipFile(ROOT / 'downloads' / 'logs.zip') as logs:
    for name in logs.namelist():
        if '/' in name and not name.endswith('/'):
            add(f'ci-logs/{name}', logs.read(name))
verification['logs_download'] = {'sha256': sha((ROOT/'downloads/logs.zip').read_bytes()), 'bytes': (ROOT/'downloads/logs.zip').stat().st_size}
paths = ['scripts/audit_c_testsuite.py', 'crates/toucan/examples/audit_translation_unit.rs', '.github/workflows/conformance.yml', 'tools/binding_compare/tests/test_c_testsuite.py', 'corpus/conformance/c-testsuite.json']
source_inventory = {}
for path in paths:
    data = subprocess.check_output(['git', 'show', f'{HEAD}:{path}'], cwd=REPO)
    blob = subprocess.check_output(['git', 'rev-parse', f'{HEAD}:{path}'], cwd=REPO).decode().strip()
    source_inventory[path] = {'sha256': sha(data), 'git_blob': blob, 'bytes': len(data)}
    add(f'tested-git/{path}', data)
write_json('tested-sources.json', {'head_sha': HEAD, 'tree': subprocess.check_output(['git', 'rev-parse', f'{HEAD}^{{tree}}'], cwd=REPO).decode().strip(), 'files': source_inventory})
write_json('artifact-verification.json', verification)
compressed('capture.json.gz', json.dumps(capture, sort_keys=True, separators=(',', ':')).encode())
print(json.dumps({'retained_files': len(capture['files']), 'excluded_files': len(capture['excluded_artifacts']), 'unique_contents': len(capture['contents']), 'payload_bytes': sum(p.stat().st_size for p in PACKAGE.iterdir())}))
