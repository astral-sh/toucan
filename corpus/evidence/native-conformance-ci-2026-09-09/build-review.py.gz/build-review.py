#!/usr/bin/env python3
"""Audit retained CI build logs and Git tree provenance without running compilers."""
import datetime,hashlib,json,pathlib,re,subprocess,zipfile
BASE=pathlib.Path('/tmp/toucan-native-conformance-ci-34394052399')
OUT=BASE/'build-review';OUT.mkdir(exist_ok=True)
REPO=pathlib.Path('/home/dev-user/code/oss/toucan')
HEAD='ca8924413da6fc01e44192f548bef0a18050ffd0';MERGE='97dc7dc9d17bb348a7e7ecebae083c30e8974ef5'
def sha(b):return hashlib.sha256(b).hexdigest()
def check(v,m):
 if not v:raise RuntimeError(m)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
merge_bytes=subprocess.check_output(['/home/dev-user/.local/bin/gh-auto','api','repos/astral-sh/toucan/git/commits/'+MERGE],cwd=REPO)
(OUT/'merge.json').write_bytes(merge_bytes);merge=json.loads(merge_bytes)
head_tree=git('rev-parse',HEAD+'^{tree}').decode().strip()
check(merge['sha']==MERGE and merge['tree']['sha']==head_tree,'tested merge differs from head tree')
check([p['sha'] for p in merge['parents']]==['b6864d8c5356eaef1ebfdf4235f7d1746f74f460',HEAD],'merge parents')
files=['.github/workflows/conformance.yml','scripts/audit_c_testsuite.py','crates/toucan/examples/audit_translation_unit.rs','tools/binding_compare/tests/test_c_testsuite.py','corpus/conformance/c-testsuite.json']
head_files={p:sha(git('show',HEAD+':'+p)) for p in files}
workflow=git('show',HEAD+':.github/workflows/conformance.yml').decode();check('toolchain: "1.96.0"' in workflow,'workflow toolchain')
run=json.loads((BASE/'run.json').read_text());jobs=json.loads((BASE/'jobs.json').read_text())['jobs'];check(run['conclusion']=='success' and run['head_sha']==HEAD and len(jobs)==2,'run conclusion')
command='cargo build --locked --release -p toucan_cli -p toucan --bin toucan --example audit_translation_unit --no-default-features'
profiles={};zip_hashes={}
with zipfile.ZipFile(BASE/'downloads/logs.zip') as z:
 for p in ['gcc','clang']:
  prefix='Pedantic C11 acceptance ('+p+')/'
  def log(number):
   name=next(n for n in z.namelist() if n.startswith(prefix+str(number)+'_'))
   b=z.read(name);zip_hashes[name]=sha(b)
   text=re.sub(r'\x1b\[[0-9;]*m','',b.decode('utf-8-sig'))
   return '\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT[\d:.]+Z ','',l) for l in text.splitlines())
  checkout=log(2);toolchain=log(3);tests=log(5);build=log(6);gate=log(7)
  check('git checkout --progress --force refs/remotes/pull/340/merge' in checkout and '\n'+MERGE in checkout,'actual checkout')
  check('rustup default 1.96.0' in toolchain and 'rustc 1.96.0 (ac68faa20 2026-05-25)' in toolchain and 'release: 1.96.0' in toolchain,'stable compiler')
  check('Ran 14 tests' in tests and '\nOK' in tests,'gate unit tests')
  check(command in build and 'Finished `release` profile [optimized]' in build,'release compilation')
  check('+ohm' not in build and 'RUSTUP_TOOLCHAIN: ohm' not in build and 'CARGO_UNSTABLE_OHM' not in build,'Ohm not present in build')
  compiled=re.findall(r'Compiling (toucan(?:_\w+)?) v0\.0\.1 \(([^\n]+)\)',build)
  check(len(compiled)==11 and len({n for n,_ in compiled})==11,'all workspace build inputs logged')
  for name,path in compiled:check(path=='/home/runner/work/toucan/toucan/crates/'+name,'compile path')
  check('--native-source --native-probe target/release/examples/audit_translation_unit' in gate and '--preprocessor '+p in gate and '--workers 4 --fail-on-strict-difference' in gate,'native gate argv')
  text=gate[gate.index('{\n  "source_count"'):];summary=json.JSONDecoder().raw_decode(text)[0]
  d=json.loads((BASE/(p+'.json')).read_text());check(d['summary']==summary,'logged summary equals uploaded report')
  check(summary['strict_toucan_accepted']==summary['strict_eligible_count']==211 and summary['native_source']['strict_accepted']==summary['native_source']['strict_eligible_count']==211,'211 strict counts')
  check(summary['differences']==summary['native_source']['differences']==['00144.c'],'exploratory difference')
  check(d['runner_sha256']==head_files['scripts/audit_c_testsuite.py'] and d['manifest_sha256']==head_files['corpus/conformance/c-testsuite.json'],'driver/manifest matches tested tree')
  check(d['tools']['native_probe']['protocol_source']['sha256']==head_files['crates/toucan/examples/audit_translation_unit.rs'],'probe source matches tested tree')
  check(d['tools']['toucan']['path']=='/home/runner/work/toucan/toucan/target/release/toucan' and d['tools']['native_probe']['path']=='/home/runner/work/toucan/toucan/target/release/examples/audit_translation_unit','used built binaries')
  job=next(j for j in jobs if j['name']=='Pedantic C11 acceptance ('+p+')')
  check(job['conclusion']=='success' and all(s['conclusion']=='success' for s in job['steps']),'job step outcome')
  profiles[p]={'job_id':job['id'],'job_url':job['html_url'],'runner_labels':job['labels'],'actual_checkout_commit':MERGE,'rustc':'rustc 1.96.0 (ac68faa20 2026-05-25)','llvm':'22.1.2','build_command':command,'release_build_status':'passed','compiled_workspace_packages':sorted(n for n,_ in compiled),'gate_tests_passed':14,'strict_gate_status':'passed','strict_acceptance_per_route':211,'exploratory_difference':['00144.c'],'recorded_cli_sha256':d['tools']['toucan']['sha256'],'recorded_probe_sha256':d['tools']['native_probe']['sha256'],'report_sha256':sha((BASE/(p+'.json')).read_bytes())}
check(profiles['gcc']['recorded_cli_sha256']==profiles['clang']['recorded_cli_sha256'] and profiles['gcc']['recorded_probe_sha256']==profiles['clang']['recorded_probe_sha256'],'binary hash crossjob')
report={'status':'passed','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':run['id'],'run_url':run['html_url'],'pull_request':340,'head_commit':HEAD,'actual_tested_commit':MERGE,'head_tree':head_tree,'tested_tree':merge['tree']['sha'],'tested_tree_equals_head':True,'merge_metadata_file':str(OUT/'merge.json'),'merge_metadata_sha256':sha(merge_bytes),'merge_metadata_url':merge['url'],'head_file_sha256':head_files,'profiles':profiles,'log_file_sha256':zip_hashes,'logs_zip_sha256':sha((BASE/'downloads/logs.zip').read_bytes()),'limitations':['Build-to-source attribution uses successful CI checkout/build logs, exact Git tree identity and recorded driver/probe source hashes. No compiler-artifact JSON, complete post-build source inventory or executable bytes were uploaded for independent reconstruction.','CLI and probe hashes match between both jobs, but reviewer did not obtain or execute those binaries.','This supplement checks stable build provenance and gate outcomes; case protocols and input dependencies are audited separately.'],'compiler_builds_or_git_writes_by_reviewer':False}
(OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['log_file_sha256','profiles']},indent=2))
