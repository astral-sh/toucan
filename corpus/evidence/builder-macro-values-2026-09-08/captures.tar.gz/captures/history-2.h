#define VALUE 20
#undef VALUE
