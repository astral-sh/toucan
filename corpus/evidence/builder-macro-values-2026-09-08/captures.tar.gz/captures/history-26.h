#define VALUE ((unsigned) -1)
#define OTHER VALUE
