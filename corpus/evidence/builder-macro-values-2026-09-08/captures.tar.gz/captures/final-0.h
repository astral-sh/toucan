#define Known 9
#define A 7
#undef A
#define A(Known)
#define Alias A
