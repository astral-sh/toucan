#define INC(x) ((x)+1)
#define VALUE INC(2)
