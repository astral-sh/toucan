#define A 1
#undef A
#define B A
