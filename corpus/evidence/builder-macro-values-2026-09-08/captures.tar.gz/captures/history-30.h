#define A "hello"
#define B A
#undef A
#define A "bye"
#define C B
#define D A
