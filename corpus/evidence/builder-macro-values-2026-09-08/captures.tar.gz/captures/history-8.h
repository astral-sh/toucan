#define A B
#define B 2
#define C A
