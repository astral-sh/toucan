#define VALUE
#undef VALUE
#define VALUE 11
