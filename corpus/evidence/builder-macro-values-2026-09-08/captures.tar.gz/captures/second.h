#line 900 "logical.h"
#undef VALUE
#define VALUE 2
#define ALIAS VALUE
#undef RECOVER
#define RECOVER 3
#define INSIDE OUTSIDE
