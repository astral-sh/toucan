#define A 1
#define B A
#undef A
#define A 2
#define C B
#define D A
