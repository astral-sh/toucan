#define A B
#define B 2
#undef A
#define A B
#define C A
