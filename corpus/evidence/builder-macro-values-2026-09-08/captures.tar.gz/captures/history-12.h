#define VALUE missing
#undef VALUE
#define VALUE 11
