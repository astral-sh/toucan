#define VALUE 1
#define RECOVER unknown
#define OUTSIDE 5
