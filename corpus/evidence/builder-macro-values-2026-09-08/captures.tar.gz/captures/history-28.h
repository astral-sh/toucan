#define VALUE sizeof(int)
#define OTHER VALUE
