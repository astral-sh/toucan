#define A "hello"
#define B A " world"
