#define A 1
#undef A
#define A (A+1)
#define B A
