#define A missing
#undef A
#define A 9
#define B A
