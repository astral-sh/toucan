from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

ROOT = Path('/home/dev-user/code/oss/toucan')
OUT = Path('/home/dev-user/.cache/toucan/builder-macro-integration-probes')
OUT.mkdir(exist_ok=True)
ENV = dict(os.environ, LIBCLANG_PATH='/usr/lib/llvm-18/lib')
for key in tuple(ENV):
    if key.startswith('BINDGEN_EXTRA_CLANG_ARGS'):
        del ENV[key]
COMMANDS = []

def run(cmd):
    started = time.monotonic()
    result = subprocess.run([str(x) for x in cmd], cwd=OUT, env=ENV, text=True, capture_output=True, timeout=90)
    COMMANDS.append(dict(command=[str(x) for x in cmd], returncode=result.returncode,
                         stdout=result.stdout, stderr=result.stderr, seconds=time.monotonic()-started))
    (OUT/'commands.json').write_text(json.dumps(COMMANDS, indent=2)+'\n')
    if result.returncode:
        raise RuntimeError(COMMANDS[-1])
    return result.stdout

DRIVER = r'''
use generator::{Builder, Formatter, MacroTypeVariation, RustTarget};
#[derive(Debug)]
struct Callbacks;
impl generator::callbacks::ParseCallbacks for Callbacks {}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut builder = Builder::default().header(&args[1])
        .formatter(Formatter::None).layout_tests(false)
        .rust_target(RustTarget::stable(64, 0).unwrap())
        .default_macro_constant_type(args[3].parse::<MacroTypeVariation>().unwrap())
        .fit_macro_constants(args[4] == "true");
    if args[5] == "true" { builder = builder.parse_callbacks(Box::new(Callbacks)); }
    if args[6] != "-" { builder = builder.allowlist_file(&args[6]); }
    builder = builder.clang_args(&args[7..]);
    let bindings = builder.generate().unwrap();
    bindings.write_to_file(&args[2]).unwrap();
    #[cfg(candidate)]
    std::fs::write(format!("{}.report", args[2]), format!("{:#?}", bindings.report())).unwrap();
}
'''
(OUT/'driver.rs').write_text(DRIVER)
CANDIDATE = max((ROOT/'target/debug/deps').glob('libtoucan_bindgen-*.rlib'), key=lambda p:p.stat().st_mtime_ns)
REFERENCE = Path('/home/dev-user/.cache/toucan/aws-lc-policy-target/release/deps/libbindgen-fc863aeb5d40a0a9.rlib')
for side, lib in [('candidate', CANDIDATE), ('reference', REFERENCE)]:
    run(['rustc', '--edition=2021', '--cfg', side, OUT/'driver.rs', '--extern', f'generator={lib}', '-L', f'dependency={lib.parent}', '-o', OUT/side])

PRELUDE = r'''
#![allow(dead_code, non_camel_case_types, non_snake_case, non_upper_case_globals)]
trait Capture { fn capture(&self) -> String; }
macro_rules! ints { ($($ty:ty),*) => { $(impl Capture for $ty { fn capture(&self) -> String { self.to_string() } })* }; }
ints!(i8, u8, i16, u16, i32, u32, i64, u64, i128, u128, usize, isize);
impl Capture for f64 { fn capture(&self) -> String { if self.is_nan() { "NaN".into() } else { format!("{:016x}", self.to_bits()) } } }
impl<const N: usize> Capture for &[u8; N] { fn capture(&self) -> String { format!("{:?}", self) } }
fn print<T: Capture>(name: &str, value: T) { println!("{}|{}|{}", name, std::any::type_name::<T>(), value.capture()); }
'''
RUSTC = {'current':shutil.which('rustc'), '1.64':'/home/dev-user/.cache/toucan/msrv-rustup/toolchains/1.64.0-x86_64-unknown-linux-gnu/bin/rustc'}
ROWS = []

def compare(name, header, *, signed='unsigned', fit=False, callbacks=False, selected='-', args=(), compilers=('current',)):
    sources = {}
    outputs = {}
    for side in ['candidate', 'reference']:
        output = OUT/f'{name}-{side}.rs'
        run([OUT/side, header, output, signed, str(fit).lower(), str(callbacks).lower(), selected,
             '--target=x86_64-unknown-linux-gnu', '-std=gnu11', *args])
        sources[side] = output.read_text()
        names = sorted(re.findall(r'pub\s+const\s+(\w+)\s*:', sources[side]))
        consumer = OUT/f'{name}-{side}-consumer.rs'
        consumer.write_text(PRELUDE + f'#[path={json.dumps(str(output))}] mod bindings;\nfn main() {{\n' +
            ''.join(f'print("{item}", bindings::{item});\n' for item in names) + '}\n')
        outputs[side] = {}
        for compiler in compilers:
            binary = OUT/f'{name}-{side}-{compiler}'
            run([RUSTC[compiler], '--edition=2021', '--crate-name', 'macro_consumer', '-Dwarnings', consumer, '-o', binary])
            outputs[side][compiler] = run([binary])
    same = outputs['candidate'] == outputs['reference']
    ROWS.append(dict(name=name, header=str(header), signed=signed, fit=fit, callbacks=callbacks,
                     selected=selected, args=list(args), outputs=outputs, equivalent=same,
                     constants={k:len(re.findall(r'pub\s+const\s+\w+\s*:',v)) for k,v in sources.items()}))
    (OUT/'comparison.json').write_text(json.dumps(ROWS, indent=2)+'\n')
    print(name, 'MATCH' if same else 'DIFFERENT', flush=True)
    if not same:
        raise RuntimeError(ROWS[-1])

boundary = [-9223372036854775808,-2147483649,-2147483648,-32769,-32768,-129,-128,-1,0,127,128,255,256,32767,32768,65535,65536,2147483647,2147483648,4294967295,4294967296,9223372036854775807]
scalar = OUT/'scalars.h'
scalar.write_text(''.join(f'#define INTEGER_{index} ({value})\n' for index,value in enumerate(boundary)) + r'''
#define SUFFIX 1ULL
#define WRAPPED 18446744073709551615ULL
#define NEGATIVE_UNSIGNED (-1ULL)
#define FLOAT 1.25f
#define NEGATIVE_ZERO (-0.0)
#define INFINITY_VALUE (1e308 * 1e308)
#define TEXT "alpha" "\0omega"
#define CHARACTER 'A'
#define RAW_BYTE '\xff'
''')
for signed in ['unsigned','signed']:
    for fit in [False,True]:
        compare(f'scalars-{signed}-{fit}', scalar, signed=signed, fit=fit, compilers=('current','1.64'))

history = json.loads(Path('/home/dev-user/.cache/toucan/macro-history-reference-probes/report.json').read_text())['rows']
final = json.loads(Path('/home/dev-user/.cache/toucan/macro-compat-evaluator-probes/final-function-reference.json').read_text())
for family, rows in [('history',history),('final',final)]:
    for index,row in enumerate(rows):
        header = OUT/f'{family}-{index}.h'
        header.write_text(row['source'])
        compare(f'{family}-{index}', header, callbacks=row.get('callback',row.get('callbacks',False)))

first, second, wrapper = (OUT/name for name in ['first.h','second.h','root.h'])
first.write_text('#define VALUE 1\n#define RECOVER unknown\n#define OUTSIDE 5\n')
second.write_text('#line 900 "logical.h"\n#undef VALUE\n#define VALUE 2\n#define ALIAS VALUE\n#undef RECOVER\n#define RECOVER 3\n#define INSIDE OUTSIDE\n')
wrapper.write_text('#include "first.h"\n#include "second.h"\n')
for part in ['first','second','logical','absent']:
    compare(f'file-{part}', wrapper, selected=rf'.*[/\\]{part}\.h', compilers=('current','1.64'))
configured = OUT/'configured-context.h'
configured.write_text('#if INPUT != 7\n#error missing input\n#endif\n#define ALIAS INPUT\n#define LITERAL 7\n')
compare('configured-context', configured, args=('-DINPUT=7',), compilers=('current','1.64'))

identity = {'candidate_parent':'9d06730', 'compilers':{k:run([v,'--version','--verbose']) for k,v in RUSTC.items()},
            'libraries':{side:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for side,p in [('candidate',CANDIDATE),('reference',REFERENCE)]},
            'executables':{side:hashlib.sha256((OUT/side).read_bytes()).hexdigest() for side in ['candidate','reference']},
            'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'crates').rglob('*.rs')},
            'libclang':'/usr/lib/llvm-18/lib','comparison_rows':len(ROWS), 'matched':sum(x['equivalent'] for x in ROWS)}
(OUT/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copyfile(__file__,OUT/'run.py')
print(json.dumps({'rows':len(ROWS),'matched':sum(x['equivalent'] for x in ROWS)}),flush=True)
