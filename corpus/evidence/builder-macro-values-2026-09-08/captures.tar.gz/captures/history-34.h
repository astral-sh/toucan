#define A 1.5f
#define B A
#undef A
#define A 2.5f
#define C B
