#define VALUE 10
#undef VALUE
#define VALUE(x) (x)
#define OTHER VALUE
