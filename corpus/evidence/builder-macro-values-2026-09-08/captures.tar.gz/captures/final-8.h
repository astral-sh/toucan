#define Known 9
#define A(Known)
#undef A
#define A 11
#undef A
#define Alias A
