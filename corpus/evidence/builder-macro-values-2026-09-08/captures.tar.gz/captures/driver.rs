
use generator::{Builder, Formatter, MacroTypeVariation, RustTarget};
#[derive(Debug)]
struct Callbacks;
impl generator::callbacks::ParseCallbacks for Callbacks {}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mut builder = Builder::default().header(&args[1])
        .formatter(Formatter::None).layout_tests(false)
        .rust_target(RustTarget::stable(64, 0).unwrap())
        .default_macro_constant_type(args[3].parse::<MacroTypeVariation>().unwrap())
        .fit_macro_constants(args[4] == "true");
    if args[5] == "true" { builder = builder.parse_callbacks(Box::new(Callbacks)); }
    if args[6] != "-" { builder = builder.allowlist_file(&args[6]); }
    builder = builder.clang_args(&args[7..]);
    let bindings = builder.generate().unwrap();
    bindings.write_to_file(&args[2]).unwrap();
    #[cfg(candidate)]
    std::fs::write(format!("{}.report", args[2]), format!("{:#?}", bindings.report())).unwrap();
}
