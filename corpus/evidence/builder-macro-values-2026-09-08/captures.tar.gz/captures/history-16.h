#define VALUE(x) (x)
#undef VALUE
#define VALUE 11
