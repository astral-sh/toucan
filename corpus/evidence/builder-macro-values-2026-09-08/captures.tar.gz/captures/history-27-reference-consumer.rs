
#![allow(dead_code, non_camel_case_types, non_snake_case, non_upper_case_globals)]
trait Capture { fn capture(&self) -> String; }
macro_rules! ints { ($($ty:ty),*) => { $(impl Capture for $ty { fn capture(&self) -> String { self.to_string() } })* }; }
ints!(i8, u8, i16, u16, i32, u32, i64, u64, i128, u128, usize, isize);
impl Capture for f64 { fn capture(&self) -> String { if self.is_nan() { "NaN".into() } else { format!("{:016x}", self.to_bits()) } } }
impl<const N: usize> Capture for &[u8; N] { fn capture(&self) -> String { format!("{:?}", self) } }
fn print<T: Capture>(name: &str, value: T) { println!("{}|{}|{}", name, std::any::type_name::<T>(), value.capture()); }
#[path="/home/dev-user/.cache/toucan/builder-macro-integration-probes/history-27-reference.rs"] mod bindings;
fn main() {
}
