enum E{VALUE=4};
#define OTHER VALUE
#define VALUE VALUE
