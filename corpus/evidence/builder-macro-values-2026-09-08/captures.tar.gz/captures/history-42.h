#define A (0 && unknown)
#define B (1 || unknown)
#define C (1 ? 3 : unknown)
