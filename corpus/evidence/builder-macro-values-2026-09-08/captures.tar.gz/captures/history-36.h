#define VALUE 10
#define VALUE 11
#define OTHER VALUE
