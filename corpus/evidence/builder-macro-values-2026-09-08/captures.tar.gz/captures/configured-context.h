#if INPUT != 7
#error missing input
#endif
#define ALIAS INPUT
#define LITERAL 7
