#define VALUE() 10
#undef VALUE
#define VALUE 11
