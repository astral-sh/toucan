
#![allow(dead_code, non_camel_case_types, non_snake_case, non_upper_case_globals)]
trait Capture { fn capture(&self) -> String; }
macro_rules! ints { ($($ty:ty),*) => { $(impl Capture for $ty { fn capture(&self) -> String { self.to_string() } })* }; }
ints!(i8, u8, i16, u16, i32, u32, i64, u64, i128, u128, usize, isize);
impl Capture for f64 { fn capture(&self) -> String { if self.is_nan() { "NaN".into() } else { format!("{:016x}", self.to_bits()) } } }
impl<const N: usize> Capture for &[u8; N] { fn capture(&self) -> String { format!("{:?}", self) } }
fn print<T: Capture>(name: &str, value: T) { println!("{}|{}|{}", name, std::any::type_name::<T>(), value.capture()); }
#[path="/home/dev-user/.cache/toucan/builder-macro-integration-probes/scalars-signed-True-reference.rs"] mod bindings;
fn main() {
print("CHARACTER", bindings::CHARACTER);
print("FLOAT", bindings::FLOAT);
print("INFINITY_VALUE", bindings::INFINITY_VALUE);
print("INTEGER_0", bindings::INTEGER_0);
print("INTEGER_1", bindings::INTEGER_1);
print("INTEGER_10", bindings::INTEGER_10);
print("INTEGER_11", bindings::INTEGER_11);
print("INTEGER_12", bindings::INTEGER_12);
print("INTEGER_13", bindings::INTEGER_13);
print("INTEGER_14", bindings::INTEGER_14);
print("INTEGER_15", bindings::INTEGER_15);
print("INTEGER_16", bindings::INTEGER_16);
print("INTEGER_17", bindings::INTEGER_17);
print("INTEGER_18", bindings::INTEGER_18);
print("INTEGER_19", bindings::INTEGER_19);
print("INTEGER_2", bindings::INTEGER_2);
print("INTEGER_20", bindings::INTEGER_20);
print("INTEGER_21", bindings::INTEGER_21);
print("INTEGER_3", bindings::INTEGER_3);
print("INTEGER_4", bindings::INTEGER_4);
print("INTEGER_5", bindings::INTEGER_5);
print("INTEGER_6", bindings::INTEGER_6);
print("INTEGER_7", bindings::INTEGER_7);
print("INTEGER_8", bindings::INTEGER_8);
print("INTEGER_9", bindings::INTEGER_9);
print("NEGATIVE_UNSIGNED", bindings::NEGATIVE_UNSIGNED);
print("NEGATIVE_ZERO", bindings::NEGATIVE_ZERO);
print("RAW_BYTE", bindings::RAW_BYTE);
print("SUFFIX", bindings::SUFFIX);
print("TEXT", bindings::TEXT);
print("WRAPPED", bindings::WRAPPED);
}
