#define A __GNUC__
#define B __SIZEOF_POINTER__
#define C __LINE__
#define D __FILE__
