#define Known 9
#define A(Known)
#undef A
#define Alias A
