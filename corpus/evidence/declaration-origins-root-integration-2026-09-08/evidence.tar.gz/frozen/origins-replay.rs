use toucan::{CompilerProfile,LanguageMode,Config};
use toucan::semantic::DeclarationTarget;
fn main(){
 let mut cases=Vec::new();
 for directory in std::env::args().skip(1){for file in std::fs::read_dir(directory).unwrap(){let path=file.unwrap().path();if path.is_file(){if let Ok(source)=std::fs::read_to_string(&path){cases.push((path,source));}}}}
 cases.sort_by(|a,b|a.0.cmp(&b.0));let mut accepted=0usize;let mut rejected=0usize;let mut origins=0usize;
 toucan::semantic::with_parser_stack(||{for (path,source) in &cases {for profile in CompilerProfile::ALL {for mode in LanguageMode::ALL {
 let mut config=Config::with_profile(profile.with_language_mode(mode));let a=toucan::parse_source(path,source,&config);
 config.analysis.retain_declaration_origins=true;config.preprocessor.record_file_origins=true;let b=toucan::parse_source(path,source,&config);
 match(a,b){(Ok(a),Ok(b))=>{accepted+=1;assert_eq!(format!("{:?}",a.unit()),format!("{:?}",b.unit()),"{} {profile:?} {mode:?}",path.display());assert_eq!(a.preprocessed().source,b.preprocessed().source);assert_eq!(a.preprocessed().macros,b.preprocessed().macros);let rows=b.declaration_origins().unwrap().entries();origins+=rows.len();assert!(rows.windows(2).all(|x|x[0].source().range().start<=x[1].source().range().start));for o in rows {let r=o.source().range();assert!(r.start<=r.end && r.end<=b.preprocessed().source.len());assert!(b.preprocessed().source.is_char_boundary(r.start)&&b.preprocessed().source.is_char_boundary(r.end));assert!(!(o.is_reference()&&o.is_definition()));match o.target(){DeclarationTarget::Declaration(id)=>{assert!(id<b.unit().declarations.len());},DeclarationTarget::Record(id)=>{assert!(id<b.unit().records.len());},DeclarationTarget::Enum(id)=>{assert!(id<b.unit().enums.len());},DeclarationTarget::Enumerator{enumeration,variant}=>{assert!(variant<b.unit().enums[enumeration].variants.len());},_=>panic!("unknown target")}}},(Err(a),Err(b))=>{rejected+=1;assert_eq!(a.to_string(),b.to_string(),"{} {profile:?} {mode:?}",path.display());},_=>panic!("parity {} {profile:?} {mode:?}",path.display())}
 }}}}).unwrap();println!("cases={} accepted={accepted} rejected={rejected} origins={origins}",cases.len());
}
