from pathlib import Path
import json,subprocess,re,hashlib
root=Path('/home/dev-user/code/oss/toucan');out=Path('/home/dev-user/.cache/toucan/feature-catalog-probes');out.mkdir(exist_ok=True)
texts='\n'.join(p.read_text() for p in (root/'crates/toucan_semantic/src').rglob('*.rs'))
names=sorted(set(re.findall(r'\b(__(?:builtin|atomic|c11_atomic|sync)_[A-Za-z0-9_]+)\b',texts)))
attributes=(root/'crates/toucan_semantic/src/attributes.rs').read_text().split('pub fn has_attribute',1)[0]
attrs=sorted(set(re.findall(r'"([a-z0-9_]+)"',attributes)))
entries=[('b',name) for name in names]+[('a',name) for name in attrs]
driver=out/'driver.rs';driver.write_text('''use std::io::Read;
fn main(){let args=std::env::args().collect::<Vec<_>>();let profile=toucan::CompilerProfile::ALL[args[1].parse::<usize>().unwrap()].with_language_mode(args[2].parse().unwrap());let mut s=String::new();std::io::stdin().read_to_string(&mut s).unwrap();for(i,l)in s.lines().enumerate(){let(k,n)=l.split_once(' ').unwrap();let value=if k=="b"{u64::from(toucan::semantic::has_builtin(profile,n))}else{toucan::semantic::has_attribute(profile,n)};println!("q{i} {value}");}}
''')
lib=max((root/'target/debug/deps').glob('libtoucan-*.rlib'),key=lambda p:p.stat().st_mtime)
subprocess.run(['rustc','--edition=2024',str(driver),'--extern','toucan='+str(lib),'-L','dependency='+str(root/'target/debug/deps'),'-o',str(out/'driver')],check=True)
profiles=[('gcc-x64',['gcc']),('gcc-arm',['/home/dev-user/.cache/toucan/aarch64-gcc-13/usr/bin/aarch64-linux-gnu-gcc-13','-B/home/dev-user/.cache/toucan/aarch64-gcc-13/usr/lib/gcc-cross/aarch64-linux-gnu/13'])]+[('clang-'+t,['clang','--target='+t]) for t in ['x86_64-apple-darwin','aarch64-apple-darwin','x86_64-pc-windows-msvc','x86_64-unknown-linux-gnu','aarch64-unknown-linux-gnu']]
csource='\n'.join(f'q{i} '+('__has_builtin' if kind=='b' else '__has_attribute')+f'({name})' for i,(kind,name) in enumerate(entries))+'\n';rustinput='\n'.join(k+' '+n for k,n in entries)+'\n';rows=[];mismatches=[]
for i,(profile,cc) in enumerate(profiles):
 for mode in ('c11','gnu11'):
  command=cc+['-E','-P','-x','c','-std='+mode,'-'];n=subprocess.run(command,input=csource,text=True,capture_output=True,timeout=15);assert n.returncode==0,n.stderr
  ourcmd=[str(out/'driver'),str(i),mode];o=subprocess.run(ourcmd,input=rustinput,text=True,capture_output=True,check=True)
  native={int(k):int(v) for k,v in re.findall(r'q(\d+)\s+(\d+)',n.stdout)};ours={int(k):int(v) for k,v in re.findall(r'q(\d+)\s+(\d+)',o.stdout)};assert len(native)==len(ours)==len(entries)
  for j,(kind,name) in enumerate(entries):
   if ours[j] and not native[j]:mismatches.append((profile,mode,kind,name,ours[j],native[j]))
  rows.append({'profile':profile,'mode':mode,'command':command,'native_stdout':n.stdout,'native_stderr':n.stderr,'toucan_command':ourcmd,'toucan_stdout':o.stdout,'advertised':sum(bool(v) for v in ours.values()),'unadvertised_native':sum(bool(native[j]) and not ours[j] for j in ours)})
r={'schema_version':1,'c_source':csource,'entries':entries,'rows':rows,'false_positive_claims':mismatches,'versions':{p:subprocess.check_output(cc+['--version'],text=True) for p,cc in profiles},'source_sha256':hashlib.sha256(csource.encode()).hexdigest()}
(out/'availability.json').write_text(json.dumps(r,indent=2)+'\n');print('entries',len(entries),'comparisons',len(entries)*len(rows),'false_positives',mismatches)
