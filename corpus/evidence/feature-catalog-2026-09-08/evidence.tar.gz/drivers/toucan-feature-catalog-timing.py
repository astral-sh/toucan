import hashlib,json,os,platform,random,statistics,subprocess,time
from pathlib import Path
cache=Path('/home/dev-user/.cache/toucan'); out=cache/'feature-catalog-probes'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
bins={k:str(cache/f'feature-catalog{suffix}-target/release/toucan') for k,suffix in [('baseline','-baseline'),('changed','')]}
hashes={k:sha(p) for k,p in bins.items()}; randomizer=random.Random(20260908); projects={}
for name in ['zlib','sqlite','zstd','libgit2']:
    old=json.loads((cache/f'benchmarks-bb6a401/{name}.json').read_text()); deps={p:sha(p) for p in old['dependency_sha256']}; samples={k:[] for k in bins}; commands={k:[p,*old['commands']['toucan'][1:]] for k,p in bins.items()}; outputs=set()
    for i in range(-1,7):
        order=list(bins); randomizer.shuffle(order)
        for position,k in enumerate(order):
            start=time.perf_counter_ns(); p=subprocess.run(commands[k],capture_output=True,timeout=60,check=True); elapsed=(time.perf_counter_ns()-start)/1e6; digest=hashlib.sha256(p.stdout).hexdigest(); outputs.add(digest)
            samples[k].append(dict(iteration=i,position=position,wall_ms=elapsed,sha256=digest,stderr=p.stderr.decode()))
    assert len(outputs)==1 and deps=={p:sha(p) for p in deps}
    projects[name]=dict(commands=commands,dependencies=deps,samples=samples,output_sha256=next(iter(outputs)),median_ms={k:statistics.median(s['wall_ms'] for s in rows if s['iteration']>=0) for k,rows in samples.items()})
    print(name,projects[name]['median_ms'],flush=True)
assert hashes=={k:sha(p) for k,p in bins.items()}
(out/'timings.json').write_text(json.dumps(dict(baseline_commit='d7ba4de',changed_base='1be727f',binary_sha256=hashes,affinity=sorted(os.sched_getaffinity(0)),platform=platform.platform(),seed=20260908,qualification='Warm CLI subprocess timings on a shared host; other agents were active. Seven measured pairs and one discarded warmup per tool. This is a change regression comparison, not an in-process bindgen comparison.',projects=projects),indent=2)+'\n')
