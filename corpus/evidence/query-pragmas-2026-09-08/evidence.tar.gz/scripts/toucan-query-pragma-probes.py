from pathlib import Path
import subprocess,json
out=Path('/home/dev-user/.cache/toucan/query-pragma-probes');out.mkdir(exist_ok=True)
rows=[]
for compiler in ['gcc','clang']:
 for pragma in ['pack(1)','once','GCC diagnostic push','message("query")']:
  for query in ['__has_attribute','__has_c_attribute','__has_feature']:
   for context in ['initializer','condition','dead_condition','wrapper_initializer']:
    operand='c_atomic' if query=='__has_feature' else 'aligned'
    literal=json.dumps(pragma)
    prefix=f'#define ARG _Pragma({literal}) {operand}\n'
    if context=='initializer': source=prefix+f'int value = {query}(ARG);\n'
    elif context=='wrapper_initializer': source=prefix+f'#define W(x) {query}(x)\nint value = W(ARG);\n'
    else: source=prefix+f'#if '+('0 && ' if context=='dead_condition' else '')+f'{query}(ARG)\nint value=1;\n#else\nint value=0;\n#endif\n'
    for operation in ['compile','preprocess']:
     command=[compiler,'-std=gnu11','-x','c',*(['-fsyntax-only'] if operation=='compile' else ['-E','-P']),'-']
     p=subprocess.run(command,input=source,text=True,capture_output=True,timeout=10)
     crash=any(x in p.stderr for x in ['PLEASE submit a bug report','internal compiler error','frontend command failed']) or p.returncode<0
     rows.append(dict(compiler=compiler,pragma=pragma,query=query,context=context,operation=operation,source=source,command=command,status=p.returncode,crash=crash,stdout=p.stdout,stderr=p.stderr))
(out/'compile-vs-preprocess.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 if r['operation']=='compile': print(r['compiler'],r['pragma'],r['query'],r['context'],r['status'],'crash' if r['crash'] else '')
