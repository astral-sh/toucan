from pathlib import Path
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
repo=Path('/home/dev-user/.codex/worktrees/toucan-query-pragmas')
cache=Path('/home/dev-user/.cache/toucan/query-pragma-probes')
out=repo/'corpus/evidence/query-pragmas-2026-09-08'
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
logs={name:Path('/tmp/toucan-query-pragmas-'+name+'.log').read_bytes() for name in ['all-native','gcc14','clippy','fmt','diff']}
counts=[tuple(map(int,x)) for x in re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',logs['all-native'].decode())]
assert tuple(map(sum,zip(*counts))) == (68,0,0)
assert b'2368 native C query/pragma acceptance comparisons' in logs['all-native']
assert b'2368 native C query/pragma acceptance comparisons' in logs['gcc14']
assert b'6 passed; 0 failed; 0 ignored' in logs['gcc14']
assert b'error:' not in logs['clippy'] and b'Finished' in logs['clippy']
assert not logs['fmt'] and not logs['diff']
out.mkdir(parents=True,exist_ok=True)
files=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{name:sha((repo/name).read_bytes()) for name in sorted(set(files)) if not name.startswith('corpus/evidence/')}}
write(out/'source.json',source)
archive={'logs/'+name+'.log':data for name,data in logs.items()}
for name in ['compile-vs-preprocess','handlers']:
 archive['native-probes/'+name+'.json']=(cache/(name+'.json')).read_bytes()
for name in source['files']: archive['source/'+name]=(repo/name).read_bytes()
for name in ['query-pragma-probes','query-pragmas-capture']:
 p=Path('/tmp/toucan-'+name+'.py');archive['scripts/'+p.name]=p.read_bytes()
versions={compiler:subprocess.check_output([compiler,'--version'],text=True) for compiler in ['gcc','clang','/home/dev-user/.cache/toucan/gcc14-parameter-probe/gcc14']}
archive['versions.json']=(json.dumps(versions,indent=2)+'\n').encode()
primary={name:{'sha256':sha((cache/name).read_bytes()),'url':'https://raw.githubusercontent.com/llvm/llvm-project/llvmorg-18.1.3/clang/lib/'+('Lex/' if name=='Pragma.cpp' else 'Parse/')+name} for name in ['Pragma.cpp','ParsePragma.cpp']}
archive['primary-sources.json']=(json.dumps(primary,indent=2)+'\n').encode()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
 for name,data in sorted(archive.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(),mtime=0))
write(out/'files.json',{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(archive.items())})
write(out/'summary.json',{'base':source['base'],'source_manifest_sha256':sha((out/'source.json').read_bytes()),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes()),'tests':{'preprocessor_all_native':68,'failed':0,'ignored':0,'new_native_group':6,'existing_operator_comparisons':5880,'existing_command_line_overrides':20,'new_handler_source_compilation_comparisons_per_run':2368,'native_runs':['GCC13 and Clang18','GCC14 and Clang18'],'accepted_sources':'Also preprocessed, compared under the library policy for discarded diagnostic/message/system-header/empty pragmas, then Toucan output compiled.','once_effect':'Repeated real header inclusion matches virtual-header preprocessing; original and generated C compile.','identity_override_cases':4},'checks':['All-target/all-feature PP Clippy','cargo fmt --all --check','git diff --check'],'contract':['Expanded supported directives retain their effect and output position.','Raw queries and raw scope lookahead reject deferred pragma tokens.','Conditional pragma rules use configured QueryDialect independently of identity macro overrides, with legacy standalone fallback when no dialect is configured.'],'remaining':['pack in query arguments remains explicitly unsupported.','Compiler-specific annotation handling outside this supported pragma subset remains outside this layer.'],'native_failure':'Clang18 compilation of pack inside expanding queries crashes after its malformed-query diagnostic; retained as tool failure, never counted as source rejection. Preprocessing-only acceptance is recorded separately.','not_claimed':['Full preprocessing-only parity for pack query arguments','Native Windows or macOS execution','Performance measurements','Sanitizer campaign']})
frozen=cache/'frozen-binaries';frozen.mkdir(exist_ok=True)
path=Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/deps/query_pragmas-40576d083c650037')
shutil.copy2(path,frozen/path.name)
write(frozen/'manifest.json',{path.name:{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}})
print(json.dumps({'source_manifest':sha((out/'source.json').read_bytes()),'archive':sha((out/'evidence.tar.gz').read_bytes()),'archive_bytes':(out/'evidence.tar.gz').stat().st_size,'files':len(archive),'binary_sha256':sha(path.read_bytes())},indent=2))
