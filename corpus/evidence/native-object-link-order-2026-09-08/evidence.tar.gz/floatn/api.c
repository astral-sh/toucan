
typedef _Float32 F32; typedef _Float64 F64; typedef _Float32x F32x;
struct Pair {F32 a;F64 b;};
F32 sum32(F32,F32);F64 sum64(F64,F64);F32x sum32x(F32x,F32x);
F32 stack32(F32,F32,F32,F32,F32,F32,F32,F32,F32,F32);
F64 stack64(F64,F64,F64,F64,F64,F64,F64,F64,F64,F64);
F32 callback32(F32(*)(F32,F32),F32,F32);
F64 callback64(F64(*)(F64,F64),F64,F64);
F32x callback32x(F32x(*)(F32x,F32x),F32x,F32x);
struct Pair pair(struct Pair);
struct Pair callback_pair(struct Pair(*)(struct Pair),struct Pair);
int variadic_check(void);

F32 sum32(F32 a,F32 b){return a+b;}F64 sum64(F64 a,F64 b){return a+b;}F32x sum32x(F32x a,F32x b){return a+b;}
F32 stack32(F32 a,F32 b,F32 c,F32 d,F32 e,F32 f,F32 g,F32 h,F32 i,F32 j){return a+i+j;}
F64 stack64(F64 a,F64 b,F64 c,F64 d,F64 e,F64 f,F64 g,F64 h,F64 i,F64 j){return a+i+j;}
F32 callback32(F32(*f)(F32,F32),F32 a,F32 b){return f(a,b);}
F64 callback64(F64(*f)(F64,F64),F64 a,F64 b){return f(a,b);}
F32x callback32x(F32x(*f)(F32x,F32x),F32x a,F32x b){return f(a,b);}
struct Pair pair(struct Pair p){p.a*=2;p.b*=3;return p;}
struct Pair callback_pair(struct Pair(*f)(struct Pair),struct Pair p){return f(p);}
static int variadic(int n,...){__builtin_va_list a;F32 f;F64 d;F32x x;__builtin_va_start(a,n);f=__builtin_va_arg(a,F32);d=__builtin_va_arg(a,F64);x=__builtin_va_arg(a,F32x);__builtin_va_end(a);return f==1.25f32&&d==2.5f64&&x==3.75f32x;}
int variadic_check(void){return variadic(3,1.25f32,2.5f64,3.75f32x);}
