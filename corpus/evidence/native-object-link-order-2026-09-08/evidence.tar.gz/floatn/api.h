
typedef _Float32 F32; typedef _Float64 F64; typedef _Float32x F32x;
struct Pair {F32 a;F64 b;};
F32 sum32(F32,F32);F64 sum64(F64,F64);F32x sum32x(F32x,F32x);
F32 stack32(F32,F32,F32,F32,F32,F32,F32,F32,F32,F32);
F64 stack64(F64,F64,F64,F64,F64,F64,F64,F64,F64,F64);
F32 callback32(F32(*)(F32,F32),F32,F32);
F64 callback64(F64(*)(F64,F64),F64,F64);
F32x callback32x(F32x(*)(F32x,F32x),F32x,F32x);
struct Pair pair(struct Pair);
struct Pair callback_pair(struct Pair(*)(struct Pair),struct Pair);
int variadic_check(void);
