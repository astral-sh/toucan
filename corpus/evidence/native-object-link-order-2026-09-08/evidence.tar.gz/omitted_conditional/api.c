#define OMITTED_VALUE (7 ?: 9)
#define OMITTED_ROUNDED (16777217.0f ?: 0.0)
typedef struct Choice{int value;int calls;}Choice;static __inline__ int take(int value,int*calls){++*calls;return value;}Choice choose(int,int);Choice increment(volatile int*,int);Choice vla_choice(int);double float_choice(float,double);
Choice choose(int x,int y){Choice result={0,0};result.value=take(x,&result.calls) ?: take(y,&result.calls);return result;}Choice increment(volatile int*p,int fallback){Choice result;result.value=(*p)++ ?: fallback;result.calls=*p;return result;}Choice vla_choice(int n){int a[2][n];int(*p)[n]=a;Choice result;result.value=sizeof(*(p++ ?: a));result.calls=p==a+1;return result;}double float_choice(float x,double fallback){return x ?: fallback;}
