#define OMITTED_VALUE (7 ?: 9)
#define OMITTED_ROUNDED (16777217.0f ?: 0.0)
typedef struct Choice{int value;int calls;}Choice;static __inline__ int take(int value,int*calls){++*calls;return value;}Choice choose(int,int);Choice increment(volatile int*,int);Choice vla_choice(int);double float_choice(float,double);
