import hashlib,json,re,subprocess,shutil,os
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/native-object-link-order');out=root/'floatn';out.mkdir(exist_ok=True)
source=Path('/home/dev-user/.codex/worktrees/toucan-native-object-link-order/crates/toucan_bindings/tests/floatn.rs').read_text()
header,implementation,rust=re.findall(r'r#"(.*?)"#',source,re.S)
(out/'api.h').write_text(header);(out/'api.c').write_text(header+implementation)
binary=Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/toucan');shutil.copy2(binary,root/'toucan')
native_env=dict(os.environ,LD_LIBRARY_PATH=str(root/'sysroot/usr/lib/x86_64-linux-gnu')+(':'+os.environ['LD_LIBRARY_PATH'] if os.environ.get('LD_LIBRARY_PATH') else ''))
report={'native_library_path':native_env['LD_LIBRARY_PATH'],'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'toucan_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'commands':[],'cases':[]}
def run(command):
 p=subprocess.run([str(s) for s in command],text=True,capture_output=True,timeout=90,env=native_env)
 report['commands'].append({'command':[str(s) for s in command],'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 return p
p=run([binary,'bindgen',out/'api.h','--target','aarch64-unknown-linux-gnu','--compiler','gcc','--rust-target','1.64']);assert p.returncode==0,p.stderr
(out/'main.rs').write_text(p.stdout+rust)
for co in [0,2]:
 obj=out/'floatn.o';p=run([root/'linker','-std=gnu11',f'-O{co}','-c',out/'api.c','-o',obj]);assert p.returncode==0,p.stderr
 symbols=run([root/'sysroot/usr/aarch64-linux-gnu/bin/nm','-u',obj]);assert '__stack_chk_guard' in symbols.stdout,symbols.stdout
 archive=out/'libfloatn.a';p=run([root/'sysroot/usr/aarch64-linux-gnu/bin/ar','crs',archive,obj]);assert p.returncode==0,p.stderr
 for version in ['stable','1.64.0']:
  rustroot=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains')/f'{version}-x86_64-unknown-linux-gnu'
  for ro in [0,3]:
   for strategy in ['object-last','archive']:
    exe=out/f'c{co}-rust{version}-r{ro}-{strategy}'
    command=[rustroot/'bin/rustc','--edition=2021','--target','aarch64-unknown-linux-gnu','--sysroot',rustroot,'-C',f'linker={root}/linker','-C',f'opt-level={ro}',out/'main.rs','-o',exe]
    command+=['-C',f'link-arg={obj}'] if strategy=='object-last' else ['-L',f'native={out}','-l','static=floatn']
    p=run(command)
    if strategy=='object-last':
     assert p.returncode!=0 and '__stack_chk_guard' in p.stderr and 'DSO missing' in p.stderr,p.stderr
     executed=False
    else:
     assert p.returncode==0,p.stderr
     p=run(['/usr/bin/qemu-aarch64-static','-L',root/'sysroot/usr/aarch64-linux-gnu',exe]);assert p.returncode==0,p.stderr;executed=True
    report['cases'].append({'c_optimization':co,'rust_version':version,'rust_optimization':ro,'strategy':strategy,'linked':strategy=='archive','emulated_execution':executed,'stack_guard_reference':True})
    print(co,version,ro,strategy,'proved',flush=True)
(root/'arm-link-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
print('8 original ARM link failures reproduced;8 corrected consumers execute under QEMU')
