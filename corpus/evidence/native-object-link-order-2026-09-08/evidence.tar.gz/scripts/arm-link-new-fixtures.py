import hashlib,json,os,re,subprocess
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/native-object-link-order');tree=Path('/home/dev-user/.codex/worktrees/toucan-native-object-link-order')
env=dict(os.environ,LD_LIBRARY_PATH=str(root/'sysroot/usr/lib/x86_64-linux-gnu'))
report={'commands':[],'cases':[],'source_sha256':{}}
def run(command):
 p=subprocess.run([str(s) for s in command],text=True,capture_output=True,timeout=90,env=env)
 report['commands'].append({'command':[str(s) for s in command],'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr});return p
for fixture in ['non_object_queries','omitted_conditional']:
 source=(tree/f'crates/toucan/tests/{fixture}.rs').read_text();report['source_sha256'][fixture]=hashlib.sha256(source.encode()).hexdigest();out=root/fixture;out.mkdir(exist_ok=True)
 if fixture=='non_object_queries':
  header,c,rust=re.findall(r'r#"(.*?)"#',source,re.S)
 else:
  quoted=r'("(?:[^"\\]|\\.)*")'
  header=json.loads(re.search(r'let header = '+quoted+r';',source).group(1));implementation=json.loads(re.search(r'let implementation = '+quoted+r';',source).group(1));c=header+implementation
  rust=json.loads(re.search(r'std::fs::write\(&rust,\s*format!\('+quoted+r'\)',source).group(1)).replace('{{','{').replace('}}','}')
 (out/'api.h').write_text(header);(out/'api.c').write_text(c)
 p=run([root/'toucan','bindgen',out/'api.h','--target','aarch64-unknown-linux-gnu','--compiler','gcc','--rust-target','1.64']);assert p.returncode==0,p.stderr
 (out/'bindings.rs').write_text(p.stdout);(out/'main.rs').write_text(rust.replace('{bindings}',p.stdout))
 for co in [0,2]:
  obj=out/'probe.o';p=run([root/'linker','-std=gnu11',f'-O{co}','-c',out/'api.c','-o',obj]);assert p.returncode==0,p.stderr
  symbols=run([root/'sysroot/usr/aarch64-linux-gnu/bin/nm','-u',obj]);guard='__stack_chk_guard' in symbols.stdout
  p=run([root/'sysroot/usr/aarch64-linux-gnu/bin/ar','crs',out/'libprobe.a',obj]);assert p.returncode==0,p.stderr
  for version in ['stable','1.64.0']:
   rustroot=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains')/f'{version}-x86_64-unknown-linux-gnu'
   for ro in [0,3]:
    for strategy in ['object-last','archive']:
     exe=out/f'c{co}-rust{version}-r{ro}-{strategy}'
     command=[rustroot/'bin/rustc','--edition=2021','--target','aarch64-unknown-linux-gnu','--sysroot',rustroot,'-C',f'linker={root}/linker','-C',f'opt-level={ro}',out/'main.rs','-o',exe]
     command+=['-C',f'link-arg={obj}'] if strategy=='object-last' else ['-L',f'native={out}','-l','static=probe']
     p=run(command)
     if strategy=='object-last' and guard:
      assert p.returncode!=0 and '__stack_chk_guard' in p.stderr and 'DSO missing' in p.stderr,p.stderr;executed=False
     else:
      assert p.returncode==0,p.stderr
      p=run(['/usr/bin/qemu-aarch64-static','-L',root/'sysroot/usr/aarch64-linux-gnu',exe]);assert p.returncode==0,p.stderr;executed=True
     report['cases'].append({'fixture':fixture,'c_optimization':co,'rust_version':version,'rust_optimization':ro,'strategy':strategy,'stack_guard_reference':guard,'emulated_execution':executed})
     print(fixture,co,version,ro,strategy,'guard',guard,'proved',flush=True)
(root/'new-fixture-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
