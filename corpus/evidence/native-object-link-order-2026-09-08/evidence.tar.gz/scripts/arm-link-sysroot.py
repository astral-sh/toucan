from pathlib import Path
import hashlib,json,subprocess,urllib.request
root=Path('/home/dev-user/.cache/toucan/native-object-link-order');root.mkdir(exist_ok=True)
sysroot=root/'sysroot';sysroot.mkdir(exist_ok=True)
rows=[]
for package in ['libc6-arm64-cross','libc6-dev-arm64-cross','libgcc-s1-arm64-cross']:
 metadata=subprocess.check_output(['apt-cache','show',package],text=True).split('\n\n')[0]
 fields=dict(line.split(': ',1) for line in metadata.splitlines() if ': ' in line and not line.startswith(' '))
 url='https://archive.ubuntu.com/ubuntu/'+fields['Filename'];path=root/Path(fields['Filename']).name
 if not path.exists():path.write_bytes(urllib.request.urlopen(url).read())
 digest=hashlib.sha256(path.read_bytes()).hexdigest();assert digest==fields['SHA256'],package
 subprocess.run(['dpkg-deb','-x',str(path),str(sysroot)],check=True)
 rows.append({'package':package,'version':fields['Version'],'url':url,'sha256':digest})
for package in ['/home/dev-user/.cache/toucan/musl-validation/packages/libgcc-13-dev-arm64-cross_13.3.0-6ubuntu2~24.04.1cross1_all.deb']:
 subprocess.run(['dpkg-deb','-x',package,str(sysroot)],check=True)
 rows.append({'package':str(package),'sha256':hashlib.sha256(Path(package).read_bytes()).hexdigest()})
(root/'sysroot-packages.json').write_text(json.dumps(rows,indent=2)+'\n')
print(sysroot)
