#include "api.h"
Opaque *identity(Opaque *p){return p;}
int apply(struct Api a,int n){return a.callback(n)+(a.context!=0);}
static int callback(int n) __attribute__((aligned(1)));
static int callback(int n){return n*3;}
Callback *get_callback(void){return callback;}
unsigned long long c_void_size(void){return SIZE_VOID;}
unsigned long long c_function_size(void){return SIZE_FUNCTION;}
