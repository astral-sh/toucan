
typedef void Opaque __attribute__((aligned(32)));
typedef int Callback(int) __attribute__((aligned(32)));
struct Api { Opaque *context; Callback *callback; };
Opaque *identity(Opaque *);
int apply(struct Api, int);
Callback *get_callback(void);
unsigned long long c_void_size(void);
unsigned long long c_function_size(void);
#define SIZE_VOID sizeof(Opaque)
#define SIZE_FUNCTION sizeof(Callback)
#define ALIGN_VOID __alignof__(Opaque)
#define ALIGN_FUNCTION __alignof__(Callback)
