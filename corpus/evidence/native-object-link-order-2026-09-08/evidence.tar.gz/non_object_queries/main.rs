include!("bindings.rs");
#[repr(align(32))] struct Context([u8;32]);
unsafe extern "C" fn callback(n:i32)->i32{n+7}
fn main(){unsafe{
    let mut context=Context([0;32]);
    let p=context.0.as_mut_ptr().cast::<Opaque>();
    assert_eq!(identity(p),p);
    assert_eq!(apply(Api{context:p,callback:Some(callback)},5),13);
    assert_eq!(get_callback().unwrap()(4),12);
    assert_eq!(c_void_size(),1);assert_eq!(c_function_size(),1);
    assert_eq!(SIZE_VOID,1);assert_eq!(SIZE_FUNCTION,1);
    assert_eq!(core::mem::size_of::<Api>(),16);
    assert_eq!(core::mem::align_of::<Api>(),8);
}}
