
typedef __int8 Byte;
typedef signed __int8 SignedByte;
typedef unsigned __int16 Word;
typedef __int32 Number;
typedef unsigned __int64 Wide;
struct Values {Byte byte; SignedByte signed_byte; Word word; Number number; Wide wide;};
Wide convert(Number, struct Values);
#define WIDE_MAX ((unsigned __int64)-1)
_Static_assert(_Generic((Byte)0, char:1, default:0), "plain char identity");
_Static_assert(_Generic((SignedByte)0, signed char:1, default:0), "signed char identity");
_Static_assert(_Generic((Word)0, unsigned short:1, default:0), "short identity");
_Static_assert(_Generic((Number)0, int:1, default:0), "int identity");
_Static_assert(_Generic((Wide)0, unsigned long long:1, default:0), "long long identity");
_Static_assert(sizeof(struct Values)==16 && _Alignof(struct Values)==8, "layout");
