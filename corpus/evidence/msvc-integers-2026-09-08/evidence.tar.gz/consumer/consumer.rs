#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals)]
include!("bindings.rs");
const _: [();16] = [();core::mem::size_of::<Values>()];
const _: () = assert!(WIDE_MAX == u64::MAX);
