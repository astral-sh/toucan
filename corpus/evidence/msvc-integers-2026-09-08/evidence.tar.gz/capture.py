import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

repo = Path('/home/dev-user/.codex/worktrees/toucan-msvc-syntax')
cache = Path('/home/dev-user/.cache/toucan/windows-arm64-probes')
output = repo / 'corpus/evidence/msvc-integers-2026-09-08'
output.mkdir(parents=True, exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=repo, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo, text=True).splitlines()
sources = {name: digest((repo/name).read_bytes()) for name in sorted(set(changed+untracked)) if not name.startswith('corpus/evidence/')}
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
write_json(output/'source.json', {'base': base, 'files': sources})

archive = {}
for path in sorted((cache/'msvc-integer-validation').iterdir()):
    if path.suffix in {'.rs', '.h', '.json'}:
        archive['consumer/'+path.name] = path.read_bytes()
for name in ['integer-ast.json', 'integer-combinations.json']:
    archive['native/'+name] = (cache/'msvc-syntax'/name).read_bytes()
native = json.loads((cache/'msvc-syntax/evidence.json').read_text())
archive['native/integer-syntax.json'] = (json.dumps([row for row in native if row['name'].startswith('int')], indent=2)+'\n').encode()
versions = []
for command in [
    ['clang', '--version'],
    ['rustc', '--version', '--verbose'],
    ['/home/dev-user/.cache/toucan/msrv-rustup/toolchains/1.64.0-x86_64-unknown-linux-gnu/bin/rustc', '--version', '--verbose'],
]:
    result = subprocess.run(command, text=True, capture_output=True, check=True)
    versions.append({'command': command, 'stdout': result.stdout, 'stderr': result.stderr})
archive['versions.json'] = (json.dumps(versions, indent=2)+'\n').encode()
archive['capture.py'] = Path(__file__).read_bytes()
stream = io.BytesIO()
with tarfile.open(fileobj=stream, mode='w') as tar:
    for name, data in sorted(archive.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
(output/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(), mtime=0))
write_json(output/'files.json', {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(archive.items())})
logs = {}
for name, path in {
    'workspace': '/tmp/toucan-msvc-integer-workspace.log',
    'differential': '/tmp/toucan-msvc-integer-tests.log',
    'clippy': '/tmp/toucan-msvc-integer-clippy.log',
    'parser': '/tmp/toucan-msvc-integer-parser.log',
    'parser-clippy': '/tmp/toucan-msvc-integer-parser-clippy.log',
    'regeneration': '/tmp/toucan-msvc-regenerate.log',
}.items():
    data = Path(path).read_bytes()
    (output/(name+'.log.gz')).write_bytes(gzip.compress(data, mtime=0))
    logs[name] = {'bytes': len(data), 'sha256': digest(data)}
workspace = Path('/tmp/toucan-msvc-integer-workspace.log').read_text()
totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', workspace)
write_json(output/'summary.json', {
    'date': '2026-09-08',
    'source_manifest_sha256': digest((output/'source.json').read_bytes()),
    'archive_sha256': digest((output/'evidence.tar.gz').read_bytes()),
    'logs': logs,
    'workspace_reported_executions': {key: sum(int(row[i]) for row in totals) for i, key in enumerate(['passed', 'failed', 'ignored'])},
    'workspace_count_note': 'Reported execution counts can include child harness output; this is not a unique test count. Ignored oracles are excluded except the explicit differential invocation below.',
    'differential': {'cases': 37, 'keyword_forms': 2, 'clang_targets': 5, 'acceptance_comparisons': 370, 'type_identity_and_layout_units': 1, 'differences': 0},
    'ordinary_retained_pairs': 518,
    'checked_seed': {'profiles': 7, 'modes': 2, 'accepted_pairs': 2, 'matching_rejection_pairs': 12, 'graph_invariants': 'passed'},
    'parser_span_and_budget_test': 'passed after full workspace invocation; production source unchanged',
    'bindings': {'canonical_C_output': 'byte-identical', 'rust_output_minimum': '1.64', 'actual_rust_versions': ['1.64.0', '1.98.1'], 'target': 'x86_64-pc-windows-msvc', 'compiled_consumer_metadata': True},
    'limits': ['No Windows executable ran.', 'This slice adds integer keywords only; Windows SDK coverage and other Microsoft syntax remain separate gates.', 'No performance benchmark was run.'],
})
print(json.dumps({'source': digest((output/'source.json').read_bytes()), 'archive': digest((output/'evidence.tar.gz').read_bytes()), 'files': len(archive)}, indent=2))
