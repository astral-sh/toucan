"""Run the paired AWS-LC check with strict frozen-input and artifact provenance."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

BASE = Path(__file__).resolve().parent
SOURCE = Path('/home/dev-user/.cache/toucan/callback-final-source-2026-09-09')
MANIFEST = SOURCE.with_name(SOURCE.name + '-manifest.json')
COMMIT = '7db2b85027108be1515ad76263720e665cba2ab9'
NAMES = {'toucan', 'toucan_bindgen', 'toucan_bindings', 'toucan_layout', 'toucan_parser', 'toucan_preprocessor', 'toucan_semantic', 'toucan_source', 'toucan_target'}

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def inventory():
    return {str(p.relative_to(SOURCE)): digest(p) for p in sorted(SOURCE.rglob('*')) if p.is_file()}

def artifacts(log, before):
    rows=[]
    names=set()
    for line in log.read_text().splitlines():
        row=json.loads(line)
        if row.get('reason') != 'compiler-artifact':
            continue
        name=row['target']['name']
        assert name not in {'bindgen', 'clang_sys', 'libloading'}, (log, name)
        if name not in NAMES:
            continue
        manifest=Path(row['manifest_path']).resolve()
        assert manifest == SOURCE/'crates'/name/'Cargo.toml', manifest
        rlib,=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
        dep=rlib.with_name(rlib.stem.removeprefix('lib')+'.d')
        words=dep.read_text().split()
        assert str(manifest.parent/'src/lib.rs') in words
        inputs={}
        for word in words:
            p=Path(word.removesuffix(':'))
            if p.is_relative_to(SOURCE) and p.is_file():
                p=p.resolve()
                assert p.is_relative_to(SOURCE)
                relative=str(p.relative_to(SOURCE))
                actual=digest(p)
                assert before[relative] == actual
                inputs[relative]=actual
        assert inputs
        rows.append({'name':name,'manifest_path':str(manifest),'package_id':row['package_id'],'fresh':row['fresh'],'rlib':str(rlib),'rlib_sha256':digest(rlib),'dep_info':str(dep),'dep_info_sha256':digest(dep),'source_inputs':inputs})
        names.add(name)
    assert names == NAMES, (log, names)
    return {'log':str(log),'log_sha256':digest(log),'all_nine_frontend_crates':True,'libclang_generator_crates_absent':True,'artifacts':rows}

manifest=json.loads(MANIFEST.read_text())
assert manifest['commit'] == COMMIT
before=inventory()
assert before == {k:v['sha256'] for k,v in manifest['files'].items()}
assert not any('__pycache__' in Path(p).parts for p in before)
env=os.environ.copy()
removed=[]
for name in list(env):
    if name.startswith(('AWS_LC_', 'BINDGEN_EXTRA_CLANG_ARGS', 'CFLAGS', 'CXXFLAGS', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CC_', 'CARGO_TARGET_')) or name in {'CC','HOST_CC','TARGET_CC','HOST_CFLAGS','TARGET_CFLAGS','CMAKE_TOOLCHAIN_FILE','ZSTD_SYS_USE_PKG_CONFIG'} or (name.startswith('CARGO_PROFILE_') and name.endswith('_DEBUG')):
        removed.append(name)
        env.pop(name)
env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo', RUSTUP_TOOLCHAIN='stable', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2', PYTHONDONTWRITEBYTECODE='1', CXX='clang++-18')
command=['/usr/bin/python3','-B',str(BASE/'verify_aws_lc_consumer.py'),'--cc','clang-18','--sysroot','/','--libclang-dir','/usr/lib/llvm-18/lib','--cache',str(BASE/'cache'),'--output',str(BASE/'evidence'),'--toucan-source',str(SOURCE),'--jobs','2']
audit={'status':'running','commit':COMMIT,'tree':manifest['tree'],'source':str(SOURCE),'git_manifest':str(MANIFEST),'git_manifest_sha256':digest(MANIFEST),'source_before':before,'source_policy':'Exact complete file equality, without exceptions.','environment':{k:env[k] for k in ['CARGO_HOME','RUSTUP_TOOLCHAIN','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','PYTHONDONTWRITEBYTECODE','CXX']},'unset_variables':sorted(removed),'command':command,'free_before':shutil.disk_usage(BASE).free,'start_unix':time.time()}

def save():
    (BASE/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')

save()
try:
    assert audit['free_before'] >= 10*1024**3, 'free disk below 10 GiB'
    print('AWS-LC all-bindings paired validation started with two jobs',flush=True)
    with (BASE/'run.log').open('w') as log:
        result=subprocess.run(command,cwd=SOURCE,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    audit['returncode']=result.returncode
    assert result.returncode == 0, 'paired AWS-LC harness failed; see run.log'
    evidence=json.loads((BASE/'evidence/evidence.json').read_text())
    assert evidence['status'] == 'passed', evidence['status']
    assert all(c['bio_memory_smoke'] == 'bio memory 23 toucan all-bindings bio' for c in evidence['cases'].values())
    assert all(c['ssl_tls_smoke'] == 'ssl tls min 771 772' for c in evidence['cases'].values())
    audit['frontend_artifacts']=[artifacts(BASE/'evidence'/name,before) for name in ['toucan-build.stdout','toucan-layout-test-build.stdout']]
    audit['status']='passed'
    print('AWS-LC passed: selected frontend artifacts and native checks verified',flush=True)
except Exception as error:
    audit.update(status='failed',error=str(error))
    raise
finally:
    audit['elapsed_seconds']=time.time()-audit['start_unix']
    audit['free_after']=shutil.disk_usage(BASE).free
    audit['source_after']=inventory()
    audit['source_after_identical']=audit['source_after']==before
    if not audit['source_after_identical']:
        audit.update(status='failed',error='frozen source file inventory changed')
    save()
assert audit['source_after_identical']
