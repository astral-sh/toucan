"""Freeze the independently captured SSL consumer run as compact, auditable evidence."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile


BASE = Path(__file__).resolve().parent
OUT = Path("/home/dev-user/.codex/worktrees/toucan-win-arm64-target/corpus/evidence/aws-lc-ssl-consumer-7db2b85-2026-09-09")
SOURCE_MANIFEST = Path("/home/dev-user/.cache/toucan/callback-final-source-2026-09-09-manifest.json")
FROZEN_COMPARATOR = Path("/home/dev-user/.cache/toucan/callback-final-source-2026-09-09/scripts/compare_bindings.py")
ROOT = Path("/home/dev-user/code/oss/toucan")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def archive_members():
    files = {
        "provenance/audit.json": (BASE / "audit.json").read_bytes(),
        "provenance/source-manifest.json": SOURCE_MANIFEST.read_bytes(),
        "harness/run.py": (BASE / "run.py").read_bytes(),
        "harness/verify_aws_lc_consumer.py": (BASE / "verify_aws_lc_consumer.py").read_bytes(),
        "harness/package_evidence.py": Path(__file__).read_bytes(),
        "comparators/7db2b85.py": FROZEN_COMPARATOR.read_bytes(),
        "comparators/1beb88d.py": subprocess.check_output(
            ["git", "-C", str(ROOT), "show", "1beb88d:scripts/compare_bindings.py"]
        ),
        "comparisons/raw-elf-markers.json": (BASE / "api-native-comparison.json").read_bytes(),
        "comparisons/elf-symbols.json": (BASE / "api-native-comparison-elf-normalized.json").read_bytes(),
        "harness/run.log": (BASE / "run.log").read_bytes(),
    }
    for path in sorted((BASE / "fixture").rglob("*")):
        if path.is_file():
            files["fixture/" + str(path.relative_to(BASE / "fixture"))] = path.read_bytes()
    for path in sorted((BASE / "evidence").rglob("*")):
        if path.is_file() and path.name not in {
            "reference-consumer", "toucan-consumer", "reference-c-layout", "toucan-c-layout",
            "reference-layout-tests", "toucan-layout-tests",
        }:
            files["evidence/" + str(path.relative_to(BASE / "evidence"))] = path.read_bytes()

    evidence = json.loads(files["evidence/evidence.json"])
    member_hashes = {}
    for name, case in evidence["cases"].items():
        out = Path(case["build_script"]["out_dir"])
        for target, relative in {
            "cmake-cache": "build/CMakeCache.txt",
            "ssl-cxx-flags": "build/aws-lc/ssl/CMakeFiles/ssl.dir/flags.make",
        }.items():
            files[f"native/{name}-{target}.txt"] = (out / relative).read_bytes()
        ssl = out / "build/artifacts/libaws_lc_0_44_0_ssl.a"
        members = subprocess.check_output(["llvm-ar-18", "t", str(ssl)], text=True).splitlines()
        assert len(members) == 41 and len(set(members)) == len(members)
        for member in members:
            data = subprocess.check_output(["llvm-ar-18", "p", str(ssl), member])
            member_hashes.setdefault(member, {})[name] = digest(data)
        bio = subprocess.check_output(["llvm-ar-18", "p", str(ssl), "bio_ssl.cc.o"])
        path_lines = subprocess.run(["strings", "-a"], input=bio, capture_output=True, check=True).stdout.decode().splitlines()
        member_hashes["bio_ssl.cc.o"][f"{name}_embedded_path"] = next(
            line for line in path_lines if line.endswith(f"/cache/{name}/aws-lc-sys/aws-lc/ssl/bio_ssl.cc")
        )
    files["native/ssl-member-hashes.json"] = (json.dumps(member_hashes, indent=2, sort_keys=True) + "\n").encode()
    assert sum(x["reference"] != x["toucan"] for x in member_hashes.values()) == 37
    return files, evidence, member_hashes


def main():
    audit = json.loads((BASE / "audit.json").read_text())
    assert audit["status"] == "passed" and audit["source_after_identical"]
    manifest = json.loads(SOURCE_MANIFEST.read_text())
    assert audit["commit"] == manifest["commit"] == "7db2b85027108be1515ad76263720e665cba2ab9"
    assert len(audit["source_before"]) == 2389
    files, evidence, member_hashes = archive_members()
    assert evidence["status"] == "passed"
    raw = json.loads(files["comparisons/raw-elf-markers.json"])
    normalized = json.loads(files["comparisons/elf-symbols.json"])
    assert raw["inputs_unchanged"] and normalized["inputs_unchanged"]
    assert normalized["elf_mangling_escape_counts"] == {
        "toucan": {"functions": 0, "globals": 0},
        "bindgen": {"functions": 2617, "globals": 60},
    }
    assert normalized["comparisons"]["functions"]["equal"] == 3230
    assert normalized["comparisons"]["globals"]["equal"] == 60
    assert not normalized["equivalent"]
    assert digest(files["comparators/1beb88d.py"]) == digest(
        (ROOT / "scripts/compare_bindings.py").read_bytes()
    )

    OUT.mkdir(parents=True, exist_ok=True)
    capture = OUT / "capture.tar.gz"
    inventory = {name: digest(data) for name, data in files.items()}
    files["archive-member-sha256.json"] = (json.dumps(inventory, indent=2, sort_keys=True) + "\n").encode()
    with capture.open("wb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tar:
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    tar.addfile(info, io.BytesIO(data))

    summary = {
        "capture_sha256": digest(capture.read_bytes()),
        "capture_size_bytes": capture.stat().st_size,
        "archive_entries": len(files),
        "frontend_commit": audit["commit"],
        "frontend_verified_files": len(audit["source_before"]),
        "frontend_unchanged": audit["source_after_identical"],
        "source_manifest_sha256": digest(SOURCE_MANIFEST.read_bytes()),
        "paired_audit_status": audit["status"],
        "paired_run_seconds": round(audit["elapsed_seconds"], 1),
        "target": evidence["target"],
        "pair_environment_cxx": audit["environment"]["CXX"],
        "comparator_root_commit": "1beb88d4a49ae1b1fe527f921598d446b68b159d",
        "raw_comparator_sha256": digest(files["comparators/7db2b85.py"]),
        "elf_comparator_sha256": digest(files["comparators/1beb88d.py"]),
        "analyzer_sha256": normalized["analyzer_sha256"],
        "generated_bindings_sha256": {
            name: case["bindings_sha256"] for name, case in evidence["cases"].items()
        },
        "cases": {
            name: {
                "aws_lc_sys_features": case["packages"]["aws-lc-sys"]["features"],
                "aws_lc_rs_features": case["packages"]["aws-lc-rs"]["features"],
                "linked_libs": case["build_script"]["linked_libs"],
                "generated_layout_tests_passed": case["generated_layout_tests"],
                "native_source_objects": len(case["native_object_files"]),
                "crypto_archive_sha256": case["native_archives"]["build/artifacts/libaws_lc_0_44_0_crypto.a"],
                "ssl_archive_sha256": case["native_archives"]["build/artifacts/libaws_lc_0_44_0_ssl.a"],
                "runtime_artifacts": len(case["runtime_artifacts"]),
                "bio_smoke": case["bio_memory_smoke"],
                "ssl_smoke": case["ssl_tls_smoke"],
                "changed_upstream_files": case["changed_upstream_files"],
            }
            for name, case in evidence["cases"].items()
        },
        "ssl_archive_members": len(member_hashes),
        "ssl_archive_member_bytes_differ": sum(x["reference"] != x["toucan"] for x in member_hashes.values()),
        "raw_elf_link_name_mismatches": {category: {
            "toucan_only": len(raw["comparisons"][category]["toucan_only"]),
            "bindgen_only": len(raw["comparisons"][category]["bindgen_only"]),
        } for category in ("functions", "globals")},
        "normalized_elf_mangling_escape_counts": normalized["elf_mangling_escape_counts"],
        "normalized_elf_api_equivalent": normalized["equivalent"],
        "normalized_comparisons": {category: {
            "equal": compare["equal"], "common": compare["common"],
            "toucan_only": len(compare["toucan_only"]),
            "bindgen_only": len(compare["bindgen_only"]),
            "different": len(compare["different"]),
        } for category, compare in normalized["comparisons"].items()},
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

    with tarfile.open(capture, "r:gz") as tar:
        extracted = {member.name: tar.extractfile(member).read() for member in tar.getmembers()}
    assert len(extracted) == len(files) and all(extracted[k] == v for k, v in files.items())
    recorded = json.loads(extracted["archive-member-sha256.json"])
    assert recorded == {name: digest(data) for name, data in extracted.items() if name != "archive-member-sha256.json"}
    print(f"Verified {len(extracted)} archive entries and SHA256s; capture {capture.stat().st_size} bytes: {summary['capture_sha256']}")


if __name__ == "__main__":
    main()
