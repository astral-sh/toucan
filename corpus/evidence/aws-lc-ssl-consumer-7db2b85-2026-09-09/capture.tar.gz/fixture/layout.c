#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "rust_wrapper.h"
#include "openssl/ssl.h"

#define LAYOUT(type) printf("layout " #type " %zu %zu\n", sizeof(type), _Alignof(type))

int main(void) {
    const char message[] = "toucan all-bindings bio";
    BIO *bio = BIO_new(BIO_s_mem());
    if (bio == NULL) return 1;
    if (BIO_write(bio, message, sizeof(message) - 1) != sizeof(message) - 1) return 1;
    char *data = NULL;
    long length = BIO_get_mem_data(bio, &data);
    if (length != sizeof(message) - 1 || data == NULL || memcmp(data, message, sizeof(message) - 1) != 0) return 1;
    printf("bio memory %ld %.*s\n", length, (int)length, data);
    if (BIO_free(bio) != 1) return 1;
    const SSL_METHOD *method = TLS_method();
    if (method == NULL) return 1;
    SSL_CTX *context = SSL_CTX_new(method);
    if (context == NULL) return 1;
    if (SSL_CTX_set_min_proto_version(context, TLS1_2_VERSION) != 1) return 1;
    SSL *connection = SSL_new(context);
    if (connection == NULL) return 1;
    if (SSL_set_min_proto_version(connection, TLS1_3_VERSION) != 1) return 1;
    unsigned context_version = SSL_CTX_get_min_proto_version(context);
    unsigned connection_version = SSL_get_min_proto_version(connection);
    if (context_version != TLS1_2_VERSION || connection_version != TLS1_3_VERSION) return 1;
    printf("ssl tls min %u %u\n", context_version, connection_version);
    SSL_free(connection);
    SSL_CTX_free(context);
    LAYOUT(SHA_CTX);
    LAYOUT(SHA256_CTX);
    LAYOUT(SHA512_CTX);
    LAYOUT(EVP_AEAD_CTX);
    LAYOUT(CBS);
    LAYOUT(CBB);
    return 0;
}
