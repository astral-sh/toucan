; ModuleID = 'consumer.f7f57611ce5e34b2-cgu.0'
source_filename = "consumer.f7f57611ce5e34b2-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

; Function Attrs: nounwind uwtable
define void @call_exchange(ptr sret([16 x i8]) align 16 %_0, ptr align 16 %value) unnamed_addr #0 {
start:
  %0 = alloca [16 x i8], align 16
  call void @llvm.memcpy.p0.p0.i64(ptr align 16 %0, ptr align 16 %value, i64 16, i1 false)
  call void @exchange(ptr sret([16 x i8]) align 16 %_0, ptr align 16 %0) #2
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #1

; Function Attrs: nounwind uwtable
declare void @exchange(ptr sret([16 x i8]) align 16, ptr align 16) unnamed_addr #0

attributes #0 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
