; ModuleID = 'consumer.26609c7a-cgu.0'
source_filename = "consumer.26609c7a-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

%Pair = type { i64, i64 }

; Function Attrs: uwtable
define void @call_exchange(%Pair* sret(%Pair) %0, %Pair* %value) unnamed_addr #0 {
start:
  %_2 = alloca %Pair, align 16
  %1 = bitcast %Pair* %_2 to i8*
  %2 = bitcast %Pair* %value to i8*
  call void @llvm.memcpy.p0i8.p0i8.i64(i8* align 16 %1, i8* align 16 %2, i64 16, i1 false)
  call void @exchange(%Pair* sret(%Pair) %0, %Pair* %_2)
  br label %bb1

bb1:                                              ; preds = %start
  ret void
}

; Function Attrs: argmemonly nofree nounwind willreturn
declare void @llvm.memcpy.p0i8.p0i8.i64(i8* noalias nocapture writeonly, i8* noalias nocapture readonly, i64, i1 immarg) #1

; Function Attrs: uwtable
declare void @exchange(%Pair* sret(%Pair), %Pair*) unnamed_addr #0

attributes #0 = { uwtable "target-cpu"="x86-64" }
attributes #1 = { argmemonly nofree nounwind willreturn }

!llvm.module.flags = !{!0}

!0 = !{i32 7, !"PIC Level", i32 2}
