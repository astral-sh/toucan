import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BINDGEN = Path('/home/dev-user/.cache/toucan/tools/bin/bindgen')
env = dict(os.environ, LIBCLANG_PATH='/usr/lib/llvm-18/lib')
variants = {
    'default': [],
    'all': ['--with-derive-default', '--with-derive-eq'],
    'no-copy': ['--no-derive-copy', '--with-derive-default', '--with-derive-eq'],
    'no-debug': ['--no-derive-debug', '--with-derive-default', '--with-derive-eq'],
    'eq': ['--with-derive-eq'],
    'default-only': ['--no-derive-copy', '--no-derive-debug', '--with-derive-default'],
}
rows = []
for name, flags in variants.items():
    command = [str(BINDGEN), str(ROOT/'traits.h'), '--rustified-enum', 'NonZero|Zero',
               '--no-layout-tests', '--use-core', '--rust-target', '1.64',
               '--no-include-path-detection', *flags, '--', '-std=gnu11',
               '--target=x86_64-unknown-linux-gnu']
    result = subprocess.run(command, text=True, capture_output=True, env=env)
    (ROOT/f'traits-{name}.rs').write_text(result.stdout)
    traits = {}
    pending = []
    for line in result.stdout.splitlines():
        if line.startswith('#[derive('):
            pending = line.removeprefix('#[derive(').removesuffix(')]').split(', ')
        match = re.match(r'pub (?:enum|struct|union) (\w+)\b', line)
        if match:
            traits[match[1]] = pending
            pending = []
    defaults = re.findall(r'impl Default for (\w+)', result.stdout)
    rows.append(dict(name=name, command=command, returncode=result.returncode,
                     stdout=result.stdout, stderr=result.stderr,
                     traits=traits, manual_defaults=defaults))
(ROOT/'traits-evidence.json').write_text(json.dumps(dict(
    bindgen_sha256=hashlib.sha256(BINDGEN.read_bytes()).hexdigest(),
    bindgen_version=subprocess.check_output([str(BINDGEN),'--version'],text=True).strip(),
    source=(ROOT/'traits.h').read_text(),
    source_sha256=hashlib.sha256((ROOT/'traits.h').read_bytes()).hexdigest(),
    rows=rows), indent=2)+'\n')
for row in rows:
    print(row['name'], row['returncode'], json.dumps(row['traits'],sort_keys=True), 'manual_defaults',row['manual_defaults'])
