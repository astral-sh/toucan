struct DefaultAbi { int (*value)(int); };
struct SysVAbi { int (__attribute__((sysv_abi)) *value)(int); };
struct Win64Abi { int (__attribute__((ms_abi)) *value)(int); };
