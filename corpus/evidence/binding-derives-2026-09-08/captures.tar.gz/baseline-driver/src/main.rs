use serde::Deserialize;
use std::path::PathBuf;
#[derive(Deserialize)]
struct Request {
    header: PathBuf,
    target: String,
    include_dirs: Vec<PathBuf>,
    sysroot: PathBuf,
    allowlist: Vec<String>,
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args=std::env::args().collect::<Vec<_>>();
    let request:Request=serde_json::from_slice(&std::fs::read(&args[1])?)?;
    let mut config = toucan::Config::new(toucan::Target::parse(&request.target)?);
    config
        .preprocessor
        .include_dirs
        .clone_from(&request.include_dirs);
    let include = request.sysroot.join("usr/include");
    let multiarch = match request.target.as_str() {
        "x86_64-unknown-linux-gnu" => Some("x86_64-linux-gnu"),
        "aarch64-unknown-linux-gnu" => Some("aarch64-linux-gnu"),
        "x86_64-unknown-linux-musl" => Some("x86_64-linux-musl"),
        "aarch64-unknown-linux-musl" => Some("aarch64-linux-musl"),
        _ => None,
    };
    if let Some(multiarch) = multiarch {
        config
            .preprocessor
            .include_dirs
            .push(include.join(multiarch));
    }
    config.preprocessor.include_dirs.push(include);

    let compilation=toucan::parse_file(&request.header,&config)?;
    let (source,report)=compilation.bindings(&toucan::BindingOptions{allowlist:request.allowlist,..Default::default()})?;
    std::fs::write(&args[2],source)?;
    let mut value=serde_json::to_value(report)?;
    value.as_object_mut().unwrap().remove("timings");
    println!("{value}");
    Ok(())
}
