import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

SOURCE = Path('/home/dev-user/.codex/worktrees/toucan-binding-derives')
ROOT = Path('/home/dev-user/.cache/toucan/binding-derive-evidence/asan')
BINARY = Path('/home/dev-user/.cache/toucan/binding-derives-asan-target/x86_64-unknown-linux-gnu/release/bindings')
ROOT.mkdir(exist_ok=True)
corpus = ROOT/'corpus'
corpus.mkdir(exist_ok=True)
artifacts = ROOT/'artifacts'
artifacts.mkdir(exist_ok=True)
data = (SOURCE/'fuzz/seeds/bindings/derive-storage.h').read_bytes()
prefix, suffix = data+b'\n/*', b'*/\n'
base = sum(prefix+suffix)
block = ((base//32768)+1)*32768
coverage = []
for traits in range(16):
    for mode in range(8):
        for profile in range(11):
            target = block+(traits<<11)+(mode<<8)
            target += (profile-target)%11
            delta = target-base
            assert delta >= 32
            count, remainder = divmod(delta, 32)
            seed = prefix+b' '*(count-1)+bytes([32+remainder])+suffix
            assert seed.startswith(data) and len(seed) <= 8192
            checksum = sum(seed)
            assert (checksum%11, (checksum>>8)&7, (checksum>>11)&15) == (profile, mode, traits)
            sha = hashlib.sha256(seed).hexdigest()
            (corpus/sha).write_bytes(seed)
            coverage.append(dict(profile=profile,mode=mode,traits=traits,sha256=sha,bytes=len(seed)))
for seed in (SOURCE/'fuzz/seeds/bindings').glob('*.h'):
    original = seed.read_bytes()
    (corpus/hashlib.sha256(original).hexdigest()).write_bytes(original)
assert len({(r['profile'],r['mode'],r['traits']) for r in coverage}) == 1408
(ROOT/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
assert b'__asan_init' in subprocess.check_output(['nm',str(BINARY)])
shutil.copy2(BINARY,ROOT/'bindings')
shutil.copyfile(SOURCE/'fuzz/c.dict',ROOT/'c.dict')
snapshot = {}
for pattern in ['crates/**/*.rs','crates/**/Cargo.toml','fuzz/fuzz_targets/*.rs','fuzz/Cargo.toml','fuzz/Cargo.lock']:
    for path in SOURCE.glob(pattern):
        snapshot[str(path.relative_to(SOURCE))] = hashlib.sha256(path.read_bytes()).hexdigest()
(ROOT/'source-before.json').write_text(json.dumps(snapshot,indent=2)+'\n')
command = [str(ROOT/'bindings'),str(corpus),'-dict='+str(ROOT/'c.dict'),'-max_total_time=60','-max_len=8192','-len_control=0','-timeout=5','-rss_limit_mb=1024','-artifact_prefix='+str(artifacts)+'/', '-print_final_stats=1']
initial_count=len(list(corpus.iterdir()))
started=time.monotonic()
with (ROOT/'run.log').open('wb') as log:
    result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'))
after={path:hashlib.sha256((SOURCE/path).read_bytes()).hexdigest() for path in snapshot}
text=(ROOT/'run.log').read_text()
summary=dict(command=command,returncode=result.returncode,wall_seconds=time.monotonic()-started,binary_sha256=hashlib.sha256(BINARY.read_bytes()).hexdigest(),seed_profile_mode_trait_combinations=len(coverage),initial_seeds=initial_count,artifacts=[p.name for p in artifacts.iterdir()],source_unchanged=snapshot==after,final_stats={key:int(value) for key,value in re.findall(r'stat::(\w+):\s+(\d+)',text)})
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
assert result.returncode==0 and not summary['artifacts'] and summary['source_unchanged']
