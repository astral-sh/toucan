# 0 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 39 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 1 3 4
# 34 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/syslimits.h" 1 3 4






# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 1 3 4
# 205 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 3 4
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4


# 24 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4
extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

# 82 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/xopen_lim.h" 1 3 4
# 64 "/usr/include/x86_64-linux-gnu/bits/xopen_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/uio_lim.h" 1 3 4
# 65 "/usr/include/x86_64-linux-gnu/bits/xopen_lim.h" 2 3 4
# 204 "/usr/include/limits.h" 2 3 4
# 206 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 2 3 4
# 8 "/usr/lib/gcc/x86_64-linux-gnu/13/include/syslimits.h" 2 3 4
# 35 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 2 3 4
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 2
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long int ptrdiff_t;
# 214 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef long unsigned int size_t;
# 329 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef int wchar_t;
# 425 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
# 436 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 3 4
} max_align_t;
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



# 1 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 24 "/usr/include/strings.h" 2 3 4










extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));



# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 552 "/usr/include/string.h" 3 4

# 42 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 2
# 64 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h"
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 119 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 120 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
# 340 "/usr/include/stdlib.h" 3 4
extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/x86_64-linux-gnu/sys/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 30 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;




typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/x86_64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 145 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 156 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4


typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{

  return __builtin_bswap16 (__bsx);



}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{

  return __builtin_bswap32 (__bsx);



}
# 69 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{

  return __builtin_bswap64 (__bsx);



}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/x86_64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 91 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4

# 102 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 153 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4

# 180 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 2 3 4
# 45 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;



  int __kind;

  short __spins;
  short __elision;
  __pthread_list_t __list;
# 53 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;

  int __cur_writer;
  int __shared;
  signed char __rwelision;




  unsigned char __pad1[7];


  unsigned long int __pad2;


  unsigned int __flags;
# 55 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 3 4
};
# 90 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));







extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) ;


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) ;




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));


extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));






# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;



extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;






extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 1167 "/usr/include/stdlib.h" 3 4

# 65 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 2
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/portability_macros.h" 1
# 162 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/portability_macros.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/cet.h" 1 3 4
# 163 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/portability_macros.h" 2
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h" 2
# 226 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 1 3 4
# 31 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 1 3 4
# 31 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/mmintrin.h" 1 3 4
# 44 "/usr/lib/gcc/x86_64-linux-gnu/13/include/mmintrin.h" 3 4
typedef int __m64 __attribute__ ((__vector_size__ (8), __may_alias__));
typedef int __m32 __attribute__ ((__vector_size__ (4), __may_alias__));
typedef short __m16 __attribute__ ((__vector_size__ (2), __may_alias__));


typedef int __m64_u __attribute__ ((__vector_size__ (8), __may_alias__, __aligned__ (1)));
typedef int __m32_u __attribute__ ((__vector_size__ (4),
        __may_alias__, __aligned__ (1)));
typedef short __m16_u __attribute__ ((__vector_size__ (2),
          __may_alias__, __aligned__ (1)));


typedef int __v2si __attribute__ ((__vector_size__ (8)));
typedef short __v4hi __attribute__ ((__vector_size__ (8)));
typedef char __v8qi __attribute__ ((__vector_size__ (8)));
typedef long long __v1di __attribute__ ((__vector_size__ (8)));
typedef float __v2sf __attribute__ ((__vector_size__ (8)));


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_empty (void)
{
  __builtin_ia32_emms ();
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_empty (void)
{
  _mm_empty ();
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi32_si64 (int __i)
{
  return (__m64) __builtin_ia32_vec_init_v2si (__i, 0);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_from_int (int __i)
{
  return _mm_cvtsi32_si64 (__i);
}





extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_from_int64 (long long __i)
{
  return (__m64) __i;
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64_m64 (long long __i)
{
  return (__m64) __i;
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64x_si64 (long long __i)
{
  return (__m64) __i;
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_pi64x (long long __i)
{
  return (__m64) __i;
}



extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64_si32 (__m64 __i)
{
  return __builtin_ia32_vec_ext_v2si ((__v2si)__i, 0);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_to_int (__m64 __i)
{
  return _mm_cvtsi64_si32 (__i);
}





extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_to_int64 (__m64 __i)
{
  return (long long)__i;
}

extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtm64_si64 (__m64 __i)
{
  return (long long)__i;
}


extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64_si64x (__m64 __i)
{
  return (long long)__i;
}





extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_packs_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_packsswb ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_packsswb (__m64 __m1, __m64 __m2)
{
  return _mm_packs_pi16 (__m1, __m2);
}




extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_packs_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_packssdw ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_packssdw (__m64 __m1, __m64 __m2)
{
  return _mm_packs_pi32 (__m1, __m2);
}




extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_packs_pu16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_packuswb ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_packuswb (__m64 __m1, __m64 __m2)
{
  return _mm_packs_pu16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_punpckhbw ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_punpckhbw (__m64 __m1, __m64 __m2)
{
  return _mm_unpackhi_pi8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_punpckhwd ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_punpckhwd (__m64 __m1, __m64 __m2)
{
  return _mm_unpackhi_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_punpckhdq ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_punpckhdq (__m64 __m1, __m64 __m2)
{
  return _mm_unpackhi_pi32 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_punpcklbw ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_punpcklbw (__m64 __m1, __m64 __m2)
{
  return _mm_unpacklo_pi8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_punpcklwd ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_punpcklwd (__m64 __m1, __m64 __m2)
{
  return _mm_unpacklo_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_punpckldq ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_punpckldq (__m64 __m1, __m64 __m2)
{
  return _mm_unpacklo_pi32 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddb (__m64 __m1, __m64 __m2)
{
  return _mm_add_pi8 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddw (__m64 __m1, __m64 __m2)
{
  return _mm_add_pi16 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddd ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddd (__m64 __m1, __m64 __m2)
{
  return _mm_add_pi32 (__m1, __m2);
}
# 334 "/usr/lib/gcc/x86_64-linux-gnu/13/include/mmintrin.h" 3 4
extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_si64 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddq ((__v1di)__m1, (__v1di)__m2);
}







extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddsb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddsb (__m64 __m1, __m64 __m2)
{
  return _mm_adds_pi8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddsw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddsw (__m64 __m1, __m64 __m2)
{
  return _mm_adds_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_pu8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddusb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddusb (__m64 __m1, __m64 __m2)
{
  return _mm_adds_pu8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_pu16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_paddusw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_paddusw (__m64 __m1, __m64 __m2)
{
  return _mm_adds_pu16 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubb (__m64 __m1, __m64 __m2)
{
  return _mm_sub_pi8 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubw (__m64 __m1, __m64 __m2)
{
  return _mm_sub_pi16 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubd ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubd (__m64 __m1, __m64 __m2)
{
  return _mm_sub_pi32 (__m1, __m2);
}
# 450 "/usr/lib/gcc/x86_64-linux-gnu/13/include/mmintrin.h" 3 4
extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_si64 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubq ((__v1di)__m1, (__v1di)__m2);
}







extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubsb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubsb (__m64 __m1, __m64 __m2)
{
  return _mm_subs_pi8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubsw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubsw (__m64 __m1, __m64 __m2)
{
  return _mm_subs_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_pu8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubusb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubusb (__m64 __m1, __m64 __m2)
{
  return _mm_subs_pu8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_pu16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_psubusw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psubusw (__m64 __m1, __m64 __m2)
{
  return _mm_subs_pu16 (__m1, __m2);
}




extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_madd_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pmaddwd ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmaddwd (__m64 __m1, __m64 __m2)
{
  return _mm_madd_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mulhi_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pmulhw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmulhw (__m64 __m1, __m64 __m2)
{
  return _mm_mulhi_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mullo_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pmullw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmullw (__m64 __m1, __m64 __m2)
{
  return _mm_mullo_pi16 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sll_pi16 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psllw ((__v4hi)__m, (__v4hi)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psllw (__m64 __m, __m64 __count)
{
  return _mm_sll_pi16 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_slli_pi16 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psllwi ((__v4hi)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psllwi (__m64 __m, int __count)
{
  return _mm_slli_pi16 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sll_pi32 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_pslld ((__v2si)__m, (__v2si)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pslld (__m64 __m, __m64 __count)
{
  return _mm_sll_pi32 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_slli_pi32 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_pslldi ((__v2si)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pslldi (__m64 __m, int __count)
{
  return _mm_slli_pi32 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sll_si64 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psllq ((__v1di)__m, (__v1di)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psllq (__m64 __m, __m64 __count)
{
  return _mm_sll_si64 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_slli_si64 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psllqi ((__v1di)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psllqi (__m64 __m, int __count)
{
  return _mm_slli_si64 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sra_pi16 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psraw ((__v4hi)__m, (__v4hi)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psraw (__m64 __m, __m64 __count)
{
  return _mm_sra_pi16 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srai_pi16 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psrawi ((__v4hi)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrawi (__m64 __m, int __count)
{
  return _mm_srai_pi16 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sra_pi32 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psrad ((__v2si)__m, (__v2si)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrad (__m64 __m, __m64 __count)
{
  return _mm_sra_pi32 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srai_pi32 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psradi ((__v2si)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psradi (__m64 __m, int __count)
{
  return _mm_srai_pi32 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srl_pi16 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psrlw ((__v4hi)__m, (__v4hi)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrlw (__m64 __m, __m64 __count)
{
  return _mm_srl_pi16 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srli_pi16 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psrlwi ((__v4hi)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrlwi (__m64 __m, int __count)
{
  return _mm_srli_pi16 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srl_pi32 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psrld ((__v2si)__m, (__v2si)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrld (__m64 __m, __m64 __count)
{
  return _mm_srl_pi32 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srli_pi32 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psrldi ((__v2si)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrldi (__m64 __m, int __count)
{
  return _mm_srli_pi32 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srl_si64 (__m64 __m, __m64 __count)
{
  return (__m64) __builtin_ia32_psrlq ((__v1di)__m, (__v1di)__count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrlq (__m64 __m, __m64 __count)
{
  return _mm_srl_si64 (__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srli_si64 (__m64 __m, int __count)
{
  return (__m64) __builtin_ia32_psrlqi ((__v1di)__m, __count);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psrlqi (__m64 __m, int __count)
{
  return _mm_srli_si64 (__m, __count);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_and_si64 (__m64 __m1, __m64 __m2)
{
  return __builtin_ia32_pand (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pand (__m64 __m1, __m64 __m2)
{
  return _mm_and_si64 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_andnot_si64 (__m64 __m1, __m64 __m2)
{
  return __builtin_ia32_pandn (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pandn (__m64 __m1, __m64 __m2)
{
  return _mm_andnot_si64 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_or_si64 (__m64 __m1, __m64 __m2)
{
  return __builtin_ia32_por (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_por (__m64 __m1, __m64 __m2)
{
  return _mm_or_si64 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_xor_si64 (__m64 __m1, __m64 __m2)
{
  return __builtin_ia32_pxor (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pxor (__m64 __m1, __m64 __m2)
{
  return _mm_xor_si64 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pcmpeqb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pcmpeqb (__m64 __m1, __m64 __m2)
{
  return _mm_cmpeq_pi8 (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_pi8 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pcmpgtb ((__v8qi)__m1, (__v8qi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pcmpgtb (__m64 __m1, __m64 __m2)
{
  return _mm_cmpgt_pi8 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pcmpeqw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pcmpeqw (__m64 __m1, __m64 __m2)
{
  return _mm_cmpeq_pi16 (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_pi16 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pcmpgtw ((__v4hi)__m1, (__v4hi)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pcmpgtw (__m64 __m1, __m64 __m2)
{
  return _mm_cmpgt_pi16 (__m1, __m2);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pcmpeqd ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pcmpeqd (__m64 __m1, __m64 __m2)
{
  return _mm_cmpeq_pi32 (__m1, __m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_pi32 (__m64 __m1, __m64 __m2)
{
  return (__m64) __builtin_ia32_pcmpgtd ((__v2si)__m1, (__v2si)__m2);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pcmpgtd (__m64 __m1, __m64 __m2)
{
  return _mm_cmpgt_pi32 (__m1, __m2);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setzero_si64 (void)
{
  return (__m64)0LL;
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_pi32 (int __i1, int __i0)
{
  return (__m64) __builtin_ia32_vec_init_v2si (__i0, __i1);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_pi16 (short __w3, short __w2, short __w1, short __w0)
{
  return (__m64) __builtin_ia32_vec_init_v4hi (__w0, __w1, __w2, __w3);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_pi8 (char __b7, char __b6, char __b5, char __b4,
      char __b3, char __b2, char __b1, char __b0)
{
  return (__m64) __builtin_ia32_vec_init_v8qi (__b0, __b1, __b2, __b3,
            __b4, __b5, __b6, __b7);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_pi32 (int __i0, int __i1)
{
  return _mm_set_pi32 (__i1, __i0);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_pi16 (short __w0, short __w1, short __w2, short __w3)
{
  return _mm_set_pi16 (__w3, __w2, __w1, __w0);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_pi8 (char __b0, char __b1, char __b2, char __b3,
       char __b4, char __b5, char __b6, char __b7)
{
  return _mm_set_pi8 (__b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_pi32 (int __i)
{
  return _mm_set_pi32 (__i, __i);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_pi16 (short __w)
{
  return _mm_set_pi16 (__w, __w, __w, __w);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_pi8 (char __b)
{
  return _mm_set_pi8 (__b, __b, __b, __b, __b, __b, __b, __b);
}
# 32 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 2 3 4


# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/mm_malloc.h" 1 3 4
# 32 "/usr/lib/gcc/x86_64-linux-gnu/13/include/mm_malloc.h" 3 4
extern int posix_memalign (void **, size_t, size_t);




static __inline void *
_mm_malloc (size_t __size, size_t __alignment)
{
  void *__ptr;
  if (__alignment == 1)
    return malloc (__size);
  if (__alignment == 2 || (sizeof (void *) == 8 && __alignment == 4))
    __alignment = sizeof (void *);
  if (posix_memalign (&__ptr, __alignment, __size) == 0)
    return __ptr;
  else
    return ((void *)0);
}

static __inline void
_mm_free (void *__ptr)
{
  free (__ptr);
}
# 35 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 2 3 4


enum _mm_hint
{
  _MM_HINT_IT0 = 19,
  _MM_HINT_IT1 = 18,

  _MM_HINT_ET0 = 7,
  _MM_HINT_ET1 = 6,
  _MM_HINT_T0 = 3,
  _MM_HINT_T1 = 2,
  _MM_HINT_T2 = 1,
  _MM_HINT_NTA = 0
};
# 72 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
typedef float __m128 __attribute__ ((__vector_size__ (16), __may_alias__));


typedef float __m128_u __attribute__ ((__vector_size__ (16), __may_alias__, __aligned__ (1)));


typedef float __v4sf __attribute__ ((__vector_size__ (16)));
# 112 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_undefined_ps (void)
{
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Winit-self"
  __m128 __Y = __Y;
#pragma GCC diagnostic pop
  return __Y;
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setzero_ps (void)
{
  return __extension__ (__m128){ 0.0f, 0.0f, 0.0f, 0.0f };
}





extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_addss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_subss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mul_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_mulss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_div_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_divss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sqrt_ss (__m128 __A)
{
  return (__m128) __builtin_ia32_sqrtss ((__v4sf)__A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_rcp_ss (__m128 __A)
{
  return (__m128) __builtin_ia32_rcpss ((__v4sf)__A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_rsqrt_ss (__m128 __A)
{
  return (__m128) __builtin_ia32_rsqrtss ((__v4sf)__A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_minss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_maxss ((__v4sf)__A, (__v4sf)__B);
}



extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_ps (__m128 __A, __m128 __B)
{
  return (__m128) ((__v4sf)__A + (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_ps (__m128 __A, __m128 __B)
{
  return (__m128) ((__v4sf)__A - (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mul_ps (__m128 __A, __m128 __B)
{
  return (__m128) ((__v4sf)__A * (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_div_ps (__m128 __A, __m128 __B)
{
  return (__m128) ((__v4sf)__A / (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sqrt_ps (__m128 __A)
{
  return (__m128) __builtin_ia32_sqrtps ((__v4sf)__A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_rcp_ps (__m128 __A)
{
  return (__m128) __builtin_ia32_rcpps ((__v4sf)__A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_rsqrt_ps (__m128 __A)
{
  return (__m128) __builtin_ia32_rsqrtps ((__v4sf)__A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_minps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_maxps ((__v4sf)__A, (__v4sf)__B);
}



extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_and_ps (__m128 __A, __m128 __B)
{
  return __builtin_ia32_andps (__A, __B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_andnot_ps (__m128 __A, __m128 __B)
{
  return __builtin_ia32_andnps (__A, __B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_or_ps (__m128 __A, __m128 __B)
{
  return __builtin_ia32_orps (__A, __B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_xor_ps (__m128 __A, __m128 __B)
{
  return __builtin_ia32_xorps (__A, __B);
}





extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpeqss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpltss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmple_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpless ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_movss ((__v4sf) __A,
     (__v4sf)
     __builtin_ia32_cmpltss ((__v4sf) __B,
        (__v4sf)
        __A));
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpge_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_movss ((__v4sf) __A,
     (__v4sf)
     __builtin_ia32_cmpless ((__v4sf) __B,
        (__v4sf)
        __A));
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpneq_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpneqss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnlt_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpnltss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnle_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpnless ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpngt_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_movss ((__v4sf) __A,
     (__v4sf)
     __builtin_ia32_cmpnltss ((__v4sf) __B,
         (__v4sf)
         __A));
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnge_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_movss ((__v4sf) __A,
     (__v4sf)
     __builtin_ia32_cmpnless ((__v4sf) __B,
         (__v4sf)
         __A));
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpord_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpordss ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpunord_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpunordss ((__v4sf)__A, (__v4sf)__B);
}





extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpeqps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpltps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmple_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpleps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpgtps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpge_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpgeps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpneq_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpneqps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnlt_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpnltps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnle_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpnleps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpngt_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpngtps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnge_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpngeps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpord_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpordps ((__v4sf)__A, (__v4sf)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpunord_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_cmpunordps ((__v4sf)__A, (__v4sf)__B);
}




extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comieq_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_comieq ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comilt_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_comilt ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comile_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_comile ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comigt_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_comigt ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comige_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_comige ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comineq_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_comineq ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomieq_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_ucomieq ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomilt_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_ucomilt ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomile_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_ucomile ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomigt_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_ucomigt ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomige_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_ucomige ((__v4sf)__A, (__v4sf)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomineq_ss (__m128 __A, __m128 __B)
{
  return __builtin_ia32_ucomineq ((__v4sf)__A, (__v4sf)__B);
}



extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtss_si32 (__m128 __A)
{
  return __builtin_ia32_cvtss2si ((__v4sf) __A);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvt_ss2si (__m128 __A)
{
  return _mm_cvtss_si32 (__A);
}






extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtss_si64 (__m128 __A)
{
  return __builtin_ia32_cvtss2si64 ((__v4sf) __A);
}


extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtss_si64x (__m128 __A)
{
  return __builtin_ia32_cvtss2si64 ((__v4sf) __A);
}




extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtps_pi32 (__m128 __A)
{
  return (__m64) __builtin_ia32_cvtps2pi ((__v4sf) __A);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvt_ps2pi (__m128 __A)
{
  return _mm_cvtps_pi32 (__A);
}


extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttss_si32 (__m128 __A)
{
  return __builtin_ia32_cvttss2si ((__v4sf) __A);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtt_ss2si (__m128 __A)
{
  return _mm_cvttss_si32 (__A);
}





extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttss_si64 (__m128 __A)
{
  return __builtin_ia32_cvttss2si64 ((__v4sf) __A);
}


extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttss_si64x (__m128 __A)
{
  return __builtin_ia32_cvttss2si64 ((__v4sf) __A);
}




extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttps_pi32 (__m128 __A)
{
  return (__m64) __builtin_ia32_cvttps2pi ((__v4sf) __A);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtt_ps2pi (__m128 __A)
{
  return _mm_cvttps_pi32 (__A);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi32_ss (__m128 __A, int __B)
{
  return (__m128) __builtin_ia32_cvtsi2ss ((__v4sf) __A, __B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvt_si2ss (__m128 __A, int __B)
{
  return _mm_cvtsi32_ss (__A, __B);
}





extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64_ss (__m128 __A, long long __B)
{
  return (__m128) __builtin_ia32_cvtsi642ss ((__v4sf) __A, __B);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64x_ss (__m128 __A, long long __B)
{
  return (__m128) __builtin_ia32_cvtsi642ss ((__v4sf) __A, __B);
}




extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpi32_ps (__m128 __A, __m64 __B)
{
  return (__m128) __builtin_ia32_cvtpi2ps ((__v4sf) __A, (__v2si)__B);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvt_pi2ps (__m128 __A, __m64 __B)
{
  return _mm_cvtpi32_ps (__A, __B);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpi16_ps (__m64 __A)
{
  __v4hi __sign;
  __v2si __hisi, __losi;
  __v4sf __zero, __ra, __rb;




  __sign = __builtin_ia32_pcmpgtw ((__v4hi)0LL, (__v4hi)__A);


  __losi = (__v2si) __builtin_ia32_punpcklwd ((__v4hi)__A, __sign);
  __hisi = (__v2si) __builtin_ia32_punpckhwd ((__v4hi)__A, __sign);


  __zero = (__v4sf) _mm_setzero_ps ();
  __ra = __builtin_ia32_cvtpi2ps (__zero, __losi);
  __rb = __builtin_ia32_cvtpi2ps (__ra, __hisi);

  return (__m128) __builtin_ia32_movlhps (__ra, __rb);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpu16_ps (__m64 __A)
{
  __v2si __hisi, __losi;
  __v4sf __zero, __ra, __rb;


  __losi = (__v2si) __builtin_ia32_punpcklwd ((__v4hi)__A, (__v4hi)0LL);
  __hisi = (__v2si) __builtin_ia32_punpckhwd ((__v4hi)__A, (__v4hi)0LL);


  __zero = (__v4sf) _mm_setzero_ps ();
  __ra = __builtin_ia32_cvtpi2ps (__zero, __losi);
  __rb = __builtin_ia32_cvtpi2ps (__ra, __hisi);

  return (__m128) __builtin_ia32_movlhps (__ra, __rb);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpi8_ps (__m64 __A)
{
  __v8qi __sign;




  __sign = __builtin_ia32_pcmpgtb ((__v8qi)0LL, (__v8qi)__A);


  __A = (__m64) __builtin_ia32_punpcklbw ((__v8qi)__A, __sign);

  return _mm_cvtpi16_ps(__A);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpu8_ps(__m64 __A)
{
  __A = (__m64) __builtin_ia32_punpcklbw ((__v8qi)__A, (__v8qi)0LL);
  return _mm_cvtpu16_ps(__A);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpi32x2_ps(__m64 __A, __m64 __B)
{
  __v4sf __zero = (__v4sf) _mm_setzero_ps ();
  __v4sf __sfa = __builtin_ia32_cvtpi2ps (__zero, (__v2si)__A);
  __v4sf __sfb = __builtin_ia32_cvtpi2ps (__sfa, (__v2si)__B);
  return (__m128) __builtin_ia32_movlhps (__sfa, __sfb);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtps_pi16(__m128 __A)
{
  __v4sf __hisf = (__v4sf)__A;
  __v4sf __losf = __builtin_ia32_movhlps (__hisf, __hisf);
  __v2si __hisi = __builtin_ia32_cvtps2pi (__hisf);
  __v2si __losi = __builtin_ia32_cvtps2pi (__losf);
  return (__m64) __builtin_ia32_packssdw (__hisi, __losi);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtps_pi8(__m128 __A)
{
  __v4hi __tmp = (__v4hi) _mm_cvtps_pi16 (__A);
  return (__m64) __builtin_ia32_packsswb (__tmp, (__v4hi)0LL);
}
# 761 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_unpckhps ((__v4sf)__A, (__v4sf)__B);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_unpcklps ((__v4sf)__A, (__v4sf)__B);
}



extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadh_pi (__m128 __A, __m64 const *__P)
{
  return (__m128) __builtin_ia32_loadhps ((__v4sf)__A, (const __v2sf *)__P);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeh_pi (__m64 *__P, __m128 __A)
{
  __builtin_ia32_storehps ((__v2sf *)__P, (__v4sf)__A);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movehl_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_movhlps ((__v4sf)__A, (__v4sf)__B);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movelh_ps (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_ia32_movlhps ((__v4sf)__A, (__v4sf)__B);
}



extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadl_pi (__m128 __A, __m64 const *__P)
{
  return (__m128) __builtin_ia32_loadlps ((__v4sf)__A, (const __v2sf *)__P);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storel_pi (__m64 *__P, __m128 __A)
{
  __builtin_ia32_storelps ((__v2sf *)__P, (__v4sf)__A);
}


extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movemask_ps (__m128 __A)
{
  return __builtin_ia32_movmskps ((__v4sf)__A);
}


extern __inline unsigned int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_getcsr (void)
{
  return __builtin_ia32_stmxcsr ();
}


extern __inline unsigned int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_GET_EXCEPTION_STATE (void)
{
  return _mm_getcsr() & 0x003f;
}

extern __inline unsigned int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_GET_EXCEPTION_MASK (void)
{
  return _mm_getcsr() & 0x1f80;
}

extern __inline unsigned int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_GET_ROUNDING_MODE (void)
{
  return _mm_getcsr() & 0x6000;
}

extern __inline unsigned int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_GET_FLUSH_ZERO_MODE (void)
{
  return _mm_getcsr() & 0x8000;
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setcsr (unsigned int __I)
{
  __builtin_ia32_ldmxcsr (__I);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_SET_EXCEPTION_STATE(unsigned int __mask)
{
  _mm_setcsr((_mm_getcsr() & ~0x003f) | __mask);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_SET_EXCEPTION_MASK (unsigned int __mask)
{
  _mm_setcsr((_mm_getcsr() & ~0x1f80) | __mask);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_SET_ROUNDING_MODE (unsigned int __mode)
{
  _mm_setcsr((_mm_getcsr() & ~0x6000) | __mode);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_MM_SET_FLUSH_ZERO_MODE (unsigned int __mode)
{
  _mm_setcsr((_mm_getcsr() & ~0x8000) | __mode);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_ss (float __F)
{
  return __extension__ (__m128)(__v4sf){ __F, 0.0f, 0.0f, 0.0f };
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_ps (float __F)
{
  return __extension__ (__m128)(__v4sf){ __F, __F, __F, __F };
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_ps1 (float __F)
{
  return _mm_set1_ps (__F);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_ss (float const *__P)
{
  return _mm_set_ss (*__P);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load1_ps (float const *__P)
{
  return _mm_set1_ps (*__P);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_ps1 (float const *__P)
{
  return _mm_load1_ps (__P);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_ps (float const *__P)
{
  return *(__m128 *)__P;
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadu_ps (float const *__P)
{
  return *(__m128_u *)__P;
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadr_ps (float const *__P)
{
  __v4sf __tmp = *(__v4sf *)__P;
  return (__m128) __builtin_ia32_shufps (__tmp, __tmp, (((0) << 6) | ((1) << 4) | ((2) << 2) | (3)));
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_ps (const float __Z, const float __Y, const float __X, const float __W)
{
  return __extension__ (__m128)(__v4sf){ __W, __X, __Y, __Z };
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_ps (float __Z, float __Y, float __X, float __W)
{
  return __extension__ (__m128)(__v4sf){ __Z, __Y, __X, __W };
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_ss (float *__P, __m128 __A)
{
  *__P = ((__v4sf)__A)[0];
}

extern __inline float __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtss_f32 (__m128 __A)
{
  return ((__v4sf)__A)[0];
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_ps (float *__P, __m128 __A)
{
  *(__m128 *)__P = __A;
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeu_ps (float *__P, __m128 __A)
{
  *(__m128_u *)__P = __A;
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store1_ps (float *__P, __m128 __A)
{
  __v4sf __va = (__v4sf)__A;
  __v4sf __tmp = __builtin_ia32_shufps (__va, __va, (((0) << 6) | ((0) << 4) | ((0) << 2) | (0)));
  _mm_storeu_ps (__P, __tmp);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_ps1 (float *__P, __m128 __A)
{
  _mm_store1_ps (__P, __A);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storer_ps (float *__P, __m128 __A)
{
  __v4sf __va = (__v4sf)__A;
  __v4sf __tmp = __builtin_ia32_shufps (__va, __va, (((0) << 6) | ((1) << 4) | ((2) << 2) | (3)));
  _mm_store_ps (__P, __tmp);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_move_ss (__m128 __A, __m128 __B)
{
  return (__m128) __builtin_shuffle ((__v4sf)__A, (__v4sf)__B,
                                     __extension__
                                     (__attribute__((__vector_size__ (16))) int)
                                     {4,1,2,3});
}
# 1069 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_pi16 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pmaxsw ((__v4hi)__A, (__v4hi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmaxsw (__m64 __A, __m64 __B)
{
  return _mm_max_pi16 (__A, __B);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_pu8 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pmaxub ((__v8qi)__A, (__v8qi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmaxub (__m64 __A, __m64 __B)
{
  return _mm_max_pu8 (__A, __B);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_pi16 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pminsw ((__v4hi)__A, (__v4hi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pminsw (__m64 __A, __m64 __B)
{
  return _mm_min_pi16 (__A, __B);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_pu8 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pminub ((__v8qi)__A, (__v8qi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pminub (__m64 __A, __m64 __B)
{
  return _mm_min_pu8 (__A, __B);
}


extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movemask_pi8 (__m64 __A)
{
  return __builtin_ia32_pmovmskb ((__v8qi)__A);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmovmskb (__m64 __A)
{
  return _mm_movemask_pi8 (__A);
}



extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mulhi_pu16 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pmulhuw ((__v4hi)__A, (__v4hi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pmulhuw (__m64 __A, __m64 __B)
{
  return _mm_mulhi_pu16 (__A, __B);
}
# 1171 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_maskmove_si64 (__m64 __A, __m64 __N, char *__P)
{



  typedef long long __v2di __attribute__ ((__vector_size__ (16)));
  typedef char __v16qi __attribute__ ((__vector_size__ (16)));

  __v2di __A128 = __extension__ (__v2di) { ((__v1di) __A)[0], 0 };
  __v2di __N128 = __extension__ (__v2di) { ((__v1di) __N)[0], 0 };


  long unsigned int offset = ((long unsigned int) __P) & 0xf;
  if (offset)
    {


      if (offset > 8)
 offset = 8;
      __P = (char *) (((long unsigned int) __P) - offset);


      switch (offset)
 {
 case 1:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 8);
   break;
 case 2:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 2 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 2 * 8);
   break;
 case 3:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 3 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 3 * 8);
   break;
 case 4:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 4 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 4 * 8);
   break;
 case 5:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 5 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 5 * 8);
   break;
 case 6:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 6 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 6 * 8);
   break;
 case 7:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 7 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 7 * 8);
   break;
 case 8:
   __A128 = __builtin_ia32_pslldqi128 (__A128, 8 * 8);
   __N128 = __builtin_ia32_pslldqi128 (__N128, 8 * 8);
   break;
 default:
   break;
 }
    }
  __builtin_ia32_maskmovdqu ((__v16qi)__A128, (__v16qi)__N128, __P);



}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_maskmovq (__m64 __A, __m64 __N, char *__P)
{
  _mm_maskmove_si64 (__A, __N, __P);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_avg_pu8 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pavgb ((__v8qi)__A, (__v8qi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pavgb (__m64 __A, __m64 __B)
{
  return _mm_avg_pu8 (__A, __B);
}


extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_avg_pu16 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_pavgw ((__v4hi)__A, (__v4hi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_pavgw (__m64 __A, __m64 __B)
{
  return _mm_avg_pu16 (__A, __B);
}




extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sad_pu8 (__m64 __A, __m64 __B)
{
  return (__m64) __builtin_ia32_psadbw ((__v8qi)__A, (__v8qi)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_m_psadbw (__m64 __A, __m64 __B)
{
  return _mm_sad_pu8 (__A, __B);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_stream_pi (__m64 *__P, __m64 __A)
{
  __builtin_ia32_movntq ((unsigned long long *)__P, (unsigned long long)__A);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_stream_ps (float *__P, __m128 __A)
{
  __builtin_ia32_movntps (__P, (__v4sf)__A);
}



extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sfence (void)
{
  __builtin_ia32_sfence ();
}
# 1322 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 1 3 4
# 1323 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 2 3 4
# 1334 "/usr/lib/gcc/x86_64-linux-gnu/13/include/xmmintrin.h" 3 4
extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_pause (void)
{
  __builtin_ia32_pause ();
}
# 32 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 2 3 4
# 40 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 3 4
typedef double __v2df __attribute__ ((__vector_size__ (16)));
typedef long long __v2di __attribute__ ((__vector_size__ (16)));
typedef unsigned long long __v2du __attribute__ ((__vector_size__ (16)));
typedef int __v4si __attribute__ ((__vector_size__ (16)));
typedef unsigned int __v4su __attribute__ ((__vector_size__ (16)));
typedef short __v8hi __attribute__ ((__vector_size__ (16)));
typedef unsigned short __v8hu __attribute__ ((__vector_size__ (16)));
typedef char __v16qi __attribute__ ((__vector_size__ (16)));
typedef signed char __v16qs __attribute__ ((__vector_size__ (16)));
typedef unsigned char __v16qu __attribute__ ((__vector_size__ (16)));



typedef long long __m128i __attribute__ ((__vector_size__ (16), __may_alias__));
typedef double __m128d __attribute__ ((__vector_size__ (16), __may_alias__));


typedef long long __m128i_u __attribute__ ((__vector_size__ (16), __may_alias__, __aligned__ (1)));
typedef double __m128d_u __attribute__ ((__vector_size__ (16), __may_alias__, __aligned__ (1)));






extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_sd (double __F)
{
  return __extension__ (__m128d){ __F, 0.0 };
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_pd (double __F)
{
  return __extension__ (__m128d){ __F, __F };
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_pd1 (double __F)
{
  return _mm_set1_pd (__F);
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_pd (double __W, double __X)
{
  return __extension__ (__m128d){ __X, __W };
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_pd (double __W, double __X)
{
  return __extension__ (__m128d){ __W, __X };
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_undefined_pd (void)
{
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Winit-self"
  __m128d __Y = __Y;
#pragma GCC diagnostic pop
  return __Y;
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setzero_pd (void)
{
  return __extension__ (__m128d){ 0.0, 0.0 };
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_move_sd (__m128d __A, __m128d __B)
{
  return __extension__ (__m128d) __builtin_shuffle ((__v2df)__A, (__v2df)__B, (__v2di){2, 1});
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_pd (double const *__P)
{
  return *(__m128d *)__P;
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadu_pd (double const *__P)
{
  return *(__m128d_u *)__P;
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load1_pd (double const *__P)
{
  return _mm_set1_pd (*__P);
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_sd (double const *__P)
{
  return _mm_set_sd (*__P);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_pd1 (double const *__P)
{
  return _mm_load1_pd (__P);
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadr_pd (double const *__P)
{
  __m128d __tmp = _mm_load_pd (__P);
  return __builtin_ia32_shufpd (__tmp, __tmp, (((0) << 1) | (1)));
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_pd (double *__P, __m128d __A)
{
  *(__m128d *)__P = __A;
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeu_pd (double *__P, __m128d __A)
{
  *(__m128d_u *)__P = __A;
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_sd (double *__P, __m128d __A)
{
  *__P = ((__v2df)__A)[0];
}

extern __inline double __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsd_f64 (__m128d __A)
{
  return ((__v2df)__A)[0];
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storel_pd (double *__P, __m128d __A)
{
  _mm_store_sd (__P, __A);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeh_pd (double *__P, __m128d __A)
{
  *__P = ((__v2df)__A)[1];
}



extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store1_pd (double *__P, __m128d __A)
{
  _mm_store_pd (__P, __builtin_ia32_shufpd (__A, __A, (((0) << 1) | (0))));
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_pd1 (double *__P, __m128d __A)
{
  _mm_store1_pd (__P, __A);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storer_pd (double *__P, __m128d __A)
{
  _mm_store_pd (__P, __builtin_ia32_shufpd (__A, __A, (((0) << 1) | (1))));
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi128_si32 (__m128i __A)
{
  return __builtin_ia32_vec_ext_v4si ((__v4si)__A, 0);
}



extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi128_si64 (__m128i __A)
{
  return ((__v2di)__A)[0];
}


extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi128_si64x (__m128i __A)
{
  return ((__v2di)__A)[0];
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_pd (__m128d __A, __m128d __B)
{
  return (__m128d) ((__v2df)__A + (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_addsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_pd (__m128d __A, __m128d __B)
{
  return (__m128d) ((__v2df)__A - (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_subsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mul_pd (__m128d __A, __m128d __B)
{
  return (__m128d) ((__v2df)__A * (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mul_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_mulsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_div_pd (__m128d __A, __m128d __B)
{
  return (__m128d) ((__v2df)__A / (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_div_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_divsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sqrt_pd (__m128d __A)
{
  return (__m128d)__builtin_ia32_sqrtpd ((__v2df)__A);
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sqrt_sd (__m128d __A, __m128d __B)
{
  __v2df __tmp = __builtin_ia32_movsd ((__v2df)__A, (__v2df)__B);
  return (__m128d)__builtin_ia32_sqrtsd ((__v2df)__tmp);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_minpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_minsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_maxpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_maxsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_and_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_andpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_andnot_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_andnpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_or_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_orpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_xor_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_xorpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpeqpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpltpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmple_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmplepd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpgtpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpge_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpgepd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpneq_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpneqpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnlt_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpnltpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnle_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpnlepd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpngt_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpngtpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnge_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpngepd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpord_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpordpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpunord_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpunordpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpeqsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpltsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmple_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmplesd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_sd (__m128d __A, __m128d __B)
{
  return (__m128d) __builtin_ia32_movsd ((__v2df) __A,
      (__v2df)
      __builtin_ia32_cmpltsd ((__v2df) __B,
         (__v2df)
         __A));
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpge_sd (__m128d __A, __m128d __B)
{
  return (__m128d) __builtin_ia32_movsd ((__v2df) __A,
      (__v2df)
      __builtin_ia32_cmplesd ((__v2df) __B,
         (__v2df)
         __A));
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpneq_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpneqsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnlt_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpnltsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnle_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpnlesd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpngt_sd (__m128d __A, __m128d __B)
{
  return (__m128d) __builtin_ia32_movsd ((__v2df) __A,
      (__v2df)
      __builtin_ia32_cmpnltsd ((__v2df) __B,
          (__v2df)
          __A));
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpnge_sd (__m128d __A, __m128d __B)
{
  return (__m128d) __builtin_ia32_movsd ((__v2df) __A,
      (__v2df)
      __builtin_ia32_cmpnlesd ((__v2df) __B,
          (__v2df)
          __A));
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpord_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpordsd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpunord_sd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_cmpunordsd ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comieq_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_comisdeq ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comilt_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_comisdlt ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comile_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_comisdle ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comigt_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_comisdgt ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comige_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_comisdge ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_comineq_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_comisdneq ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomieq_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_ucomisdeq ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomilt_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_ucomisdlt ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomile_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_ucomisdle ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomigt_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_ucomisdgt ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomige_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_ucomisdge ((__v2df)__A, (__v2df)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_ucomineq_sd (__m128d __A, __m128d __B)
{
  return __builtin_ia32_ucomisdneq ((__v2df)__A, (__v2df)__B);
}



extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_epi64x (long long __q1, long long __q0)
{
  return __extension__ (__m128i)(__v2di){ __q0, __q1 };
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_epi64 (__m64 __q1, __m64 __q0)
{
  return _mm_set_epi64x ((long long)__q1, (long long)__q0);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_epi32 (int __q3, int __q2, int __q1, int __q0)
{
  return __extension__ (__m128i)(__v4si){ __q0, __q1, __q2, __q3 };
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_epi16 (short __q7, short __q6, short __q5, short __q4,
        short __q3, short __q2, short __q1, short __q0)
{
  return __extension__ (__m128i)(__v8hi){
    __q0, __q1, __q2, __q3, __q4, __q5, __q6, __q7 };
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set_epi8 (char __q15, char __q14, char __q13, char __q12,
       char __q11, char __q10, char __q09, char __q08,
       char __q07, char __q06, char __q05, char __q04,
       char __q03, char __q02, char __q01, char __q00)
{
  return __extension__ (__m128i)(__v16qi){
    __q00, __q01, __q02, __q03, __q04, __q05, __q06, __q07,
    __q08, __q09, __q10, __q11, __q12, __q13, __q14, __q15
  };
}



extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_epi64x (long long __A)
{
  return _mm_set_epi64x (__A, __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_epi64 (__m64 __A)
{
  return _mm_set_epi64 (__A, __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_epi32 (int __A)
{
  return _mm_set_epi32 (__A, __A, __A, __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_epi16 (short __A)
{
  return _mm_set_epi16 (__A, __A, __A, __A, __A, __A, __A, __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_set1_epi8 (char __A)
{
  return _mm_set_epi8 (__A, __A, __A, __A, __A, __A, __A, __A,
         __A, __A, __A, __A, __A, __A, __A, __A);
}




extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_epi64 (__m64 __q0, __m64 __q1)
{
  return _mm_set_epi64 (__q1, __q0);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_epi32 (int __q0, int __q1, int __q2, int __q3)
{
  return _mm_set_epi32 (__q3, __q2, __q1, __q0);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_epi16 (short __q0, short __q1, short __q2, short __q3,
         short __q4, short __q5, short __q6, short __q7)
{
  return _mm_set_epi16 (__q7, __q6, __q5, __q4, __q3, __q2, __q1, __q0);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setr_epi8 (char __q00, char __q01, char __q02, char __q03,
        char __q04, char __q05, char __q06, char __q07,
        char __q08, char __q09, char __q10, char __q11,
        char __q12, char __q13, char __q14, char __q15)
{
  return _mm_set_epi8 (__q15, __q14, __q13, __q12, __q11, __q10, __q09, __q08,
         __q07, __q06, __q05, __q04, __q03, __q02, __q01, __q00);
}



extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_load_si128 (__m128i const *__P)
{
  return *__P;
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadu_si128 (__m128i_u const *__P)
{
  return *__P;
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadl_epi64 (__m128i_u const *__P)
{
  return _mm_set_epi64 ((__m64)0LL, *(__m64_u *)__P);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadu_si64 (void const *__P)
{
  return _mm_loadl_epi64 ((__m128i_u *)__P);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadu_si32 (void const *__P)
{
  return _mm_set_epi32 (0, 0, 0, (*(__m32_u *)__P)[0]);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadu_si16 (void const *__P)
{
  return _mm_set_epi16 (0, 0, 0, 0, 0, 0, 0, (*(__m16_u *)__P)[0]);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_store_si128 (__m128i *__P, __m128i __B)
{
  *__P = __B;
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeu_si128 (__m128i_u *__P, __m128i __B)
{
  *__P = __B;
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storel_epi64 (__m128i_u *__P, __m128i __B)
{
  *(__m64_u *)__P = (__m64) ((__v2di)__B)[0];
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeu_si64 (void *__P, __m128i __B)
{
  _mm_storel_epi64 ((__m128i_u *)__P, __B);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeu_si32 (void *__P, __m128i __B)
{
  *(__m32_u *)__P = (__m32) ((__v4si)__B)[0];
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_storeu_si16 (void *__P, __m128i __B)
{
  *(__m16_u *)__P = (__m16) ((__v8hi)__B)[0];
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movepi64_pi64 (__m128i __B)
{
  return (__m64) ((__v2di)__B)[0];
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movpi64_epi64 (__m64 __A)
{
  return _mm_set_epi64 ((__m64)0LL, __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_move_epi64 (__m128i __A)
{
  return (__m128i)__builtin_ia32_movq128 ((__v2di) __A);
}


extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_undefined_si128 (void)
{
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Winit-self"
  __m128i __Y = __Y;
#pragma GCC diagnostic pop
  return __Y;
}


extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_setzero_si128 (void)
{
  return __extension__ (__m128i)(__v4si){ 0, 0, 0, 0 };
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtepi32_pd (__m128i __A)
{
  return (__m128d)__builtin_ia32_cvtdq2pd ((__v4si) __A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtepi32_ps (__m128i __A)
{
  return (__m128)__builtin_ia32_cvtdq2ps ((__v4si) __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpd_epi32 (__m128d __A)
{
  return (__m128i)__builtin_ia32_cvtpd2dq ((__v2df) __A);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpd_pi32 (__m128d __A)
{
  return (__m64)__builtin_ia32_cvtpd2pi ((__v2df) __A);
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpd_ps (__m128d __A)
{
  return (__m128)__builtin_ia32_cvtpd2ps ((__v2df) __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttpd_epi32 (__m128d __A)
{
  return (__m128i)__builtin_ia32_cvttpd2dq ((__v2df) __A);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttpd_pi32 (__m128d __A)
{
  return (__m64)__builtin_ia32_cvttpd2pi ((__v2df) __A);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtpi32_pd (__m64 __A)
{
  return (__m128d)__builtin_ia32_cvtpi2pd ((__v2si) __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtps_epi32 (__m128 __A)
{
  return (__m128i)__builtin_ia32_cvtps2dq ((__v4sf) __A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttps_epi32 (__m128 __A)
{
  return (__m128i)__builtin_ia32_cvttps2dq ((__v4sf) __A);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtps_pd (__m128 __A)
{
  return (__m128d)__builtin_ia32_cvtps2pd ((__v4sf) __A);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsd_si32 (__m128d __A)
{
  return __builtin_ia32_cvtsd2si ((__v2df) __A);
}



extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsd_si64 (__m128d __A)
{
  return __builtin_ia32_cvtsd2si64 ((__v2df) __A);
}


extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsd_si64x (__m128d __A)
{
  return __builtin_ia32_cvtsd2si64 ((__v2df) __A);
}


extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttsd_si32 (__m128d __A)
{
  return __builtin_ia32_cvttsd2si ((__v2df) __A);
}



extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttsd_si64 (__m128d __A)
{
  return __builtin_ia32_cvttsd2si64 ((__v2df) __A);
}


extern __inline long long __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvttsd_si64x (__m128d __A)
{
  return __builtin_ia32_cvttsd2si64 ((__v2df) __A);
}


extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsd_ss (__m128 __A, __m128d __B)
{
  return (__m128)__builtin_ia32_cvtsd2ss ((__v4sf) __A, (__v2df) __B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi32_sd (__m128d __A, int __B)
{
  return (__m128d)__builtin_ia32_cvtsi2sd ((__v2df) __A, __B);
}



extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64_sd (__m128d __A, long long __B)
{
  return (__m128d)__builtin_ia32_cvtsi642sd ((__v2df) __A, __B);
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64x_sd (__m128d __A, long long __B)
{
  return (__m128d)__builtin_ia32_cvtsi642sd ((__v2df) __A, __B);
}


extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtss_sd (__m128d __A, __m128 __B)
{
  return (__m128d)__builtin_ia32_cvtss2sd ((__v2df) __A, (__v4sf)__B);
}
# 961 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 3 4
extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_unpckhpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_pd (__m128d __A, __m128d __B)
{
  return (__m128d)__builtin_ia32_unpcklpd ((__v2df)__A, (__v2df)__B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadh_pd (__m128d __A, double const *__B)
{
  return (__m128d)__builtin_ia32_loadhpd ((__v2df)__A, __B);
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_loadl_pd (__m128d __A, double const *__B)
{
  return (__m128d)__builtin_ia32_loadlpd ((__v2df)__A, __B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movemask_pd (__m128d __A)
{
  return __builtin_ia32_movmskpd ((__v2df)__A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_packs_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_packsswb128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_packs_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_packssdw128 ((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_packus_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_packuswb128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpckhbw128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpckhwd128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpckhdq128 ((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpackhi_epi64 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpckhqdq128 ((__v2di)__A, (__v2di)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpcklbw128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpcklwd128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpckldq128 ((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_unpacklo_epi64 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_punpcklqdq128 ((__v2di)__A, (__v2di)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v16qu)__A + (__v16qu)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v8hu)__A + (__v8hu)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v4su)__A + (__v4su)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_add_epi64 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v2du)__A + (__v2du)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_paddsb128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_paddsw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_epu8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_paddusb128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_adds_epu16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_paddusw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v16qu)__A - (__v16qu)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v8hu)__A - (__v8hu)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v4su)__A - (__v4su)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sub_epi64 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v2du)__A - (__v2du)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psubsb128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psubsw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_epu8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psubusb128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_subs_epu16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psubusw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_madd_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pmaddwd128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mulhi_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pmulhw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mullo_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v8hu)__A * (__v8hu)__B);
}

extern __inline __m64 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mul_su32 (__m64 __A, __m64 __B)
{
  return (__m64)__builtin_ia32_pmuludq ((__v2si)__A, (__v2si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mul_epu32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pmuludq128 ((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_slli_epi16 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psllwi128 ((__v8hi)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_slli_epi32 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_pslldi128 ((__v4si)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_slli_epi64 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psllqi128 ((__v2di)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srai_epi16 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psrawi128 ((__v8hi)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srai_epi32 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psradi128 ((__v4si)__A, __B);
}
# 1248 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 3 4
extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srli_epi16 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psrlwi128 ((__v8hi)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srli_epi32 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psrldi128 ((__v4si)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srli_epi64 (__m128i __A, int __B)
{
  return (__m128i)__builtin_ia32_psrlqi128 ((__v2di)__A, __B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sll_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psllw128((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sll_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pslld128((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sll_epi64 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psllq128((__v2di)__A, (__v2di)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sra_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psraw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sra_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psrad128 ((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srl_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psrlw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srl_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psrld128 ((__v4si)__A, (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_srl_epi64 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psrlq128 ((__v2di)__A, (__v2di)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_and_si128 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v2du)__A & (__v2du)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_andnot_si128 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pandn128 ((__v2di)__A, (__v2di)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_or_si128 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v2du)__A | (__v2du)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_xor_si128 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v2du)__A ^ (__v2du)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v16qi)__A == (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v8hi)__A == (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpeq_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v4si)__A == (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v16qs)__A < (__v16qs)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v8hi)__A < (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmplt_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v4si)__A < (__v4si)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_epi8 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v16qs)__A > (__v16qs)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v8hi)__A > (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cmpgt_epi32 (__m128i __A, __m128i __B)
{
  return (__m128i) ((__v4si)__A > (__v4si)__B);
}
# 1412 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 3 4
extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pmaxsw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_max_epu8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pmaxub128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_epi16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pminsw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_min_epu8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pminub128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline int __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_movemask_epi8 (__m128i __A)
{
  return __builtin_ia32_pmovmskb128 ((__v16qi)__A);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mulhi_epu16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pmulhuw128 ((__v8hi)__A, (__v8hi)__B);
}
# 1475 "/usr/lib/gcc/x86_64-linux-gnu/13/include/emmintrin.h" 3 4
extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_maskmoveu_si128 (__m128i __A, __m128i __B, char *__C)
{
  __builtin_ia32_maskmovdqu ((__v16qi)__A, (__v16qi)__B, __C);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_avg_epu8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pavgb128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_avg_epu16 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_pavgw128 ((__v8hi)__A, (__v8hi)__B);
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_sad_epu8 (__m128i __A, __m128i __B)
{
  return (__m128i)__builtin_ia32_psadbw128 ((__v16qi)__A, (__v16qi)__B);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_stream_si32 (int *__A, int __B)
{
  __builtin_ia32_movnti (__A, __B);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_stream_si64 (long long int *__A, long long int __B)
{
  __builtin_ia32_movnti64 (__A, __B);
}


extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_stream_si128 (__m128i *__A, __m128i __B)
{
  __builtin_ia32_movntdq ((__v2di *)__A, (__v2di)__B);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_stream_pd (double *__A, __m128d __B)
{
  __builtin_ia32_movntpd (__A, (__v2df)__B);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_clflush (void const *__A)
{
  __builtin_ia32_clflush (__A);
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_lfence (void)
{
  __builtin_ia32_lfence ();
}

extern __inline void __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_mfence (void)
{
  __builtin_ia32_mfence ();
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi32_si128 (int __A)
{
  return _mm_set_epi32 (0, 0, 0, __A);
}



extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64_si128 (long long __A)
{
  return _mm_set_epi64x (0, __A);
}


extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_cvtsi64x_si128 (long long __A)
{
  return _mm_set_epi64x (0, __A);
}




extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_castpd_ps(__m128d __A)
{
  return (__m128) __A;
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_castpd_si128(__m128d __A)
{
  return (__m128i) __A;
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_castps_pd(__m128 __A)
{
  return (__m128d) __A;
}

extern __inline __m128i __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_castps_si128(__m128 __A)
{
  return (__m128i) __A;
}

extern __inline __m128 __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_castsi128_ps(__m128i __A)
{
  return (__m128) __A;
}

extern __inline __m128d __attribute__((__gnu_inline__, __always_inline__, __artificial__))
_mm_castsi128_pd(__m128i __A)
{
  return (__m128d) __A;
}
# 227 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h" 2
# 274 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h"

# 274 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h"
static __inline __attribute__((unused)) int ZSTD_isPower2(size_t u) {
    return (u & (u-1)) == 0;
}
# 346 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h"
static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
ptrdiff_t ZSTD_wrappedPtrDiff(unsigned char const* lhs, unsigned char const* rhs)
{
    return lhs - rhs;
}






static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
unsigned char const* ZSTD_wrappedPtrAdd(unsigned char const* ptr, ptrdiff_t add)
{
    return ptr + add;
}







static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
unsigned char const* ZSTD_wrappedPtrSub(unsigned char const* ptr, ptrdiff_t sub)
{
    return ptr - sub;
}







static __inline __attribute__((unused))
unsigned char* ZSTD_maybeNullPtrAdd(unsigned char* ptr, ptrdiff_t add)
{
    return add > 0 ? ptr + add : ptr;
}
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd_errors.h" 1
# 60 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd_errors.h"
typedef enum {
  ZSTD_error_no_error = 0,
  ZSTD_error_GENERIC = 1,
  ZSTD_error_prefix_unknown = 10,
  ZSTD_error_version_unsupported = 12,
  ZSTD_error_frameParameter_unsupported = 14,
  ZSTD_error_frameParameter_windowTooLarge = 16,
  ZSTD_error_corruption_detected = 20,
  ZSTD_error_checksum_wrong = 22,
  ZSTD_error_literals_headerWrong = 24,
  ZSTD_error_dictionary_corrupted = 30,
  ZSTD_error_dictionary_wrong = 32,
  ZSTD_error_dictionaryCreation_failed = 34,
  ZSTD_error_parameter_unsupported = 40,
  ZSTD_error_parameter_combination_unsupported = 41,
  ZSTD_error_parameter_outOfBound = 42,
  ZSTD_error_tableLog_tooLarge = 44,
  ZSTD_error_maxSymbolValue_tooLarge = 46,
  ZSTD_error_maxSymbolValue_tooSmall = 48,
  ZSTD_error_cannotProduce_uncompressedBlock = 49,
  ZSTD_error_stabilityCondition_notRespected = 50,
  ZSTD_error_stage_wrong = 60,
  ZSTD_error_init_missing = 62,
  ZSTD_error_memory_allocation = 64,
  ZSTD_error_workSpace_tooSmall= 66,
  ZSTD_error_dstSize_tooSmall = 70,
  ZSTD_error_srcSize_wrong = 72,
  ZSTD_error_dstBuffer_null = 74,
  ZSTD_error_noForwardProgress_destFull = 80,
  ZSTD_error_noForwardProgress_inputEmpty = 82,

  ZSTD_error_frameIndex_tooLarge = 100,
  ZSTD_error_seekableIO = 102,
  ZSTD_error_dstBuffer_wrong = 104,
  ZSTD_error_srcBuffer_wrong = 105,
  ZSTD_error_sequenceProducer_failed = 106,
  ZSTD_error_externalSequences_invalid = 107,
  ZSTD_error_maxCode = 120
} ZSTD_ErrorCode;

__attribute__ ((visibility ("default"))) const char* ZSTD_getErrorString(ZSTD_ErrorCode code);
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 2

# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/limits.h" 1 3 4
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 2
# 119 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_versionNumber(void);
# 128 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) const char* ZSTD_versionString(void);
# 160 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compress( void* dst, size_t dstCapacity,
                            const void* src, size_t srcSize,
                                  int compressionLevel);
# 173 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decompress( void* dst, size_t dstCapacity,
                              const void* src, size_t compressedSize);
# 205 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_getFrameContentSize(const void *src, size_t srcSize);







__attribute__((deprecated))
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_getDecompressedSize(const void* src, size_t srcSize);
# 227 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_findFrameCompressedSize(const void* src, size_t srcSize);
# 250 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBound(size_t srcSize);
# 259 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_isError(size_t result);
__attribute__ ((visibility ("default"))) ZSTD_ErrorCode ZSTD_getErrorCode(size_t functionResult);
__attribute__ ((visibility ("default"))) const char* ZSTD_getErrorName(size_t result);
__attribute__ ((visibility ("default"))) int ZSTD_minCLevel(void);
__attribute__ ((visibility ("default"))) int ZSTD_maxCLevel(void);
__attribute__ ((visibility ("default"))) int ZSTD_defaultCLevel(void);
# 280 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef struct ZSTD_CCtx_s ZSTD_CCtx;
__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_createCCtx(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCCtx(ZSTD_CCtx* cctx);
# 292 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compressCCtx(ZSTD_CCtx* cctx,
                                     void* dst, size_t dstCapacity,
                               const void* src, size_t srcSize,
                                     int compressionLevel);







typedef struct ZSTD_DCtx_s ZSTD_DCtx;
__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_createDCtx(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDCtx(ZSTD_DCtx* dctx);






__attribute__ ((visibility ("default"))) size_t ZSTD_decompressDCtx(ZSTD_DCtx* dctx,
                                       void* dst, size_t dstCapacity,
                                 const void* src, size_t srcSize);
# 336 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef enum { ZSTD_fast=1,
               ZSTD_dfast=2,
               ZSTD_greedy=3,
               ZSTD_lazy=4,
               ZSTD_lazy2=5,
               ZSTD_btlazy2=6,
               ZSTD_btopt=7,
               ZSTD_btultra=8,
               ZSTD_btultra2=9


} ZSTD_strategy;

typedef enum {





    ZSTD_c_compressionLevel=100,
# 368 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
    ZSTD_c_windowLog=101,







    ZSTD_c_hashLog=102,





    ZSTD_c_chainLog=103,







    ZSTD_c_searchLog=104,



    ZSTD_c_minMatch=105,







    ZSTD_c_targetLength=106,







    ZSTD_c_strategy=107,




    ZSTD_c_targetCBlockSize=130,
# 428 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
    ZSTD_c_enableLongDistanceMatching=160,







    ZSTD_c_ldmHashLog=161,





    ZSTD_c_ldmMinMatch=162,



    ZSTD_c_ldmBucketSizeLog=163,



    ZSTD_c_ldmHashRateLog=164,







    ZSTD_c_contentSizeFlag=200,



    ZSTD_c_checksumFlag=201,
    ZSTD_c_dictIDFlag=202,







    ZSTD_c_nbWorkers=400,
# 480 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
    ZSTD_c_jobSize=401,




    ZSTD_c_overlapLog=402,
# 522 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
     ZSTD_c_experimentalParam1=500,
     ZSTD_c_experimentalParam2=10,
     ZSTD_c_experimentalParam3=1000,
     ZSTD_c_experimentalParam4=1001,
     ZSTD_c_experimentalParam5=1002,

     ZSTD_c_experimentalParam7=1004,
     ZSTD_c_experimentalParam8=1005,
     ZSTD_c_experimentalParam9=1006,
     ZSTD_c_experimentalParam10=1007,
     ZSTD_c_experimentalParam11=1008,
     ZSTD_c_experimentalParam12=1009,
     ZSTD_c_experimentalParam13=1010,
     ZSTD_c_experimentalParam14=1011,
     ZSTD_c_experimentalParam15=1012,
     ZSTD_c_experimentalParam16=1013,
     ZSTD_c_experimentalParam17=1014,
     ZSTD_c_experimentalParam18=1015,
     ZSTD_c_experimentalParam19=1016,
     ZSTD_c_experimentalParam20=1017
} ZSTD_cParameter;

typedef struct {
    size_t error;
    int lowerBound;
    int upperBound;
} ZSTD_bounds;
# 557 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_bounds ZSTD_cParam_getBounds(ZSTD_cParameter cParam);
# 570 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParameter(ZSTD_CCtx* cctx, ZSTD_cParameter param, int value);
# 587 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setPledgedSrcSize(ZSTD_CCtx* cctx, unsigned long long pledgedSrcSize);

typedef enum {
    ZSTD_reset_session_only = 1,
    ZSTD_reset_parameters = 2,
    ZSTD_reset_session_and_parameters = 3
} ZSTD_ResetDirective;
# 609 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_reset(ZSTD_CCtx* cctx, ZSTD_ResetDirective reset);
# 623 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compress2( ZSTD_CCtx* cctx,
                                   void* dst, size_t dstCapacity,
                             const void* src, size_t srcSize);
# 640 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef enum {

    ZSTD_d_windowLogMax=100,
# 661 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
     ZSTD_d_experimentalParam1=1000,
     ZSTD_d_experimentalParam2=1001,
     ZSTD_d_experimentalParam3=1002,
     ZSTD_d_experimentalParam4=1003,
     ZSTD_d_experimentalParam5=1004,
     ZSTD_d_experimentalParam6=1005

} ZSTD_dParameter;
# 677 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_bounds ZSTD_dParam_getBounds(ZSTD_dParameter dParam);
# 686 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_setParameter(ZSTD_DCtx* dctx, ZSTD_dParameter param, int value);







__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_reset(ZSTD_DCtx* dctx, ZSTD_ResetDirective reset);






typedef struct ZSTD_inBuffer_s {
  const void* src;
  size_t size;
  size_t pos;
} ZSTD_inBuffer;

typedef struct ZSTD_outBuffer_s {
  void* dst;
  size_t size;
  size_t pos;
} ZSTD_outBuffer;
# 776 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef ZSTD_CCtx ZSTD_CStream;


__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_createCStream(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCStream(ZSTD_CStream* zcs);


typedef enum {
    ZSTD_e_continue=0,
    ZSTD_e_flush=1,



    ZSTD_e_end=2




} ZSTD_EndDirective;
# 823 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream2( ZSTD_CCtx* cctx,
                                         ZSTD_outBuffer* output,
                                         ZSTD_inBuffer* input,
                                         ZSTD_EndDirective endOp);
# 842 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CStreamInSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_CStreamOutSize(void);
# 862 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_initCStream(ZSTD_CStream* zcs, int compressionLevel);






__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output, ZSTD_inBuffer* input);

__attribute__ ((visibility ("default"))) size_t ZSTD_flushStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output);

__attribute__ ((visibility ("default"))) size_t ZSTD_endStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output);
# 908 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef ZSTD_DCtx ZSTD_DStream;


__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_createDStream(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDStream(ZSTD_DStream* zds);
# 924 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream(ZSTD_DStream* zds);
# 948 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressStream(ZSTD_DStream* zds, ZSTD_outBuffer* output, ZSTD_inBuffer* input);

__attribute__ ((visibility ("default"))) size_t ZSTD_DStreamInSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_DStreamOutSize(void);
# 964 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compress_usingDict(ZSTD_CCtx* ctx,
                                           void* dst, size_t dstCapacity,
                                     const void* src, size_t srcSize,
                                     const void* dict,size_t dictSize,
                                           int compressionLevel);







__attribute__ ((visibility ("default"))) size_t ZSTD_decompress_usingDict(ZSTD_DCtx* dctx,
                                             void* dst, size_t dstCapacity,
                                       const void* src, size_t srcSize,
                                       const void* dict,size_t dictSize);





typedef struct ZSTD_CDict_s ZSTD_CDict;
# 999 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict(const void* dictBuffer, size_t dictSize,
                                         int compressionLevel);




__attribute__ ((visibility ("default"))) size_t ZSTD_freeCDict(ZSTD_CDict* CDict);






__attribute__ ((visibility ("default"))) size_t ZSTD_compress_usingCDict(ZSTD_CCtx* cctx,
                                            void* dst, size_t dstCapacity,
                                      const void* src, size_t srcSize,
                                      const ZSTD_CDict* cdict);


typedef struct ZSTD_DDict_s ZSTD_DDict;




__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict(const void* dictBuffer, size_t dictSize);




__attribute__ ((visibility ("default"))) size_t ZSTD_freeDDict(ZSTD_DDict* ddict);




__attribute__ ((visibility ("default"))) size_t ZSTD_decompress_usingDDict(ZSTD_DCtx* dctx,
                                              void* dst, size_t dstCapacity,
                                        const void* src, size_t srcSize,
                                        const ZSTD_DDict* ddict);
# 1047 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromDict(const void* dict, size_t dictSize);





__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromCDict(const ZSTD_CDict* cdict);





__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromDDict(const ZSTD_DDict* ddict);
# 1071 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromFrame(const void* src, size_t srcSize);
# 1108 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary(ZSTD_CCtx* cctx, const void* dict, size_t dictSize);
# 1122 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict);
# 1143 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refPrefix(ZSTD_CCtx* cctx,
                                 const void* prefix, size_t prefixSize);
# 1161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);
# 1180 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refDDict(ZSTD_DCtx* dctx, const ZSTD_DDict* ddict);
# 1198 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refPrefix(ZSTD_DCtx* dctx,
                                 const void* prefix, size_t prefixSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CCtx(const ZSTD_CCtx* cctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DCtx(const ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CStream(const ZSTD_CStream* zcs);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DStream(const ZSTD_DStream* zds);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CDict(const ZSTD_CDict* cdict);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DDict(const ZSTD_DDict* ddict);
# 1313 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef struct ZSTD_CCtx_params_s ZSTD_CCtx_params;

typedef struct {
    unsigned int offset;




    unsigned int litLength;
    unsigned int matchLength;





    unsigned int rep;
# 1350 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
} ZSTD_Sequence;

typedef struct {
    unsigned windowLog;
    unsigned chainLog;
    unsigned hashLog;
    unsigned searchLog;
    unsigned minMatch;
    unsigned targetLength;
    ZSTD_strategy strategy;
} ZSTD_compressionParameters;

typedef struct {
    int contentSizeFlag;
    int checksumFlag;
    int noDictIDFlag;
} ZSTD_frameParameters;

typedef struct {
    ZSTD_compressionParameters cParams;
    ZSTD_frameParameters fParams;
} ZSTD_parameters;

typedef enum {
    ZSTD_dct_auto = 0,
    ZSTD_dct_rawContent = 1,
    ZSTD_dct_fullDict = 2
} ZSTD_dictContentType_e;

typedef enum {
    ZSTD_dlm_byCopy = 0,
    ZSTD_dlm_byRef = 1
} ZSTD_dictLoadMethod_e;

typedef enum {
    ZSTD_f_zstd1 = 0,
    ZSTD_f_zstd1_magicless = 1


} ZSTD_format_e;

typedef enum {

    ZSTD_d_validateChecksum = 0,
    ZSTD_d_ignoreChecksum = 1
} ZSTD_forceIgnoreChecksum_e;

typedef enum {

    ZSTD_rmd_refSingleDDict = 0,
    ZSTD_rmd_refMultipleDDicts = 1
} ZSTD_refMultipleDDicts_e;

typedef enum {
# 1436 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
    ZSTD_dictDefaultAttach = 0,
    ZSTD_dictForceAttach = 1,
    ZSTD_dictForceCopy = 2,
    ZSTD_dictForceLoad = 3
} ZSTD_dictAttachPref_e;

typedef enum {
  ZSTD_lcm_auto = 0,


  ZSTD_lcm_huffman = 1,

  ZSTD_lcm_uncompressed = 2
} ZSTD_literalCompressionMode_e;

typedef enum {




  ZSTD_ps_auto = 0,
  ZSTD_ps_enable = 1,
  ZSTD_ps_disable = 2
} ZSTD_ParamSwitch_e;
# 1487 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_findDecompressedSize(const void* src, size_t srcSize);
# 1502 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_decompressBound(const void* src, size_t srcSize);





__attribute__ ((visibility ("default"))) size_t ZSTD_frameHeaderSize(const void* src, size_t srcSize);

typedef enum { ZSTD_frame, ZSTD_skippableFrame } ZSTD_FrameType_e;

typedef struct {
    unsigned long long frameContentSize;
    unsigned long long windowSize;
    unsigned blockSizeMax;
    ZSTD_FrameType_e frameType;
    unsigned headerSize;
    unsigned dictID;
    unsigned checksumFlag;
    unsigned _reserved1;
    unsigned _reserved2;
} ZSTD_FrameHeader;







__attribute__ ((visibility ("default"))) size_t ZSTD_getFrameHeader(ZSTD_FrameHeader* zfhPtr, const void* src, size_t srcSize);



__attribute__ ((visibility ("default"))) size_t ZSTD_getFrameHeader_advanced(ZSTD_FrameHeader* zfhPtr, const void* src, size_t srcSize, ZSTD_format_e format);
# 1559 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressionMargin(const void* src, size_t srcSize);
# 1581 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef enum {
  ZSTD_sf_noBlockDelimiters = 0,
  ZSTD_sf_explicitBlockDelimiters = 1
} ZSTD_SequenceFormat_e;
# 1594 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_sequenceBound(size_t srcSize);
# 1624 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t
ZSTD_generateSequences(ZSTD_CCtx* zc,
                       ZSTD_Sequence* outSeqs, size_t outSeqsCapacity,
                       const void* src, size_t srcSize);
# 1641 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_mergeBlockDelimiters(ZSTD_Sequence* sequences, size_t seqsSize);
# 1679 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t
ZSTD_compressSequences(ZSTD_CCtx* cctx,
                       void* dst, size_t dstCapacity,
                 const ZSTD_Sequence* inSeqs, size_t inSeqsSize,
                 const void* src, size_t srcSize);
# 1704 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t
ZSTD_compressSequencesAndLiterals(ZSTD_CCtx* cctx,
                                  void* dst, size_t dstCapacity,
                            const ZSTD_Sequence* inSeqs, size_t nbSequences,
                            const void* literals, size_t litSize, size_t litBufCapacity,
                            size_t decompressedSize);
# 1725 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_writeSkippableFrame(void* dst, size_t dstCapacity,
                                             const void* src, size_t srcSize,
                                                   unsigned magicVariant);
# 1740 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_readSkippableFrame(void* dst, size_t dstCapacity,
                                                  unsigned* magicVariant,
                                                  const void* src, size_t srcSize);




__attribute__ ((visibility ("default"))) unsigned ZSTD_isSkippableFrame(const void* buffer, size_t size);
# 1782 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCCtxSize(int maxCompressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCCtxSize_usingCParams(ZSTD_compressionParameters cParams);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCCtxSize_usingCCtxParams(const ZSTD_CCtx_params* params);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDCtxSize(void);
# 1807 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCStreamSize(int maxCompressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCStreamSize_usingCParams(ZSTD_compressionParameters cParams);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCStreamSize_usingCCtxParams(const ZSTD_CCtx_params* params);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDStreamSize(size_t maxWindowSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDStreamSize_fromFrame(const void* src, size_t srcSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCDictSize(size_t dictSize, int compressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCDictSize_advanced(size_t dictSize, ZSTD_compressionParameters cParams, ZSTD_dictLoadMethod_e dictLoadMethod);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDDictSize(size_t dictSize, ZSTD_dictLoadMethod_e dictLoadMethod);
# 1843 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_initStaticCCtx(void* workspace, size_t workspaceSize);
__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_initStaticCStream(void* workspace, size_t workspaceSize);

__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_initStaticDCtx(void* workspace, size_t workspaceSize);
__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_initStaticDStream(void* workspace, size_t workspaceSize);

__attribute__ ((visibility ("default"))) const ZSTD_CDict* ZSTD_initStaticCDict(
                                        void* workspace, size_t workspaceSize,
                                        const void* dict, size_t dictSize,
                                        ZSTD_dictLoadMethod_e dictLoadMethod,
                                        ZSTD_dictContentType_e dictContentType,
                                        ZSTD_compressionParameters cParams);

__attribute__ ((visibility ("default"))) const ZSTD_DDict* ZSTD_initStaticDDict(
                                        void* workspace, size_t workspaceSize,
                                        const void* dict, size_t dictSize,
                                        ZSTD_dictLoadMethod_e dictLoadMethod,
                                        ZSTD_dictContentType_e dictContentType);







typedef void* (*ZSTD_allocFunction) (void* opaque, size_t size);
typedef void (*ZSTD_freeFunction) (void* opaque, void* address);
typedef struct { ZSTD_allocFunction customAlloc; ZSTD_freeFunction customFree; void* opaque; } ZSTD_customMem;
static

__attribute__((__unused__))






ZSTD_customMem const ZSTD_defaultCMem = { 
# 1880 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 3 4
                                         ((void *)0)
# 1880 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
                                             , 
# 1880 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 3 4
                                               ((void *)0)
# 1880 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
                                                   , 
# 1880 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 3 4
                                                     ((void *)0) 
# 1880 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
                                                          };




__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_createCCtx_advanced(ZSTD_customMem customMem);
__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_createCStream_advanced(ZSTD_customMem customMem);
__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_createDCtx_advanced(ZSTD_customMem customMem);
__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_createDStream_advanced(ZSTD_customMem customMem);

__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict_advanced(const void* dict, size_t dictSize,
                                                  ZSTD_dictLoadMethod_e dictLoadMethod,
                                                  ZSTD_dictContentType_e dictContentType,
                                                  ZSTD_compressionParameters cParams,
                                                  ZSTD_customMem customMem);
# 1906 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef struct POOL_ctx_s ZSTD_threadPool;
__attribute__ ((visibility ("default"))) ZSTD_threadPool* ZSTD_createThreadPool(size_t numThreads);
__attribute__ ((visibility ("default"))) void ZSTD_freeThreadPool (ZSTD_threadPool* pool);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refThreadPool(ZSTD_CCtx* cctx, ZSTD_threadPool* pool);





__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict_advanced2(
    const void* dict, size_t dictSize,
    ZSTD_dictLoadMethod_e dictLoadMethod,
    ZSTD_dictContentType_e dictContentType,
    const ZSTD_CCtx_params* cctxParams,
    ZSTD_customMem customMem);

__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict_advanced(
    const void* dict, size_t dictSize,
    ZSTD_dictLoadMethod_e dictLoadMethod,
    ZSTD_dictContentType_e dictContentType,
    ZSTD_customMem customMem);
# 1939 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict_byReference(const void* dictBuffer, size_t dictSize, int compressionLevel);




__attribute__ ((visibility ("default"))) ZSTD_compressionParameters ZSTD_getCParams(int compressionLevel, unsigned long long estimatedSrcSize, size_t dictSize);




__attribute__ ((visibility ("default"))) ZSTD_parameters ZSTD_getParams(int compressionLevel, unsigned long long estimatedSrcSize, size_t dictSize);




__attribute__ ((visibility ("default"))) size_t ZSTD_checkCParams(ZSTD_compressionParameters params);







__attribute__ ((visibility ("default"))) ZSTD_compressionParameters ZSTD_adjustCParams(ZSTD_compressionParameters cPar, unsigned long long srcSize, size_t dictSize);
# 1971 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setCParams(ZSTD_CCtx* cctx, ZSTD_compressionParameters cparams);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setFParams(ZSTD_CCtx* cctx, ZSTD_frameParameters fparams);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParams(ZSTD_CCtx* cctx, ZSTD_parameters params);





__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_compress_advanced(ZSTD_CCtx* cctx,
                              void* dst, size_t dstCapacity,
                        const void* src, size_t srcSize,
                        const void* dict,size_t dictSize,
                              ZSTD_parameters params);





__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_compress_usingCDict_advanced(ZSTD_CCtx* cctx,
                                              void* dst, size_t dstCapacity,
                                        const void* src, size_t srcSize,
                                        const ZSTD_CDict* cdict,
                                              ZSTD_frameParameters fParams);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary_byReference(ZSTD_CCtx* cctx, const void* dict, size_t dictSize);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary_advanced(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, ZSTD_dictLoadMethod_e dictLoadMethod, ZSTD_dictContentType_e dictContentType);




__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refPrefix_advanced(ZSTD_CCtx* cctx, const void* prefix, size_t prefixSize, ZSTD_dictContentType_e dictContentType);
# 2364 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_getParameter(const ZSTD_CCtx* cctx, ZSTD_cParameter param, int* value);
# 2384 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CCtx_params* ZSTD_createCCtxParams(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCCtxParams(ZSTD_CCtx_params* params);




__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_reset(ZSTD_CCtx_params* params);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_init(ZSTD_CCtx_params* cctxParams, int compressionLevel);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_init_advanced(ZSTD_CCtx_params* cctxParams, ZSTD_parameters params);
# 2412 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_setParameter(ZSTD_CCtx_params* params, ZSTD_cParameter param, int value);






__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_getParameter(const ZSTD_CCtx_params* params, ZSTD_cParameter param, int* value);
# 2428 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParametersUsingCCtxParams(
        ZSTD_CCtx* cctx, const ZSTD_CCtx_params* params);







__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream2_simpleArgs (
                            ZSTD_CCtx* cctx,
                            void* dst, size_t dstCapacity, size_t* dstPos,
                      const void* src, size_t srcSize, size_t* srcPos,
                            ZSTD_EndDirective endOp);
# 2453 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_isFrame(const void* buffer, size_t size);






__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict_byReference(const void* dictBuffer, size_t dictSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary_byReference(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary_advanced(ZSTD_DCtx* dctx, const void* dict, size_t dictSize, ZSTD_dictLoadMethod_e dictLoadMethod, ZSTD_dictContentType_e dictContentType);




__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refPrefix_advanced(ZSTD_DCtx* dctx, const void* prefix, size_t prefixSize, ZSTD_dictContentType_e dictContentType);
# 2488 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_setMaxWindowSize(ZSTD_DCtx* dctx, size_t maxWindowSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_getParameter(ZSTD_DCtx* dctx, ZSTD_dParameter param, int* value);
# 2602 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_DCtx_setFormat(ZSTD_DCtx* dctx, ZSTD_format_e format);







__attribute__ ((visibility ("default"))) size_t ZSTD_decompressStream_simpleArgs (
                            ZSTD_DCtx* dctx,
                            void* dst, size_t dstCapacity, size_t* dstPos,
                      const void* src, size_t srcSize, size_t* srcPos);
# 2639 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_srcSize(ZSTD_CStream* zcs,
                         int compressionLevel,
                         unsigned long long pledgedSrcSize);
# 2657 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_usingDict(ZSTD_CStream* zcs,
                     const void* dict, size_t dictSize,
                           int compressionLevel);
# 2675 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_advanced(ZSTD_CStream* zcs,
                    const void* dict, size_t dictSize,
                          ZSTD_parameters params,
                          unsigned long long pledgedSrcSize);
# 2690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_usingCDict(ZSTD_CStream* zcs, const ZSTD_CDict* cdict);
# 2706 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_usingCDict_advanced(ZSTD_CStream* zcs,
                               const ZSTD_CDict* cdict,
                                     ZSTD_frameParameters fParams,
                                     unsigned long long pledgedSrcSize);
# 2731 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_resetCStream(ZSTD_CStream* zcs, unsigned long long pledgedSrcSize);


typedef struct {
    unsigned long long ingested;
    unsigned long long consumed;
    unsigned long long produced;
    unsigned long long flushed;
    unsigned currentJobID;
    unsigned nbActiveWorkers;
} ZSTD_frameProgression;







__attribute__ ((visibility ("default"))) ZSTD_frameProgression ZSTD_getFrameProgression(const ZSTD_CCtx* cctx);
# 2766 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_toFlushNow(ZSTD_CCtx* cctx);
# 2779 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream_usingDict(ZSTD_DStream* zds, const void* dict, size_t dictSize);
# 2790 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream_usingDDict(ZSTD_DStream* zds, const ZSTD_DDict* ddict);
# 2800 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_resetDStream(ZSTD_DStream* zds);
# 2930 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
typedef size_t (*ZSTD_sequenceProducer_F) (
  void* sequenceProducerState,
  ZSTD_Sequence* outSeqs, size_t outSeqsCapacity,
  const void* src, size_t srcSize,
  const void* dict, size_t dictSize,
  int compressionLevel,
  size_t windowSize
);
# 2958 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) void
ZSTD_registerSequenceProducer(
  ZSTD_CCtx* cctx,
  void* sequenceProducerState,
  ZSTD_sequenceProducer_F sequenceProducer
);
# 2974 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) void
ZSTD_CCtxParams_registerSequenceProducer(
  ZSTD_CCtx_params* params,
  void* sequenceProducerState,
  ZSTD_sequenceProducer_F sequenceProducer
);
# 3026 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBegin(ZSTD_CCtx* cctx, int compressionLevel);
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBegin_usingDict(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, int compressionLevel);
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBegin_usingCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict);

__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_copyCCtx(ZSTD_CCtx* cctx, const ZSTD_CCtx* preparedCCtx, unsigned long long pledgedSrcSize);

__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressContinue(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressEnd(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);


__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_compressBegin_advanced(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, ZSTD_parameters params, unsigned long long pledgedSrcSize);
__attribute__((deprecated))
__attribute__ ((visibility ("default")))
size_t ZSTD_compressBegin_usingCDict_advanced(ZSTD_CCtx* const cctx, const ZSTD_CDict* const cdict, ZSTD_frameParameters const fParams, unsigned long long const pledgedSrcSize);
# 3124 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decodingBufferSize_min(unsigned long long windowSize, unsigned long long frameContentSize);

__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBegin(ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBegin_usingDict(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBegin_usingDDict(ZSTD_DCtx* dctx, const ZSTD_DDict* ddict);

__attribute__ ((visibility ("default"))) size_t ZSTD_nextSrcSizeToDecompress(ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressContinue(ZSTD_DCtx* dctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);


__attribute__((deprecated))
__attribute__ ((visibility ("default"))) void ZSTD_copyDCtx(ZSTD_DCtx* dctx, const ZSTD_DCtx* preparedDCtx);
typedef enum { ZSTDnit_frameHeader, ZSTDnit_blockHeader, ZSTDnit_block, ZSTDnit_lastBlock, ZSTDnit_checksum, ZSTDnit_skippableFrame } ZSTD_nextInputType_e;
__attribute__ ((visibility ("default"))) ZSTD_nextInputType_e ZSTD_nextInputType(ZSTD_DCtx* dctx);
# 3185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h"
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_getBlockSize (const ZSTD_CCtx* cctx);
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBlock (ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBlock(ZSTD_DCtx* dctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
__attribute__((deprecated))
__attribute__ ((visibility ("default"))) size_t ZSTD_insertBlock (ZSTD_DCtx* dctx, const void* blockStart, size_t blockSize);
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 2






static __inline __attribute__((unused)) void* ZSTD_customMalloc(size_t size, ZSTD_customMem customMem)
{
    if (customMem.customAlloc)
        return customMem.customAlloc(customMem.opaque, size);
    return malloc(size);
}

static __inline __attribute__((unused)) void* ZSTD_customCalloc(size_t size, ZSTD_customMem customMem)
{
    if (customMem.customAlloc) {


        void* const ptr = customMem.customAlloc(customMem.opaque, size);
        __builtin_memset((ptr),(0),(size));
        return ptr;
    }
    return calloc((1), (size));
}

static __inline __attribute__((unused)) void ZSTD_customFree(void* ptr, ZSTD_customMem customMem)
{
    if (ptr!=
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 3 4
            ((void *)0)
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h"
                ) {
        if (customMem.customFree)
            customMem.customFree(customMem.opaque, ptr);
        else
            free((ptr));
    }
}
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/debug.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h" 2
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 1 3 4
# 9 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4

# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 10 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stdint.h" 2 3 4
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h" 2

  
# 42 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
 typedef uint8_t BYTE;
  typedef uint8_t U8;
  typedef int8_t S8;
  typedef uint16_t U16;
  typedef int16_t S16;
  typedef uint32_t U32;
  typedef int32_t S32;
  typedef uint64_t U64;
  typedef int64_t S64;
# 79 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
static __inline __attribute__((unused)) unsigned MEM_32bits(void);
static __inline __attribute__((unused)) unsigned MEM_64bits(void);
static __inline __attribute__((unused)) unsigned MEM_isLittleEndian(void);


static __inline __attribute__((unused)) U16 MEM_read16(const void* memPtr);
static __inline __attribute__((unused)) U32 MEM_read32(const void* memPtr);
static __inline __attribute__((unused)) U64 MEM_read64(const void* memPtr);
static __inline __attribute__((unused)) size_t MEM_readST(const void* memPtr);

static __inline __attribute__((unused)) void MEM_write16(void* memPtr, U16 value);
static __inline __attribute__((unused)) void MEM_write32(void* memPtr, U32 value);
static __inline __attribute__((unused)) void MEM_write64(void* memPtr, U64 value);


static __inline __attribute__((unused)) U16 MEM_readLE16(const void* memPtr);
static __inline __attribute__((unused)) U32 MEM_readLE24(const void* memPtr);
static __inline __attribute__((unused)) U32 MEM_readLE32(const void* memPtr);
static __inline __attribute__((unused)) U64 MEM_readLE64(const void* memPtr);
static __inline __attribute__((unused)) size_t MEM_readLEST(const void* memPtr);

static __inline __attribute__((unused)) void MEM_writeLE16(void* memPtr, U16 val);
static __inline __attribute__((unused)) void MEM_writeLE24(void* memPtr, U32 val);
static __inline __attribute__((unused)) void MEM_writeLE32(void* memPtr, U32 val32);
static __inline __attribute__((unused)) void MEM_writeLE64(void* memPtr, U64 val64);
static __inline __attribute__((unused)) void MEM_writeLEST(void* memPtr, size_t val);


static __inline __attribute__((unused)) U32 MEM_readBE32(const void* memPtr);
static __inline __attribute__((unused)) U64 MEM_readBE64(const void* memPtr);
static __inline __attribute__((unused)) size_t MEM_readBEST(const void* memPtr);

static __inline __attribute__((unused)) void MEM_writeBE32(void* memPtr, U32 val32);
static __inline __attribute__((unused)) void MEM_writeBE64(void* memPtr, U64 val64);
static __inline __attribute__((unused)) void MEM_writeBEST(void* memPtr, size_t val);


static __inline __attribute__((unused)) U32 MEM_swap32(U32 in);
static __inline __attribute__((unused)) U64 MEM_swap64(U64 in);
static __inline __attribute__((unused)) size_t MEM_swapST(size_t in);
# 137 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
static __inline __attribute__((unused)) unsigned MEM_32bits(void) { return sizeof(size_t)==4; }
static __inline __attribute__((unused)) unsigned MEM_64bits(void) { return sizeof(size_t)==8; }

static __inline __attribute__((unused)) unsigned MEM_isLittleEndian(void)
{

    return 1;
# 160 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
}
# 177 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
typedef __attribute__((aligned(1))) U16 unalign16;
typedef __attribute__((aligned(1))) U32 unalign32;
typedef __attribute__((aligned(1))) U64 unalign64;
typedef __attribute__((aligned(1))) size_t unalignArch;

static __inline __attribute__((unused)) U16 MEM_read16(const void* ptr) { return *(const unalign16*)ptr; }
static __inline __attribute__((unused)) U32 MEM_read32(const void* ptr) { return *(const unalign32*)ptr; }
static __inline __attribute__((unused)) U64 MEM_read64(const void* ptr) { return *(const unalign64*)ptr; }
static __inline __attribute__((unused)) size_t MEM_readST(const void* ptr) { return *(const unalignArch*)ptr; }

static __inline __attribute__((unused)) void MEM_write16(void* memPtr, U16 value) { *(unalign16*)memPtr = value; }
static __inline __attribute__((unused)) void MEM_write32(void* memPtr, U32 value) { *(unalign32*)memPtr = value; }
static __inline __attribute__((unused)) void MEM_write64(void* memPtr, U64 value) { *(unalign64*)memPtr = value; }
# 233 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h"
static __inline __attribute__((unused)) U32 MEM_swap32_fallback(U32 in)
{
    return ((in << 24) & 0xff000000 ) |
            ((in << 8) & 0x00ff0000 ) |
            ((in >> 8) & 0x0000ff00 ) |
            ((in >> 24) & 0x000000ff );
}

static __inline __attribute__((unused)) U32 MEM_swap32(U32 in)
{




    return __builtin_bswap32(in);





}

static __inline __attribute__((unused)) U64 MEM_swap64_fallback(U64 in)
{
     return ((in << 56) & 0xff00000000000000ULL) |
            ((in << 40) & 0x00ff000000000000ULL) |
            ((in << 24) & 0x0000ff0000000000ULL) |
            ((in << 8) & 0x000000ff00000000ULL) |
            ((in >> 8) & 0x00000000ff000000ULL) |
            ((in >> 24) & 0x0000000000ff0000ULL) |
            ((in >> 40) & 0x000000000000ff00ULL) |
            ((in >> 56) & 0x00000000000000ffULL);
}

static __inline __attribute__((unused)) U64 MEM_swap64(U64 in)
{




    return __builtin_bswap64(in);



}

static __inline __attribute__((unused)) size_t MEM_swapST(size_t in)
{
    if (MEM_32bits())
        return (size_t)MEM_swap32((U32)in);
    else
        return (size_t)MEM_swap64((U64)in);
}



static __inline __attribute__((unused)) U16 MEM_readLE16(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_read16(memPtr);
    else {
        const BYTE* p = (const BYTE*)memPtr;
        return (U16)(p[0] + (p[1]<<8));
    }
}

static __inline __attribute__((unused)) void MEM_writeLE16(void* memPtr, U16 val)
{
    if (MEM_isLittleEndian()) {
        MEM_write16(memPtr, val);
    } else {
        BYTE* p = (BYTE*)memPtr;
        p[0] = (BYTE)val;
        p[1] = (BYTE)(val>>8);
    }
}

static __inline __attribute__((unused)) U32 MEM_readLE24(const void* memPtr)
{
    return (U32)MEM_readLE16(memPtr) + ((U32)(((const BYTE*)memPtr)[2]) << 16);
}

static __inline __attribute__((unused)) void MEM_writeLE24(void* memPtr, U32 val)
{
    MEM_writeLE16(memPtr, (U16)val);
    ((BYTE*)memPtr)[2] = (BYTE)(val>>16);
}

static __inline __attribute__((unused)) U32 MEM_readLE32(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_read32(memPtr);
    else
        return MEM_swap32(MEM_read32(memPtr));
}

static __inline __attribute__((unused)) void MEM_writeLE32(void* memPtr, U32 val32)
{
    if (MEM_isLittleEndian())
        MEM_write32(memPtr, val32);
    else
        MEM_write32(memPtr, MEM_swap32(val32));
}

static __inline __attribute__((unused)) U64 MEM_readLE64(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_read64(memPtr);
    else
        return MEM_swap64(MEM_read64(memPtr));
}

static __inline __attribute__((unused)) void MEM_writeLE64(void* memPtr, U64 val64)
{
    if (MEM_isLittleEndian())
        MEM_write64(memPtr, val64);
    else
        MEM_write64(memPtr, MEM_swap64(val64));
}

static __inline __attribute__((unused)) size_t MEM_readLEST(const void* memPtr)
{
    if (MEM_32bits())
        return (size_t)MEM_readLE32(memPtr);
    else
        return (size_t)MEM_readLE64(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeLEST(void* memPtr, size_t val)
{
    if (MEM_32bits())
        MEM_writeLE32(memPtr, (U32)val);
    else
        MEM_writeLE64(memPtr, (U64)val);
}



static __inline __attribute__((unused)) U32 MEM_readBE32(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_swap32(MEM_read32(memPtr));
    else
        return MEM_read32(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeBE32(void* memPtr, U32 val32)
{
    if (MEM_isLittleEndian())
        MEM_write32(memPtr, MEM_swap32(val32));
    else
        MEM_write32(memPtr, val32);
}

static __inline __attribute__((unused)) U64 MEM_readBE64(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_swap64(MEM_read64(memPtr));
    else
        return MEM_read64(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeBE64(void* memPtr, U64 val64)
{
    if (MEM_isLittleEndian())
        MEM_write64(memPtr, MEM_swap64(val64));
    else
        MEM_write64(memPtr, val64);
}

static __inline __attribute__((unused)) size_t MEM_readBEST(const void* memPtr)
{
    if (MEM_32bits())
        return (size_t)MEM_readBE32(memPtr);
    else
        return (size_t)MEM_readBE64(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeBEST(void* memPtr, size_t val)
{
    if (MEM_32bits())
        MEM_writeBE32(memPtr, (U32)val);
    else
        MEM_writeBE64(memPtr, (U64)val);
}


static __inline __attribute__((unused)) void MEM_check(void) { (void)sizeof(char[((sizeof(size_t)==4) || (sizeof(size_t)==8)) ? 1 : -1]); }
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd_errors.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h" 2
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h"
typedef ZSTD_ErrorCode ERR_enum;
# 52 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h"
static __attribute__((unused)) unsigned ERR_isError(size_t code) { return (code > ((size_t)-ZSTD_error_maxCode)); }

static __attribute__((unused)) ERR_enum ERR_getErrorCode(size_t code) { if (!ERR_isError(code)) return (ERR_enum)0; return (ERR_enum) (0-code); }
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h"
const char* ERR_getErrorString(ERR_enum code);

static __attribute__((unused)) const char* ERR_getErrorName(size_t code)
{
    return ERR_getErrorString(ERR_getErrorCode(code));
}
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h"
static inline __attribute__((unused))
void _force_has_format_string(const char *format, ...) {
  (void)format;
}
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/hist.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/hist.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/hist.h" 2
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/hist.h"
size_t HIST_count(unsigned* count, unsigned* maxSymbolValuePtr,
                  const void* src, size_t srcSize);

unsigned HIST_isError(size_t code);
# 46 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/hist.h"
size_t HIST_count_wksp(unsigned* count, unsigned* maxSymbolValuePtr,
                       const void* src, size_t srcSize,
                       void* workSpace, size_t workSpaceSize);





size_t HIST_countFast(unsigned* count, unsigned* maxSymbolValuePtr,
                      const void* src, size_t srcSize);






size_t HIST_countFast_wksp(unsigned* count, unsigned* maxSymbolValuePtr,
                           const void* src, size_t srcSize,
                           void* workSpace, size_t workSpaceSize);
# 74 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/hist.h"
unsigned HIST_count_simple(unsigned* count, unsigned* maxSymbolValuePtr,
                           const void* src, size_t srcSize);






void HIST_add(unsigned* count, const void* src, size_t srcSize);
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h" 2
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
 unsigned FSE_versionNumber(void);





 size_t FSE_compressBound(size_t size);


 unsigned FSE_isError(size_t code);
 const char* FSE_getErrorName(size_t code);
# 87 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
 unsigned FSE_optimalTableLog(unsigned maxTableLog, size_t srcSize, unsigned maxSymbolValue);
# 100 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
 size_t FSE_normalizeCount(short* normalizedCounter, unsigned tableLog,
                    const unsigned* count, size_t srcSize, unsigned maxSymbolValue, unsigned useLowProbCount);




 size_t FSE_NCountWriteBound(unsigned maxSymbolValue, unsigned tableLog);





 size_t FSE_writeNCount (void* buffer, size_t bufferSize,
                                 const short* normalizedCounter,
                                 unsigned maxSymbolValue, unsigned tableLog);



typedef unsigned FSE_CTable;




 size_t FSE_buildCTable(FSE_CTable* ct, const short* normalizedCounter, unsigned maxSymbolValue, unsigned tableLog);






 size_t FSE_compress_usingCTable (void* dst, size_t dstCapacity, const void* src, size_t srcSize, const FSE_CTable* ct);
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
 size_t FSE_readNCount (short* normalizedCounter,
                           unsigned* maxSymbolValuePtr, unsigned* tableLogPtr,
                           const void* rBuffer, size_t rBuffSize);




 size_t FSE_readNCount_bmi2(short* normalizedCounter,
                           unsigned* maxSymbolValuePtr, unsigned* tableLogPtr,
                           const void* rBuffer, size_t rBuffSize, int bmi2);

typedef unsigned FSE_DTable;
# 229 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/mem.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/error_private.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
static __inline __attribute__((unused)) unsigned ZSTD_countTrailingZeros32_fallback(U32 val)
{
    ((void)0);
    {
        static const U32 DeBruijnBytePos[32] = {0, 1, 28, 2, 29, 14, 24, 3,
                                                30, 22, 20, 15, 25, 17, 4, 8,
                                                31, 27, 13, 23, 21, 19, 16, 7,
                                                26, 12, 18, 6, 11, 5, 10, 9};
        return DeBruijnBytePos[((U32) ((val & -(S32) val) * 0x077CB531U)) >> 27];
    }
}

static __inline __attribute__((unused)) unsigned ZSTD_countTrailingZeros32(U32 val)
{
    ((void)0);
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
    return (unsigned)__builtin_ctz(val);





}

static __inline __attribute__((unused)) unsigned ZSTD_countLeadingZeros32_fallback(U32 val)
{
    ((void)0);
    {
        static const U32 DeBruijnClz[32] = {0, 9, 1, 10, 13, 21, 2, 29,
                                            11, 14, 16, 18, 22, 25, 3, 30,
                                            8, 12, 20, 28, 15, 17, 24, 7,
                                            19, 27, 23, 6, 26, 5, 4, 31};
        val |= val >> 1;
        val |= val >> 2;
        val |= val >> 4;
        val |= val >> 8;
        val |= val >> 16;
        return 31 - DeBruijnClz[(val * 0x07C4ACDDU) >> 27];
    }
}

static __inline __attribute__((unused)) unsigned ZSTD_countLeadingZeros32(U32 val)
{
    ((void)0);
# 85 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
    return (unsigned)__builtin_clz(val);





}

static __inline __attribute__((unused)) unsigned ZSTD_countTrailingZeros64(U64 val)
{
    ((void)0);
# 109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
    return (unsigned)__builtin_ctzll(val);
# 123 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
}

static __inline __attribute__((unused)) unsigned ZSTD_countLeadingZeros64(U64 val)
{
    ((void)0);
# 141 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
    return (unsigned)(__builtin_clzll(val));
# 155 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h"
}

static __inline __attribute__((unused)) unsigned ZSTD_NbCommonBytes(size_t val)
{
    if (MEM_isLittleEndian()) {
        if (MEM_64bits()) {
            return ZSTD_countTrailingZeros64((U64)val) >> 3;
        } else {
            return ZSTD_countTrailingZeros32((U32)val) >> 3;
        }
    } else {
        if (MEM_64bits()) {
            return ZSTD_countLeadingZeros64((U64)val) >> 3;
        } else {
            return ZSTD_countLeadingZeros32((U32)val) >> 3;
        }
    }
}

static __inline __attribute__((unused)) unsigned ZSTD_highbit32(U32 val)
{
    ((void)0);
    return 31 - ZSTD_countLeadingZeros32(val);
}





static __inline __attribute__((unused))
U64 ZSTD_rotateRight_U64(U64 const value, U32 count) {
    ((void)0);
    count &= 0x3F;
    return (value >> count) | (U64)(value << ((0U - count) & 0x3F));
}

static __inline __attribute__((unused))
U32 ZSTD_rotateRight_U32(U32 const value, U32 count) {
    ((void)0);
    count &= 0x1F;
    return (value >> count) | (U32)(value << ((0U - count) & 0x1F));
}

static __inline __attribute__((unused))
U16 ZSTD_rotateRight_U16(U16 const value, U32 count) {
    ((void)0);
    count &= 0x0F;
    return (value >> count) | (U16)(value << ((0U - count) & 0x0F));
}
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h" 2
# 51 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
typedef size_t BitContainerType;




typedef struct {
    BitContainerType bitContainer;
    unsigned bitPos;
    char* startPtr;
    char* ptr;
    char* endPtr;
} BIT_CStream_t;

static __inline __attribute__((unused)) size_t BIT_initCStream(BIT_CStream_t* bitC, void* dstBuffer, size_t dstCapacity);
static __inline __attribute__((unused)) void BIT_addBits(BIT_CStream_t* bitC, BitContainerType value, unsigned nbBits);
static __inline __attribute__((unused)) void BIT_flushBits(BIT_CStream_t* bitC);
static __inline __attribute__((unused)) size_t BIT_closeCStream(BIT_CStream_t* bitC);
# 90 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
typedef struct {
    BitContainerType bitContainer;
    unsigned bitsConsumed;
    const char* ptr;
    const char* start;
    const char* limitPtr;
} BIT_DStream_t;

typedef enum { BIT_DStream_unfinished = 0,
               BIT_DStream_endOfBuffer = 1,
               BIT_DStream_completed = 2,
               BIT_DStream_overflow = 3
    } BIT_DStream_status;

static __inline __attribute__((unused)) size_t BIT_initDStream(BIT_DStream_t* bitD, const void* srcBuffer, size_t srcSize);
static __inline __attribute__((unused)) BitContainerType BIT_readBits(BIT_DStream_t* bitD, unsigned nbBits);
static __inline __attribute__((unused)) BIT_DStream_status BIT_reloadDStream(BIT_DStream_t* bitD);
static __inline __attribute__((unused)) unsigned BIT_endOfDStream(const BIT_DStream_t* bitD);
# 124 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
static __inline __attribute__((unused)) void BIT_addBitsFast(BIT_CStream_t* bitC, BitContainerType value, unsigned nbBits);


static __inline __attribute__((unused)) void BIT_flushBitsFast(BIT_CStream_t* bitC);


static __inline __attribute__((unused)) size_t BIT_readBitsFast(BIT_DStream_t* bitD, unsigned nbBits);



static const unsigned BIT_mask[] = {
    0, 1, 3, 7, 0xF, 0x1F,
    0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF,
    0xFFF, 0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF, 0x1FFFF,
    0x3FFFF, 0x7FFFF, 0xFFFFF, 0x1FFFFF, 0x3FFFFF, 0x7FFFFF,
    0xFFFFFF, 0x1FFFFFF, 0x3FFFFFF, 0x7FFFFFF, 0xFFFFFFF, 0x1FFFFFFF,
    0x3FFFFFFF, 0x7FFFFFFF};
# 150 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
static __inline __attribute__((unused)) size_t BIT_initCStream(BIT_CStream_t* bitC,
                                  void* startPtr, size_t dstCapacity)
{
    bitC->bitContainer = 0;
    bitC->bitPos = 0;
    bitC->startPtr = (char*)startPtr;
    bitC->ptr = bitC->startPtr;
    bitC->endPtr = bitC->startPtr + dstCapacity - sizeof(bitC->bitContainer);
    if (dstCapacity <= sizeof(bitC->bitContainer)) return ((size_t)-ZSTD_error_dstSize_tooSmall);
    return 0;
}

static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_getLowerBits(BitContainerType bitContainer, U32 const nbBits)
{
# 172 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
    ((void)0);
    return bitContainer & BIT_mask[nbBits];

}




static __inline __attribute__((unused)) void BIT_addBits(BIT_CStream_t* bitC,
                            BitContainerType value, unsigned nbBits)
{
    (void)sizeof(char[((sizeof(BIT_mask) / sizeof(BIT_mask[0])) == 32) ? 1 : -1]);
    ((void)0);
    ((void)0);
    bitC->bitContainer |= BIT_getLowerBits(value, nbBits) << bitC->bitPos;
    bitC->bitPos += nbBits;
}




static __inline __attribute__((unused)) void BIT_addBitsFast(BIT_CStream_t* bitC,
                                BitContainerType value, unsigned nbBits)
{
    ((void)0);
    ((void)0);
    bitC->bitContainer |= value << bitC->bitPos;
    bitC->bitPos += nbBits;
}




static __inline __attribute__((unused)) void BIT_flushBitsFast(BIT_CStream_t* bitC)
{
    size_t const nbBytes = bitC->bitPos >> 3;
    ((void)0);
    ((void)0);
    MEM_writeLEST(bitC->ptr, bitC->bitContainer);
    bitC->ptr += nbBytes;
    bitC->bitPos &= 7;
    bitC->bitContainer >>= nbBytes*8;
}






static __inline __attribute__((unused)) void BIT_flushBits(BIT_CStream_t* bitC)
{
    size_t const nbBytes = bitC->bitPos >> 3;
    ((void)0);
    ((void)0);
    MEM_writeLEST(bitC->ptr, bitC->bitContainer);
    bitC->ptr += nbBytes;
    if (bitC->ptr > bitC->endPtr) bitC->ptr = bitC->endPtr;
    bitC->bitPos &= 7;
    bitC->bitContainer >>= nbBytes*8;
}




static __inline __attribute__((unused)) size_t BIT_closeCStream(BIT_CStream_t* bitC)
{
    BIT_addBitsFast(bitC, 1, 1);
    BIT_flushBits(bitC);
    if (bitC->ptr >= bitC->endPtr) return 0;
    return (size_t)(bitC->ptr - bitC->startPtr) + (bitC->bitPos > 0);
}
# 254 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bitstream.h"
static __inline __attribute__((unused)) size_t BIT_initDStream(BIT_DStream_t* bitD, const void* srcBuffer, size_t srcSize)
{
    if (srcSize < 1) { __builtin_memset((bitD),(0),(sizeof(*bitD))); return ((size_t)-ZSTD_error_srcSize_wrong); }

    bitD->start = (const char*)srcBuffer;
    bitD->limitPtr = bitD->start + sizeof(bitD->bitContainer);

    if (srcSize >= sizeof(bitD->bitContainer)) {
        bitD->ptr = (const char*)srcBuffer + srcSize - sizeof(bitD->bitContainer);
        bitD->bitContainer = MEM_readLEST(bitD->ptr);
        { BYTE const lastByte = ((const BYTE*)srcBuffer)[srcSize-1];
          bitD->bitsConsumed = lastByte ? 8 - ZSTD_highbit32(lastByte) : 0;
          if (lastByte == 0) return ((size_t)-ZSTD_error_GENERIC); }
    } else {
        bitD->ptr = bitD->start;
        bitD->bitContainer = *(const BYTE*)(bitD->start);
        switch(srcSize)
        {
        case 7: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[6]) << (sizeof(bitD->bitContainer)*8 - 16);
                ; __attribute__((__fallthrough__));

        case 6: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[5]) << (sizeof(bitD->bitContainer)*8 - 24);
                ; __attribute__((__fallthrough__));

        case 5: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[4]) << (sizeof(bitD->bitContainer)*8 - 32);
                ; __attribute__((__fallthrough__));

        case 4: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[3]) << 24;
                ; __attribute__((__fallthrough__));

        case 3: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[2]) << 16;
                ; __attribute__((__fallthrough__));

        case 2: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[1]) << 8;
                ; __attribute__((__fallthrough__));

        default: break;
        }
        { BYTE const lastByte = ((const BYTE*)srcBuffer)[srcSize-1];
            bitD->bitsConsumed = lastByte ? 8 - ZSTD_highbit32(lastByte) : 0;
            if (lastByte == 0) return ((size_t)-ZSTD_error_corruption_detected);
        }
        bitD->bitsConsumed += (U32)(sizeof(bitD->bitContainer) - srcSize)*8;
    }

    return srcSize;
}

static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_getUpperBits(BitContainerType bitContainer, U32 const start)
{
    return bitContainer >> start;
}

static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_getMiddleBits(BitContainerType bitContainer, U32 const start, U32 const nbBits)
{
    U32 const regMask = sizeof(bitContainer)*8 - 1;

    ((void)0);






    return (bitContainer >> (start & regMask)) & ((((U64)1) << nbBits) - 1);



}







static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_lookBits(const BIT_DStream_t* bitD, U32 nbBits)
{




    return BIT_getMiddleBits(bitD->bitContainer, (sizeof(bitD->bitContainer)*8) - bitD->bitsConsumed - nbBits, nbBits);





}



static __inline __attribute__((unused)) BitContainerType BIT_lookBitsFast(const BIT_DStream_t* bitD, U32 nbBits)
{
    U32 const regMask = sizeof(bitD->bitContainer)*8 - 1;
    ((void)0);
    return (bitD->bitContainer << (bitD->bitsConsumed & regMask)) >> (((regMask+1)-nbBits) & regMask);
}

static inline __attribute__((always_inline)) __attribute__((unused)) void BIT_skipBits(BIT_DStream_t* bitD, U32 nbBits)
{
    bitD->bitsConsumed += nbBits;
}





static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_readBits(BIT_DStream_t* bitD, unsigned nbBits)
{
    BitContainerType const value = BIT_lookBits(bitD, nbBits);
    BIT_skipBits(bitD, nbBits);
    return value;
}



static __inline __attribute__((unused)) BitContainerType BIT_readBitsFast(BIT_DStream_t* bitD, unsigned nbBits)
{
    BitContainerType const value = BIT_lookBitsFast(bitD, nbBits);
    ((void)0);
    BIT_skipBits(bitD, nbBits);
    return value;
}






static __inline __attribute__((unused)) BIT_DStream_status BIT_reloadDStream_internal(BIT_DStream_t* bitD)
{
    ((void)0);
    bitD->ptr -= bitD->bitsConsumed >> 3;
    ((void)0);
    bitD->bitsConsumed &= 7;
    bitD->bitContainer = MEM_readLEST(bitD->ptr);
    return BIT_DStream_unfinished;
}







static __inline __attribute__((unused)) BIT_DStream_status BIT_reloadDStreamFast(BIT_DStream_t* bitD)
{
    if ((__builtin_expect((bitD->ptr < bitD->limitPtr), 0)))
        return BIT_DStream_overflow;
    return BIT_reloadDStream_internal(bitD);
}






static inline __attribute__((always_inline)) __attribute__((unused)) BIT_DStream_status BIT_reloadDStream(BIT_DStream_t* bitD)
{

    if ((__builtin_expect((bitD->bitsConsumed > (sizeof(bitD->bitContainer)*8)), 0))) {
        static const BitContainerType zeroFilled = 0;
        bitD->ptr = (const char*)&zeroFilled;

        return BIT_DStream_overflow;
    }

    ((void)0);

    if (bitD->ptr >= bitD->limitPtr) {
        return BIT_reloadDStream_internal(bitD);
    }
    if (bitD->ptr == bitD->start) {

        if (bitD->bitsConsumed < sizeof(bitD->bitContainer)*8) return BIT_DStream_endOfBuffer;
        return BIT_DStream_completed;
    }

    { U32 nbBytes = bitD->bitsConsumed >> 3;
        BIT_DStream_status result = BIT_DStream_unfinished;
        if (bitD->ptr - nbBytes < bitD->start) {
            nbBytes = (U32)(bitD->ptr - bitD->start);
            result = BIT_DStream_endOfBuffer;
        }
        bitD->ptr -= nbBytes;
        bitD->bitsConsumed -= nbBytes*8;
        bitD->bitContainer = MEM_readLEST(bitD->ptr);
        return result;
    }
}




static __inline __attribute__((unused)) unsigned BIT_endOfDStream(const BIT_DStream_t* DStream)
{
    return ((DStream->ptr == DStream->start) && (DStream->bitsConsumed == sizeof(DStream->bitContainer)*8));
}
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h" 2
# 252 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
unsigned FSE_optimalTableLog_internal(unsigned maxTableLog, size_t srcSize, unsigned maxSymbolValue, unsigned minus);


size_t FSE_buildCTable_rle (FSE_CTable* ct, unsigned char symbolValue);
# 265 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
size_t FSE_buildCTable_wksp(FSE_CTable* ct, const short* normalizedCounter, unsigned maxSymbolValue, unsigned tableLog, void* workSpace, size_t wkspSize);



 size_t FSE_buildDTable_wksp(FSE_DTable* dt, const short* normalizedCounter, unsigned maxSymbolValue, unsigned tableLog, void* workSpace, size_t wkspSize);




size_t FSE_decompress_wksp_bmi2(void* dst, size_t dstCapacity, const void* cSrc, size_t cSrcSize, unsigned maxLog, void* workSpace, size_t wkspSize, int bmi2);



typedef enum {
   FSE_repeat_none,
   FSE_repeat_check,
   FSE_repeat_valid
 } FSE_repeat;
# 291 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
typedef struct {
    ptrdiff_t value;
    const void* stateTable;
    const void* symbolTT;
    unsigned stateLog;
} FSE_CState_t;

static void FSE_initCState(FSE_CState_t* CStatePtr, const FSE_CTable* ct);

static void FSE_encodeSymbol(BIT_CStream_t* bitC, FSE_CState_t* CStatePtr, unsigned symbol);

static void FSE_flushCState(BIT_CStream_t* bitC, const FSE_CState_t* CStatePtr);
# 351 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
typedef struct {
    size_t state;
    const void* table;
} FSE_DState_t;


static void FSE_initDState(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD, const FSE_DTable* dt);

static unsigned char FSE_decodeSymbol(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD);

static unsigned FSE_endOfDState(const FSE_DState_t* DStatePtr);
# 416 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h"
static unsigned char FSE_decodeSymbolFast(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD);






typedef struct {
    int deltaFindState;
    U32 deltaNbBits;
} FSE_symbolCompressionTransform;

static __inline __attribute__((unused)) void FSE_initCState(FSE_CState_t* statePtr, const FSE_CTable* ct)
{
    const void* ptr = ct;
    const U16* u16ptr = (const U16*) ptr;
    const U32 tableLog = MEM_read16(ptr);
    statePtr->value = (ptrdiff_t)1<<tableLog;
    statePtr->stateTable = u16ptr+2;
    statePtr->symbolTT = ct + 1 + (tableLog ? (1<<(tableLog-1)) : 1);
    statePtr->stateLog = tableLog;
}





static __inline __attribute__((unused)) void FSE_initCState2(FSE_CState_t* statePtr, const FSE_CTable* ct, U32 symbol)
{
    FSE_initCState(statePtr, ct);
    { const FSE_symbolCompressionTransform symbolTT = ((const FSE_symbolCompressionTransform*)(statePtr->symbolTT))[symbol];
        const U16* stateTable = (const U16*)(statePtr->stateTable);
        U32 nbBitsOut = (U32)((symbolTT.deltaNbBits + (1<<15)) >> 16);
        statePtr->value = (nbBitsOut << 16) - symbolTT.deltaNbBits;
        statePtr->value = stateTable[(statePtr->value >> nbBitsOut) + symbolTT.deltaFindState];
    }
}

static __inline __attribute__((unused)) void FSE_encodeSymbol(BIT_CStream_t* bitC, FSE_CState_t* statePtr, unsigned symbol)
{
    FSE_symbolCompressionTransform const symbolTT = ((const FSE_symbolCompressionTransform*)(statePtr->symbolTT))[symbol];
    const U16* const stateTable = (const U16*)(statePtr->stateTable);
    U32 const nbBitsOut = (U32)((statePtr->value + symbolTT.deltaNbBits) >> 16);
    BIT_addBits(bitC, (BitContainerType)statePtr->value, nbBitsOut);
    statePtr->value = stateTable[ (statePtr->value >> nbBitsOut) + symbolTT.deltaFindState];
}

static __inline __attribute__((unused)) void FSE_flushCState(BIT_CStream_t* bitC, const FSE_CState_t* statePtr)
{
    BIT_addBits(bitC, (BitContainerType)statePtr->value, statePtr->stateLog);
    BIT_flushBits(bitC);
}







static __inline __attribute__((unused)) U32 FSE_getMaxNbBits(const void* symbolTTPtr, U32 symbolValue)
{
    const FSE_symbolCompressionTransform* symbolTT = (const FSE_symbolCompressionTransform*) symbolTTPtr;
    return (symbolTT[symbolValue].deltaNbBits + ((1<<16)-1)) >> 16;
}





static __inline __attribute__((unused)) U32 FSE_bitCost(const void* symbolTTPtr, U32 tableLog, U32 symbolValue, U32 accuracyLog)
{
    const FSE_symbolCompressionTransform* symbolTT = (const FSE_symbolCompressionTransform*) symbolTTPtr;
    U32 const minNbBits = symbolTT[symbolValue].deltaNbBits >> 16;
    U32 const threshold = (minNbBits+1) << 16;
    ((void)0);
    ((void)0);
    { U32 const tableSize = 1 << tableLog;
        U32 const deltaFromThreshold = threshold - (symbolTT[symbolValue].deltaNbBits + tableSize);
        U32 const normalizedDeltaFromThreshold = (deltaFromThreshold << accuracyLog) >> tableLog;
        U32 const bitMultiplier = 1 << accuracyLog;
        ((void)0);
        ((void)0);
        return (minNbBits+1)*bitMultiplier - normalizedDeltaFromThreshold;
    }
}




typedef struct {
    U16 tableLog;
    U16 fastMode;
} FSE_DTableHeader;

typedef struct
{
    unsigned short newState;
    unsigned char symbol;
    unsigned char nbBits;
} FSE_decode_t;

static __inline __attribute__((unused)) void FSE_initDState(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD, const FSE_DTable* dt)
{
    const void* ptr = dt;
    const FSE_DTableHeader* const DTableH = (const FSE_DTableHeader*)ptr;
    DStatePtr->state = BIT_readBits(bitD, DTableH->tableLog);
    BIT_reloadDStream(bitD);
    DStatePtr->table = dt + 1;
}

static __inline __attribute__((unused)) BYTE FSE_peekSymbol(const FSE_DState_t* DStatePtr)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    return DInfo.symbol;
}

static __inline __attribute__((unused)) void FSE_updateState(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    U32 const nbBits = DInfo.nbBits;
    size_t const lowBits = BIT_readBits(bitD, nbBits);
    DStatePtr->state = DInfo.newState + lowBits;
}

static __inline __attribute__((unused)) BYTE FSE_decodeSymbol(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    U32 const nbBits = DInfo.nbBits;
    BYTE const symbol = DInfo.symbol;
    size_t const lowBits = BIT_readBits(bitD, nbBits);

    DStatePtr->state = DInfo.newState + lowBits;
    return symbol;
}



static __inline __attribute__((unused)) BYTE FSE_decodeSymbolFast(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    U32 const nbBits = DInfo.nbBits;
    BYTE const symbol = DInfo.symbol;
    size_t const lowBits = BIT_readBitsFast(bitD, nbBits);

    DStatePtr->state = DInfo.newState + lowBits;
    return symbol;
}

static __inline __attribute__((unused)) unsigned FSE_endOfDState(const FSE_DState_t* DStatePtr)
{
    return DStatePtr->state == 0;
}
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h" 1
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h" 2



size_t HUF_compressBound(size_t size);


unsigned HUF_isError(size_t code);
const char* HUF_getErrorName(size_t code);
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
typedef size_t HUF_CElt;






typedef U32 HUF_DTable;
# 80 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
typedef enum {




    HUF_flags_bmi2 = (1 << 0),




    HUF_flags_optimalDepth = (1 << 1),




    HUF_flags_preferRepeat = (1 << 2),




    HUF_flags_suspectUncompressible = (1 << 3),




    HUF_flags_disableAsm = (1 << 4),




    HUF_flags_disableFast = (1 << 5)
} HUF_flags_e;
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
unsigned HUF_minTableLog(unsigned symbolCardinality);
unsigned HUF_cardinality(const unsigned* count, unsigned maxSymbolValue);
unsigned HUF_optimalTableLog(unsigned maxTableLog, size_t srcSize, unsigned maxSymbolValue, void* workSpace,
 size_t wkspSize, HUF_CElt* table, const unsigned* count, int flags);
size_t HUF_writeCTable_wksp(void* dst, size_t maxDstSize, const HUF_CElt* CTable, unsigned maxSymbolValue, unsigned huffLog, void* workspace, size_t workspaceSize);
size_t HUF_compress4X_usingCTable(void* dst, size_t dstSize, const void* src, size_t srcSize, const HUF_CElt* CTable, int flags);
size_t HUF_estimateCompressedSize(const HUF_CElt* CTable, const unsigned* count, unsigned maxSymbolValue);
int HUF_validateCTable(const HUF_CElt* CTable, const unsigned* count, unsigned maxSymbolValue);

typedef enum {
   HUF_repeat_none,
   HUF_repeat_check,
   HUF_repeat_valid
 } HUF_repeat;







size_t HUF_compress4X_repeat(void* dst, size_t dstSize,
                       const void* src, size_t srcSize,
                       unsigned maxSymbolValue, unsigned tableLog,
                       void* workSpace, size_t wkspSize,
                       HUF_CElt* hufTable, HUF_repeat* repeat, int flags);







size_t HUF_buildCTable_wksp (HUF_CElt* tree,
                       const unsigned* count, U32 maxSymbolValue, U32 maxNbBits,
                             void* workSpace, size_t wkspSize);






size_t HUF_readStats(BYTE* huffWeight, size_t hwSize,
                     U32* rankStats, U32* nbSymbolsPtr, U32* tableLogPtr,
                     const void* src, size_t srcSize);
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
size_t HUF_readStats_wksp(BYTE* huffWeight, size_t hwSize,
                          U32* rankStats, U32* nbSymbolsPtr, U32* tableLogPtr,
                          const void* src, size_t srcSize,
                          void* workspace, size_t wkspSize,
                          int flags);



size_t HUF_readCTable (HUF_CElt* CTable, unsigned* maxSymbolValuePtr, const void* src, size_t srcSize, unsigned *hasZeroWeights);






U32 HUF_getNbBitsFromCTable(const HUF_CElt* symbolTable, U32 symbolValue);

typedef struct {
    BYTE tableLog;
    BYTE maxSymbolValue;
    BYTE unused[sizeof(size_t) - 2];
} HUF_CTableHeader;




HUF_CTableHeader HUF_readCTableHeader(HUF_CElt const* ctable);
# 223 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
U32 HUF_selectDecoder (size_t dstSize, size_t cSrcSize);
# 243 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h"
size_t HUF_compress1X_usingCTable(void* dst, size_t dstSize, const void* src, size_t srcSize, const HUF_CElt* CTable, int flags);






size_t HUF_compress1X_repeat(void* dst, size_t dstSize,
                       const void* src, size_t srcSize,
                       unsigned maxSymbolValue, unsigned tableLog,
                       void* workSpace, size_t wkspSize,
                       HUF_CElt* hufTable, HUF_repeat* repeat, int flags);

size_t HUF_decompress1X_DCtx_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);

size_t HUF_decompress1X2_DCtx_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);





size_t HUF_decompress1X_usingDTable(void* dst, size_t maxDstSize, const void* cSrc, size_t cSrcSize, const HUF_DTable* DTable, int flags);

size_t HUF_decompress1X1_DCtx_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);

size_t HUF_decompress4X_usingDTable(void* dst, size_t maxDstSize, const void* cSrc, size_t cSrcSize, const HUF_DTable* DTable, int flags);
size_t HUF_decompress4X_hufOnly_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);

size_t HUF_readDTableX1_wksp(HUF_DTable* DTable, const void* src, size_t srcSize, void* workSpace, size_t wkspSize, int flags);


size_t HUF_readDTableX2_wksp(HUF_DTable* DTable, const void* src, size_t srcSize, void* workSpace, size_t wkspSize, int flags);
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 1
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/cpu.h" 1
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/cpu.h"
typedef struct {
    U32 f1c;
    U32 f1d;
    U32 f7b;
    U32 f7c;
} ZSTD_cpuid_t;

static __inline __attribute__((unused)) ZSTD_cpuid_t ZSTD_cpuid(void) {
    U32 f1c = 0;
    U32 f1d = 0;
    U32 f7b = 0;
    U32 f7c = 0;
# 122 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/cpu.h"
    U32 n;
    __asm__("cpuid" : "=a"(n) : "a"(0) : "ebx", "ecx", "edx");
    if (n >= 1) {
      U32 f1a;
      __asm__("cpuid" : "=a"(f1a), "=c"(f1c), "=d"(f1d) : "a"(1) : "ebx");
    }
    if (n >= 7) {
      U32 f7a;
      __asm__("cpuid"
              : "=a"(f7a), "=b"(f7b), "=c"(f7c)
              : "a"(7), "c"(0)
              : "edx");
    }

    {
        ZSTD_cpuid_t cpuid;
        cpuid.f1c = f1c;
        cpuid.f1d = f1d;
        cpuid.f7b = f7b;
        cpuid.f7c = f7c;
        return cpuid;
    }
}
# 153 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/cpu.h"
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse3(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 0)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pclmuldq(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 1)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_dtes64(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 2)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_monitor(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 3)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_dscpl(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 4)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_vmx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 5)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_smx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 6)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_eist(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 7)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tm2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 8)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_ssse3(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 9)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cnxtid(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 10)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_fma(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 12)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cx16(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 13)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_xtpr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 14)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pdcm(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 15)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pcid(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 17)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_dca(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 18)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse41(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 19)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse42(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 20)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_x2apic(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 21)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_movbe(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 22)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_popcnt(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 23)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tscdeadline(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 24)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_aes(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 25)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_xsave(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 26)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_osxsave(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 27)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 28)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_f16c(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 29)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_rdrand(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 30)) != 0; }


  static __inline __attribute__((unused)) int ZSTD_cpuid_fpu(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 0)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_vme(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 1)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_de(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 2)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pse(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 3)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tsc(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 4)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_msr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 5)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pae(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 6)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mce(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 7)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cx8(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 8)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_apic(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 9)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sep(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 11)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mtrr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 12)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pge(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 13)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mca(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 14)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cmov(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 15)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pat(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 16)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pse36(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 17)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_psn(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 18)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_clfsh(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 19)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_ds(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 21)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_acpi(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 22)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mmx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 23)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_fxsr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 24)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 25)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 26)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_ss(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 27)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_htt(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 28)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tm(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 29)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pbe(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 31)) != 0; }




  static __inline __attribute__((unused)) int ZSTD_cpuid_bmi1(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 3)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_hle(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 4)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 5)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_smep(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 7)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_bmi2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 8)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_erms(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 9)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_invpcid(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 10)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_rtm(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 11)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mpx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 14)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512f(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 16)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512dq(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 17)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_rdseed(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 18)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_adx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 19)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_smap(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 20)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512ifma(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 21)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pcommit(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 22)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_clflushopt(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 23)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_clwb(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 24)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512pf(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 26)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512er(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 27)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512cd(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 28)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sha(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 29)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512bw(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 30)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512vl(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 31)) != 0; }


  static __inline __attribute__((unused)) int ZSTD_cpuid_prefetchwt1(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7c) & (1U << 0)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512vbmi(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7c) & (1U << 1)) != 0; }
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 2




# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 1
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h" 1
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/huf.h" 1
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h" 1
# 547 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((const)) unsigned ZSTD_XXH_versionNumber (void);
# 556 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 557 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h" 2



typedef enum {
    XXH_OK = 0,
    XXH_ERROR
} XXH_errorcode;
# 585 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
    typedef uint32_t XXH32_hash_t;
# 635 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((pure)) XXH32_hash_t ZSTD_XXH32 (const void* input, size_t length, XXH32_hash_t seed);
# 644 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
typedef struct XXH32_state_s XXH32_state_t;
# 654 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((malloc)) XXH32_state_t* ZSTD_XXH32_createState(void);
# 665 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 XXH_errorcode ZSTD_XXH32_freeState(XXH32_state_t* statePtr);
# 674 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 void ZSTD_XXH32_copyState(XXH32_state_t* dst_state, const XXH32_state_t* src_state);
# 690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 XXH_errorcode ZSTD_XXH32_reset (XXH32_state_t* statePtr, XXH32_hash_t seed);
# 711 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 XXH_errorcode ZSTD_XXH32_update (XXH32_state_t* statePtr, const void* input, size_t length);
# 727 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((pure)) XXH32_hash_t ZSTD_XXH32_digest (const XXH32_state_t* statePtr);







typedef struct {
    unsigned char digest[4];
} XXH32_canonical_t;
# 750 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 void ZSTD_XXH32_canonicalFromHash(XXH32_canonical_t* dst, XXH32_hash_t hash);
# 764 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((pure)) XXH32_hash_t ZSTD_XXH32_hashFromCanonical(const XXH32_canonical_t* src);
# 859 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
   typedef uint64_t XXH64_hash_t;
# 904 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((pure)) XXH64_hash_t ZSTD_XXH64( const void* input, size_t length, XXH64_hash_t seed);
# 913 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
typedef struct XXH64_state_s XXH64_state_t;
# 923 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((malloc)) XXH64_state_t* ZSTD_XXH64_createState(void);
# 934 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 XXH_errorcode ZSTD_XXH64_freeState(XXH64_state_t* statePtr);
# 944 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 void ZSTD_XXH64_copyState( XXH64_state_t* dst_state, const XXH64_state_t* src_state);
# 960 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 XXH_errorcode ZSTD_XXH64_reset ( XXH64_state_t* statePtr, XXH64_hash_t seed);
# 981 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 XXH_errorcode ZSTD_XXH64_update ( XXH64_state_t* statePtr, const void* input, size_t length);
# 997 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((pure)) XXH64_hash_t ZSTD_XXH64_digest ( const XXH64_state_t* statePtr);






typedef struct { unsigned char digest[sizeof(XXH64_hash_t)]; } XXH64_canonical_t;
# 1017 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 void ZSTD_XXH64_canonicalFromHash( XXH64_canonical_t* dst, XXH64_hash_t hash);
# 1031 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
 __attribute__((pure)) XXH64_hash_t ZSTD_XXH64_hashFromCanonical( const XXH64_canonical_t* src);
# 1619 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
struct XXH32_state_s {
   XXH32_hash_t total_len_32;
   XXH32_hash_t large_len;
   XXH32_hash_t v[4];
   XXH32_hash_t mem32[4];
   XXH32_hash_t memsize;
   XXH32_hash_t reserved;
};
# 1643 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/xxhash.h"
struct XXH64_state_s {
   XXH64_hash_t total_len;
   XXH64_hash_t v[4];
   XXH64_hash_t mem64[4];
   XXH32_hash_t memsize;
   XXH32_hash_t reserved32;
   XXH64_hash_t reserved64;
};
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h" 2
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h"
struct ZSTD_CCtx_s;
struct ZSTD_DCtx_s;
struct ZSTD_CCtx_params_s;

typedef struct {
# 60 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h"
    unsigned version;



    int streaming;



    unsigned dictionaryID;




    int dictionaryIsCold;



    size_t dictionarySize;



    size_t uncompressedSize;



    size_t compressedSize;



    struct ZSTD_CCtx_params_s const* params;



    struct ZSTD_CCtx_s const* cctx;



    struct ZSTD_DCtx_s const* dctx;
} ZSTD_Trace;
# 114 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h"
typedef unsigned long long ZSTD_TraceCtx;
# 123 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h"
__attribute__((__weak__)) ZSTD_TraceCtx ZSTD_trace_compress_begin(
    struct ZSTD_CCtx_s const* cctx);






__attribute__((__weak__)) void ZSTD_trace_compress_end(
    ZSTD_TraceCtx ctx,
    ZSTD_Trace const* trace);
# 142 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_trace.h"
__attribute__((__weak__)) ZSTD_TraceCtx ZSTD_trace_decompress_begin(
    struct ZSTD_DCtx_s const* dctx);






__attribute__((__weak__)) void ZSTD_trace_decompress_end(
    ZSTD_TraceCtx ctx,
    ZSTD_Trace const* trace);
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h" 2
# 65 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
static __attribute__((unused)) const U32 repStartValue[3] = { 1, 4, 8 };
# 79 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
static __attribute__((unused)) const size_t ZSTD_fcs_fieldSize[4] = { 0, 2, 4, 8 };
static __attribute__((unused)) const size_t ZSTD_did_fieldSize[4] = { 0, 1, 2, 4 };




static __attribute__((unused)) const size_t ZSTD_blockHeaderSize = 3;
typedef enum { bt_raw, bt_rle, bt_compressed, bt_reserved } blockType_e;







typedef enum { set_basic, set_rle, set_compressed, set_repeat } SymbolEncodingType_e;
# 119 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
static __attribute__((unused)) const U8 LL_bits[35 +1] = {
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 2, 2, 3, 3,
     4, 6, 7, 8, 9,10,11,12,
    13,14,15,16
};
static __attribute__((unused)) const S16 LL_defaultNorm[35 +1] = {
     4, 3, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 1, 1, 1,
     2, 2, 2, 2, 2, 2, 2, 2,
     2, 3, 2, 1, 1, 1, 1, 1,
    -1,-1,-1,-1
};

static __attribute__((unused)) const U32 LL_defaultNormLog = 6;

static __attribute__((unused)) const U8 ML_bits[52 +1] = {
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 2, 2, 3, 3,
     4, 4, 5, 7, 8, 9,10,11,
    12,13,14,15,16
};
static __attribute__((unused)) const S16 ML_defaultNorm[52 +1] = {
     1, 4, 3, 2, 2, 2, 2, 2,
     2, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1,-1,-1,
    -1,-1,-1,-1,-1
};

static __attribute__((unused)) const U32 ML_defaultNormLog = 6;

static __attribute__((unused)) const S16 OF_defaultNorm[28 +1] = {
     1, 1, 1, 1, 1, 1, 2, 2,
     2, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
    -1,-1,-1,-1,-1
};

static __attribute__((unused)) const U32 OF_defaultNormLog = 5;





static void ZSTD_copy8(void* dst, const void* src) {



    __builtin_memcpy((dst),(src),(8));

}






static void ZSTD_copy16(void* dst, const void* src) {



    _mm_storeu_si128((__m128i*)dst, _mm_loadu_si128((const __m128i*)src));
# 196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
}





typedef enum {
    ZSTD_no_overlap,
    ZSTD_overlap_src_before_dst

} ZSTD_overlap_e;
# 215 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
static __inline __attribute__((unused)) __attribute__((always_inline))
void ZSTD_wildcopy(void* dst, const void* src, ptrdiff_t length, ZSTD_overlap_e const ovtype)
{
    ptrdiff_t diff = (BYTE*)dst - (const BYTE*)src;
    const BYTE* ip = (const BYTE*)src;
    BYTE* op = (BYTE*)dst;
    BYTE* const oend = op + length;

    if (ovtype == ZSTD_overlap_src_before_dst && diff < 16) {

        do {
            do { ZSTD_copy8(op,ip); op+=8; ip+=8; } while (0);
        } while (op < oend);
    } else {
        ((void)0);






        ZSTD_copy16(op, ip);
        if (16 >= length) return;
        op += 16;
        ip += 16;
        do {
            do { ZSTD_copy16(op,ip); op+=16; ip+=16; } while (0);
            do { ZSTD_copy16(op,ip); op+=16; ip+=16; } while (0);
        }
        while (op < oend);
    }
}

static __inline __attribute__((unused)) size_t ZSTD_limitCopy(void* dst, size_t dstCapacity, const void* src, size_t srcSize)
{
    size_t const length = ((dstCapacity)<(srcSize) ? (dstCapacity) : (srcSize));
    if (length > 0) {
        __builtin_memcpy((dst),(src),(length));
    }
    return length;
}
# 268 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
typedef enum {
    ZSTD_bm_buffered = 0,
    ZSTD_bm_stable = 1
} ZSTD_bufferMode_e;
# 284 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_internal.h"
typedef struct {
    size_t nbBlocks;
    size_t compressedSize;
    unsigned long long decompressedBound;
} ZSTD_frameSizeInfo;





void ZSTD_invalidateRepCodes(ZSTD_CCtx* cctx);


typedef struct {
    blockType_e blockType;
    U32 lastBlock;
    U32 origSize;
} blockProperties_t;




size_t ZSTD_getcBlockSize(const void* src, size_t srcSize,
                          blockProperties_t* bpPtr);




size_t ZSTD_decodeSeqHeaders(ZSTD_DCtx* dctx, int* nbSeqPtr,
                       const void* src, size_t srcSize);




static __inline __attribute__((unused)) int ZSTD_cpuSupportsBmi2(void)
{
    ZSTD_cpuid_t cpuid = ZSTD_cpuid();
    return ZSTD_cpuid_bmi1(cpuid) && ZSTD_cpuid_bmi2(cpuid);
}
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/zstd_deps.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/../zstd.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/allocations.h" 2
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/portability_macros.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/compiler.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 2
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
typedef enum {
    ZSTD_cwksp_alloc_objects,
    ZSTD_cwksp_alloc_aligned_init_once,
    ZSTD_cwksp_alloc_aligned,
    ZSTD_cwksp_alloc_buffers
} ZSTD_cwksp_alloc_phase_e;






typedef enum {
    ZSTD_cwksp_dynamic_alloc,
    ZSTD_cwksp_static_alloc
} ZSTD_cwksp_static_alloc_e;
# 155 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
typedef struct {
    void* workspace;
    void* workspaceEnd;

    void* objectEnd;
    void* tableEnd;
    void* tableValidEnd;
    void* allocStart;
    void* initOnceStart;

    BYTE allocFailed;
    int workspaceOversizedDuration;
    ZSTD_cwksp_alloc_phase_e phase;
    ZSTD_cwksp_static_alloc_e isStatic;
} ZSTD_cwksp;





static __inline __attribute__((unused)) size_t ZSTD_cwksp_available_space(ZSTD_cwksp* ws);
static __inline __attribute__((unused)) void* ZSTD_cwksp_initialAllocStart(ZSTD_cwksp* ws);

static __inline __attribute__((unused)) void ZSTD_cwksp_assert_internal_consistency(ZSTD_cwksp* ws) {
    (void)ws;
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
# 201 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
}




static __inline __attribute__((unused)) size_t ZSTD_cwksp_align(size_t size, size_t align) {
    size_t const mask = align - 1;
    ((void)0);
    return (size + mask) & ~mask;
}
# 224 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
static __inline __attribute__((unused)) size_t ZSTD_cwksp_alloc_size(size_t size) {
    if (size == 0)
        return 0;



    return size;

}

static __inline __attribute__((unused)) size_t ZSTD_cwksp_aligned_alloc_size(size_t size, size_t alignment) {
    return ZSTD_cwksp_alloc_size(ZSTD_cwksp_align(size, alignment));
}





static __inline __attribute__((unused)) size_t ZSTD_cwksp_aligned64_alloc_size(size_t size) {
    return ZSTD_cwksp_aligned_alloc_size(size, 64);
}





static __inline __attribute__((unused)) size_t ZSTD_cwksp_slack_space_required(void) {



    size_t const slackSpace = 64 * 2;
    return slackSpace;
}






static __inline __attribute__((unused)) size_t ZSTD_cwksp_bytes_to_align_ptr(void* ptr, const size_t alignBytes) {
    size_t const alignBytesMask = alignBytes - 1;
    size_t const bytes = (alignBytes - ((size_t)ptr & (alignBytesMask))) & alignBytesMask;
    ((void)0);
    ((void)0);
    return bytes;
}





static __inline __attribute__((unused)) void* ZSTD_cwksp_initialAllocStart(ZSTD_cwksp* ws)
{
    char* endPtr = (char*)ws->workspaceEnd;
    ((void)0);
    endPtr = endPtr - ((size_t)endPtr % 64);
    return (void*)endPtr;
}
# 290 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
static __inline __attribute__((unused)) void*
ZSTD_cwksp_reserve_internal_buffer_space(ZSTD_cwksp* ws, size_t const bytes)
{
    void* const alloc = (BYTE*)ws->allocStart - bytes;
    void* const bottom = ws->tableEnd;
    do { } while (0)
                                                             ;
    ZSTD_cwksp_assert_internal_consistency(ws);
    ((void)0);
    if (alloc < bottom) {
        do { } while (0);
        ws->allocFailed = 1;
        return 
# 302 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
              ((void *)0)
# 302 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                  ;
    }


    if (alloc < ws->tableValidEnd) {
        ws->tableValidEnd = alloc;
    }
    ws->allocStart = alloc;
    return alloc;
}






static __inline __attribute__((unused)) size_t
ZSTD_cwksp_internal_advance_phase(ZSTD_cwksp* ws, ZSTD_cwksp_alloc_phase_e phase)
{
    ((void)0);
    if (phase > ws->phase) {

        if (ws->phase < ZSTD_cwksp_alloc_aligned_init_once &&
            phase >= ZSTD_cwksp_alloc_aligned_init_once) {
            ws->tableValidEnd = ws->objectEnd;
            ws->initOnceStart = ZSTD_cwksp_initialAllocStart(ws);

            {
                void *const alloc = ws->objectEnd;
                size_t const bytesToAlign = ZSTD_cwksp_bytes_to_align_ptr(alloc, 64);
                void *const objectEnd = (BYTE *) alloc + bytesToAlign;
                do { } while (0);
                do { if (objectEnd > ws->workspaceEnd) { do { } while (0); do { if (0) { _force_has_format_string("table phase - alignment initial allocation failed!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0)
                                                                                     ;
                ws->objectEnd = objectEnd;
                ws->tableEnd = objectEnd;
                if (ws->tableValidEnd < ws->tableEnd) {
                    ws->tableValidEnd = ws->tableEnd;
                }
            }
        }
        ws->phase = phase;
        ZSTD_cwksp_assert_internal_consistency(ws);
    }
    return 0;
}




static __inline __attribute__((unused)) int ZSTD_cwksp_owns_buffer(const ZSTD_cwksp* ws, const void* ptr)
{
    return (ptr != 
# 354 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
                  ((void *)0)
# 354 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                      ) && (ws->workspace <= ptr) && (ptr < ws->workspaceEnd);
}




static __inline __attribute__((unused)) void*
ZSTD_cwksp_reserve_internal(ZSTD_cwksp* ws, size_t bytes, ZSTD_cwksp_alloc_phase_e phase)
{
    void* alloc;
    if (ERR_isError(ZSTD_cwksp_internal_advance_phase(ws, phase)) || bytes == 0) {
        return 
# 365 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
              ((void *)0)
# 365 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                  ;
    }






    alloc = ZSTD_cwksp_reserve_internal_buffer_space(ws, bytes);
# 388 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
    return alloc;
}




static __inline __attribute__((unused)) BYTE* ZSTD_cwksp_reserve_buffer(ZSTD_cwksp* ws, size_t bytes)
{
    return (BYTE*)ZSTD_cwksp_reserve_internal(ws, bytes, ZSTD_cwksp_alloc_buffers);
}
# 408 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
static __inline __attribute__((unused)) void* ZSTD_cwksp_reserve_aligned_init_once(ZSTD_cwksp* ws, size_t bytes)
{
    size_t const alignedBytes = ZSTD_cwksp_align(bytes, 64);
    void* ptr = ZSTD_cwksp_reserve_internal(ws, alignedBytes, ZSTD_cwksp_alloc_aligned_init_once);
    ((void)0);
    if(ptr && ptr < ws->initOnceStart) {






        __builtin_memset((ptr),(0),((((size_t)((U8*)ws->initOnceStart - (U8*)ptr))<(alignedBytes) ? ((size_t)((U8*)ws->initOnceStart - (U8*)ptr)) : (alignedBytes))));
        ws->initOnceStart = ptr;
    }



    return ptr;
}




static __inline __attribute__((unused)) void* ZSTD_cwksp_reserve_aligned64(ZSTD_cwksp* ws, size_t bytes)
{
    void* const ptr = ZSTD_cwksp_reserve_internal(ws,
                        ZSTD_cwksp_align(bytes, 64),
                        ZSTD_cwksp_alloc_aligned);
    ((void)0);
    return ptr;
}






static __inline __attribute__((unused)) void* ZSTD_cwksp_reserve_table(ZSTD_cwksp* ws, size_t bytes)
{
    const ZSTD_cwksp_alloc_phase_e phase = ZSTD_cwksp_alloc_aligned_init_once;
    void* alloc;
    void* end;
    void* top;



    if(ws->phase < phase) {
        if (ERR_isError(ZSTD_cwksp_internal_advance_phase(ws, phase))) {
            return 
# 457 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
                  ((void *)0)
# 457 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                      ;
        }
    }
    alloc = ws->tableEnd;
    end = (BYTE *)alloc + bytes;
    top = ws->allocStart;

    do { } while (0)
                                                             ;
    ((void)0);
    ZSTD_cwksp_assert_internal_consistency(ws);
    ((void)0);
    if (end > top) {
        do { } while (0);
        ws->allocFailed = 1;
        return 
# 472 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
              ((void *)0)
# 472 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                  ;
    }
    ws->tableEnd = end;







    ((void)0);
    ((void)0);
    return alloc;
}





static __inline __attribute__((unused)) void* ZSTD_cwksp_reserve_object(ZSTD_cwksp* ws, size_t bytes)
{
    size_t const roundedBytes = ZSTD_cwksp_align(bytes, sizeof(void*));
    void* alloc = ws->objectEnd;
    void* end = (BYTE*)alloc + roundedBytes;






    do { } while (0)

                                                                                  ;
    ((void)0);
    ((void)0);
    ZSTD_cwksp_assert_internal_consistency(ws);

    if (ws->phase != ZSTD_cwksp_alloc_objects || end > ws->workspaceEnd) {
        do { } while (0);
        ws->allocFailed = 1;
        return 
# 512 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
              ((void *)0)
# 512 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                  ;
    }
    ws->objectEnd = end;
    ws->tableEnd = end;
    ws->tableValidEnd = end;
# 527 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
    return alloc;
}




static __inline __attribute__((unused)) void* ZSTD_cwksp_reserve_object_aligned(ZSTD_cwksp* ws, size_t byteSize, size_t alignment)
{
    size_t const mask = alignment - 1;
    size_t const surplus = (alignment > sizeof(void*)) ? alignment - sizeof(void*) : 0;
    void* const start = ZSTD_cwksp_reserve_object(ws, byteSize + surplus);
    if (start == 
# 538 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
                ((void *)0)
# 538 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                    ) return 
# 538 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
                             ((void *)0)
# 538 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
                                 ;
    if (surplus == 0) return start;
    ((void)0);
    return (void*)(((size_t)start + surplus) & ~mask);
}

static __inline __attribute__((unused)) void ZSTD_cwksp_mark_tables_dirty(ZSTD_cwksp* ws)
{
    do { } while (0);
# 567 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
    ((void)0);
    ((void)0);
    ws->tableValidEnd = ws->objectEnd;
    ZSTD_cwksp_assert_internal_consistency(ws);
}

static __inline __attribute__((unused)) void ZSTD_cwksp_mark_tables_clean(ZSTD_cwksp* ws) {
    do { } while (0);
    ((void)0);
    ((void)0);
    if (ws->tableValidEnd < ws->tableEnd) {
        ws->tableValidEnd = ws->tableEnd;
    }
    ZSTD_cwksp_assert_internal_consistency(ws);
}




static __inline __attribute__((unused)) void ZSTD_cwksp_clean_tables(ZSTD_cwksp* ws) {
    do { } while (0);
    ((void)0);
    ((void)0);
    if (ws->tableValidEnd < ws->tableEnd) {
        __builtin_memset((ws->tableValidEnd),(0),((size_t)((BYTE*)ws->tableEnd - (BYTE*)ws->tableValidEnd)));
    }
    ZSTD_cwksp_mark_tables_clean(ws);
}





static __inline __attribute__((unused)) void ZSTD_cwksp_clear_tables(ZSTD_cwksp* ws)
{
    do { } while (0);
# 615 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
    ws->tableEnd = ws->objectEnd;
    ZSTD_cwksp_assert_internal_consistency(ws);
}





static __inline __attribute__((unused)) void ZSTD_cwksp_clear(ZSTD_cwksp* ws) {
    do { } while (0);
# 651 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
    ws->tableEnd = ws->objectEnd;
    ws->allocStart = ZSTD_cwksp_initialAllocStart(ws);
    ws->allocFailed = 0;
    if (ws->phase > ZSTD_cwksp_alloc_aligned_init_once) {
        ws->phase = ZSTD_cwksp_alloc_aligned_init_once;
    }
    ZSTD_cwksp_assert_internal_consistency(ws);
}

static __inline __attribute__((unused)) size_t ZSTD_cwksp_sizeof(const ZSTD_cwksp* ws) {
    return (size_t)((BYTE*)ws->workspaceEnd - (BYTE*)ws->workspace);
}

static __inline __attribute__((unused)) size_t ZSTD_cwksp_used(const ZSTD_cwksp* ws) {
    return (size_t)((BYTE*)ws->tableEnd - (BYTE*)ws->workspace)
         + (size_t)((BYTE*)ws->workspaceEnd - (BYTE*)ws->allocStart);
}






static __inline __attribute__((unused)) void ZSTD_cwksp_init(ZSTD_cwksp* ws, void* start, size_t size, ZSTD_cwksp_static_alloc_e isStatic) {
    do { } while (0);
    ((void)0);
    ws->workspace = start;
    ws->workspaceEnd = (BYTE*)start + size;
    ws->objectEnd = ws->workspace;
    ws->tableValidEnd = ws->objectEnd;
    ws->initOnceStart = ZSTD_cwksp_initialAllocStart(ws);
    ws->phase = ZSTD_cwksp_alloc_objects;
    ws->isStatic = isStatic;
    ZSTD_cwksp_clear(ws);
    ws->workspaceOversizedDuration = 0;
    ZSTD_cwksp_assert_internal_consistency(ws);
}

static __inline __attribute__((unused)) size_t ZSTD_cwksp_create(ZSTD_cwksp* ws, size_t size, ZSTD_customMem customMem) {
    void* workspace = ZSTD_customMalloc(size, customMem);
    do { } while (0);
    do { if (workspace == 
# 692 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h" 3 4
   ((void *)0)
# 692 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
   ) { do { } while (0); do { if (0) { _force_has_format_string("NULL pointer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);
    ZSTD_cwksp_init(ws, workspace, size, ZSTD_cwksp_dynamic_alloc);
    return 0;
}

static __inline __attribute__((unused)) void ZSTD_cwksp_free(ZSTD_cwksp* ws, ZSTD_customMem customMem) {
    void *ptr = ws->workspace;
    do { } while (0);





    __builtin_memset((ws),(0),(sizeof(ZSTD_cwksp)));
    ZSTD_customFree(ptr, customMem);
}





static __inline __attribute__((unused)) void ZSTD_cwksp_move(ZSTD_cwksp* dst, ZSTD_cwksp* src) {
    *dst = *src;
    __builtin_memset((src),(0),(sizeof(ZSTD_cwksp)));
}

static __inline __attribute__((unused)) int ZSTD_cwksp_reserve_failed(const ZSTD_cwksp* ws) {
    return ws->allocFailed;
}
# 730 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_cwksp.h"
static __inline __attribute__((unused)) int ZSTD_cwksp_estimated_space_within_bounds(const ZSTD_cwksp *const ws, size_t const estimatedSpace) {


    return (estimatedSpace - ZSTD_cwksp_slack_space_required()) <= ZSTD_cwksp_used(ws) &&
           ZSTD_cwksp_used(ws) <= estimatedSpace;
}


static __inline __attribute__((unused)) size_t ZSTD_cwksp_available_space(ZSTD_cwksp* ws) {
    return (size_t)((BYTE*)ws->allocStart - (BYTE*)ws->tableEnd);
}

static __inline __attribute__((unused)) int ZSTD_cwksp_check_available(ZSTD_cwksp* ws, size_t additionalNeededSpace) {
    return ZSTD_cwksp_available_space(ws) >= additionalNeededSpace;
}

static __inline __attribute__((unused)) int ZSTD_cwksp_check_too_large(ZSTD_cwksp* ws, size_t additionalNeededSpace) {
    return ZSTD_cwksp_check_available(
        ws, additionalNeededSpace * 3);
}

static __inline __attribute__((unused)) int ZSTD_cwksp_check_wasteful(ZSTD_cwksp* ws, size_t additionalNeededSpace) {
    return ZSTD_cwksp_check_too_large(ws, additionalNeededSpace)
        && ws->workspaceOversizedDuration > 128;
}

static __inline __attribute__((unused)) void ZSTD_cwksp_bump_oversized_duration(
        ZSTD_cwksp* ws, size_t additionalNeededSpace) {
    if (ZSTD_cwksp_check_too_large(ws, additionalNeededSpace)) {
        ws->workspaceOversizedDuration++;
    } else {
        ws->workspaceOversizedDuration = 0;
    }
}
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/bits.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_preSplit.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_preSplit.h"
# 1 "/usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h" 1 3 4
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_preSplit.h" 2
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_preSplit.h"
size_t ZSTD_splitBlock(const void* blockStart, size_t blockSize,
                    int level,
                    void* workspace, size_t wkspSize);
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 2
# 46 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
typedef enum { ZSTDcs_created=0, ZSTDcs_init, ZSTDcs_ongoing, ZSTDcs_ending } ZSTD_compressionStage_e;
typedef enum { zcss_init=0, zcss_load, zcss_flush } ZSTD_cStreamStage;

typedef struct ZSTD_prefixDict_s {
    const void* dict;
    size_t dictSize;
    ZSTD_dictContentType_e dictContentType;
} ZSTD_prefixDict;

typedef struct {
    void* dictBuffer;
    void const* dict;
    size_t dictSize;
    ZSTD_dictContentType_e dictContentType;
    ZSTD_CDict* cdict;
} ZSTD_localDict;

typedef struct {
    HUF_CElt CTable[((255)+2)];
    HUF_repeat repeatMode;
} ZSTD_hufCTables_t;

typedef struct {
    FSE_CTable offcodeCTable[(1 + (1<<((8)-1)) + (((31)+1)*2))];
    FSE_CTable matchlengthCTable[(1 + (1<<((9)-1)) + (((52)+1)*2))];
    FSE_CTable litlengthCTable[(1 + (1<<((9)-1)) + (((35)+1)*2))];
    FSE_repeat offcode_repeatMode;
    FSE_repeat matchlength_repeatMode;
    FSE_repeat litlength_repeatMode;
} ZSTD_fseCTables_t;

typedef struct {
    ZSTD_hufCTables_t huf;
    ZSTD_fseCTables_t fse;
} ZSTD_entropyCTables_t;




typedef struct SeqDef_s {
    U32 offBase;
    U16 litLength;
    U16 mlBase;
} SeqDef;


typedef enum {
    ZSTD_llt_none = 0,
    ZSTD_llt_literalLength = 1,
    ZSTD_llt_matchLength = 2
} ZSTD_longLengthType_e;

typedef struct {
    SeqDef* sequencesStart;
    SeqDef* sequences;
    BYTE* litStart;
    BYTE* lit;
    BYTE* llCode;
    BYTE* mlCode;
    BYTE* ofCode;
    size_t maxNbSeq;
    size_t maxNbLit;





    ZSTD_longLengthType_e longLengthType;
    U32 longLengthPos;
} SeqStore_t;

typedef struct {
    U32 litLength;
    U32 matchLength;
} ZSTD_SequenceLength;





static __inline __attribute__((unused)) ZSTD_SequenceLength ZSTD_getSequenceLength(SeqStore_t const* seqStore, SeqDef const* seq)
{
    ZSTD_SequenceLength seqLen;
    seqLen.litLength = seq->litLength;
    seqLen.matchLength = seq->mlBase + 3;
    if (seqStore->longLengthPos == (U32)(seq - seqStore->sequencesStart)) {
        if (seqStore->longLengthType == ZSTD_llt_literalLength) {
            seqLen.litLength += 0x10000;
        }
        if (seqStore->longLengthType == ZSTD_llt_matchLength) {
            seqLen.matchLength += 0x10000;
        }
    }
    return seqLen;
}

const SeqStore_t* ZSTD_getSeqStore(const ZSTD_CCtx* ctx);
int ZSTD_seqToCodes(const SeqStore_t* seqStorePtr);
# 154 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
typedef struct {
    SymbolEncodingType_e hType;
    BYTE hufDesBuffer[128];
    size_t hufDesSize;
} ZSTD_hufCTablesMetadata_t;






typedef struct {
    SymbolEncodingType_e llType;
    SymbolEncodingType_e ofType;
    SymbolEncodingType_e mlType;
    BYTE fseTablesBuffer[(((52 + 1) * 9 + (35 + 1) * 9 + (31 + 1) * 8 + 7) / 8)];
    size_t fseTablesSize;
    size_t lastCountSize;
} ZSTD_fseCTablesMetadata_t;

typedef struct {
    ZSTD_hufCTablesMetadata_t hufMetadata;
    ZSTD_fseCTablesMetadata_t fseMetadata;
} ZSTD_entropyCTablesMetadata_t;




size_t ZSTD_buildBlockEntropyStats(
                    const SeqStore_t* seqStorePtr,
                    const ZSTD_entropyCTables_t* prevEntropy,
                          ZSTD_entropyCTables_t* nextEntropy,
                    const ZSTD_CCtx_params* cctxParams,
                          ZSTD_entropyCTablesMetadata_t* entropyMetadata,
                          void* workspace, size_t wkspSize);





typedef struct {
    U32 off;
    U32 len;
} ZSTD_match_t;

typedef struct {
    U32 offset;
    U32 litLength;
    U32 matchLength;
} rawSeq;

typedef struct {
  rawSeq* seq;
  size_t pos;
  size_t posInSequence;

  size_t size;
  size_t capacity;
} RawSeqStore_t;

__attribute__((unused)) static const RawSeqStore_t kNullRawSeqStore = {
# 214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 3 4
                                                          ((void *)0)
# 214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
                                                              , 0, 0, 0, 0};

typedef struct {
    int price;
    U32 off;
    U32 mlen;
    U32 litlen;
    U32 rep[3];
} ZSTD_optimal_t;

typedef enum { zop_dynamic=0, zop_predef } ZSTD_OptPrice_e;


typedef struct {

    unsigned* litFreq;
    unsigned* litLengthFreq;
    unsigned* matchLengthFreq;
    unsigned* offCodeFreq;
    ZSTD_match_t* matchTable;
    ZSTD_optimal_t* priceTable;

    U32 litSum;
    U32 litLengthSum;
    U32 matchLengthSum;
    U32 offCodeSum;
    U32 litSumBasePrice;
    U32 litLengthSumBasePrice;
    U32 matchLengthSumBasePrice;
    U32 offCodeSumBasePrice;
    ZSTD_OptPrice_e priceType;
    const ZSTD_entropyCTables_t* symbolCosts;
    ZSTD_ParamSwitch_e literalCompressionMode;
} optState_t;

typedef struct {
  ZSTD_entropyCTables_t entropy;
  U32 rep[3];
} ZSTD_compressedBlockState_t;

typedef struct {
    BYTE const* nextSrc;
    BYTE const* base;
    BYTE const* dictBase;
    U32 dictLimit;
    U32 lowLimit;
    U32 nbOverflowCorrections;



} ZSTD_window_t;



typedef struct ZSTD_MatchState_t ZSTD_MatchState_t;



struct ZSTD_MatchState_t {
    ZSTD_window_t window;
    U32 loadedDictEnd;






    U32 nextToUpdate;
    U32 hashLog3;

    U32 rowHashLog;
    BYTE* tagTable;
    U32 hashCache[8];
    U64 hashSalt;
    U32 hashSaltEntropy;

    U32* hashTable;
    U32* hashTable3;
    U32* chainTable;

    int forceNonContiguous;

    int dedicatedDictSearch;


    optState_t opt;
    const ZSTD_MatchState_t* dictMatchState;
    ZSTD_compressionParameters cParams;
    const RawSeqStore_t* ldmSeqStore;




    int prefetchCDictTables;






    int lazySkipping;
};

typedef struct {
    ZSTD_compressedBlockState_t* prevCBlock;
    ZSTD_compressedBlockState_t* nextCBlock;
    ZSTD_MatchState_t matchState;
} ZSTD_blockState_t;

typedef struct {
    U32 offset;
    U32 checksum;
} ldmEntry_t;

typedef struct {
    BYTE const* split;
    U32 hash;
    U32 checksum;
    ldmEntry_t* bucket;
} ldmMatchCandidate_t;



typedef struct {
    ZSTD_window_t window;
    ldmEntry_t* hashTable;
    U32 loadedDictEnd;
    BYTE* bucketOffsets;
    size_t splitIndices[64];
    ldmMatchCandidate_t matchCandidates[64];
} ldmState_t;

typedef struct {
    ZSTD_ParamSwitch_e enableLdm;
    U32 hashLog;
    U32 bucketSizeLog;
    U32 minMatchLength;
    U32 hashRateLog;
    U32 windowLog;
} ldmParams_t;

typedef struct {
    int collectSequences;
    ZSTD_Sequence* seqStart;
    size_t seqIndex;
    size_t maxSequences;
} SeqCollector;

struct ZSTD_CCtx_params_s {
    ZSTD_format_e format;
    ZSTD_compressionParameters cParams;
    ZSTD_frameParameters fParams;

    int compressionLevel;
    int forceWindow;

    size_t targetCBlockSize;


    int srcSizeHint;



    ZSTD_dictAttachPref_e attachDictPref;
    ZSTD_ParamSwitch_e literalCompressionMode;


    int nbWorkers;
    size_t jobSize;
    int overlapLog;
    int rsyncable;


    ldmParams_t ldmParams;


    int enableDedicatedDictSearch;


    ZSTD_bufferMode_e inBufferMode;
    ZSTD_bufferMode_e outBufferMode;


    ZSTD_SequenceFormat_e blockDelimiters;
    int validateSequences;
# 410 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
    ZSTD_ParamSwitch_e postBlockSplitter;
    int preBlockSplitter_level;


    size_t maxBlockSize;


    ZSTD_ParamSwitch_e useRowMatchFinder;


    int deterministicRefPrefix;


    ZSTD_customMem customMem;


    ZSTD_ParamSwitch_e prefetchCDictTables;



    int enableMatchFinderFallback;




    void* extSeqProdState;
    ZSTD_sequenceProducer_F extSeqProdFunc;


    ZSTD_ParamSwitch_e searchForExternalRepcodes;
};
# 451 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
typedef enum {
    ZSTDb_not_buffered,
    ZSTDb_buffered
} ZSTD_buffered_policy_e;






typedef struct {
    SeqStore_t fullSeqStoreChunk;
    SeqStore_t firstHalfSeqStore;
    SeqStore_t secondHalfSeqStore;
    SeqStore_t currSeqStore;
    SeqStore_t nextSeqStore;

    U32 partitions[196];
    ZSTD_entropyCTablesMetadata_t entropyMetadata;
} ZSTD_blockSplitCtx;

struct ZSTD_CCtx_s {
    ZSTD_compressionStage_e stage;
    int cParamsChanged;
    int bmi2;
    ZSTD_CCtx_params requestedParams;
    ZSTD_CCtx_params appliedParams;
    ZSTD_CCtx_params simpleApiParams;
    U32 dictID;
    size_t dictContentSize;

    ZSTD_cwksp workspace;
    size_t blockSizeMax;
    unsigned long long pledgedSrcSizePlusOne;
    unsigned long long consumedSrcSize;
    unsigned long long producedCSize;
    XXH64_state_t xxhState;
    ZSTD_customMem customMem;
    ZSTD_threadPool* pool;
    size_t staticSize;
    SeqCollector seqCollector;
    int isFirstBlock;
    int initialized;

    SeqStore_t seqStore;
    ldmState_t ldmState;
    rawSeq* ldmSequences;
    size_t maxNbLdmSequences;
    RawSeqStore_t externSeqStore;
    ZSTD_blockState_t blockState;
    void* tmpWorkspace;
    size_t tmpWkspSize;


    ZSTD_buffered_policy_e bufferedPolicy;


    char* inBuff;
    size_t inBuffSize;
    size_t inToCompress;
    size_t inBuffPos;
    size_t inBuffTarget;
    char* outBuff;
    size_t outBuffSize;
    size_t outBuffContentSize;
    size_t outBuffFlushedSize;
    ZSTD_cStreamStage streamStage;
    U32 frameEnded;


    ZSTD_inBuffer expectedInBuffer;
    size_t stableIn_notConsumed;
    size_t expectedOutBufferSize;


    ZSTD_localDict localDict;
    const ZSTD_CDict* cdict;
    ZSTD_prefixDict prefixDict;
# 537 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
    ZSTD_TraceCtx traceCtx;



    ZSTD_blockSplitCtx blockSplitCtx;


    ZSTD_Sequence* extSeqBuf;
    size_t extSeqBufCapacity;
};

typedef enum { ZSTD_dtlm_fast, ZSTD_dtlm_full } ZSTD_dictTableLoadMethod_e;
typedef enum { ZSTD_tfp_forCCtx, ZSTD_tfp_forCDict } ZSTD_tableFillPurpose_e;

typedef enum {
    ZSTD_noDict = 0,
    ZSTD_extDict = 1,
    ZSTD_dictMatchState = 2,
    ZSTD_dedicatedDictSearch = 3
} ZSTD_dictMode_e;

typedef enum {
    ZSTD_cpm_noAttachDict = 0,



    ZSTD_cpm_attachDict = 1,



    ZSTD_cpm_createCDict = 2,



    ZSTD_cpm_unknown = 3




} ZSTD_CParamMode_e;

typedef size_t (*ZSTD_BlockCompressor_f) (
        ZSTD_MatchState_t* bs, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
ZSTD_BlockCompressor_f ZSTD_selectBlockCompressor(ZSTD_strategy strat, ZSTD_ParamSwitch_e rowMatchfinderMode, ZSTD_dictMode_e dictMode);


static __inline __attribute__((unused)) U32 ZSTD_LLcode(U32 litLength)
{
    static const BYTE LL_Code[64] = { 0, 1, 2, 3, 4, 5, 6, 7,
                                       8, 9, 10, 11, 12, 13, 14, 15,
                                      16, 16, 17, 17, 18, 18, 19, 19,
                                      20, 20, 20, 20, 21, 21, 21, 21,
                                      22, 22, 22, 22, 22, 22, 22, 22,
                                      23, 23, 23, 23, 23, 23, 23, 23,
                                      24, 24, 24, 24, 24, 24, 24, 24,
                                      24, 24, 24, 24, 24, 24, 24, 24 };
    static const U32 LL_deltaCode = 19;
    return (litLength > 63) ? ZSTD_highbit32(litLength) + LL_deltaCode : LL_Code[litLength];
}




static __inline __attribute__((unused)) U32 ZSTD_MLcode(U32 mlBase)
{
    static const BYTE ML_Code[128] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                                      16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
                                      32, 32, 33, 33, 34, 34, 35, 35, 36, 36, 36, 36, 37, 37, 37, 37,
                                      38, 38, 38, 38, 38, 38, 38, 38, 39, 39, 39, 39, 39, 39, 39, 39,
                                      40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
                                      41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
                                      42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42,
                                      42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42 };
    static const U32 ML_deltaCode = 36;
    return (mlBase > 127) ? ZSTD_highbit32(mlBase) + ML_deltaCode : ML_Code[mlBase];
}




static __inline __attribute__((unused)) int ZSTD_cParam_withinBounds(ZSTD_cParameter cParam, int value)
{
    ZSTD_bounds const bounds = ZSTD_cParam_getBounds(cParam);
    if (ERR_isError(bounds.error)) return 0;
    if (value < bounds.lowerBound) return 0;
    if (value > bounds.upperBound) return 0;
    return 1;
}




static __inline __attribute__((unused)) const BYTE*
ZSTD_selectAddr(U32 index, U32 lowLimit, const BYTE* candidate, const BYTE* backup)
{

    __asm__ (
        "cmp %1, %2\n"
        "cmova %3, %0\n"
        : "+r"(candidate)
        : "r"(index), "r"(lowLimit), "r"(backup)
        );
    return candidate;



}




static __inline __attribute__((unused)) size_t
ZSTD_noCompressBlock(void* dst, size_t dstCapacity, const void* src, size_t srcSize, U32 lastBlock)
{
    U32 const cBlockHeader24 = lastBlock + (((U32)bt_raw)<<1) + (U32)(srcSize << 3);
    do { } while (0);
    do { if (srcSize + ZSTD_blockHeaderSize > dstCapacity) { do { } while (0); do { if (0) { _force_has_format_string("dst buf too small for uncompressed block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)
                                                                                 ;
    MEM_writeLE24(dst, cBlockHeader24);
    __builtin_memcpy(((BYTE*)dst + ZSTD_blockHeaderSize),(src),(srcSize));
    return ZSTD_blockHeaderSize + srcSize;
}

static __inline __attribute__((unused)) size_t
ZSTD_rleCompressBlock(void* dst, size_t dstCapacity, BYTE src, size_t srcSize, U32 lastBlock)
{
    BYTE* const op = (BYTE*)dst;
    U32 const cBlockHeader = lastBlock + (((U32)bt_rle)<<1) + (U32)(srcSize << 3);
    do { if (dstCapacity < 4) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
    MEM_writeLE24(op, cBlockHeader);
    op[3] = src;
    return 4;
}






static __inline __attribute__((unused)) size_t ZSTD_minGain(size_t srcSize, ZSTD_strategy strat)
{
    U32 const minlog = (strat>=ZSTD_btultra) ? (U32)(strat) - 1 : 6;
    (void)sizeof(char[(ZSTD_btultra == 8) ? 1 : -1]);
    ((void)0);
    return (srcSize >> minlog) + 2;
}

static __inline __attribute__((unused)) int ZSTD_literalsCompressionIsDisabled(const ZSTD_CCtx_params* cctxParams)
{
    switch (cctxParams->literalCompressionMode) {
    case ZSTD_ps_enable:
        return 0;
    case ZSTD_ps_disable:
        return 1;
    default:
        ((void)0);
        ; __attribute__((__fallthrough__));
    case ZSTD_ps_auto:
        return (cctxParams->cParams.strategy == ZSTD_fast) && (cctxParams->cParams.targetLength > 0);
    }
}






static void
ZSTD_safecopyLiterals(BYTE* op, BYTE const* ip, BYTE const* const iend, BYTE const* ilimit_w)
{
    ((void)0);
    if (ip <= ilimit_w) {
        ZSTD_wildcopy(op, ip, ilimit_w - ip, ZSTD_no_overlap);
        op += ilimit_w - ip;
        ip = ilimit_w;
    }
    while (ip < iend) *op++ = *ip++;
}
# 734 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static inline __attribute__((always_inline)) __attribute__((unused)) __attribute__((unused)) void
ZSTD_storeSeqOnly(SeqStore_t* seqStorePtr,
              size_t litLength,
              U32 offBase,
              size_t matchLength)
{
    ((void)0);


    ((void)0);
    if ((__builtin_expect((litLength>0xFFFF), 0))) {
        ((void)0);
        seqStorePtr->longLengthType = ZSTD_llt_literalLength;
        seqStorePtr->longLengthPos = (U32)(seqStorePtr->sequences - seqStorePtr->sequencesStart);
    }
    seqStorePtr->sequences[0].litLength = (U16)litLength;


    seqStorePtr->sequences[0].offBase = offBase;


    ((void)0);
    ((void)0);
    { size_t const mlBase = matchLength - 3;
        if ((__builtin_expect((mlBase>0xFFFF), 0))) {
            ((void)0);
            seqStorePtr->longLengthType = ZSTD_llt_matchLength;
            seqStorePtr->longLengthPos = (U32)(seqStorePtr->sequences - seqStorePtr->sequencesStart);
        }
        seqStorePtr->sequences[0].mlBase = (U16)mlBase;
    }

    seqStorePtr->sequences++;
}







static inline __attribute__((always_inline)) __attribute__((unused)) __attribute__((unused)) void
ZSTD_storeSeq(SeqStore_t* seqStorePtr,
              size_t litLength, const BYTE* literals, const BYTE* litLimit,
              U32 offBase,
              size_t matchLength)
{
    BYTE const* const litLimit_w = litLimit - 32;
    BYTE const* const litEnd = literals + litLength;
# 791 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
    ((void)0);

    ((void)0);
    ((void)0);
    ((void)0);
    if (litEnd <= litLimit_w) {



        (void)sizeof(char[(32 >= 16) ? 1 : -1]);
        ZSTD_copy16(seqStorePtr->lit, literals);
        if (litLength > 16) {
            ZSTD_wildcopy(seqStorePtr->lit+16, literals+16, (ptrdiff_t)litLength-16, ZSTD_no_overlap);
        }
    } else {
        ZSTD_safecopyLiterals(seqStorePtr->lit, literals, litEnd, litLimit_w);
    }
    seqStorePtr->lit += litLength;

    ZSTD_storeSeqOnly(seqStorePtr, litLength, offBase, matchLength);
}





static __inline __attribute__((unused)) void
ZSTD_updateRep(U32 rep[3], U32 const offBase, U32 const ll0)
{
    if (((offBase) > 3)) {
        rep[2] = rep[1];
        rep[1] = rep[0];
        rep[0] = (((void)0), (offBase) - 3);
    } else {
        U32 const repCode = (((void)0), (offBase)) - 1 + ll0;
        if (repCode > 0) {
            U32 const currentOffset = (repCode==3) ? (rep[0] - 1) : rep[repCode];
            rep[2] = (repCode >= 2) ? rep[1] : rep[2];
            rep[1] = rep[0];
            rep[0] = currentOffset;
        } else {

        }
    }
}

typedef struct repcodes_s {
    U32 rep[3];
} Repcodes_t;

static __inline __attribute__((unused)) Repcodes_t
ZSTD_newRep(U32 const rep[3], U32 const offBase, U32 const ll0)
{
    Repcodes_t newReps;
    __builtin_memcpy((&newReps),(rep),(sizeof(newReps)));
    ZSTD_updateRep(newReps.rep, offBase, ll0);
    return newReps;
}





static __inline __attribute__((unused)) size_t ZSTD_count(const BYTE* pIn, const BYTE* pMatch, const BYTE* const pInLimit)
{
    const BYTE* const pStart = pIn;
    const BYTE* const pInLoopLimit = pInLimit - (sizeof(size_t)-1);

    if (pIn < pInLoopLimit) {
        { size_t const diff = MEM_readST(pMatch) ^ MEM_readST(pIn);
          if (diff) return ZSTD_NbCommonBytes(diff); }
        pIn+=sizeof(size_t); pMatch+=sizeof(size_t);
        while (pIn < pInLoopLimit) {
            size_t const diff = MEM_readST(pMatch) ^ MEM_readST(pIn);
            if (!diff) { pIn+=sizeof(size_t); pMatch+=sizeof(size_t); continue; }
            pIn += ZSTD_NbCommonBytes(diff);
            return (size_t)(pIn - pStart);
    } }
    if (MEM_64bits() && (pIn<(pInLimit-3)) && (MEM_read32(pMatch) == MEM_read32(pIn))) { pIn+=4; pMatch+=4; }
    if ((pIn<(pInLimit-1)) && (MEM_read16(pMatch) == MEM_read16(pIn))) { pIn+=2; pMatch+=2; }
    if ((pIn<pInLimit) && (*pMatch == *pIn)) pIn++;
    return (size_t)(pIn - pStart);
}





static __inline __attribute__((unused)) size_t
ZSTD_count_2segments(const BYTE* ip, const BYTE* match,
                     const BYTE* iEnd, const BYTE* mEnd, const BYTE* iStart)
{
    const BYTE* const vEnd = ((ip + (mEnd - match))<(iEnd) ? (ip + (mEnd - match)) : (iEnd));
    size_t const matchLength = ZSTD_count(ip, match, vEnd);
    if (match + matchLength != mEnd) return matchLength;
    do { } while (0);
    do { } while (0);
    do { } while (0);
    do { } while (0);
    do { } while (0);
    return matchLength + ZSTD_count(ip+matchLength, iStart, iEnd);
}





static const U32 prime3bytes = 506832829U;
static U32 ZSTD_hash3(U32 u, U32 h, U32 s) { ((void)0); return (((u << (32-24)) * prime3bytes) ^ s) >> (32-h) ; }
static __inline __attribute__((unused)) size_t ZSTD_hash3Ptr(const void* ptr, U32 h) { return ZSTD_hash3(MEM_readLE32(ptr), h, 0); }
static __inline __attribute__((unused)) size_t ZSTD_hash3PtrS(const void* ptr, U32 h, U32 s) { return ZSTD_hash3(MEM_readLE32(ptr), h, s); }

static const U32 prime4bytes = 2654435761U;
static U32 ZSTD_hash4(U32 u, U32 h, U32 s) { ((void)0); return ((u * prime4bytes) ^ s) >> (32-h) ; }
static size_t ZSTD_hash4Ptr(const void* ptr, U32 h) { return ZSTD_hash4(MEM_readLE32(ptr), h, 0); }
static size_t ZSTD_hash4PtrS(const void* ptr, U32 h, U32 s) { return ZSTD_hash4(MEM_readLE32(ptr), h, s); }

static const U64 prime5bytes = 889523592379ULL;
static size_t ZSTD_hash5(U64 u, U32 h, U64 s) { ((void)0); return (size_t)((((u << (64-40)) * prime5bytes) ^ s) >> (64-h)) ; }
static size_t ZSTD_hash5Ptr(const void* p, U32 h) { return ZSTD_hash5(MEM_readLE64(p), h, 0); }
static size_t ZSTD_hash5PtrS(const void* p, U32 h, U64 s) { return ZSTD_hash5(MEM_readLE64(p), h, s); }

static const U64 prime6bytes = 227718039650203ULL;
static size_t ZSTD_hash6(U64 u, U32 h, U64 s) { ((void)0); return (size_t)((((u << (64-48)) * prime6bytes) ^ s) >> (64-h)) ; }
static size_t ZSTD_hash6Ptr(const void* p, U32 h) { return ZSTD_hash6(MEM_readLE64(p), h, 0); }
static size_t ZSTD_hash6PtrS(const void* p, U32 h, U64 s) { return ZSTD_hash6(MEM_readLE64(p), h, s); }

static const U64 prime7bytes = 58295818150454627ULL;
static size_t ZSTD_hash7(U64 u, U32 h, U64 s) { ((void)0); return (size_t)((((u << (64-56)) * prime7bytes) ^ s) >> (64-h)) ; }
static size_t ZSTD_hash7Ptr(const void* p, U32 h) { return ZSTD_hash7(MEM_readLE64(p), h, 0); }
static size_t ZSTD_hash7PtrS(const void* p, U32 h, U64 s) { return ZSTD_hash7(MEM_readLE64(p), h, s); }

static const U64 prime8bytes = 0xCF1BBCDCB7A56463ULL;
static size_t ZSTD_hash8(U64 u, U32 h, U64 s) { ((void)0); return (size_t)((((u) * prime8bytes) ^ s) >> (64-h)) ; }
static size_t ZSTD_hash8Ptr(const void* p, U32 h) { return ZSTD_hash8(MEM_readLE64(p), h, 0); }
static size_t ZSTD_hash8PtrS(const void* p, U32 h, U64 s) { return ZSTD_hash8(MEM_readLE64(p), h, s); }


static __inline __attribute__((unused)) __attribute__((always_inline))
size_t ZSTD_hashPtr(const void* p, U32 hBits, U32 mls)
{


    ((void)0);

    switch(mls)
    {
    default:
    case 4: return ZSTD_hash4Ptr(p, hBits);
    case 5: return ZSTD_hash5Ptr(p, hBits);
    case 6: return ZSTD_hash6Ptr(p, hBits);
    case 7: return ZSTD_hash7Ptr(p, hBits);
    case 8: return ZSTD_hash8Ptr(p, hBits);
    }
}

static __inline __attribute__((unused)) __attribute__((always_inline))
size_t ZSTD_hashPtrSalted(const void* p, U32 hBits, U32 mls, const U64 hashSalt) {


    ((void)0);

    switch(mls)
    {
        default:
        case 4: return ZSTD_hash4PtrS(p, hBits, (U32)hashSalt);
        case 5: return ZSTD_hash5PtrS(p, hBits, hashSalt);
        case 6: return ZSTD_hash6PtrS(p, hBits, hashSalt);
        case 7: return ZSTD_hash7PtrS(p, hBits, hashSalt);
        case 8: return ZSTD_hash8PtrS(p, hBits, hashSalt);
    }
}





static U64 ZSTD_ipow(U64 base, U64 exponent)
{
    U64 power = 1;
    while (exponent) {
      if (exponent & 1) power *= base;
      exponent >>= 1;
      base *= base;
    }
    return power;
}






static U64 ZSTD_rollingHash_append(U64 hash, void const* buf, size_t size)
{
    BYTE const* istart = (BYTE const*)buf;
    size_t pos;
    for (pos = 0; pos < size; ++pos) {
        hash *= prime8bytes;
        hash += istart[pos] + 10;
    }
    return hash;
}




static __inline __attribute__((unused)) U64 ZSTD_rollingHash_compute(void const* buf, size_t size)
{
    return ZSTD_rollingHash_append(0, buf, size);
}





static __inline __attribute__((unused)) U64 ZSTD_rollingHash_primePower(U32 length)
{
    return ZSTD_ipow(prime8bytes, length - 1);
}




static __inline __attribute__((unused)) U64 ZSTD_rollingHash_rotate(U64 hash, BYTE toRemove, BYTE toAdd, U64 primePower)
{
    hash -= (toRemove + 10) * primePower;
    hash *= prime8bytes;
    hash += toAdd + 10;
    return hash;
}
# 1041 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static __inline __attribute__((unused)) void ZSTD_window_clear(ZSTD_window_t* window)
{
    size_t const endT = (size_t)(window->nextSrc - window->base);
    U32 const end = (U32)endT;

    window->lowLimit = end;
    window->dictLimit = end;
}

static __inline __attribute__((unused)) U32 ZSTD_window_isEmpty(ZSTD_window_t const window)
{
    return window.dictLimit == 2 &&
           window.lowLimit == 2 &&
           (window.nextSrc - window.base) == 2;
}





static __inline __attribute__((unused)) U32 ZSTD_window_hasExtDict(ZSTD_window_t const window)
{
    return window.lowLimit < window.dictLimit;
}






static __inline __attribute__((unused)) ZSTD_dictMode_e ZSTD_matchState_dictMode(const ZSTD_MatchState_t *ms)
{
    return ZSTD_window_hasExtDict(ms->window) ?
        ZSTD_extDict :
        ms->dictMatchState != 
# 1075 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 3 4
                             ((void *)0) 
# 1075 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
                                  ?
            (ms->dictMatchState->dedicatedDictSearch ? ZSTD_dedicatedDictSearch : ZSTD_dictMatchState) :
            ZSTD_noDict;
}
# 1097 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static __inline __attribute__((unused)) U32 ZSTD_window_canOverflowCorrect(ZSTD_window_t const window,
                                              U32 cycleLog,
                                              U32 maxDist,
                                              U32 loadedDictEnd,
                                              void const* src)
{
    U32 const cycleSize = 1u << cycleLog;
    U32 const curr = (U32)((BYTE const*)src - window.base);
    U32 const minIndexToOverflowCorrect = cycleSize
                                        + ((maxDist)>(cycleSize) ? (maxDist) : (cycleSize))
                                        + 2;






    U32 const adjustment = window.nbOverflowCorrections + 1;
    U32 const adjustedIndex = ((minIndexToOverflowCorrect * adjustment)>(minIndexToOverflowCorrect) ? (minIndexToOverflowCorrect * adjustment) : (minIndexToOverflowCorrect))
                                                            ;
    U32 const indexLargeEnough = curr > adjustedIndex;




    U32 const dictionaryInvalidated = curr > maxDist + loadedDictEnd;

    return indexLargeEnough && dictionaryInvalidated;
}






static __inline __attribute__((unused)) U32 ZSTD_window_needOverflowCorrection(ZSTD_window_t const window,
                                                  U32 cycleLog,
                                                  U32 maxDist,
                                                  U32 loadedDictEnd,
                                                  void const* src,
                                                  void const* srcEnd)
{
    U32 const curr = (U32)((BYTE const*)srcEnd - window.base);
    if (0) {
        if (ZSTD_window_canOverflowCorrect(window, cycleLog, maxDist, loadedDictEnd, src)) {
            return 1;
        }
    }
    return curr > (MEM_64bits() ? 3500U *(1 <<20) : 2000U *(1 <<20));
}
# 1157 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
U32 ZSTD_window_correctOverflow(ZSTD_window_t* window, U32 cycleLog,
                                           U32 maxDist, void const* src)
{
# 1181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
    U32 const cycleSize = 1u << cycleLog;
    U32 const cycleMask = cycleSize - 1;
    U32 const curr = (U32)((BYTE const*)src - window->base);
    U32 const currentCycle = curr & cycleMask;

    U32 const currentCycleCorrection = currentCycle < 2
                                     ? ((cycleSize)>(2) ? (cycleSize) : (2))
                                     : 0;
    U32 const newCurrent = currentCycle
                         + currentCycleCorrection
                         + ((maxDist)>(cycleSize) ? (maxDist) : (cycleSize));
    U32 const correction = curr - newCurrent;




    ((void)0);
    ((void)0);
    ((void)0);
    if (!0) {

        ((void)0);
    }

    window->base += correction;
    window->dictBase += correction;
    if (window->lowLimit < correction + 2) {
        window->lowLimit = 2;
    } else {
        window->lowLimit -= correction;
    }
    if (window->dictLimit < correction + 2) {
        window->dictLimit = 2;
    } else {
        window->dictLimit -= correction;
    }


    ((void)0);
    ((void)0);

    ((void)0);
    ((void)0);

    ++window->nbOverflowCorrections;

    do { } while (0)
                              ;
    return correction;
}
# 1255 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static __inline __attribute__((unused)) void
ZSTD_window_enforceMaxDist(ZSTD_window_t* window,
                     const void* blockEnd,
                           U32 maxDist,
                           U32* loadedDictEndPtr,
                     const ZSTD_MatchState_t** dictMatchStatePtr)
{
    U32 const blockEndIdx = (U32)((BYTE const*)blockEnd - window->base);
    U32 const loadedDictEnd = (loadedDictEndPtr != 
# 1263 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 3 4
                                                  ((void *)0)
# 1263 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
                                                      ) ? *loadedDictEndPtr : 0;
    do { } while (0)
                                                                                  ;
# 1280 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
    if (blockEndIdx > maxDist + loadedDictEnd) {
        U32 const newLowLimit = blockEndIdx - maxDist;
        if (window->lowLimit < newLowLimit) window->lowLimit = newLowLimit;
        if (window->dictLimit < window->lowLimit) {
            do { } while (0)
                                                                                ;
            window->dictLimit = window->lowLimit;
        }

        if (loadedDictEndPtr) *loadedDictEndPtr = 0;
        if (dictMatchStatePtr) *dictMatchStatePtr = 
# 1290 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 3 4
                                                   ((void *)0)
# 1290 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
                                                       ;
    }
}







static __inline __attribute__((unused)) void
ZSTD_checkDictValidity(const ZSTD_window_t* window,
                       const void* blockEnd,
                             U32 maxDist,
                             U32* loadedDictEndPtr,
                       const ZSTD_MatchState_t** dictMatchStatePtr)
{
    ((void)0);
    ((void)0);
    { U32 const blockEndIdx = (U32)((BYTE const*)blockEnd - window->base);
        U32 const loadedDictEnd = *loadedDictEndPtr;
        do { } while (0)
                                                                                      ;
        ((void)0);

        if (blockEndIdx > loadedDictEnd + maxDist || loadedDictEnd != window->dictLimit) {
# 1325 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
            do { } while (0);
            *loadedDictEndPtr = 0;
            *dictMatchStatePtr = 
# 1327 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 3 4
                                ((void *)0)
# 1327 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
                                    ;
        } else {
            if (*loadedDictEndPtr != 0) {
                do { } while (0);
    } } }
}

static __inline __attribute__((unused)) void ZSTD_window_init(ZSTD_window_t* window) {
    __builtin_memset((window),(0),(sizeof(*window)));
    window->base = (BYTE const*)" ";
    window->dictBase = (BYTE const*)" ";
    (void)sizeof(char[(1 < 2) ? 1 : -1]);
    window->dictLimit = 2;
    window->lowLimit = 2;
    window->nextSrc = window->base + 2;
    window->nbOverflowCorrections = 0;
}
# 1352 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
U32 ZSTD_window_update(ZSTD_window_t* window,
                 const void* src, size_t srcSize,
                       int forceNonContiguous)
{
    BYTE const* const ip = (BYTE const*)src;
    U32 contiguous = 1;
    do { } while (0);
    if (srcSize == 0)
        return contiguous;
    ((void)0);
    ((void)0);

    if (src != window->nextSrc || forceNonContiguous) {

        size_t const distanceFromBase = (size_t)(window->nextSrc - window->base);
        do { } while (0);
        window->lowLimit = window->dictLimit;
        ((void)0);
        window->dictLimit = (U32)distanceFromBase;
        window->dictBase = window->base;
        window->base = ip - distanceFromBase;

        if (window->dictLimit - window->lowLimit < 8) window->lowLimit = window->dictLimit;
        contiguous = 0;
    }
    window->nextSrc = ip + srcSize;

    if ( (ip+srcSize > window->dictBase + window->lowLimit)
       & (ip < window->dictBase + window->dictLimit)) {
        size_t const highInputIdx = (size_t)((ip + srcSize) - window->dictBase);
        U32 const lowLimitMax = (highInputIdx > (size_t)window->dictLimit) ? window->dictLimit : (U32)highInputIdx;
        ((void)0);
        window->lowLimit = lowLimitMax;
        do { } while (0);
    }
    return contiguous;
}




static __inline __attribute__((unused)) U32 ZSTD_getLowestMatchIndex(const ZSTD_MatchState_t* ms, U32 curr, unsigned windowLog)
{
    U32 const maxDistance = 1U << windowLog;
    U32 const lowestValid = ms->window.lowLimit;
    U32 const withinWindow = (curr - lowestValid > maxDistance) ? curr - maxDistance : lowestValid;
    U32 const isDictionary = (ms->loadedDictEnd != 0);




    U32 const matchLowest = isDictionary ? lowestValid : withinWindow;
    return matchLowest;
}




static __inline __attribute__((unused)) U32 ZSTD_getLowestPrefixIndex(const ZSTD_MatchState_t* ms, U32 curr, unsigned windowLog)
{
    U32 const maxDistance = 1U << windowLog;
    U32 const lowestValid = ms->window.dictLimit;
    U32 const withinWindow = (curr - lowestValid > maxDistance) ? curr - maxDistance : lowestValid;
    U32 const isDictionary = (ms->loadedDictEnd != 0);



    U32 const matchLowest = isDictionary ? lowestValid : withinWindow;
    return matchLowest;
}





static __inline __attribute__((unused)) int ZSTD_index_overlap_check(const U32 prefixLowestIndex, const U32 repIndex) {
    return ((U32)((prefixLowestIndex-1) - repIndex) >= 3);
}
# 1487 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
static __inline __attribute__((unused)) void ZSTD_writeTaggedIndex(U32* const hashTable, size_t hashAndTag, U32 index) {
    size_t const hash = hashAndTag >> 8;
    U32 const tag = (U32)(hashAndTag & ((1u << 8) - 1));
    ((void)0);
    hashTable[hash] = (index << 8) | tag;
}



static __inline __attribute__((unused)) int ZSTD_comparePackedTags(size_t packedTag1, size_t packedTag2) {
    U32 const tag1 = packedTag1 & ((1u << 8) - 1);
    U32 const tag2 = packedTag2 & ((1u << 8) - 1);
    return tag1 == tag2;
}
# 1512 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
size_t ZSTD_loadCEntropy(ZSTD_compressedBlockState_t* bs, void* workspace,
                         const void* const dict, size_t dictSize);

void ZSTD_reset_compressedBlockState(ZSTD_compressedBlockState_t* bs);

typedef struct {
    U32 idx;
    U32 posInSequence;
    size_t posInSrc;
} ZSTD_SequencePosition;


size_t ZSTD_convertBlockSequences(ZSTD_CCtx* cctx,
                        const ZSTD_Sequence* const inSeqs, size_t nbSequences,
                        int const repcodeResolution);

typedef struct {
    size_t nbSequences;
    size_t blockSize;
    size_t litSize;
} BlockSummary;

BlockSummary ZSTD_get1BlockSummary(const ZSTD_Sequence* seqs, size_t nbSeqs);
# 1546 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
ZSTD_compressionParameters ZSTD_getCParamsFromCCtxParams(
        const ZSTD_CCtx_params* CCtxParams, U64 srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode);






size_t ZSTD_initCStream_internal(ZSTD_CStream* zcs,
                     const void* dict, size_t dictSize,
                     const ZSTD_CDict* cdict,
                     const ZSTD_CCtx_params* params, unsigned long long pledgedSrcSize);

void ZSTD_resetSeqStore(SeqStore_t* ssPtr);



ZSTD_compressionParameters ZSTD_getCParamsFromCDict(const ZSTD_CDict* cdict);



size_t ZSTD_compressBegin_advanced_internal(ZSTD_CCtx* cctx,
                                    const void* dict, size_t dictSize,
                                    ZSTD_dictContentType_e dictContentType,
                                    ZSTD_dictTableLoadMethod_e dtlm,
                                    const ZSTD_CDict* cdict,
                                    const ZSTD_CCtx_params* params,
                                    unsigned long long pledgedSrcSize);



size_t ZSTD_compress_advanced_internal(ZSTD_CCtx* cctx,
                                       void* dst, size_t dstCapacity,
                                 const void* src, size_t srcSize,
                                 const void* dict,size_t dictSize,
                                 const ZSTD_CCtx_params* params);







size_t ZSTD_writeLastEmptyBlock(void* dst, size_t dstCapacity);
# 1601 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
void ZSTD_referenceExternalSequences(ZSTD_CCtx* cctx, rawSeq* seq, size_t nbSeq);



U32 ZSTD_cycleLog(U32 hashLog, ZSTD_strategy strat);




void ZSTD_CCtx_trace(ZSTD_CCtx* cctx, size_t extraCSize);


static __inline __attribute__((unused)) int ZSTD_hasExtSeqProd(const ZSTD_CCtx_params* params) {
    return params->extSeqProdFunc != 
# 1614 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h" 3 4
                                    ((void *)0)
# 1614 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_internal.h"
                                        ;
}







size_t ZSTD_compressBegin_usingCDict_deprecated(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict);

size_t ZSTD_compressContinue_public(ZSTD_CCtx* cctx,
                                    void* dst, size_t dstCapacity,
                              const void* src, size_t srcSize);

size_t ZSTD_compressEnd_public(ZSTD_CCtx* cctx,
                               void* dst, size_t dstCapacity,
                         const void* src, size_t srcSize);

size_t ZSTD_compressBlock_deprecated(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_sequences.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_sequences.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../common/fse.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_sequences.h" 2


typedef enum {
    ZSTD_defaultDisallowed = 0,
    ZSTD_defaultAllowed = 1
} ZSTD_DefaultPolicy_e;

SymbolEncodingType_e
ZSTD_selectEncodingType(
        FSE_repeat* repeatMode, unsigned const* count, unsigned const max,
        size_t const mostFrequent, size_t nbSeq, unsigned const FSELog,
        FSE_CTable const* prevCTable,
        short const* defaultNorm, U32 defaultNormLog,
        ZSTD_DefaultPolicy_e const isDefaultAllowed,
        ZSTD_strategy const strategy);

size_t
ZSTD_buildCTable(void* dst, size_t dstCapacity,
                FSE_CTable* nextCTable, U32 FSELog, SymbolEncodingType_e type,
                unsigned* count, U32 max,
                const BYTE* codeTable, size_t nbSeq,
                const S16* defaultNorm, U32 defaultNormLog, U32 defaultMax,
                const FSE_CTable* prevCTable, size_t prevCTableSize,
                void* entropyWorkspace, size_t entropyWorkspaceSize);

size_t ZSTD_encodeSequences(
            void* dst, size_t dstCapacity,
            FSE_CTable const* CTable_MatchLength, BYTE const* mlCodeTable,
            FSE_CTable const* CTable_OffsetBits, BYTE const* ofCodeTable,
            FSE_CTable const* CTable_LitLength, BYTE const* llCodeTable,
            SeqDef const* sequences, size_t nbSeq, int longOffsets, int bmi2);

size_t ZSTD_fseBitCost(
    FSE_CTable const* ctable,
    unsigned const* count,
    unsigned const max);

size_t ZSTD_crossEntropyCost(short const* norm, unsigned accuracyLog,
                             unsigned const* count, unsigned const max);
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_literals.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_literals.h"
size_t ZSTD_noCompressLiterals (void* dst, size_t dstCapacity, const void* src, size_t srcSize);





size_t ZSTD_compressRleLiteralsBlock (void* dst, size_t dstCapacity, const void* src, size_t srcSize);






size_t ZSTD_compressLiterals (void* dst, size_t dstCapacity,
                        const void* src, size_t srcSize,
                              void* entropyWorkspace, size_t entropyWorkspaceSize,
                        const ZSTD_hufCTables_t* prevHuf,
                              ZSTD_hufCTables_t* nextHuf,
                              ZSTD_strategy strategy, int disableLiteralCompression,
                              int suspectUncompressible,
                              int bmi2);
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_fast.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_fast.h"
void ZSTD_fillHashTable(ZSTD_MatchState_t* ms,
                        void const* end, ZSTD_dictTableLoadMethod_e dtlm,
                        ZSTD_tableFillPurpose_e tfp);
size_t ZSTD_compressBlock_fast(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_fast_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_fast_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_double_fast.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_double_fast.h"
void ZSTD_fillDoubleHashTable(ZSTD_MatchState_t* ms,
                              void const* end, ZSTD_dictTableLoadMethod_e dtlm,
                              ZSTD_tableFillPurpose_e tfp);

size_t ZSTD_compressBlock_doubleFast(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_doubleFast_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_doubleFast_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_lazy.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_lazy.h"
U32 ZSTD_insertAndFindFirstIndex(ZSTD_MatchState_t* ms, const BYTE* ip);
void ZSTD_row_update(ZSTD_MatchState_t* const ms, const BYTE* ip);

void ZSTD_dedicatedDictSearch_lazy_loadDictionary(ZSTD_MatchState_t* ms, const BYTE* const ip);

void ZSTD_preserveUnsortedMark (U32* const table, U32 const size, U32 const reducerValue);



size_t ZSTD_compressBlock_greedy(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_dictMatchState_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_dedicatedDictSearch(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_dedicatedDictSearch_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_greedy_extDict_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 84 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_lazy.h"
size_t ZSTD_compressBlock_lazy(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_dictMatchState_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_dedicatedDictSearch(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_dedicatedDictSearch_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy_extDict_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 129 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_lazy.h"
size_t ZSTD_compressBlock_lazy2(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_dictMatchState_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_dedicatedDictSearch(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_dedicatedDictSearch_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_lazy2_extDict_row(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 174 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_lazy.h"
size_t ZSTD_compressBlock_btlazy2(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_btlazy2_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_btlazy2_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_opt.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_opt.h"
void ZSTD_updateTree(ZSTD_MatchState_t* ms, const BYTE* ip, const BYTE* iend);



size_t ZSTD_compressBlock_btopt(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_btopt_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_btopt_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_opt.h"
size_t ZSTD_compressBlock_btultra(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_btultra_dictMatchState(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
size_t ZSTD_compressBlock_btultra_extDict(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);




size_t ZSTD_compressBlock_btultra2(
        ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
        void const* src, size_t srcSize);
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../zstd.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h" 2







void ZSTD_ldm_fillHashTable(
            ldmState_t* state, const BYTE* ip,
            const BYTE* iend, ldmParams_t const* params);
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h"
size_t ZSTD_ldm_generateSequences(
            ldmState_t* ldms, RawSeqStore_t* sequences,
            ldmParams_t const* params, void const* src, size_t srcSize);
# 63 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h"
size_t ZSTD_ldm_blockCompress(RawSeqStore_t* rawSeqStore,
            ZSTD_MatchState_t* ms, SeqStore_t* seqStore, U32 rep[3],
            ZSTD_ParamSwitch_e useRowMatchFinder,
            void const* src, size_t srcSize);
# 75 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h"
void ZSTD_ldm_skipSequences(RawSeqStore_t* rawSeqStore, size_t srcSize,
    U32 const minMatch);






void ZSTD_ldm_skipRawSeqStoreBytes(RawSeqStore_t* rawSeqStore, size_t nbBytes);





size_t ZSTD_ldm_getTableSize(ldmParams_t params);





size_t ZSTD_ldm_getMaxNbSeq(ldmParams_t params, size_t maxChunkSize);
# 106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_ldm.h"
void ZSTD_ldm_adjustParameters(ldmParams_t* params,
                               ZSTD_compressionParameters const* cParams);
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_superblock.h" 1
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_superblock.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../zstd.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_superblock.h" 2
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress_superblock.h"
size_t ZSTD_compressSuperBlock(ZSTD_CCtx* zc,
                               void* dst, size_t dstCapacity,
                               void const* src, size_t srcSize,
                               unsigned lastBlock);
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
size_t ZSTD_compressBound(size_t srcSize) {
    size_t const r = (((size_t)(srcSize) >= ((sizeof(size_t)==8) ? 0xFF00FF00FF00FF00ULL : 0xFF00FF00U)) ? 0 : (srcSize) + ((srcSize)>>8) + (((srcSize) < (128<<10)) ? (((128<<10) - (srcSize)) >> 11) : 0));
    if (r==0) return ((size_t)-ZSTD_error_srcSize_wrong);
    return r;
}





struct ZSTD_CDict_s {
    const void* dictContent;
    size_t dictContentSize;
    ZSTD_dictContentType_e dictContentType;
    U32* entropyWorkspace;
    ZSTD_cwksp workspace;
    ZSTD_MatchState_t matchState;
    ZSTD_compressedBlockState_t cBlockState;
    ZSTD_customMem customMem;
    U32 dictID;
    int compressionLevel;
    ZSTD_ParamSwitch_e useRowMatchFinder;



};

ZSTD_CCtx* ZSTD_createCCtx(void)
{
    return ZSTD_createCCtx_advanced(ZSTD_defaultCMem);
}

static void ZSTD_initCCtx(ZSTD_CCtx* cctx, ZSTD_customMem memManager)
{
    ((void)0);
    __builtin_memset((cctx),(0),(sizeof(*cctx)));
    cctx->customMem = memManager;
    cctx->bmi2 = ZSTD_cpuSupportsBmi2();
    { size_t const err = ZSTD_CCtx_reset(cctx, ZSTD_reset_parameters);
        ((void)0);
        (void)err;
    }
}

ZSTD_CCtx* ZSTD_createCCtx_advanced(ZSTD_customMem customMem)
{
    (void)sizeof(char[(zcss_init==0) ? 1 : -1]);
    (void)sizeof(char[((0ULL - 1)==(0ULL - 1)) ? 1 : -1]);
    if ((!customMem.customAlloc) ^ (!customMem.customFree)) return 
# 118 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                  ((void *)0)
# 118 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                      ;
    { ZSTD_CCtx* const cctx = (ZSTD_CCtx*)ZSTD_customMalloc(sizeof(ZSTD_CCtx), customMem);
        if (!cctx) return 
# 120 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                         ((void *)0)
# 120 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                             ;
        ZSTD_initCCtx(cctx, customMem);
        return cctx;
    }
}

ZSTD_CCtx* ZSTD_initStaticCCtx(void* workspace, size_t workspaceSize)
{
    ZSTD_cwksp ws;
    ZSTD_CCtx* cctx;
    if (workspaceSize <= sizeof(ZSTD_CCtx)) return 
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                  ((void *)0)
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                      ;
    if ((size_t)workspace & 7) return 
# 131 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                     ((void *)0)
# 131 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                         ;
    ZSTD_cwksp_init(&ws, workspace, workspaceSize, ZSTD_cwksp_static_alloc);

    cctx = (ZSTD_CCtx*)ZSTD_cwksp_reserve_object(&ws, sizeof(ZSTD_CCtx));
    if (cctx == 
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
               ((void *)0)
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                   ) return 
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                            ((void *)0)
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                ;

    __builtin_memset((cctx),(0),(sizeof(ZSTD_CCtx)));
    ZSTD_cwksp_move(&cctx->workspace, &ws);
    cctx->staticSize = workspaceSize;


    if (!ZSTD_cwksp_check_available(&cctx->workspace, ((((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2))))>(8208) ? ((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2)))) : (8208))) + 2 * sizeof(ZSTD_compressedBlockState_t))) return 
# 142 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                                                                           ((void *)0)
# 142 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                                                                               ;
    cctx->blockState.prevCBlock = (ZSTD_compressedBlockState_t*)ZSTD_cwksp_reserve_object(&cctx->workspace, sizeof(ZSTD_compressedBlockState_t));
    cctx->blockState.nextCBlock = (ZSTD_compressedBlockState_t*)ZSTD_cwksp_reserve_object(&cctx->workspace, sizeof(ZSTD_compressedBlockState_t));
    cctx->tmpWorkspace = ZSTD_cwksp_reserve_object(&cctx->workspace, ((((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2))))>(8208) ? ((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2)))) : (8208))));
    cctx->tmpWkspSize = ((((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2))))>(8208) ? ((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2)))) : (8208)));
    cctx->bmi2 = ZSTD_cpuid_bmi2(ZSTD_cpuid());
    return cctx;
}




static void ZSTD_clearAllDicts(ZSTD_CCtx* cctx)
{
    ZSTD_customFree(cctx->localDict.dictBuffer, cctx->customMem);
    ZSTD_freeCDict(cctx->localDict.cdict);
    __builtin_memset((&cctx->localDict),(0),(sizeof(cctx->localDict)));
    __builtin_memset((&cctx->prefixDict),(0),(sizeof(cctx->prefixDict)));
    cctx->cdict = 
# 160 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                 ((void *)0)
# 160 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                     ;
}

static size_t ZSTD_sizeof_localDict(ZSTD_localDict dict)
{
    size_t const bufferSize = dict.dictBuffer != 
# 165 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                ((void *)0) 
# 165 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                     ? dict.dictSize : 0;
    size_t const cdictSize = ZSTD_sizeof_CDict(dict.cdict);
    return bufferSize + cdictSize;
}

static void ZSTD_freeCCtxContent(ZSTD_CCtx* cctx)
{
    ((void)0);
    ((void)0);
    ZSTD_clearAllDicts(cctx);



    ZSTD_cwksp_free(&cctx->workspace, cctx->customMem);
}

size_t ZSTD_freeCCtx(ZSTD_CCtx* cctx)
{
    do { } while (0);
    if (cctx==
# 184 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
             ((void *)0)
# 184 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                 ) return 0;
    do { if (cctx->staticSize) { do { } while (0); do { if (0) { _force_has_format_string("not compatible with static CCtx"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0)
                                                      ;
    { int cctxInWorkspace = ZSTD_cwksp_owns_buffer(&cctx->workspace, cctx);
        ZSTD_freeCCtxContent(cctx);
        if (!cctxInWorkspace) ZSTD_customFree(cctx, cctx->customMem);
    }
    return 0;
}


static size_t ZSTD_sizeof_mtctx(const ZSTD_CCtx* cctx)
{



    (void)cctx;
    return 0;

}


size_t ZSTD_sizeof_CCtx(const ZSTD_CCtx* cctx)
{
    if (cctx==
# 208 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
             ((void *)0)
# 208 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                 ) return 0;

    return (cctx->workspace.workspace == cctx ? 0 : sizeof(*cctx))
           + ZSTD_cwksp_sizeof(&cctx->workspace)
           + ZSTD_sizeof_localDict(cctx->localDict)
           + ZSTD_sizeof_mtctx(cctx);
}

size_t ZSTD_sizeof_CStream(const ZSTD_CStream* zcs)
{
    return ZSTD_sizeof_CCtx(zcs);
}


const SeqStore_t* ZSTD_getSeqStore(const ZSTD_CCtx* ctx) { return &(ctx->seqStore); }


static int ZSTD_rowMatchFinderSupported(const ZSTD_strategy strategy) {
    return (strategy >= ZSTD_greedy && strategy <= ZSTD_lazy2);
}




static int ZSTD_rowMatchFinderUsed(const ZSTD_strategy strategy, const ZSTD_ParamSwitch_e mode) {
    ((void)0);
    return ZSTD_rowMatchFinderSupported(strategy) && (mode == ZSTD_ps_enable);
}


static ZSTD_ParamSwitch_e ZSTD_resolveRowMatchFinderMode(ZSTD_ParamSwitch_e mode,
                                                         const ZSTD_compressionParameters* const cParams) {
    if (mode != ZSTD_ps_auto) return mode;
    mode = ZSTD_ps_disable;
    if (!ZSTD_rowMatchFinderSupported(cParams->strategy)) return mode;
    if (cParams->windowLog > 14) mode = ZSTD_ps_enable;
    return mode;
}


static ZSTD_ParamSwitch_e ZSTD_resolveBlockSplitterMode(ZSTD_ParamSwitch_e mode,
                                                        const ZSTD_compressionParameters* const cParams) {
    if (mode != ZSTD_ps_auto) return mode;
    return (cParams->strategy >= ZSTD_btopt && cParams->windowLog >= 17) ? ZSTD_ps_enable : ZSTD_ps_disable;
}


static int ZSTD_allocateChainTable(const ZSTD_strategy strategy,
                                   const ZSTD_ParamSwitch_e useRowMatchFinder,
                                   const U32 forDDSDict) {
    ((void)0);



    return forDDSDict || ((strategy != ZSTD_fast) && !ZSTD_rowMatchFinderUsed(strategy, useRowMatchFinder));
}





static ZSTD_ParamSwitch_e ZSTD_resolveEnableLdm(ZSTD_ParamSwitch_e mode,
                                 const ZSTD_compressionParameters* const cParams) {
    if (mode != ZSTD_ps_auto) return mode;
    return (cParams->strategy >= ZSTD_btopt && cParams->windowLog >= 27) ? ZSTD_ps_enable : ZSTD_ps_disable;
}

static int ZSTD_resolveExternalSequenceValidation(int mode) {
    return mode;
}


static size_t ZSTD_resolveMaxBlockSize(size_t maxBlockSize) {
    if (maxBlockSize == 0) {
        return (1<<17);
    } else {
        return maxBlockSize;
    }
}

static ZSTD_ParamSwitch_e ZSTD_resolveExternalRepcodeSearch(ZSTD_ParamSwitch_e value, int cLevel) {
    if (value != ZSTD_ps_auto) return value;
    if (cLevel < 10) {
        return ZSTD_ps_disable;
    } else {
        return ZSTD_ps_enable;
    }
}



static int ZSTD_CDictIndicesAreTagged(const ZSTD_compressionParameters* const cParams) {
    return cParams->strategy == ZSTD_fast || cParams->strategy == ZSTD_dfast;
}

static ZSTD_CCtx_params ZSTD_makeCCtxParamsFromCParams(
        ZSTD_compressionParameters cParams)
{
    ZSTD_CCtx_params cctxParams;

    ZSTD_CCtxParams_init(&cctxParams, 3);
    cctxParams.cParams = cParams;


    cctxParams.ldmParams.enableLdm = ZSTD_resolveEnableLdm(cctxParams.ldmParams.enableLdm, &cParams);
    if (cctxParams.ldmParams.enableLdm == ZSTD_ps_enable) {
        ZSTD_ldm_adjustParameters(&cctxParams.ldmParams, &cParams);
        ((void)0);
        ((void)0);
    }
    cctxParams.postBlockSplitter = ZSTD_resolveBlockSplitterMode(cctxParams.postBlockSplitter, &cParams);
    cctxParams.useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(cctxParams.useRowMatchFinder, &cParams);
    cctxParams.validateSequences = ZSTD_resolveExternalSequenceValidation(cctxParams.validateSequences);
    cctxParams.maxBlockSize = ZSTD_resolveMaxBlockSize(cctxParams.maxBlockSize);
    cctxParams.searchForExternalRepcodes = ZSTD_resolveExternalRepcodeSearch(cctxParams.searchForExternalRepcodes,
                                                                             cctxParams.compressionLevel);
    ((void)0);
    return cctxParams;
}

static ZSTD_CCtx_params* ZSTD_createCCtxParams_advanced(
        ZSTD_customMem customMem)
{
    ZSTD_CCtx_params* params;
    if ((!customMem.customAlloc) ^ (!customMem.customFree)) return 
# 332 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                  ((void *)0)
# 332 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                      ;
    params = (ZSTD_CCtx_params*)ZSTD_customCalloc(
            sizeof(ZSTD_CCtx_params), customMem);
    if (!params) { return 
# 335 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                         ((void *)0)
# 335 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                             ; }
    ZSTD_CCtxParams_init(params, 3);
    params->customMem = customMem;
    return params;
}

ZSTD_CCtx_params* ZSTD_createCCtxParams(void)
{
    return ZSTD_createCCtxParams_advanced(ZSTD_defaultCMem);
}

size_t ZSTD_freeCCtxParams(ZSTD_CCtx_params* params)
{
    if (params == 
# 348 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                 ((void *)0)
# 348 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                     ) { return 0; }
    ZSTD_customFree(params, params->customMem);
    return 0;
}

size_t ZSTD_CCtxParams_reset(ZSTD_CCtx_params* params)
{
    return ZSTD_CCtxParams_init(params, 3);
}

size_t ZSTD_CCtxParams_init(ZSTD_CCtx_params* cctxParams, int compressionLevel) {
    do { if (!cctxParams) { do { } while (0); do { if (0) { _force_has_format_string("NULL pointer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_GENERIC); } } while (0);
    __builtin_memset((cctxParams),(0),(sizeof(*cctxParams)));
    cctxParams->compressionLevel = compressionLevel;
    cctxParams->fParams.contentSizeFlag = 1;
    return 0;
}







static void
ZSTD_CCtxParams_init_internal(ZSTD_CCtx_params* cctxParams,
                        const ZSTD_parameters* params,
                              int compressionLevel)
{
    ((void)0);
    __builtin_memset((cctxParams),(0),(sizeof(*cctxParams)));
    cctxParams->cParams = params->cParams;
    cctxParams->fParams = params->fParams;



    cctxParams->compressionLevel = compressionLevel;
    cctxParams->useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(cctxParams->useRowMatchFinder, &params->cParams);
    cctxParams->postBlockSplitter = ZSTD_resolveBlockSplitterMode(cctxParams->postBlockSplitter, &params->cParams);
    cctxParams->ldmParams.enableLdm = ZSTD_resolveEnableLdm(cctxParams->ldmParams.enableLdm, &params->cParams);
    cctxParams->validateSequences = ZSTD_resolveExternalSequenceValidation(cctxParams->validateSequences);
    cctxParams->maxBlockSize = ZSTD_resolveMaxBlockSize(cctxParams->maxBlockSize);
    cctxParams->searchForExternalRepcodes = ZSTD_resolveExternalRepcodeSearch(cctxParams->searchForExternalRepcodes, compressionLevel);
    do { } while (0)
                                                                                                              ;
}

size_t ZSTD_CCtxParams_init_advanced(ZSTD_CCtx_params* cctxParams, ZSTD_parameters params)
{
    do { if (!cctxParams) { do { } while (0); do { if (0) { _force_has_format_string("NULL pointer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_GENERIC); } } while (0);
    do { size_t const err_code = (ZSTD_checkCParams(params.cParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    ZSTD_CCtxParams_init_internal(cctxParams, &params, 0);
    return 0;
}





static void ZSTD_CCtxParams_setZstdParams(
        ZSTD_CCtx_params* cctxParams, const ZSTD_parameters* params)
{
    ((void)0);
    cctxParams->cParams = params->cParams;
    cctxParams->fParams = params->fParams;



    cctxParams->compressionLevel = 0;
}

ZSTD_bounds ZSTD_cParam_getBounds(ZSTD_cParameter param)
{
    ZSTD_bounds bounds = { 0, 0, 0 };

    switch(param)
    {
    case ZSTD_c_compressionLevel:
        bounds.lowerBound = ZSTD_minCLevel();
        bounds.upperBound = ZSTD_maxCLevel();
        return bounds;

    case ZSTD_c_windowLog:
        bounds.lowerBound = 10;
        bounds.upperBound = ((int)(sizeof(size_t) == 4 ? 30 : 31));
        return bounds;

    case ZSTD_c_hashLog:
        bounds.lowerBound = 6;
        bounds.upperBound = ((((int)(sizeof(size_t) == 4 ? 30 : 31)) < 30) ? ((int)(sizeof(size_t) == 4 ? 30 : 31)) : 30);
        return bounds;

    case ZSTD_c_chainLog:
        bounds.lowerBound = 6;
        bounds.upperBound = ((int)(sizeof(size_t) == 4 ? 29 : 30));
        return bounds;

    case ZSTD_c_searchLog:
        bounds.lowerBound = 1;
        bounds.upperBound = (((int)(sizeof(size_t) == 4 ? 30 : 31))-1);
        return bounds;

    case ZSTD_c_minMatch:
        bounds.lowerBound = 3;
        bounds.upperBound = 7;
        return bounds;

    case ZSTD_c_targetLength:
        bounds.lowerBound = 0;
        bounds.upperBound = (1<<17);
        return bounds;

    case ZSTD_c_strategy:
        bounds.lowerBound = ZSTD_fast;
        bounds.upperBound = ZSTD_btultra2;
        return bounds;

    case ZSTD_c_contentSizeFlag:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_checksumFlag:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_dictIDFlag:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_nbWorkers:
        bounds.lowerBound = 0;



        bounds.upperBound = 0;

        return bounds;

    case ZSTD_c_jobSize:
        bounds.lowerBound = 0;



        bounds.upperBound = 0;

        return bounds;

    case ZSTD_c_overlapLog:




        bounds.lowerBound = 0;
        bounds.upperBound = 0;

        return bounds;

    case ZSTD_c_experimentalParam8:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_enableLongDistanceMatching:
        bounds.lowerBound = (int)ZSTD_ps_auto;
        bounds.upperBound = (int)ZSTD_ps_disable;
        return bounds;

    case ZSTD_c_ldmHashLog:
        bounds.lowerBound = 6;
        bounds.upperBound = ((((int)(sizeof(size_t) == 4 ? 30 : 31)) < 30) ? ((int)(sizeof(size_t) == 4 ? 30 : 31)) : 30);
        return bounds;

    case ZSTD_c_ldmMinMatch:
        bounds.lowerBound = 4;
        bounds.upperBound = 4096;
        return bounds;

    case ZSTD_c_ldmBucketSizeLog:
        bounds.lowerBound = 1;
        bounds.upperBound = 8;
        return bounds;

    case ZSTD_c_ldmHashRateLog:
        bounds.lowerBound = 0;
        bounds.upperBound = (((int)(sizeof(size_t) == 4 ? 30 : 31)) - 6);
        return bounds;


    case ZSTD_c_experimentalParam1:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_experimentalParam3 :
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_experimentalParam2:
        (void)sizeof(char[(ZSTD_f_zstd1 < ZSTD_f_zstd1_magicless) ? 1 : -1]);
        bounds.lowerBound = ZSTD_f_zstd1;
        bounds.upperBound = ZSTD_f_zstd1_magicless;
        return bounds;

    case ZSTD_c_experimentalParam4:
        (void)sizeof(char[(ZSTD_dictDefaultAttach < ZSTD_dictForceLoad) ? 1 : -1]);
        bounds.lowerBound = ZSTD_dictDefaultAttach;
        bounds.upperBound = ZSTD_dictForceLoad;
        return bounds;

    case ZSTD_c_experimentalParam5:
        (void)sizeof(char[(ZSTD_ps_auto < ZSTD_ps_enable && ZSTD_ps_enable < ZSTD_ps_disable) ? 1 : -1]);
        bounds.lowerBound = (int)ZSTD_ps_auto;
        bounds.upperBound = (int)ZSTD_ps_disable;
        return bounds;

    case ZSTD_c_targetCBlockSize:
        bounds.lowerBound = 1340;
        bounds.upperBound = (1<<17);
        return bounds;

    case ZSTD_c_experimentalParam7:
        bounds.lowerBound = 0;
        bounds.upperBound = 0x7fffffff
# 574 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                               ;
        return bounds;

    case ZSTD_c_experimentalParam9:
    case ZSTD_c_experimentalParam10:
        bounds.lowerBound = (int)ZSTD_bm_buffered;
        bounds.upperBound = (int)ZSTD_bm_stable;
        return bounds;

    case ZSTD_c_experimentalParam11:
        bounds.lowerBound = (int)ZSTD_sf_noBlockDelimiters;
        bounds.upperBound = (int)ZSTD_sf_explicitBlockDelimiters;
        return bounds;

    case ZSTD_c_experimentalParam12:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_experimentalParam13:
        bounds.lowerBound = (int)ZSTD_ps_auto;
        bounds.upperBound = (int)ZSTD_ps_disable;
        return bounds;

    case ZSTD_c_experimentalParam20:
        bounds.lowerBound = 0;
        bounds.upperBound = 6;
        return bounds;

    case ZSTD_c_experimentalParam14:
        bounds.lowerBound = (int)ZSTD_ps_auto;
        bounds.upperBound = (int)ZSTD_ps_disable;
        return bounds;

    case ZSTD_c_experimentalParam15:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_experimentalParam16:
        bounds.lowerBound = (int)ZSTD_ps_auto;
        bounds.upperBound = (int)ZSTD_ps_disable;
        return bounds;

    case ZSTD_c_experimentalParam17:
        bounds.lowerBound = 0;
        bounds.upperBound = 1;
        return bounds;

    case ZSTD_c_experimentalParam18:
        bounds.lowerBound = (1 << 10);
        bounds.upperBound = (1<<17);
        return bounds;

    case ZSTD_c_experimentalParam19:
        bounds.lowerBound = (int)ZSTD_ps_auto;
        bounds.upperBound = (int)ZSTD_ps_disable;
        return bounds;

    default:
        bounds.error = ((size_t)-ZSTD_error_parameter_unsupported);
        return bounds;
    }
}




static size_t ZSTD_cParam_clampBounds(ZSTD_cParameter cParam, int* value)
{
    ZSTD_bounds const bounds = ZSTD_cParam_getBounds(cParam);
    if (ERR_isError(bounds.error)) return bounds.error;
    if (*value < bounds.lowerBound) *value = bounds.lowerBound;
    if (*value > bounds.upperBound) *value = bounds.upperBound;
    return 0;
}
# 658 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static int ZSTD_isUpdateAuthorized(ZSTD_cParameter param)
{
    switch(param)
    {
    case ZSTD_c_compressionLevel:
    case ZSTD_c_hashLog:
    case ZSTD_c_chainLog:
    case ZSTD_c_searchLog:
    case ZSTD_c_minMatch:
    case ZSTD_c_targetLength:
    case ZSTD_c_strategy:
    case ZSTD_c_experimentalParam20:
        return 1;

    case ZSTD_c_experimentalParam2:
    case ZSTD_c_windowLog:
    case ZSTD_c_contentSizeFlag:
    case ZSTD_c_checksumFlag:
    case ZSTD_c_dictIDFlag:
    case ZSTD_c_experimentalParam3 :
    case ZSTD_c_nbWorkers:
    case ZSTD_c_jobSize:
    case ZSTD_c_overlapLog:
    case ZSTD_c_experimentalParam1:
    case ZSTD_c_experimentalParam8:
    case ZSTD_c_enableLongDistanceMatching:
    case ZSTD_c_ldmHashLog:
    case ZSTD_c_ldmMinMatch:
    case ZSTD_c_ldmBucketSizeLog:
    case ZSTD_c_ldmHashRateLog:
    case ZSTD_c_experimentalParam4:
    case ZSTD_c_experimentalParam5:
    case ZSTD_c_targetCBlockSize:
    case ZSTD_c_experimentalParam7:
    case ZSTD_c_experimentalParam9:
    case ZSTD_c_experimentalParam10:
    case ZSTD_c_experimentalParam11:
    case ZSTD_c_experimentalParam12:
    case ZSTD_c_experimentalParam13:
    case ZSTD_c_experimentalParam14:
    case ZSTD_c_experimentalParam15:
    case ZSTD_c_experimentalParam16:
    case ZSTD_c_experimentalParam17:
    case ZSTD_c_experimentalParam18:
    case ZSTD_c_experimentalParam19:
    default:
        return 0;
    }
}

size_t ZSTD_CCtx_setParameter(ZSTD_CCtx* cctx, ZSTD_cParameter param, int value)
{
    do { } while (0);
    if (cctx->streamStage != zcss_init) {
        if (ZSTD_isUpdateAuthorized(param)) {
            cctx->cParamsChanged = 1;
        } else {
            do { do { } while (0); do { if (0) { _force_has_format_string("can only set params in cctx init stage"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } while(0);
    } }

    switch(param)
    {
    case ZSTD_c_nbWorkers:
        do { if ((value!=0) && cctx->staticSize) { do { } while (0); do { if (0) { _force_has_format_string("MT not compatible with static alloc"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0)
                                                              ;
        break;

    case ZSTD_c_compressionLevel:
    case ZSTD_c_windowLog:
    case ZSTD_c_hashLog:
    case ZSTD_c_chainLog:
    case ZSTD_c_searchLog:
    case ZSTD_c_minMatch:
    case ZSTD_c_targetLength:
    case ZSTD_c_strategy:
    case ZSTD_c_ldmHashRateLog:
    case ZSTD_c_experimentalParam2:
    case ZSTD_c_contentSizeFlag:
    case ZSTD_c_checksumFlag:
    case ZSTD_c_dictIDFlag:
    case ZSTD_c_experimentalParam3:
    case ZSTD_c_experimentalParam4:
    case ZSTD_c_experimentalParam5:
    case ZSTD_c_jobSize:
    case ZSTD_c_overlapLog:
    case ZSTD_c_experimentalParam1:
    case ZSTD_c_experimentalParam8:
    case ZSTD_c_enableLongDistanceMatching:
    case ZSTD_c_ldmHashLog:
    case ZSTD_c_ldmMinMatch:
    case ZSTD_c_ldmBucketSizeLog:
    case ZSTD_c_targetCBlockSize:
    case ZSTD_c_experimentalParam7:
    case ZSTD_c_experimentalParam9:
    case ZSTD_c_experimentalParam10:
    case ZSTD_c_experimentalParam11:
    case ZSTD_c_experimentalParam12:
    case ZSTD_c_experimentalParam13:
    case ZSTD_c_experimentalParam20:
    case ZSTD_c_experimentalParam14:
    case ZSTD_c_experimentalParam15:
    case ZSTD_c_experimentalParam16:
    case ZSTD_c_experimentalParam17:
    case ZSTD_c_experimentalParam18:
    case ZSTD_c_experimentalParam19:
        break;

    default: do { do { } while (0); do { if (0) { _force_has_format_string("unknown parameter"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);
    }
    return ZSTD_CCtxParams_setParameter(&cctx->requestedParams, param, value);
}

size_t ZSTD_CCtxParams_setParameter(ZSTD_CCtx_params* CCtxParams,
                                    ZSTD_cParameter param, int value)
{
    do { } while (0);
    switch(param)
    {
    case ZSTD_c_experimentalParam2 :
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam2,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->format = (ZSTD_format_e)value;
        return (size_t)CCtxParams->format;

    case ZSTD_c_compressionLevel : {
        do { size_t const err_code = (ZSTD_cParam_clampBounds(param, &value)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        if (value == 0)
            CCtxParams->compressionLevel = 3;
        else
            CCtxParams->compressionLevel = value;
        if (CCtxParams->compressionLevel >= 0) return (size_t)CCtxParams->compressionLevel;
        return 0;
    }

    case ZSTD_c_windowLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_windowLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.windowLog = (U32)value;
        return CCtxParams->cParams.windowLog;

    case ZSTD_c_hashLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_hashLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.hashLog = (U32)value;
        return CCtxParams->cParams.hashLog;

    case ZSTD_c_chainLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_chainLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.chainLog = (U32)value;
        return CCtxParams->cParams.chainLog;

    case ZSTD_c_searchLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_searchLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.searchLog = (U32)value;
        return (size_t)value;

    case ZSTD_c_minMatch :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_minMatch,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.minMatch = (U32)value;
        return CCtxParams->cParams.minMatch;

    case ZSTD_c_targetLength :
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_targetLength,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.targetLength = (U32)value;
        return CCtxParams->cParams.targetLength;

    case ZSTD_c_strategy :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_strategy,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->cParams.strategy = (ZSTD_strategy)value;
        return (size_t)CCtxParams->cParams.strategy;

    case ZSTD_c_contentSizeFlag :

        do { } while (0);
        CCtxParams->fParams.contentSizeFlag = value != 0;
        return (size_t)CCtxParams->fParams.contentSizeFlag;

    case ZSTD_c_checksumFlag :

        CCtxParams->fParams.checksumFlag = value != 0;
        return (size_t)CCtxParams->fParams.checksumFlag;

    case ZSTD_c_dictIDFlag :
        do { } while (0);
        CCtxParams->fParams.noDictIDFlag = !value;
        return !CCtxParams->fParams.noDictIDFlag;

    case ZSTD_c_experimentalParam3 :
        CCtxParams->forceWindow = (value != 0);
        return (size_t)CCtxParams->forceWindow;

    case ZSTD_c_experimentalParam4 : {
        const ZSTD_dictAttachPref_e pref = (ZSTD_dictAttachPref_e)value;
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam4,(int)pref)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->attachDictPref = pref;
        return CCtxParams->attachDictPref;
    }

    case ZSTD_c_experimentalParam5 : {
        const ZSTD_ParamSwitch_e lcm = (ZSTD_ParamSwitch_e)value;
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam5,(int)lcm)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->literalCompressionMode = lcm;
        return CCtxParams->literalCompressionMode;
    }

    case ZSTD_c_nbWorkers :

        do { if (value!=0) { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0);
        return 0;






    case ZSTD_c_jobSize :

        do { if (value!=0) { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0);
        return 0;
# 890 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    case ZSTD_c_overlapLog :

        do { if (value!=0) { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0);
        return 0;






    case ZSTD_c_experimentalParam1 :

        do { if (value!=0) { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0);
        return 0;






    case ZSTD_c_experimentalParam8 :
        CCtxParams->enableDedicatedDictSearch = (value!=0);
        return (size_t)CCtxParams->enableDedicatedDictSearch;

    case ZSTD_c_enableLongDistanceMatching :
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_enableLongDistanceMatching,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->ldmParams.enableLdm = (ZSTD_ParamSwitch_e)value;
        return CCtxParams->ldmParams.enableLdm;

    case ZSTD_c_ldmHashLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_ldmHashLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->ldmParams.hashLog = (U32)value;
        return CCtxParams->ldmParams.hashLog;

    case ZSTD_c_ldmMinMatch :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_ldmMinMatch,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->ldmParams.minMatchLength = (U32)value;
        return CCtxParams->ldmParams.minMatchLength;

    case ZSTD_c_ldmBucketSizeLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_ldmBucketSizeLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->ldmParams.bucketSizeLog = (U32)value;
        return CCtxParams->ldmParams.bucketSizeLog;

    case ZSTD_c_ldmHashRateLog :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_ldmHashRateLog,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->ldmParams.hashRateLog = (U32)value;
        return CCtxParams->ldmParams.hashRateLog;

    case ZSTD_c_targetCBlockSize :
        if (value!=0) {
            value = ((value)>(1340) ? (value) : (1340));
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_targetCBlockSize,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        }
        CCtxParams->targetCBlockSize = (U32)value;
        return CCtxParams->targetCBlockSize;

    case ZSTD_c_experimentalParam7 :
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam7,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->srcSizeHint = value;
        return (size_t)CCtxParams->srcSizeHint;

    case ZSTD_c_experimentalParam9:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam9,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->inBufferMode = (ZSTD_bufferMode_e)value;
        return CCtxParams->inBufferMode;

    case ZSTD_c_experimentalParam10:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam10,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->outBufferMode = (ZSTD_bufferMode_e)value;
        return CCtxParams->outBufferMode;

    case ZSTD_c_experimentalParam11:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam11,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->blockDelimiters = (ZSTD_SequenceFormat_e)value;
        return CCtxParams->blockDelimiters;

    case ZSTD_c_experimentalParam12:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam12,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->validateSequences = value;
        return (size_t)CCtxParams->validateSequences;

    case ZSTD_c_experimentalParam13:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam13,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->postBlockSplitter = (ZSTD_ParamSwitch_e)value;
        return CCtxParams->postBlockSplitter;

    case ZSTD_c_experimentalParam20:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam20,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->preBlockSplitter_level = value;
        return (size_t)CCtxParams->preBlockSplitter_level;

    case ZSTD_c_experimentalParam14:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam14,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->useRowMatchFinder = (ZSTD_ParamSwitch_e)value;
        return CCtxParams->useRowMatchFinder;

    case ZSTD_c_experimentalParam15:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam15,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->deterministicRefPrefix = !!value;
        return (size_t)CCtxParams->deterministicRefPrefix;

    case ZSTD_c_experimentalParam16:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam16,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->prefetchCDictTables = (ZSTD_ParamSwitch_e)value;
        return CCtxParams->prefetchCDictTables;

    case ZSTD_c_experimentalParam17:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam17,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->enableMatchFinderFallback = value;
        return (size_t)CCtxParams->enableMatchFinderFallback;

    case ZSTD_c_experimentalParam18:
        if (value!=0)
            do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam18,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        ((void)0);
        CCtxParams->maxBlockSize = (size_t)value;
        return CCtxParams->maxBlockSize;

    case ZSTD_c_experimentalParam19:
        do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_experimentalParam19,value)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
        CCtxParams->searchForExternalRepcodes = (ZSTD_ParamSwitch_e)value;
        return CCtxParams->searchForExternalRepcodes;

    default: do { do { } while (0); do { if (0) { _force_has_format_string("unknown parameter"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);
    }
}

size_t ZSTD_CCtx_getParameter(ZSTD_CCtx const* cctx, ZSTD_cParameter param, int* value)
{
    return ZSTD_CCtxParams_getParameter(&cctx->requestedParams, param, value);
}

size_t ZSTD_CCtxParams_getParameter(
        ZSTD_CCtx_params const* CCtxParams, ZSTD_cParameter param, int* value)
{
    switch(param)
    {
    case ZSTD_c_experimentalParam2 :
        *value = (int)CCtxParams->format;
        break;
    case ZSTD_c_compressionLevel :
        *value = CCtxParams->compressionLevel;
        break;
    case ZSTD_c_windowLog :
        *value = (int)CCtxParams->cParams.windowLog;
        break;
    case ZSTD_c_hashLog :
        *value = (int)CCtxParams->cParams.hashLog;
        break;
    case ZSTD_c_chainLog :
        *value = (int)CCtxParams->cParams.chainLog;
        break;
    case ZSTD_c_searchLog :
        *value = (int)CCtxParams->cParams.searchLog;
        break;
    case ZSTD_c_minMatch :
        *value = (int)CCtxParams->cParams.minMatch;
        break;
    case ZSTD_c_targetLength :
        *value = (int)CCtxParams->cParams.targetLength;
        break;
    case ZSTD_c_strategy :
        *value = (int)CCtxParams->cParams.strategy;
        break;
    case ZSTD_c_contentSizeFlag :
        *value = CCtxParams->fParams.contentSizeFlag;
        break;
    case ZSTD_c_checksumFlag :
        *value = CCtxParams->fParams.checksumFlag;
        break;
    case ZSTD_c_dictIDFlag :
        *value = !CCtxParams->fParams.noDictIDFlag;
        break;
    case ZSTD_c_experimentalParam3 :
        *value = CCtxParams->forceWindow;
        break;
    case ZSTD_c_experimentalParam4 :
        *value = (int)CCtxParams->attachDictPref;
        break;
    case ZSTD_c_experimentalParam5 :
        *value = (int)CCtxParams->literalCompressionMode;
        break;
    case ZSTD_c_nbWorkers :

        ((void)0);

        *value = CCtxParams->nbWorkers;
        break;
    case ZSTD_c_jobSize :

        do { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);





    case ZSTD_c_overlapLog :

        do { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);




    case ZSTD_c_experimentalParam1 :

        do { do { } while (0); do { if (0) { _force_has_format_string("not compiled with multithreading"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);




    case ZSTD_c_experimentalParam8 :
        *value = CCtxParams->enableDedicatedDictSearch;
        break;
    case ZSTD_c_enableLongDistanceMatching :
        *value = (int)CCtxParams->ldmParams.enableLdm;
        break;
    case ZSTD_c_ldmHashLog :
        *value = (int)CCtxParams->ldmParams.hashLog;
        break;
    case ZSTD_c_ldmMinMatch :
        *value = (int)CCtxParams->ldmParams.minMatchLength;
        break;
    case ZSTD_c_ldmBucketSizeLog :
        *value = (int)CCtxParams->ldmParams.bucketSizeLog;
        break;
    case ZSTD_c_ldmHashRateLog :
        *value = (int)CCtxParams->ldmParams.hashRateLog;
        break;
    case ZSTD_c_targetCBlockSize :
        *value = (int)CCtxParams->targetCBlockSize;
        break;
    case ZSTD_c_experimentalParam7 :
        *value = (int)CCtxParams->srcSizeHint;
        break;
    case ZSTD_c_experimentalParam9 :
        *value = (int)CCtxParams->inBufferMode;
        break;
    case ZSTD_c_experimentalParam10 :
        *value = (int)CCtxParams->outBufferMode;
        break;
    case ZSTD_c_experimentalParam11 :
        *value = (int)CCtxParams->blockDelimiters;
        break;
    case ZSTD_c_experimentalParam12 :
        *value = (int)CCtxParams->validateSequences;
        break;
    case ZSTD_c_experimentalParam13 :
        *value = (int)CCtxParams->postBlockSplitter;
        break;
    case ZSTD_c_experimentalParam20 :
        *value = CCtxParams->preBlockSplitter_level;
        break;
    case ZSTD_c_experimentalParam14 :
        *value = (int)CCtxParams->useRowMatchFinder;
        break;
    case ZSTD_c_experimentalParam15:
        *value = (int)CCtxParams->deterministicRefPrefix;
        break;
    case ZSTD_c_experimentalParam16:
        *value = (int)CCtxParams->prefetchCDictTables;
        break;
    case ZSTD_c_experimentalParam17:
        *value = CCtxParams->enableMatchFinderFallback;
        break;
    case ZSTD_c_experimentalParam18:
        *value = (int)CCtxParams->maxBlockSize;
        break;
    case ZSTD_c_experimentalParam19:
        *value = (int)CCtxParams->searchForExternalRepcodes;
        break;
    default: do { do { } while (0); do { if (0) { _force_has_format_string("unknown parameter"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);
    }
    return 0;
}
# 1178 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
size_t ZSTD_CCtx_setParametersUsingCCtxParams(
        ZSTD_CCtx* cctx, const ZSTD_CCtx_params* params)
{
    do { } while (0);
    do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("The context is in the wrong stage!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                         ;
    do { if (cctx->cdict) { do { } while (0); do { if (0) { _force_has_format_string("Can't override parameters with cdict attached (some must " "be inherited from the cdict)."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)

                                                    ;

    cctx->requestedParams = *params;
    return 0;
}

size_t ZSTD_CCtx_setCParams(ZSTD_CCtx* cctx, ZSTD_compressionParameters cparams)
{
    (void)sizeof(char[(sizeof(cparams) == 7 * 4) ? 1 : -1]);
    do { } while (0);

    do { size_t const err_code = (ZSTD_checkCParams(cparams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_windowLog, (int)cparams.windowLog)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_chainLog, (int)cparams.chainLog)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_hashLog, (int)cparams.hashLog)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_searchLog, (int)cparams.searchLog)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_minMatch, (int)cparams.minMatch)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_targetLength, (int)cparams.targetLength)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_strategy, (int)cparams.strategy)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}

size_t ZSTD_CCtx_setFParams(ZSTD_CCtx* cctx, ZSTD_frameParameters fparams)
{
    (void)sizeof(char[(sizeof(fparams) == 3 * 4) ? 1 : -1]);
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_contentSizeFlag, fparams.contentSizeFlag != 0)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_checksumFlag, fparams.checksumFlag != 0)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(cctx, ZSTD_c_dictIDFlag, fparams.noDictIDFlag == 0)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}

size_t ZSTD_CCtx_setParams(ZSTD_CCtx* cctx, ZSTD_parameters params)
{
    do { } while (0);

    do { size_t const err_code = (ZSTD_checkCParams(params.cParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

    do { size_t const err_code = (ZSTD_CCtx_setFParams(cctx, params.fParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

    do { size_t const err_code = (ZSTD_CCtx_setCParams(cctx, params.cParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}

size_t ZSTD_CCtx_setPledgedSrcSize(ZSTD_CCtx* cctx, unsigned long long pledgedSrcSize)
{
    do { } while (0);
    do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("Can't set pledgedSrcSize when not in init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                       ;
    cctx->pledgedSrcSizePlusOne = pledgedSrcSize+1;
    return 0;
}

static ZSTD_compressionParameters ZSTD_dedicatedDictSearch_getCParams(
        int const compressionLevel,
        size_t const dictSize);
static int ZSTD_dedicatedDictSearch_isSupported(
        const ZSTD_compressionParameters* cParams);
static void ZSTD_dedicatedDictSearch_revertCParams(
        ZSTD_compressionParameters* cParams);






static size_t ZSTD_initLocalDict(ZSTD_CCtx* cctx)
{
    ZSTD_localDict* const dl = &cctx->localDict;
    if (dl->dict == 
# 1255 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                   ((void *)0)
# 1255 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                       ) {

        ((void)0);
        ((void)0);
        ((void)0);
        return 0;
    }
    if (dl->cdict != 
# 1262 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                    ((void *)0)
# 1262 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                        ) {

        ((void)0);
        return 0;
    }
    ((void)0);
    ((void)0);
    ((void)0);

    dl->cdict = ZSTD_createCDict_advanced2(
            dl->dict,
            dl->dictSize,
            ZSTD_dlm_byRef,
            dl->dictContentType,
            &cctx->requestedParams,
            cctx->customMem);
    do { if (!dl->cdict) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_createCDict_advanced failed"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);
    cctx->cdict = dl->cdict;
    return 0;
}

size_t ZSTD_CCtx_loadDictionary_advanced(
        ZSTD_CCtx* cctx,
        const void* dict, size_t dictSize,
        ZSTD_dictLoadMethod_e dictLoadMethod,
        ZSTD_dictContentType_e dictContentType)
{
    do { } while (0);
    do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("Can't load a dictionary when cctx is not in init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                              ;
    ZSTD_clearAllDicts(cctx);
    if (dict == 
# 1293 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
               ((void *)0) 
# 1293 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                    || dictSize == 0)
        return 0;
    if (dictLoadMethod == ZSTD_dlm_byRef) {
        cctx->localDict.dict = dict;
    } else {

        void* dictBuffer;
        do { if (cctx->staticSize) { do { } while (0); do { if (0) { _force_has_format_string("static CCtx can't allocate for an internal copy of dictionary"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0)
                                                                                        ;
        dictBuffer = ZSTD_customMalloc(dictSize, cctx->customMem);
        do { if (dictBuffer==
# 1303 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
       ((void *)0)
# 1303 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
       ) { do { } while (0); do { if (0) { _force_has_format_string("allocation failed for dictionary content"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0)
                                                                   ;
        __builtin_memcpy((dictBuffer),(dict),(dictSize));
        cctx->localDict.dictBuffer = dictBuffer;
        cctx->localDict.dict = dictBuffer;
    }
    cctx->localDict.dictSize = dictSize;
    cctx->localDict.dictContentType = dictContentType;
    return 0;
}

size_t ZSTD_CCtx_loadDictionary_byReference(
      ZSTD_CCtx* cctx, const void* dict, size_t dictSize)
{
    return ZSTD_CCtx_loadDictionary_advanced(
            cctx, dict, dictSize, ZSTD_dlm_byRef, ZSTD_dct_auto);
}

size_t ZSTD_CCtx_loadDictionary(ZSTD_CCtx* cctx, const void* dict, size_t dictSize)
{
    return ZSTD_CCtx_loadDictionary_advanced(
            cctx, dict, dictSize, ZSTD_dlm_byCopy, ZSTD_dct_auto);
}


size_t ZSTD_CCtx_refCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict)
{
    do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("Can't ref a dict when ctx not in init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                   ;

    ZSTD_clearAllDicts(cctx);
    cctx->cdict = cdict;
    return 0;
}

size_t ZSTD_CCtx_refThreadPool(ZSTD_CCtx* cctx, ZSTD_threadPool* pool)
{
    do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("Can't ref a pool when ctx not in init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                   ;
    cctx->pool = pool;
    return 0;
}

size_t ZSTD_CCtx_refPrefix(ZSTD_CCtx* cctx, const void* prefix, size_t prefixSize)
{
    return ZSTD_CCtx_refPrefix_advanced(cctx, prefix, prefixSize, ZSTD_dct_rawContent);
}

size_t ZSTD_CCtx_refPrefix_advanced(
        ZSTD_CCtx* cctx, const void* prefix, size_t prefixSize, ZSTD_dictContentType_e dictContentType)
{
    do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("Can't ref a prefix when ctx not in init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                     ;
    ZSTD_clearAllDicts(cctx);
    if (prefix != 
# 1357 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                 ((void *)0) 
# 1357 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                      && prefixSize > 0) {
        cctx->prefixDict.dict = prefix;
        cctx->prefixDict.dictSize = prefixSize;
        cctx->prefixDict.dictContentType = dictContentType;
    }
    return 0;
}



size_t ZSTD_CCtx_reset(ZSTD_CCtx* cctx, ZSTD_ResetDirective reset)
{
    if ( (reset == ZSTD_reset_session_only)
      || (reset == ZSTD_reset_session_and_parameters) ) {
        cctx->streamStage = zcss_init;
        cctx->pledgedSrcSizePlusOne = 0;
    }
    if ( (reset == ZSTD_reset_parameters)
      || (reset == ZSTD_reset_session_and_parameters) ) {
        do { if (cctx->streamStage != zcss_init) { do { } while (0); do { if (0) { _force_has_format_string("Reset parameters is only possible during init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                               ;
        ZSTD_clearAllDicts(cctx);
        return ZSTD_CCtxParams_reset(&cctx->requestedParams);
    }
    return 0;
}





size_t ZSTD_checkCParams(ZSTD_compressionParameters cParams)
{
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_windowLog,(int)cParams.windowLog)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_chainLog,(int)cParams.chainLog)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_hashLog,(int)cParams.hashLog)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_searchLog,(int)cParams.searchLog)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_minMatch,(int)cParams.minMatch)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_targetLength,(int)cParams.targetLength)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    do { do { if (!ZSTD_cParam_withinBounds(ZSTD_c_strategy,(int)cParams.strategy)) { do { } while (0); do { if (0) { _force_has_format_string("Param out of bounds"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0); } while (0);
    return 0;
}




static ZSTD_compressionParameters
ZSTD_clampCParams(ZSTD_compressionParameters cParams)
{







    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_windowLog); if ((int)cParams.windowLog<bounds.lowerBound) cParams.windowLog=(unsigned)bounds.lowerBound; else if ((int)cParams.windowLog>bounds.upperBound) cParams.windowLog=(unsigned)bounds.upperBound; } while (0);
    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_chainLog); if ((int)cParams.chainLog<bounds.lowerBound) cParams.chainLog=(unsigned)bounds.lowerBound; else if ((int)cParams.chainLog>bounds.upperBound) cParams.chainLog=(unsigned)bounds.upperBound; } while (0);
    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_hashLog); if ((int)cParams.hashLog<bounds.lowerBound) cParams.hashLog=(unsigned)bounds.lowerBound; else if ((int)cParams.hashLog>bounds.upperBound) cParams.hashLog=(unsigned)bounds.upperBound; } while (0);
    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_searchLog); if ((int)cParams.searchLog<bounds.lowerBound) cParams.searchLog=(unsigned)bounds.lowerBound; else if ((int)cParams.searchLog>bounds.upperBound) cParams.searchLog=(unsigned)bounds.upperBound; } while (0);
    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_minMatch); if ((int)cParams.minMatch<bounds.lowerBound) cParams.minMatch=(unsigned)bounds.lowerBound; else if ((int)cParams.minMatch>bounds.upperBound) cParams.minMatch=(unsigned)bounds.upperBound; } while (0);
    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_targetLength); if ((int)cParams.targetLength<bounds.lowerBound) cParams.targetLength=(unsigned)bounds.lowerBound; else if ((int)cParams.targetLength>bounds.upperBound) cParams.targetLength=(unsigned)bounds.upperBound; } while (0);
    do { ZSTD_bounds const bounds = ZSTD_cParam_getBounds(ZSTD_c_strategy); if ((int)cParams.strategy<bounds.lowerBound) cParams.strategy=(ZSTD_strategy)bounds.lowerBound; else if ((int)cParams.strategy>bounds.upperBound) cParams.strategy=(ZSTD_strategy)bounds.upperBound; } while (0);
    return cParams;
}



U32 ZSTD_cycleLog(U32 hashLog, ZSTD_strategy strat)
{
    U32 const btScale = ((U32)strat >= (U32)ZSTD_btlazy2);
    return hashLog - btScale;
}
# 1439 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static U32 ZSTD_dictAndWindowLog(U32 windowLog, U64 srcSize, U64 dictSize)
{
    const U64 maxWindowSize = 1ULL << ((int)(sizeof(size_t) == 4 ? 30 : 31));

    if (dictSize == 0) {
        return windowLog;
    }
    ((void)0);
    ((void)0);
    {
        U64 const windowSize = 1ULL << windowLog;
        U64 const dictAndWindowSize = dictSize + windowSize;




        if (windowSize >= dictSize + srcSize) {
            return windowLog;
        } else if (dictAndWindowSize >= maxWindowSize) {
            return ((int)(sizeof(size_t) == 4 ? 30 : 31));
        } else {
            return ZSTD_highbit32((U32)dictAndWindowSize - 1) + 1;
        }
    }
}
# 1472 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static ZSTD_compressionParameters
ZSTD_adjustCParams_internal(ZSTD_compressionParameters cPar,
                            unsigned long long srcSize,
                            size_t dictSize,
                            ZSTD_CParamMode_e mode,
                            ZSTD_ParamSwitch_e useRowMatchFinder)
{
    const U64 minSrcSize = 513;
    const U64 maxWindowResize = 1ULL << (((int)(sizeof(size_t) == 4 ? 30 : 31))-1);
    ((void)0);
# 1525 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    switch (mode) {
    case ZSTD_cpm_unknown:
    case ZSTD_cpm_noAttachDict:




        break;
    case ZSTD_cpm_createCDict:



        if (dictSize && srcSize == (0ULL - 1))
            srcSize = minSrcSize;
        break;
    case ZSTD_cpm_attachDict:




        dictSize = 0;
        break;
    default:
        ((void)0);
        break;
    }


    if ( (srcSize <= maxWindowResize)
      && (dictSize <= maxWindowResize) ) {
        U32 const tSize = (U32)(srcSize + dictSize);
        static U32 const hashSizeMin = 1 << 6;
        U32 const srcLog = (tSize < hashSizeMin) ? 6 :
                            ZSTD_highbit32(tSize-1) + 1;
        if (cPar.windowLog > srcLog) cPar.windowLog = srcLog;
    }
    if (srcSize != (0ULL - 1)) {
        U32 const dictAndWindowLog = ZSTD_dictAndWindowLog(cPar.windowLog, (U64)srcSize, (U64)dictSize);
        U32 const cycleLog = ZSTD_cycleLog(cPar.chainLog, cPar.strategy);
        if (cPar.hashLog > dictAndWindowLog+1) cPar.hashLog = dictAndWindowLog+1;
        if (cycleLog > dictAndWindowLog)
            cPar.chainLog -= (cycleLog - dictAndWindowLog);
    }

    if (cPar.windowLog < 10)
        cPar.windowLog = 10;




    if (mode == ZSTD_cpm_createCDict && ZSTD_CDictIndicesAreTagged(&cPar)) {
        U32 const maxShortCacheHashLog = 32 - 8;
        if (cPar.hashLog > maxShortCacheHashLog) {
            cPar.hashLog = maxShortCacheHashLog;
        }
        if (cPar.chainLog > maxShortCacheHashLog) {
            cPar.chainLog = maxShortCacheHashLog;
        }
    }







    if (useRowMatchFinder == ZSTD_ps_auto)
        useRowMatchFinder = ZSTD_ps_enable;




    if (ZSTD_rowMatchFinderUsed(cPar.strategy, useRowMatchFinder)) {

        U32 const rowLog = (((4)>(((cPar.searchLog)<(6) ? (cPar.searchLog) : (6))) ? (4) : (((cPar.searchLog)<(6) ? (cPar.searchLog) : (6)))));
        U32 const maxRowHashLog = 32 - 8;
        U32 const maxHashLog = maxRowHashLog + rowLog;
        ((void)0);
        if (cPar.hashLog > maxHashLog) {
            cPar.hashLog = maxHashLog;
        }
    }

    return cPar;
}

ZSTD_compressionParameters
ZSTD_adjustCParams(ZSTD_compressionParameters cPar,
                   unsigned long long srcSize,
                   size_t dictSize)
{
    cPar = ZSTD_clampCParams(cPar);
    if (srcSize == 0) srcSize = (0ULL - 1);
    return ZSTD_adjustCParams_internal(cPar, srcSize, dictSize, ZSTD_cpm_unknown, ZSTD_ps_auto);
}

static ZSTD_compressionParameters ZSTD_getCParams_internal(int compressionLevel, unsigned long long srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode);
static ZSTD_parameters ZSTD_getParams_internal(int compressionLevel, unsigned long long srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode);

static void ZSTD_overrideCParams(
              ZSTD_compressionParameters* cParams,
        const ZSTD_compressionParameters* overrides)
{
    if (overrides->windowLog) cParams->windowLog = overrides->windowLog;
    if (overrides->hashLog) cParams->hashLog = overrides->hashLog;
    if (overrides->chainLog) cParams->chainLog = overrides->chainLog;
    if (overrides->searchLog) cParams->searchLog = overrides->searchLog;
    if (overrides->minMatch) cParams->minMatch = overrides->minMatch;
    if (overrides->targetLength) cParams->targetLength = overrides->targetLength;
    if (overrides->strategy) cParams->strategy = overrides->strategy;
}

ZSTD_compressionParameters ZSTD_getCParamsFromCCtxParams(
        const ZSTD_CCtx_params* CCtxParams, U64 srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode)
{
    ZSTD_compressionParameters cParams;
    if (srcSizeHint == (0ULL - 1) && CCtxParams->srcSizeHint > 0) {
        ((void)0);
        srcSizeHint = (U64)CCtxParams->srcSizeHint;
    }
    cParams = ZSTD_getCParams_internal(CCtxParams->compressionLevel, srcSizeHint, dictSize, mode);
    if (CCtxParams->ldmParams.enableLdm == ZSTD_ps_enable) cParams.windowLog = 27;
    ZSTD_overrideCParams(&cParams, &CCtxParams->cParams);
    ((void)0);

    return ZSTD_adjustCParams_internal(cParams, srcSizeHint, dictSize, mode, CCtxParams->useRowMatchFinder);
}

static size_t
ZSTD_sizeof_matchState(const ZSTD_compressionParameters* const cParams,
                       const ZSTD_ParamSwitch_e useRowMatchFinder,
                       const int enableDedicatedDictSearch,
                       const U32 forCCtx)
{

    size_t const chainSize = ZSTD_allocateChainTable(cParams->strategy, useRowMatchFinder, enableDedicatedDictSearch && !forCCtx)
                                ? ((size_t)1 << cParams->chainLog)
                                : 0;
    size_t const hSize = ((size_t)1) << cParams->hashLog;
    U32 const hashLog3 = (forCCtx && cParams->minMatch==3) ? ((17)<(cParams->windowLog) ? (17) : (cParams->windowLog)) : 0;
    size_t const h3Size = hashLog3 ? ((size_t)1) << hashLog3 : 0;


    size_t const tableSpace = chainSize * sizeof(U32)
                            + hSize * sizeof(U32)
                            + h3Size * sizeof(U32);
    size_t const optPotentialSpace =
        ZSTD_cwksp_aligned64_alloc_size((52 +1) * sizeof(U32))
      + ZSTD_cwksp_aligned64_alloc_size((35 +1) * sizeof(U32))
      + ZSTD_cwksp_aligned64_alloc_size((31 +1) * sizeof(U32))
      + ZSTD_cwksp_aligned64_alloc_size((1<<8) * sizeof(U32))
      + ZSTD_cwksp_aligned64_alloc_size(((1<<12)+3) * sizeof(ZSTD_match_t))
      + ZSTD_cwksp_aligned64_alloc_size(((1<<12)+3) * sizeof(ZSTD_optimal_t));
    size_t const lazyAdditionalSpace = ZSTD_rowMatchFinderUsed(cParams->strategy, useRowMatchFinder)
                                            ? ZSTD_cwksp_aligned64_alloc_size(hSize)
                                            : 0;
    size_t const optSpace = (forCCtx && (cParams->strategy >= ZSTD_btopt))
                                ? optPotentialSpace
                                : 0;
    size_t const slackSpace = ZSTD_cwksp_slack_space_required();


    (void)sizeof(char[(6 >= 4 && 10 >= 4 && 6 >= 4) ? 1 : -1]);
    ((void)0);

    do { } while (0)
                                                        ;
    return tableSpace + optSpace + slackSpace + lazyAdditionalSpace;
}



static size_t ZSTD_maxNbSeq(size_t blockSize, unsigned minMatch, int useSequenceProducer) {
    U32 const divider = (minMatch==3 || useSequenceProducer) ? 3 : 4;
    return blockSize / divider;
}

static size_t ZSTD_estimateCCtxSize_usingCCtxParams_internal(
        const ZSTD_compressionParameters* cParams,
        const ldmParams_t* ldmParams,
        const int isStatic,
        const ZSTD_ParamSwitch_e useRowMatchFinder,
        const size_t buffInSize,
        const size_t buffOutSize,
        const U64 pledgedSrcSize,
        int useSequenceProducer,
        size_t maxBlockSize)
{
    size_t const windowSize = (size_t) (((1ULL)>(((1ULL << cParams->windowLog)<(pledgedSrcSize) ? (1ULL << cParams->windowLog) : (pledgedSrcSize))) ? (1ULL) : (((1ULL << cParams->windowLog)<(pledgedSrcSize) ? (1ULL << cParams->windowLog) : (pledgedSrcSize)))));
    size_t const blockSize = ((ZSTD_resolveMaxBlockSize(maxBlockSize))<(windowSize) ? (ZSTD_resolveMaxBlockSize(maxBlockSize)) : (windowSize));
    size_t const maxNbSeq = ZSTD_maxNbSeq(blockSize, cParams->minMatch, useSequenceProducer);
    size_t const tokenSpace = ZSTD_cwksp_alloc_size(32 + blockSize)
                            + ZSTD_cwksp_aligned64_alloc_size(maxNbSeq * sizeof(SeqDef))
                            + 3 * ZSTD_cwksp_alloc_size(maxNbSeq * sizeof(BYTE));
    size_t const tmpWorkSpace = ZSTD_cwksp_alloc_size(((((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2))))>(8208) ? ((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2)))) : (8208))));
    size_t const blockStateSpace = 2 * ZSTD_cwksp_alloc_size(sizeof(ZSTD_compressedBlockState_t));
    size_t const matchStateSize = ZSTD_sizeof_matchState(cParams, useRowMatchFinder, 0, 1);

    size_t const ldmSpace = ZSTD_ldm_getTableSize(*ldmParams);
    size_t const maxNbLdmSeq = ZSTD_ldm_getMaxNbSeq(*ldmParams, blockSize);
    size_t const ldmSeqSpace = ldmParams->enableLdm == ZSTD_ps_enable ?
        ZSTD_cwksp_aligned64_alloc_size(maxNbLdmSeq * sizeof(rawSeq)) : 0;


    size_t const bufferSpace = ZSTD_cwksp_alloc_size(buffInSize)
                             + ZSTD_cwksp_alloc_size(buffOutSize);

    size_t const cctxSpace = isStatic ? ZSTD_cwksp_alloc_size(sizeof(ZSTD_CCtx)) : 0;

    size_t const maxNbExternalSeq = ZSTD_sequenceBound(blockSize);
    size_t const externalSeqSpace = useSequenceProducer
        ? ZSTD_cwksp_aligned64_alloc_size(maxNbExternalSeq * sizeof(ZSTD_Sequence))
        : 0;

    size_t const neededSpace =
        cctxSpace +
        tmpWorkSpace +
        blockStateSpace +
        ldmSpace +
        ldmSeqSpace +
        matchStateSize +
        tokenSpace +
        bufferSpace +
        externalSeqSpace;

    do { } while (0);
    return neededSpace;
}

size_t ZSTD_estimateCCtxSize_usingCCtxParams(const ZSTD_CCtx_params* params)
{
    ZSTD_compressionParameters const cParams =
                ZSTD_getCParamsFromCCtxParams(params, (0ULL - 1), 0, ZSTD_cpm_noAttachDict);
    ZSTD_ParamSwitch_e const useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(params->useRowMatchFinder,
                                                                               &cParams);

    do { if (params->nbWorkers > 0) { do { } while (0); do { if (0) { _force_has_format_string("Estimate CCtx size is supported for single-threaded compression only."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_GENERIC); } } while (0);



    return ZSTD_estimateCCtxSize_usingCCtxParams_internal(
        &cParams, &params->ldmParams, 1, useRowMatchFinder, 0, 0, (0ULL - 1), ZSTD_hasExtSeqProd(params), params->maxBlockSize);
}

size_t ZSTD_estimateCCtxSize_usingCParams(ZSTD_compressionParameters cParams)
{
    ZSTD_CCtx_params initialParams = ZSTD_makeCCtxParamsFromCParams(cParams);
    if (ZSTD_rowMatchFinderSupported(cParams.strategy)) {

        size_t noRowCCtxSize;
        size_t rowCCtxSize;
        initialParams.useRowMatchFinder = ZSTD_ps_disable;
        noRowCCtxSize = ZSTD_estimateCCtxSize_usingCCtxParams(&initialParams);
        initialParams.useRowMatchFinder = ZSTD_ps_enable;
        rowCCtxSize = ZSTD_estimateCCtxSize_usingCCtxParams(&initialParams);
        return ((noRowCCtxSize)>(rowCCtxSize) ? (noRowCCtxSize) : (rowCCtxSize));
    } else {
        return ZSTD_estimateCCtxSize_usingCCtxParams(&initialParams);
    }
}

static size_t ZSTD_estimateCCtxSize_internal(int compressionLevel)
{
    int tier = 0;
    size_t largestSize = 0;
    static const unsigned long long srcSizeTiers[4] = {16 *(1 <<10), 128 *(1 <<10), 256 *(1 <<10), (0ULL - 1)};
    for (; tier < 4; ++tier) {

        ZSTD_compressionParameters const cParams = ZSTD_getCParams_internal(compressionLevel, srcSizeTiers[tier], 0, ZSTD_cpm_noAttachDict);
        largestSize = ((ZSTD_estimateCCtxSize_usingCParams(cParams))>(largestSize) ? (ZSTD_estimateCCtxSize_usingCParams(cParams)) : (largestSize));
    }
    return largestSize;
}

size_t ZSTD_estimateCCtxSize(int compressionLevel)
{
    int level;
    size_t memBudget = 0;
    for (level=((compressionLevel)<(1) ? (compressionLevel) : (1)); level<=compressionLevel; level++) {

        size_t const newMB = ZSTD_estimateCCtxSize_internal(level);
        if (newMB > memBudget) memBudget = newMB;
    }
    return memBudget;
}

size_t ZSTD_estimateCStreamSize_usingCCtxParams(const ZSTD_CCtx_params* params)
{
    do { if (params->nbWorkers > 0) { do { } while (0); do { if (0) { _force_has_format_string("Estimate CCtx size is supported for single-threaded compression only."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_GENERIC); } } while (0);
    { ZSTD_compressionParameters const cParams =
                ZSTD_getCParamsFromCCtxParams(params, (0ULL - 1), 0, ZSTD_cpm_noAttachDict);
        size_t const blockSize = ((ZSTD_resolveMaxBlockSize(params->maxBlockSize))<((size_t)1 << cParams.windowLog) ? (ZSTD_resolveMaxBlockSize(params->maxBlockSize)) : ((size_t)1 << cParams.windowLog));
        size_t const inBuffSize = (params->inBufferMode == ZSTD_bm_buffered)
                ? ((size_t)1 << cParams.windowLog) + blockSize
                : 0;
        size_t const outBuffSize = (params->outBufferMode == ZSTD_bm_buffered)
                ? ZSTD_compressBound(blockSize) + 1
                : 0;
        ZSTD_ParamSwitch_e const useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(params->useRowMatchFinder, &params->cParams);

        return ZSTD_estimateCCtxSize_usingCCtxParams_internal(
            &cParams, &params->ldmParams, 1, useRowMatchFinder, inBuffSize, outBuffSize,
            (0ULL - 1), ZSTD_hasExtSeqProd(params), params->maxBlockSize);
    }
}

size_t ZSTD_estimateCStreamSize_usingCParams(ZSTD_compressionParameters cParams)
{
    ZSTD_CCtx_params initialParams = ZSTD_makeCCtxParamsFromCParams(cParams);
    if (ZSTD_rowMatchFinderSupported(cParams.strategy)) {

        size_t noRowCCtxSize;
        size_t rowCCtxSize;
        initialParams.useRowMatchFinder = ZSTD_ps_disable;
        noRowCCtxSize = ZSTD_estimateCStreamSize_usingCCtxParams(&initialParams);
        initialParams.useRowMatchFinder = ZSTD_ps_enable;
        rowCCtxSize = ZSTD_estimateCStreamSize_usingCCtxParams(&initialParams);
        return ((noRowCCtxSize)>(rowCCtxSize) ? (noRowCCtxSize) : (rowCCtxSize));
    } else {
        return ZSTD_estimateCStreamSize_usingCCtxParams(&initialParams);
    }
}

static size_t ZSTD_estimateCStreamSize_internal(int compressionLevel)
{
    ZSTD_compressionParameters const cParams = ZSTD_getCParams_internal(compressionLevel, (0ULL - 1), 0, ZSTD_cpm_noAttachDict);
    return ZSTD_estimateCStreamSize_usingCParams(cParams);
}

size_t ZSTD_estimateCStreamSize(int compressionLevel)
{
    int level;
    size_t memBudget = 0;
    for (level=((compressionLevel)<(1) ? (compressionLevel) : (1)); level<=compressionLevel; level++) {
        size_t const newMB = ZSTD_estimateCStreamSize_internal(level);
        if (newMB > memBudget) memBudget = newMB;
    }
    return memBudget;
}





ZSTD_frameProgression ZSTD_getFrameProgression(const ZSTD_CCtx* cctx)
{





    { ZSTD_frameProgression fp;
        size_t const buffered = (cctx->inBuff == 
# 1877 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                ((void *)0)
# 1877 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                    ) ? 0 :
                                cctx->inBuffPos - cctx->inToCompress;
        if (buffered) ((void)0);
        ((void)0);
        fp.ingested = cctx->consumedSrcSize + buffered;
        fp.consumed = cctx->consumedSrcSize;
        fp.produced = cctx->producedCSize;
        fp.flushed = cctx->producedCSize;
        fp.currentJobID = 0;
        fp.nbActiveWorkers = 0;
        return fp;
} }




size_t ZSTD_toFlushNow(ZSTD_CCtx* cctx)
{





    (void)cctx;
    return 0;
}

static void ZSTD_assertEqualCParams(ZSTD_compressionParameters cParams1,
                                    ZSTD_compressionParameters cParams2)
{
    (void)cParams1;
    (void)cParams2;
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
}

void ZSTD_reset_compressedBlockState(ZSTD_compressedBlockState_t* bs)
{
    int i;
    for (i = 0; i < 3; ++i)
        bs->rep[i] = repStartValue[i];
    bs->entropy.huf.repeatMode = HUF_repeat_none;
    bs->entropy.fse.offcode_repeatMode = FSE_repeat_none;
    bs->entropy.fse.matchlength_repeatMode = FSE_repeat_none;
    bs->entropy.fse.litlength_repeatMode = FSE_repeat_none;
}





static void ZSTD_invalidateMatchState(ZSTD_MatchState_t* ms)
{
    ZSTD_window_clear(&ms->window);

    ms->nextToUpdate = ms->window.dictLimit;
    ms->loadedDictEnd = 0;
    ms->opt.litLengthSum = 0;
    ms->dictMatchState = 
# 1940 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                        ((void *)0)
# 1940 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                            ;
}
# 1950 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
typedef enum {
    ZSTDcrp_makeClean,
    ZSTDcrp_leaveDirty
} ZSTD_compResetPolicy_e;






typedef enum {
    ZSTDirp_continue,
    ZSTDirp_reset
} ZSTD_indexResetPolicy_e;

typedef enum {
    ZSTD_resetTarget_CDict,
    ZSTD_resetTarget_CCtx
} ZSTD_resetTarget_e;


static U64 ZSTD_bitmix(U64 val, U64 len) {
    val ^= ZSTD_rotateRight_U64(val, 49) ^ ZSTD_rotateRight_U64(val, 24);
    val *= 0x9FB21C651E98DF25ULL;
    val ^= (val >> 35) + len ;
    val *= 0x9FB21C651E98DF25ULL;
    return val ^ (val >> 28);
}


static void ZSTD_advanceHashSalt(ZSTD_MatchState_t* ms) {
    ms->hashSalt = ZSTD_bitmix(ms->hashSalt, 8) ^ ZSTD_bitmix((U64) ms->hashSaltEntropy, 4);
}

static size_t
ZSTD_reset_matchState(ZSTD_MatchState_t* ms,
                      ZSTD_cwksp* ws,
                const ZSTD_compressionParameters* cParams,
                const ZSTD_ParamSwitch_e useRowMatchFinder,
                const ZSTD_compResetPolicy_e crp,
                const ZSTD_indexResetPolicy_e forceResetIndex,
                const ZSTD_resetTarget_e forWho)
{

    size_t const chainSize = ZSTD_allocateChainTable(cParams->strategy, useRowMatchFinder,
                                                     ms->dedicatedDictSearch && (forWho == ZSTD_resetTarget_CDict))
                                ? ((size_t)1 << cParams->chainLog)
                                : 0;
    size_t const hSize = ((size_t)1) << cParams->hashLog;
    U32 const hashLog3 = ((forWho == ZSTD_resetTarget_CCtx) && cParams->minMatch==3) ? ((17)<(cParams->windowLog) ? (17) : (cParams->windowLog)) : 0;
    size_t const h3Size = hashLog3 ? ((size_t)1) << hashLog3 : 0;

    do { } while (0);
    ((void)0);
    if (forceResetIndex == ZSTDirp_reset) {
        ZSTD_window_init(&ms->window);
        ZSTD_cwksp_mark_tables_dirty(ws);
    }

    ms->hashLog3 = hashLog3;
    ms->lazySkipping = 0;

    ZSTD_invalidateMatchState(ms);

    ((void)0);

    ZSTD_cwksp_clear_tables(ws);

    do { } while (0);

    ms->hashTable = (U32*)ZSTD_cwksp_reserve_table(ws, hSize * sizeof(U32));
    ms->chainTable = (U32*)ZSTD_cwksp_reserve_table(ws, chainSize * sizeof(U32));
    ms->hashTable3 = (U32*)ZSTD_cwksp_reserve_table(ws, h3Size * sizeof(U32));
    do { if (ZSTD_cwksp_reserve_failed(ws)) { do { } while (0); do { if (0) { _force_has_format_string("failed a workspace allocation in ZSTD_reset_matchState"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0)
                                                                             ;

    do { } while (0);
    if (crp!=ZSTDcrp_leaveDirty) {

        ZSTD_cwksp_clean_tables(ws);
    }

    if (ZSTD_rowMatchFinderUsed(cParams->strategy, useRowMatchFinder)) {

        size_t const tagTableSize = hSize;


        if(forWho == ZSTD_resetTarget_CCtx) {
            ms->tagTable = (BYTE*) ZSTD_cwksp_reserve_aligned_init_once(ws, tagTableSize);
            ZSTD_advanceHashSalt(ms);
        } else {

            ms->tagTable = (BYTE*) ZSTD_cwksp_reserve_aligned64(ws, tagTableSize);
            __builtin_memset((ms->tagTable),(0),(tagTableSize));
            ms->hashSalt = 0;
        }
        {
            U32 const rowLog = (((4)>(((cParams->searchLog)<(6) ? (cParams->searchLog) : (6))) ? (4) : (((cParams->searchLog)<(6) ? (cParams->searchLog) : (6)))));
            ((void)0);
            ms->rowHashLog = cParams->hashLog - rowLog;
        }
    }


    if ((forWho == ZSTD_resetTarget_CCtx) && (cParams->strategy >= ZSTD_btopt)) {
        do { } while (0);
        ms->opt.litFreq = (unsigned*)ZSTD_cwksp_reserve_aligned64(ws, (1<<8) * sizeof(unsigned));
        ms->opt.litLengthFreq = (unsigned*)ZSTD_cwksp_reserve_aligned64(ws, (35 +1) * sizeof(unsigned));
        ms->opt.matchLengthFreq = (unsigned*)ZSTD_cwksp_reserve_aligned64(ws, (52 +1) * sizeof(unsigned));
        ms->opt.offCodeFreq = (unsigned*)ZSTD_cwksp_reserve_aligned64(ws, (31 +1) * sizeof(unsigned));
        ms->opt.matchTable = (ZSTD_match_t*)ZSTD_cwksp_reserve_aligned64(ws, ((1<<12)+3) * sizeof(ZSTD_match_t));
        ms->opt.priceTable = (ZSTD_optimal_t*)ZSTD_cwksp_reserve_aligned64(ws, ((1<<12)+3) * sizeof(ZSTD_optimal_t));
    }

    ms->cParams = *cParams;

    do { if (ZSTD_cwksp_reserve_failed(ws)) { do { } while (0); do { if (0) { _force_has_format_string("failed a workspace allocation in ZSTD_reset_matchState"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0)
                                                                             ;
    return 0;
}
# 2079 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static int ZSTD_indexTooCloseToMax(ZSTD_window_t w)
{
    return (size_t)(w.nextSrc - w.base) > ((MEM_64bits() ? 3500U *(1 <<20) : 2000U *(1 <<20)) - (16 *(1 <<20)));
}






static int ZSTD_dictTooBig(size_t const loadedDictSize)
{
    return loadedDictSize > ( ((U32)-1) - (MEM_64bits() ? 3500U *(1 <<20) : 2000U *(1 <<20)));
}







static size_t ZSTD_resetCCtx_internal(ZSTD_CCtx* zc,
                                      ZSTD_CCtx_params const* params,
                                      U64 const pledgedSrcSize,
                                      size_t const loadedDictSize,
                                      ZSTD_compResetPolicy_e const crp,
                                      ZSTD_buffered_policy_e const zbuff)
{
    ZSTD_cwksp* const ws = &zc->workspace;
    do { } while (0)
                                                                                                                               ;
    ((void)0);

    zc->isFirstBlock = 1;




    zc->appliedParams = *params;
    params = &zc->appliedParams;

    ((void)0);
    ((void)0);
    ((void)0);
    ((void)0);
    if (params->ldmParams.enableLdm == ZSTD_ps_enable) {

        ZSTD_ldm_adjustParameters(&zc->appliedParams.ldmParams, &params->cParams);
        ((void)0);
        ((void)0);
    }

    { size_t const windowSize = ((1)>((size_t)((((U64)1 << params->cParams.windowLog))<(pledgedSrcSize) ? (((U64)1 << params->cParams.windowLog)) : (pledgedSrcSize))) ? (1) : ((size_t)((((U64)1 << params->cParams.windowLog))<(pledgedSrcSize) ? (((U64)1 << params->cParams.windowLog)) : (pledgedSrcSize))));
        size_t const blockSize = ((params->maxBlockSize)<(windowSize) ? (params->maxBlockSize) : (windowSize));
        size_t const maxNbSeq = ZSTD_maxNbSeq(blockSize, params->cParams.minMatch, ZSTD_hasExtSeqProd(params));
        size_t const buffOutSize = (zbuff == ZSTDb_buffered && params->outBufferMode == ZSTD_bm_buffered)
                ? ZSTD_compressBound(blockSize) + 1
                : 0;
        size_t const buffInSize = (zbuff == ZSTDb_buffered && params->inBufferMode == ZSTD_bm_buffered)
                ? windowSize + blockSize
                : 0;
        size_t const maxNbLdmSeq = ZSTD_ldm_getMaxNbSeq(params->ldmParams, blockSize);

        int const indexTooClose = ZSTD_indexTooCloseToMax(zc->blockState.matchState.window);
        int const dictTooBig = ZSTD_dictTooBig(loadedDictSize);
        ZSTD_indexResetPolicy_e needsIndexReset =
            (indexTooClose || dictTooBig || !zc->initialized) ? ZSTDirp_reset : ZSTDirp_continue;

        size_t const neededSpace =
            ZSTD_estimateCCtxSize_usingCCtxParams_internal(
                &params->cParams, &params->ldmParams, zc->staticSize != 0, params->useRowMatchFinder,
                buffInSize, buffOutSize, pledgedSrcSize, ZSTD_hasExtSeqProd(params), params->maxBlockSize);

        do { size_t const err_code = (neededSpace); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("cctx size estimate failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

        if (!zc->staticSize) ZSTD_cwksp_bump_oversized_duration(ws, 0);

        {
            int const workspaceTooSmall = ZSTD_cwksp_sizeof(ws) < neededSpace;
            int const workspaceWasteful = ZSTD_cwksp_check_wasteful(ws, neededSpace);
            int resizeWorkspace = workspaceTooSmall || workspaceWasteful;
            do { } while (0);
            do { } while (0);

            if (resizeWorkspace) {
                do { } while (0)

                                              ;

                do { if (zc->staticSize) { do { } while (0); do { if (0) { _force_has_format_string("static cctx : no resize"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);

                needsIndexReset = ZSTDirp_reset;

                ZSTD_cwksp_free(ws, zc->customMem);
                do { size_t const err_code = (ZSTD_cwksp_create(ws, neededSpace, zc->customMem)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

                do { } while (0);



                ((void)0);
                zc->blockState.prevCBlock = (ZSTD_compressedBlockState_t*) ZSTD_cwksp_reserve_object(ws, sizeof(ZSTD_compressedBlockState_t));
                do { if (zc->blockState.prevCBlock == 
# 2181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
               ((void *)0)
# 2181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
               ) { do { } while (0); do { if (0) { _force_has_format_string("couldn't allocate prevCBlock"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);
                zc->blockState.nextCBlock = (ZSTD_compressedBlockState_t*) ZSTD_cwksp_reserve_object(ws, sizeof(ZSTD_compressedBlockState_t));
                do { if (zc->blockState.nextCBlock == 
# 2183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
               ((void *)0)
# 2183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
               ) { do { } while (0); do { if (0) { _force_has_format_string("couldn't allocate nextCBlock"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);
                zc->tmpWorkspace = ZSTD_cwksp_reserve_object(ws, ((((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2))))>(8208) ? ((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2)))) : (8208))));
                do { if (zc->tmpWorkspace == 
# 2185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
               ((void *)0)
# 2185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
               ) { do { } while (0); do { if (0) { _force_has_format_string("couldn't allocate tmpWorkspace"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);
                zc->tmpWkspSize = ((((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2))))>(8208) ? ((((8 << 10) + 512 ) + (sizeof(unsigned) * (((35)>(52) ? (35) : (52)) + 2)))) : (8208)));
        } }

        ZSTD_cwksp_clear(ws);


        zc->blockState.matchState.cParams = params->cParams;
        zc->blockState.matchState.prefetchCDictTables = params->prefetchCDictTables == ZSTD_ps_enable;
        zc->pledgedSrcSizePlusOne = pledgedSrcSize+1;
        zc->consumedSrcSize = 0;
        zc->producedCSize = 0;
        if (pledgedSrcSize == (0ULL - 1))
            zc->appliedParams.fParams.contentSizeFlag = 0;
        do { } while (0)
                                                                                ;
        zc->blockSizeMax = blockSize;

        ZSTD_XXH64_reset(&zc->xxhState, 0);
        zc->stage = ZSTDcs_init;
        zc->dictID = 0;
        zc->dictContentSize = 0;

        ZSTD_reset_compressedBlockState(zc->blockState.prevCBlock);

        do { size_t const err_code = (ZSTD_reset_matchState( &zc->blockState.matchState, ws, &params->cParams, params->useRowMatchFinder, crp, needsIndexReset, ZSTD_resetTarget_CCtx)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)






                                           ;

        zc->seqStore.sequencesStart = (SeqDef*)ZSTD_cwksp_reserve_aligned64(ws, maxNbSeq * sizeof(SeqDef));


        if (params->ldmParams.enableLdm == ZSTD_ps_enable) {

            size_t const ldmHSize = ((size_t)1) << params->ldmParams.hashLog;
            zc->ldmState.hashTable = (ldmEntry_t*)ZSTD_cwksp_reserve_aligned64(ws, ldmHSize * sizeof(ldmEntry_t));
            __builtin_memset((zc->ldmState.hashTable),(0),(ldmHSize * sizeof(ldmEntry_t)));
            zc->ldmSequences = (rawSeq*)ZSTD_cwksp_reserve_aligned64(ws, maxNbLdmSeq * sizeof(rawSeq));
            zc->maxNbLdmSequences = maxNbLdmSeq;

            ZSTD_window_init(&zc->ldmState.window);
            zc->ldmState.loadedDictEnd = 0;
        }


        if (ZSTD_hasExtSeqProd(params)) {
            size_t const maxNbExternalSeq = ZSTD_sequenceBound(blockSize);
            zc->extSeqBufCapacity = maxNbExternalSeq;
            zc->extSeqBuf =
                (ZSTD_Sequence*)ZSTD_cwksp_reserve_aligned64(ws, maxNbExternalSeq * sizeof(ZSTD_Sequence));
        }






        zc->seqStore.litStart = ZSTD_cwksp_reserve_buffer(ws, blockSize + 32);
        zc->seqStore.maxNbLit = blockSize;

        zc->bufferedPolicy = zbuff;
        zc->inBuffSize = buffInSize;
        zc->inBuff = (char*)ZSTD_cwksp_reserve_buffer(ws, buffInSize);
        zc->outBuffSize = buffOutSize;
        zc->outBuff = (char*)ZSTD_cwksp_reserve_buffer(ws, buffOutSize);


        if (params->ldmParams.enableLdm == ZSTD_ps_enable) {

            size_t const numBuckets =
                  ((size_t)1) << (params->ldmParams.hashLog -
                                  params->ldmParams.bucketSizeLog);
            zc->ldmState.bucketOffsets = ZSTD_cwksp_reserve_buffer(ws, numBuckets);
            __builtin_memset((zc->ldmState.bucketOffsets),(0),(numBuckets));
        }


        ZSTD_referenceExternalSequences(zc, 
# 2267 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                           ((void *)0)
# 2267 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                               , 0);
        zc->seqStore.maxNbSeq = maxNbSeq;
        zc->seqStore.llCode = ZSTD_cwksp_reserve_buffer(ws, maxNbSeq * sizeof(BYTE));
        zc->seqStore.mlCode = ZSTD_cwksp_reserve_buffer(ws, maxNbSeq * sizeof(BYTE));
        zc->seqStore.ofCode = ZSTD_cwksp_reserve_buffer(ws, maxNbSeq * sizeof(BYTE));

        do { } while (0);
        ((void)0);

        zc->initialized = 1;

        return 0;
    }
}





void ZSTD_invalidateRepCodes(ZSTD_CCtx* cctx) {
    int i;
    for (i=0; i<3; i++) cctx->blockState.prevCBlock->rep[i] = 0;
    ((void)0);
}





static const size_t attachDictSizeCutoffs[ZSTD_btultra2+1] = {
    8 *(1 <<10),
    8 *(1 <<10),
    16 *(1 <<10),
    32 *(1 <<10),
    32 *(1 <<10),
    32 *(1 <<10),
    32 *(1 <<10),
    32 *(1 <<10),
    8 *(1 <<10),
    8 *(1 <<10)
};

static int ZSTD_shouldAttachDict(const ZSTD_CDict* cdict,
                                 const ZSTD_CCtx_params* params,
                                 U64 pledgedSrcSize)
{
    size_t cutoff = attachDictSizeCutoffs[cdict->matchState.cParams.strategy];
    int const dedicatedDictSearch = cdict->matchState.dedicatedDictSearch;
    return dedicatedDictSearch
        || ( ( pledgedSrcSize <= cutoff
            || pledgedSrcSize == (0ULL - 1)
            || params->attachDictPref == ZSTD_dictForceAttach )
          && params->attachDictPref != ZSTD_dictForceCopy
          && !params->forceWindow );

}

static size_t
ZSTD_resetCCtx_byAttachingCDict(ZSTD_CCtx* cctx,
                        const ZSTD_CDict* cdict,
                        ZSTD_CCtx_params params,
                        U64 pledgedSrcSize,
                        ZSTD_buffered_policy_e zbuff)
{
    do { } while (0)
                                                   ;
    {
        ZSTD_compressionParameters adjusted_cdict_cParams = cdict->matchState.cParams;
        unsigned const windowLog = params.cParams.windowLog;
        ((void)0);




        if (cdict->matchState.dedicatedDictSearch) {
            ZSTD_dedicatedDictSearch_revertCParams(&adjusted_cdict_cParams);
        }

        params.cParams = ZSTD_adjustCParams_internal(adjusted_cdict_cParams, pledgedSrcSize,
                                                     cdict->dictContentSize, ZSTD_cpm_attachDict,
                                                     params.useRowMatchFinder);
        params.cParams.windowLog = windowLog;
        params.useRowMatchFinder = cdict->useRowMatchFinder;
        do { size_t const err_code = (ZSTD_resetCCtx_internal(cctx, &params, pledgedSrcSize, 0, ZSTDcrp_makeClean, zbuff)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)

                                                                               ;
        ((void)0);
    }

    { const U32 cdictEnd = (U32)( cdict->matchState.window.nextSrc
                                  - cdict->matchState.window.base);
        const U32 cdictLen = cdictEnd - cdict->matchState.window.dictLimit;
        if (cdictLen == 0) {

            do { } while (0);
        } else {
            do { } while (0);
            cctx->blockState.matchState.dictMatchState = &cdict->matchState;



            if (cctx->blockState.matchState.window.dictLimit < cdictEnd) {
                cctx->blockState.matchState.window.nextSrc =
                    cctx->blockState.matchState.window.base + cdictEnd;
                ZSTD_window_clear(&cctx->blockState.matchState.window);
            }

            cctx->blockState.matchState.loadedDictEnd = cctx->blockState.matchState.window.dictLimit;
    } }

    cctx->dictID = cdict->dictID;
    cctx->dictContentSize = cdict->dictContentSize;


    __builtin_memcpy((cctx->blockState.prevCBlock),(&cdict->cBlockState),(sizeof(cdict->cBlockState)));

    return 0;
}

static void ZSTD_copyCDictTableIntoCCtx(U32* dst, U32 const* src, size_t tableSize,
                                        ZSTD_compressionParameters const* cParams) {
    if (ZSTD_CDictIndicesAreTagged(cParams)){


        size_t i;
        for (i = 0; i < tableSize; i++) {
            U32 const taggedIndex = src[i];
            U32 const index = taggedIndex >> 8;
            dst[i] = index;
        }
    } else {
        __builtin_memcpy((dst),(src),(tableSize * sizeof(U32)));
    }
}

static size_t ZSTD_resetCCtx_byCopyingCDict(ZSTD_CCtx* cctx,
                            const ZSTD_CDict* cdict,
                            ZSTD_CCtx_params params,
                            U64 pledgedSrcSize,
                            ZSTD_buffered_policy_e zbuff)
{
    const ZSTD_compressionParameters *cdict_cParams = &cdict->matchState.cParams;

    ((void)0);
    do { } while (0)
                                                   ;

    { unsigned const windowLog = params.cParams.windowLog;
        ((void)0);

        params.cParams = *cdict_cParams;
        params.cParams.windowLog = windowLog;
        params.useRowMatchFinder = cdict->useRowMatchFinder;
        do { size_t const err_code = (ZSTD_resetCCtx_internal(cctx, &params, pledgedSrcSize, 0, ZSTDcrp_leaveDirty, zbuff)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)

                                                                                ;
        ((void)0);
        ((void)0);
        ((void)0);
    }

    ZSTD_cwksp_mark_tables_dirty(&cctx->workspace);
    ((void)0);


    { size_t const chainSize = ZSTD_allocateChainTable(cdict_cParams->strategy, cdict->useRowMatchFinder, 0 )
                                                            ? ((size_t)1 << cdict_cParams->chainLog)
                                                            : 0;
        size_t const hSize = (size_t)1 << cdict_cParams->hashLog;

        ZSTD_copyCDictTableIntoCCtx(cctx->blockState.matchState.hashTable,
                                cdict->matchState.hashTable,
                                hSize, cdict_cParams);


        if (ZSTD_allocateChainTable(cctx->appliedParams.cParams.strategy, cctx->appliedParams.useRowMatchFinder, 0 )) {
            ZSTD_copyCDictTableIntoCCtx(cctx->blockState.matchState.chainTable,
                                    cdict->matchState.chainTable,
                                    chainSize, cdict_cParams);
        }

        if (ZSTD_rowMatchFinderUsed(cdict_cParams->strategy, cdict->useRowMatchFinder)) {
            size_t const tagTableSize = hSize;
            __builtin_memcpy((cctx->blockState.matchState.tagTable),(cdict->matchState.tagTable),(tagTableSize))

                                     ;
            cctx->blockState.matchState.hashSalt = cdict->matchState.hashSalt;
        }
    }


    ((void)0);
    { U32 const h3log = cctx->blockState.matchState.hashLog3;
        size_t const h3Size = h3log ? ((size_t)1 << h3log) : 0;
        ((void)0);
        __builtin_memset((cctx->blockState.matchState.hashTable3),(0),(h3Size * sizeof(U32)));
    }

    ZSTD_cwksp_mark_tables_clean(&cctx->workspace);


    { ZSTD_MatchState_t const* srcMatchState = &cdict->matchState;
        ZSTD_MatchState_t* dstMatchState = &cctx->blockState.matchState;
        dstMatchState->window = srcMatchState->window;
        dstMatchState->nextToUpdate = srcMatchState->nextToUpdate;
        dstMatchState->loadedDictEnd= srcMatchState->loadedDictEnd;
    }

    cctx->dictID = cdict->dictID;
    cctx->dictContentSize = cdict->dictContentSize;


    __builtin_memcpy((cctx->blockState.prevCBlock),(&cdict->cBlockState),(sizeof(cdict->cBlockState)));

    return 0;
}




static size_t ZSTD_resetCCtx_usingCDict(ZSTD_CCtx* cctx,
                            const ZSTD_CDict* cdict,
                            const ZSTD_CCtx_params* params,
                            U64 pledgedSrcSize,
                            ZSTD_buffered_policy_e zbuff)
{

    do { } while (0)
                                         ;

    if (ZSTD_shouldAttachDict(cdict, params, pledgedSrcSize)) {
        return ZSTD_resetCCtx_byAttachingCDict(
            cctx, cdict, *params, pledgedSrcSize, zbuff);
    } else {
        return ZSTD_resetCCtx_byCopyingCDict(
            cctx, cdict, *params, pledgedSrcSize, zbuff);
    }
}
# 2513 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static size_t ZSTD_copyCCtx_internal(ZSTD_CCtx* dstCCtx,
                            const ZSTD_CCtx* srcCCtx,
                            ZSTD_frameParameters fParams,
                            U64 pledgedSrcSize,
                            ZSTD_buffered_policy_e zbuff)
{
    do { if (srcCCtx->stage!=ZSTDcs_init) { do { } while (0); do { if (0) { _force_has_format_string("Can't copy a ctx that's not in init stage."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                                 ;
    do { } while (0);
    __builtin_memcpy((&dstCCtx->customMem),(&srcCCtx->customMem),(sizeof(ZSTD_customMem)));
    { ZSTD_CCtx_params params = dstCCtx->requestedParams;

        params.cParams = srcCCtx->appliedParams.cParams;
        ((void)0);
        ((void)0);
        ((void)0);
        params.useRowMatchFinder = srcCCtx->appliedParams.useRowMatchFinder;
        params.postBlockSplitter = srcCCtx->appliedParams.postBlockSplitter;
        params.ldmParams = srcCCtx->appliedParams.ldmParams;
        params.fParams = fParams;
        params.maxBlockSize = srcCCtx->appliedParams.maxBlockSize;
        ZSTD_resetCCtx_internal(dstCCtx, &params, pledgedSrcSize,
                                                     0,
                                ZSTDcrp_leaveDirty, zbuff);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
        ((void)0);
    }

    ZSTD_cwksp_mark_tables_dirty(&dstCCtx->workspace);


    { size_t const chainSize = ZSTD_allocateChainTable(srcCCtx->appliedParams.cParams.strategy,
                                                         srcCCtx->appliedParams.useRowMatchFinder,
                                                         0 )
                                    ? ((size_t)1 << srcCCtx->appliedParams.cParams.chainLog)
                                    : 0;
        size_t const hSize = (size_t)1 << srcCCtx->appliedParams.cParams.hashLog;
        U32 const h3log = srcCCtx->blockState.matchState.hashLog3;
        size_t const h3Size = h3log ? ((size_t)1 << h3log) : 0;

        __builtin_memcpy((dstCCtx->blockState.matchState.hashTable),(srcCCtx->blockState.matchState.hashTable),(hSize * sizeof(U32)))

                                   ;
        __builtin_memcpy((dstCCtx->blockState.matchState.chainTable),(srcCCtx->blockState.matchState.chainTable),(chainSize * sizeof(U32)))

                                       ;
        __builtin_memcpy((dstCCtx->blockState.matchState.hashTable3),(srcCCtx->blockState.matchState.hashTable3),(h3Size * sizeof(U32)))

                                    ;
    }

    ZSTD_cwksp_mark_tables_clean(&dstCCtx->workspace);


    {
        const ZSTD_MatchState_t* srcMatchState = &srcCCtx->blockState.matchState;
        ZSTD_MatchState_t* dstMatchState = &dstCCtx->blockState.matchState;
        dstMatchState->window = srcMatchState->window;
        dstMatchState->nextToUpdate = srcMatchState->nextToUpdate;
        dstMatchState->loadedDictEnd= srcMatchState->loadedDictEnd;
    }
    dstCCtx->dictID = srcCCtx->dictID;
    dstCCtx->dictContentSize = srcCCtx->dictContentSize;


    __builtin_memcpy((dstCCtx->blockState.prevCBlock),(srcCCtx->blockState.prevCBlock),(sizeof(*srcCCtx->blockState.prevCBlock)));

    return 0;
}






size_t ZSTD_copyCCtx(ZSTD_CCtx* dstCCtx, const ZSTD_CCtx* srcCCtx, unsigned long long pledgedSrcSize)
{
    ZSTD_frameParameters fParams = { 1 , 0 , 0 };
    ZSTD_buffered_policy_e const zbuff = srcCCtx->bufferedPolicy;
    (void)sizeof(char[((U32)ZSTDb_buffered==1) ? 1 : -1]);
    if (pledgedSrcSize==0) pledgedSrcSize = (0ULL - 1);
    fParams.contentSizeFlag = (pledgedSrcSize != (0ULL - 1));

    return ZSTD_copyCCtx_internal(dstCCtx, srcCCtx,
                                fParams, pledgedSrcSize,
                                zbuff);
}
# 2612 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static inline __attribute__((always_inline)) __attribute__((unused)) void
ZSTD_reduceTable_internal (U32* const table, U32 const size, U32 const reducerValue, int const preserveMark)
{
    int const nbRows = (int)size / 16;
    int cellNb = 0;
    int rowNb;

    U32 const reducerThreshold = reducerValue + 2;
    ((void)0);
    ((void)0);
# 2636 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    for (rowNb=0 ; rowNb < nbRows ; rowNb++) {
        int column;
        for (column=0; column<16; column++) {
            U32 newVal;
            if (preserveMark && table[cellNb] == 1) {


                newVal = 1;
            } else if (table[cellNb] < reducerThreshold) {
                newVal = 0;
            } else {
                newVal = table[cellNb] - reducerValue;
            }
            table[cellNb] = newVal;
            cellNb++;
    } }
}

static void ZSTD_reduceTable(U32* const table, U32 const size, U32 const reducerValue)
{
    ZSTD_reduceTable_internal(table, size, reducerValue, 0);
}

static void ZSTD_reduceTable_btlazy2(U32* const table, U32 const size, U32 const reducerValue)
{
    ZSTD_reduceTable_internal(table, size, reducerValue, 1);
}



static void ZSTD_reduceIndex (ZSTD_MatchState_t* ms, ZSTD_CCtx_params const* params, const U32 reducerValue)
{
    { U32 const hSize = (U32)1 << params->cParams.hashLog;
        ZSTD_reduceTable(ms->hashTable, hSize, reducerValue);
    }

    if (ZSTD_allocateChainTable(params->cParams.strategy, params->useRowMatchFinder, (U32)ms->dedicatedDictSearch)) {
        U32 const chainSize = (U32)1 << params->cParams.chainLog;
        if (params->cParams.strategy == ZSTD_btlazy2)
            ZSTD_reduceTable_btlazy2(ms->chainTable, chainSize, reducerValue);
        else
            ZSTD_reduceTable(ms->chainTable, chainSize, reducerValue);
    }

    if (ms->hashLog3) {
        U32 const h3Size = (U32)1 << ms->hashLog3;
        ZSTD_reduceTable(ms->hashTable3, h3Size, reducerValue);
    }
}
# 2693 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
int ZSTD_seqToCodes(const SeqStore_t* seqStorePtr)
{
    const SeqDef* const sequences = seqStorePtr->sequencesStart;
    BYTE* const llCodeTable = seqStorePtr->llCode;
    BYTE* const ofCodeTable = seqStorePtr->ofCode;
    BYTE* const mlCodeTable = seqStorePtr->mlCode;
    U32 const nbSeq = (U32)(seqStorePtr->sequences - seqStorePtr->sequencesStart);
    U32 u;
    int longOffsets = 0;
    ((void)0);
    for (u=0; u<nbSeq; u++) {
        U32 const llv = sequences[u].litLength;
        U32 const ofCode = ZSTD_highbit32(sequences[u].offBase);
        U32 const mlv = sequences[u].mlBase;
        llCodeTable[u] = (BYTE)ZSTD_LLcode(llv);
        ofCodeTable[u] = (BYTE)ofCode;
        mlCodeTable[u] = (BYTE)ZSTD_MLcode(mlv);
        ((void)0);
        if (MEM_32bits() && ofCode >= ((U32)(MEM_32bits() ? 25 : 57)))
            longOffsets = 1;
    }
    if (seqStorePtr->longLengthType==ZSTD_llt_literalLength)
        llCodeTable[seqStorePtr->longLengthPos] = 35;
    if (seqStorePtr->longLengthType==ZSTD_llt_matchLength)
        mlCodeTable[seqStorePtr->longLengthPos] = 52;
    return longOffsets;
}





static int ZSTD_useTargetCBlockSize(const ZSTD_CCtx_params* cctxParams)
{
    do { } while (0);
    return (cctxParams->targetCBlockSize != 0);
}






static int ZSTD_blockSplitterEnabled(ZSTD_CCtx_params* cctxParams)
{
    do { } while (0);
    ((void)0);
    return (cctxParams->postBlockSplitter == ZSTD_ps_enable);
}




typedef struct {
    U32 LLtype;
    U32 Offtype;
    U32 MLtype;
    size_t size;
    size_t lastCountSize;
    int longOffsets;
} ZSTD_symbolEncodingTypeStats_t;
# 2762 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static ZSTD_symbolEncodingTypeStats_t
ZSTD_buildSequencesStatistics(
                const SeqStore_t* seqStorePtr, size_t nbSeq,
                const ZSTD_fseCTables_t* prevEntropy, ZSTD_fseCTables_t* nextEntropy,
                      BYTE* dst, const BYTE* const dstEnd,
                      ZSTD_strategy strategy, unsigned* countWorkspace,
                      void* entropyWorkspace, size_t entropyWkspSize)
{
    BYTE* const ostart = dst;
    const BYTE* const oend = dstEnd;
    BYTE* op = ostart;
    FSE_CTable* CTable_LitLength = nextEntropy->litlengthCTable;
    FSE_CTable* CTable_OffsetBits = nextEntropy->offcodeCTable;
    FSE_CTable* CTable_MatchLength = nextEntropy->matchlengthCTable;
    const BYTE* const ofCodeTable = seqStorePtr->ofCode;
    const BYTE* const llCodeTable = seqStorePtr->llCode;
    const BYTE* const mlCodeTable = seqStorePtr->mlCode;
    ZSTD_symbolEncodingTypeStats_t stats;

    stats.lastCountSize = 0;

    stats.longOffsets = ZSTD_seqToCodes(seqStorePtr);
    ((void)0);
    ((void)0);

    { unsigned max = 35;
        size_t const mostFrequent = HIST_countFast_wksp(countWorkspace, &max, llCodeTable, nbSeq, entropyWorkspace, entropyWkspSize);
        do { } while (0);
        nextEntropy->litlength_repeatMode = prevEntropy->litlength_repeatMode;
        stats.LLtype = ZSTD_selectEncodingType(&nextEntropy->litlength_repeatMode,
                                        countWorkspace, max, mostFrequent, nbSeq,
                                        9, prevEntropy->litlengthCTable,
                                        LL_defaultNorm, LL_defaultNormLog,
                                        ZSTD_defaultAllowed, strategy);
        ((void)0);
        ((void)0);
        { size_t const countSize = ZSTD_buildCTable(
                op, (size_t)(oend - op),
                CTable_LitLength, 9, (SymbolEncodingType_e)stats.LLtype,
                countWorkspace, max, llCodeTable, nbSeq,
                LL_defaultNorm, LL_defaultNormLog, 35,
                prevEntropy->litlengthCTable,
                sizeof(prevEntropy->litlengthCTable),
                entropyWorkspace, entropyWkspSize);
            if (ERR_isError(countSize)) {
                do { } while (0);
                stats.size = countSize;
                return stats;
            }
            if (stats.LLtype == set_compressed)
                stats.lastCountSize = countSize;
            op += countSize;
            ((void)0);
    } }

    { unsigned max = 31;
        size_t const mostFrequent = HIST_countFast_wksp(
            countWorkspace, &max, ofCodeTable, nbSeq, entropyWorkspace, entropyWkspSize);

        ZSTD_DefaultPolicy_e const defaultPolicy = (max <= 28) ? ZSTD_defaultAllowed : ZSTD_defaultDisallowed;
        do { } while (0);
        nextEntropy->offcode_repeatMode = prevEntropy->offcode_repeatMode;
        stats.Offtype = ZSTD_selectEncodingType(&nextEntropy->offcode_repeatMode,
                                        countWorkspace, max, mostFrequent, nbSeq,
                                        8, prevEntropy->offcodeCTable,
                                        OF_defaultNorm, OF_defaultNormLog,
                                        defaultPolicy, strategy);
        ((void)0);
        { size_t const countSize = ZSTD_buildCTable(
                op, (size_t)(oend - op),
                CTable_OffsetBits, 8, (SymbolEncodingType_e)stats.Offtype,
                countWorkspace, max, ofCodeTable, nbSeq,
                OF_defaultNorm, OF_defaultNormLog, 28,
                prevEntropy->offcodeCTable,
                sizeof(prevEntropy->offcodeCTable),
                entropyWorkspace, entropyWkspSize);
            if (ERR_isError(countSize)) {
                do { } while (0);
                stats.size = countSize;
                return stats;
            }
            if (stats.Offtype == set_compressed)
                stats.lastCountSize = countSize;
            op += countSize;
            ((void)0);
    } }

    { unsigned max = 52;
        size_t const mostFrequent = HIST_countFast_wksp(
            countWorkspace, &max, mlCodeTable, nbSeq, entropyWorkspace, entropyWkspSize);
        do { } while (0);
        nextEntropy->matchlength_repeatMode = prevEntropy->matchlength_repeatMode;
        stats.MLtype = ZSTD_selectEncodingType(&nextEntropy->matchlength_repeatMode,
                                        countWorkspace, max, mostFrequent, nbSeq,
                                        9, prevEntropy->matchlengthCTable,
                                        ML_defaultNorm, ML_defaultNormLog,
                                        ZSTD_defaultAllowed, strategy);
        ((void)0);
        { size_t const countSize = ZSTD_buildCTable(
                op, (size_t)(oend - op),
                CTable_MatchLength, 9, (SymbolEncodingType_e)stats.MLtype,
                countWorkspace, max, mlCodeTable, nbSeq,
                ML_defaultNorm, ML_defaultNormLog, 52,
                prevEntropy->matchlengthCTable,
                sizeof(prevEntropy->matchlengthCTable),
                entropyWorkspace, entropyWkspSize);
            if (ERR_isError(countSize)) {
                do { } while (0);
                stats.size = countSize;
                return stats;
            }
            if (stats.MLtype == set_compressed)
                stats.lastCountSize = countSize;
            op += countSize;
            ((void)0);
    } }
    stats.size = (size_t)(op-ostart);
    return stats;
}






static __inline __attribute__((unused)) size_t
ZSTD_entropyCompressSeqStore_internal(
                              void* dst, size_t dstCapacity,
                        const void* literals, size_t litSize,
                        const SeqStore_t* seqStorePtr,
                        const ZSTD_entropyCTables_t* prevEntropy,
                              ZSTD_entropyCTables_t* nextEntropy,
                        const ZSTD_CCtx_params* cctxParams,
                              void* entropyWorkspace, size_t entropyWkspSize,
                        const int bmi2)
{
    ZSTD_strategy const strategy = cctxParams->cParams.strategy;
    unsigned* count = (unsigned*)entropyWorkspace;
    FSE_CTable* CTable_LitLength = nextEntropy->fse.litlengthCTable;
    FSE_CTable* CTable_OffsetBits = nextEntropy->fse.offcodeCTable;
    FSE_CTable* CTable_MatchLength = nextEntropy->fse.matchlengthCTable;
    const SeqDef* const sequences = seqStorePtr->sequencesStart;
    const size_t nbSeq = (size_t)(seqStorePtr->sequences - seqStorePtr->sequencesStart);
    const BYTE* const ofCodeTable = seqStorePtr->ofCode;
    const BYTE* const llCodeTable = seqStorePtr->llCode;
    const BYTE* const mlCodeTable = seqStorePtr->mlCode;
    BYTE* const ostart = (BYTE*)dst;
    BYTE* const oend = ostart + dstCapacity;
    BYTE* op = ostart;
    size_t lastCountSize;
    int longOffsets = 0;

    entropyWorkspace = count + (((35)>(52) ? (35) : (52)) + 1);
    entropyWkspSize -= (((35)>(52) ? (35) : (52)) + 1) * sizeof(*count);

    do { } while (0);
    (void)sizeof(char[(((8 << 10) + 512 ) >= (1<<((9)>(9) ? (9) : (9)))) ? 1 : -1]);
    ((void)0);


    { size_t const numSequences = (size_t)(seqStorePtr->sequences - seqStorePtr->sequencesStart);

        int const suspectUncompressible = (numSequences == 0) || (litSize / numSequences >= 20);

        size_t const cSize = ZSTD_compressLiterals(
                                    op, dstCapacity,
                                    literals, litSize,
                                    entropyWorkspace, entropyWkspSize,
                                    &prevEntropy->huf, &nextEntropy->huf,
                                    cctxParams->cParams.strategy,
                                    ZSTD_literalsCompressionIsDisabled(cctxParams),
                                    suspectUncompressible, bmi2);
        do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressLiterals failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ((void)0);
        op += cSize;
    }


    do { if ((oend-op) < 3 + 1) { do { } while (0); do { if (0) { _force_has_format_string("Can't fit seq hdr in output buf!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)
                                                                         ;
    if (nbSeq < 128) {
        *op++ = (BYTE)nbSeq;
    } else if (nbSeq < 0x7F00) {
        op[0] = (BYTE)((nbSeq>>8) + 0x80);
        op[1] = (BYTE)nbSeq;
        op+=2;
    } else {
        op[0]=0xFF;
        MEM_writeLE16(op+1, (U16)(nbSeq - 0x7F00));
        op+=3;
    }
    ((void)0);
    if (nbSeq==0) {

        __builtin_memcpy((&nextEntropy->fse),(&prevEntropy->fse),(sizeof(prevEntropy->fse)));
        return (size_t)(op - ostart);
    }
    { BYTE* const seqHead = op++;

        const ZSTD_symbolEncodingTypeStats_t stats =
                ZSTD_buildSequencesStatistics(seqStorePtr, nbSeq,
                                             &prevEntropy->fse, &nextEntropy->fse,
                                              op, oend,
                                              strategy, count,
                                              entropyWorkspace, entropyWkspSize);
        do { size_t const err_code = (stats.size); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildSequencesStatistics failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        *seqHead = (BYTE)((stats.LLtype<<6) + (stats.Offtype<<4) + (stats.MLtype<<2));
        lastCountSize = stats.lastCountSize;
        op += stats.size;
        longOffsets = stats.longOffsets;
    }

    { size_t const bitstreamSize = ZSTD_encodeSequences(
                                        op, (size_t)(oend - op),
                                        CTable_MatchLength, mlCodeTable,
                                        CTable_OffsetBits, ofCodeTable,
                                        CTable_LitLength, llCodeTable,
                                        sequences, nbSeq,
                                        longOffsets, bmi2);
        do { size_t const err_code = (bitstreamSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_encodeSequences failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        op += bitstreamSize;
        ((void)0);
# 2992 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
        if (lastCountSize && (lastCountSize + bitstreamSize) < 4) {

            ((void)0);
            do { } while (0)
                                                          ;
            return 0;
        }
    }

    do { } while (0);
    return (size_t)(op - ostart);
}

static size_t
ZSTD_entropyCompressSeqStore_wExtLitBuffer(
                          void* dst, size_t dstCapacity,
                    const void* literals, size_t litSize,
                          size_t blockSize,
                    const SeqStore_t* seqStorePtr,
                    const ZSTD_entropyCTables_t* prevEntropy,
                          ZSTD_entropyCTables_t* nextEntropy,
                    const ZSTD_CCtx_params* cctxParams,
                          void* entropyWorkspace, size_t entropyWkspSize,
                          int bmi2)
{
    size_t const cSize = ZSTD_entropyCompressSeqStore_internal(
                            dst, dstCapacity,
                            literals, litSize,
                            seqStorePtr, prevEntropy, nextEntropy, cctxParams,
                            entropyWorkspace, entropyWkspSize, bmi2);
    if (cSize == 0) return 0;



    if ((cSize == ((size_t)-ZSTD_error_dstSize_tooSmall)) & (blockSize <= dstCapacity)) {
        do { } while (0);
        return 0;
    }
    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_entropyCompressSeqStore_internal failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);


    { size_t const maxCSize = blockSize - ZSTD_minGain(blockSize, cctxParams->cParams.strategy);
        if (cSize >= maxCSize) return 0;
    }
    do { } while (0);



    ((void)0);
    return cSize;
}

static size_t
ZSTD_entropyCompressSeqStore(
                    const SeqStore_t* seqStorePtr,
                    const ZSTD_entropyCTables_t* prevEntropy,
                          ZSTD_entropyCTables_t* nextEntropy,
                    const ZSTD_CCtx_params* cctxParams,
                          void* dst, size_t dstCapacity,
                          size_t srcSize,
                          void* entropyWorkspace, size_t entropyWkspSize,
                          int bmi2)
{
    return ZSTD_entropyCompressSeqStore_wExtLitBuffer(
                dst, dstCapacity,
                seqStorePtr->litStart, (size_t)(seqStorePtr->lit - seqStorePtr->litStart),
                srcSize,
                seqStorePtr,
                prevEntropy, nextEntropy,
                cctxParams,
                entropyWorkspace, entropyWkspSize,
                bmi2);
}




ZSTD_BlockCompressor_f ZSTD_selectBlockCompressor(ZSTD_strategy strat, ZSTD_ParamSwitch_e useRowMatchFinder, ZSTD_dictMode_e dictMode)
{
    static const ZSTD_BlockCompressor_f blockCompressor[4][ZSTD_btultra2+1] = {
        { ZSTD_compressBlock_fast ,
          ZSTD_compressBlock_fast,
          ZSTD_compressBlock_doubleFast,
          ZSTD_compressBlock_greedy,
          ZSTD_compressBlock_lazy,
          ZSTD_compressBlock_lazy2,
          ZSTD_compressBlock_btlazy2,
          ZSTD_compressBlock_btopt,
          ZSTD_compressBlock_btultra,
          ZSTD_compressBlock_btultra2
        },
        { ZSTD_compressBlock_fast_extDict ,
          ZSTD_compressBlock_fast_extDict,
          ZSTD_compressBlock_doubleFast_extDict,
          ZSTD_compressBlock_greedy_extDict,
          ZSTD_compressBlock_lazy_extDict,
          ZSTD_compressBlock_lazy2_extDict,
          ZSTD_compressBlock_btlazy2_extDict,
          ZSTD_compressBlock_btopt_extDict,
          ZSTD_compressBlock_btultra_extDict,
          ZSTD_compressBlock_btultra_extDict
        },
        { ZSTD_compressBlock_fast_dictMatchState ,
          ZSTD_compressBlock_fast_dictMatchState,
          ZSTD_compressBlock_doubleFast_dictMatchState,
          ZSTD_compressBlock_greedy_dictMatchState,
          ZSTD_compressBlock_lazy_dictMatchState,
          ZSTD_compressBlock_lazy2_dictMatchState,
          ZSTD_compressBlock_btlazy2_dictMatchState,
          ZSTD_compressBlock_btopt_dictMatchState,
          ZSTD_compressBlock_btultra_dictMatchState,
          ZSTD_compressBlock_btultra_dictMatchState
        },
        { 
# 3105 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0) 
# 3105 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                  ,
          
# 3106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0)
# 3106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
             ,
          
# 3107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0)
# 3107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
             ,
          ZSTD_compressBlock_greedy_dedicatedDictSearch,
          ZSTD_compressBlock_lazy_dedicatedDictSearch,
          ZSTD_compressBlock_lazy2_dedicatedDictSearch,
          
# 3111 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0)
# 3111 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
             ,
          
# 3112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0)
# 3112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
             ,
          
# 3113 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0)
# 3113 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
             ,
          
# 3114 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
         ((void *)0) 
# 3114 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
              }
    };
    ZSTD_BlockCompressor_f selectedCompressor;
    (void)sizeof(char[((unsigned)ZSTD_fast == 1) ? 1 : -1]);

    ((void)0);
    do { } while (0);
    if (ZSTD_rowMatchFinderUsed(strat, useRowMatchFinder)) {
        static const ZSTD_BlockCompressor_f rowBasedBlockCompressors[4][3] = {
            {
                ZSTD_compressBlock_greedy_row,
                ZSTD_compressBlock_lazy_row,
                ZSTD_compressBlock_lazy2_row
            },
            {
                ZSTD_compressBlock_greedy_extDict_row,
                ZSTD_compressBlock_lazy_extDict_row,
                ZSTD_compressBlock_lazy2_extDict_row
            },
            {
                ZSTD_compressBlock_greedy_dictMatchState_row,
                ZSTD_compressBlock_lazy_dictMatchState_row,
                ZSTD_compressBlock_lazy2_dictMatchState_row
            },
            {
                ZSTD_compressBlock_greedy_dedicatedDictSearch_row,
                ZSTD_compressBlock_lazy_dedicatedDictSearch_row,
                ZSTD_compressBlock_lazy2_dedicatedDictSearch_row
            }
        };
        do { } while (0);
        ((void)0);
        selectedCompressor = rowBasedBlockCompressors[(int)dictMode][(int)strat - (int)ZSTD_greedy];
    } else {
        selectedCompressor = blockCompressor[(int)dictMode][(int)strat];
    }
    ((void)0);
    return selectedCompressor;
}

static void ZSTD_storeLastLiterals(SeqStore_t* seqStorePtr,
                                   const BYTE* anchor, size_t lastLLSize)
{
    __builtin_memcpy((seqStorePtr->lit),(anchor),(lastLLSize));
    seqStorePtr->lit += lastLLSize;
}

void ZSTD_resetSeqStore(SeqStore_t* ssPtr)
{
    ssPtr->lit = ssPtr->litStart;
    ssPtr->sequences = ssPtr->sequencesStart;
    ssPtr->longLengthType = ZSTD_llt_none;
}







static size_t ZSTD_postProcessSequenceProducerResult(
    ZSTD_Sequence* outSeqs, size_t nbExternalSeqs, size_t outSeqsCapacity, size_t srcSize
) {
    do { if (nbExternalSeqs > outSeqsCapacity) { do { } while (0); do { if (0) { _force_has_format_string("External sequence producer returned error code %lu", (unsigned long)nbExternalSeqs); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_sequenceProducer_failed); } } while (0)




     ;

    do { if (nbExternalSeqs == 0 && srcSize > 0) { do { } while (0); do { if (0) { _force_has_format_string("Got zero sequences from external sequence producer for a non-empty src buffer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_sequenceProducer_failed); } } while (0)



     ;

    if (srcSize == 0) {
        __builtin_memset((&outSeqs[0]),(0),(sizeof(ZSTD_Sequence)));
        return 1;
    }

    {
        ZSTD_Sequence const lastSeq = outSeqs[nbExternalSeqs - 1];


        if (lastSeq.offset == 0 && lastSeq.matchLength == 0) {
            return nbExternalSeqs;
        }



        do { if (nbExternalSeqs == outSeqsCapacity) { do { } while (0); do { if (0) { _force_has_format_string("nbExternalSeqs == outSeqsCapacity but lastSeq is not a block delimiter!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_sequenceProducer_failed); } } while (0)



         ;


        __builtin_memset((&outSeqs[nbExternalSeqs]),(0),(sizeof(ZSTD_Sequence)));
        return nbExternalSeqs + 1;
    }
}







static size_t ZSTD_fastSequenceLengthSum(ZSTD_Sequence const* seqBuf, size_t seqBufSize) {
    size_t matchLenSum, litLenSum, i;
    matchLenSum = 0;
    litLenSum = 0;
    for (i = 0; i < seqBufSize; i++) {
        litLenSum += seqBuf[i].litLength;
        matchLenSum += seqBuf[i].matchLength;
    }
    return litLenSum + matchLenSum;
}




static void ZSTD_validateSeqStore(const SeqStore_t* seqStore, const ZSTD_compressionParameters* cParams)
{
# 3250 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    (void)seqStore;
    (void)cParams;

}

static size_t
ZSTD_transferSequences_wBlockDelim(ZSTD_CCtx* cctx,
                                   ZSTD_SequencePosition* seqPos,
                             const ZSTD_Sequence* const inSeqs, size_t inSeqsSize,
                             const void* src, size_t blockSize,
                                   ZSTD_ParamSwitch_e externalRepSearch);

typedef enum { ZSTDbss_compress, ZSTDbss_noCompress } ZSTD_BuildSeqStore_e;

static size_t ZSTD_buildSeqStore(ZSTD_CCtx* zc, const void* src, size_t srcSize)
{
    ZSTD_MatchState_t* const ms = &zc->blockState.matchState;
    do { } while (0);
    ((void)0);

    ZSTD_assertEqualCParams(zc->appliedParams.cParams, ms->cParams);


    if (srcSize < (1 + 1 )+ZSTD_blockHeaderSize+1+1) {
        if (zc->appliedParams.cParams.strategy >= ZSTD_btopt) {
            ZSTD_ldm_skipRawSeqStoreBytes(&zc->externSeqStore, srcSize);
        } else {
            ZSTD_ldm_skipSequences(&zc->externSeqStore, srcSize, zc->appliedParams.cParams.minMatch);
        }
        return ZSTDbss_noCompress;
    }
    ZSTD_resetSeqStore(&(zc->seqStore));

    ms->opt.symbolCosts = &zc->blockState.prevCBlock->entropy;

    ms->opt.literalCompressionMode = zc->appliedParams.literalCompressionMode;



    ((void)0);


    { const BYTE* const base = ms->window.base;
        const BYTE* const istart = (const BYTE*)src;
        const U32 curr = (U32)(istart-base);
        if (sizeof(ptrdiff_t)==8) ((void)0);
        if (curr > ms->nextToUpdate + 384)
            ms->nextToUpdate = curr - ((192)<((U32)(curr - ms->nextToUpdate - 384)) ? (192) : ((U32)(curr - ms->nextToUpdate - 384)));
    }


    { ZSTD_dictMode_e const dictMode = ZSTD_matchState_dictMode(ms);
        size_t lastLLSize;
        { int i;
            for (i = 0; i < 3; ++i)
                zc->blockState.nextCBlock->rep[i] = zc->blockState.prevCBlock->rep[i];
        }
        if (zc->externSeqStore.pos < zc->externSeqStore.size) {
            ((void)0);



            do { if (ZSTD_hasExtSeqProd(&zc->appliedParams)) { do { } while (0); do { if (0) { _force_has_format_string("Long-distance matching with external sequence producer enabled is not currently supported."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_combination_unsupported); } } while (0)



             ;


            lastLLSize =
                ZSTD_ldm_blockCompress(&zc->externSeqStore,
                                       ms, &zc->seqStore,
                                       zc->blockState.nextCBlock->rep,
                                       zc->appliedParams.useRowMatchFinder,
                                       src, srcSize);
            ((void)0);
        } else if (zc->appliedParams.ldmParams.enableLdm == ZSTD_ps_enable) {
            RawSeqStore_t ldmSeqStore = kNullRawSeqStore;



            do { if (ZSTD_hasExtSeqProd(&zc->appliedParams)) { do { } while (0); do { if (0) { _force_has_format_string("Long-distance matching with external sequence producer enabled is not currently supported."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_combination_unsupported); } } while (0)



             ;

            ldmSeqStore.seq = zc->ldmSequences;
            ldmSeqStore.capacity = zc->maxNbLdmSequences;

            do { size_t const err_code = (ZSTD_ldm_generateSequences(&zc->ldmState, &ldmSeqStore, &zc->appliedParams.ldmParams, src, srcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)

                                                                 ;

            lastLLSize =
                ZSTD_ldm_blockCompress(&ldmSeqStore,
                                       ms, &zc->seqStore,
                                       zc->blockState.nextCBlock->rep,
                                       zc->appliedParams.useRowMatchFinder,
                                       src, srcSize);
            ((void)0);
        } else if (ZSTD_hasExtSeqProd(&zc->appliedParams)) {
            ((void)0)

             ;
            ((void)0);

            { U32 const windowSize = (U32)1 << zc->appliedParams.cParams.windowLog;

                size_t const nbExternalSeqs = (zc->appliedParams.extSeqProdFunc)(
                    zc->appliedParams.extSeqProdState,
                    zc->extSeqBuf,
                    zc->extSeqBufCapacity,
                    src, srcSize,
                    
# 3364 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                   ((void *)0)
# 3364 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                       , 0,
                    zc->appliedParams.compressionLevel,
                    windowSize
                );

                size_t const nbPostProcessedSeqs = ZSTD_postProcessSequenceProducerResult(
                    zc->extSeqBuf,
                    nbExternalSeqs,
                    zc->extSeqBufCapacity,
                    srcSize
                );


                if (!ERR_isError(nbPostProcessedSeqs)) {
                    ZSTD_SequencePosition seqPos = {0,0,0};
                    size_t const seqLenSum = ZSTD_fastSequenceLengthSum(zc->extSeqBuf, nbPostProcessedSeqs);
                    do { if (seqLenSum > srcSize) { do { } while (0); do { if (0) { _force_has_format_string("External sequences imply too large a block!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);
                    do { size_t const err_code = (ZSTD_transferSequences_wBlockDelim( zc, &seqPos, zc->extSeqBuf, nbPostProcessedSeqs, src, srcSize, zc->appliedParams.searchForExternalRepcodes )); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Failed to copy external sequences to seqStore!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)







                     ;
                    ms->ldmSeqStore = 
# 3390 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                     ((void *)0)
# 3390 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                         ;
                    do { } while (0);
                    return ZSTDbss_compress;
                }


                if (!zc->appliedParams.enableMatchFinderFallback) {
                    return nbPostProcessedSeqs;
                }


                { ZSTD_BlockCompressor_f const blockCompressor =
                        ZSTD_selectBlockCompressor(
                            zc->appliedParams.cParams.strategy,
                            zc->appliedParams.useRowMatchFinder,
                            dictMode);
                    ms->ldmSeqStore = 
# 3406 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                     ((void *)0)
# 3406 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                         ;
                    do { } while (0)



                     ;
                    lastLLSize = blockCompressor(ms, &zc->seqStore, zc->blockState.nextCBlock->rep, src, srcSize);
            } }
        } else {
            ZSTD_BlockCompressor_f const blockCompressor = ZSTD_selectBlockCompressor(
                    zc->appliedParams.cParams.strategy,
                    zc->appliedParams.useRowMatchFinder,
                    dictMode);
            ms->ldmSeqStore = 
# 3419 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                             ((void *)0)
# 3419 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                 ;
            lastLLSize = blockCompressor(ms, &zc->seqStore, zc->blockState.nextCBlock->rep, src, srcSize);
        }
        { const BYTE* const lastLiterals = (const BYTE*)src + srcSize - lastLLSize;
            ZSTD_storeLastLiterals(&zc->seqStore, lastLiterals, lastLLSize);
    } }
    ZSTD_validateSeqStore(&zc->seqStore, &zc->appliedParams.cParams);
    return ZSTDbss_compress;
}

static size_t ZSTD_copyBlockSequences(SeqCollector* seqCollector, const SeqStore_t* seqStore, const U32 prevRepcodes[3])
{
    const SeqDef* inSeqs = seqStore->sequencesStart;
    const size_t nbInSequences = (size_t)(seqStore->sequences - inSeqs);
    const size_t nbInLiterals = (size_t)(seqStore->lit - seqStore->litStart);

    ZSTD_Sequence* outSeqs = seqCollector->seqIndex == 0 ? seqCollector->seqStart : seqCollector->seqStart + seqCollector->seqIndex;
    const size_t nbOutSequences = nbInSequences + 1;
    size_t nbOutLiterals = 0;
    Repcodes_t repcodes;
    size_t i;




    ((void)0);
    do { if (nbOutSequences > (size_t)(seqCollector->maxSequences - seqCollector->seqIndex)) { do { } while (0); do { if (0) { _force_has_format_string("Not enough space to copy sequences"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)


                                             ;

    __builtin_memcpy((&repcodes),(prevRepcodes),(sizeof(repcodes)));
    for (i = 0; i < nbInSequences; ++i) {
        U32 rawOffset;
        outSeqs[i].litLength = inSeqs[i].litLength;
        outSeqs[i].matchLength = inSeqs[i].mlBase + 3;
        outSeqs[i].rep = 0;





        if (i == seqStore->longLengthPos) {
            if (seqStore->longLengthType == ZSTD_llt_literalLength) {
                outSeqs[i].litLength += 0x10000;
            } else if (seqStore->longLengthType == ZSTD_llt_matchLength) {
                outSeqs[i].matchLength += 0x10000;
            }
        }


        if (( 1 <= (inSeqs[i].offBase) && (inSeqs[i].offBase) <= 3)) {
            const U32 repcode = (((void)0), (inSeqs[i].offBase));
            ((void)0);
            outSeqs[i].rep = repcode;
            if (outSeqs[i].litLength != 0) {
                rawOffset = repcodes.rep[repcode - 1];
            } else {
                if (repcode == 3) {
                    ((void)0);
                    rawOffset = repcodes.rep[0] - 1;
                } else {
                    rawOffset = repcodes.rep[repcode];
                }
            }
        } else {
            rawOffset = (((void)0), (inSeqs[i].offBase) - 3);
        }
        outSeqs[i].offset = rawOffset;


        ZSTD_updateRep(repcodes.rep,
                       inSeqs[i].offBase,
                       inSeqs[i].litLength == 0);

        nbOutLiterals += outSeqs[i].litLength;
    }




    ((void)0);
    {
        const size_t lastLLSize = nbInLiterals - nbOutLiterals;
        outSeqs[nbInSequences].litLength = (U32)lastLLSize;
        outSeqs[nbInSequences].matchLength = 0;
        outSeqs[nbInSequences].offset = 0;
        ((void)0);
    }
    seqCollector->seqIndex += nbOutSequences;
    ((void)0);

    return 0;
}

size_t ZSTD_sequenceBound(size_t srcSize) {
    const size_t maxNbSeq = (srcSize / 3) + 1;
    const size_t maxNbDelims = (srcSize / (1 << 10)) + 1;
    return maxNbSeq + maxNbDelims;
}

size_t ZSTD_generateSequences(ZSTD_CCtx* zc, ZSTD_Sequence* outSeqs,
                              size_t outSeqsSize, const void* src, size_t srcSize)
{
    const size_t dstCapacity = ZSTD_compressBound(srcSize);
    void* dst;
    SeqCollector seqCollector;
    {
        int targetCBlockSize;
        do { size_t const err_code = (ZSTD_CCtx_getParameter(zc, ZSTD_c_targetCBlockSize, &targetCBlockSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        do { if (targetCBlockSize != 0) { do { } while (0); do { if (0) { _force_has_format_string("targetCBlockSize != 0"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0);
    }
    {
        int nbWorkers;
        do { size_t const err_code = (ZSTD_CCtx_getParameter(zc, ZSTD_c_nbWorkers, &nbWorkers)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        do { if (nbWorkers != 0) { do { } while (0); do { if (0) { _force_has_format_string("nbWorkers != 0"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } } while (0);
    }

    dst = ZSTD_customMalloc(dstCapacity, ZSTD_defaultCMem);
    do { if (dst == 
# 3538 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
   ((void *)0)
# 3538 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
   ) { do { } while (0); do { if (0) { _force_has_format_string("NULL pointer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);

    seqCollector.collectSequences = 1;
    seqCollector.seqStart = outSeqs;
    seqCollector.seqIndex = 0;
    seqCollector.maxSequences = outSeqsSize;
    zc->seqCollector = seqCollector;

    {
        const size_t ret = ZSTD_compress2(zc, dst, dstCapacity, src, srcSize);
        ZSTD_customFree(dst, ZSTD_defaultCMem);
        do { size_t const err_code = (ret); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compress2 failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    }
    ((void)0);
    return zc->seqCollector.seqIndex;
}

size_t ZSTD_mergeBlockDelimiters(ZSTD_Sequence* sequences, size_t seqsSize) {
    size_t in = 0;
    size_t out = 0;
    for (; in < seqsSize; ++in) {
        if (sequences[in].offset == 0 && sequences[in].matchLength == 0) {
            if (in != seqsSize - 1) {
                sequences[in+1].litLength += sequences[in].litLength;
            }
        } else {
            sequences[out] = sequences[in];
            ++out;
        }
    }
    return out;
}


static int ZSTD_isRLE(const BYTE* src, size_t length) {
    const BYTE* ip = src;
    const BYTE value = ip[0];
    const size_t valueST = (size_t)((U64)value * 0x0101010101010101ULL);
    const size_t unrollSize = sizeof(size_t) * 4;
    const size_t unrollMask = unrollSize - 1;
    const size_t prefixLength = length & unrollMask;
    size_t i;
    if (length == 1) return 1;

    if (prefixLength && ZSTD_count(ip+1, ip, ip+prefixLength) != prefixLength-1) {
        return 0;
    }
    for (i = prefixLength; i != length; i += unrollSize) {
        size_t u;
        for (u = 0; u < unrollSize; u += sizeof(size_t)) {
            if (MEM_readST(ip + i + u) != valueST) {
                return 0;
    } } }
    return 1;
}





static int ZSTD_maybeRLE(SeqStore_t const* seqStore)
{
    size_t const nbSeqs = (size_t)(seqStore->sequences - seqStore->sequencesStart);
    size_t const nbLits = (size_t)(seqStore->lit - seqStore->litStart);

    return nbSeqs < 4 && nbLits < 10;
}

static void
ZSTD_blockState_confirmRepcodesAndEntropyTables(ZSTD_blockState_t* const bs)
{
    ZSTD_compressedBlockState_t* const tmp = bs->prevCBlock;
    bs->prevCBlock = bs->nextCBlock;
    bs->nextCBlock = tmp;
}


static void
writeBlockHeader(void* op, size_t cSize, size_t blockSize, U32 lastBlock)
{
    U32 const cBlockHeader = cSize == 1 ?
                        lastBlock + (((U32)bt_rle)<<1) + (U32)(blockSize << 3) :
                        lastBlock + (((U32)bt_compressed)<<1) + (U32)(cSize << 3);
    MEM_writeLE24(op, cBlockHeader);
    do { } while (0);
}
# 3632 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static size_t
ZSTD_buildBlockEntropyStats_literals(void* const src, size_t srcSize,
                               const ZSTD_hufCTables_t* prevHuf,
                                     ZSTD_hufCTables_t* nextHuf,
                                     ZSTD_hufCTablesMetadata_t* hufMetadata,
                               const int literalsCompressionIsDisabled,
                                     void* workspace, size_t wkspSize,
                                     int hufFlags)
{
    BYTE* const wkspStart = (BYTE*)workspace;
    BYTE* const wkspEnd = wkspStart + wkspSize;
    BYTE* const countWkspStart = wkspStart;
    unsigned* const countWksp = (unsigned*)workspace;
    const size_t countWkspSize = (255 + 1) * sizeof(unsigned);
    BYTE* const nodeWksp = countWkspStart + countWkspSize;
    const size_t nodeWkspSize = (size_t)(wkspEnd - nodeWksp);
    unsigned maxSymbolValue = 255;
    unsigned huffLog = 11;
    HUF_repeat repeat = prevHuf->repeatMode;
    do { } while (0);


    __builtin_memcpy((nextHuf),(prevHuf),(sizeof(*prevHuf)));

    if (literalsCompressionIsDisabled) {
        do { } while (0);
        hufMetadata->hType = set_basic;
        return 0;
    }





    { size_t const minLitSize = (prevHuf->repeatMode == HUF_repeat_valid) ? 6 : 63;
        if (srcSize <= minLitSize) {
            do { } while (0);
            hufMetadata->hType = set_basic;
            return 0;
    } }


    { size_t const largest =
            HIST_count_wksp (countWksp, &maxSymbolValue,
                            (const BYTE*)src, srcSize,
                            workspace, wkspSize);
        do { size_t const err_code = (largest); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("HIST_count_wksp failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        if (largest == srcSize) {

            do { } while (0);
            hufMetadata->hType = set_rle;
            return 0;
        }
        if (largest <= (srcSize >> 7)+4) {

            do { } while (0);
            hufMetadata->hType = set_basic;
            return 0;
    } }


    if (repeat == HUF_repeat_check
      && !HUF_validateCTable((HUF_CElt const*)prevHuf->CTable, countWksp, maxSymbolValue)) {
        repeat = HUF_repeat_none;
    }


    __builtin_memset((nextHuf->CTable),(0),(sizeof(nextHuf->CTable)));
    huffLog = HUF_optimalTableLog(huffLog, srcSize, maxSymbolValue, nodeWksp, nodeWkspSize, nextHuf->CTable, countWksp, hufFlags);
    ((void)0);
    { size_t const maxBits = HUF_buildCTable_wksp((HUF_CElt*)nextHuf->CTable, countWksp,
                                                    maxSymbolValue, huffLog,
                                                    nodeWksp, nodeWkspSize);
        do { size_t const err_code = (maxBits); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("HUF_buildCTable_wksp"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        huffLog = (U32)maxBits;
    }
    {
        size_t const newCSize = HUF_estimateCompressedSize(
                (HUF_CElt*)nextHuf->CTable, countWksp, maxSymbolValue);
        size_t const hSize = HUF_writeCTable_wksp(
                hufMetadata->hufDesBuffer, sizeof(hufMetadata->hufDesBuffer),
                (HUF_CElt*)nextHuf->CTable, maxSymbolValue, huffLog,
                nodeWksp, nodeWkspSize);

        if (repeat != HUF_repeat_none) {
            size_t const oldCSize = HUF_estimateCompressedSize(
                    (HUF_CElt const*)prevHuf->CTable, countWksp, maxSymbolValue);
            if (oldCSize < srcSize && (oldCSize <= hSize + newCSize || hSize + 12 >= srcSize)) {
                do { } while (0);
                __builtin_memcpy((nextHuf),(prevHuf),(sizeof(*prevHuf)));
                hufMetadata->hType = set_repeat;
                return 0;
        } }
        if (newCSize + hSize >= srcSize) {
            do { } while (0);
            __builtin_memcpy((nextHuf),(prevHuf),(sizeof(*prevHuf)));
            hufMetadata->hType = set_basic;
            return 0;
        }
        do { } while (0);
        hufMetadata->hType = set_compressed;
        nextHuf->repeatMode = HUF_repeat_check;
        return hSize;
    }
}






static ZSTD_symbolEncodingTypeStats_t
ZSTD_buildDummySequencesStatistics(ZSTD_fseCTables_t* nextEntropy)
{
    ZSTD_symbolEncodingTypeStats_t stats = {set_basic, set_basic, set_basic, 0, 0, 0};
    nextEntropy->litlength_repeatMode = FSE_repeat_none;
    nextEntropy->offcode_repeatMode = FSE_repeat_none;
    nextEntropy->matchlength_repeatMode = FSE_repeat_none;
    return stats;
}






static size_t
ZSTD_buildBlockEntropyStats_sequences(
                const SeqStore_t* seqStorePtr,
                const ZSTD_fseCTables_t* prevEntropy,
                      ZSTD_fseCTables_t* nextEntropy,
                const ZSTD_CCtx_params* cctxParams,
                      ZSTD_fseCTablesMetadata_t* fseMetadata,
                      void* workspace, size_t wkspSize)
{
    ZSTD_strategy const strategy = cctxParams->cParams.strategy;
    size_t const nbSeq = (size_t)(seqStorePtr->sequences - seqStorePtr->sequencesStart);
    BYTE* const ostart = fseMetadata->fseTablesBuffer;
    BYTE* const oend = ostart + sizeof(fseMetadata->fseTablesBuffer);
    BYTE* op = ostart;
    unsigned* countWorkspace = (unsigned*)workspace;
    unsigned* entropyWorkspace = countWorkspace + (((35)>(52) ? (35) : (52)) + 1);
    size_t entropyWorkspaceSize = wkspSize - (((35)>(52) ? (35) : (52)) + 1) * sizeof(*countWorkspace);
    ZSTD_symbolEncodingTypeStats_t stats;

    do { } while (0);
    stats = nbSeq != 0 ? ZSTD_buildSequencesStatistics(seqStorePtr, nbSeq,
                                          prevEntropy, nextEntropy, op, oend,
                                          strategy, countWorkspace,
                                          entropyWorkspace, entropyWorkspaceSize)
                       : ZSTD_buildDummySequencesStatistics(nextEntropy);
    do { size_t const err_code = (stats.size); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildSequencesStatistics failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    fseMetadata->llType = (SymbolEncodingType_e) stats.LLtype;
    fseMetadata->ofType = (SymbolEncodingType_e) stats.Offtype;
    fseMetadata->mlType = (SymbolEncodingType_e) stats.MLtype;
    fseMetadata->lastCountSize = stats.lastCountSize;
    return stats.size;
}
# 3798 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
size_t ZSTD_buildBlockEntropyStats(
            const SeqStore_t* seqStorePtr,
            const ZSTD_entropyCTables_t* prevEntropy,
                  ZSTD_entropyCTables_t* nextEntropy,
            const ZSTD_CCtx_params* cctxParams,
                  ZSTD_entropyCTablesMetadata_t* entropyMetadata,
                  void* workspace, size_t wkspSize)
{
    size_t const litSize = (size_t)(seqStorePtr->lit - seqStorePtr->litStart);
    int const huf_useOptDepth = (cctxParams->cParams.strategy >= ZSTD_btultra);
    int const hufFlags = huf_useOptDepth ? HUF_flags_optimalDepth : 0;

    entropyMetadata->hufMetadata.hufDesSize =
        ZSTD_buildBlockEntropyStats_literals(seqStorePtr->litStart, litSize,
                                            &prevEntropy->huf, &nextEntropy->huf,
                                            &entropyMetadata->hufMetadata,
                                            ZSTD_literalsCompressionIsDisabled(cctxParams),
                                            workspace, wkspSize, hufFlags);

    do { size_t const err_code = (entropyMetadata->hufMetadata.hufDesSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildBlockEntropyStats_literals failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    entropyMetadata->fseMetadata.fseTablesSize =
        ZSTD_buildBlockEntropyStats_sequences(seqStorePtr,
                                              &prevEntropy->fse, &nextEntropy->fse,
                                              cctxParams,
                                              &entropyMetadata->fseMetadata,
                                              workspace, wkspSize);
    do { size_t const err_code = (entropyMetadata->fseMetadata.fseTablesSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildBlockEntropyStats_sequences failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}


static size_t
ZSTD_estimateBlockSize_literal(const BYTE* literals, size_t litSize,
                               const ZSTD_hufCTables_t* huf,
                               const ZSTD_hufCTablesMetadata_t* hufMetadata,
                               void* workspace, size_t wkspSize,
                               int writeEntropy)
{
    unsigned* const countWksp = (unsigned*)workspace;
    unsigned maxSymbolValue = 255;
    size_t literalSectionHeaderSize = 3 + (litSize >= 1 *(1 <<10)) + (litSize >= 16 *(1 <<10));
    U32 singleStream = litSize < 256;

    if (hufMetadata->hType == set_basic) return litSize;
    else if (hufMetadata->hType == set_rle) return 1;
    else if (hufMetadata->hType == set_compressed || hufMetadata->hType == set_repeat) {
        size_t const largest = HIST_count_wksp (countWksp, &maxSymbolValue, (const BYTE*)literals, litSize, workspace, wkspSize);
        if (ERR_isError(largest)) return litSize;
        { size_t cLitSizeEstimate = HUF_estimateCompressedSize((const HUF_CElt*)huf->CTable, countWksp, maxSymbolValue);
            if (writeEntropy) cLitSizeEstimate += hufMetadata->hufDesSize;
            if (!singleStream) cLitSizeEstimate += 6;
            return cLitSizeEstimate + literalSectionHeaderSize;
    } }
    ((void)0);
    return 0;
}


static size_t
ZSTD_estimateBlockSize_symbolType(SymbolEncodingType_e type,
                    const BYTE* codeTable, size_t nbSeq, unsigned maxCode,
                    const FSE_CTable* fseCTable,
                    const U8* additionalBits,
                    short const* defaultNorm, U32 defaultNormLog, U32 defaultMax,
                    void* workspace, size_t wkspSize)
{
    unsigned* const countWksp = (unsigned*)workspace;
    const BYTE* ctp = codeTable;
    const BYTE* const ctStart = ctp;
    const BYTE* const ctEnd = ctStart + nbSeq;
    size_t cSymbolTypeSizeEstimateInBits = 0;
    unsigned max = maxCode;

    HIST_countFast_wksp(countWksp, &max, codeTable, nbSeq, workspace, wkspSize);
    if (type == set_basic) {

        ((void)0);
        (void)defaultMax;
        cSymbolTypeSizeEstimateInBits = ZSTD_crossEntropyCost(defaultNorm, defaultNormLog, countWksp, max);
    } else if (type == set_rle) {
        cSymbolTypeSizeEstimateInBits = 0;
    } else if (type == set_compressed || type == set_repeat) {
        cSymbolTypeSizeEstimateInBits = ZSTD_fseBitCost(fseCTable, countWksp, max);
    }
    if (ERR_isError(cSymbolTypeSizeEstimateInBits)) {
        return nbSeq * 10;
    }
    while (ctp < ctEnd) {
        if (additionalBits) cSymbolTypeSizeEstimateInBits += additionalBits[*ctp];
        else cSymbolTypeSizeEstimateInBits += *ctp;
        ctp++;
    }
    return cSymbolTypeSizeEstimateInBits >> 3;
}


static size_t
ZSTD_estimateBlockSize_sequences(const BYTE* ofCodeTable,
                                 const BYTE* llCodeTable,
                                 const BYTE* mlCodeTable,
                                 size_t nbSeq,
                                 const ZSTD_fseCTables_t* fseTables,
                                 const ZSTD_fseCTablesMetadata_t* fseMetadata,
                                 void* workspace, size_t wkspSize,
                                 int writeEntropy)
{
    size_t sequencesSectionHeaderSize = 1 + 1 + (nbSeq >= 128) + (nbSeq >= 0x7F00);
    size_t cSeqSizeEstimate = 0;
    cSeqSizeEstimate += ZSTD_estimateBlockSize_symbolType(fseMetadata->ofType, ofCodeTable, nbSeq, 31,
                                    fseTables->offcodeCTable, 
# 3907 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                             ((void *)0)
# 3907 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                 ,
                                    OF_defaultNorm, OF_defaultNormLog, 28,
                                    workspace, wkspSize);
    cSeqSizeEstimate += ZSTD_estimateBlockSize_symbolType(fseMetadata->llType, llCodeTable, nbSeq, 35,
                                    fseTables->litlengthCTable, LL_bits,
                                    LL_defaultNorm, LL_defaultNormLog, 35,
                                    workspace, wkspSize);
    cSeqSizeEstimate += ZSTD_estimateBlockSize_symbolType(fseMetadata->mlType, mlCodeTable, nbSeq, 52,
                                    fseTables->matchlengthCTable, ML_bits,
                                    ML_defaultNorm, ML_defaultNormLog, 52,
                                    workspace, wkspSize);
    if (writeEntropy) cSeqSizeEstimate += fseMetadata->fseTablesSize;
    return cSeqSizeEstimate + sequencesSectionHeaderSize;
}


static size_t
ZSTD_estimateBlockSize(const BYTE* literals, size_t litSize,
                       const BYTE* ofCodeTable,
                       const BYTE* llCodeTable,
                       const BYTE* mlCodeTable,
                       size_t nbSeq,
                       const ZSTD_entropyCTables_t* entropy,
                       const ZSTD_entropyCTablesMetadata_t* entropyMetadata,
                       void* workspace, size_t wkspSize,
                       int writeLitEntropy, int writeSeqEntropy)
{
    size_t const literalsSize = ZSTD_estimateBlockSize_literal(literals, litSize,
                                    &entropy->huf, &entropyMetadata->hufMetadata,
                                    workspace, wkspSize, writeLitEntropy);
    size_t const seqSize = ZSTD_estimateBlockSize_sequences(ofCodeTable, llCodeTable, mlCodeTable,
                                    nbSeq, &entropy->fse, &entropyMetadata->fseMetadata,
                                    workspace, wkspSize, writeSeqEntropy);
    return seqSize + literalsSize + ZSTD_blockHeaderSize;
}





static size_t
ZSTD_buildEntropyStatisticsAndEstimateSubBlockSize(SeqStore_t* seqStore, ZSTD_CCtx* zc)
{
    ZSTD_entropyCTablesMetadata_t* const entropyMetadata = &zc->blockSplitCtx.entropyMetadata;
    do { } while (0);
    do { size_t const err_code = (ZSTD_buildBlockEntropyStats(seqStore, &zc->blockState.prevCBlock->entropy, &zc->blockState.nextCBlock->entropy, &zc->appliedParams, entropyMetadata, zc->tmpWorkspace, zc->tmpWkspSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)




                                                           ;
    return ZSTD_estimateBlockSize(
                    seqStore->litStart, (size_t)(seqStore->lit - seqStore->litStart),
                    seqStore->ofCode, seqStore->llCode, seqStore->mlCode,
                    (size_t)(seqStore->sequences - seqStore->sequencesStart),
                    &zc->blockState.nextCBlock->entropy,
                    entropyMetadata,
                    zc->tmpWorkspace, zc->tmpWkspSize,
                    (int)(entropyMetadata->hufMetadata.hType == set_compressed), 1);
}


static size_t ZSTD_countSeqStoreLiteralsBytes(const SeqStore_t* const seqStore)
{
    size_t literalsBytes = 0;
    size_t const nbSeqs = (size_t)(seqStore->sequences - seqStore->sequencesStart);
    size_t i;
    for (i = 0; i < nbSeqs; ++i) {
        SeqDef const seq = seqStore->sequencesStart[i];
        literalsBytes += seq.litLength;
        if (i == seqStore->longLengthPos && seqStore->longLengthType == ZSTD_llt_literalLength) {
            literalsBytes += 0x10000;
    } }
    return literalsBytes;
}


static size_t ZSTD_countSeqStoreMatchBytes(const SeqStore_t* const seqStore)
{
    size_t matchBytes = 0;
    size_t const nbSeqs = (size_t)(seqStore->sequences - seqStore->sequencesStart);
    size_t i;
    for (i = 0; i < nbSeqs; ++i) {
        SeqDef seq = seqStore->sequencesStart[i];
        matchBytes += seq.mlBase + 3;
        if (i == seqStore->longLengthPos && seqStore->longLengthType == ZSTD_llt_matchLength) {
            matchBytes += 0x10000;
    } }
    return matchBytes;
}




static void ZSTD_deriveSeqStoreChunk(SeqStore_t* resultSeqStore,
                               const SeqStore_t* originalSeqStore,
                                     size_t startIdx, size_t endIdx)
{
    *resultSeqStore = *originalSeqStore;
    if (startIdx > 0) {
        resultSeqStore->sequences = originalSeqStore->sequencesStart + startIdx;
        resultSeqStore->litStart += ZSTD_countSeqStoreLiteralsBytes(resultSeqStore);
    }


    if (originalSeqStore->longLengthType != ZSTD_llt_none) {
        if (originalSeqStore->longLengthPos < startIdx || originalSeqStore->longLengthPos > endIdx) {
            resultSeqStore->longLengthType = ZSTD_llt_none;
        } else {
            resultSeqStore->longLengthPos -= (U32)startIdx;
        }
    }
    resultSeqStore->sequencesStart = originalSeqStore->sequencesStart + startIdx;
    resultSeqStore->sequences = originalSeqStore->sequencesStart + endIdx;
    if (endIdx == (size_t)(originalSeqStore->sequences - originalSeqStore->sequencesStart)) {

        ((void)0);
    } else {
        size_t const literalsBytes = ZSTD_countSeqStoreLiteralsBytes(resultSeqStore);
        resultSeqStore->lit = resultSeqStore->litStart + literalsBytes;
    }
    resultSeqStore->llCode += startIdx;
    resultSeqStore->mlCode += startIdx;
    resultSeqStore->ofCode += startIdx;
}





static U32
ZSTD_resolveRepcodeToRawOffset(const U32 rep[3], const U32 offBase, const U32 ll0)
{
    U32 const adjustedRepCode = (((void)0), (offBase)) - 1 + ll0;
    ((void)0);
    if (adjustedRepCode == 3) {
        ((void)0);







        return rep[0] - 1;
    }
    return rep[adjustedRepCode];
}
# 4069 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static void
ZSTD_seqStore_resolveOffCodes(Repcodes_t* const dRepcodes, Repcodes_t* const cRepcodes,
                        const SeqStore_t* const seqStore, U32 const nbSeq)
{
    U32 idx = 0;
    U32 const longLitLenIdx = seqStore->longLengthType == ZSTD_llt_literalLength ? seqStore->longLengthPos : nbSeq;
    for (; idx < nbSeq; ++idx) {
        SeqDef* const seq = seqStore->sequencesStart + idx;
        U32 const ll0 = (seq->litLength == 0) && (idx != longLitLenIdx);
        U32 const offBase = seq->offBase;
        ((void)0);
        if (( 1 <= (offBase) && (offBase) <= 3)) {
            U32 const dRawOffset = ZSTD_resolveRepcodeToRawOffset(dRepcodes->rep, offBase, ll0);
            U32 const cRawOffset = ZSTD_resolveRepcodeToRawOffset(cRepcodes->rep, offBase, ll0);




            if (dRawOffset != cRawOffset) {
                seq->offBase = (((void)0), cRawOffset + 3);
            }
        }



        ZSTD_updateRep(dRepcodes->rep, seq->offBase, ll0);
        ZSTD_updateRep(cRepcodes->rep, offBase, ll0);
    }
}






static size_t
ZSTD_compressSeqStore_singleBlock(ZSTD_CCtx* zc,
                            const SeqStore_t* const seqStore,
                                  Repcodes_t* const dRep, Repcodes_t* const cRep,
                                  void* dst, size_t dstCapacity,
                            const void* src, size_t srcSize,
                                  U32 lastBlock, U32 isPartition)
{
    const U32 rleMaxLength = 25;
    BYTE* op = (BYTE*)dst;
    const BYTE* ip = (const BYTE*)src;
    size_t cSize;
    size_t cSeqsSize;


    Repcodes_t const dRepOriginal = *dRep;
    do { } while (0);
    if (isPartition)
        ZSTD_seqStore_resolveOffCodes(dRep, cRep, seqStore, (U32)(seqStore->sequences - seqStore->sequencesStart));

    do { if (dstCapacity < ZSTD_blockHeaderSize) { do { } while (0); do { if (0) { _force_has_format_string("Block header doesn't fit"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
    cSeqsSize = ZSTD_entropyCompressSeqStore(seqStore,
                &zc->blockState.prevCBlock->entropy, &zc->blockState.nextCBlock->entropy,
                &zc->appliedParams,
                op + ZSTD_blockHeaderSize, dstCapacity - ZSTD_blockHeaderSize,
                srcSize,
                zc->tmpWorkspace, zc->tmpWkspSize ,
                zc->bmi2);
    do { size_t const err_code = (cSeqsSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_entropyCompressSeqStore failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

    if (!zc->isFirstBlock &&
        cSeqsSize < rleMaxLength &&
        ZSTD_isRLE((BYTE const*)src, srcSize)) {




        cSeqsSize = 1;
    }


    if (zc->seqCollector.collectSequences) {
        do { size_t const err_code = (ZSTD_copyBlockSequences(&zc->seqCollector, seqStore, dRepOriginal.rep)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("copyBlockSequences failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ZSTD_blockState_confirmRepcodesAndEntropyTables(&zc->blockState);
        return 0;
    }

    if (cSeqsSize == 0) {
        cSize = ZSTD_noCompressBlock(op, dstCapacity, ip, srcSize, lastBlock);
        do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Nocompress block failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        do { } while (0);
        *dRep = dRepOriginal;
    } else if (cSeqsSize == 1) {
        cSize = ZSTD_rleCompressBlock(op, dstCapacity, *ip, srcSize, lastBlock);
        do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("RLE compress block failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        do { } while (0);
        *dRep = dRepOriginal;
    } else {
        ZSTD_blockState_confirmRepcodesAndEntropyTables(&zc->blockState);
        writeBlockHeader(op, cSeqsSize, srcSize, lastBlock);
        cSize = ZSTD_blockHeaderSize + cSeqsSize;
        do { } while (0);
    }

    if (zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode == FSE_repeat_valid)
        zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode = FSE_repeat_check;

    return cSize;
}


typedef struct {
    U32* splitLocations;
    size_t idx;
} seqStoreSplits;
# 4196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static void
ZSTD_deriveBlockSplitsHelper(seqStoreSplits* splits, size_t startIdx, size_t endIdx,
                             ZSTD_CCtx* zc, const SeqStore_t* origSeqStore)
{
    SeqStore_t* const fullSeqStoreChunk = &zc->blockSplitCtx.fullSeqStoreChunk;
    SeqStore_t* const firstHalfSeqStore = &zc->blockSplitCtx.firstHalfSeqStore;
    SeqStore_t* const secondHalfSeqStore = &zc->blockSplitCtx.secondHalfSeqStore;
    size_t estimatedOriginalSize;
    size_t estimatedFirstHalfSize;
    size_t estimatedSecondHalfSize;
    size_t midIdx = (startIdx + endIdx)/2;

    do { } while (0);
    ((void)0);
    if (endIdx - startIdx < 300 || splits->idx >= 196) {
        do { } while (0);
        return;
    }
    ZSTD_deriveSeqStoreChunk(fullSeqStoreChunk, origSeqStore, startIdx, endIdx);
    ZSTD_deriveSeqStoreChunk(firstHalfSeqStore, origSeqStore, startIdx, midIdx);
    ZSTD_deriveSeqStoreChunk(secondHalfSeqStore, origSeqStore, midIdx, endIdx);
    estimatedOriginalSize = ZSTD_buildEntropyStatisticsAndEstimateSubBlockSize(fullSeqStoreChunk, zc);
    estimatedFirstHalfSize = ZSTD_buildEntropyStatisticsAndEstimateSubBlockSize(firstHalfSeqStore, zc);
    estimatedSecondHalfSize = ZSTD_buildEntropyStatisticsAndEstimateSubBlockSize(secondHalfSeqStore, zc);
    do { } while (0)
                                                                                    ;
    if (ERR_isError(estimatedOriginalSize) || ERR_isError(estimatedFirstHalfSize) || ERR_isError(estimatedSecondHalfSize)) {
        return;
    }
    if (estimatedFirstHalfSize + estimatedSecondHalfSize < estimatedOriginalSize) {
        do { } while (0);
        ZSTD_deriveBlockSplitsHelper(splits, startIdx, midIdx, zc, origSeqStore);
        splits->splitLocations[splits->idx] = (U32)midIdx;
        splits->idx++;
        ZSTD_deriveBlockSplitsHelper(splits, midIdx, endIdx, zc, origSeqStore);
    }
}






static size_t ZSTD_deriveBlockSplits(ZSTD_CCtx* zc, U32 partitions[], U32 nbSeq)
{
    seqStoreSplits splits;
    splits.splitLocations = partitions;
    splits.idx = 0;
    if (nbSeq <= 4) {
        do { } while (0);

        return 0;
    }
    ZSTD_deriveBlockSplitsHelper(&splits, 0, nbSeq, zc, &zc->seqStore);
    splits.splitLocations[splits.idx] = nbSeq;
    do { } while (0);
    return splits.idx;
}






static size_t
ZSTD_compressBlock_splitBlock_internal(ZSTD_CCtx* zc,
                                    void* dst, size_t dstCapacity,
                              const void* src, size_t blockSize,
                                    U32 lastBlock, U32 nbSeq)
{
    size_t cSize = 0;
    const BYTE* ip = (const BYTE*)src;
    BYTE* op = (BYTE*)dst;
    size_t i = 0;
    size_t srcBytesTotal = 0;
    U32* const partitions = zc->blockSplitCtx.partitions;
    SeqStore_t* const nextSeqStore = &zc->blockSplitCtx.nextSeqStore;
    SeqStore_t* const currSeqStore = &zc->blockSplitCtx.currSeqStore;
    size_t const numSplits = ZSTD_deriveBlockSplits(zc, partitions, nbSeq);
# 4290 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    Repcodes_t dRep;
    Repcodes_t cRep;
    __builtin_memcpy((dRep.rep),(zc->blockState.prevCBlock->rep),(sizeof(Repcodes_t)));
    __builtin_memcpy((cRep.rep),(zc->blockState.prevCBlock->rep),(sizeof(Repcodes_t)));
    __builtin_memset((nextSeqStore),(0),(sizeof(SeqStore_t)));

    do { } while (0)

                                                                 ;

    if (numSplits == 0) {
        size_t cSizeSingleBlock =
            ZSTD_compressSeqStore_singleBlock(zc, &zc->seqStore,
                                            &dRep, &cRep,
                                            op, dstCapacity,
                                            ip, blockSize,
                                            lastBlock, 0 );
        do { size_t const err_code = (cSizeSingleBlock); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Compressing single block from splitBlock_internal() failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        do { } while (0);
        ((void)0);
        ((void)0);
        return cSizeSingleBlock;
    }

    ZSTD_deriveSeqStoreChunk(currSeqStore, &zc->seqStore, 0, partitions[0]);
    for (i = 0; i <= numSplits; ++i) {
        size_t cSizeChunk;
        U32 const lastPartition = (i == numSplits);
        U32 lastBlockEntireSrc = 0;

        size_t srcBytes = ZSTD_countSeqStoreLiteralsBytes(currSeqStore) + ZSTD_countSeqStoreMatchBytes(currSeqStore);
        srcBytesTotal += srcBytes;
        if (lastPartition) {

            srcBytes += blockSize - srcBytesTotal;
            lastBlockEntireSrc = lastBlock;
        } else {
            ZSTD_deriveSeqStoreChunk(nextSeqStore, &zc->seqStore, partitions[i], partitions[i+1]);
        }

        cSizeChunk = ZSTD_compressSeqStore_singleBlock(zc, currSeqStore,
                                                      &dRep, &cRep,
                                                       op, dstCapacity,
                                                       ip, srcBytes,
                                                       lastBlockEntireSrc, 1 );
        do { } while (0)
                                                                                                     ;
        do { size_t const err_code = (cSizeChunk); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Compressing chunk failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

        ip += srcBytes;
        op += cSizeChunk;
        dstCapacity -= cSizeChunk;
        cSize += cSizeChunk;
        *currSeqStore = *nextSeqStore;
        ((void)0);
    }



    __builtin_memcpy((zc->blockState.prevCBlock->rep),(dRep.rep),(sizeof(Repcodes_t)));
    return cSize;
}

static size_t
ZSTD_compressBlock_splitBlock(ZSTD_CCtx* zc,
                              void* dst, size_t dstCapacity,
                              const void* src, size_t srcSize, U32 lastBlock)
{
    U32 nbSeq;
    size_t cSize;
    do { } while (0);
    ((void)0);

    { const size_t bss = ZSTD_buildSeqStore(zc, src, srcSize);
        do { size_t const err_code = (bss); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildSeqStore failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        if (bss == ZSTDbss_noCompress) {
            if (zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode == FSE_repeat_valid)
                zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode = FSE_repeat_check;
            do { if (zc->seqCollector.collectSequences) { do { } while (0); do { if (0) { _force_has_format_string("Uncompressible block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_sequenceProducer_failed); } } while (0);
            cSize = ZSTD_noCompressBlock(dst, dstCapacity, src, srcSize, lastBlock);
            do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_noCompressBlock failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
            do { } while (0);
            return cSize;
        }
        nbSeq = (U32)(zc->seqStore.sequences - zc->seqStore.sequencesStart);
    }

    cSize = ZSTD_compressBlock_splitBlock_internal(zc, dst, dstCapacity, src, srcSize, lastBlock, nbSeq);
    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Splitting blocks failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return cSize;
}

static size_t
ZSTD_compressBlock_internal(ZSTD_CCtx* zc,
                            void* dst, size_t dstCapacity,
                            const void* src, size_t srcSize, U32 frame)
{




    const U32 rleMaxLength = 25;
    size_t cSize;
    const BYTE* ip = (const BYTE*)src;
    BYTE* op = (BYTE*)dst;
    do { } while (0)

                                                                 ;

    { const size_t bss = ZSTD_buildSeqStore(zc, src, srcSize);
        do { size_t const err_code = (bss); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildSeqStore failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        if (bss == ZSTDbss_noCompress) {
            do { if (zc->seqCollector.collectSequences) { do { } while (0); do { if (0) { _force_has_format_string("Uncompressible block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_sequenceProducer_failed); } } while (0);
            cSize = 0;
            goto out;
        }
    }

    if (zc->seqCollector.collectSequences) {
        do { size_t const err_code = (ZSTD_copyBlockSequences(&zc->seqCollector, ZSTD_getSeqStore(zc), zc->blockState.prevCBlock->rep)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("copyBlockSequences failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ZSTD_blockState_confirmRepcodesAndEntropyTables(&zc->blockState);
        return 0;
    }


    cSize = ZSTD_entropyCompressSeqStore(&zc->seqStore,
            &zc->blockState.prevCBlock->entropy, &zc->blockState.nextCBlock->entropy,
            &zc->appliedParams,
            dst, dstCapacity,
            srcSize,
            zc->tmpWorkspace, zc->tmpWkspSize ,
            zc->bmi2);

    if (frame &&




        !zc->isFirstBlock &&
        cSize < rleMaxLength &&
        ZSTD_isRLE(ip, srcSize))
    {
        cSize = 1;
        op[0] = ip[0];
    }

out:
    if (!ERR_isError(cSize) && cSize > 1) {
        ZSTD_blockState_confirmRepcodesAndEntropyTables(&zc->blockState);
    }




    if (zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode == FSE_repeat_valid)
        zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode = FSE_repeat_check;

    return cSize;
}

static size_t ZSTD_compressBlock_targetCBlockSize_body(ZSTD_CCtx* zc,
                               void* dst, size_t dstCapacity,
                               const void* src, size_t srcSize,
                               const size_t bss, U32 lastBlock)
{
    do { } while (0);
    if (bss == ZSTDbss_compress) {
        if (



            !zc->isFirstBlock &&
            ZSTD_maybeRLE(&zc->seqStore) &&
            ZSTD_isRLE((BYTE const*)src, srcSize))
        {
            return ZSTD_rleCompressBlock(dst, dstCapacity, *(BYTE const*)src, srcSize, lastBlock);
        }
# 4485 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
        { size_t const cSize =
                ZSTD_compressSuperBlock(zc, dst, dstCapacity, src, srcSize, lastBlock);
            if (cSize != ((size_t)-ZSTD_error_dstSize_tooSmall)) {
                size_t const maxCSize =
                    srcSize - ZSTD_minGain(srcSize, zc->appliedParams.cParams.strategy);
                do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressSuperBlock failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                if (cSize != 0 && cSize < maxCSize + ZSTD_blockHeaderSize) {
                    ZSTD_blockState_confirmRepcodesAndEntropyTables(&zc->blockState);
                    return cSize;
                }
            }
        }
    }

    do { } while (0);



    return ZSTD_noCompressBlock(dst, dstCapacity, src, srcSize, lastBlock);
}

static size_t ZSTD_compressBlock_targetCBlockSize(ZSTD_CCtx* zc,
                               void* dst, size_t dstCapacity,
                               const void* src, size_t srcSize,
                               U32 lastBlock)
{
    size_t cSize = 0;
    const size_t bss = ZSTD_buildSeqStore(zc, src, srcSize);
    do { } while (0)
                                                                                                                                                       ;
    do { size_t const err_code = (bss); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_buildSeqStore failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

    cSize = ZSTD_compressBlock_targetCBlockSize_body(zc, dst, dstCapacity, src, srcSize, bss, lastBlock);
    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressBlock_targetCBlockSize_body failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

    if (zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode == FSE_repeat_valid)
        zc->blockState.prevCBlock->entropy.fse.offcode_repeatMode = FSE_repeat_check;

    return cSize;
}

static void ZSTD_overflowCorrectIfNeeded(ZSTD_MatchState_t* ms,
                                         ZSTD_cwksp* ws,
                                         ZSTD_CCtx_params const* params,
                                         void const* ip,
                                         void const* iend)
{
    U32 const cycleLog = ZSTD_cycleLog(params->cParams.chainLog, params->cParams.strategy);
    U32 const maxDist = (U32)1 << params->cParams.windowLog;
    if (ZSTD_window_needOverflowCorrection(ms->window, cycleLog, maxDist, ms->loadedDictEnd, ip, iend)) {
        U32 const correction = ZSTD_window_correctOverflow(&ms->window, cycleLog, maxDist, ip);
        (void)sizeof(char[(((int)(sizeof(size_t) == 4 ? 29 : 30)) <= 30) ? 1 : -1]);
        (void)sizeof(char[(30 <= 30) ? 1 : -1]);
        (void)sizeof(char[(((int)(sizeof(size_t) == 4 ? 30 : 31)) <= 31) ? 1 : -1]);
        ZSTD_cwksp_mark_tables_dirty(ws);
        ZSTD_reduceIndex(ms, params, correction);
        ZSTD_cwksp_mark_tables_clean(ws);
        if (ms->nextToUpdate < correction) ms->nextToUpdate = 0;
        else ms->nextToUpdate -= correction;

        ms->loadedDictEnd = 0;
        ms->dictMatchState = 
# 4546 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                            ((void *)0)
# 4546 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                ;
    }
}



static size_t ZSTD_optimalBlockSize(ZSTD_CCtx* cctx, const void* src, size_t srcSize, size_t blockSizeMax, int splitLevel, ZSTD_strategy strat, S64 savings)
{

    static const int splitLevels[] = { 0, 0, 1, 2, 2, 3, 3, 4, 4, 4 };




    if (srcSize < 128 *(1 <<10) || blockSizeMax < 128 *(1 <<10))
        return ((srcSize)<(blockSizeMax) ? (srcSize) : (blockSizeMax));




    if (savings < 3) {
        do { } while (0);
        return 128 *(1 <<10);
    }



    if (splitLevel == 1) return 128 *(1 <<10);
    if (splitLevel == 0) {
        ((void)0);
        splitLevel = splitLevels[strat];
    } else {
        ((void)0);
        splitLevel -= 2;
    }
    return ZSTD_splitBlock(src, blockSizeMax, splitLevel, cctx->tmpWorkspace, cctx->tmpWkspSize);
}
# 4591 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static size_t ZSTD_compress_frameChunk(ZSTD_CCtx* cctx,
                                     void* dst, size_t dstCapacity,
                               const void* src, size_t srcSize,
                                     U32 lastFrameChunk)
{
    size_t blockSizeMax = cctx->blockSizeMax;
    size_t remaining = srcSize;
    const BYTE* ip = (const BYTE*)src;
    BYTE* const ostart = (BYTE*)dst;
    BYTE* op = ostart;
    U32 const maxDist = (U32)1 << cctx->appliedParams.cParams.windowLog;
    S64 savings = (S64)cctx->consumedSrcSize - (S64)cctx->producedCSize;

    ((void)0);

    do { } while (0);
    if (cctx->appliedParams.fParams.checksumFlag && srcSize)
        ZSTD_XXH64_update(&cctx->xxhState, src, srcSize);

    while (remaining) {
        ZSTD_MatchState_t* const ms = &cctx->blockState.matchState;
        size_t const blockSize = ZSTD_optimalBlockSize(cctx,
                                ip, remaining,
                                blockSizeMax,
                                cctx->appliedParams.preBlockSplitter_level,
                                cctx->appliedParams.cParams.strategy,
                                savings);
        U32 const lastBlock = lastFrameChunk & (blockSize == remaining);
        ((void)0);



        do { if (dstCapacity < ZSTD_blockHeaderSize + (1 + 1 ) + 1) { do { } while (0); do { if (0) { _force_has_format_string("not enough space to store compressed block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)

                                                                     ;

        ZSTD_overflowCorrectIfNeeded(
            ms, &cctx->workspace, &cctx->appliedParams, ip, ip + blockSize);
        ZSTD_checkDictValidity(&ms->window, ip + blockSize, maxDist, &ms->loadedDictEnd, &ms->dictMatchState);
        ZSTD_window_enforceMaxDist(&ms->window, ip, maxDist, &ms->loadedDictEnd, &ms->dictMatchState);


        if (ms->nextToUpdate < ms->window.lowLimit) ms->nextToUpdate = ms->window.lowLimit;

        { size_t cSize;
            if (ZSTD_useTargetCBlockSize(&cctx->appliedParams)) {
                cSize = ZSTD_compressBlock_targetCBlockSize(cctx, op, dstCapacity, ip, blockSize, lastBlock);
                do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressBlock_targetCBlockSize failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                ((void)0);
                ((void)0);
            } else if (ZSTD_blockSplitterEnabled(&cctx->appliedParams)) {
                cSize = ZSTD_compressBlock_splitBlock(cctx, op, dstCapacity, ip, blockSize, lastBlock);
                do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressBlock_splitBlock failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                ((void)0);
            } else {
                cSize = ZSTD_compressBlock_internal(cctx,
                                        op+ZSTD_blockHeaderSize, dstCapacity-ZSTD_blockHeaderSize,
                                        ip, blockSize, 1 );
                do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressBlock_internal failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

                if (cSize == 0) {
                    cSize = ZSTD_noCompressBlock(op, dstCapacity, ip, blockSize, lastBlock);
                    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_noCompressBlock failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                } else {
                    U32 const cBlockHeader = cSize == 1 ?
                        lastBlock + (((U32)bt_rle)<<1) + (U32)(blockSize << 3) :
                        lastBlock + (((U32)bt_compressed)<<1) + (U32)(cSize << 3);
                    MEM_writeLE24(op, cBlockHeader);
                    cSize += ZSTD_blockHeaderSize;
                }
            }
# 4677 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
            savings += (S64)blockSize - (S64)cSize;

            ip += blockSize;
            ((void)0);
            remaining -= blockSize;
            op += cSize;
            ((void)0);
            dstCapacity -= cSize;
            cctx->isFirstBlock = 0;
            do { } while (0)
                                        ;
    } }

    if (lastFrameChunk && (op>ostart)) cctx->stage = ZSTDcs_ending;
    return (size_t)(op-ostart);
}


static size_t ZSTD_writeFrameHeader(void* dst, size_t dstCapacity,
                                    const ZSTD_CCtx_params* params,
                                    U64 pledgedSrcSize, U32 dictID)
{
    BYTE* const op = (BYTE*)dst;
    U32 const dictIDSizeCodeLength = (dictID>0) + (dictID>=256) + (dictID>=65536);
    U32 const dictIDSizeCode = params->fParams.noDictIDFlag ? 0 : dictIDSizeCodeLength;
    U32 const checksumFlag = params->fParams.checksumFlag>0;
    U32 const windowSize = (U32)1 << params->cParams.windowLog;
    U32 const singleSegment = params->fParams.contentSizeFlag && (windowSize >= pledgedSrcSize);
    BYTE const windowLogByte = (BYTE)((params->cParams.windowLog - 10) << 3);
    U32 const fcsCode = params->fParams.contentSizeFlag ?
                     (pledgedSrcSize>=256) + (pledgedSrcSize>=65536+256) + (pledgedSrcSize>=0xFFFFFFFFU) : 0;
    BYTE const frameHeaderDescriptionByte = (BYTE)(dictIDSizeCode + (checksumFlag<<2) + (singleSegment<<5) + (fcsCode<<6) );
    size_t pos=0;

    ((void)0);
    do { if (dstCapacity < 18) { do { } while (0); do { if (0) { _force_has_format_string("dst buf is too small to fit worst-case frame header size."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)
                                                                                ;
    do { } while (0)
                                                                                          ;
    if (params->format == ZSTD_f_zstd1) {
        MEM_writeLE32(dst, 0xFD2FB528);
        pos = 4;
    }
    op[pos++] = frameHeaderDescriptionByte;
    if (!singleSegment) op[pos++] = windowLogByte;
    switch(dictIDSizeCode)
    {
        default:
            ((void)0);
            ; __attribute__((__fallthrough__));
        case 0 : break;
        case 1 : op[pos] = (BYTE)(dictID); pos++; break;
        case 2 : MEM_writeLE16(op+pos, (U16)dictID); pos+=2; break;
        case 3 : MEM_writeLE32(op+pos, dictID); pos+=4; break;
    }
    switch(fcsCode)
    {
        default:
            ((void)0);
            ; __attribute__((__fallthrough__));
        case 0 : if (singleSegment) op[pos++] = (BYTE)(pledgedSrcSize); break;
        case 1 : MEM_writeLE16(op+pos, (U16)(pledgedSrcSize-256)); pos+=2; break;
        case 2 : MEM_writeLE32(op+pos, (U32)(pledgedSrcSize)); pos+=4; break;
        case 3 : MEM_writeLE64(op+pos, (U64)(pledgedSrcSize)); pos+=8; break;
    }
    return pos;
}







size_t ZSTD_writeSkippableFrame(void* dst, size_t dstCapacity,
                                const void* src, size_t srcSize, unsigned magicVariant) {
    BYTE* op = (BYTE*)dst;
    do { if (dstCapacity < srcSize + 8) { do { } while (0); do { if (0) { _force_has_format_string("Not enough room for skippable frame"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)
                                                                            ;
    do { if (srcSize > (unsigned)0xFFFFFFFF) { do { } while (0); do { if (0) { _force_has_format_string("Src size too large for skippable frame"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_srcSize_wrong); } } while (0);
    do { if (magicVariant > 15) { do { } while (0); do { if (0) { _force_has_format_string("Skippable frame magic number variant not supported"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0);

    MEM_writeLE32(op, (U32)(0x184D2A50 + magicVariant));
    MEM_writeLE32(op+4, (U32)srcSize);
    __builtin_memcpy((op+8),(src),(srcSize));
    return srcSize + 8;
}






size_t ZSTD_writeLastEmptyBlock(void* dst, size_t dstCapacity)
{
    do { if (dstCapacity < ZSTD_blockHeaderSize) { do { } while (0); do { if (0) { _force_has_format_string("dst buf is too small to write frame trailer empty block."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0)
                                                                               ;
    { U32 const cBlockHeader24 = 1 + (((U32)bt_raw)<<1);
        MEM_writeLE24(dst, cBlockHeader24);
        return ZSTD_blockHeaderSize;
    }
}

void ZSTD_referenceExternalSequences(ZSTD_CCtx* cctx, rawSeq* seq, size_t nbSeq)
{
    ((void)0);
    ((void)0);
    cctx->externSeqStore.seq = seq;
    cctx->externSeqStore.size = nbSeq;
    cctx->externSeqStore.capacity = nbSeq;
    cctx->externSeqStore.pos = 0;
    cctx->externSeqStore.posInSequence = 0;
}


static size_t ZSTD_compressContinue_internal (ZSTD_CCtx* cctx,
                              void* dst, size_t dstCapacity,
                        const void* src, size_t srcSize,
                               U32 frame, U32 lastFrameChunk)
{
    ZSTD_MatchState_t* const ms = &cctx->blockState.matchState;
    size_t fhSize = 0;

    do { } while (0)
                                               ;
    do { if (cctx->stage==ZSTDcs_created) { do { } while (0); do { if (0) { _force_has_format_string("missing init (ZSTD_compressBegin)"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0)
                                                        ;

    if (frame && (cctx->stage==ZSTDcs_init)) {
        fhSize = ZSTD_writeFrameHeader(dst, dstCapacity, &cctx->appliedParams,
                                       cctx->pledgedSrcSizePlusOne-1, cctx->dictID);
        do { size_t const err_code = (fhSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_writeFrameHeader failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ((void)0);
        dstCapacity -= fhSize;
        dst = (char*)dst + fhSize;
        cctx->stage = ZSTDcs_ongoing;
    }

    if (!srcSize) return fhSize;

    if (!ZSTD_window_update(&ms->window, src, srcSize, ms->forceNonContiguous)) {
        ms->forceNonContiguous = 0;
        ms->nextToUpdate = ms->window.dictLimit;
    }
    if (cctx->appliedParams.ldmParams.enableLdm == ZSTD_ps_enable) {
        ZSTD_window_update(&cctx->ldmState.window, src, srcSize, 0);
    }

    if (!frame) {

        ZSTD_overflowCorrectIfNeeded(
            ms, &cctx->workspace, &cctx->appliedParams,
            src, (BYTE const*)src + srcSize);
    }

    do { } while (0);
    { size_t const cSize = frame ?
                             ZSTD_compress_frameChunk (cctx, dst, dstCapacity, src, srcSize, lastFrameChunk) :
                             ZSTD_compressBlock_internal (cctx, dst, dstCapacity, src, srcSize, 0 );
        do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("%s", frame ? "ZSTD_compress_frameChunk failed" : "ZSTD_compressBlock_internal failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        cctx->consumedSrcSize += srcSize;
        cctx->producedCSize += (cSize + fhSize);
        ((void)0);
        if (cctx->pledgedSrcSizePlusOne != 0) {
            (void)sizeof(char[((0ULL - 1) == (unsigned long long)-1) ? 1 : -1]);
            do { if (cctx->consumedSrcSize+1 > cctx->pledgedSrcSizePlusOne) { do { } while (0); do { if (0) { _force_has_format_string("error : pledgedSrcSize = %u, while realSrcSize >= %u", (unsigned)cctx->pledgedSrcSizePlusOne-1, (unsigned)cctx->consumedSrcSize); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_srcSize_wrong); } } while (0)




                                                ;
        }
        return cSize + fhSize;
    }
}

size_t ZSTD_compressContinue_public(ZSTD_CCtx* cctx,
                                        void* dst, size_t dstCapacity,
                                  const void* src, size_t srcSize)
{
    do { } while (0);
    return ZSTD_compressContinue_internal(cctx, dst, dstCapacity, src, srcSize, 1 , 0 );
}


size_t ZSTD_compressContinue(ZSTD_CCtx* cctx,
                             void* dst, size_t dstCapacity,
                       const void* src, size_t srcSize)
{
    return ZSTD_compressContinue_public(cctx, dst, dstCapacity, src, srcSize);
}

static size_t ZSTD_getBlockSize_deprecated(const ZSTD_CCtx* cctx)
{
    ZSTD_compressionParameters const cParams = cctx->appliedParams.cParams;
    ((void)0);
    return ((cctx->appliedParams.maxBlockSize)<((size_t)1 << cParams.windowLog) ? (cctx->appliedParams.maxBlockSize) : ((size_t)1 << cParams.windowLog));
}


size_t ZSTD_getBlockSize(const ZSTD_CCtx* cctx)
{
    return ZSTD_getBlockSize_deprecated(cctx);
}


size_t ZSTD_compressBlock_deprecated(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize)
{
    do { } while (0);
    { size_t const blockSizeMax = ZSTD_getBlockSize_deprecated(cctx);
      do { if (srcSize > blockSizeMax) { do { } while (0); do { if (0) { _force_has_format_string("input is larger than a block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_srcSize_wrong); } } while (0); }

    return ZSTD_compressContinue_internal(cctx, dst, dstCapacity, src, srcSize, 0 , 0 );
}


size_t ZSTD_compressBlock(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize)
{
    return ZSTD_compressBlock_deprecated(cctx, dst, dstCapacity, src, srcSize);
}




static size_t
ZSTD_loadDictionaryContent(ZSTD_MatchState_t* ms,
                        ldmState_t* ls,
                        ZSTD_cwksp* ws,
                        ZSTD_CCtx_params const* params,
                        const void* src, size_t srcSize,
                        ZSTD_dictTableLoadMethod_e dtlm,
                        ZSTD_tableFillPurpose_e tfp)
{
    const BYTE* ip = (const BYTE*) src;
    const BYTE* const iend = ip + srcSize;
    int const loadLdmDict = params->ldmParams.enableLdm == ZSTD_ps_enable && ls != 
# 4912 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                                  ((void *)0)
# 4912 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                                      ;


    ZSTD_assertEqualCParams(params->cParams, ms->cParams);

    {





        U32 maxDictSize = (MEM_64bits() ? 3500U *(1 <<20) : 2000U *(1 <<20)) - 2;

        int const CDictTaggedIndices = ZSTD_CDictIndicesAreTagged(&params->cParams);
        if (CDictTaggedIndices && tfp == ZSTD_tfp_forCDict) {





            U32 const shortCacheMaxDictSize = (1u << (32 - 8)) - 2;
            maxDictSize = ((maxDictSize)<(shortCacheMaxDictSize) ? (maxDictSize) : (shortCacheMaxDictSize));
            ((void)0);
        }


        if (srcSize > maxDictSize) {
            ip = iend - maxDictSize;
            src = ip;
            srcSize = maxDictSize;
        }
    }

    if (srcSize > ( ((U32)-1) - (MEM_64bits() ? 3500U *(1 <<20) : 2000U *(1 <<20)))) {

        ((void)0);
        if (loadLdmDict) ((void)0);
    }
    ZSTD_window_update(&ms->window, src, srcSize, 0);

    do { } while (0);

    if (loadLdmDict) {
        do { } while (0);
        ZSTD_window_update(&ls->window, src, srcSize, 0);
        ls->loadedDictEnd = params->forceWindow ? 0 : (U32)(iend - ls->window.base);
        ZSTD_ldm_fillHashTable(ls, ip, iend, &params->ldmParams);
        do { } while (0);
    }


    { U32 maxDictSize = 1U << ((((params->cParams.hashLog + 3)>(params->cParams.chainLog + 1) ? (params->cParams.hashLog + 3) : (params->cParams.chainLog + 1)))<(31) ? (((params->cParams.hashLog + 3)>(params->cParams.chainLog + 1) ? (params->cParams.hashLog + 3) : (params->cParams.chainLog + 1))) : (31));
        if (srcSize > maxDictSize) {
            ip = iend - maxDictSize;
            src = ip;
            srcSize = maxDictSize;
        }
    }

    ms->nextToUpdate = (U32)(ip - ms->window.base);
    ms->loadedDictEnd = params->forceWindow ? 0 : (U32)(iend - ms->window.base);
    ms->forceNonContiguous = params->deterministicRefPrefix;

    if (srcSize <= 8) return 0;

    ZSTD_overflowCorrectIfNeeded(ms, ws, params, ip, iend);

    switch(params->cParams.strategy)
    {
    case ZSTD_fast:
        ZSTD_fillHashTable(ms, iend, dtlm, tfp);
        break;
    case ZSTD_dfast:

        ZSTD_fillDoubleHashTable(ms, iend, dtlm, tfp);



        break;

    case ZSTD_greedy:
    case ZSTD_lazy:
    case ZSTD_lazy2:



        ((void)0);
        if (ms->dedicatedDictSearch) {
            ((void)0);
            ZSTD_dedicatedDictSearch_lazy_loadDictionary(ms, iend-8);
        } else {
            ((void)0);
            if (params->useRowMatchFinder == ZSTD_ps_enable) {
                size_t const tagTableSize = ((size_t)1 << params->cParams.hashLog);
                __builtin_memset((ms->tagTable),(0),(tagTableSize));
                ZSTD_row_update(ms, iend-8);
                do { } while (0);
            } else {
                ZSTD_insertAndFindFirstIndex(ms, iend-8);
                do { } while (0);
            }
        }



        break;

    case ZSTD_btlazy2:
    case ZSTD_btopt:
    case ZSTD_btultra:
    case ZSTD_btultra2:



        ((void)0);
        do { } while (0);
        ZSTD_updateTree(ms, iend-8, iend);



        break;

    default:
        ((void)0);
    }

    ms->nextToUpdate = (U32)(iend - ms->window.base);
    return 0;
}






static FSE_repeat ZSTD_dictNCountRepeat(short* normalizedCounter, unsigned dictMaxSymbolValue, unsigned maxSymbolValue)
{
    U32 s;
    if (dictMaxSymbolValue < maxSymbolValue) {
        return FSE_repeat_check;
    }
    for (s = 0; s <= maxSymbolValue; ++s) {
        if (normalizedCounter[s] == 0) {
            return FSE_repeat_check;
        }
    }
    return FSE_repeat_valid;
}

size_t ZSTD_loadCEntropy(ZSTD_compressedBlockState_t* bs, void* workspace,
                         const void* const dict, size_t dictSize)
{
    short offcodeNCount[31 +1];
    unsigned offcodeMaxValue = 31;
    const BYTE* dictPtr = (const BYTE*)dict;
    const BYTE* const dictEnd = dictPtr + dictSize;
    dictPtr += 8;
    bs->entropy.huf.repeatMode = HUF_repeat_check;

    { unsigned maxSymbolValue = 255;
        unsigned hasZeroWeights = 1;
        size_t const hufHeaderSize = HUF_readCTable((HUF_CElt*)bs->entropy.huf.CTable, &maxSymbolValue, dictPtr,
            (size_t)(dictEnd-dictPtr), &hasZeroWeights);



        if (!hasZeroWeights && maxSymbolValue == 255)
            bs->entropy.huf.repeatMode = HUF_repeat_valid;

        do { if (ERR_isError(hufHeaderSize)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
        dictPtr += hufHeaderSize;
    }

    { unsigned offcodeLog;
        size_t const offcodeHeaderSize = FSE_readNCount(offcodeNCount, &offcodeMaxValue, &offcodeLog, dictPtr, (size_t)(dictEnd-dictPtr));
        do { if (ERR_isError(offcodeHeaderSize)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
        do { if (offcodeLog > 8) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);

        do { if (ERR_isError(FSE_buildCTable_wksp( bs->entropy.fse.offcodeCTable, offcodeNCount, 31, offcodeLog, workspace, ((8 << 10) + 512 )))) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0)



                                     ;

        dictPtr += offcodeHeaderSize;
    }

    { short matchlengthNCount[52 +1];
        unsigned matchlengthMaxValue = 52, matchlengthLog;
        size_t const matchlengthHeaderSize = FSE_readNCount(matchlengthNCount, &matchlengthMaxValue, &matchlengthLog, dictPtr, (size_t)(dictEnd-dictPtr));
        do { if (ERR_isError(matchlengthHeaderSize)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
        do { if (matchlengthLog > 9) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
        do { if (ERR_isError(FSE_buildCTable_wksp( bs->entropy.fse.matchlengthCTable, matchlengthNCount, matchlengthMaxValue, matchlengthLog, workspace, ((8 << 10) + 512 )))) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0)



                                     ;
        bs->entropy.fse.matchlength_repeatMode = ZSTD_dictNCountRepeat(matchlengthNCount, matchlengthMaxValue, 52);
        dictPtr += matchlengthHeaderSize;
    }

    { short litlengthNCount[35 +1];
        unsigned litlengthMaxValue = 35, litlengthLog;
        size_t const litlengthHeaderSize = FSE_readNCount(litlengthNCount, &litlengthMaxValue, &litlengthLog, dictPtr, (size_t)(dictEnd-dictPtr));
        do { if (ERR_isError(litlengthHeaderSize)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
        do { if (litlengthLog > 9) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
        do { if (ERR_isError(FSE_buildCTable_wksp( bs->entropy.fse.litlengthCTable, litlengthNCount, litlengthMaxValue, litlengthLog, workspace, ((8 << 10) + 512 )))) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0)



                                     ;
        bs->entropy.fse.litlength_repeatMode = ZSTD_dictNCountRepeat(litlengthNCount, litlengthMaxValue, 35);
        dictPtr += litlengthHeaderSize;
    }

    do { if (dictPtr+12 > dictEnd) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
    bs->rep[0] = MEM_readLE32(dictPtr+0);
    bs->rep[1] = MEM_readLE32(dictPtr+4);
    bs->rep[2] = MEM_readLE32(dictPtr+8);
    dictPtr += 12;

    { size_t const dictContentSize = (size_t)(dictEnd - dictPtr);
        U32 offcodeMax = 31;
        if (dictContentSize <= ((U32)-1) - 128 *(1 <<10)) {
            U32 const maxOffset = (U32)dictContentSize + 128 *(1 <<10);
            offcodeMax = ZSTD_highbit32(maxOffset);
        }

        bs->entropy.fse.offcode_repeatMode = ZSTD_dictNCountRepeat(offcodeNCount, offcodeMaxValue, ((offcodeMax)<(31) ? (offcodeMax) : (31)));


        { U32 u;
            for (u=0; u<3; u++) {
                do { if (bs->rep[u] == 0) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
                do { if (bs->rep[u] > dictContentSize) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_corrupted); } } while (0);
    } } }

    return (size_t)(dictPtr - (const BYTE*)dict);
}
# 5161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static size_t ZSTD_loadZstdDictionary(ZSTD_compressedBlockState_t* bs,
                                      ZSTD_MatchState_t* ms,
                                      ZSTD_cwksp* ws,
                                      ZSTD_CCtx_params const* params,
                                      const void* dict, size_t dictSize,
                                      ZSTD_dictTableLoadMethod_e dtlm,
                                      ZSTD_tableFillPurpose_e tfp,
                                      void* workspace)
{
    const BYTE* dictPtr = (const BYTE*)dict;
    const BYTE* const dictEnd = dictPtr + dictSize;
    size_t dictID;
    size_t eSize;
    (void)sizeof(char[(((8 << 10) + 512 ) >= (1<<((9)>(9) ? (9) : (9)))) ? 1 : -1]);
    ((void)0);
    ((void)0);

    dictID = params->fParams.noDictIDFlag ? 0 : MEM_readLE32(dictPtr + 4 );
    eSize = ZSTD_loadCEntropy(bs, workspace, dict, dictSize);
    do { size_t const err_code = (eSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_loadCEntropy failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    dictPtr += eSize;

    {
        size_t const dictContentSize = (size_t)(dictEnd - dictPtr);
        do { size_t const err_code = (ZSTD_loadDictionaryContent( ms, 
# 5185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
       ((void *)0)
# 5185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
       , ws, params, dictPtr, dictContentSize, dtlm, tfp)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)
                                                                           ;
    }
    return dictID;
}



static size_t
ZSTD_compress_insertDictionary(ZSTD_compressedBlockState_t* bs,
                               ZSTD_MatchState_t* ms,
                               ldmState_t* ls,
                               ZSTD_cwksp* ws,
                         const ZSTD_CCtx_params* params,
                         const void* dict, size_t dictSize,
                               ZSTD_dictContentType_e dictContentType,
                               ZSTD_dictTableLoadMethod_e dtlm,
                               ZSTD_tableFillPurpose_e tfp,
                               void* workspace)
{
    do { } while (0);
    if ((dict==
# 5206 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
              ((void *)0)
# 5206 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                  ) || (dictSize<8)) {
        do { if (dictContentType == ZSTD_dct_fullDict) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_wrong); } } while (0);
        return 0;
    }

    ZSTD_reset_compressedBlockState(bs);


    if (dictContentType == ZSTD_dct_rawContent)
        return ZSTD_loadDictionaryContent(ms, ls, ws, params, dict, dictSize, dtlm, tfp);

    if (MEM_readLE32(dict) != 0xEC30A437) {
        if (dictContentType == ZSTD_dct_auto) {
            do { } while (0);
            return ZSTD_loadDictionaryContent(
                ms, ls, ws, params, dict, dictSize, dtlm, tfp);
        }
        do { if (dictContentType == ZSTD_dct_fullDict) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_wrong); } } while (0);
        ((void)0);
    }


    return ZSTD_loadZstdDictionary(
        bs, ms, ws, params, dict, dictSize, dtlm, tfp, workspace);
}







static size_t ZSTD_compressBegin_internal(ZSTD_CCtx* cctx,
                                    const void* dict, size_t dictSize,
                                    ZSTD_dictContentType_e dictContentType,
                                    ZSTD_dictTableLoadMethod_e dtlm,
                                    const ZSTD_CDict* cdict,
                                    const ZSTD_CCtx_params* params, U64 pledgedSrcSize,
                                    ZSTD_buffered_policy_e zbuff)
{
    size_t const dictContentSize = cdict ? cdict->dictContentSize : dictSize;

    cctx->traceCtx = (ZSTD_trace_compress_begin != 
# 5248 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                  ((void *)0)
# 5248 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                      ) ? ZSTD_trace_compress_begin(cctx) : 0;

    do { } while (0);

    ((void)0);
    ((void)0);
    if ( (cdict)
      && (cdict->dictContentSize > 0)
      && ( pledgedSrcSize < (128 *(1 <<10))
        || pledgedSrcSize < cdict->dictContentSize * (6ULL)
        || pledgedSrcSize == (0ULL - 1)
        || cdict->compressionLevel == 0)
      && (params->attachDictPref != ZSTD_dictForceLoad) ) {
        return ZSTD_resetCCtx_usingCDict(cctx, cdict, params, pledgedSrcSize, zbuff);
    }

    do { size_t const err_code = (ZSTD_resetCCtx_internal(cctx, params, pledgedSrcSize, dictContentSize, ZSTDcrp_makeClean, zbuff)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)

                                                                    ;
    { size_t const dictID = cdict ?
                ZSTD_compress_insertDictionary(
                        cctx->blockState.prevCBlock, &cctx->blockState.matchState,
                        &cctx->ldmState, &cctx->workspace, &cctx->appliedParams, cdict->dictContent,
                        cdict->dictContentSize, cdict->dictContentType, dtlm,
                        ZSTD_tfp_forCCtx, cctx->tmpWorkspace)
              : ZSTD_compress_insertDictionary(
                        cctx->blockState.prevCBlock, &cctx->blockState.matchState,
                        &cctx->ldmState, &cctx->workspace, &cctx->appliedParams, dict, dictSize,
                        dictContentType, dtlm, ZSTD_tfp_forCCtx, cctx->tmpWorkspace);
        do { size_t const err_code = (dictID); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compress_insertDictionary failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ((void)0);
        cctx->dictID = (U32)dictID;
        cctx->dictContentSize = dictContentSize;
    }
    return 0;
}

size_t ZSTD_compressBegin_advanced_internal(ZSTD_CCtx* cctx,
                                    const void* dict, size_t dictSize,
                                    ZSTD_dictContentType_e dictContentType,
                                    ZSTD_dictTableLoadMethod_e dtlm,
                                    const ZSTD_CDict* cdict,
                                    const ZSTD_CCtx_params* params,
                                    unsigned long long pledgedSrcSize)
{
    do { } while (0);

    do { size_t const err_code = (ZSTD_checkCParams(params->cParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return ZSTD_compressBegin_internal(cctx,
                                       dict, dictSize, dictContentType, dtlm,
                                       cdict,
                                       params, pledgedSrcSize,
                                       ZSTDb_not_buffered);
}



size_t ZSTD_compressBegin_advanced(ZSTD_CCtx* cctx,
                             const void* dict, size_t dictSize,
                                   ZSTD_parameters params, unsigned long long pledgedSrcSize)
{
    ZSTD_CCtx_params cctxParams;
    ZSTD_CCtxParams_init_internal(&cctxParams, &params, 0);
    return ZSTD_compressBegin_advanced_internal(cctx,
                                            dict, dictSize, ZSTD_dct_auto, ZSTD_dtlm_fast,
                                            
# 5313 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                           ((void *)0) 
# 5313 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                         ,
                                            &cctxParams, pledgedSrcSize);
}

static size_t
ZSTD_compressBegin_usingDict_deprecated(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, int compressionLevel)
{
    ZSTD_CCtx_params cctxParams;
    { ZSTD_parameters const params = ZSTD_getParams_internal(compressionLevel, (0ULL - 1), dictSize, ZSTD_cpm_noAttachDict);
        ZSTD_CCtxParams_init_internal(&cctxParams, &params, (compressionLevel == 0) ? 3 : compressionLevel);
    }
    do { } while (0);
    return ZSTD_compressBegin_internal(cctx, dict, dictSize, ZSTD_dct_auto, ZSTD_dtlm_fast, 
# 5325 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                                           ((void *)0)
# 5325 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                                               ,
                                       &cctxParams, (0ULL - 1), ZSTDb_not_buffered);
}

size_t
ZSTD_compressBegin_usingDict(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, int compressionLevel)
{
    return ZSTD_compressBegin_usingDict_deprecated(cctx, dict, dictSize, compressionLevel);
}

size_t ZSTD_compressBegin(ZSTD_CCtx* cctx, int compressionLevel)
{
    return ZSTD_compressBegin_usingDict_deprecated(cctx, 
# 5337 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                        ((void *)0)
# 5337 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                            , 0, compressionLevel);
}





static size_t ZSTD_writeEpilogue(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity)
{
    BYTE* const ostart = (BYTE*)dst;
    BYTE* op = ostart;

    do { } while (0);
    do { if (cctx->stage == ZSTDcs_created) { do { } while (0); do { if (0) { _force_has_format_string("init missing"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stage_wrong); } } while (0);


    if (cctx->stage == ZSTDcs_init) {
        size_t fhSize = ZSTD_writeFrameHeader(dst, dstCapacity, &cctx->appliedParams, 0, 0);
        do { size_t const err_code = (fhSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_writeFrameHeader failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        dstCapacity -= fhSize;
        op += fhSize;
        cctx->stage = ZSTDcs_ongoing;
    }

    if (cctx->stage != ZSTDcs_ending) {

        U32 const cBlockHeader24 = 1 + (((U32)bt_raw)<<1) + 0;
        (void)sizeof(char[(3 == 3) ? 1 : -1]);
        do { if (dstCapacity<3) { do { } while (0); do { if (0) { _force_has_format_string("no room for epilogue"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
        MEM_writeLE24(op, cBlockHeader24);
        op += ZSTD_blockHeaderSize;
        dstCapacity -= ZSTD_blockHeaderSize;
    }

    if (cctx->appliedParams.fParams.checksumFlag) {
        U32 const checksum = (U32) ZSTD_XXH64_digest(&cctx->xxhState);
        do { if (dstCapacity<4) { do { } while (0); do { if (0) { _force_has_format_string("no room for checksum"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
        do { } while (0);
        MEM_writeLE32(op, checksum);
        op += 4;
    }

    cctx->stage = ZSTDcs_created;
    return (size_t)(op-ostart);
}

void ZSTD_CCtx_trace(ZSTD_CCtx* cctx, size_t extraCSize)
{

    if (cctx->traceCtx && ZSTD_trace_compress_end != 
# 5386 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                    ((void *)0)
# 5386 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                        ) {
        int const streaming = cctx->inBuffSize > 0 || cctx->outBuffSize > 0 || cctx->appliedParams.nbWorkers > 0;
        ZSTD_Trace trace;
        __builtin_memset((&trace),(0),(sizeof(trace)));
        trace.version = (1 *100*100 + 5 *100 + 7);
        trace.streaming = streaming;
        trace.dictionaryID = cctx->dictID;
        trace.dictionarySize = cctx->dictContentSize;
        trace.uncompressedSize = cctx->consumedSrcSize;
        trace.compressedSize = cctx->producedCSize + extraCSize;
        trace.params = &cctx->appliedParams;
        trace.cctx = cctx;
        ZSTD_trace_compress_end(cctx->traceCtx, &trace);
    }
    cctx->traceCtx = 0;




}

size_t ZSTD_compressEnd_public(ZSTD_CCtx* cctx,
                               void* dst, size_t dstCapacity,
                         const void* src, size_t srcSize)
{
    size_t endResult;
    size_t const cSize = ZSTD_compressContinue_internal(cctx,
                                dst, dstCapacity, src, srcSize,
                                1 , 1 );
    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressContinue_internal failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    endResult = ZSTD_writeEpilogue(cctx, (char*)dst + cSize, dstCapacity-cSize);
    do { size_t const err_code = (endResult); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_writeEpilogue failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    ((void)0);
    if (cctx->pledgedSrcSizePlusOne != 0) {
        (void)sizeof(char[((0ULL - 1) == (unsigned long long)-1) ? 1 : -1]);
        do { } while (0);
        do { if (cctx->pledgedSrcSizePlusOne != cctx->consumedSrcSize+1) { do { } while (0); do { if (0) { _force_has_format_string("error : pledgedSrcSize = %u, while realSrcSize = %u", (unsigned)cctx->pledgedSrcSizePlusOne-1, (unsigned)cctx->consumedSrcSize); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_srcSize_wrong); } } while (0)




                                            ;
    }
    ZSTD_CCtx_trace(cctx, endResult);
    return cSize + endResult;
}


size_t ZSTD_compressEnd(ZSTD_CCtx* cctx,
                        void* dst, size_t dstCapacity,
                  const void* src, size_t srcSize)
{
    return ZSTD_compressEnd_public(cctx, dst, dstCapacity, src, srcSize);
}

size_t ZSTD_compress_advanced (ZSTD_CCtx* cctx,
                               void* dst, size_t dstCapacity,
                         const void* src, size_t srcSize,
                         const void* dict,size_t dictSize,
                               ZSTD_parameters params)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_checkCParams(params.cParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    ZSTD_CCtxParams_init_internal(&cctx->simpleApiParams, &params, 0);
    return ZSTD_compress_advanced_internal(cctx,
                                           dst, dstCapacity,
                                           src, srcSize,
                                           dict, dictSize,
                                           &cctx->simpleApiParams);
}


size_t ZSTD_compress_advanced_internal(
        ZSTD_CCtx* cctx,
        void* dst, size_t dstCapacity,
        const void* src, size_t srcSize,
        const void* dict,size_t dictSize,
        const ZSTD_CCtx_params* params)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_compressBegin_internal(cctx, dict, dictSize, ZSTD_dct_auto, ZSTD_dtlm_fast, 
# 5466 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
   ((void *)0)
# 5466 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
   , params, srcSize, ZSTDb_not_buffered)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)

                                                                   ;
    return ZSTD_compressEnd_public(cctx, dst, dstCapacity, src, srcSize);
}

size_t ZSTD_compress_usingDict(ZSTD_CCtx* cctx,
                               void* dst, size_t dstCapacity,
                         const void* src, size_t srcSize,
                         const void* dict, size_t dictSize,
                               int compressionLevel)
{
    {
        ZSTD_parameters const params = ZSTD_getParams_internal(compressionLevel, srcSize, dict ? dictSize : 0, ZSTD_cpm_noAttachDict);
        ((void)0);
        ZSTD_CCtxParams_init_internal(&cctx->simpleApiParams, &params, (compressionLevel == 0) ? 3: compressionLevel);
    }
    do { } while (0);
    return ZSTD_compress_advanced_internal(cctx, dst, dstCapacity, src, srcSize, dict, dictSize, &cctx->simpleApiParams);
}

size_t ZSTD_compressCCtx(ZSTD_CCtx* cctx,
                         void* dst, size_t dstCapacity,
                   const void* src, size_t srcSize,
                         int compressionLevel)
{
    do { } while (0);
    ((void)0);
    return ZSTD_compress_usingDict(cctx, dst, dstCapacity, src, srcSize, 
# 5494 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                        ((void *)0)
# 5494 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                            , 0, compressionLevel);
}

size_t ZSTD_compress(void* dst, size_t dstCapacity,
               const void* src, size_t srcSize,
                     int compressionLevel)
{
    size_t result;






    ZSTD_CCtx ctxBody;
    ZSTD_initCCtx(&ctxBody, ZSTD_defaultCMem);
    result = ZSTD_compressCCtx(&ctxBody, dst, dstCapacity, src, srcSize, compressionLevel);
    ZSTD_freeCCtxContent(&ctxBody);

    return result;
}






size_t ZSTD_estimateCDictSize_advanced(
        size_t dictSize, ZSTD_compressionParameters cParams,
        ZSTD_dictLoadMethod_e dictLoadMethod)
{
    do { } while (0);
    return ZSTD_cwksp_alloc_size(sizeof(ZSTD_CDict))
         + ZSTD_cwksp_alloc_size(((8 << 10) + 512 ))


         + ZSTD_sizeof_matchState(&cParams, ZSTD_resolveRowMatchFinderMode(ZSTD_ps_auto, &cParams),
                                                                  1, 0)
         + (dictLoadMethod == ZSTD_dlm_byRef ? 0
            : ZSTD_cwksp_alloc_size(ZSTD_cwksp_align(dictSize, sizeof(void *))));
}

size_t ZSTD_estimateCDictSize(size_t dictSize, int compressionLevel)
{
    ZSTD_compressionParameters const cParams = ZSTD_getCParams_internal(compressionLevel, (0ULL - 1), dictSize, ZSTD_cpm_createCDict);
    return ZSTD_estimateCDictSize_advanced(dictSize, cParams, ZSTD_dlm_byCopy);
}

size_t ZSTD_sizeof_CDict(const ZSTD_CDict* cdict)
{
    if (cdict==
# 5544 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
              ((void *)0)
# 5544 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                  ) return 0;
    do { } while (0);

    return (cdict->workspace.workspace == cdict ? 0 : sizeof(*cdict))
        + ZSTD_cwksp_sizeof(&cdict->workspace);
}

static size_t ZSTD_initCDict_internal(
                    ZSTD_CDict* cdict,
              const void* dictBuffer, size_t dictSize,
                    ZSTD_dictLoadMethod_e dictLoadMethod,
                    ZSTD_dictContentType_e dictContentType,
                    ZSTD_CCtx_params params)
{
    do { } while (0);
    ((void)0);
    cdict->matchState.cParams = params.cParams;
    cdict->matchState.dedicatedDictSearch = params.enableDedicatedDictSearch;
    if ((dictLoadMethod == ZSTD_dlm_byRef) || (!dictBuffer) || (!dictSize)) {
        cdict->dictContent = dictBuffer;
    } else {
         void *internalBuffer = ZSTD_cwksp_reserve_object(&cdict->workspace, ZSTD_cwksp_align(dictSize, sizeof(void*)));
        do { if (!internalBuffer) { do { } while (0); do { if (0) { _force_has_format_string("NULL pointer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_memory_allocation); } } while (0);
        cdict->dictContent = internalBuffer;
        __builtin_memcpy((internalBuffer),(dictBuffer),(dictSize));
    }
    cdict->dictContentSize = dictSize;
    cdict->dictContentType = dictContentType;

    cdict->entropyWorkspace = (U32*)ZSTD_cwksp_reserve_object(&cdict->workspace, ((8 << 10) + 512 ));



    ZSTD_reset_compressedBlockState(&cdict->cBlockState);
    do { size_t const err_code = (ZSTD_reset_matchState( &cdict->matchState, &cdict->workspace, &params.cParams, params.useRowMatchFinder, ZSTDcrp_makeClean, ZSTDirp_reset, ZSTD_resetTarget_CDict)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)






                                    ;



    { params.compressionLevel = 3;
        params.fParams.contentSizeFlag = 1;
        { size_t const dictID = ZSTD_compress_insertDictionary(
                    &cdict->cBlockState, &cdict->matchState, 
# 5592 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                            ((void *)0)
# 5592 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                , &cdict->workspace,
                    &params, cdict->dictContent, cdict->dictContentSize,
                    dictContentType, ZSTD_dtlm_full, ZSTD_tfp_forCDict, cdict->entropyWorkspace);
            do { size_t const err_code = (dictID); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compress_insertDictionary failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
            ((void)0);
            cdict->dictID = (U32)dictID;
        }
    }

    return 0;
}

static ZSTD_CDict*
ZSTD_createCDict_advanced_internal(size_t dictSize,
                                ZSTD_dictLoadMethod_e dictLoadMethod,
                                ZSTD_compressionParameters cParams,
                                ZSTD_ParamSwitch_e useRowMatchFinder,
                                int enableDedicatedDictSearch,
                                ZSTD_customMem customMem)
{
    if ((!customMem.customAlloc) ^ (!customMem.customFree)) return 
# 5612 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                                  ((void *)0)
# 5612 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                      ;
    do { } while (0);

    { size_t const workspaceSize =
            ZSTD_cwksp_alloc_size(sizeof(ZSTD_CDict)) +
            ZSTD_cwksp_alloc_size(((8 << 10) + 512 )) +
            ZSTD_sizeof_matchState(&cParams, useRowMatchFinder, enableDedicatedDictSearch, 0) +
            (dictLoadMethod == ZSTD_dlm_byRef ? 0
             : ZSTD_cwksp_alloc_size(ZSTD_cwksp_align(dictSize, sizeof(void*))));
        void* const workspace = ZSTD_customMalloc(workspaceSize, customMem);
        ZSTD_cwksp ws;
        ZSTD_CDict* cdict;

        if (!workspace) {
            ZSTD_customFree(workspace, customMem);
            return 
# 5627 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                  ((void *)0)
# 5627 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                      ;
        }

        ZSTD_cwksp_init(&ws, workspace, workspaceSize, ZSTD_cwksp_dynamic_alloc);

        cdict = (ZSTD_CDict*)ZSTD_cwksp_reserve_object(&ws, sizeof(ZSTD_CDict));
        ((void)0);
        ZSTD_cwksp_move(&cdict->workspace, &ws);
        cdict->customMem = customMem;
        cdict->compressionLevel = 0;
        cdict->useRowMatchFinder = useRowMatchFinder;
        return cdict;
    }
}

ZSTD_CDict* ZSTD_createCDict_advanced(const void* dictBuffer, size_t dictSize,
                                      ZSTD_dictLoadMethod_e dictLoadMethod,
                                      ZSTD_dictContentType_e dictContentType,
                                      ZSTD_compressionParameters cParams,
                                      ZSTD_customMem customMem)
{
    ZSTD_CCtx_params cctxParams;
    __builtin_memset((&cctxParams),(0),(sizeof(cctxParams)));
    do { } while (0);
    ZSTD_CCtxParams_init(&cctxParams, 0);
    cctxParams.cParams = cParams;
    cctxParams.customMem = customMem;
    return ZSTD_createCDict_advanced2(
        dictBuffer, dictSize,
        dictLoadMethod, dictContentType,
        &cctxParams, customMem);
}

ZSTD_CDict* ZSTD_createCDict_advanced2(
        const void* dict, size_t dictSize,
        ZSTD_dictLoadMethod_e dictLoadMethod,
        ZSTD_dictContentType_e dictContentType,
        const ZSTD_CCtx_params* originalCctxParams,
        ZSTD_customMem customMem)
{
    ZSTD_CCtx_params cctxParams = *originalCctxParams;
    ZSTD_compressionParameters cParams;
    ZSTD_CDict* cdict;

    do { } while (0);
    if (!customMem.customAlloc ^ !customMem.customFree) return 
# 5672 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                                              ((void *)0)
# 5672 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                                                  ;

    if (cctxParams.enableDedicatedDictSearch) {
        cParams = ZSTD_dedicatedDictSearch_getCParams(
            cctxParams.compressionLevel, dictSize);
        ZSTD_overrideCParams(&cParams, &cctxParams.cParams);
    } else {
        cParams = ZSTD_getCParamsFromCCtxParams(
            &cctxParams, (0ULL - 1), dictSize, ZSTD_cpm_createCDict);
    }

    if (!ZSTD_dedicatedDictSearch_isSupported(&cParams)) {

        cctxParams.enableDedicatedDictSearch = 0;
        cParams = ZSTD_getCParamsFromCCtxParams(
            &cctxParams, (0ULL - 1), dictSize, ZSTD_cpm_createCDict);
    }

    do { } while (0);
    cctxParams.cParams = cParams;
    cctxParams.useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(cctxParams.useRowMatchFinder, &cParams);

    cdict = ZSTD_createCDict_advanced_internal(dictSize,
                        dictLoadMethod, cctxParams.cParams,
                        cctxParams.useRowMatchFinder, cctxParams.enableDedicatedDictSearch,
                        customMem);

    if (!cdict || ERR_isError( ZSTD_initCDict_internal(cdict,
                                    dict, dictSize,
                                    dictLoadMethod, dictContentType,
                                    cctxParams) )) {
        ZSTD_freeCDict(cdict);
        return 
# 5704 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
              ((void *)0)
# 5704 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                  ;
    }

    return cdict;
}

ZSTD_CDict* ZSTD_createCDict(const void* dict, size_t dictSize, int compressionLevel)
{
    ZSTD_compressionParameters cParams = ZSTD_getCParams_internal(compressionLevel, (0ULL - 1), dictSize, ZSTD_cpm_createCDict);
    ZSTD_CDict* const cdict = ZSTD_createCDict_advanced(dict, dictSize,
                                                  ZSTD_dlm_byCopy, ZSTD_dct_auto,
                                                  cParams, ZSTD_defaultCMem);
    if (cdict)
        cdict->compressionLevel = (compressionLevel == 0) ? 3 : compressionLevel;
    return cdict;
}

ZSTD_CDict* ZSTD_createCDict_byReference(const void* dict, size_t dictSize, int compressionLevel)
{
    ZSTD_compressionParameters cParams = ZSTD_getCParams_internal(compressionLevel, (0ULL - 1), dictSize, ZSTD_cpm_createCDict);
    ZSTD_CDict* const cdict = ZSTD_createCDict_advanced(dict, dictSize,
                                     ZSTD_dlm_byRef, ZSTD_dct_auto,
                                     cParams, ZSTD_defaultCMem);
    if (cdict)
        cdict->compressionLevel = (compressionLevel == 0) ? 3 : compressionLevel;
    return cdict;
}

size_t ZSTD_freeCDict(ZSTD_CDict* cdict)
{
    if (cdict==
# 5734 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
              ((void *)0)
# 5734 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                  ) return 0;
    { ZSTD_customMem const cMem = cdict->customMem;
        int cdictInWorkspace = ZSTD_cwksp_owns_buffer(&cdict->workspace, cdict);
        ZSTD_cwksp_free(&cdict->workspace, cMem);
        if (!cdictInWorkspace) {
            ZSTD_customFree(cdict, cMem);
        }
        return 0;
    }
}
# 5758 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
const ZSTD_CDict* ZSTD_initStaticCDict(
                                 void* workspace, size_t workspaceSize,
                           const void* dict, size_t dictSize,
                                 ZSTD_dictLoadMethod_e dictLoadMethod,
                                 ZSTD_dictContentType_e dictContentType,
                                 ZSTD_compressionParameters cParams)
{
    ZSTD_ParamSwitch_e const useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(ZSTD_ps_auto, &cParams);

    size_t const matchStateSize = ZSTD_sizeof_matchState(&cParams, useRowMatchFinder, 1, 0);
    size_t const neededSize = ZSTD_cwksp_alloc_size(sizeof(ZSTD_CDict))
                            + (dictLoadMethod == ZSTD_dlm_byRef ? 0
                               : ZSTD_cwksp_alloc_size(ZSTD_cwksp_align(dictSize, sizeof(void*))))
                            + ZSTD_cwksp_alloc_size(((8 << 10) + 512 ))
                            + matchStateSize;
    ZSTD_CDict* cdict;
    ZSTD_CCtx_params params;

    do { } while (0);
    if ((size_t)workspace & 7) return 
# 5777 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                     ((void *)0)
# 5777 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                         ;

    {
        ZSTD_cwksp ws;
        ZSTD_cwksp_init(&ws, workspace, workspaceSize, ZSTD_cwksp_static_alloc);
        cdict = (ZSTD_CDict*)ZSTD_cwksp_reserve_object(&ws, sizeof(ZSTD_CDict));
        if (cdict == 
# 5783 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                    ((void *)0)
# 5783 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                        ) return 
# 5783 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                 ((void *)0)
# 5783 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                     ;
        ZSTD_cwksp_move(&cdict->workspace, &ws);
    }

    if (workspaceSize < neededSize) return 
# 5787 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                          ((void *)0)
# 5787 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                              ;

    ZSTD_CCtxParams_init(&params, 0);
    params.cParams = cParams;
    params.useRowMatchFinder = useRowMatchFinder;
    cdict->useRowMatchFinder = useRowMatchFinder;
    cdict->compressionLevel = 0;

    if (ERR_isError( ZSTD_initCDict_internal(cdict,
                                              dict, dictSize,
                                              dictLoadMethod, dictContentType,
                                              params) ))
        return 
# 5799 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
              ((void *)0)
# 5799 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                  ;

    return cdict;
}

ZSTD_compressionParameters ZSTD_getCParamsFromCDict(const ZSTD_CDict* cdict)
{
    ((void)0);
    return cdict->matchState.cParams;
}





unsigned ZSTD_getDictID_fromCDict(const ZSTD_CDict* cdict)
{
    if (cdict==
# 5816 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
              ((void *)0)
# 5816 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                  ) return 0;
    return cdict->dictID;
}




static size_t ZSTD_compressBegin_usingCDict_internal(
    ZSTD_CCtx* const cctx, const ZSTD_CDict* const cdict,
    ZSTD_frameParameters const fParams, unsigned long long const pledgedSrcSize)
{
    ZSTD_CCtx_params cctxParams;
    do { } while (0);
    do { if (cdict==
# 5829 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
   ((void *)0)
# 5829 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
   ) { do { } while (0); do { if (0) { _force_has_format_string("NULL pointer!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dictionary_wrong); } } while (0);

    {
        ZSTD_parameters params;
        params.fParams = fParams;
        params.cParams = ( pledgedSrcSize < (128 *(1 <<10))
                        || pledgedSrcSize < cdict->dictContentSize * (6ULL)
                        || pledgedSrcSize == (0ULL - 1)
                        || cdict->compressionLevel == 0 ) ?
                ZSTD_getCParamsFromCDict(cdict)
              : ZSTD_getCParams(cdict->compressionLevel,
                                pledgedSrcSize,
                                cdict->dictContentSize);
        ZSTD_CCtxParams_init_internal(&cctxParams, &params, cdict->compressionLevel);
    }




    if (pledgedSrcSize != (0ULL - 1)) {
        U32 const limitedSrcSize = (U32)((pledgedSrcSize)<(1U << 19) ? (pledgedSrcSize) : (1U << 19));
        U32 const limitedSrcLog = limitedSrcSize > 1 ? ZSTD_highbit32(limitedSrcSize - 1) + 1 : 1;
        cctxParams.cParams.windowLog = ((cctxParams.cParams.windowLog)>(limitedSrcLog) ? (cctxParams.cParams.windowLog) : (limitedSrcLog));
    }
    return ZSTD_compressBegin_internal(cctx,
                                        
# 5854 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                       ((void *)0)
# 5854 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                           , 0, ZSTD_dct_auto, ZSTD_dtlm_fast,
                                        cdict,
                                        &cctxParams, pledgedSrcSize,
                                        ZSTDb_not_buffered);
}





size_t ZSTD_compressBegin_usingCDict_advanced(
    ZSTD_CCtx* const cctx, const ZSTD_CDict* const cdict,
    ZSTD_frameParameters const fParams, unsigned long long const pledgedSrcSize)
{
    return ZSTD_compressBegin_usingCDict_internal(cctx, cdict, fParams, pledgedSrcSize);
}



size_t ZSTD_compressBegin_usingCDict_deprecated(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict)
{
    ZSTD_frameParameters const fParams = { 0 , 0 , 0 };
    return ZSTD_compressBegin_usingCDict_internal(cctx, cdict, fParams, (0ULL - 1));
}

size_t ZSTD_compressBegin_usingCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict)
{
    return ZSTD_compressBegin_usingCDict_deprecated(cctx, cdict);
}




static size_t ZSTD_compress_usingCDict_internal(ZSTD_CCtx* cctx,
                                void* dst, size_t dstCapacity,
                                const void* src, size_t srcSize,
                                const ZSTD_CDict* cdict, ZSTD_frameParameters fParams)
{
    do { size_t const err_code = (ZSTD_compressBegin_usingCDict_internal(cctx, cdict, fParams, srcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return ZSTD_compressEnd_public(cctx, dst, dstCapacity, src, srcSize);
}




size_t ZSTD_compress_usingCDict_advanced(ZSTD_CCtx* cctx,
                                void* dst, size_t dstCapacity,
                                const void* src, size_t srcSize,
                                const ZSTD_CDict* cdict, ZSTD_frameParameters fParams)
{
    return ZSTD_compress_usingCDict_internal(cctx, dst, dstCapacity, src, srcSize, cdict, fParams);
}






size_t ZSTD_compress_usingCDict(ZSTD_CCtx* cctx,
                                void* dst, size_t dstCapacity,
                                const void* src, size_t srcSize,
                                const ZSTD_CDict* cdict)
{
    ZSTD_frameParameters const fParams = { 1 , 0 , 0 };
    return ZSTD_compress_usingCDict_internal(cctx, dst, dstCapacity, src, srcSize, cdict, fParams);
}







ZSTD_CStream* ZSTD_createCStream(void)
{
    do { } while (0);
    return ZSTD_createCStream_advanced(ZSTD_defaultCMem);
}

ZSTD_CStream* ZSTD_initStaticCStream(void *workspace, size_t workspaceSize)
{
    return ZSTD_initStaticCCtx(workspace, workspaceSize);
}

ZSTD_CStream* ZSTD_createCStream_advanced(ZSTD_customMem customMem)
{
    return ZSTD_createCCtx_advanced(customMem);
}

size_t ZSTD_freeCStream(ZSTD_CStream* zcs)
{
    return ZSTD_freeCCtx(zcs);
}





size_t ZSTD_CStreamInSize(void) { return (1<<17); }

size_t ZSTD_CStreamOutSize(void)
{
    return ZSTD_compressBound((1<<17)) + ZSTD_blockHeaderSize + 4 ;
}

static ZSTD_CParamMode_e ZSTD_getCParamMode(ZSTD_CDict const* cdict, ZSTD_CCtx_params const* params, U64 pledgedSrcSize)
{
    if (cdict != 
# 5961 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                ((void *)0) 
# 5961 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                     && ZSTD_shouldAttachDict(cdict, params, pledgedSrcSize))
        return ZSTD_cpm_attachDict;
    else
        return ZSTD_cpm_noAttachDict;
}



size_t ZSTD_resetCStream(ZSTD_CStream* zcs, unsigned long long pss)
{




    U64 const pledgedSrcSize = (pss==0) ? (0ULL - 1) : pss;
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setPledgedSrcSize(zcs, pledgedSrcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}





size_t ZSTD_initCStream_internal(ZSTD_CStream* zcs,
                    const void* dict, size_t dictSize, const ZSTD_CDict* cdict,
                    const ZSTD_CCtx_params* params,
                    unsigned long long pledgedSrcSize)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setPledgedSrcSize(zcs, pledgedSrcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    ((void)0);
    zcs->requestedParams = *params;
    ((void)0);
    if (dict) {
        do { size_t const err_code = (ZSTD_CCtx_loadDictionary(zcs, dict, dictSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    } else {

        do { size_t const err_code = (ZSTD_CCtx_refCDict(zcs, cdict)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    }
    return 0;
}



size_t ZSTD_initCStream_usingCDict_advanced(ZSTD_CStream* zcs,
                                            const ZSTD_CDict* cdict,
                                            ZSTD_frameParameters fParams,
                                            unsigned long long pledgedSrcSize)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setPledgedSrcSize(zcs, pledgedSrcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    zcs->requestedParams.fParams = fParams;
    do { size_t const err_code = (ZSTD_CCtx_refCDict(zcs, cdict)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}


size_t ZSTD_initCStream_usingCDict(ZSTD_CStream* zcs, const ZSTD_CDict* cdict)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_refCDict(zcs, cdict)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}






size_t ZSTD_initCStream_advanced(ZSTD_CStream* zcs,
                                 const void* dict, size_t dictSize,
                                 ZSTD_parameters params, unsigned long long pss)
{




    U64 const pledgedSrcSize = (pss==0 && params.fParams.contentSizeFlag==0) ? (0ULL - 1) : pss;
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setPledgedSrcSize(zcs, pledgedSrcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_checkCParams(params.cParams)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    ZSTD_CCtxParams_setZstdParams(&zcs->requestedParams, &params);
    do { size_t const err_code = (ZSTD_CCtx_loadDictionary(zcs, dict, dictSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}

size_t ZSTD_initCStream_usingDict(ZSTD_CStream* zcs, const void* dict, size_t dictSize, int compressionLevel)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(zcs, ZSTD_c_compressionLevel, compressionLevel)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_loadDictionary(zcs, dict, dictSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}

size_t ZSTD_initCStream_srcSize(ZSTD_CStream* zcs, int compressionLevel, unsigned long long pss)
{




    U64 const pledgedSrcSize = (pss==0) ? (0ULL - 1) : pss;
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_refCDict(zcs, 
# 6071 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
   ((void *)0)
# 6071 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
   )); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(zcs, ZSTD_c_compressionLevel, compressionLevel)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setPledgedSrcSize(zcs, pledgedSrcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}

size_t ZSTD_initCStream(ZSTD_CStream* zcs, int compressionLevel)
{
    do { } while (0);
    do { size_t const err_code = (ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_refCDict(zcs, 
# 6081 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
   ((void *)0)
# 6081 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
   )); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { size_t const err_code = (ZSTD_CCtx_setParameter(zcs, ZSTD_c_compressionLevel, compressionLevel)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return 0;
}



static size_t ZSTD_nextInputSizeHint(const ZSTD_CCtx* cctx)
{
    if (cctx->appliedParams.inBufferMode == ZSTD_bm_stable) {
        return cctx->blockSizeMax - cctx->stableIn_notConsumed;
    }
    ((void)0);
    { size_t hintInSize = cctx->inBuffTarget - cctx->inBuffPos;
        if (hintInSize==0) hintInSize = cctx->blockSizeMax;
        return hintInSize;
    }
}




static size_t ZSTD_compressStream_generic(ZSTD_CStream* zcs,
                                          ZSTD_outBuffer* output,
                                          ZSTD_inBuffer* input,
                                          ZSTD_EndDirective const flushMode)
{
    const char* const istart = (((void)0), (const char*)input->src);
    const char* const iend = (istart != 
# 6109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                       ((void *)0)
# 6109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                           ) ? istart + input->size : istart;
    const char* ip = (istart != 
# 6110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                               ((void *)0)
# 6110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                   ) ? istart + input->pos : istart;
    char* const ostart = (((void)0), (char*)output->dst);
    char* const oend = (ostart != 
# 6112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                 ((void *)0)
# 6112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                     ) ? ostart + output->size : ostart;
    char* op = (ostart != 
# 6113 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                         ((void *)0)
# 6113 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                             ) ? ostart + output->pos : ostart;
    U32 someMoreWork = 1;


    do { } while (0);
    ((void)0);
    if (zcs->appliedParams.inBufferMode == ZSTD_bm_stable) {
        ((void)0);
        input->pos -= zcs->stableIn_notConsumed;
        if (ip) ip -= zcs->stableIn_notConsumed;
        zcs->stableIn_notConsumed = 0;
    }
    if (zcs->appliedParams.inBufferMode == ZSTD_bm_buffered) {
        ((void)0);
        ((void)0);
    }
    if (zcs->appliedParams.outBufferMode == ZSTD_bm_buffered) {
        ((void)0);
        ((void)0);
    }
    if (input->src == 
# 6133 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                     ((void *)0)
# 6133 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                         ) ((void)0);
    ((void)0);
    if (output->dst == 
# 6135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                      ((void *)0)
# 6135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                          ) ((void)0);
    ((void)0);
    ((void)0);

    while (someMoreWork) {
        switch(zcs->streamStage)
        {
        case zcss_init:
            do { do { } while (0); do { if (0) { _force_has_format_string("call ZSTD_initCStream() first!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_init_missing); } while(0);

        case zcss_load:
            if ( (flushMode == ZSTD_e_end)
              && ( (size_t)(oend-op) >= ZSTD_compressBound((size_t)(iend-ip))
                || zcs->appliedParams.outBufferMode == ZSTD_bm_stable)
              && (zcs->inBuffPos == 0) ) {

                size_t const cSize = ZSTD_compressEnd_public(zcs,
                                                op, (size_t)(oend-op),
                                                ip, (size_t)(iend-ip));
                do { } while (0);
                do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressEnd failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                ip = iend;
                op += cSize;
                zcs->frameEnded = 1;
                ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only);
                someMoreWork = 0; break;
            }

            if (zcs->appliedParams.inBufferMode == ZSTD_bm_buffered) {
                size_t const toLoad = zcs->inBuffTarget - zcs->inBuffPos;
                size_t const loaded = ZSTD_limitCopy(
                                        zcs->inBuff + zcs->inBuffPos, toLoad,
                                        ip, (size_t)(iend-ip));
                zcs->inBuffPos += loaded;
                if (ip) ip += loaded;
                if ( (flushMode == ZSTD_e_continue)
                  && (zcs->inBuffPos < zcs->inBuffTarget) ) {

                    someMoreWork = 0; break;
                }
                if ( (flushMode == ZSTD_e_flush)
                  && (zcs->inBuffPos == zcs->inToCompress) ) {

                    someMoreWork = 0; break;
                }
            } else {
                ((void)0);
                if ( (flushMode == ZSTD_e_continue)
                  && ( (size_t)(iend - ip) < zcs->blockSizeMax) ) {

                    zcs->stableIn_notConsumed = (size_t)(iend - ip);
                    ip = iend;
                    someMoreWork = 0; break;
                }
                if ( (flushMode == ZSTD_e_flush)
                  && (ip == iend) ) {

                    someMoreWork = 0; break;
                }
            }

            do { } while (0);
            { int const inputBuffered = (zcs->appliedParams.inBufferMode == ZSTD_bm_buffered);
                void* cDst;
                size_t cSize;
                size_t oSize = (size_t)(oend-op);
                size_t const iSize = inputBuffered ? zcs->inBuffPos - zcs->inToCompress
                                                   : (((size_t)(iend - ip))<(zcs->blockSizeMax) ? ((size_t)(iend - ip)) : (zcs->blockSizeMax));
                if (oSize >= ZSTD_compressBound(iSize) || zcs->appliedParams.outBufferMode == ZSTD_bm_stable)
                    cDst = op;
                else
                    cDst = zcs->outBuff, oSize = zcs->outBuffSize;
                if (inputBuffered) {
                    unsigned const lastBlock = (flushMode == ZSTD_e_end) && (ip==iend);
                    cSize = lastBlock ?
                            ZSTD_compressEnd_public(zcs, cDst, oSize,
                                        zcs->inBuff + zcs->inToCompress, iSize) :
                            ZSTD_compressContinue_public(zcs, cDst, oSize,
                                        zcs->inBuff + zcs->inToCompress, iSize);
                    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("%s", lastBlock ? "ZSTD_compressEnd failed" : "ZSTD_compressContinue failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                    zcs->frameEnded = lastBlock;

                    zcs->inBuffTarget = zcs->inBuffPos + zcs->blockSizeMax;
                    if (zcs->inBuffTarget > zcs->inBuffSize)
                        zcs->inBuffPos = 0, zcs->inBuffTarget = zcs->blockSizeMax;
                    do { } while (0)
                                                                                   ;
                    if (!lastBlock)
                        ((void)0);
                    zcs->inToCompress = zcs->inBuffPos;
                } else {
                    unsigned const lastBlock = (flushMode == ZSTD_e_end) && (ip + iSize == iend);
                    cSize = lastBlock ?
                            ZSTD_compressEnd_public(zcs, cDst, oSize, ip, iSize) :
                            ZSTD_compressContinue_public(zcs, cDst, oSize, ip, iSize);

                    if (ip) ip += iSize;
                    do { size_t const err_code = (cSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("%s", lastBlock ? "ZSTD_compressEnd failed" : "ZSTD_compressContinue failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
                    zcs->frameEnded = lastBlock;
                    if (lastBlock) ((void)0);
                }
                if (cDst == op) {
                    op += cSize;
                    if (zcs->frameEnded) {
                        do { } while (0);
                        someMoreWork = 0;
                        ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only);
                    }
                    break;
                }
                zcs->outBuffContentSize = cSize;
                zcs->outBuffFlushedSize = 0;
                zcs->streamStage = zcss_flush;
            }
     ; __attribute__((__fallthrough__));
        case zcss_flush:
            do { } while (0);
            ((void)0);
            { size_t const toFlush = zcs->outBuffContentSize - zcs->outBuffFlushedSize;
                size_t const flushed = ZSTD_limitCopy(op, (size_t)(oend-op),
                            zcs->outBuff + zcs->outBuffFlushedSize, toFlush);
                do { } while (0)
                                                                                      ;
                if (flushed)
                    op += flushed;
                zcs->outBuffFlushedSize += flushed;
                if (toFlush!=flushed) {

                    ((void)0);
                    someMoreWork = 0;
                    break;
                }
                zcs->outBuffContentSize = zcs->outBuffFlushedSize = 0;
                if (zcs->frameEnded) {
                    do { } while (0);
                    someMoreWork = 0;
                    ZSTD_CCtx_reset(zcs, ZSTD_reset_session_only);
                    break;
                }
                zcs->streamStage = zcss_load;
                break;
            }

        default:
            ((void)0);
        }
    }

    input->pos = (size_t)(ip - istart);
    output->pos = (size_t)(op - ostart);
    if (zcs->frameEnded) return 0;
    return ZSTD_nextInputSizeHint(zcs);
}

static size_t ZSTD_nextInputSizeHint_MTorST(const ZSTD_CCtx* cctx)
{






    return ZSTD_nextInputSizeHint(cctx);

}

size_t ZSTD_compressStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output, ZSTD_inBuffer* input)
{
    do { size_t const err_code = (ZSTD_compressStream2(zcs, output, input, ZSTD_e_continue)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    return ZSTD_nextInputSizeHint_MTorST(zcs);
}




static void
ZSTD_setBufferExpectations(ZSTD_CCtx* cctx, const ZSTD_outBuffer* output, const ZSTD_inBuffer* input)
{
    do { } while (0);
    if (cctx->appliedParams.inBufferMode == ZSTD_bm_stable) {
        cctx->expectedInBuffer = *input;
    }
    if (cctx->appliedParams.outBufferMode == ZSTD_bm_stable) {
        cctx->expectedOutBufferSize = output->size - output->pos;
    }
}




static size_t ZSTD_checkBufferStability(ZSTD_CCtx const* cctx,
                                        ZSTD_outBuffer const* output,
                                        ZSTD_inBuffer const* input,
                                        ZSTD_EndDirective endOp)
{
    if (cctx->appliedParams.inBufferMode == ZSTD_bm_stable) {
        ZSTD_inBuffer const expect = cctx->expectedInBuffer;
        if (expect.src != input->src || expect.pos != input->pos)
            do { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_c_stableInBuffer enabled but input differs!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stabilityCondition_notRespected); } while(0);
    }
    (void)endOp;
    if (cctx->appliedParams.outBufferMode == ZSTD_bm_stable) {
        size_t const outBufferSize = output->size - output->pos;
        if (cctx->expectedOutBufferSize != outBufferSize)
            do { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_c_stableOutBuffer enabled but output size differs!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stabilityCondition_notRespected); } while(0);
    }
    return 0;
}






static size_t ZSTD_CCtx_init_compressStream2(ZSTD_CCtx* cctx,
                                             ZSTD_EndDirective endOp,
                                             size_t inSize)
{
    ZSTD_CCtx_params params = cctx->requestedParams;
    ZSTD_prefixDict const prefixDict = cctx->prefixDict;
    do { size_t const err_code = (ZSTD_initLocalDict(cctx)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    __builtin_memset((&cctx->prefixDict),(0),(sizeof(cctx->prefixDict)));
    ((void)0);
    if (cctx->cdict && !cctx->localDict.cdict) {




        params.compressionLevel = cctx->cdict->compressionLevel;
    }
    do { } while (0);
    if (endOp == ZSTD_e_end) cctx->pledgedSrcSizePlusOne = inSize + 1;

    { size_t const dictSize = prefixDict.dict
                ? prefixDict.dictSize
                : (cctx->cdict ? cctx->cdict->dictContentSize : 0);
        ZSTD_CParamMode_e const mode = ZSTD_getCParamMode(cctx->cdict, &params, cctx->pledgedSrcSizePlusOne - 1);
        params.cParams = ZSTD_getCParamsFromCCtxParams(
                &params, cctx->pledgedSrcSizePlusOne-1,
                dictSize, mode);
    }

    params.postBlockSplitter = ZSTD_resolveBlockSplitterMode(params.postBlockSplitter, &params.cParams);
    params.ldmParams.enableLdm = ZSTD_resolveEnableLdm(params.ldmParams.enableLdm, &params.cParams);
    params.useRowMatchFinder = ZSTD_resolveRowMatchFinderMode(params.useRowMatchFinder, &params.cParams);
    params.validateSequences = ZSTD_resolveExternalSequenceValidation(params.validateSequences);
    params.maxBlockSize = ZSTD_resolveMaxBlockSize(params.maxBlockSize);
    params.searchForExternalRepcodes = ZSTD_resolveExternalRepcodeSearch(params.searchForExternalRepcodes, params.compressionLevel);
# 6420 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    { U64 const pledgedSrcSize = cctx->pledgedSrcSizePlusOne - 1;
        ((void)0);
        do { size_t const err_code = (ZSTD_compressBegin_internal(cctx, prefixDict.dict, prefixDict.dictSize, prefixDict.dictContentType, ZSTD_dtlm_fast, cctx->cdict, &params, pledgedSrcSize, ZSTDb_buffered)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)



                                     ;
        ((void)0);
        cctx->inToCompress = 0;
        cctx->inBuffPos = 0;
        if (cctx->appliedParams.inBufferMode == ZSTD_bm_buffered) {



            cctx->inBuffTarget = cctx->blockSizeMax + (cctx->blockSizeMax == pledgedSrcSize);
        } else {
            cctx->inBuffTarget = 0;
        }
        cctx->outBuffContentSize = cctx->outBuffFlushedSize = 0;
        cctx->streamStage = zcss_load;
        cctx->frameEnded = 0;
    }
    return 0;
}



size_t ZSTD_compressStream2( ZSTD_CCtx* cctx,
                             ZSTD_outBuffer* output,
                             ZSTD_inBuffer* input,
                             ZSTD_EndDirective endOp)
{
    do { } while (0);

    do { if (output->pos > output->size) { do { } while (0); do { if (0) { _force_has_format_string("invalid output buffer"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
    do { if (input->pos > input->size) { do { } while (0); do { if (0) { _force_has_format_string("invalid input buffer"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_srcSize_wrong); } } while (0);
    do { if ((U32)endOp > (U32)ZSTD_e_end) { do { } while (0); do { if (0) { _force_has_format_string("invalid endDirective"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_outOfBound); } } while (0);
    ((void)0);


    if (cctx->streamStage == zcss_init) {
        size_t const inputSize = input->size - input->pos;
        size_t const totalInputSize = inputSize + cctx->stableIn_notConsumed;
        if ( (cctx->requestedParams.inBufferMode == ZSTD_bm_stable)
          && (endOp == ZSTD_e_continue)
          && (totalInputSize < (1<<17)) ) {
            if (cctx->stableIn_notConsumed) {

                do { if (input->src != cctx->expectedInBuffer.src) { do { } while (0); do { if (0) { _force_has_format_string("stableInBuffer condition not respected: wrong src pointer"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stabilityCondition_notRespected); } } while (0);
                do { if (input->pos != cctx->expectedInBuffer.size) { do { } while (0); do { if (0) { _force_has_format_string("stableInBuffer condition not respected: externally modified pos"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_stabilityCondition_notRespected); } } while (0);
            }

            input->pos = input->size;

            cctx->expectedInBuffer = *input;

            cctx->stableIn_notConsumed += inputSize;

            return ((cctx->requestedParams.format) == ZSTD_f_zstd1 ? 6 : 2);
        }
        do { size_t const err_code = (ZSTD_CCtx_init_compressStream2(cctx, endOp, totalInputSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("compressStream2 initialization failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ZSTD_setBufferExpectations(cctx, output, input);
    }


    do { size_t const err_code = (ZSTD_checkBufferStability(cctx, output, input, endOp)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("invalid buffers"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
# 6540 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
    do { size_t const err_code = (ZSTD_compressStream_generic(cctx, output, input, endOp)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    do { } while (0);
    ZSTD_setBufferExpectations(cctx, output, input);
    return cctx->outBuffContentSize - cctx->outBuffFlushedSize;
}

size_t ZSTD_compressStream2_simpleArgs (
                            ZSTD_CCtx* cctx,
                            void* dst, size_t dstCapacity, size_t* dstPos,
                      const void* src, size_t srcSize, size_t* srcPos,
                            ZSTD_EndDirective endOp)
{
    ZSTD_outBuffer output;
    ZSTD_inBuffer input;
    output.dst = dst;
    output.size = dstCapacity;
    output.pos = *dstPos;
    input.src = src;
    input.size = srcSize;
    input.pos = *srcPos;

    { size_t const cErr = ZSTD_compressStream2(cctx, &output, &input, endOp);
        *dstPos = output.pos;
        *srcPos = input.pos;
        return cErr;
    }
}

size_t ZSTD_compress2(ZSTD_CCtx* cctx,
                      void* dst, size_t dstCapacity,
                      const void* src, size_t srcSize)
{
    ZSTD_bufferMode_e const originalInBufferMode = cctx->requestedParams.inBufferMode;
    ZSTD_bufferMode_e const originalOutBufferMode = cctx->requestedParams.outBufferMode;
    do { } while (0);
    ZSTD_CCtx_reset(cctx, ZSTD_reset_session_only);

    cctx->requestedParams.inBufferMode = ZSTD_bm_stable;
    cctx->requestedParams.outBufferMode = ZSTD_bm_stable;
    { size_t oPos = 0;
        size_t iPos = 0;
        size_t const result = ZSTD_compressStream2_simpleArgs(cctx,
                                        dst, dstCapacity, &oPos,
                                        src, srcSize, &iPos,
                                        ZSTD_e_end);

        cctx->requestedParams.inBufferMode = originalInBufferMode;
        cctx->requestedParams.outBufferMode = originalOutBufferMode;

        do { size_t const err_code = (result); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressStream2_simpleArgs failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        if (result != 0) {
            ((void)0);
            do { do { } while (0); do { if (0) { _force_has_format_string(""); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } while(0);
        }
        ((void)0);
        return oPos;
    }
}





static size_t
ZSTD_validateSequence(U32 offBase, U32 matchLength, U32 minMatch,
                      size_t posInSrc, U32 windowLog, size_t dictSize, int useSequenceProducer)
{
    U32 const windowSize = 1u << windowLog;





    size_t const offsetBound = posInSrc > windowSize ? (size_t)windowSize : posInSrc + (size_t)dictSize;
    size_t const matchLenLowerBound = (minMatch == 3 || useSequenceProducer) ? 3 : 4;
    do { if (offBase > (((void)0), offsetBound + 3)) { do { } while (0); do { if (0) { _force_has_format_string("Offset too large!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);

    do { if (matchLength < matchLenLowerBound) { do { } while (0); do { if (0) { _force_has_format_string("Matchlength too small for the minMatch"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);
    return 0;
}


static U32 ZSTD_finalizeOffBase(U32 rawOffset, const U32 rep[3], U32 ll0)
{
    U32 offBase = (((void)0), rawOffset + 3);

    if (!ll0 && rawOffset == rep[0]) {
        offBase = (((void)0), ((void)0), (1));
    } else if (rawOffset == rep[1]) {
        offBase = (((void)0), ((void)0), (2 - ll0));
    } else if (rawOffset == rep[2]) {
        offBase = (((void)0), ((void)0), (3 - ll0));
    } else if (ll0 && rawOffset == rep[0] - 1) {
        offBase = (((void)0), ((void)0), (3));
    }
    return offBase;
}







static size_t
ZSTD_transferSequences_wBlockDelim(ZSTD_CCtx* cctx,
                                   ZSTD_SequencePosition* seqPos,
                             const ZSTD_Sequence* const inSeqs, size_t inSeqsSize,
                             const void* src, size_t blockSize,
                                   ZSTD_ParamSwitch_e externalRepSearch)
{
    U32 idx = seqPos->idx;
    U32 const startIdx = idx;
    BYTE const* ip = (BYTE const*)(src);
    const BYTE* const iend = ip + blockSize;
    Repcodes_t updatedRepcodes;
    U32 dictSize;

    do { } while (0);

    if (cctx->cdict) {
        dictSize = (U32)cctx->cdict->dictContentSize;
    } else if (cctx->prefixDict.dict) {
        dictSize = (U32)cctx->prefixDict.dictSize;
    } else {
        dictSize = 0;
    }
    __builtin_memcpy((updatedRepcodes.rep),(cctx->blockState.prevCBlock->rep),(sizeof(Repcodes_t)));
    for (; idx < inSeqsSize && (inSeqs[idx].matchLength != 0 || inSeqs[idx].offset != 0); ++idx) {
        U32 const litLength = inSeqs[idx].litLength;
        U32 const matchLength = inSeqs[idx].matchLength;
        U32 offBase;

        if (externalRepSearch == ZSTD_ps_disable) {
            offBase = (((void)0), inSeqs[idx].offset + 3);
        } else {
            U32 const ll0 = (litLength == 0);
            offBase = ZSTD_finalizeOffBase(inSeqs[idx].offset, updatedRepcodes.rep, ll0);
            ZSTD_updateRep(updatedRepcodes.rep, offBase, ll0);
        }

        do { } while (0);
        if (cctx->appliedParams.validateSequences) {
            seqPos->posInSrc += litLength + matchLength;
            do { size_t const err_code = (ZSTD_validateSequence(offBase, matchLength, cctx->appliedParams.cParams.minMatch, seqPos->posInSrc, cctx->appliedParams.cParams.windowLog, dictSize, ZSTD_hasExtSeqProd(&cctx->appliedParams))); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Sequence validation failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)



                                                                             ;
        }
        do { if (idx - seqPos->idx >= cctx->seqStore.maxNbSeq) { do { } while (0); do { if (0) { _force_has_format_string("Not enough memory allocated. Try adjusting ZSTD_c_minMatch."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0)
                                                                                      ;
        ZSTD_storeSeq(&cctx->seqStore, litLength, ip, iend, offBase, matchLength);
        ip += matchLength + litLength;
    }
    do { if (idx == inSeqsSize) { do { } while (0); do { if (0) { _force_has_format_string("Block delimiter not found."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);


    ((void)0);
    ((void)0);
    if (externalRepSearch == ZSTD_ps_disable && idx != startIdx) {
        U32* const rep = updatedRepcodes.rep;
        U32 lastSeqIdx = idx - 1;

        if (lastSeqIdx >= startIdx + 2) {
            rep[2] = inSeqs[lastSeqIdx - 2].offset;
            rep[1] = inSeqs[lastSeqIdx - 1].offset;
            rep[0] = inSeqs[lastSeqIdx].offset;
        } else if (lastSeqIdx == startIdx + 1) {
            rep[2] = rep[0];
            rep[1] = inSeqs[lastSeqIdx - 1].offset;
            rep[0] = inSeqs[lastSeqIdx].offset;
        } else {
            ((void)0);
            rep[2] = rep[1];
            rep[1] = rep[0];
            rep[0] = inSeqs[lastSeqIdx].offset;
        }
    }

    __builtin_memcpy((cctx->blockState.nextCBlock->rep),(updatedRepcodes.rep),(sizeof(Repcodes_t)));

    if (inSeqs[idx].litLength) {
        do { } while (0);
        ZSTD_storeLastLiterals(&cctx->seqStore, ip, inSeqs[idx].litLength);
        ip += inSeqs[idx].litLength;
        seqPos->posInSrc += inSeqs[idx].litLength;
    }
    do { if (ip != iend) { do { } while (0); do { if (0) { _force_has_format_string("Blocksize doesn't agree with block delimiter!"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);
    seqPos->idx = idx+1;
    return blockSize;
}
# 6744 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static size_t
ZSTD_transferSequences_noDelim(ZSTD_CCtx* cctx,
                               ZSTD_SequencePosition* seqPos,
                         const ZSTD_Sequence* const inSeqs, size_t inSeqsSize,
                         const void* src, size_t blockSize,
                               ZSTD_ParamSwitch_e externalRepSearch)
{
    U32 idx = seqPos->idx;
    U32 startPosInSequence = seqPos->posInSequence;
    U32 endPosInSequence = seqPos->posInSequence + (U32)blockSize;
    size_t dictSize;
    const BYTE* const istart = (const BYTE*)(src);
    const BYTE* ip = istart;
    const BYTE* iend = istart + blockSize;
    Repcodes_t updatedRepcodes;
    U32 bytesAdjustment = 0;
    U32 finalMatchSplit = 0;


    (void)externalRepSearch;

    if (cctx->cdict) {
        dictSize = cctx->cdict->dictContentSize;
    } else if (cctx->prefixDict.dict) {
        dictSize = cctx->prefixDict.dictSize;
    } else {
        dictSize = 0;
    }
    do { } while (0);
    do { } while (0);
    __builtin_memcpy((updatedRepcodes.rep),(cctx->blockState.prevCBlock->rep),(sizeof(Repcodes_t)));
    while (endPosInSequence && idx < inSeqsSize && !finalMatchSplit) {
        const ZSTD_Sequence currSeq = inSeqs[idx];
        U32 litLength = currSeq.litLength;
        U32 matchLength = currSeq.matchLength;
        U32 const rawOffset = currSeq.offset;
        U32 offBase;


        if (endPosInSequence >= currSeq.litLength + currSeq.matchLength) {
            if (startPosInSequence >= litLength) {
                startPosInSequence -= litLength;
                litLength = 0;
                matchLength -= startPosInSequence;
            } else {
                litLength -= startPosInSequence;
            }

            endPosInSequence -= currSeq.litLength + currSeq.matchLength;
            startPosInSequence = 0;
        } else {


            do { } while (0)
                                                                                                       ;
            if (endPosInSequence > litLength) {
                U32 firstHalfMatchLength;
                litLength = startPosInSequence >= litLength ? 0 : litLength - startPosInSequence;
                firstHalfMatchLength = endPosInSequence - startPosInSequence - litLength;
                if (matchLength > blockSize && firstHalfMatchLength >= cctx->appliedParams.cParams.minMatch) {

                    U32 secondHalfMatchLength = currSeq.matchLength + currSeq.litLength - endPosInSequence;
                    if (secondHalfMatchLength < cctx->appliedParams.cParams.minMatch) {

                        endPosInSequence -= cctx->appliedParams.cParams.minMatch - secondHalfMatchLength;
                        bytesAdjustment = cctx->appliedParams.cParams.minMatch - secondHalfMatchLength;
                        firstHalfMatchLength -= bytesAdjustment;
                    }
                    matchLength = firstHalfMatchLength;


                    finalMatchSplit = 1;
                } else {





                    bytesAdjustment = endPosInSequence - currSeq.litLength;
                    endPosInSequence = currSeq.litLength;
                    break;
                }
            } else {

                break;
            }
        }

        { U32 const ll0 = (litLength == 0);
            offBase = ZSTD_finalizeOffBase(rawOffset, updatedRepcodes.rep, ll0);
            ZSTD_updateRep(updatedRepcodes.rep, offBase, ll0);
        }

        if (cctx->appliedParams.validateSequences) {
            seqPos->posInSrc += litLength + matchLength;
            do { size_t const err_code = (ZSTD_validateSequence(offBase, matchLength, cctx->appliedParams.cParams.minMatch, seqPos->posInSrc, cctx->appliedParams.cParams.windowLog, dictSize, ZSTD_hasExtSeqProd(&cctx->appliedParams))); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Sequence validation failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0)

                                                                                ;
        }
        do { } while (0);
        do { if (idx - seqPos->idx >= cctx->seqStore.maxNbSeq) { do { } while (0); do { if (0) { _force_has_format_string("Not enough memory allocated. Try adjusting ZSTD_c_minMatch."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0)
                                                                                      ;
        ZSTD_storeSeq(&cctx->seqStore, litLength, ip, iend, offBase, matchLength);
        ip += matchLength + litLength;
        if (!finalMatchSplit)
            idx++;
    }
    do { } while (0);
    ((void)0);
    seqPos->idx = idx;
    seqPos->posInSequence = endPosInSequence;
    __builtin_memcpy((cctx->blockState.nextCBlock->rep),(updatedRepcodes.rep),(sizeof(Repcodes_t)));

    iend -= bytesAdjustment;
    if (ip != iend) {

        U32 const lastLLSize = (U32)(iend - ip);
        ((void)0);
        do { } while (0);
        ZSTD_storeLastLiterals(&cctx->seqStore, ip, lastLLSize);
        seqPos->posInSrc += lastLLSize;
    }

    return (size_t)(iend-istart);
}






typedef size_t (*ZSTD_SequenceCopier_f)(ZSTD_CCtx* cctx,
                                        ZSTD_SequencePosition* seqPos,
                                  const ZSTD_Sequence* const inSeqs, size_t inSeqsSize,
                                  const void* src, size_t blockSize,
                                        ZSTD_ParamSwitch_e externalRepSearch);

static ZSTD_SequenceCopier_f ZSTD_selectSequenceCopier(ZSTD_SequenceFormat_e mode)
{
    ((void)0);
    if (mode == ZSTD_sf_explicitBlockDelimiters) {
        return ZSTD_transferSequences_wBlockDelim;
    }
    ((void)0);
    return ZSTD_transferSequences_noDelim;
}





static size_t
blockSize_explicitDelimiter(const ZSTD_Sequence* inSeqs, size_t inSeqsSize, ZSTD_SequencePosition seqPos)
{
    int end = 0;
    size_t blockSize = 0;
    size_t spos = seqPos.idx;
    do { } while (0);
    ((void)0);
    while (spos < inSeqsSize) {
        end = (inSeqs[spos].offset == 0);
        blockSize += inSeqs[spos].litLength + inSeqs[spos].matchLength;
        if (end) {
            if (inSeqs[spos].matchLength != 0)
                do { do { } while (0); do { if (0) { _force_has_format_string("delimiter format error : both matchlength and offset must be == 0"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } while(0);
            break;
        }
        spos++;
    }
    if (!end)
        do { do { } while (0); do { if (0) { _force_has_format_string("Reached end of sequences without finding a block delimiter"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } while(0);
    return blockSize;
}

static size_t determine_blockSize(ZSTD_SequenceFormat_e mode,
                           size_t blockSize, size_t remaining,
                     const ZSTD_Sequence* inSeqs, size_t inSeqsSize,
                           ZSTD_SequencePosition seqPos)
{
    do { } while (0);
    if (mode == ZSTD_sf_noBlockDelimiters) {

        return ((remaining)<(blockSize) ? (remaining) : (blockSize));
    }
    ((void)0);
    { size_t const explicitBlockSize = blockSize_explicitDelimiter(inSeqs, inSeqsSize, seqPos);
        do { size_t const err_code = (explicitBlockSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Error while determining block size with explicit delimiters"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        if (explicitBlockSize > blockSize)
            do { do { } while (0); do { if (0) { _force_has_format_string("sequences incorrectly define a too large block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } while(0);
        if (explicitBlockSize > remaining)
            do { do { } while (0); do { if (0) { _force_has_format_string("sequences define a frame longer than source"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } while(0);
        return explicitBlockSize;
    }
}






static size_t
ZSTD_compressSequences_internal(ZSTD_CCtx* cctx,
                                void* dst, size_t dstCapacity,
                          const ZSTD_Sequence* inSeqs, size_t inSeqsSize,
                          const void* src, size_t srcSize)
{
    size_t cSize = 0;
    size_t remaining = srcSize;
    ZSTD_SequencePosition seqPos = {0, 0, 0};

    const BYTE* ip = (BYTE const*)src;
    BYTE* op = (BYTE*)dst;
    ZSTD_SequenceCopier_f const sequenceCopier = ZSTD_selectSequenceCopier(cctx->appliedParams.blockDelimiters);

    do { } while (0);

    if (remaining == 0) {
        U32 const cBlockHeader24 = 1 + (((U32)bt_raw)<<1);
        do { if (dstCapacity<4) { do { } while (0); do { if (0) { _force_has_format_string("No room for empty frame block header"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
        MEM_writeLE32(op, cBlockHeader24);
        op += ZSTD_blockHeaderSize;
        dstCapacity -= ZSTD_blockHeaderSize;
        cSize += ZSTD_blockHeaderSize;
    }

    while (remaining) {
        size_t compressedSeqsSize;
        size_t cBlockSize;
        size_t blockSize = determine_blockSize(cctx->appliedParams.blockDelimiters,
                                        cctx->blockSizeMax, remaining,
                                        inSeqs, inSeqsSize, seqPos);
        U32 const lastBlock = (blockSize == remaining);
        do { size_t const err_code = (blockSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Error while trying to determine block size"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ((void)0);
        ZSTD_resetSeqStore(&cctx->seqStore);

        blockSize = sequenceCopier(cctx,
                                   &seqPos, inSeqs, inSeqsSize,
                                   ip, blockSize,
                                   cctx->appliedParams.searchForExternalRepcodes);
        do { size_t const err_code = (blockSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Bad sequence copy"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);




        if (blockSize < (1 + 1 )+ZSTD_blockHeaderSize+1+1) {
            cBlockSize = ZSTD_noCompressBlock(op, dstCapacity, ip, blockSize, lastBlock);
            do { size_t const err_code = (cBlockSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Nocompress block failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
            do { } while (0);
            cSize += cBlockSize;
            ip += blockSize;
            op += cBlockSize;
            remaining -= blockSize;
            dstCapacity -= cBlockSize;
            continue;
        }

        do { if (dstCapacity < ZSTD_blockHeaderSize) { do { } while (0); do { if (0) { _force_has_format_string("not enough dstCapacity to write a new compressed block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
        compressedSeqsSize = ZSTD_entropyCompressSeqStore(&cctx->seqStore,
                                &cctx->blockState.prevCBlock->entropy, &cctx->blockState.nextCBlock->entropy,
                                &cctx->appliedParams,
                                op + ZSTD_blockHeaderSize , dstCapacity - ZSTD_blockHeaderSize,
                                blockSize,
                                cctx->tmpWorkspace, cctx->tmpWkspSize ,
                                cctx->bmi2);
        do { size_t const err_code = (compressedSeqsSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Compressing sequences of block failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        do { } while (0);

        if (!cctx->isFirstBlock &&
            ZSTD_maybeRLE(&cctx->seqStore) &&
            ZSTD_isRLE(ip, blockSize)) {




            compressedSeqsSize = 1;
        }

        if (compressedSeqsSize == 0) {

            cBlockSize = ZSTD_noCompressBlock(op, dstCapacity, ip, blockSize, lastBlock);
            do { size_t const err_code = (cBlockSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_noCompressBlock failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
            do { } while (0);
        } else if (compressedSeqsSize == 1) {
            cBlockSize = ZSTD_rleCompressBlock(op, dstCapacity, *ip, blockSize, lastBlock);
            do { size_t const err_code = (cBlockSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_rleCompressBlock failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
            do { } while (0);
        } else {
            U32 cBlockHeader;

            ZSTD_blockState_confirmRepcodesAndEntropyTables(&cctx->blockState);
            if (cctx->blockState.prevCBlock->entropy.fse.offcode_repeatMode == FSE_repeat_valid)
                cctx->blockState.prevCBlock->entropy.fse.offcode_repeatMode = FSE_repeat_check;


            cBlockHeader = lastBlock + (((U32)bt_compressed)<<1) + (U32)(compressedSeqsSize << 3);
            MEM_writeLE24(op, cBlockHeader);
            cBlockSize = ZSTD_blockHeaderSize + compressedSeqsSize;
            do { } while (0);
        }

        cSize += cBlockSize;

        if (lastBlock) {
            break;
        } else {
            ip += blockSize;
            op += cBlockSize;
            remaining -= blockSize;
            dstCapacity -= cBlockSize;
            cctx->isFirstBlock = 0;
        }
        do { } while (0);
    }

    do { } while (0);
    return cSize;
}

size_t ZSTD_compressSequences(ZSTD_CCtx* cctx,
                              void* dst, size_t dstCapacity,
                              const ZSTD_Sequence* inSeqs, size_t inSeqsSize,
                              const void* src, size_t srcSize)
{
    BYTE* op = (BYTE*)dst;
    size_t cSize = 0;


    do { } while (0);
    ((void)0);
    do { size_t const err_code = (ZSTD_CCtx_init_compressStream2(cctx, ZSTD_e_end, srcSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("CCtx initialization failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);


    { size_t const frameHeaderSize = ZSTD_writeFrameHeader(op, dstCapacity,
                    &cctx->appliedParams, srcSize, cctx->dictID);
        op += frameHeaderSize;
        ((void)0);
        dstCapacity -= frameHeaderSize;
        cSize += frameHeaderSize;
    }
    if (cctx->appliedParams.fParams.checksumFlag && srcSize) {
        ZSTD_XXH64_update(&cctx->xxhState, src, srcSize);
    }


    { size_t const cBlocksSize = ZSTD_compressSequences_internal(cctx,
                                                           op, dstCapacity,
                                                           inSeqs, inSeqsSize,
                                                           src, srcSize);
        do { size_t const err_code = (cBlocksSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Compressing blocks failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        cSize += cBlocksSize;
        ((void)0);
        dstCapacity -= cBlocksSize;
    }


    if (cctx->appliedParams.fParams.checksumFlag) {
        U32 const checksum = (U32) ZSTD_XXH64_digest(&cctx->xxhState);
        do { if (dstCapacity<4) { do { } while (0); do { if (0) { _force_has_format_string("no room for checksum"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
        do { } while (0);
        MEM_writeLE32((char*)dst + cSize, checksum);
        cSize += 4;
    }

    do { } while (0);
    return cSize;
}
# 7285 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
static size_t convertSequences_noRepcodes(
    SeqDef* dstSeqs,
    const ZSTD_Sequence* inSeqs,
    size_t nbSequences)
{
    size_t longLen = 0;
    size_t n;
    for (n=0; n<nbSequences; n++) {
        dstSeqs[n].offBase = (((void)0), inSeqs[n].offset + 3);
        dstSeqs[n].litLength = (U16)inSeqs[n].litLength;
        dstSeqs[n].mlBase = (U16)(inSeqs[n].matchLength - 3);

        if ((__builtin_expect((inSeqs[n].matchLength > 65535+3), 0))) {
            ((void)0);
            longLen = n + 1;
        }
        if ((__builtin_expect((inSeqs[n].litLength > 65535), 0))) {
            ((void)0);
            longLen = n + nbSequences + 1;
        }
    }
    return longLen;
}
# 7318 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
size_t ZSTD_convertBlockSequences(ZSTD_CCtx* cctx,
                const ZSTD_Sequence* const inSeqs, size_t nbSequences,
                int repcodeResolution)
{
    Repcodes_t updatedRepcodes;
    size_t seqNb = 0;

    do { } while (0);

    do { if (nbSequences >= cctx->seqStore.maxNbSeq) { do { } while (0); do { if (0) { _force_has_format_string("Not enough memory allocated. Try adjusting ZSTD_c_minMatch."); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0)
                                                                                  ;

    __builtin_memcpy((updatedRepcodes.rep),(cctx->blockState.prevCBlock->rep),(sizeof(Repcodes_t)));


    ((void)0);
    ((void)0);
    ((void)0);


    if (!repcodeResolution) {
        size_t const longl = convertSequences_noRepcodes(cctx->seqStore.sequencesStart, inSeqs, nbSequences-1);
        cctx->seqStore.sequences = cctx->seqStore.sequencesStart + nbSequences-1;
        if (longl) {
            do { } while (0);
            ((void)0);
            if (longl <= nbSequences-1) {
                do { } while (0);
                cctx->seqStore.longLengthType = ZSTD_llt_matchLength;
                cctx->seqStore.longLengthPos = (U32)(longl-1);
            } else {
                do { } while (0);
                ((void)0);
                cctx->seqStore.longLengthType = ZSTD_llt_literalLength;
                cctx->seqStore.longLengthPos = (U32)(longl-(nbSequences-1)-1);
            }
        }
    } else {
        for (seqNb = 0; seqNb < nbSequences - 1 ; seqNb++) {
            U32 const litLength = inSeqs[seqNb].litLength;
            U32 const matchLength = inSeqs[seqNb].matchLength;
            U32 const ll0 = (litLength == 0);
            U32 const offBase = ZSTD_finalizeOffBase(inSeqs[seqNb].offset, updatedRepcodes.rep, ll0);

            do { } while (0);
            ZSTD_storeSeqOnly(&cctx->seqStore, litLength, offBase, matchLength);
            ZSTD_updateRep(updatedRepcodes.rep, offBase, ll0);
        }
    }


    if (!repcodeResolution && nbSequences > 1) {
        U32* const rep = updatedRepcodes.rep;

        if (nbSequences >= 4) {
            U32 lastSeqIdx = (U32)nbSequences - 2;
            rep[2] = inSeqs[lastSeqIdx - 2].offset;
            rep[1] = inSeqs[lastSeqIdx - 1].offset;
            rep[0] = inSeqs[lastSeqIdx].offset;
        } else if (nbSequences == 3) {
            rep[2] = rep[0];
            rep[1] = inSeqs[0].offset;
            rep[0] = inSeqs[1].offset;
        } else {
            ((void)0);
            rep[2] = rep[1];
            rep[1] = rep[0];
            rep[0] = inSeqs[0].offset;
        }
    }

    __builtin_memcpy((cctx->blockState.nextCBlock->rep),(updatedRepcodes.rep),(sizeof(Repcodes_t)));

    return 0;
}
# 7448 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
BlockSummary ZSTD_get1BlockSummary(const ZSTD_Sequence* seqs, size_t nbSeqs)
{
    size_t totalMatchSize = 0;
    size_t litSize = 0;
    size_t n;
    ((void)0);
    for (n=0; n<nbSeqs; n++) {
        totalMatchSize += seqs[n].matchLength;
        litSize += seqs[n].litLength;
        if (seqs[n].matchLength == 0) {
            ((void)0);
            break;
        }
    }
    if (n==nbSeqs) {
        BlockSummary bs;
        bs.nbSequences = ((size_t)-ZSTD_error_externalSequences_invalid);
        return bs;
    }
    { BlockSummary bs;
        bs.nbSequences = n+1;
        bs.blockSize = litSize + totalMatchSize;
        bs.litSize = litSize;
        return bs;
    }
}



static size_t
ZSTD_compressSequencesAndLiterals_internal(ZSTD_CCtx* cctx,
                                void* dst, size_t dstCapacity,
                          const ZSTD_Sequence* inSeqs, size_t nbSequences,
                          const void* literals, size_t litSize, size_t srcSize)
{
    size_t remaining = srcSize;
    size_t cSize = 0;
    BYTE* op = (BYTE*)dst;
    int const repcodeResolution = (cctx->appliedParams.searchForExternalRepcodes == ZSTD_ps_enable);
    ((void)0);

    do { } while (0);
    do { if (nbSequences == 0) { do { } while (0); do { if (0) { _force_has_format_string("Requires at least 1 end-of-block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);


    if ((nbSequences == 1) && (inSeqs[0].litLength == 0)) {
        U32 const cBlockHeader24 = 1 + (((U32)bt_raw)<<1);
        do { if (dstCapacity<3) { do { } while (0); do { if (0) { _force_has_format_string("No room for empty frame block header"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);
        MEM_writeLE24(op, cBlockHeader24);
        op += ZSTD_blockHeaderSize;
        dstCapacity -= ZSTD_blockHeaderSize;
        cSize += ZSTD_blockHeaderSize;
    }

    while (nbSequences) {
        size_t compressedSeqsSize, cBlockSize, conversionStatus;
        BlockSummary const block = ZSTD_get1BlockSummary(inSeqs, nbSequences);
        U32 const lastBlock = (block.nbSequences == nbSequences);
        do { size_t const err_code = (block.nbSequences); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Error while trying to determine nb of sequences for a block"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        ((void)0);
        do { if (block.litSize > litSize) { do { } while (0); do { if (0) { _force_has_format_string("discrepancy: Sequences require more literals than present in buffer"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);
        ZSTD_resetSeqStore(&cctx->seqStore);

        conversionStatus = ZSTD_convertBlockSequences(cctx,
                            inSeqs, block.nbSequences,
                            repcodeResolution);
        do { size_t const err_code = (conversionStatus); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Bad sequence conversion"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        inSeqs += block.nbSequences;
        nbSequences -= block.nbSequences;
        remaining -= block.blockSize;






        do { if (dstCapacity < ZSTD_blockHeaderSize) { do { } while (0); do { if (0) { _force_has_format_string("not enough dstCapacity to write a new compressed block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_dstSize_tooSmall); } } while (0);

        compressedSeqsSize = ZSTD_entropyCompressSeqStore_internal(
                                op + ZSTD_blockHeaderSize , dstCapacity - ZSTD_blockHeaderSize,
                                literals, block.litSize,
                                &cctx->seqStore,
                                &cctx->blockState.prevCBlock->entropy, &cctx->blockState.nextCBlock->entropy,
                                &cctx->appliedParams,
                                cctx->tmpWorkspace, cctx->tmpWkspSize ,
                                cctx->bmi2);
        do { size_t const err_code = (compressedSeqsSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Compressing sequences of block failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

        if (compressedSeqsSize > cctx->blockSizeMax) compressedSeqsSize = 0;
        do { } while (0);
        litSize -= block.litSize;
        literals = (const char*)literals + block.litSize;




        if (compressedSeqsSize == 0) {





            do { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressSequencesAndLiterals cannot generate an uncompressed block"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_cannotProduce_uncompressedBlock); } while(0);
        } else {
            U32 cBlockHeader;
            ((void)0);

            ZSTD_blockState_confirmRepcodesAndEntropyTables(&cctx->blockState);
            if (cctx->blockState.prevCBlock->entropy.fse.offcode_repeatMode == FSE_repeat_valid)
                cctx->blockState.prevCBlock->entropy.fse.offcode_repeatMode = FSE_repeat_check;


            cBlockHeader = lastBlock + (((U32)bt_compressed)<<1) + (U32)(compressedSeqsSize << 3);
            MEM_writeLE24(op, cBlockHeader);
            cBlockSize = ZSTD_blockHeaderSize + compressedSeqsSize;
            do { } while (0);
        }

        cSize += cBlockSize;
        op += cBlockSize;
        dstCapacity -= cBlockSize;
        cctx->isFirstBlock = 0;
        do { } while (0);

        if (lastBlock) {
            ((void)0);
            break;
        }
    }

    do { if (litSize != 0) { do { } while (0); do { if (0) { _force_has_format_string("literals must be entirely and exactly consumed"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);
    do { if (remaining != 0) { do { } while (0); do { if (0) { _force_has_format_string("Sequences must represent a total of exactly srcSize=%zu", srcSize); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_externalSequences_invalid); } } while (0);
    do { } while (0);
    return cSize;
}

size_t
ZSTD_compressSequencesAndLiterals(ZSTD_CCtx* cctx,
                    void* dst, size_t dstCapacity,
                    const ZSTD_Sequence* inSeqs, size_t inSeqsSize,
                    const void* literals, size_t litSize, size_t litCapacity,
                    size_t decompressedSize)
{
    BYTE* op = (BYTE*)dst;
    size_t cSize = 0;


    do { } while (0);
    ((void)0);
    if (litCapacity < litSize) {
        do { do { } while (0); do { if (0) { _force_has_format_string("literals buffer is not large enough: must be at least 8 bytes larger than litSize (risk of read out-of-bound)"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_workSpace_tooSmall); } while(0);
    }
    do { size_t const err_code = (ZSTD_CCtx_init_compressStream2(cctx, ZSTD_e_end, decompressedSize)); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("CCtx initialization failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);

    if (cctx->appliedParams.blockDelimiters == ZSTD_sf_noBlockDelimiters) {
        do { do { } while (0); do { if (0) { _force_has_format_string("This mode is only compatible with explicit delimiters"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_frameParameter_unsupported); } while(0);
    }
    if (cctx->appliedParams.validateSequences) {
        do { do { } while (0); do { if (0) { _force_has_format_string("This mode is not compatible with Sequence validation"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_parameter_unsupported); } while(0);
    }
    if (cctx->appliedParams.fParams.checksumFlag) {
        do { do { } while (0); do { if (0) { _force_has_format_string("this mode is not compatible with frame checksum"); } } while (0); do { } while (0); do { } while (0); return ((size_t)-ZSTD_error_frameParameter_unsupported); } while(0);
    }


    { size_t const frameHeaderSize = ZSTD_writeFrameHeader(op, dstCapacity,
                    &cctx->appliedParams, decompressedSize, cctx->dictID);
        op += frameHeaderSize;
        ((void)0);
        dstCapacity -= frameHeaderSize;
        cSize += frameHeaderSize;
    }


    { size_t const cBlocksSize = ZSTD_compressSequencesAndLiterals_internal(cctx,
                                            op, dstCapacity,
                                            inSeqs, inSeqsSize,
                                            literals, litSize, decompressedSize);
        do { size_t const err_code = (cBlocksSize); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("Compressing blocks failed!"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
        cSize += cBlocksSize;
        ((void)0);
        dstCapacity -= cBlocksSize;
    }

    do { } while (0);
    return cSize;
}



static ZSTD_inBuffer inBuffer_forEndFlush(const ZSTD_CStream* zcs)
{
    const ZSTD_inBuffer nullInput = { 
# 7640 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                     ((void *)0)
# 7640 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                         , 0, 0 };
    const int stableInput = (zcs->appliedParams.inBufferMode == ZSTD_bm_stable);
    return stableInput ? zcs->expectedInBuffer : nullInput;
}



size_t ZSTD_flushStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output)
{
    ZSTD_inBuffer input = inBuffer_forEndFlush(zcs);
    input.size = input.pos;
    return ZSTD_compressStream2(zcs, output, &input, ZSTD_e_flush);
}

size_t ZSTD_endStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output)
{
    ZSTD_inBuffer input = inBuffer_forEndFlush(zcs);
    size_t const remainingToFlush = ZSTD_compressStream2(zcs, output, &input, ZSTD_e_end);
    do { size_t const err_code = (remainingToFlush); if (ERR_isError(err_code)) { do { } while (0); do { if (0) { _force_has_format_string("ZSTD_compressStream2(,,ZSTD_e_end) failed"); } } while (0); do { } while (0); do { } while (0); return err_code; } } while(0);
    if (zcs->appliedParams.nbWorkers > 0) return remainingToFlush;

    { size_t const lastBlockSize = zcs->frameEnded ? 0 : 3;
        size_t const checksumSize = (size_t)(zcs->frameEnded ? 0 : zcs->appliedParams.fParams.checksumFlag * 4);
        size_t const toFlush = remainingToFlush + lastBlockSize + checksumSize;
        do { } while (0);
        return toFlush;
    }
}



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/clevels.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/clevels.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/../zstd.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/clevels.h" 2






__attribute__((__unused__))


static const ZSTD_compressionParameters ZSTD_defaultCParameters[4][22 +1] = {
{

    { 19, 12, 13, 1, 6, 1, ZSTD_fast },
    { 19, 13, 14, 1, 7, 0, ZSTD_fast },
    { 20, 15, 16, 1, 6, 0, ZSTD_fast },
    { 21, 16, 17, 1, 5, 0, ZSTD_dfast },
    { 21, 18, 18, 1, 5, 0, ZSTD_dfast },
    { 21, 18, 19, 3, 5, 2, ZSTD_greedy },
    { 21, 18, 19, 3, 5, 4, ZSTD_lazy },
    { 21, 19, 20, 4, 5, 8, ZSTD_lazy },
    { 21, 19, 20, 4, 5, 16, ZSTD_lazy2 },
    { 22, 20, 21, 4, 5, 16, ZSTD_lazy2 },
    { 22, 21, 22, 5, 5, 16, ZSTD_lazy2 },
    { 22, 21, 22, 6, 5, 16, ZSTD_lazy2 },
    { 22, 22, 23, 6, 5, 32, ZSTD_lazy2 },
    { 22, 22, 22, 4, 5, 32, ZSTD_btlazy2 },
    { 22, 22, 23, 5, 5, 32, ZSTD_btlazy2 },
    { 22, 23, 23, 6, 5, 32, ZSTD_btlazy2 },
    { 22, 22, 22, 5, 5, 48, ZSTD_btopt },
    { 23, 23, 22, 5, 4, 64, ZSTD_btopt },
    { 23, 23, 22, 6, 3, 64, ZSTD_btultra },
    { 23, 24, 22, 7, 3,256, ZSTD_btultra2},
    { 25, 25, 23, 7, 3,256, ZSTD_btultra2},
    { 26, 26, 24, 7, 3,512, ZSTD_btultra2},
    { 27, 27, 25, 9, 3,999, ZSTD_btultra2},
},
{

    { 18, 12, 13, 1, 5, 1, ZSTD_fast },
    { 18, 13, 14, 1, 6, 0, ZSTD_fast },
    { 18, 14, 14, 1, 5, 0, ZSTD_dfast },
    { 18, 16, 16, 1, 4, 0, ZSTD_dfast },
    { 18, 16, 17, 3, 5, 2, ZSTD_greedy },
    { 18, 17, 18, 5, 5, 2, ZSTD_greedy },
    { 18, 18, 19, 3, 5, 4, ZSTD_lazy },
    { 18, 18, 19, 4, 4, 4, ZSTD_lazy },
    { 18, 18, 19, 4, 4, 8, ZSTD_lazy2 },
    { 18, 18, 19, 5, 4, 8, ZSTD_lazy2 },
    { 18, 18, 19, 6, 4, 8, ZSTD_lazy2 },
    { 18, 18, 19, 5, 4, 12, ZSTD_btlazy2 },
    { 18, 19, 19, 7, 4, 12, ZSTD_btlazy2 },
    { 18, 18, 19, 4, 4, 16, ZSTD_btopt },
    { 18, 18, 19, 4, 3, 32, ZSTD_btopt },
    { 18, 18, 19, 6, 3,128, ZSTD_btopt },
    { 18, 19, 19, 6, 3,128, ZSTD_btultra },
    { 18, 19, 19, 8, 3,256, ZSTD_btultra },
    { 18, 19, 19, 6, 3,128, ZSTD_btultra2},
    { 18, 19, 19, 8, 3,256, ZSTD_btultra2},
    { 18, 19, 19, 10, 3,512, ZSTD_btultra2},
    { 18, 19, 19, 12, 3,512, ZSTD_btultra2},
    { 18, 19, 19, 13, 3,999, ZSTD_btultra2},
},
{

    { 17, 12, 12, 1, 5, 1, ZSTD_fast },
    { 17, 12, 13, 1, 6, 0, ZSTD_fast },
    { 17, 13, 15, 1, 5, 0, ZSTD_fast },
    { 17, 15, 16, 2, 5, 0, ZSTD_dfast },
    { 17, 17, 17, 2, 4, 0, ZSTD_dfast },
    { 17, 16, 17, 3, 4, 2, ZSTD_greedy },
    { 17, 16, 17, 3, 4, 4, ZSTD_lazy },
    { 17, 16, 17, 3, 4, 8, ZSTD_lazy2 },
    { 17, 16, 17, 4, 4, 8, ZSTD_lazy2 },
    { 17, 16, 17, 5, 4, 8, ZSTD_lazy2 },
    { 17, 16, 17, 6, 4, 8, ZSTD_lazy2 },
    { 17, 17, 17, 5, 4, 8, ZSTD_btlazy2 },
    { 17, 18, 17, 7, 4, 12, ZSTD_btlazy2 },
    { 17, 18, 17, 3, 4, 12, ZSTD_btopt },
    { 17, 18, 17, 4, 3, 32, ZSTD_btopt },
    { 17, 18, 17, 6, 3,256, ZSTD_btopt },
    { 17, 18, 17, 6, 3,128, ZSTD_btultra },
    { 17, 18, 17, 8, 3,256, ZSTD_btultra },
    { 17, 18, 17, 10, 3,512, ZSTD_btultra },
    { 17, 18, 17, 5, 3,256, ZSTD_btultra2},
    { 17, 18, 17, 7, 3,512, ZSTD_btultra2},
    { 17, 18, 17, 9, 3,512, ZSTD_btultra2},
    { 17, 18, 17, 11, 3,999, ZSTD_btultra2},
},
{

    { 14, 12, 13, 1, 5, 1, ZSTD_fast },
    { 14, 14, 15, 1, 5, 0, ZSTD_fast },
    { 14, 14, 15, 1, 4, 0, ZSTD_fast },
    { 14, 14, 15, 2, 4, 0, ZSTD_dfast },
    { 14, 14, 14, 4, 4, 2, ZSTD_greedy },
    { 14, 14, 14, 3, 4, 4, ZSTD_lazy },
    { 14, 14, 14, 4, 4, 8, ZSTD_lazy2 },
    { 14, 14, 14, 6, 4, 8, ZSTD_lazy2 },
    { 14, 14, 14, 8, 4, 8, ZSTD_lazy2 },
    { 14, 15, 14, 5, 4, 8, ZSTD_btlazy2 },
    { 14, 15, 14, 9, 4, 8, ZSTD_btlazy2 },
    { 14, 15, 14, 3, 4, 12, ZSTD_btopt },
    { 14, 15, 14, 4, 3, 24, ZSTD_btopt },
    { 14, 15, 14, 5, 3, 32, ZSTD_btultra },
    { 14, 15, 15, 6, 3, 64, ZSTD_btultra },
    { 14, 15, 15, 7, 3,256, ZSTD_btultra },
    { 14, 15, 15, 5, 3, 48, ZSTD_btultra2},
    { 14, 15, 15, 6, 3,128, ZSTD_btultra2},
    { 14, 15, 15, 7, 3,256, ZSTD_btultra2},
    { 14, 15, 15, 8, 3,256, ZSTD_btultra2},
    { 14, 15, 15, 8, 3,512, ZSTD_btultra2},
    { 14, 15, 15, 9, 3,512, ZSTD_btultra2},
    { 14, 15, 15, 10, 3,999, ZSTD_btultra2},
},
};
# 7672 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 2

int ZSTD_maxCLevel(void) { return 22; }
int ZSTD_minCLevel(void) { return (int)-(1<<17); }
int ZSTD_defaultCLevel(void) { return 3; }

static ZSTD_compressionParameters ZSTD_dedicatedDictSearch_getCParams(int const compressionLevel, size_t const dictSize)
{
    ZSTD_compressionParameters cParams = ZSTD_getCParams_internal(compressionLevel, 0, dictSize, ZSTD_cpm_createCDict);
    switch (cParams.strategy) {
        case ZSTD_fast:
        case ZSTD_dfast:
            break;
        case ZSTD_greedy:
        case ZSTD_lazy:
        case ZSTD_lazy2:
            cParams.hashLog += 2;
            break;
        case ZSTD_btlazy2:
        case ZSTD_btopt:
        case ZSTD_btultra:
        case ZSTD_btultra2:
            break;
    }
    return cParams;
}

static int ZSTD_dedicatedDictSearch_isSupported(
        ZSTD_compressionParameters const* cParams)
{
    return (cParams->strategy >= ZSTD_greedy)
        && (cParams->strategy <= ZSTD_lazy2)
        && (cParams->hashLog > cParams->chainLog)
        && (cParams->chainLog <= 24);
}






static void ZSTD_dedicatedDictSearch_revertCParams(
        ZSTD_compressionParameters* cParams) {
    switch (cParams->strategy) {
        case ZSTD_fast:
        case ZSTD_dfast:
            break;
        case ZSTD_greedy:
        case ZSTD_lazy:
        case ZSTD_lazy2:
            cParams->hashLog -= 2;
            if (cParams->hashLog < 6) {
                cParams->hashLog = 6;
            }
            break;
        case ZSTD_btlazy2:
        case ZSTD_btopt:
        case ZSTD_btultra:
        case ZSTD_btultra2:
            break;
    }
}

static U64 ZSTD_getCParamRowSize(U64 srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode)
{
    switch (mode) {
    case ZSTD_cpm_unknown:
    case ZSTD_cpm_noAttachDict:
    case ZSTD_cpm_createCDict:
        break;
    case ZSTD_cpm_attachDict:
        dictSize = 0;
        break;
    default:
        ((void)0);
        break;
    }
    { int const unknown = srcSizeHint == (0ULL - 1);
        size_t const addedSize = unknown && dictSize > 0 ? 500 : 0;
        return unknown && dictSize == 0 ? (0ULL - 1) : srcSizeHint+dictSize+addedSize;
    }
}






static ZSTD_compressionParameters ZSTD_getCParams_internal(int compressionLevel, unsigned long long srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode)
{
    U64 const rSize = ZSTD_getCParamRowSize(srcSizeHint, dictSize, mode);
    U32 const tableID = (rSize <= 256 *(1 <<10)) + (rSize <= 128 *(1 <<10)) + (rSize <= 16 *(1 <<10));
    int row;
    do { } while (0);


    if (compressionLevel == 0) row = 3;
    else if (compressionLevel < 0) row = 0;
    else if (compressionLevel > 22) row = 22;
    else row = compressionLevel;

    { ZSTD_compressionParameters cp = ZSTD_defaultCParameters[tableID][row];
        do { } while (0);

        if (compressionLevel < 0) {
            int const clampedCompressionLevel = ((ZSTD_minCLevel())>(compressionLevel) ? (ZSTD_minCLevel()) : (compressionLevel));
            cp.targetLength = (unsigned)(-clampedCompressionLevel);
        }

        return ZSTD_adjustCParams_internal(cp, srcSizeHint, dictSize, mode, ZSTD_ps_auto);
    }
}




ZSTD_compressionParameters ZSTD_getCParams(int compressionLevel, unsigned long long srcSizeHint, size_t dictSize)
{
    if (srcSizeHint == 0) srcSizeHint = (0ULL - 1);
    return ZSTD_getCParams_internal(compressionLevel, srcSizeHint, dictSize, ZSTD_cpm_unknown);
}





static ZSTD_parameters
ZSTD_getParams_internal(int compressionLevel, unsigned long long srcSizeHint, size_t dictSize, ZSTD_CParamMode_e mode)
{
    ZSTD_parameters params;
    ZSTD_compressionParameters const cParams = ZSTD_getCParams_internal(compressionLevel, srcSizeHint, dictSize, mode);
    do { } while (0);
    __builtin_memset((&params),(0),(sizeof(params)));
    params.cParams = cParams;
    params.fParams.contentSizeFlag = 1;
    return params;
}





ZSTD_parameters ZSTD_getParams(int compressionLevel, unsigned long long srcSizeHint, size_t dictSize)
{
    if (srcSizeHint == 0) srcSizeHint = (0ULL - 1);
    return ZSTD_getParams_internal(compressionLevel, srcSizeHint, dictSize, ZSTD_cpm_unknown);
}

void ZSTD_registerSequenceProducer(
    ZSTD_CCtx* zc,
    void* extSeqProdState,
    ZSTD_sequenceProducer_F extSeqProdFunc)
{
    ((void)0);
    ZSTD_CCtxParams_registerSequenceProducer(
        &zc->requestedParams, extSeqProdState, extSeqProdFunc
    );
}

void ZSTD_CCtxParams_registerSequenceProducer(
  ZSTD_CCtx_params* params,
  void* extSeqProdState,
  ZSTD_sequenceProducer_F extSeqProdFunc)
{
    ((void)0);
    if (extSeqProdFunc != 
# 7836 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                         ((void *)0)
# 7836 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                             ) {
        params->extSeqProdFunc = extSeqProdFunc;
        params->extSeqProdState = extSeqProdState;
    } else {
        params->extSeqProdFunc = 
# 7840 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                ((void *)0)
# 7840 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                    ;
        params->extSeqProdState = 
# 7841 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c" 3 4
                                 ((void *)0)
# 7841 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/compress/zstd_compress.c"
                                     ;
    }
}
