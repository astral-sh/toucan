typedef int __int128_t __attribute__ ( ( mode ( TI ) ) ) ; typedef unsigned int __uint128_t __attribute__ ( ( mode ( TI ) ) ) ;
typedef long unsigned int size_t ;
typedef unsigned char __u_char ; typedef unsigned short int __u_short ; typedef unsigned int __u_int ; typedef unsigned long int __u_long ; typedef signed char __int8_t ; typedef unsigned char __uint8_t ; typedef signed short int __int16_t ; typedef unsigned short int __uint16_t ; typedef signed int __int32_t ; typedef unsigned int __uint32_t ;
typedef signed long int __int64_t ; typedef unsigned long int __uint64_t ;
typedef __int8_t __int_least8_t ; typedef __uint8_t __uint_least8_t ; typedef __int16_t __int_least16_t ; typedef __uint16_t __uint_least16_t ; typedef __int32_t __int_least32_t ; typedef __uint32_t __uint_least32_t ; typedef __int64_t __int_least64_t ; typedef __uint64_t __uint_least64_t ;
typedef long int __quad_t ; typedef unsigned long int __u_quad_t ;
typedef long int __intmax_t ; typedef unsigned long int __uintmax_t ;
typedef unsigned long int __dev_t ; typedef unsigned int __uid_t ; typedef unsigned int __gid_t ; typedef unsigned long int __ino_t ; typedef unsigned long int __ino64_t ; typedef unsigned int __mode_t ; typedef unsigned long int __nlink_t ; typedef long int __off_t ; typedef long int __off64_t ; typedef int __pid_t ; typedef struct { int __val [ 2 ] ; } __fsid_t ; typedef long int __clock_t ; typedef unsigned long int __rlim_t ; typedef unsigned long int __rlim64_t ; typedef unsigned int __id_t ; typedef long int __time_t ; typedef unsigned int __useconds_t ; typedef long int __suseconds_t ; typedef long int __suseconds64_t ; typedef int __daddr_t ; typedef int __key_t ; typedef int __clockid_t ; typedef void * __timer_t ; typedef long int __blksize_t ; typedef long int __blkcnt_t ; typedef long int __blkcnt64_t ; typedef unsigned long int __fsblkcnt_t ; typedef unsigned long int __fsblkcnt64_t ; typedef unsigned long int __fsfilcnt_t ; typedef unsigned long int __fsfilcnt64_t ; typedef long int __fsword_t ; typedef long int __ssize_t ; typedef long int __syscall_slong_t ; typedef unsigned long int __syscall_ulong_t ; typedef __off64_t __loff_t ; typedef char * __caddr_t ; typedef long int __intptr_t ; typedef unsigned int __socklen_t ; typedef int __sig_atomic_t ;
struct timeval {
__time_t tv_sec ; __suseconds_t tv_usec ;
} ;
struct timex {
unsigned int modes ; __syscall_slong_t offset ; __syscall_slong_t freq ; __syscall_slong_t maxerror ; __syscall_slong_t esterror ; int status ; __syscall_slong_t constant ; __syscall_slong_t precision ; __syscall_slong_t tolerance ; struct timeval time ; __syscall_slong_t tick ; __syscall_slong_t ppsfreq ; __syscall_slong_t jitter ; int shift ; __syscall_slong_t stabil ; __syscall_slong_t jitcnt ; __syscall_slong_t calcnt ; __syscall_slong_t errcnt ; __syscall_slong_t stbcnt ; int tai ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ; int : 32 ;
} ;
extern int clock_adjtime ( __clockid_t __clock_id , struct timex * __utx ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;

typedef __clock_t clock_t ;
typedef __time_t time_t ;
struct tm { int tm_sec ; int tm_min ; int tm_hour ; int tm_mday ; int tm_mon ; int tm_year ; int tm_wday ; int tm_yday ; int tm_isdst ;
long int tm_gmtoff ; const char * tm_zone ;
} ;
struct timespec {
__time_t tv_sec ;
__syscall_slong_t tv_nsec ;
} ;
typedef __clockid_t clockid_t ;
typedef __timer_t timer_t ;
struct itimerspec { struct timespec it_interval ; struct timespec it_value ; } ;
struct sigevent ;
typedef __pid_t pid_t ;
struct __locale_struct { struct __locale_data * __locales [ 13 ] ; const unsigned short int * __ctype_b ; const int * __ctype_tolower ; const int * __ctype_toupper ; const char * __names [ 13 ] ; } ; typedef struct __locale_struct * __locale_t ;
typedef __locale_t locale_t ;
extern clock_t clock ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern time_t time ( time_t * __timer ) __attribute__ ( ( __nothrow__ ) ) ; extern double difftime ( time_t __time1 , time_t __time0 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern time_t mktime ( struct tm * __tp ) __attribute__ ( ( __nothrow__ ) ) ;
extern size_t strftime ( char * __restrict __s , size_t __maxsize , const char * __restrict __format , const struct tm * __restrict __tp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 , 4 ) ) ) ;
extern char * strptime ( const char * __restrict __s , const char * __restrict __fmt , struct tm * __tp ) __attribute__ ( ( __nothrow__ ) ) ;
extern size_t strftime_l ( char * __restrict __s , size_t __maxsize , const char * __restrict __format , const struct tm * __restrict __tp , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * strptime_l ( const char * __restrict __s , const char * __restrict __fmt , struct tm * __tp , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) ;
extern struct tm * gmtime ( const time_t * __timer ) __attribute__ ( ( __nothrow__ ) ) ; extern struct tm * localtime ( const time_t * __timer ) __attribute__ ( ( __nothrow__ ) ) ;
extern struct tm * gmtime_r ( const time_t * __restrict __timer , struct tm * __restrict __tp ) __attribute__ ( ( __nothrow__ ) ) ; extern struct tm * localtime_r ( const time_t * __restrict __timer , struct tm * __restrict __tp ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * asctime ( const struct tm * __tp ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * ctime ( const time_t * __timer ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * asctime_r ( const struct tm * __restrict __tp , char * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * ctime_r ( const time_t * __restrict __timer , char * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * __tzname [ 2 ] ; extern int __daylight ; extern long int __timezone ;
extern char * tzname [ 2 ] ; extern void tzset ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int daylight ; extern long int timezone ;
extern time_t timegm ( struct tm * __tp ) __attribute__ ( ( __nothrow__ ) ) ;
extern time_t timelocal ( struct tm * __tp ) __attribute__ ( ( __nothrow__ ) ) ;
extern int dysize ( int __year ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern int nanosleep ( const struct timespec * __requested_time , struct timespec * __remaining ) ; extern int clock_getres ( clockid_t __clock_id , struct timespec * __res ) __attribute__ ( ( __nothrow__ ) ) ; extern int clock_gettime ( clockid_t __clock_id , struct timespec * __tp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int clock_settime ( clockid_t __clock_id , const struct timespec * __tp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int clock_nanosleep ( clockid_t __clock_id , int __flags , const struct timespec * __req , struct timespec * __rem ) ;
extern int clock_getcpuclockid ( pid_t __pid , clockid_t * __clock_id ) __attribute__ ( ( __nothrow__ ) ) ;
extern int timer_create ( clockid_t __clock_id , struct sigevent * __restrict __evp , timer_t * __restrict __timerid ) __attribute__ ( ( __nothrow__ ) ) ; extern int timer_delete ( timer_t __timerid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int timer_settime ( timer_t __timerid , int __flags , const struct itimerspec * __restrict __value , struct itimerspec * __restrict __ovalue ) __attribute__ ( ( __nothrow__ ) ) ; extern int timer_gettime ( timer_t __timerid , struct itimerspec * __value ) __attribute__ ( ( __nothrow__ ) ) ;
extern int timer_getoverrun ( timer_t __timerid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int timespec_get ( struct timespec * __ts , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int timespec_getres ( struct timespec * __ts , int __base ) __attribute__ ( ( __nothrow__ ) ) ;
extern int getdate_err ; extern struct tm * getdate ( const char * __string ) ;
extern int getdate_r ( const char * __restrict __string , struct tm * __restrict __resbufp ) ;

typedef int wchar_t ;

typedef float _Float32 ;
typedef double _Float64 ;
typedef double _Float32x ;
typedef long double _Float64x ;
typedef struct { int quot ; int rem ; } div_t ;
typedef struct { long int quot ; long int rem ; } ldiv_t ;
__extension__ typedef struct { long long int quot ; long long int rem ; } lldiv_t ;
extern size_t __ctype_get_mb_cur_max ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern double atof ( const char * __nptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int atoi ( const char * __nptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long int atol ( const char * __nptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
__extension__ extern long long int atoll ( const char * __nptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern double strtod ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern float strtof ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long double strtold ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern _Float32 strtof32 ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern _Float64 strtof64 ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern _Float32x strtof32x ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern _Float64x strtof64x ( const char * __restrict __nptr , char * * __restrict __endptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern long int strtol ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern unsigned long int strtoul ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
__extension__ extern long long int strtoq ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; __extension__ extern unsigned long long int strtouq ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
__extension__ extern long long int strtoll ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; __extension__ extern unsigned long long int strtoull ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern long int strtol ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtol" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern unsigned long int strtoul ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoul" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
__extension__ extern long long int strtoq ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoll" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; __extension__ extern unsigned long long int strtouq ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoull" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
__extension__ extern long long int strtoll ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoll" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; __extension__ extern unsigned long long int strtoull ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoull" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int strfromd ( char * __dest , size_t __size , const char * __format , double __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ; extern int strfromf ( char * __dest , size_t __size , const char * __format , float __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ; extern int strfroml ( char * __dest , size_t __size , const char * __format , long double __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern int strfromf32 ( char * __dest , size_t __size , const char * __format , _Float32 __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern int strfromf64 ( char * __dest , size_t __size , const char * __format , _Float64 __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern int strfromf32x ( char * __dest , size_t __size , const char * __format , _Float32x __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern int strfromf64x ( char * __dest , size_t __size , const char * __format , _Float64x __f ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern long int strtol_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ; extern unsigned long int strtoul_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ; __extension__ extern long long int strtoll_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ; __extension__ extern unsigned long long int strtoull_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ;
extern long int strtol_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtol_l" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ; extern unsigned long int strtoul_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoul_l" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ; __extension__ extern long long int strtoll_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoll_l" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ; __extension__ extern unsigned long long int strtoull_l ( const char * __restrict __nptr , char * * __restrict __endptr , int __base , locale_t __loc ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoull_l" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ;
extern double strtod_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern float strtof_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern long double strtold_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern _Float32 strtof32_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern _Float64 strtof64_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern _Float32x strtof32x_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern _Float64x strtof64x_l ( const char * __restrict __nptr , char * * __restrict __endptr , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern char * l64a ( long int __n ) __attribute__ ( ( __nothrow__ ) ) ; extern long int a64l ( const char * __s ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;

typedef __u_char u_char ; typedef __u_short u_short ; typedef __u_int u_int ; typedef __u_long u_long ; typedef __quad_t quad_t ; typedef __u_quad_t u_quad_t ; typedef __fsid_t fsid_t ;
typedef __loff_t loff_t ;
typedef __ino_t ino_t ;
typedef __ino64_t ino64_t ;
typedef __dev_t dev_t ;
typedef __gid_t gid_t ;
typedef __mode_t mode_t ;
typedef __nlink_t nlink_t ;
typedef __uid_t uid_t ;
typedef __off_t off_t ;
typedef __off64_t off64_t ;
typedef __id_t id_t ;
typedef __ssize_t ssize_t ;
typedef __daddr_t daddr_t ; typedef __caddr_t caddr_t ;
typedef __key_t key_t ;
typedef __useconds_t useconds_t ;
typedef __suseconds_t suseconds_t ;
typedef unsigned long int ulong ; typedef unsigned short int ushort ; typedef unsigned int uint ;
typedef __int8_t int8_t ; typedef __int16_t int16_t ; typedef __int32_t int32_t ; typedef __int64_t int64_t ;
typedef __uint8_t u_int8_t ; typedef __uint16_t u_int16_t ; typedef __uint32_t u_int32_t ; typedef __uint64_t u_int64_t ;
typedef int register_t __attribute__ ( ( __mode__ ( __word__ ) ) ) ;
static __inline __uint16_t __bswap_16 ( __uint16_t __bsx ) {
return ( ( __uint16_t ) ( ( ( ( __bsx ) >> 8 ) & 0xff ) | ( ( ( __bsx ) & 0xff ) << 8 ) ) ) ;
}
static __inline __uint32_t __bswap_32 ( __uint32_t __bsx ) {
return ( ( ( ( __bsx ) & 0xff000000u ) >> 24 ) | ( ( ( __bsx ) & 0x00ff0000u ) >> 8 ) | ( ( ( __bsx ) & 0x0000ff00u ) << 8 ) | ( ( ( __bsx ) & 0x000000ffu ) << 24 ) ) ;
}
__extension__ static __inline __uint64_t __bswap_64 ( __uint64_t __bsx ) {
return ( ( ( ( __bsx ) & 0xff00000000000000ull ) >> 56 ) | ( ( ( __bsx ) & 0x00ff000000000000ull ) >> 40 ) | ( ( ( __bsx ) & 0x0000ff0000000000ull ) >> 24 ) | ( ( ( __bsx ) & 0x000000ff00000000ull ) >> 8 ) | ( ( ( __bsx ) & 0x00000000ff000000ull ) << 8 ) | ( ( ( __bsx ) & 0x0000000000ff0000ull ) << 24 ) | ( ( ( __bsx ) & 0x000000000000ff00ull ) << 40 ) | ( ( ( __bsx ) & 0x00000000000000ffull ) << 56 ) ) ;
}
static __inline __uint16_t __uint16_identity ( __uint16_t __x ) { return __x ; } static __inline __uint32_t __uint32_identity ( __uint32_t __x ) { return __x ; } static __inline __uint64_t __uint64_identity ( __uint64_t __x ) { return __x ; }
typedef struct { unsigned long int __val [ ( 1024 / ( 8 * sizeof ( unsigned long int ) ) ) ] ; } __sigset_t ;
typedef __sigset_t sigset_t ;
typedef long int __fd_mask ;
typedef struct {
__fd_mask fds_bits [ 1024 / ( 8 * ( int ) sizeof ( __fd_mask ) ) ] ;
} fd_set ;
typedef __fd_mask fd_mask ;

extern int select ( int __nfds , fd_set * __restrict __readfds , fd_set * __restrict __writefds , fd_set * __restrict __exceptfds , struct timeval * __restrict __timeout ) ;
extern int pselect ( int __nfds , fd_set * __restrict __readfds , fd_set * __restrict __writefds , fd_set * __restrict __exceptfds , const struct timespec * __restrict __timeout , const __sigset_t * __restrict __sigmask ) ;

typedef __blksize_t blksize_t ;
typedef __blkcnt_t blkcnt_t ;
typedef __fsblkcnt_t fsblkcnt_t ;
typedef __fsfilcnt_t fsfilcnt_t ;
typedef __blkcnt64_t blkcnt64_t ; typedef __fsblkcnt64_t fsblkcnt64_t ; typedef __fsfilcnt64_t fsfilcnt64_t ;
typedef union { __extension__ unsigned long long int __value64 ; struct { unsigned int __low ; unsigned int __high ; } __value32 ; } __atomic_wide_counter ;
typedef struct __pthread_internal_list { struct __pthread_internal_list * __prev ; struct __pthread_internal_list * __next ; } __pthread_list_t ; typedef struct __pthread_internal_slist { struct __pthread_internal_slist * __next ; } __pthread_slist_t ;
struct __pthread_mutex_s { int __lock ; unsigned int __count ; int __owner ;
unsigned int __nusers ;
int __kind ;
short __spins ; short __elision ; __pthread_list_t __list ;
} ;
struct __pthread_rwlock_arch_t { unsigned int __readers ; unsigned int __writers ; unsigned int __wrphase_futex ; unsigned int __writers_futex ; unsigned int __pad3 ; unsigned int __pad4 ;
int __cur_writer ; int __shared ; signed char __rwelision ;
unsigned char __pad1 [ 7 ] ;
unsigned long int __pad2 ; unsigned int __flags ;
} ;
struct __pthread_cond_s { __atomic_wide_counter __wseq ; __atomic_wide_counter __g1_start ; unsigned int __g_refs [ 2 ] ; unsigned int __g_size [ 2 ] ; unsigned int __g1_orig_size ; unsigned int __wrefs ; unsigned int __g_signals [ 2 ] ; } ; typedef unsigned int __tss_t ; typedef unsigned long int __thrd_t ; typedef struct { int __data ; } __once_flag ;
typedef unsigned long int pthread_t ; typedef union { char __size [ 4 ] ; int __align ; } pthread_mutexattr_t ; typedef union { char __size [ 4 ] ; int __align ; } pthread_condattr_t ; typedef unsigned int pthread_key_t ; typedef int pthread_once_t ; union pthread_attr_t { char __size [ 56 ] ; long int __align ; } ;
typedef union pthread_attr_t pthread_attr_t ;
typedef union { struct __pthread_mutex_s __data ; char __size [ 40 ] ; long int __align ; } pthread_mutex_t ; typedef union { struct __pthread_cond_s __data ; char __size [ 48 ] ; __extension__ long long int __align ; } pthread_cond_t ;
typedef union { struct __pthread_rwlock_arch_t __data ; char __size [ 56 ] ; long int __align ; } pthread_rwlock_t ; typedef union { char __size [ 8 ] ; long int __align ; } pthread_rwlockattr_t ;
typedef volatile int pthread_spinlock_t ; typedef union { char __size [ 32 ] ; long int __align ; } pthread_barrier_t ; typedef union { char __size [ 4 ] ; int __align ; } pthread_barrierattr_t ;

extern long int random ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern void srandom ( unsigned int __seed ) __attribute__ ( ( __nothrow__ ) ) ; extern char * initstate ( unsigned int __seed , char * __statebuf , size_t __statelen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern char * setstate ( char * __statebuf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
struct random_data { int32_t * fptr ; int32_t * rptr ; int32_t * state ; int rand_type ; int rand_deg ; int rand_sep ; int32_t * end_ptr ; } ; extern int random_r ( struct random_data * __restrict __buf , int32_t * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int srandom_r ( unsigned int __seed , struct random_data * __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int initstate_r ( unsigned int __seed , char * __restrict __statebuf , size_t __statelen , struct random_data * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 4 ) ) ) ; extern int setstate_r ( char * __restrict __statebuf , struct random_data * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int rand ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern void srand ( unsigned int __seed ) __attribute__ ( ( __nothrow__ ) ) ;
extern int rand_r ( unsigned int * __seed ) __attribute__ ( ( __nothrow__ ) ) ;
extern double drand48 ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern double erand48 ( unsigned short int __xsubi [ 3 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long int lrand48 ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern long int nrand48 ( unsigned short int __xsubi [ 3 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long int mrand48 ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern long int jrand48 ( unsigned short int __xsubi [ 3 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern void srand48 ( long int __seedval ) __attribute__ ( ( __nothrow__ ) ) ; extern unsigned short int * seed48 ( unsigned short int __seed16v [ 3 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern void lcong48 ( unsigned short int __param [ 7 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
struct drand48_data { unsigned short int __x [ 3 ] ; unsigned short int __old_x [ 3 ] ; unsigned short int __c ; unsigned short int __init ; __extension__ unsigned long long int __a ; } ; extern int drand48_r ( struct drand48_data * __restrict __buffer , double * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int erand48_r ( unsigned short int __xsubi [ 3 ] , struct drand48_data * __restrict __buffer , double * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int lrand48_r ( struct drand48_data * __restrict __buffer , long int * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int nrand48_r ( unsigned short int __xsubi [ 3 ] , struct drand48_data * __restrict __buffer , long int * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int mrand48_r ( struct drand48_data * __restrict __buffer , long int * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int jrand48_r ( unsigned short int __xsubi [ 3 ] , struct drand48_data * __restrict __buffer , long int * __restrict __result ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int srand48_r ( long int __seedval , struct drand48_data * __buffer ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int seed48_r ( unsigned short int __seed16v [ 3 ] , struct drand48_data * __buffer ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int lcong48_r ( unsigned short int __param [ 7 ] , struct drand48_data * __buffer ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern __uint32_t arc4random ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern void arc4random_buf ( void * __buf , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern __uint32_t arc4random_uniform ( __uint32_t __upper_bound ) __attribute__ ( ( __nothrow__ ) ) ;
extern void * malloc ( size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ; extern void * calloc ( size_t __nmemb , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ; extern void * realloc ( void * __ptr , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __warn_unused_result__ ) ) ; extern void free ( void * __ptr ) __attribute__ ( ( __nothrow__ ) ) ;
extern void * reallocarray ( void * __ptr , size_t __nmemb , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __warn_unused_result__ ) ) ; extern void * reallocarray ( void * __ptr , size_t __nmemb , size_t __size ) __attribute__ ( ( __nothrow__ ) ) ;

extern void * alloca ( size_t __size ) __attribute__ ( ( __nothrow__ ) ) ;

extern void * valloc ( size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ;
extern int posix_memalign ( void * * __memptr , size_t __alignment , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void * aligned_alloc ( size_t __alignment , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ;
extern void abort ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __noreturn__ ) ) ; extern int atexit ( void ( * __func ) ( void ) ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int at_quick_exit ( void ( * __func ) ( void ) ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int on_exit ( void ( * __func ) ( int __status , void * __arg ) , void * __arg ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void exit ( int __status ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __noreturn__ ) ) ;
extern void quick_exit ( int __status ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __noreturn__ ) ) ;
extern void _Exit ( int __status ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __noreturn__ ) ) ;
extern char * getenv ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * secure_getenv ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int putenv ( char * __string ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int setenv ( const char * __name , const char * __value , int __replace ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int unsetenv ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int clearenv ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * mktemp ( char * __template ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkstemp ( char * __template ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkstemp64 ( char * __template ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkstemps ( char * __template , int __suffixlen ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkstemps64 ( char * __template , int __suffixlen ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * mkdtemp ( char * __template ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkostemp ( char * __template , int __flags ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkostemp64 ( char * __template , int __flags ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkostemps ( char * __template , int __suffixlen , int __flags ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkostemps64 ( char * __template , int __suffixlen , int __flags ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int system ( const char * __command ) ;
extern char * canonicalize_file_name ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __malloc__ ) ) ;
extern char * realpath ( const char * __restrict __name , char * __restrict __resolved ) __attribute__ ( ( __nothrow__ ) ) ;
typedef int ( * __compar_fn_t ) ( const void * , const void * ) ;
typedef __compar_fn_t comparison_fn_t ;
typedef int ( * __compar_d_fn_t ) ( const void * , const void * , void * ) ;
extern void * bsearch ( const void * __key , const void * __base , size_t __nmemb , size_t __size , __compar_fn_t __compar ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 5 ) ) ) ;
extern void qsort ( void * __base , size_t __nmemb , size_t __size , __compar_fn_t __compar ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ;
extern void qsort_r ( void * __base , size_t __nmemb , size_t __size , __compar_d_fn_t __compar , void * __arg ) __attribute__ ( ( __nonnull__ ( 1 , 4 ) ) ) ;
extern int abs ( int __x ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern long int labs ( long int __x ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
__extension__ extern long long int llabs ( long long int __x ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern div_t div ( int __numer , int __denom ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern ldiv_t ldiv ( long int __numer , long int __denom ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
__extension__ extern lldiv_t lldiv ( long long int __numer , long long int __denom ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern char * ecvt ( double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 ) ) ) ; extern char * fcvt ( double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 ) ) ) ; extern char * gcvt ( double __value , int __ndigit , char * __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern char * qecvt ( long double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 ) ) ) ; extern char * qfcvt ( long double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 ) ) ) ; extern char * qgcvt ( long double __value , int __ndigit , char * __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ; extern int ecvt_r ( double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign , char * __restrict __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 , 5 ) ) ) ; extern int fcvt_r ( double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign , char * __restrict __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 , 5 ) ) ) ; extern int qecvt_r ( long double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign , char * __restrict __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 , 5 ) ) ) ; extern int qfcvt_r ( long double __value , int __ndigit , int * __restrict __decpt , int * __restrict __sign , char * __restrict __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 , 4 , 5 ) ) ) ;
extern int mblen ( const char * __s , size_t __n ) __attribute__ ( ( __nothrow__ ) ) ; extern int mbtowc ( wchar_t * __restrict __pwc , const char * __restrict __s , size_t __n ) __attribute__ ( ( __nothrow__ ) ) ; extern int wctomb ( char * __s , wchar_t __wchar ) __attribute__ ( ( __nothrow__ ) ) ; extern size_t mbstowcs ( wchar_t * __restrict __pwcs , const char * __restrict __s , size_t __n ) __attribute__ ( ( __nothrow__ ) ) ; extern size_t wcstombs ( char * __restrict __s , const wchar_t * __restrict __pwcs , size_t __n ) __attribute__ ( ( __nothrow__ ) ) ;
extern int rpmatch ( const char * __response ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int getsubopt ( char * * __restrict __optionp , char * const * __restrict __tokens , char * * __restrict __valuep ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ;
extern int posix_openpt ( int __oflag ) ;
extern int grantpt ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ; extern int unlockpt ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ; extern char * ptsname ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ;
extern int ptsname_r ( int __fd , char * __buf , size_t __buflen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int getpt ( void ) ;
extern int getloadavg ( double __loadavg [ ] , int __nelem ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;

typedef __uint8_t uint8_t ; typedef __uint16_t uint16_t ; typedef __uint32_t uint32_t ; typedef __uint64_t uint64_t ;
typedef __int_least8_t int_least8_t ; typedef __int_least16_t int_least16_t ; typedef __int_least32_t int_least32_t ; typedef __int_least64_t int_least64_t ; typedef __uint_least8_t uint_least8_t ; typedef __uint_least16_t uint_least16_t ; typedef __uint_least32_t uint_least32_t ; typedef __uint_least64_t uint_least64_t ;
typedef signed char int_fast8_t ;
typedef long int int_fast16_t ; typedef long int int_fast32_t ; typedef long int int_fast64_t ;
typedef unsigned char uint_fast8_t ;
typedef unsigned long int uint_fast16_t ; typedef unsigned long int uint_fast32_t ; typedef unsigned long int uint_fast64_t ;
typedef long int intptr_t ;
typedef unsigned long int uintptr_t ;
typedef __intmax_t intmax_t ; typedef __uintmax_t uintmax_t ;
typedef int __gwchar_t ;

typedef struct { long int quot ; long int rem ; } imaxdiv_t ;
extern intmax_t imaxabs ( intmax_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern imaxdiv_t imaxdiv ( intmax_t __numer , intmax_t __denom ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern intmax_t strtoimax ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) ; extern uintmax_t strtoumax ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) ; extern intmax_t wcstoimax ( const __gwchar_t * __restrict __nptr , __gwchar_t * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) ; extern uintmax_t wcstoumax ( const __gwchar_t * __restrict __nptr , __gwchar_t * * __restrict __endptr , int __base ) __attribute__ ( ( __nothrow__ ) ) ;
extern intmax_t strtoimax ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoimax" ) __attribute__ ( ( __nothrow__ ) ) ; extern uintmax_t strtoumax ( const char * __restrict __nptr , char * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_strtoumax" ) __attribute__ ( ( __nothrow__ ) ) ; extern intmax_t wcstoimax ( const __gwchar_t * __restrict __nptr , __gwchar_t * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_wcstoimax" ) __attribute__ ( ( __nothrow__ ) ) ; extern uintmax_t wcstoumax ( const __gwchar_t * __restrict __nptr , __gwchar_t * * __restrict __endptr , int __base ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_wcstoumax" ) __attribute__ ( ( __nothrow__ ) ) ;


extern __attribute__ ( ( visibility ( "default" ) ) ) int git_libgit2_version ( int * major , int * minor , int * rev ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) const char * git_libgit2_prerelease ( void ) ; typedef enum { GIT_FEATURE_THREADS = ( 1 << 0 ) , GIT_FEATURE_HTTPS = ( 1 << 1 ) , GIT_FEATURE_SSH = ( 1 << 2 ) , GIT_FEATURE_NSEC = ( 1 << 3 ) , GIT_FEATURE_HTTP_PARSER = ( 1 << 4 ) , GIT_FEATURE_REGEX = ( 1 << 5 ) , GIT_FEATURE_I18N = ( 1 << 6 ) , GIT_FEATURE_AUTH_NTLM = ( 1 << 7 ) , GIT_FEATURE_AUTH_NEGOTIATE = ( 1 << 8 ) , GIT_FEATURE_COMPRESSION = ( 1 << 9 ) , GIT_FEATURE_SHA1 = ( 1 << 10 ) , GIT_FEATURE_SHA256 = ( 1 << 11 ) } git_feature_t ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_libgit2_features ( void ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) const char * git_libgit2_feature_backend ( git_feature_t feature ) ; typedef enum { GIT_OPT_GET_MWINDOW_SIZE , GIT_OPT_SET_MWINDOW_SIZE , GIT_OPT_GET_MWINDOW_MAPPED_LIMIT , GIT_OPT_SET_MWINDOW_MAPPED_LIMIT , GIT_OPT_GET_SEARCH_PATH , GIT_OPT_SET_SEARCH_PATH , GIT_OPT_SET_CACHE_OBJECT_LIMIT , GIT_OPT_SET_CACHE_MAX_SIZE , GIT_OPT_ENABLE_CACHING , GIT_OPT_GET_CACHED_MEMORY , GIT_OPT_GET_TEMPLATE_PATH , GIT_OPT_SET_TEMPLATE_PATH , GIT_OPT_SET_SSL_CERT_LOCATIONS , GIT_OPT_SET_USER_AGENT , GIT_OPT_ENABLE_STRICT_OBJECT_CREATION , GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION , GIT_OPT_SET_SSL_CIPHERS , GIT_OPT_GET_USER_AGENT , GIT_OPT_ENABLE_OFS_DELTA , GIT_OPT_ENABLE_FSYNC_GITDIR , GIT_OPT_GET_WINDOWS_SHAREMODE , GIT_OPT_SET_WINDOWS_SHAREMODE , GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION , GIT_OPT_SET_ALLOCATOR , GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY , GIT_OPT_GET_PACK_MAX_OBJECTS , GIT_OPT_SET_PACK_MAX_OBJECTS , GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS , GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE , GIT_OPT_GET_MWINDOW_FILE_LIMIT , GIT_OPT_SET_MWINDOW_FILE_LIMIT , GIT_OPT_SET_ODB_PACKED_PRIORITY , GIT_OPT_SET_ODB_LOOSE_PRIORITY , GIT_OPT_GET_EXTENSIONS , GIT_OPT_SET_EXTENSIONS , GIT_OPT_GET_OWNER_VALIDATION , GIT_OPT_SET_OWNER_VALIDATION , GIT_OPT_GET_HOMEDIR , GIT_OPT_SET_HOMEDIR , GIT_OPT_SET_SERVER_CONNECT_TIMEOUT , GIT_OPT_GET_SERVER_CONNECT_TIMEOUT , GIT_OPT_SET_SERVER_TIMEOUT , GIT_OPT_GET_SERVER_TIMEOUT , GIT_OPT_SET_USER_AGENT_PRODUCT , GIT_OPT_GET_USER_AGENT_PRODUCT , GIT_OPT_ADD_SSL_X509_CERT } git_libgit2_opt_t ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_libgit2_opts ( int option , ... ) ;
typedef struct { void * ( * gmalloc ) ( size_t n , const char * file , int line ) ; void * ( * grealloc ) ( void * ptr , size_t size , const char * file , int line ) ; void ( * gfree ) ( void * ptr ) ; } git_allocator ; int git_stdalloc_init_allocator ( git_allocator * allocator ) ; int git_win32_crtdbg_init_allocator ( git_allocator * allocator ) ;
extern __attribute__ ( ( visibility ( "default" ) ) ) void git_error_clear ( void ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) void git_error_set ( int error_class , const char * fmt , ... ) __attribute__ ( ( format ( printf , 2 , 3 ) ) ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_error_set_str ( int error_class , const char * string ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) void git_error_set_oom ( void ) ;
typedef __builtin_va_list __gnuc_va_list ;
typedef __builtin_va_list va_list ;
typedef struct git_str git_str ;
extern int * __errno_location ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern char * program_invocation_name ; extern char * program_invocation_short_name ;
typedef int error_t ;

extern long int __sysconf ( int __name ) __attribute__ ( ( __nothrow__ ) ) ;

typedef struct { int __count ; union { unsigned int __wch ; char __wchb [ 4 ] ; } __value ; } __mbstate_t ;
typedef struct _G_fpos_t { __off_t __pos ; __mbstate_t __state ; } __fpos_t ;
typedef struct _G_fpos64_t { __off64_t __pos ; __mbstate_t __state ; } __fpos64_t ;
struct _IO_FILE ; typedef struct _IO_FILE __FILE ;
struct _IO_FILE ; typedef struct _IO_FILE FILE ;
struct _IO_FILE ; struct _IO_marker ; struct _IO_codecvt ; struct _IO_wide_data ;
typedef void _IO_lock_t ;
struct _IO_FILE { int _flags ; char * _IO_read_ptr ; char * _IO_read_end ; char * _IO_read_base ; char * _IO_write_base ; char * _IO_write_ptr ; char * _IO_write_end ; char * _IO_buf_base ; char * _IO_buf_end ; char * _IO_save_base ; char * _IO_backup_base ; char * _IO_save_end ; struct _IO_marker * _markers ; struct _IO_FILE * _chain ; int _fileno ; int _flags2 ; __off_t _old_offset ; unsigned short _cur_column ; signed char _vtable_offset ; char _shortbuf [ 1 ] ; _IO_lock_t * _lock ;
__off64_t _offset ; struct _IO_codecvt * _codecvt ; struct _IO_wide_data * _wide_data ; struct _IO_FILE * _freeres_list ; void * _freeres_buf ; size_t __pad5 ; int _mode ; char _unused2 [ 15 * sizeof ( int ) - 4 * sizeof ( void * ) - sizeof ( size_t ) ] ; } ;
typedef __ssize_t cookie_read_function_t ( void * __cookie , char * __buf , size_t __nbytes ) ; typedef __ssize_t cookie_write_function_t ( void * __cookie , const char * __buf , size_t __nbytes ) ; typedef int cookie_seek_function_t ( void * __cookie , __off64_t * __pos , int __w ) ; typedef int cookie_close_function_t ( void * __cookie ) ; typedef struct _IO_cookie_io_functions_t { cookie_read_function_t * read ; cookie_write_function_t * write ; cookie_seek_function_t * seek ; cookie_close_function_t * close ; } cookie_io_functions_t ;
typedef __gnuc_va_list va_list ;
typedef __fpos_t fpos_t ;
typedef __fpos64_t fpos64_t ;
extern FILE * stdin ; extern FILE * stdout ; extern FILE * stderr ;
extern int remove ( const char * __filename ) __attribute__ ( ( __nothrow__ ) ) ; extern int rename ( const char * __old , const char * __new ) __attribute__ ( ( __nothrow__ ) ) ;
extern int renameat ( int __oldfd , const char * __old , int __newfd , const char * __new ) __attribute__ ( ( __nothrow__ ) ) ;
extern int renameat2 ( int __oldfd , const char * __old , int __newfd , const char * __new , unsigned int __flags ) __attribute__ ( ( __nothrow__ ) ) ;
extern int fclose ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern FILE * tmpfile ( void ) __attribute__ ( ( __malloc__ ) ) ;
extern FILE * tmpfile64 ( void ) __attribute__ ( ( __malloc__ ) ) ;
extern char * tmpnam ( char [ 20 ] ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * tmpnam_r ( char __s [ 20 ] ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * tempnam ( const char * __dir , const char * __pfx ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ;
extern int fflush ( FILE * __stream ) ;
extern int fflush_unlocked ( FILE * __stream ) ;
extern int fcloseall ( void ) ;
extern FILE * fopen ( const char * __restrict __filename , const char * __restrict __modes ) __attribute__ ( ( __malloc__ ) ) ; extern FILE * freopen ( const char * __restrict __filename , const char * __restrict __modes , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern FILE * fopen64 ( const char * __restrict __filename , const char * __restrict __modes ) __attribute__ ( ( __malloc__ ) ) ; extern FILE * freopen64 ( const char * __restrict __filename , const char * __restrict __modes , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern FILE * fdopen ( int __fd , const char * __modes ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ;
extern FILE * fopencookie ( void * __restrict __magic_cookie , const char * __restrict __modes , cookie_io_functions_t __io_funcs ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ;
extern FILE * fmemopen ( void * __s , size_t __len , const char * __modes ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ; extern FILE * open_memstream ( char * * __bufloc , size_t * __sizeloc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) ;
extern void setbuf ( FILE * __restrict __stream , char * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int setvbuf ( FILE * __restrict __stream , char * __restrict __buf , int __modes , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void setbuffer ( FILE * __restrict __stream , char * __restrict __buf , size_t __size ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern void setlinebuf ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fprintf ( FILE * __restrict __stream , const char * __restrict __format , ... ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int printf ( const char * __restrict __format , ... ) ; extern int sprintf ( char * __restrict __s , const char * __restrict __format , ... ) __attribute__ ( ( __nothrow__ ) ) ; extern int vfprintf ( FILE * __restrict __s , const char * __restrict __format , __gnuc_va_list __arg ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int vprintf ( const char * __restrict __format , __gnuc_va_list __arg ) ; extern int vsprintf ( char * __restrict __s , const char * __restrict __format , __gnuc_va_list __arg ) __attribute__ ( ( __nothrow__ ) ) ;
extern int snprintf ( char * __restrict __s , size_t __maxlen , const char * __restrict __format , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 3 , 4 ) ) ) ; extern int vsnprintf ( char * __restrict __s , size_t __maxlen , const char * __restrict __format , __gnuc_va_list __arg ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 3 , 0 ) ) ) ;
extern int vasprintf ( char * * __restrict __ptr , const char * __restrict __f , __gnuc_va_list __arg ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 2 , 0 ) ) ) ; extern int __asprintf ( char * * __restrict __ptr , const char * __restrict __fmt , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 2 , 3 ) ) ) ; extern int asprintf ( char * * __restrict __ptr , const char * __restrict __fmt , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 2 , 3 ) ) ) ;
extern int vdprintf ( int __fd , const char * __restrict __fmt , __gnuc_va_list __arg ) __attribute__ ( ( __format__ ( __printf__ , 2 , 0 ) ) ) ; extern int dprintf ( int __fd , const char * __restrict __fmt , ... ) __attribute__ ( ( __format__ ( __printf__ , 2 , 3 ) ) ) ;
extern int fscanf ( FILE * __restrict __stream , const char * __restrict __format , ... ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int scanf ( const char * __restrict __format , ... ) ; extern int sscanf ( const char * __restrict __s , const char * __restrict __format , ... ) __attribute__ ( ( __nothrow__ ) ) ;
extern int fscanf ( FILE * __restrict __stream , const char * __restrict __format , ... ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_fscanf" ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int scanf ( const char * __restrict __format , ... ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_scanf" ) ; extern int sscanf ( const char * __restrict __s , const char * __restrict __format , ... ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_sscanf" ) __attribute__ ( ( __nothrow__ ) ) ;
extern int vfscanf ( FILE * __restrict __s , const char * __restrict __format , __gnuc_va_list __arg ) __attribute__ ( ( __format__ ( __scanf__ , 2 , 0 ) ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int vscanf ( const char * __restrict __format , __gnuc_va_list __arg ) __attribute__ ( ( __format__ ( __scanf__ , 1 , 0 ) ) ) ; extern int vsscanf ( const char * __restrict __s , const char * __restrict __format , __gnuc_va_list __arg ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __scanf__ , 2 , 0 ) ) ) ;
extern int vfscanf ( FILE * __restrict __s , const char * __restrict __format , __gnuc_va_list __arg ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_vfscanf" ) __attribute__ ( ( __format__ ( __scanf__ , 2 , 0 ) ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int vscanf ( const char * __restrict __format , __gnuc_va_list __arg ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_vscanf" ) __attribute__ ( ( __format__ ( __scanf__ , 1 , 0 ) ) ) ; extern int vsscanf ( const char * __restrict __s , const char * __restrict __format , __gnuc_va_list __arg ) __asm__ ( "__USER_LABEL_PREFIX__" "__isoc23_vsscanf" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __scanf__ , 2 , 0 ) ) ) ;
extern int fgetc ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int getc ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int getchar ( void ) ;
extern int getc_unlocked ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int getchar_unlocked ( void ) ;
extern int fgetc_unlocked ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fputc ( int __c , FILE * __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int putc ( int __c , FILE * __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int putchar ( int __c ) ;
extern int fputc_unlocked ( int __c , FILE * __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int putc_unlocked ( int __c , FILE * __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int putchar_unlocked ( int __c ) ;
extern int getw ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int putw ( int __w , FILE * __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern char * fgets ( char * __restrict __s , int __n , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern char * fgets_unlocked ( char * __restrict __s , int __n , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern __ssize_t __getdelim ( char * * __restrict __lineptr , size_t * __restrict __n , int __delimiter , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 4 ) ) ) ; extern __ssize_t getdelim ( char * * __restrict __lineptr , size_t * __restrict __n , int __delimiter , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 4 ) ) ) ; extern __ssize_t getline ( char * * __restrict __lineptr , size_t * __restrict __n , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern int fputs ( const char * __restrict __s , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int puts ( const char * __s ) ; extern int ungetc ( int __c , FILE * __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern size_t fread ( void * __restrict __ptr , size_t __size , size_t __n , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 4 ) ) ) ; extern size_t fwrite ( const void * __restrict __ptr , size_t __size , size_t __n , FILE * __restrict __s ) __attribute__ ( ( __nonnull__ ( 4 ) ) ) ;
extern int fputs_unlocked ( const char * __restrict __s , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern size_t fread_unlocked ( void * __restrict __ptr , size_t __size , size_t __n , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 4 ) ) ) ; extern size_t fwrite_unlocked ( const void * __restrict __ptr , size_t __size , size_t __n , FILE * __restrict __stream ) __attribute__ ( ( __nonnull__ ( 4 ) ) ) ;
extern int fseek ( FILE * __stream , long int __off , int __whence ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long int ftell ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern void rewind ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fseeko ( FILE * __stream , __off_t __off , int __whence ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern __off_t ftello ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fgetpos ( FILE * __restrict __stream , fpos_t * __restrict __pos ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int fsetpos ( FILE * __stream , const fpos_t * __pos ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fseeko64 ( FILE * __stream , __off64_t __off , int __whence ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern __off64_t ftello64 ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int fgetpos64 ( FILE * __restrict __stream , fpos64_t * __restrict __pos ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int fsetpos64 ( FILE * __stream , const fpos64_t * __pos ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void clearerr ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int feof ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int ferror ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void clearerr_unlocked ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int feof_unlocked ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int ferror_unlocked ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void perror ( const char * __s ) ;
extern int fileno ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fileno_unlocked ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pclose ( FILE * __stream ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern FILE * popen ( const char * __command , const char * __modes ) __attribute__ ( ( __malloc__ ) ) ;
extern char * ctermid ( char * __s ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * cuserid ( char * __s ) ;
struct obstack ; extern int obstack_printf ( struct obstack * __restrict __obstack , const char * __restrict __format , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 2 , 3 ) ) ) ; extern int obstack_vprintf ( struct obstack * __restrict __obstack , const char * __restrict __format , __gnuc_va_list __args ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __format__ ( __printf__ , 2 , 0 ) ) ) ;
extern void flockfile ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int ftrylockfile ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern void funlockfile ( FILE * __stream ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int __uflow ( FILE * ) ; extern int __overflow ( FILE * , int ) ;


extern void * memcpy ( void * __restrict __dest , const void * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern void * memmove ( void * __dest , const void * __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern void * memccpy ( void * __restrict __dest , const void * __restrict __src , int __c , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern void * memset ( void * __s , int __c , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int memcmp ( const void * __s1 , const void * __s2 , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int __memcmpeq ( const void * __s1 , const void * __s2 , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern void * memchr ( const void * __s , int __c , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void * rawmemchr ( const void * __s , int __c ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void * memrchr ( const void * __s , int __c , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * strcpy ( char * __restrict __dest , const char * __restrict __src ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * strncpy ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * strcat ( char * __restrict __dest , const char * __restrict __src ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * strncat ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int strcmp ( const char * __s1 , const char * __s2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int strncmp ( const char * __s1 , const char * __s2 , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int strcoll ( const char * __s1 , const char * __s2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern size_t strxfrm ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int strcoll_l ( const char * __s1 , const char * __s2 , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ; extern size_t strxfrm_l ( char * __dest , const char * __src , size_t __n , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 4 ) ) ) ;
extern char * strdup ( const char * __s ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * strndup ( const char * __string , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __malloc__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * strchr ( const char * __s , int __c ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * strrchr ( const char * __s , int __c ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * strchrnul ( const char * __s , int __c ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern size_t strcspn ( const char * __s , const char * __reject ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern size_t strspn ( const char * __s , const char * __accept ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern char * strpbrk ( const char * __s , const char * __accept ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern char * strstr ( const char * __haystack , const char * __needle ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern char * strtok ( char * __restrict __s , const char * __restrict __delim ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern char * __strtok_r ( char * __restrict __s , const char * __restrict __delim , char * * __restrict __save_ptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern char * strtok_r ( char * __restrict __s , const char * __restrict __delim , char * * __restrict __save_ptr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern char * strcasestr ( const char * __haystack , const char * __needle ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern void * memmem ( const void * __haystack , size_t __haystacklen , const void * __needle , size_t __needlelen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern void * __mempcpy ( void * __restrict __dest , const void * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern void * mempcpy ( void * __restrict __dest , const void * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern size_t strlen ( const char * __s ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern size_t strnlen ( const char * __string , size_t __maxlen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * strerror ( int __errnum ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * strerror_r ( int __errnum , char * __buf , size_t __buflen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern const char * strerrordesc_np ( int __err ) __attribute__ ( ( __nothrow__ ) ) ; extern const char * strerrorname_np ( int __err ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * strerror_l ( int __errnum , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) ;

extern int bcmp ( const void * __s1 , const void * __s2 , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern void bcopy ( const void * __src , void * __dest , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern void bzero ( void * __s , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * index ( const char * __s , int __c ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * rindex ( const char * __s , int __c ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int ffs ( int __i ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern int ffsl ( long int __l ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; __extension__ extern int ffsll ( long long int __ll ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern int strcasecmp ( const char * __s1 , const char * __s2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int strncasecmp ( const char * __s1 , const char * __s2 , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int strcasecmp_l ( const char * __s1 , const char * __s2 , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ; extern int strncasecmp_l ( const char * __s1 , const char * __s2 , size_t __n , locale_t __loc ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 4 ) ) ) ;

extern void explicit_bzero ( void * __s , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern char * strsep ( char * * __restrict __stringp , const char * __restrict __delim ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern char * strsignal ( int __sig ) __attribute__ ( ( __nothrow__ ) ) ;
extern const char * sigabbrev_np ( int __sig ) __attribute__ ( ( __nothrow__ ) ) ; extern const char * sigdescr_np ( int __sig ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * __stpcpy ( char * __restrict __dest , const char * __restrict __src ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * stpcpy ( char * __restrict __dest , const char * __restrict __src ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * __stpncpy ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * stpncpy ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern size_t strlcpy ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern size_t strlcat ( char * __restrict __dest , const char * __restrict __src , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int strverscmp ( const char * __s1 , const char * __s2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern char * strfry ( char * __string ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern void * memfrob ( void * __s , size_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * basename ( const char * __filename ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;


struct stat {
__dev_t st_dev ;
__ino_t st_ino ;
__nlink_t st_nlink ; __mode_t st_mode ;
__uid_t st_uid ; __gid_t st_gid ;
int __pad0 ;
__dev_t st_rdev ;
__off_t st_size ;
__blksize_t st_blksize ;
__blkcnt_t st_blocks ;
struct timespec st_atim ; struct timespec st_mtim ; struct timespec st_ctim ;
__syscall_slong_t __glibc_reserved [ 3 ] ;
} ;
struct stat64 {
__dev_t st_dev ;
__ino64_t st_ino ; __nlink_t st_nlink ; __mode_t st_mode ;
__uid_t st_uid ; __gid_t st_gid ;
int __pad0 ; __dev_t st_rdev ; __off_t st_size ;
__blksize_t st_blksize ; __blkcnt64_t st_blocks ;
struct timespec st_atim ; struct timespec st_mtim ; struct timespec st_ctim ;
__syscall_slong_t __glibc_reserved [ 3 ] ;
} ;
extern int stat ( const char * __restrict __file , struct stat * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int fstat ( int __fd , struct stat * __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int stat64 ( const char * __restrict __file , struct stat64 * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int fstat64 ( int __fd , struct stat64 * __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int fstatat ( int __fd , const char * __restrict __file , struct stat * __restrict __buf , int __flag ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern int fstatat64 ( int __fd , const char * __restrict __file , struct stat64 * __restrict __buf , int __flag ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern int lstat ( const char * __restrict __file , struct stat * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int lstat64 ( const char * __restrict __file , struct stat64 * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int chmod ( const char * __file , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int lchmod ( const char * __file , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fchmod ( int __fd , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) ;
extern int fchmodat ( int __fd , const char * __file , __mode_t __mode , int __flag ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern __mode_t umask ( __mode_t __mask ) __attribute__ ( ( __nothrow__ ) ) ;
extern __mode_t getumask ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int mkdir ( const char * __path , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkdirat ( int __fd , const char * __path , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int mknod ( const char * __path , __mode_t __mode , __dev_t __dev ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mknodat ( int __fd , const char * __path , __mode_t __mode , __dev_t __dev ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int mkfifo ( const char * __path , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int mkfifoat ( int __fd , const char * __path , __mode_t __mode ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int utimensat ( int __fd , const char * __path , const struct timespec __times [ 2 ] , int __flags ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int futimens ( int __fd , const struct timespec __times [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) ;
typedef __signed__ char __s8 ; typedef unsigned char __u8 ; typedef __signed__ short __s16 ; typedef unsigned short __u16 ; typedef __signed__ int __s32 ; typedef unsigned int __u32 ;
__extension__ typedef __signed__ long long __s64 ; __extension__ typedef unsigned long long __u64 ;
typedef struct { unsigned long fds_bits [ 1024 / ( 8 * sizeof ( long ) ) ] ; } __kernel_fd_set ; typedef void ( * __kernel_sighandler_t ) ( int ) ; typedef int __kernel_key_t ; typedef int __kernel_mqd_t ;
typedef unsigned short __kernel_old_uid_t ; typedef unsigned short __kernel_old_gid_t ;
typedef unsigned long __kernel_old_dev_t ;
typedef long __kernel_long_t ; typedef unsigned long __kernel_ulong_t ;
typedef __kernel_ulong_t __kernel_ino_t ;
typedef unsigned int __kernel_mode_t ;
typedef int __kernel_pid_t ;
typedef int __kernel_ipc_pid_t ;
typedef unsigned int __kernel_uid_t ; typedef unsigned int __kernel_gid_t ;
typedef __kernel_long_t __kernel_suseconds_t ;
typedef int __kernel_daddr_t ;
typedef unsigned int __kernel_uid32_t ; typedef unsigned int __kernel_gid32_t ;
typedef __kernel_ulong_t __kernel_size_t ; typedef __kernel_long_t __kernel_ssize_t ; typedef __kernel_long_t __kernel_ptrdiff_t ;
typedef struct { int val [ 2 ] ; } __kernel_fsid_t ;
typedef __kernel_long_t __kernel_off_t ; typedef long long __kernel_loff_t ; typedef __kernel_long_t __kernel_old_time_t ; typedef __kernel_long_t __kernel_time_t ; typedef long long __kernel_time64_t ; typedef __kernel_long_t __kernel_clock_t ; typedef int __kernel_timer_t ; typedef int __kernel_clockid_t ; typedef char * __kernel_caddr_t ; typedef unsigned short __kernel_uid16_t ; typedef unsigned short __kernel_gid16_t ;
typedef __signed__ __int128 __s128 __attribute__ ( ( aligned ( 16 ) ) ) ; typedef unsigned __int128 __u128 __attribute__ ( ( aligned ( 16 ) ) ) ;
typedef __u16 __le16 ; typedef __u16 __be16 ; typedef __u32 __le32 ; typedef __u32 __be32 ; typedef __u64 __le64 ; typedef __u64 __be64 ; typedef __u16 __sum16 ; typedef __u32 __wsum ;
typedef unsigned __poll_t ;
struct statx_timestamp { __s64 tv_sec ; __u32 tv_nsec ; __s32 __reserved ; } ; struct statx { __u32 stx_mask ; __u32 stx_blksize ; __u64 stx_attributes ; __u32 stx_nlink ; __u32 stx_uid ; __u32 stx_gid ; __u16 stx_mode ; __u16 __spare0 [ 1 ] ; __u64 stx_ino ; __u64 stx_size ; __u64 stx_blocks ; __u64 stx_attributes_mask ; struct statx_timestamp stx_atime ; struct statx_timestamp stx_btime ; struct statx_timestamp stx_ctime ; struct statx_timestamp stx_mtime ; __u32 stx_rdev_major ; __u32 stx_rdev_minor ; __u32 stx_dev_major ; __u32 stx_dev_minor ; __u64 stx_mnt_id ; __u32 stx_dio_mem_align ; __u32 stx_dio_offset_align ; __u64 __spare3 [ 12 ] ; } ;
int statx ( int __dirfd , const char * __restrict __path , int __flags , unsigned int __mask , struct statx * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 5 ) ) ) ;


typedef __socklen_t socklen_t ;
extern int access ( const char * __name , int __type ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int euidaccess ( const char * __name , int __type ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int eaccess ( const char * __name , int __type ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int execveat ( int __fd , const char * __path , char * const __argv [ ] , char * const __envp [ ] , int __flags ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern int faccessat ( int __fd , const char * __file , int __type , int __flag ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern __off_t lseek ( int __fd , __off_t __offset , int __whence ) __attribute__ ( ( __nothrow__ ) ) ;
extern __off64_t lseek64 ( int __fd , __off64_t __offset , int __whence ) __attribute__ ( ( __nothrow__ ) ) ;
extern int close ( int __fd ) ;
extern void closefrom ( int __lowfd ) __attribute__ ( ( __nothrow__ ) ) ;
extern ssize_t read ( int __fd , void * __buf , size_t __nbytes ) ; extern ssize_t write ( int __fd , const void * __buf , size_t __n ) ;
extern ssize_t pread ( int __fd , void * __buf , size_t __nbytes , __off_t __offset ) ; extern ssize_t pwrite ( int __fd , const void * __buf , size_t __n , __off_t __offset ) ;
extern ssize_t pread64 ( int __fd , void * __buf , size_t __nbytes , __off64_t __offset ) ; extern ssize_t pwrite64 ( int __fd , const void * __buf , size_t __n , __off64_t __offset ) ;
extern int pipe ( int __pipedes [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pipe2 ( int __pipedes [ 2 ] , int __flags ) __attribute__ ( ( __nothrow__ ) ) ;
extern unsigned int alarm ( unsigned int __seconds ) __attribute__ ( ( __nothrow__ ) ) ; extern unsigned int sleep ( unsigned int __seconds ) ;
extern __useconds_t ualarm ( __useconds_t __value , __useconds_t __interval ) __attribute__ ( ( __nothrow__ ) ) ; extern int usleep ( __useconds_t __useconds ) ;
extern int pause ( void ) ; extern int chown ( const char * __file , __uid_t __owner , __gid_t __group ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fchown ( int __fd , __uid_t __owner , __gid_t __group ) __attribute__ ( ( __nothrow__ ) ) ; extern int lchown ( const char * __file , __uid_t __owner , __gid_t __group ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fchownat ( int __fd , const char * __file , __uid_t __owner , __gid_t __group , int __flag ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int chdir ( const char * __path ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fchdir ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * getcwd ( char * __buf , size_t __size ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * get_current_dir_name ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * getwd ( char * __buf ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int dup ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ; extern int dup2 ( int __fd , int __fd2 ) __attribute__ ( ( __nothrow__ ) ) ;
extern int dup3 ( int __fd , int __fd2 , int __flags ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * * __environ ;
extern char * * environ ;
extern int execve ( const char * __path , char * const __argv [ ] , char * const __envp [ ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int fexecve ( int __fd , char * const __argv [ ] , char * const __envp [ ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int execv ( const char * __path , char * const __argv [ ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int execle ( const char * __path , const char * __arg , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int execl ( const char * __path , const char * __arg , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int execvp ( const char * __file , char * const __argv [ ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int execlp ( const char * __file , const char * __arg , ... ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int execvpe ( const char * __file , char * const __argv [ ] , char * const __envp [ ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int nice ( int __inc ) __attribute__ ( ( __nothrow__ ) ) ;
extern void _exit ( int __status ) __attribute__ ( ( __noreturn__ ) ) ;
enum { _PC_LINK_MAX ,
_PC_MAX_CANON ,
_PC_MAX_INPUT ,
_PC_NAME_MAX ,
_PC_PATH_MAX ,
_PC_PIPE_BUF ,
_PC_CHOWN_RESTRICTED ,
_PC_NO_TRUNC ,
_PC_VDISABLE ,
_PC_SYNC_IO ,
_PC_ASYNC_IO ,
_PC_PRIO_IO ,
_PC_SOCK_MAXBUF ,
_PC_FILESIZEBITS ,
_PC_REC_INCR_XFER_SIZE ,
_PC_REC_MAX_XFER_SIZE ,
_PC_REC_MIN_XFER_SIZE ,
_PC_REC_XFER_ALIGN ,
_PC_ALLOC_SIZE_MIN ,
_PC_SYMLINK_MAX ,
_PC_2_SYMLINKS
} ; enum { _SC_ARG_MAX ,
_SC_CHILD_MAX ,
_SC_CLK_TCK ,
_SC_NGROUPS_MAX ,
_SC_OPEN_MAX ,
_SC_STREAM_MAX ,
_SC_TZNAME_MAX ,
_SC_JOB_CONTROL ,
_SC_SAVED_IDS ,
_SC_REALTIME_SIGNALS ,
_SC_PRIORITY_SCHEDULING ,
_SC_TIMERS ,
_SC_ASYNCHRONOUS_IO ,
_SC_PRIORITIZED_IO ,
_SC_SYNCHRONIZED_IO ,
_SC_FSYNC ,
_SC_MAPPED_FILES ,
_SC_MEMLOCK ,
_SC_MEMLOCK_RANGE ,
_SC_MEMORY_PROTECTION ,
_SC_MESSAGE_PASSING ,
_SC_SEMAPHORES ,
_SC_SHARED_MEMORY_OBJECTS ,
_SC_AIO_LISTIO_MAX ,
_SC_AIO_MAX ,
_SC_AIO_PRIO_DELTA_MAX ,
_SC_DELAYTIMER_MAX ,
_SC_MQ_OPEN_MAX ,
_SC_MQ_PRIO_MAX ,
_SC_VERSION ,
_SC_PAGESIZE ,
_SC_RTSIG_MAX ,
_SC_SEM_NSEMS_MAX ,
_SC_SEM_VALUE_MAX ,
_SC_SIGQUEUE_MAX ,
_SC_TIMER_MAX ,
_SC_BC_BASE_MAX ,
_SC_BC_DIM_MAX ,
_SC_BC_SCALE_MAX ,
_SC_BC_STRING_MAX ,
_SC_COLL_WEIGHTS_MAX ,
_SC_EQUIV_CLASS_MAX ,
_SC_EXPR_NEST_MAX ,
_SC_LINE_MAX ,
_SC_RE_DUP_MAX ,
_SC_CHARCLASS_NAME_MAX ,
_SC_2_VERSION ,
_SC_2_C_BIND ,
_SC_2_C_DEV ,
_SC_2_FORT_DEV ,
_SC_2_FORT_RUN ,
_SC_2_SW_DEV ,
_SC_2_LOCALEDEF ,
_SC_PII ,
_SC_PII_XTI ,
_SC_PII_SOCKET ,
_SC_PII_INTERNET ,
_SC_PII_OSI ,
_SC_POLL ,
_SC_SELECT ,
_SC_UIO_MAXIOV ,
_SC_IOV_MAX = _SC_UIO_MAXIOV ,
_SC_PII_INTERNET_STREAM ,
_SC_PII_INTERNET_DGRAM ,
_SC_PII_OSI_COTS ,
_SC_PII_OSI_CLTS ,
_SC_PII_OSI_M ,
_SC_T_IOV_MAX ,
_SC_THREADS ,
_SC_THREAD_SAFE_FUNCTIONS ,
_SC_GETGR_R_SIZE_MAX ,
_SC_GETPW_R_SIZE_MAX ,
_SC_LOGIN_NAME_MAX ,
_SC_TTY_NAME_MAX ,
_SC_THREAD_DESTRUCTOR_ITERATIONS ,
_SC_THREAD_KEYS_MAX ,
_SC_THREAD_STACK_MIN ,
_SC_THREAD_THREADS_MAX ,
_SC_THREAD_ATTR_STACKADDR ,
_SC_THREAD_ATTR_STACKSIZE ,
_SC_THREAD_PRIORITY_SCHEDULING ,
_SC_THREAD_PRIO_INHERIT ,
_SC_THREAD_PRIO_PROTECT ,
_SC_THREAD_PROCESS_SHARED ,
_SC_NPROCESSORS_CONF ,
_SC_NPROCESSORS_ONLN ,
_SC_PHYS_PAGES ,
_SC_AVPHYS_PAGES ,
_SC_ATEXIT_MAX ,
_SC_PASS_MAX ,
_SC_XOPEN_VERSION ,
_SC_XOPEN_XCU_VERSION ,
_SC_XOPEN_UNIX ,
_SC_XOPEN_CRYPT ,
_SC_XOPEN_ENH_I18N ,
_SC_XOPEN_SHM ,
_SC_2_CHAR_TERM ,
_SC_2_C_VERSION ,
_SC_2_UPE ,
_SC_XOPEN_XPG2 ,
_SC_XOPEN_XPG3 ,
_SC_XOPEN_XPG4 ,
_SC_CHAR_BIT ,
_SC_CHAR_MAX ,
_SC_CHAR_MIN ,
_SC_INT_MAX ,
_SC_INT_MIN ,
_SC_LONG_BIT ,
_SC_WORD_BIT ,
_SC_MB_LEN_MAX ,
_SC_NZERO ,
_SC_SSIZE_MAX ,
_SC_SCHAR_MAX ,
_SC_SCHAR_MIN ,
_SC_SHRT_MAX ,
_SC_SHRT_MIN ,
_SC_UCHAR_MAX ,
_SC_UINT_MAX ,
_SC_ULONG_MAX ,
_SC_USHRT_MAX ,
_SC_NL_ARGMAX ,
_SC_NL_LANGMAX ,
_SC_NL_MSGMAX ,
_SC_NL_NMAX ,
_SC_NL_SETMAX ,
_SC_NL_TEXTMAX ,
_SC_XBS5_ILP32_OFF32 ,
_SC_XBS5_ILP32_OFFBIG ,
_SC_XBS5_LP64_OFF64 ,
_SC_XBS5_LPBIG_OFFBIG ,
_SC_XOPEN_LEGACY ,
_SC_XOPEN_REALTIME ,
_SC_XOPEN_REALTIME_THREADS ,
_SC_ADVISORY_INFO ,
_SC_BARRIERS ,
_SC_BASE ,
_SC_C_LANG_SUPPORT ,
_SC_C_LANG_SUPPORT_R ,
_SC_CLOCK_SELECTION ,
_SC_CPUTIME ,
_SC_THREAD_CPUTIME ,
_SC_DEVICE_IO ,
_SC_DEVICE_SPECIFIC ,
_SC_DEVICE_SPECIFIC_R ,
_SC_FD_MGMT ,
_SC_FIFO ,
_SC_PIPE ,
_SC_FILE_ATTRIBUTES ,
_SC_FILE_LOCKING ,
_SC_FILE_SYSTEM ,
_SC_MONOTONIC_CLOCK ,
_SC_MULTI_PROCESS ,
_SC_SINGLE_PROCESS ,
_SC_NETWORKING ,
_SC_READER_WRITER_LOCKS ,
_SC_SPIN_LOCKS ,
_SC_REGEXP ,
_SC_REGEX_VERSION ,
_SC_SHELL ,
_SC_SIGNALS ,
_SC_SPAWN ,
_SC_SPORADIC_SERVER ,
_SC_THREAD_SPORADIC_SERVER ,
_SC_SYSTEM_DATABASE ,
_SC_SYSTEM_DATABASE_R ,
_SC_TIMEOUTS ,
_SC_TYPED_MEMORY_OBJECTS ,
_SC_USER_GROUPS ,
_SC_USER_GROUPS_R ,
_SC_2_PBS ,
_SC_2_PBS_ACCOUNTING ,
_SC_2_PBS_LOCATE ,
_SC_2_PBS_MESSAGE ,
_SC_2_PBS_TRACK ,
_SC_SYMLOOP_MAX ,
_SC_STREAMS ,
_SC_2_PBS_CHECKPOINT ,
_SC_V6_ILP32_OFF32 ,
_SC_V6_ILP32_OFFBIG ,
_SC_V6_LP64_OFF64 ,
_SC_V6_LPBIG_OFFBIG ,
_SC_HOST_NAME_MAX ,
_SC_TRACE ,
_SC_TRACE_EVENT_FILTER ,
_SC_TRACE_INHERIT ,
_SC_TRACE_LOG ,
_SC_LEVEL1_ICACHE_SIZE ,
_SC_LEVEL1_ICACHE_ASSOC ,
_SC_LEVEL1_ICACHE_LINESIZE ,
_SC_LEVEL1_DCACHE_SIZE ,
_SC_LEVEL1_DCACHE_ASSOC ,
_SC_LEVEL1_DCACHE_LINESIZE ,
_SC_LEVEL2_CACHE_SIZE ,
_SC_LEVEL2_CACHE_ASSOC ,
_SC_LEVEL2_CACHE_LINESIZE ,
_SC_LEVEL3_CACHE_SIZE ,
_SC_LEVEL3_CACHE_ASSOC ,
_SC_LEVEL3_CACHE_LINESIZE ,
_SC_LEVEL4_CACHE_SIZE ,
_SC_LEVEL4_CACHE_ASSOC ,
_SC_LEVEL4_CACHE_LINESIZE ,
_SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50 ,
_SC_RAW_SOCKETS ,
_SC_V7_ILP32_OFF32 ,
_SC_V7_ILP32_OFFBIG ,
_SC_V7_LP64_OFF64 ,
_SC_V7_LPBIG_OFFBIG ,
_SC_SS_REPL_MAX ,
_SC_TRACE_EVENT_NAME_MAX ,
_SC_TRACE_NAME_MAX ,
_SC_TRACE_SYS_MAX ,
_SC_TRACE_USER_EVENT_MAX ,
_SC_XOPEN_STREAMS ,
_SC_THREAD_ROBUST_PRIO_INHERIT ,
_SC_THREAD_ROBUST_PRIO_PROTECT ,
_SC_MINSIGSTKSZ ,
_SC_SIGSTKSZ
} ; enum { _CS_PATH ,
_CS_V6_WIDTH_RESTRICTED_ENVS ,
_CS_GNU_LIBC_VERSION ,
_CS_GNU_LIBPTHREAD_VERSION ,
_CS_V5_WIDTH_RESTRICTED_ENVS ,
_CS_V7_WIDTH_RESTRICTED_ENVS ,
_CS_LFS_CFLAGS = 1000 ,
_CS_LFS_LDFLAGS ,
_CS_LFS_LIBS ,
_CS_LFS_LINTFLAGS ,
_CS_LFS64_CFLAGS ,
_CS_LFS64_LDFLAGS ,
_CS_LFS64_LIBS ,
_CS_LFS64_LINTFLAGS ,
_CS_XBS5_ILP32_OFF32_CFLAGS = 1100 ,
_CS_XBS5_ILP32_OFF32_LDFLAGS ,
_CS_XBS5_ILP32_OFF32_LIBS ,
_CS_XBS5_ILP32_OFF32_LINTFLAGS ,
_CS_XBS5_ILP32_OFFBIG_CFLAGS ,
_CS_XBS5_ILP32_OFFBIG_LDFLAGS ,
_CS_XBS5_ILP32_OFFBIG_LIBS ,
_CS_XBS5_ILP32_OFFBIG_LINTFLAGS ,
_CS_XBS5_LP64_OFF64_CFLAGS ,
_CS_XBS5_LP64_OFF64_LDFLAGS ,
_CS_XBS5_LP64_OFF64_LIBS ,
_CS_XBS5_LP64_OFF64_LINTFLAGS ,
_CS_XBS5_LPBIG_OFFBIG_CFLAGS ,
_CS_XBS5_LPBIG_OFFBIG_LDFLAGS ,
_CS_XBS5_LPBIG_OFFBIG_LIBS ,
_CS_XBS5_LPBIG_OFFBIG_LINTFLAGS ,
_CS_POSIX_V6_ILP32_OFF32_CFLAGS ,
_CS_POSIX_V6_ILP32_OFF32_LDFLAGS ,
_CS_POSIX_V6_ILP32_OFF32_LIBS ,
_CS_POSIX_V6_ILP32_OFF32_LINTFLAGS ,
_CS_POSIX_V6_ILP32_OFFBIG_CFLAGS ,
_CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS ,
_CS_POSIX_V6_ILP32_OFFBIG_LIBS ,
_CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS ,
_CS_POSIX_V6_LP64_OFF64_CFLAGS ,
_CS_POSIX_V6_LP64_OFF64_LDFLAGS ,
_CS_POSIX_V6_LP64_OFF64_LIBS ,
_CS_POSIX_V6_LP64_OFF64_LINTFLAGS ,
_CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS ,
_CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS ,
_CS_POSIX_V6_LPBIG_OFFBIG_LIBS ,
_CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS ,
_CS_POSIX_V7_ILP32_OFF32_CFLAGS ,
_CS_POSIX_V7_ILP32_OFF32_LDFLAGS ,
_CS_POSIX_V7_ILP32_OFF32_LIBS ,
_CS_POSIX_V7_ILP32_OFF32_LINTFLAGS ,
_CS_POSIX_V7_ILP32_OFFBIG_CFLAGS ,
_CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS ,
_CS_POSIX_V7_ILP32_OFFBIG_LIBS ,
_CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS ,
_CS_POSIX_V7_LP64_OFF64_CFLAGS ,
_CS_POSIX_V7_LP64_OFF64_LDFLAGS ,
_CS_POSIX_V7_LP64_OFF64_LIBS ,
_CS_POSIX_V7_LP64_OFF64_LINTFLAGS ,
_CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS ,
_CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS ,
_CS_POSIX_V7_LPBIG_OFFBIG_LIBS ,
_CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS ,
_CS_V6_ENV ,
_CS_V7_ENV
} ;
extern long int pathconf ( const char * __path , int __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long int fpathconf ( int __fd , int __name ) __attribute__ ( ( __nothrow__ ) ) ; extern long int sysconf ( int __name ) __attribute__ ( ( __nothrow__ ) ) ;
extern size_t confstr ( int __name , char * __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t getpid ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern __pid_t getppid ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern __pid_t getpgrp ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern __pid_t __getpgid ( __pid_t __pid ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t getpgid ( __pid_t __pid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setpgid ( __pid_t __pid , __pid_t __pgid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setpgrp ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t setsid ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t getsid ( __pid_t __pid ) __attribute__ ( ( __nothrow__ ) ) ;
extern __uid_t getuid ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern __uid_t geteuid ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern __gid_t getgid ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern __gid_t getegid ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int getgroups ( int __size , __gid_t __list [ ] ) __attribute__ ( ( __nothrow__ ) ) ;
extern int group_member ( __gid_t __gid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setuid ( __uid_t __uid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setreuid ( __uid_t __ruid , __uid_t __euid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int seteuid ( __uid_t __uid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setgid ( __gid_t __gid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setregid ( __gid_t __rgid , __gid_t __egid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setegid ( __gid_t __gid ) __attribute__ ( ( __nothrow__ ) ) ;
extern int getresuid ( __uid_t * __ruid , __uid_t * __euid , __uid_t * __suid ) __attribute__ ( ( __nothrow__ ) ) ; extern int getresgid ( __gid_t * __rgid , __gid_t * __egid , __gid_t * __sgid ) __attribute__ ( ( __nothrow__ ) ) ; extern int setresuid ( __uid_t __ruid , __uid_t __euid , __uid_t __suid ) __attribute__ ( ( __nothrow__ ) ) ; extern int setresgid ( __gid_t __rgid , __gid_t __egid , __gid_t __sgid ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t fork ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t vfork ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t _Fork ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern char * ttyname ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ; extern int ttyname_r ( int __fd , char * __buf , size_t __buflen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int isatty ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ;
extern int ttyslot ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int link ( const char * __from , const char * __to ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int linkat ( int __fromfd , const char * __from , int __tofd , const char * __to , int __flags ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 4 ) ) ) ;
extern int symlink ( const char * __from , const char * __to ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern ssize_t readlink ( const char * __restrict __path , char * __restrict __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int symlinkat ( const char * __from , int __tofd , const char * __to ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern ssize_t readlinkat ( int __fd , const char * __restrict __path , char * __restrict __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern int unlink ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int unlinkat ( int __fd , const char * __name , int __flag ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int rmdir ( const char * __path ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern __pid_t tcgetpgrp ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ; extern int tcsetpgrp ( int __fd , __pid_t __pgrp_id ) __attribute__ ( ( __nothrow__ ) ) ; extern char * getlogin ( void ) ;
extern int getlogin_r ( char * __name , size_t __name_len ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int setlogin ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern char * optarg ; extern int optind ; extern int opterr ; extern int optopt ; extern int getopt ( int ___argc , char * const * ___argv , const char * __shortopts ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;


extern int gethostname ( char * __name , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int sethostname ( const char * __name , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sethostid ( long int __id ) __attribute__ ( ( __nothrow__ ) ) ; extern int getdomainname ( char * __name , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int setdomainname ( const char * __name , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int vhangup ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int revoke ( const char * __file ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int profil ( unsigned short int * __sample_buffer , size_t __size , size_t __offset , unsigned int __scale ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int acct ( const char * __name ) __attribute__ ( ( __nothrow__ ) ) ; extern char * getusershell ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern void endusershell ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern void setusershell ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int daemon ( int __nochdir , int __noclose ) __attribute__ ( ( __nothrow__ ) ) ;
extern int chroot ( const char * __path ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern char * getpass ( const char * __prompt ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int fsync ( int __fd ) ;
extern int syncfs ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ;
extern long int gethostid ( void ) ; extern void sync ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int getpagesize ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern int getdtablesize ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int truncate ( const char * __file , __off_t __length ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int truncate64 ( const char * __file , __off64_t __length ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int ftruncate ( int __fd , __off_t __length ) __attribute__ ( ( __nothrow__ ) ) ;
extern int ftruncate64 ( int __fd , __off64_t __length ) __attribute__ ( ( __nothrow__ ) ) ;
extern int brk ( void * __addr ) __attribute__ ( ( __nothrow__ ) ) ; extern void * sbrk ( intptr_t __delta ) __attribute__ ( ( __nothrow__ ) ) ;
extern long int syscall ( long int __sysno , ... ) __attribute__ ( ( __nothrow__ ) ) ;
extern int lockf ( int __fd , int __cmd , __off_t __len ) ;
extern int lockf64 ( int __fd , int __cmd , __off64_t __len ) ;
ssize_t copy_file_range ( int __infd , __off64_t * __pinoff , int __outfd , __off64_t * __poutoff , size_t __length , unsigned int __flags ) ;
extern int fdatasync ( int __fildes ) ;
extern char * crypt ( const char * __key , const char * __salt ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern void swab ( const void * __restrict __from , void * __restrict __to , ssize_t __n ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
int getentropy ( void * __buffer , size_t __length ) ;
extern int close_range ( unsigned int __fd , unsigned int __max_fd , int __flags ) __attribute__ ( ( __nothrow__ ) ) ;
extern __pid_t gettid ( void ) __attribute__ ( ( __nothrow__ ) ) ;

struct sched_param { int sched_priority ; } ;

extern int clone ( int ( * __fn ) ( void * __arg ) , void * __child_stack , int __flags , void * __arg , ... ) __attribute__ ( ( __nothrow__ ) ) ; extern int unshare ( int __flags ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_getcpu ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int getcpu ( unsigned int * , unsigned int * ) __attribute__ ( ( __nothrow__ ) ) ; extern int setns ( int __fd , int __nstype ) __attribute__ ( ( __nothrow__ ) ) ;

typedef unsigned long int __cpu_mask ;
typedef struct { __cpu_mask __bits [ 1024 / ( 8 * sizeof ( __cpu_mask ) ) ] ; } cpu_set_t ;
extern int __sched_cpucount ( size_t __setsize , const cpu_set_t * __setp ) __attribute__ ( ( __nothrow__ ) ) ; extern cpu_set_t * __sched_cpualloc ( size_t __count ) __attribute__ ( ( __nothrow__ ) ) ; extern void __sched_cpufree ( cpu_set_t * __set ) __attribute__ ( ( __nothrow__ ) ) ;
extern int sched_setparam ( __pid_t __pid , const struct sched_param * __param ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_getparam ( __pid_t __pid , struct sched_param * __param ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_setscheduler ( __pid_t __pid , int __policy , const struct sched_param * __param ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_getscheduler ( __pid_t __pid ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_yield ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_get_priority_max ( int __algorithm ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_get_priority_min ( int __algorithm ) __attribute__ ( ( __nothrow__ ) ) ;
extern int sched_rr_get_interval ( __pid_t __pid , struct timespec * __t ) __attribute__ ( ( __nothrow__ ) ) ;
extern int sched_setaffinity ( __pid_t __pid , size_t __cpusetsize , const cpu_set_t * __cpuset ) __attribute__ ( ( __nothrow__ ) ) ; extern int sched_getaffinity ( __pid_t __pid , size_t __cpusetsize , cpu_set_t * __cpuset ) __attribute__ ( ( __nothrow__ ) ) ;

typedef long int __jmp_buf [ 8 ] ;
struct __jmp_buf_tag { __jmp_buf __jmpbuf ; int __mask_was_saved ; __sigset_t __saved_mask ; } ;
enum { PTHREAD_CREATE_JOINABLE ,
PTHREAD_CREATE_DETACHED
} ; enum { PTHREAD_MUTEX_TIMED_NP , PTHREAD_MUTEX_RECURSIVE_NP , PTHREAD_MUTEX_ERRORCHECK_NP , PTHREAD_MUTEX_ADAPTIVE_NP
, PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP , PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP , PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP , PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL
, PTHREAD_MUTEX_FAST_NP = PTHREAD_MUTEX_TIMED_NP
} ;
enum { PTHREAD_MUTEX_STALLED , PTHREAD_MUTEX_STALLED_NP = PTHREAD_MUTEX_STALLED , PTHREAD_MUTEX_ROBUST , PTHREAD_MUTEX_ROBUST_NP = PTHREAD_MUTEX_ROBUST } ;
enum { PTHREAD_PRIO_NONE , PTHREAD_PRIO_INHERIT , PTHREAD_PRIO_PROTECT } ;
enum { PTHREAD_RWLOCK_PREFER_READER_NP , PTHREAD_RWLOCK_PREFER_WRITER_NP , PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP , PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_READER_NP } ;
enum { PTHREAD_INHERIT_SCHED ,
PTHREAD_EXPLICIT_SCHED
} ; enum { PTHREAD_SCOPE_SYSTEM ,
PTHREAD_SCOPE_PROCESS
} ; enum { PTHREAD_PROCESS_PRIVATE ,
PTHREAD_PROCESS_SHARED
} ;
struct _pthread_cleanup_buffer { void ( * __routine ) ( void * ) ; void * __arg ; int __canceltype ; struct _pthread_cleanup_buffer * __prev ; } ; enum { PTHREAD_CANCEL_ENABLE ,
PTHREAD_CANCEL_DISABLE
} ; enum { PTHREAD_CANCEL_DEFERRED ,
PTHREAD_CANCEL_ASYNCHRONOUS
} ;
extern int pthread_create ( pthread_t * __restrict __newthread , const pthread_attr_t * __restrict __attr , void * ( * __start_routine ) ( void * ) , void * __restrict __arg ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern void pthread_exit ( void * __retval ) __attribute__ ( ( __noreturn__ ) ) ; extern int pthread_join ( pthread_t __th , void * * __thread_return ) ;
extern int pthread_tryjoin_np ( pthread_t __th , void * * __thread_return ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_timedjoin_np ( pthread_t __th , void * * __thread_return , const struct timespec * __abstime ) ; extern int pthread_clockjoin_np ( pthread_t __th , void * * __thread_return , clockid_t __clockid , const struct timespec * __abstime ) ;
extern int pthread_detach ( pthread_t __th ) __attribute__ ( ( __nothrow__ ) ) ; extern pthread_t pthread_self ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern int pthread_equal ( pthread_t __thread1 , pthread_t __thread2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern int pthread_attr_init ( pthread_attr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_destroy ( pthread_attr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_getdetachstate ( const pthread_attr_t * __attr , int * __detachstate ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setdetachstate ( pthread_attr_t * __attr , int __detachstate ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_getguardsize ( const pthread_attr_t * __attr , size_t * __guardsize ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setguardsize ( pthread_attr_t * __attr , size_t __guardsize ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_getschedparam ( const pthread_attr_t * __restrict __attr , struct sched_param * __restrict __param ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setschedparam ( pthread_attr_t * __restrict __attr , const struct sched_param * __restrict __param ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_getschedpolicy ( const pthread_attr_t * __restrict __attr , int * __restrict __policy ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setschedpolicy ( pthread_attr_t * __attr , int __policy ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_getinheritsched ( const pthread_attr_t * __restrict __attr , int * __restrict __inherit ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setinheritsched ( pthread_attr_t * __attr , int __inherit ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_getscope ( const pthread_attr_t * __restrict __attr , int * __restrict __scope ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setscope ( pthread_attr_t * __attr , int __scope ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_getstackaddr ( const pthread_attr_t * __restrict __attr , void * * __restrict __stackaddr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int pthread_attr_setstackaddr ( pthread_attr_t * __attr , void * __stackaddr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int pthread_attr_getstacksize ( const pthread_attr_t * __restrict __attr , size_t * __restrict __stacksize ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_attr_setstacksize ( pthread_attr_t * __attr , size_t __stacksize ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_attr_getstack ( const pthread_attr_t * __restrict __attr , void * * __restrict __stackaddr , size_t * __restrict __stacksize ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ; extern int pthread_attr_setstack ( pthread_attr_t * __attr , void * __stackaddr , size_t __stacksize ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_attr_setaffinity_np ( pthread_attr_t * __attr , size_t __cpusetsize , const cpu_set_t * __cpuset ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern int pthread_attr_getaffinity_np ( const pthread_attr_t * __attr , size_t __cpusetsize , cpu_set_t * __cpuset ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ; extern int pthread_getattr_default_np ( pthread_attr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_attr_setsigmask_np ( pthread_attr_t * __attr , const __sigset_t * sigmask ) ; extern int pthread_attr_getsigmask_np ( const pthread_attr_t * __attr , __sigset_t * sigmask ) ;
extern int pthread_setattr_default_np ( const pthread_attr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_getattr_np ( pthread_t __th , pthread_attr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int pthread_setschedparam ( pthread_t __target_thread , int __policy , const struct sched_param * __param ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ; extern int pthread_getschedparam ( pthread_t __target_thread , int * __restrict __policy , struct sched_param * __restrict __param ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ; extern int pthread_setschedprio ( pthread_t __target_thread , int __prio ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_getname_np ( pthread_t __target_thread , char * __buf , size_t __buflen ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ; extern int pthread_setname_np ( pthread_t __target_thread , const char * __name ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int pthread_getconcurrency ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int pthread_setconcurrency ( int __level ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_yield ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_yield ( void ) __asm__ ( "__USER_LABEL_PREFIX__" "sched_yield" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int pthread_setaffinity_np ( pthread_t __th , size_t __cpusetsize , const cpu_set_t * __cpuset ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ; extern int pthread_getaffinity_np ( pthread_t __th , size_t __cpusetsize , cpu_set_t * __cpuset ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 3 ) ) ) ;
extern int pthread_once ( pthread_once_t * __once_control , void ( * __init_routine ) ( void ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_setcancelstate ( int __state , int * __oldstate ) ; extern int pthread_setcanceltype ( int __type , int * __oldtype ) ; extern int pthread_cancel ( pthread_t __th ) ; extern void pthread_testcancel ( void ) ; struct __cancel_jmp_buf_tag { __jmp_buf __cancel_jmp_buf ; int __mask_was_saved ; } ; typedef struct { struct __cancel_jmp_buf_tag __cancel_jmp_buf [ 1 ] ; void * __pad [ 4 ] ; } __pthread_unwind_buf_t __attribute__ ( ( __aligned__ ) ) ;
struct __pthread_cleanup_frame { void ( * __cancel_routine ) ( void * ) ; void * __cancel_arg ; int __do_it ; int __cancel_type ; } ;
extern void __pthread_register_cancel ( __pthread_unwind_buf_t * __buf ) ;
extern void __pthread_unregister_cancel ( __pthread_unwind_buf_t * __buf ) ;
extern void __pthread_register_cancel_defer ( __pthread_unwind_buf_t * __buf ) ;
extern void __pthread_unregister_cancel_restore ( __pthread_unwind_buf_t * __buf ) ;
extern void __pthread_unwind_next ( __pthread_unwind_buf_t * __buf ) __attribute__ ( ( __noreturn__ ) )
__attribute__ ( ( __weak__ ) )
;
extern int __sigsetjmp ( struct __jmp_buf_tag __env [ 1 ] , int __savemask ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_mutex_init ( pthread_mutex_t * __mutex , const pthread_mutexattr_t * __mutexattr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutex_destroy ( pthread_mutex_t * __mutex ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutex_trylock ( pthread_mutex_t * __mutex ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutex_lock ( pthread_mutex_t * __mutex ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_mutex_timedlock ( pthread_mutex_t * __restrict __mutex , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int pthread_mutex_clocklock ( pthread_mutex_t * __restrict __mutex , clockid_t __clockid , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern int pthread_mutex_unlock ( pthread_mutex_t * __mutex ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutex_getprioceiling ( const pthread_mutex_t * __restrict __mutex , int * __restrict __prioceiling ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_mutex_setprioceiling ( pthread_mutex_t * __restrict __mutex , int __prioceiling , int * __restrict __old_ceiling ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern int pthread_mutex_consistent ( pthread_mutex_t * __mutex ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_mutex_consistent_np ( pthread_mutex_t * ) __asm__ ( "__USER_LABEL_PREFIX__" "pthread_mutex_consistent" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int pthread_mutexattr_init ( pthread_mutexattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutexattr_destroy ( pthread_mutexattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutexattr_getpshared ( const pthread_mutexattr_t * __restrict __attr , int * __restrict __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_mutexattr_setpshared ( pthread_mutexattr_t * __attr , int __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_mutexattr_gettype ( const pthread_mutexattr_t * __restrict __attr , int * __restrict __kind ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_mutexattr_settype ( pthread_mutexattr_t * __attr , int __kind ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_mutexattr_getprotocol ( const pthread_mutexattr_t * __restrict __attr , int * __restrict __protocol ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_mutexattr_setprotocol ( pthread_mutexattr_t * __attr , int __protocol ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_mutexattr_getprioceiling ( const pthread_mutexattr_t * __restrict __attr , int * __restrict __prioceiling ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_mutexattr_setprioceiling ( pthread_mutexattr_t * __attr , int __prioceiling ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_mutexattr_getrobust ( const pthread_mutexattr_t * __attr , int * __robustness ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int pthread_mutexattr_getrobust_np ( pthread_mutexattr_t * , int * ) __asm__ ( "__USER_LABEL_PREFIX__" "pthread_mutexattr_getrobust" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int pthread_mutexattr_setrobust ( pthread_mutexattr_t * __attr , int __robustness ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_mutexattr_setrobust_np ( pthread_mutexattr_t * , int ) __asm__ ( "__USER_LABEL_PREFIX__" "pthread_mutexattr_setrobust" ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int pthread_rwlock_init ( pthread_rwlock_t * __restrict __rwlock , const pthread_rwlockattr_t * __restrict __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlock_destroy ( pthread_rwlock_t * __rwlock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlock_rdlock ( pthread_rwlock_t * __rwlock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlock_tryrdlock ( pthread_rwlock_t * __rwlock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_rwlock_timedrdlock ( pthread_rwlock_t * __restrict __rwlock , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int pthread_rwlock_clockrdlock ( pthread_rwlock_t * __restrict __rwlock , clockid_t __clockid , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern int pthread_rwlock_wrlock ( pthread_rwlock_t * __rwlock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlock_trywrlock ( pthread_rwlock_t * __rwlock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_rwlock_timedwrlock ( pthread_rwlock_t * __restrict __rwlock , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int pthread_rwlock_clockwrlock ( pthread_rwlock_t * __restrict __rwlock , clockid_t __clockid , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 3 ) ) ) ;
extern int pthread_rwlock_unlock ( pthread_rwlock_t * __rwlock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlockattr_init ( pthread_rwlockattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlockattr_destroy ( pthread_rwlockattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlockattr_getpshared ( const pthread_rwlockattr_t * __restrict __attr , int * __restrict __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_rwlockattr_setpshared ( pthread_rwlockattr_t * __attr , int __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_rwlockattr_getkind_np ( const pthread_rwlockattr_t * __restrict __attr , int * __restrict __pref ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_rwlockattr_setkind_np ( pthread_rwlockattr_t * __attr , int __pref ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_cond_init ( pthread_cond_t * __restrict __cond , const pthread_condattr_t * __restrict __cond_attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_cond_destroy ( pthread_cond_t * __cond ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_cond_signal ( pthread_cond_t * __cond ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_cond_broadcast ( pthread_cond_t * __cond ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_cond_wait ( pthread_cond_t * __restrict __cond , pthread_mutex_t * __restrict __mutex ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int pthread_cond_timedwait ( pthread_cond_t * __restrict __cond , pthread_mutex_t * __restrict __mutex , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ;
extern int pthread_cond_clockwait ( pthread_cond_t * __restrict __cond , pthread_mutex_t * __restrict __mutex , __clockid_t __clock_id , const struct timespec * __restrict __abstime ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 4 ) ) ) ;
extern int pthread_condattr_init ( pthread_condattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_condattr_destroy ( pthread_condattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_condattr_getpshared ( const pthread_condattr_t * __restrict __attr , int * __restrict __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_condattr_setpshared ( pthread_condattr_t * __attr , int __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_condattr_getclock ( const pthread_condattr_t * __restrict __attr , __clockid_t * __restrict __clock_id ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_condattr_setclock ( pthread_condattr_t * __attr , __clockid_t __clock_id ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_spin_init ( pthread_spinlock_t * __lock , int __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_spin_destroy ( pthread_spinlock_t * __lock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_spin_lock ( pthread_spinlock_t * __lock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_spin_trylock ( pthread_spinlock_t * __lock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_spin_unlock ( pthread_spinlock_t * __lock ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_barrier_init ( pthread_barrier_t * __restrict __barrier , const pthread_barrierattr_t * __restrict __attr , unsigned int __count ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_barrier_destroy ( pthread_barrier_t * __barrier ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_barrier_wait ( pthread_barrier_t * __barrier ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_barrierattr_init ( pthread_barrierattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_barrierattr_destroy ( pthread_barrierattr_t * __attr ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_barrierattr_getpshared ( const pthread_barrierattr_t * __restrict __attr , int * __restrict __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ; extern int pthread_barrierattr_setpshared ( pthread_barrierattr_t * __attr , int __pshared ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int pthread_key_create ( pthread_key_t * __key , void ( * __destr_function ) ( void * ) ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int pthread_key_delete ( pthread_key_t __key ) __attribute__ ( ( __nothrow__ ) ) ; extern void * pthread_getspecific ( pthread_key_t __key ) __attribute__ ( ( __nothrow__ ) ) ; extern int pthread_setspecific ( pthread_key_t __key , const void * __pointer ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_getcpuclockid ( pthread_t __thread_id , __clockid_t * __clock_id ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int pthread_atfork ( void ( * __prepare ) ( void ) , void ( * __parent ) ( void ) , void ( * __child ) ( void ) ) __attribute__ ( ( __nothrow__ ) ) ;


struct iovec { void * iov_base ; size_t iov_len ; } ;
enum __socket_type { SOCK_STREAM = 1 ,
SOCK_DGRAM = 2 ,
SOCK_RAW = 3 ,
SOCK_RDM = 4 ,
SOCK_SEQPACKET = 5 ,
SOCK_DCCP = 6 ,
SOCK_PACKET = 10 ,
SOCK_CLOEXEC = 02000000 ,
SOCK_NONBLOCK = 00004000
} ;
typedef unsigned short int sa_family_t ;
struct sockaddr { sa_family_t sa_family ; char sa_data [ 14 ] ; } ;
struct sockaddr_storage { sa_family_t ss_family ; char __ss_padding [ ( 128 - ( sizeof ( unsigned short int ) ) - sizeof ( unsigned long int ) ) ] ; unsigned long int __ss_align ; } ; enum { MSG_OOB = 0x01 ,
MSG_PEEK = 0x02 ,
MSG_DONTROUTE = 0x04 ,
MSG_TRYHARD = MSG_DONTROUTE ,
MSG_CTRUNC = 0x08 ,
MSG_PROXY = 0x10 ,
MSG_TRUNC = 0x20 ,
MSG_DONTWAIT = 0x40 ,
MSG_EOR = 0x80 ,
MSG_WAITALL = 0x100 ,
MSG_FIN = 0x200 ,
MSG_SYN = 0x400 ,
MSG_CONFIRM = 0x800 ,
MSG_RST = 0x1000 ,
MSG_ERRQUEUE = 0x2000 ,
MSG_NOSIGNAL = 0x4000 ,
MSG_MORE = 0x8000 ,
MSG_WAITFORONE = 0x10000 ,
MSG_BATCH = 0x40000 ,
MSG_ZEROCOPY = 0x4000000 ,
MSG_FASTOPEN = 0x20000000 ,
MSG_CMSG_CLOEXEC = 0x40000000
} ; struct msghdr { void * msg_name ; socklen_t msg_namelen ; struct iovec * msg_iov ; size_t msg_iovlen ; void * msg_control ; size_t msg_controllen ; int msg_flags ; } ; struct cmsghdr { size_t cmsg_len ; int cmsg_level ; int cmsg_type ;
__extension__ unsigned char __cmsg_data [ ] ;
} ;
extern struct cmsghdr * __cmsg_nxthdr ( struct msghdr * __mhdr , struct cmsghdr * __cmsg ) __attribute__ ( ( __nothrow__ ) ) ;
enum { SCM_RIGHTS = 0x01
, SCM_CREDENTIALS = 0x02
, SCM_SECURITY = 0x03
, SCM_PIDFD = 0x04
} ;
struct ucred { pid_t pid ; uid_t uid ; gid_t gid ; } ;
struct linger { int l_onoff ; int l_linger ; } ;
struct osockaddr { unsigned short int sa_family ; unsigned char sa_data [ 14 ] ; } ;
enum { SHUT_RD = 0 ,
SHUT_WR ,
SHUT_RDWR
} ;
typedef union { struct sockaddr * __restrict __sockaddr__ ; struct sockaddr_at * __restrict __sockaddr_at__ ; struct sockaddr_ax25 * __restrict __sockaddr_ax25__ ; struct sockaddr_dl * __restrict __sockaddr_dl__ ; struct sockaddr_eon * __restrict __sockaddr_eon__ ; struct sockaddr_in * __restrict __sockaddr_in__ ; struct sockaddr_in6 * __restrict __sockaddr_in6__ ; struct sockaddr_inarp * __restrict __sockaddr_inarp__ ; struct sockaddr_ipx * __restrict __sockaddr_ipx__ ; struct sockaddr_iso * __restrict __sockaddr_iso__ ; struct sockaddr_ns * __restrict __sockaddr_ns__ ; struct sockaddr_un * __restrict __sockaddr_un__ ; struct sockaddr_x25 * __restrict __sockaddr_x25__ ; } __SOCKADDR_ARG __attribute__ ( ( __transparent_union__ ) ) ;
typedef union { const struct sockaddr * __restrict __sockaddr__ ; const struct sockaddr_at * __restrict __sockaddr_at__ ; const struct sockaddr_ax25 * __restrict __sockaddr_ax25__ ; const struct sockaddr_dl * __restrict __sockaddr_dl__ ; const struct sockaddr_eon * __restrict __sockaddr_eon__ ; const struct sockaddr_in * __restrict __sockaddr_in__ ; const struct sockaddr_in6 * __restrict __sockaddr_in6__ ; const struct sockaddr_inarp * __restrict __sockaddr_inarp__ ; const struct sockaddr_ipx * __restrict __sockaddr_ipx__ ; const struct sockaddr_iso * __restrict __sockaddr_iso__ ; const struct sockaddr_ns * __restrict __sockaddr_ns__ ; const struct sockaddr_un * __restrict __sockaddr_un__ ; const struct sockaddr_x25 * __restrict __sockaddr_x25__ ; } __CONST_SOCKADDR_ARG __attribute__ ( ( __transparent_union__ ) ) ;
struct mmsghdr { struct msghdr msg_hdr ; unsigned int msg_len ; } ;
extern int socket ( int __domain , int __type , int __protocol ) __attribute__ ( ( __nothrow__ ) ) ; extern int socketpair ( int __domain , int __type , int __protocol , int __fds [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) ; extern int bind ( int __fd , __CONST_SOCKADDR_ARG __addr , socklen_t __len ) __attribute__ ( ( __nothrow__ ) ) ; extern int getsockname ( int __fd , __SOCKADDR_ARG __addr , socklen_t * __restrict __len ) __attribute__ ( ( __nothrow__ ) ) ; extern int connect ( int __fd , __CONST_SOCKADDR_ARG __addr , socklen_t __len ) ; extern int getpeername ( int __fd , __SOCKADDR_ARG __addr , socklen_t * __restrict __len ) __attribute__ ( ( __nothrow__ ) ) ; extern ssize_t send ( int __fd , const void * __buf , size_t __n , int __flags ) ; extern ssize_t recv ( int __fd , void * __buf , size_t __n , int __flags ) ; extern ssize_t sendto ( int __fd , const void * __buf , size_t __n , int __flags , __CONST_SOCKADDR_ARG __addr , socklen_t __addr_len ) ; extern ssize_t recvfrom ( int __fd , void * __restrict __buf , size_t __n , int __flags , __SOCKADDR_ARG __addr , socklen_t * __restrict __addr_len ) ;
extern ssize_t sendmsg ( int __fd , const struct msghdr * __message , int __flags ) ;
extern int sendmmsg ( int __fd , struct mmsghdr * __vmessages , unsigned int __vlen , int __flags ) ;
extern ssize_t recvmsg ( int __fd , struct msghdr * __message , int __flags ) ;
extern int recvmmsg ( int __fd , struct mmsghdr * __vmessages , unsigned int __vlen , int __flags , struct timespec * __tmo ) ;
extern int getsockopt ( int __fd , int __level , int __optname , void * __restrict __optval , socklen_t * __restrict __optlen ) __attribute__ ( ( __nothrow__ ) ) ;
extern int setsockopt ( int __fd , int __level , int __optname , const void * __optval , socklen_t __optlen ) __attribute__ ( ( __nothrow__ ) ) ;
extern int listen ( int __fd , int __n ) __attribute__ ( ( __nothrow__ ) ) ; extern int accept ( int __fd , __SOCKADDR_ARG __addr , socklen_t * __restrict __addr_len ) ;
extern int accept4 ( int __fd , __SOCKADDR_ARG __addr , socklen_t * __restrict __addr_len , int __flags ) ;
extern int shutdown ( int __fd , int __how ) __attribute__ ( ( __nothrow__ ) ) ;
extern int sockatmark ( int __fd ) __attribute__ ( ( __nothrow__ ) ) ;
extern int isfdtype ( int __fd , int __fdtype ) __attribute__ ( ( __nothrow__ ) ) ;

typedef uint32_t in_addr_t ; struct in_addr { in_addr_t s_addr ; } ;
struct ip_opts { struct in_addr ip_dst ; char ip_opts [ 40 ] ; } ; struct in_pktinfo { int ipi_ifindex ; struct in_addr ipi_spec_dst ; struct in_addr ipi_addr ; } ;
enum { IPPROTO_IP = 0 ,
IPPROTO_ICMP = 1 ,
IPPROTO_IGMP = 2 ,
IPPROTO_IPIP = 4 ,
IPPROTO_TCP = 6 ,
IPPROTO_EGP = 8 ,
IPPROTO_PUP = 12 ,
IPPROTO_UDP = 17 ,
IPPROTO_IDP = 22 ,
IPPROTO_TP = 29 ,
IPPROTO_DCCP = 33 ,
IPPROTO_IPV6 = 41 ,
IPPROTO_RSVP = 46 ,
IPPROTO_GRE = 47 ,
IPPROTO_ESP = 50 ,
IPPROTO_AH = 51 ,
IPPROTO_MTP = 92 ,
IPPROTO_BEETPH = 94 ,
IPPROTO_ENCAP = 98 ,
IPPROTO_PIM = 103 ,
IPPROTO_COMP = 108 ,
IPPROTO_L2TP = 115 ,
IPPROTO_SCTP = 132 ,
IPPROTO_UDPLITE = 136 ,
IPPROTO_MPLS = 137 ,
IPPROTO_ETHERNET = 143 ,
IPPROTO_RAW = 255 ,
IPPROTO_MPTCP = 262 ,
IPPROTO_MAX } ;
enum { IPPROTO_HOPOPTS = 0 ,
IPPROTO_ROUTING = 43 ,
IPPROTO_FRAGMENT = 44 ,
IPPROTO_ICMPV6 = 58 ,
IPPROTO_NONE = 59 ,
IPPROTO_DSTOPTS = 60 ,
IPPROTO_MH = 135
} ;
typedef uint16_t in_port_t ; enum { IPPORT_ECHO = 7 , IPPORT_DISCARD = 9 , IPPORT_SYSTAT = 11 , IPPORT_DAYTIME = 13 , IPPORT_NETSTAT = 15 , IPPORT_FTP = 21 , IPPORT_TELNET = 23 , IPPORT_SMTP = 25 , IPPORT_TIMESERVER = 37 , IPPORT_NAMESERVER = 42 , IPPORT_WHOIS = 43 , IPPORT_MTP = 57 , IPPORT_TFTP = 69 , IPPORT_RJE = 77 , IPPORT_FINGER = 79 , IPPORT_TTYLINK = 87 , IPPORT_SUPDUP = 95 , IPPORT_EXECSERVER = 512 , IPPORT_LOGINSERVER = 513 , IPPORT_CMDSERVER = 514 , IPPORT_EFSSERVER = 520 , IPPORT_BIFFUDP = 512 , IPPORT_WHOSERVER = 513 , IPPORT_ROUTESERVER = 520 , IPPORT_RESERVED = 1024 , IPPORT_USERRESERVED = 5000 } ;
struct in6_addr { union { uint8_t __u6_addr8 [ 16 ] ; uint16_t __u6_addr16 [ 8 ] ; uint32_t __u6_addr32 [ 4 ] ; } __in6_u ;
} ;
extern const struct in6_addr in6addr_any ; extern const struct in6_addr in6addr_loopback ;
struct sockaddr_in { sa_family_t sin_family ; in_port_t sin_port ; struct in_addr sin_addr ; unsigned char sin_zero [ sizeof ( struct sockaddr ) - ( sizeof ( unsigned short int ) ) - sizeof ( in_port_t ) - sizeof ( struct in_addr ) ] ; } ;
struct sockaddr_in6 { sa_family_t sin6_family ; in_port_t sin6_port ; uint32_t sin6_flowinfo ; struct in6_addr sin6_addr ; uint32_t sin6_scope_id ; } ;
struct ip_mreq { struct in_addr imr_multiaddr ; struct in_addr imr_interface ; } ; struct ip_mreqn { struct in_addr imr_multiaddr ; struct in_addr imr_address ; int imr_ifindex ; } ; struct ip_mreq_source { struct in_addr imr_multiaddr ; struct in_addr imr_interface ; struct in_addr imr_sourceaddr ; } ;
struct ipv6_mreq { struct in6_addr ipv6mr_multiaddr ; unsigned int ipv6mr_interface ; } ;
struct group_req { uint32_t gr_interface ; struct sockaddr_storage gr_group ; } ; struct group_source_req { uint32_t gsr_interface ; struct sockaddr_storage gsr_group ; struct sockaddr_storage gsr_source ; } ; struct ip_msfilter { struct in_addr imsf_multiaddr ; struct in_addr imsf_interface ; uint32_t imsf_fmode ; uint32_t imsf_numsrc ; struct in_addr imsf_slist [ 1 ] ; } ;
struct group_filter { uint32_t gf_interface ; struct sockaddr_storage gf_group ; uint32_t gf_fmode ; uint32_t gf_numsrc ; struct sockaddr_storage gf_slist [ 1 ] ; } ;
extern uint32_t ntohl ( uint32_t __netlong ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern uint16_t ntohs ( uint16_t __netshort ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern uint32_t htonl ( uint32_t __hostlong ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern uint16_t htons ( uint16_t __hostshort ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern int bindresvport ( int __sockfd , struct sockaddr_in * __sock_in ) __attribute__ ( ( __nothrow__ ) ) ; extern int bindresvport6 ( int __sockfd , struct sockaddr_in6 * __sock_in ) __attribute__ ( ( __nothrow__ ) ) ;
struct cmsghdr ;
struct in6_pktinfo { struct in6_addr ipi6_addr ; unsigned int ipi6_ifindex ; } ; struct ip6_mtuinfo { struct sockaddr_in6 ip6m_addr ; uint32_t ip6m_mtu ; } ;
extern int inet6_option_space ( int __nbytes ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int inet6_option_init ( void * __bp , struct cmsghdr * * __cmsgp , int __type ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int inet6_option_append ( struct cmsghdr * __cmsg , const uint8_t * __typep , int __multx , int __plusy ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern uint8_t * inet6_option_alloc ( struct cmsghdr * __cmsg , int __datalen , int __multx , int __plusy ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int inet6_option_next ( const struct cmsghdr * __cmsg , uint8_t * * __tptrp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int inet6_option_find ( const struct cmsghdr * __cmsg , uint8_t * * __tptrp , int __type ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int inet6_opt_init ( void * __extbuf , socklen_t __extlen ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_opt_append ( void * __extbuf , socklen_t __extlen , int __offset , uint8_t __type , socklen_t __len , uint8_t __align , void * * __databufp ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_opt_finish ( void * __extbuf , socklen_t __extlen , int __offset ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_opt_set_val ( void * __databuf , int __offset , void * __val , socklen_t __vallen ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_opt_next ( void * __extbuf , socklen_t __extlen , int __offset , uint8_t * __typep , socklen_t * __lenp , void * * __databufp ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_opt_find ( void * __extbuf , socklen_t __extlen , int __offset , uint8_t __type , socklen_t * __lenp , void * * __databufp ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_opt_get_val ( void * __databuf , int __offset , void * __val , socklen_t __vallen ) __attribute__ ( ( __nothrow__ ) ) ; extern socklen_t inet6_rth_space ( int __type , int __segments ) __attribute__ ( ( __nothrow__ ) ) ; extern void * inet6_rth_init ( void * __bp , socklen_t __bp_len , int __type , int __segments ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_rth_add ( void * __bp , const struct in6_addr * __addr ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_rth_reverse ( const void * __in , void * __out ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet6_rth_segments ( const void * __bp ) __attribute__ ( ( __nothrow__ ) ) ; extern struct in6_addr * inet6_rth_getaddr ( const void * __bp , int __index ) __attribute__ ( ( __nothrow__ ) ) ; extern int getipv4sourcefilter ( int __s , struct in_addr __interface_addr , struct in_addr __group , uint32_t * __fmode , uint32_t * __numsrc , struct in_addr * __slist ) __attribute__ ( ( __nothrow__ ) ) ; extern int setipv4sourcefilter ( int __s , struct in_addr __interface_addr , struct in_addr __group , uint32_t __fmode , uint32_t __numsrc , const struct in_addr * __slist ) __attribute__ ( ( __nothrow__ ) ) ; extern int getsourcefilter ( int __s , uint32_t __interface_addr , const struct sockaddr * __group , socklen_t __grouplen , uint32_t * __fmode , uint32_t * __numsrc , struct sockaddr_storage * __slist ) __attribute__ ( ( __nothrow__ ) ) ; extern int setsourcefilter ( int __s , uint32_t __interface_addr , const struct sockaddr * __group , socklen_t __grouplen , uint32_t __fmode , uint32_t __numsrc , const struct sockaddr_storage * __slist ) __attribute__ ( ( __nothrow__ ) ) ;

extern in_addr_t inet_addr ( const char * __cp ) __attribute__ ( ( __nothrow__ ) ) ; extern in_addr_t inet_lnaof ( struct in_addr __in ) __attribute__ ( ( __nothrow__ ) ) ; extern struct in_addr inet_makeaddr ( in_addr_t __net , in_addr_t __host ) __attribute__ ( ( __nothrow__ ) ) ; extern in_addr_t inet_netof ( struct in_addr __in ) __attribute__ ( ( __nothrow__ ) ) ; extern in_addr_t inet_network ( const char * __cp ) __attribute__ ( ( __nothrow__ ) ) ; extern char * inet_ntoa ( struct in_addr __in ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet_pton ( int __af , const char * __restrict __cp , void * __restrict __buf ) __attribute__ ( ( __nothrow__ ) ) ; extern const char * inet_ntop ( int __af , const void * __restrict __cp , char * __restrict __buf , socklen_t __len ) __attribute__ ( ( __nothrow__ ) ) ;
extern int inet_aton ( const char * __cp , struct in_addr * __inp ) __attribute__ ( ( __nothrow__ ) ) ; extern char * inet_neta ( in_addr_t __net , char * __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern char * inet_net_ntop ( int __af , const void * __cp , int __bits , char * __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) ; extern int inet_net_pton ( int __af , const char * __cp , void * __buf , size_t __len ) __attribute__ ( ( __nothrow__ ) ) ; extern unsigned int inet_nsap_addr ( const char * __cp , unsigned char * __buf , int __len ) __attribute__ ( ( __nothrow__ ) ) ; extern char * inet_nsap_ntoa ( int __len , const unsigned char * __cp , char * __buf ) __attribute__ ( ( __nothrow__ ) ) ;


typedef int64_t git_off_t ; typedef int64_t git_time_t ;
typedef uint64_t git_object_size_t ;
typedef struct { char * ptr ; size_t reserved ; size_t size ; } git_buf ;
extern __attribute__ ( ( visibility ( "default" ) ) ) void git_buf_dispose ( git_buf * buffer ) ;
typedef enum {
GIT_OID_SHA1 = 1
} git_oid_t ;
typedef struct git_oid {
unsigned char id [ 20 ] ; } git_oid ;
extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_fromstr ( git_oid * out , const char * str ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_fromstrp ( git_oid * out , const char * str ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_fromstrn ( git_oid * out , const char * str , size_t length ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_fromraw ( git_oid * out , const unsigned char * raw ) ;
extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_fmt ( char * out , const git_oid * id ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_nfmt ( char * out , size_t n , const git_oid * id ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_pathfmt ( char * out , const git_oid * id ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) char * git_oid_tostr_s ( const git_oid * oid ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) char * git_oid_tostr ( char * out , size_t n , const git_oid * id ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_cpy ( git_oid * out , const git_oid * src ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_cmp ( const git_oid * a , const git_oid * b ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_equal ( const git_oid * a , const git_oid * b ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_ncmp ( const git_oid * a , const git_oid * b , size_t len ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_streq ( const git_oid * id , const char * str ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_strcmp ( const git_oid * id , const char * str ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_is_zero ( const git_oid * id ) ; typedef struct git_oid_shorten git_oid_shorten ; extern __attribute__ ( ( visibility ( "default" ) ) ) git_oid_shorten * git_oid_shorten_new ( size_t min_length ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) int git_oid_shorten_add ( git_oid_shorten * os , const char * text_id ) ; extern __attribute__ ( ( visibility ( "default" ) ) ) void git_oid_shorten_free ( git_oid_shorten * os ) ;
typedef enum { GIT_OBJECT_ANY = - 2 , GIT_OBJECT_INVALID = - 1 , GIT_OBJECT_COMMIT = 1 , GIT_OBJECT_TREE = 2 , GIT_OBJECT_BLOB = 3 , GIT_OBJECT_TAG = 4 , GIT_OBJECT_OFS_DELTA = 6 , GIT_OBJECT_REF_DELTA = 7 } git_object_t ; typedef struct git_odb git_odb ; typedef struct git_odb_backend git_odb_backend ; typedef struct git_odb_object git_odb_object ; typedef struct git_odb_stream git_odb_stream ; typedef struct git_odb_writepack git_odb_writepack ; typedef struct git_midx_writer git_midx_writer ; typedef struct git_refdb git_refdb ; typedef struct git_refdb_backend git_refdb_backend ; typedef struct git_commit_graph git_commit_graph ; typedef struct git_commit_graph_writer git_commit_graph_writer ; typedef struct git_repository git_repository ; typedef struct git_worktree git_worktree ; typedef struct git_object git_object ; typedef struct git_revwalk git_revwalk ; typedef struct git_tag git_tag ; typedef struct git_blob git_blob ; typedef struct git_commit git_commit ; typedef struct git_tree_entry git_tree_entry ; typedef struct git_tree git_tree ; typedef struct git_treebuilder git_treebuilder ; typedef struct git_index git_index ; typedef struct git_index_iterator git_index_iterator ; typedef struct git_index_conflict_iterator git_index_conflict_iterator ; typedef struct git_config git_config ; typedef struct git_config_backend git_config_backend ; typedef struct git_reflog_entry git_reflog_entry ; typedef struct git_reflog git_reflog ; typedef struct git_note git_note ; typedef struct git_packbuilder git_packbuilder ; typedef struct git_time { git_time_t time ; int offset ; char sign ; } git_time ; typedef struct git_signature { char * name ; char * email ; git_time when ; } git_signature ; typedef struct git_reference git_reference ; typedef struct git_reference_iterator git_reference_iterator ; typedef struct git_transaction git_transaction ; typedef struct git_annotated_commit git_annotated_commit ; typedef struct git_status_list git_status_list ; typedef struct git_rebase git_rebase ; typedef enum { GIT_REFERENCE_INVALID = 0 , GIT_REFERENCE_DIRECT = 1 , GIT_REFERENCE_SYMBOLIC = 2 , GIT_REFERENCE_ALL = GIT_REFERENCE_DIRECT | GIT_REFERENCE_SYMBOLIC } git_reference_t ; typedef enum { GIT_BRANCH_LOCAL = 1 , GIT_BRANCH_REMOTE = 2 , GIT_BRANCH_ALL = GIT_BRANCH_LOCAL | GIT_BRANCH_REMOTE } git_branch_t ; typedef enum { GIT_FILEMODE_UNREADABLE = 0000000 , GIT_FILEMODE_TREE = 0040000 , GIT_FILEMODE_BLOB = 0100644 , GIT_FILEMODE_BLOB_EXECUTABLE = 0100755 , GIT_FILEMODE_LINK = 0120000 , GIT_FILEMODE_COMMIT = 0160000 } git_filemode_t ; typedef struct git_refspec git_refspec ; typedef struct git_remote git_remote ; typedef struct git_transport git_transport ; typedef struct git_push git_push ; typedef struct git_remote_head git_remote_head ; typedef struct git_remote_callbacks git_remote_callbacks ; typedef struct git_cert git_cert ; typedef struct git_submodule git_submodule ; typedef enum { GIT_SUBMODULE_UPDATE_CHECKOUT = 1 , GIT_SUBMODULE_UPDATE_REBASE = 2 , GIT_SUBMODULE_UPDATE_MERGE = 3 , GIT_SUBMODULE_UPDATE_NONE = 4 , GIT_SUBMODULE_UPDATE_DEFAULT = 0 } git_submodule_update_t ; typedef enum { GIT_SUBMODULE_IGNORE_UNSPECIFIED = - 1 , GIT_SUBMODULE_IGNORE_NONE = 1 , GIT_SUBMODULE_IGNORE_UNTRACKED = 2 , GIT_SUBMODULE_IGNORE_DIRTY = 3 , GIT_SUBMODULE_IGNORE_ALL = 4 } git_submodule_ignore_t ; typedef enum { GIT_SUBMODULE_RECURSE_NO = 0 , GIT_SUBMODULE_RECURSE_YES = 1 , GIT_SUBMODULE_RECURSE_ONDEMAND = 2 } git_submodule_recurse_t ; typedef struct git_writestream git_writestream ; struct git_writestream { int ( * write ) ( git_writestream * stream , const char * buffer , size_t len ) ; int ( * close ) ( git_writestream * stream ) ; void ( * free ) ( git_writestream * stream ) ; } ; typedef struct git_mailmap git_mailmap ;
typedef enum { GIT_OK = 0 , GIT_ERROR = - 1 , GIT_ENOTFOUND = - 3 , GIT_EEXISTS = - 4 , GIT_EAMBIGUOUS = - 5 , GIT_EBUFS = - 6 , GIT_EUSER = - 7 , GIT_EBAREREPO = - 8 , GIT_EUNBORNBRANCH = - 9 , GIT_EUNMERGED = - 10 , GIT_ENONFASTFORWARD = - 11 , GIT_EINVALIDSPEC = - 12 , GIT_ECONFLICT = - 13 , GIT_ELOCKED = - 14 , GIT_EMODIFIED = - 15 , GIT_EAUTH = - 16 , GIT_ECERTIFICATE = - 17 , GIT_EAPPLIED = - 18 , GIT_EPEEL = - 19 , GIT_EEOF = - 20 , GIT_EINVALID = - 21 , GIT_EUNCOMMITTED = - 22 , GIT_EDIRECTORY = - 23 , GIT_EMERGECONFLICT = - 24 , GIT_PASSTHROUGH = - 30 , GIT_ITEROVER = - 31 , GIT_RETRY = - 32 , GIT_EMISMATCH = - 33 , GIT_EINDEXDIRTY = - 34 , GIT_EAPPLYFAIL = - 35 , GIT_EOWNER = - 36 , GIT_TIMEOUT = - 37 , GIT_EUNCHANGED = - 38 , GIT_ENOTSUPPORTED = - 39 , GIT_EREADONLY = - 40 } git_error_code ; typedef enum { GIT_ERROR_NONE = 0 , GIT_ERROR_NOMEMORY , GIT_ERROR_OS , GIT_ERROR_INVALID , GIT_ERROR_REFERENCE , GIT_ERROR_ZLIB , GIT_ERROR_REPOSITORY , GIT_ERROR_CONFIG , GIT_ERROR_REGEX , GIT_ERROR_ODB , GIT_ERROR_INDEX , GIT_ERROR_OBJECT , GIT_ERROR_NET , GIT_ERROR_TAG , GIT_ERROR_TREE , GIT_ERROR_INDEXER , GIT_ERROR_SSL , GIT_ERROR_SUBMODULE , GIT_ERROR_THREAD , GIT_ERROR_STASH , GIT_ERROR_CHECKOUT , GIT_ERROR_FETCHHEAD , GIT_ERROR_MERGE , GIT_ERROR_SSH , GIT_ERROR_FILTER , GIT_ERROR_REVERT , GIT_ERROR_CALLBACK , GIT_ERROR_CHERRYPICK , GIT_ERROR_DESCRIBE , GIT_ERROR_REBASE , GIT_ERROR_FILESYSTEM , GIT_ERROR_PATCH , GIT_ERROR_WORKTREE , GIT_ERROR_SHA , GIT_ERROR_HTTP , GIT_ERROR_INTERNAL , GIT_ERROR_GRAFTS } git_error_t ; typedef struct { char * message ; int klass ; } git_error ; extern __attribute__ ( ( visibility ( "default" ) ) ) const git_error * git_error_last ( void ) ;
typedef struct {
volatile int val ;
} git_atomic32 ;
typedef struct {
volatile int64_t val ;
} git_atomic64 ; typedef git_atomic64 git_atomic_ssize ;
typedef struct { pthread_t thread ; } git_thread ; static __inline__ int git_threads_global_init ( void ) { return 0 ; }
static __inline__ void git_atomic32_set ( git_atomic32 * a , int val ) {
__atomic_store_n ( & a -> val , val , 5 ) ;
} static __inline__ int git_atomic32_inc ( git_atomic32 * a ) {
return __atomic_add_fetch ( & a -> val , 1 , 5 ) ;
} static __inline__ int git_atomic32_add ( git_atomic32 * a , int32_t addend ) {
return __atomic_add_fetch ( & a -> val , addend , 5 ) ;
} static __inline__ int git_atomic32_dec ( git_atomic32 * a ) {
return __atomic_sub_fetch ( & a -> val , 1 , 5 ) ;
} static __inline__ int git_atomic32_get ( git_atomic32 * a ) {
return __atomic_load_n ( & a -> val , 5 ) ;
} static __inline__ void * git_atomic__compare_and_swap ( void * volatile * ptr , void * oldval , void * newval ) {
void * foundval = oldval ; __atomic_compare_exchange ( ptr , & foundval , & newval , 0 , 5 , 5 ) ; return foundval ;
} static __inline__ volatile void * git_atomic__swap ( void * volatile * ptr , void * newval ) {
void * foundval = ( ( void * ) 0 ) ; __atomic_exchange ( ptr , & newval , & foundval , 5 ) ; return foundval ;
} static __inline__ volatile void * git_atomic__load ( void * volatile * ptr ) {
return ( volatile void * ) __atomic_load_n ( ptr , 5 ) ;
}
static __inline__ int64_t git_atomic64_add ( git_atomic64 * a , int64_t addend ) {
return __atomic_add_fetch ( & a -> val , addend , 5 ) ;
} static __inline__ void git_atomic64_set ( git_atomic64 * a , int64_t val ) {
__atomic_store_n ( & a -> val , val , 5 ) ;
} static __inline__ int64_t git_atomic64_get ( git_atomic64 * a ) {
return __atomic_load_n ( & a -> val , 5 ) ;
}
int git_tlsdata_init ( pthread_key_t * key , void ( * destroy_fn ) ( void * ) ) ; int git_tlsdata_set ( pthread_key_t key , void * value ) ; void * git_tlsdata_get ( pthread_key_t key ) ; int git_tlsdata_dispose ( pthread_key_t key ) ;
static __inline__ int git__is_sizet ( int64_t p ) { size_t r = ( size_t ) p ; return p == ( int64_t ) r ; } static __inline__ int git__is_ssizet ( size_t p ) { ssize_t r = ( ssize_t ) p ; return p == ( size_t ) r ; } static __inline__ int git__is_uint16 ( size_t p ) { uint16_t r = ( uint16_t ) p ; return p == ( size_t ) r ; } static __inline__ int git__is_uint32 ( size_t p ) { uint32_t r = ( uint32_t ) p ; return p == ( size_t ) r ; } static __inline__ int git__is_ulong ( int64_t p ) { unsigned long r = ( unsigned long ) p ; return p == ( int64_t ) r ; } static __inline__ int git__is_int ( int64_t p ) { int r = ( int ) p ; return p == ( int64_t ) r ; }

struct flock { short int l_type ; short int l_whence ;
__off_t l_start ; __off_t l_len ;
__pid_t l_pid ; } ;
struct flock64 { short int l_type ; short int l_whence ; __off64_t l_start ; __off64_t l_len ; __pid_t l_pid ; } ;
enum __pid_type { F_OWNER_TID = 0 , F_OWNER_PID , F_OWNER_PGRP , F_OWNER_GID = F_OWNER_PGRP } ; struct f_owner_ex { enum __pid_type type ; __pid_t pid ; } ;
struct file_handle { unsigned int handle_bytes ; int handle_type ; unsigned char f_handle [ 0 ] ; } ;

extern __ssize_t readahead ( int __fd , __off64_t __offset , size_t __count ) __attribute__ ( ( __nothrow__ ) ) ; extern int sync_file_range ( int __fd , __off64_t __offset , __off64_t __count , unsigned int __flags ) ; extern __ssize_t vmsplice ( int __fdout , const struct iovec * __iov , size_t __count , unsigned int __flags ) ; extern __ssize_t splice ( int __fdin , __off64_t * __offin , int __fdout , __off64_t * __offout , size_t __len , unsigned int __flags ) ; extern __ssize_t tee ( int __fdin , int __fdout , size_t __len , unsigned int __flags ) ;
extern int fallocate ( int __fd , int __mode , __off_t __offset , __off_t __len ) ;
extern int fallocate64 ( int __fd , int __mode , __off64_t __offset , __off64_t __len ) ;
extern int name_to_handle_at ( int __dfd , const char * __name , struct file_handle * __handle , int * __mnt_id , int __flags ) __attribute__ ( ( __nothrow__ ) ) ; extern int open_by_handle_at ( int __mountdirfd , struct file_handle * __handle , int __flags ) ;

extern int fcntl ( int __fd , int __cmd , ... ) ;
extern int fcntl64 ( int __fd , int __cmd , ... ) ;
extern int open ( const char * __file , int __oflag , ... ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int open64 ( const char * __file , int __oflag , ... ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int openat ( int __fd , const char * __file , int __oflag , ... ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int openat64 ( int __fd , const char * __file , int __oflag , ... ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;
extern int creat ( const char * __file , mode_t __mode ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int creat64 ( const char * __file , mode_t __mode ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int posix_fadvise ( int __fd , off_t __offset , off_t __len , int __advise ) __attribute__ ( ( __nothrow__ ) ) ;
extern int posix_fadvise64 ( int __fd , off64_t __offset , off64_t __len , int __advise ) __attribute__ ( ( __nothrow__ ) ) ;
extern int posix_fallocate ( int __fd , off_t __offset , off_t __len ) ;
extern int posix_fallocate64 ( int __fd , off64_t __offset , off64_t __len ) ;

typedef int64_t off64_t ;
typedef int git_file ; extern ssize_t p_read ( git_file fd , void * buf , size_t cnt ) ; extern int p_write ( git_file fd , const void * buf , size_t cnt ) ; extern ssize_t p_pread ( int fd , void * data , size_t size , off64_t offset ) ; extern ssize_t p_pwrite ( int fd , const void * data , size_t size , off64_t offset ) ;
extern int p_open ( const char * path , int flags , ... ) ; extern int p_creat ( const char * path , mode_t mode ) ; extern int p_getcwd ( char * buffer_out , size_t size ) ; extern int p_rename ( const char * from , const char * to ) ; extern int git__page_size ( size_t * page_size ) ; extern int git__mmap_alignment ( size_t * page_size ) ; extern size_t p_fsync__cnt ;

struct dirent {
__ino_t d_ino ; __off_t d_off ;
unsigned short int d_reclen ; unsigned char d_type ; char d_name [ 256 ] ; } ;
struct dirent64 { __ino64_t d_ino ; __off64_t d_off ; unsigned short int d_reclen ; unsigned char d_type ; char d_name [ 256 ] ; } ;
enum { DT_UNKNOWN = 0 ,
DT_FIFO = 1 ,
DT_CHR = 2 ,
DT_DIR = 4 ,
DT_BLK = 6 ,
DT_REG = 8 ,
DT_LNK = 10 ,
DT_SOCK = 12 ,
DT_WHT = 14
} ;
typedef struct __dirstream DIR ; extern int closedir ( DIR * __dirp ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern DIR * opendir ( const char * __name ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) __attribute__ ( ( __malloc__ ) ) ;
extern DIR * fdopendir ( int __fd ) __attribute__ ( ( __malloc__ ) ) ;
extern struct dirent * readdir ( DIR * __dirp ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern struct dirent64 * readdir64 ( DIR * __dirp ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int readdir_r ( DIR * __restrict __dirp , struct dirent * __restrict __entry , struct dirent * * __restrict __result ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int readdir64_r ( DIR * __restrict __dirp , struct dirent64 * __restrict __entry , struct dirent64 * * __restrict __result ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern void rewinddir ( DIR * __dirp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern void seekdir ( DIR * __dirp , long int __pos ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern long int telldir ( DIR * __dirp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int dirfd ( DIR * __dirp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int scandir ( const char * __restrict __dir , struct dirent * * * __restrict __namelist , int ( * __selector ) ( const struct dirent * ) , int ( * __cmp ) ( const struct dirent * * , const struct dirent * * ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int scandir64 ( const char * __restrict __dir , struct dirent64 * * * __restrict __namelist , int ( * __selector ) ( const struct dirent64 * ) , int ( * __cmp ) ( const struct dirent64 * * , const struct dirent64 * * ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int scandirat ( int __dfd , const char * __restrict __dir , struct dirent * * * __restrict __namelist , int ( * __selector ) ( const struct dirent * ) , int ( * __cmp ) ( const struct dirent * * , const struct dirent * * ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern int scandirat64 ( int __dfd , const char * __restrict __dir , struct dirent64 * * * __restrict __namelist , int ( * __selector ) ( const struct dirent64 * ) , int ( * __cmp ) ( const struct dirent64 * * , const struct dirent64 * * ) ) __attribute__ ( ( __nonnull__ ( 2 , 3 ) ) ) ;
extern int alphasort ( const struct dirent * * __e1 , const struct dirent * * __e2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int alphasort64 ( const struct dirent64 * * __e1 , const struct dirent64 * * __e2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern __ssize_t getdirentries ( int __fd , char * __restrict __buf , size_t __nbytes , __off_t * __restrict __basep ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 4 ) ) ) ;
extern __ssize_t getdirentries64 ( int __fd , char * __restrict __buf , size_t __nbytes , __off64_t * __restrict __basep ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 , 4 ) ) ) ;
extern int versionsort ( const struct dirent * * __e1 , const struct dirent * * __e2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int versionsort64 ( const struct dirent64 * * __e1 , const struct dirent64 * * __e2 ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __pure__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;


extern __ssize_t getdents64 ( int __fd , void * __buffer , size_t __length ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 2 ) ) ) ;


typedef __sig_atomic_t sig_atomic_t ;
union sigval { int sival_int ; void * sival_ptr ; } ; typedef union sigval __sigval_t ;
typedef struct { int si_signo ;
int si_errno ; int si_code ;
int __pad0 ;
union { int _pad [ ( ( 128 / sizeof ( int ) ) - 4 ) ] ; struct { __pid_t si_pid ; __uid_t si_uid ; } _kill ; struct { int si_tid ; int si_overrun ; __sigval_t si_sigval ; } _timer ; struct { __pid_t si_pid ; __uid_t si_uid ; __sigval_t si_sigval ; } _rt ; struct { __pid_t si_pid ; __uid_t si_uid ; int si_status ; __clock_t si_utime ; __clock_t si_stime ; } _sigchld ; struct { void * si_addr ; short int si_addr_lsb ; union { struct { void * _lower ; void * _upper ; } _addr_bnd ; __uint32_t _pkey ; } _bounds ; } _sigfault ; struct { long int si_band ; int si_fd ; } _sigpoll ;
struct { void * _call_addr ; int _syscall ; unsigned int _arch ; } _sigsys ;
} _sifields ; } siginfo_t ;
enum { SI_ASYNCNL = - 60 , SI_DETHREAD = - 7 , SI_TKILL , SI_SIGIO ,
SI_ASYNCIO , SI_MESGQ , SI_TIMER ,
SI_QUEUE , SI_USER , SI_KERNEL = 0x80
} ;
enum { ILL_ILLOPC = 1 ,
ILL_ILLOPN ,
ILL_ILLADR ,
ILL_ILLTRP ,
ILL_PRVOPC ,
ILL_PRVREG ,
ILL_COPROC ,
ILL_BADSTK ,
ILL_BADIADDR
} ; enum { FPE_INTDIV = 1 ,
FPE_INTOVF ,
FPE_FLTDIV ,
FPE_FLTOVF ,
FPE_FLTUND ,
FPE_FLTRES ,
FPE_FLTINV ,
FPE_FLTSUB ,
FPE_FLTUNK = 14 ,
FPE_CONDTRAP
} ; enum { SEGV_MAPERR = 1 ,
SEGV_ACCERR ,
SEGV_BNDERR ,
SEGV_PKUERR ,
SEGV_ACCADI ,
SEGV_ADIDERR ,
SEGV_ADIPERR ,
SEGV_MTEAERR ,
SEGV_MTESERR ,
SEGV_CPERR
} ; enum { BUS_ADRALN = 1 ,
BUS_ADRERR ,
BUS_OBJERR ,
BUS_MCEERR_AR ,
BUS_MCEERR_AO
} ;
enum { TRAP_BRKPT = 1 ,
TRAP_TRACE ,
TRAP_BRANCH ,
TRAP_HWBKPT ,
TRAP_UNK
} ;
enum { CLD_EXITED = 1 ,
CLD_KILLED ,
CLD_DUMPED ,
CLD_TRAPPED ,
CLD_STOPPED ,
CLD_CONTINUED
} ; enum { POLL_IN = 1 ,
POLL_OUT ,
POLL_MSG ,
POLL_ERR ,
POLL_PRI ,
POLL_HUP
} ;
typedef __sigval_t sigval_t ;
typedef struct sigevent { __sigval_t sigev_value ; int sigev_signo ; int sigev_notify ; union { int _pad [ ( ( 64 / sizeof ( int ) ) - 4 ) ] ; __pid_t _tid ; struct { void ( * _function ) ( __sigval_t ) ; pthread_attr_t * _attribute ; } _sigev_thread ; } _sigev_un ; } sigevent_t ;
enum { SIGEV_SIGNAL = 0 ,
SIGEV_NONE ,
SIGEV_THREAD ,
SIGEV_THREAD_ID = 4
} ;
typedef void ( * __sighandler_t ) ( int ) ; extern __sighandler_t __sysv_signal ( int __sig , __sighandler_t __handler ) __attribute__ ( ( __nothrow__ ) ) ;
extern __sighandler_t sysv_signal ( int __sig , __sighandler_t __handler ) __attribute__ ( ( __nothrow__ ) ) ;
extern __sighandler_t signal ( int __sig , __sighandler_t __handler ) __attribute__ ( ( __nothrow__ ) ) ;
extern int kill ( __pid_t __pid , int __sig ) __attribute__ ( ( __nothrow__ ) ) ;
extern int killpg ( __pid_t __pgrp , int __sig ) __attribute__ ( ( __nothrow__ ) ) ;
extern int raise ( int __sig ) __attribute__ ( ( __nothrow__ ) ) ;
extern __sighandler_t ssignal ( int __sig , __sighandler_t __handler ) __attribute__ ( ( __nothrow__ ) ) ; extern int gsignal ( int __sig ) __attribute__ ( ( __nothrow__ ) ) ;
extern void psignal ( int __sig , const char * __s ) ; extern void psiginfo ( const siginfo_t * __pinfo , const char * __s ) ;
extern int sigpause ( int __sig ) __asm__ ( "__xpg_sigpause" ) __attribute__ ( ( __deprecated__ ) ) ;
extern int sigblock ( int __mask ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int sigsetmask ( int __mask ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int siggetmask ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ;
typedef __sighandler_t sighandler_t ;
typedef __sighandler_t sig_t ;
extern int sigemptyset ( sigset_t * __set ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sigfillset ( sigset_t * __set ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sigaddset ( sigset_t * __set , int __signo ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sigdelset ( sigset_t * __set , int __signo ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sigismember ( const sigset_t * __set , int __signo ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int sigisemptyset ( const sigset_t * __set ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sigandset ( sigset_t * __set , const sigset_t * __left , const sigset_t * __right ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ; extern int sigorset ( sigset_t * __set , const sigset_t * __left , const sigset_t * __right ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 , 2 , 3 ) ) ) ;
struct sigaction {
union { __sighandler_t sa_handler ; void ( * sa_sigaction ) ( int , siginfo_t * , void * ) ; } __sigaction_handler ;
__sigset_t sa_mask ; int sa_flags ; void ( * sa_restorer ) ( void ) ; } ;
extern int sigprocmask ( int __how , const sigset_t * __restrict __set , sigset_t * __restrict __oset ) __attribute__ ( ( __nothrow__ ) ) ; extern int sigsuspend ( const sigset_t * __set ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int sigaction ( int __sig , const struct sigaction * __restrict __act , struct sigaction * __restrict __oact ) __attribute__ ( ( __nothrow__ ) ) ; extern int sigpending ( sigset_t * __set ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int sigwait ( const sigset_t * __restrict __set , int * __restrict __sig ) __attribute__ ( ( __nonnull__ ( 1 , 2 ) ) ) ;
extern int sigwaitinfo ( const sigset_t * __restrict __set , siginfo_t * __restrict __info ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int sigtimedwait ( const sigset_t * __restrict __set , siginfo_t * __restrict __info , const struct timespec * __restrict __timeout ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int sigqueue ( __pid_t __pid , int __sig , const union sigval __val ) __attribute__ ( ( __nothrow__ ) ) ;
struct _fpx_sw_bytes { __uint32_t magic1 ; __uint32_t extended_size ; __uint64_t xstate_bv ; __uint32_t xstate_size ; __uint32_t __glibc_reserved1 [ 7 ] ; } ; struct _fpreg { unsigned short significand [ 4 ] ; unsigned short exponent ; } ; struct _fpxreg { unsigned short significand [ 4 ] ; unsigned short exponent ; unsigned short __glibc_reserved1 [ 3 ] ; } ; struct _xmmreg { __uint32_t element [ 4 ] ; } ;
struct _fpstate { __uint16_t cwd ; __uint16_t swd ; __uint16_t ftw ; __uint16_t fop ; __uint64_t rip ; __uint64_t rdp ; __uint32_t mxcsr ; __uint32_t mxcr_mask ; struct _fpxreg _st [ 8 ] ; struct _xmmreg _xmm [ 16 ] ; __uint32_t __glibc_reserved1 [ 24 ] ; } ; struct sigcontext { __uint64_t r8 ; __uint64_t r9 ; __uint64_t r10 ; __uint64_t r11 ; __uint64_t r12 ; __uint64_t r13 ; __uint64_t r14 ; __uint64_t r15 ; __uint64_t rdi ; __uint64_t rsi ; __uint64_t rbp ; __uint64_t rbx ; __uint64_t rdx ; __uint64_t rax ; __uint64_t rcx ; __uint64_t rsp ; __uint64_t rip ; __uint64_t eflags ; unsigned short cs ; unsigned short gs ; unsigned short fs ; unsigned short __pad0 ; __uint64_t err ; __uint64_t trapno ; __uint64_t oldmask ; __uint64_t cr2 ; __extension__ union { struct _fpstate * fpstate ; __uint64_t __fpstate_word ; } ; __uint64_t __reserved1 [ 8 ] ; } ;
struct _xsave_hdr { __uint64_t xstate_bv ; __uint64_t __glibc_reserved1 [ 2 ] ; __uint64_t __glibc_reserved2 [ 5 ] ; } ; struct _ymmh_state { __uint32_t ymmh_space [ 64 ] ; } ; struct _xstate { struct _fpstate fpstate ; struct _xsave_hdr xstate_hdr ; struct _ymmh_state ymmh ; } ;
extern int sigreturn ( struct sigcontext * __scp ) __attribute__ ( ( __nothrow__ ) ) ;
typedef struct { void * ss_sp ; int ss_flags ; size_t ss_size ; } stack_t ;
__extension__ typedef long long int greg_t ;
typedef greg_t gregset_t [ 23 ] ;
enum { REG_R8 = 0 ,
REG_R9 ,
REG_R10 ,
REG_R11 ,
REG_R12 ,
REG_R13 ,
REG_R14 ,
REG_R15 ,
REG_RDI ,
REG_RSI ,
REG_RBP ,
REG_RBX ,
REG_RDX ,
REG_RAX ,
REG_RCX ,
REG_RSP ,
REG_RIP ,
REG_EFL ,
REG_CSGSFS ,
REG_ERR ,
REG_TRAPNO ,
REG_OLDMASK ,
REG_CR2
} ;
struct _libc_fpxreg { unsigned short int significand [ 4 ] ; unsigned short int exponent ; unsigned short int __glibc_reserved1 [ 3 ] ; } ; struct _libc_xmmreg { __uint32_t element [ 4 ] ; } ; struct _libc_fpstate { __uint16_t cwd ; __uint16_t swd ; __uint16_t ftw ; __uint16_t fop ; __uint64_t rip ; __uint64_t rdp ; __uint32_t mxcsr ; __uint32_t mxcr_mask ; struct _libc_fpxreg _st [ 8 ] ; struct _libc_xmmreg _xmm [ 16 ] ; __uint32_t __glibc_reserved1 [ 24 ] ; } ; typedef struct _libc_fpstate * fpregset_t ; typedef struct { gregset_t gregs ; fpregset_t fpregs ; __extension__ unsigned long long __reserved1 [ 8 ] ; } mcontext_t ; typedef struct ucontext_t { unsigned long int uc_flags ; struct ucontext_t * uc_link ; stack_t uc_stack ; mcontext_t uc_mcontext ; sigset_t uc_sigmask ; struct _libc_fpstate __fpregs_mem ; __extension__ unsigned long long int __ssp [ 4 ] ; } ucontext_t ;
extern int siginterrupt ( int __sig , int __interrupt ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ;
enum { SS_ONSTACK = 1 ,
SS_DISABLE
} ;
extern int sigaltstack ( const stack_t * __restrict __ss , stack_t * __restrict __oss ) __attribute__ ( ( __nothrow__ ) ) ;
struct sigstack { void * ss_sp ; int ss_onstack ; } ;
extern int sigstack ( struct sigstack * __ss , struct sigstack * __oss ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int sighold ( int __sig ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int sigrelse ( int __sig ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern int sigignore ( int __sig ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ; extern __sighandler_t sigset ( int __sig , __sighandler_t __disp ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __deprecated__ ) ) ;
extern int pthread_sigmask ( int __how , const __sigset_t * __restrict __newmask , __sigset_t * __restrict __oldmask ) __attribute__ ( ( __nothrow__ ) ) ; extern int pthread_kill ( pthread_t __threadid , int __signo ) __attribute__ ( ( __nothrow__ ) ) ;
extern int pthread_sigqueue ( pthread_t __threadid , int __signo , const union sigval __value ) __attribute__ ( ( __nothrow__ ) ) ;
extern int __libc_current_sigrtmin ( void ) __attribute__ ( ( __nothrow__ ) ) ; extern int __libc_current_sigrtmax ( void ) __attribute__ ( ( __nothrow__ ) ) ;
extern int tgkill ( __pid_t __tgid , __pid_t __tid , int __signal ) ;


struct timezone { int tz_minuteswest ; int tz_dsttime ; } ;
extern int gettimeofday ( struct timeval * __restrict __tv , void * __restrict __tz ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int settimeofday ( const struct timeval * __tv , const struct timezone * __tz ) __attribute__ ( ( __nothrow__ ) ) ; extern int adjtime ( const struct timeval * __delta , struct timeval * __olddelta ) __attribute__ ( ( __nothrow__ ) ) ;
enum __itimer_which { ITIMER_REAL = 0 ,
ITIMER_VIRTUAL = 1 ,
ITIMER_PROF = 2
} ; struct itimerval { struct timeval it_interval ; struct timeval it_value ; } ;
typedef enum __itimer_which __itimer_which_t ;
extern int getitimer ( __itimer_which_t __which , struct itimerval * __value ) __attribute__ ( ( __nothrow__ ) ) ; extern int setitimer ( __itimer_which_t __which , const struct itimerval * __restrict __new , struct itimerval * __restrict __old ) __attribute__ ( ( __nothrow__ ) ) ; extern int utimes ( const char * __file , const struct timeval __tvp [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ;
extern int lutimes ( const char * __file , const struct timeval __tvp [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __nonnull__ ( 1 ) ) ) ; extern int futimes ( int __fd , const struct timeval __tvp [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) ;
extern int futimesat ( int __fd , const char * __file , const struct timeval __tvp [ 2 ] ) __attribute__ ( ( __nothrow__ ) ) ;

typedef int GIT_SOCKET ;
extern char * p_realpath ( const char * , char * ) ; static __inline__ int p_fsync ( int fd ) { p_fsync__cnt ++ ; return fsync ( fd ) ; }
static __inline__ int p_futimes ( int f , const struct timeval t [ 2 ] ) { struct timespec s [ 2 ] ; s [ 0 ] . tv_sec = t [ 0 ] . tv_sec ; s [ 0 ] . tv_nsec = t [ 0 ] . tv_usec * 1000 ; s [ 1 ] . tv_sec = t [ 1 ] . tv_sec ; s [ 1 ] . tv_nsec = t [ 1 ] . tv_usec * 1000 ; return futimens ( f , s ) ; }
typedef unsigned long int nfds_t ; struct pollfd { int fd ; short int events ; short int revents ; } ; extern int poll ( struct pollfd * __fds , nfds_t __nfds , int __timeout ) ;
extern int ppoll ( struct pollfd * __fds , nfds_t __nfds , const struct timespec * __timeout , const __sigset_t * __ss ) ;

struct git_str { char * ptr ; size_t asize ; size_t size ; } ; typedef enum { GIT_STR_BOM_NONE = 0 , GIT_STR_BOM_UTF8 = 1 , GIT_STR_BOM_UTF16_LE = 2 , GIT_STR_BOM_UTF16_BE = 3 , GIT_STR_BOM_UTF32_LE = 4 , GIT_STR_BOM_UTF32_BE = 5 } git_str_bom_t ; typedef struct { git_str_bom_t bom ; unsigned int nul , cr , lf , crlf ; unsigned int printable , nonprintable ; } git_str_text_stats ; extern char git_str__initstr [ ] ; extern char git_str__oom [ ] ;
static __inline__ _Bool git_str_is_allocated ( const git_str * str ) { return ( str -> ptr != ( ( void * ) 0 ) && str -> asize > 0 ) ; } extern int git_str_init ( git_str * str , size_t initial_size ) ; extern void git_str_dispose ( git_str * str ) ; int git_str_grow ( git_str * str , size_t target_size ) ; extern int git_str_grow_by ( git_str * str , size_t additional_size ) ; extern int git_str_try_grow ( git_str * str , size_t target_size , _Bool mark_oom ) ; extern void git_str_swap ( git_str * str_a , git_str * str_b ) ; extern char * git_str_detach ( git_str * str ) ; extern int git_str_attach ( git_str * str , char * ptr , size_t asize ) ; extern void git_str_attach_notowned ( git_str * str , const char * ptr , size_t size ) ; static __inline__ _Bool git_str_oom ( const git_str * str ) { return ( str -> ptr == git_str__oom ) ; } int git_str_set ( git_str * str , const void * data , size_t datalen ) ; int git_str_sets ( git_str * str , const char * string ) ; int git_str_putc ( git_str * str , char c ) ; int git_str_putcn ( git_str * str , char c , size_t len ) ; int git_str_put ( git_str * str , const char * data , size_t len ) ; int git_str_puts ( git_str * str , const char * string ) ; int git_str_printf ( git_str * str , const char * format , ... ) __attribute__ ( ( format ( printf , 2 , 3 ) ) ) ; int git_str_vprintf ( git_str * str , const char * format , va_list ap ) ; void git_str_clear ( git_str * str ) ; void git_str_consume_bytes ( git_str * str , size_t len ) ; void git_str_consume ( git_str * str , const char * end ) ; void git_str_truncate ( git_str * str , size_t len ) ; void git_str_shorten ( git_str * str , size_t amount ) ; void git_str_truncate_at_char ( git_str * path , char separator ) ; void git_str_rtruncate_at_char ( git_str * path , char separator ) ; int git_str_join_n ( git_str * str , char separator , int len , ... ) ; int git_str_join ( git_str * str , char separator , const char * str_a , const char * str_b ) ; int git_str_join3 ( git_str * str , char separator , const char * str_a , const char * str_b , const char * str_c ) ; static __inline__ int git_str_joinpath ( git_str * str , const char * a , const char * b ) { return git_str_join ( str , '/' , a , b ) ; } static __inline__ const char * git_str_cstr ( const git_str * str ) { return str -> ptr ; } static __inline__ size_t git_str_len ( const git_str * str ) { return str -> size ; } int git_str_copy_cstr ( char * data , size_t datasize , const git_str * str ) ;
static __inline__ ssize_t git_str_rfind_next ( const git_str * str , char ch ) { ssize_t idx = ( ssize_t ) str -> size - 1 ; while ( idx >= 0 && str -> ptr [ idx ] == ch ) idx -- ; while ( idx >= 0 && str -> ptr [ idx ] != ch ) idx -- ; return idx ; } static __inline__ ssize_t git_str_rfind ( const git_str * str , char ch ) { ssize_t idx = ( ssize_t ) str -> size - 1 ; while ( idx >= 0 && str -> ptr [ idx ] != ch ) idx -- ; return idx ; } static __inline__ ssize_t git_str_find ( const git_str * str , char ch ) { void * found = memchr ( str -> ptr , ch , str -> size ) ; return found ? ( ssize_t ) ( ( const char * ) found - str -> ptr ) : - 1 ; } void git_str_rtrim ( git_str * str ) ; int git_str_cmp ( const git_str * a , const git_str * b ) ; int git_str_quote ( git_str * str ) ; int git_str_unquote ( git_str * str ) ; int git_str_encode_hexstr ( git_str * str , const char * data , size_t len ) ; int git_str_encode_base64 ( git_str * str , const char * data , size_t len ) ; int git_str_decode_base64 ( git_str * str , const char * base64 , size_t len ) ; int git_str_encode_base85 ( git_str * str , const char * data , size_t len ) ; int git_str_decode_base85 ( git_str * str , const char * base64 , size_t len , size_t output_len ) ; int git_str_decode_percent ( git_str * str , const char * encoded , size_t len ) ; int git_str_splice ( git_str * str , size_t where , size_t nb_to_remove , const char * data , size_t nb_to_insert ) ; extern int git_str_puts_escaped ( git_str * str , const char * string , const char * esc_chars , const char * esc_with ) ; static __inline__ int git_str_puts_escape_regex ( git_str * str , const char * string ) { return git_str_puts_escaped ( str , string , "^.[]$()|*+?{}\\" , "\\" ) ; } extern void git_str_unescape ( git_str * str ) ; extern int git_str_crlf_to_lf ( git_str * tgt , const git_str * src ) ; extern int git_str_lf_to_crlf ( git_str * tgt , const git_str * src ) ; extern int git_str_common_prefix ( git_str * buf , char * const * const strings , size_t count ) ; extern int git_str_detect_bom ( git_str_bom_t * bom , const git_str * str ) ; extern _Bool git_str_gather_text_stats ( git_str_text_stats * stats , const git_str * str , _Bool skip_bom ) ; int git_str_is_binary ( const git_str * str ) ; int git_str_contains_nul ( const git_str * str ) ;

enum { _ISupper = ( ( 0 ) < 8 ? ( ( 1 << ( 0 ) ) << 8 ) : ( ( 1 << ( 0 ) ) >> 8 ) ) , _ISlower = ( ( 1 ) < 8 ? ( ( 1 << ( 1 ) ) << 8 ) : ( ( 1 << ( 1 ) ) >> 8 ) ) , _ISalpha = ( ( 2 ) < 8 ? ( ( 1 << ( 2 ) ) << 8 ) : ( ( 1 << ( 2 ) ) >> 8 ) ) , _ISdigit = ( ( 3 ) < 8 ? ( ( 1 << ( 3 ) ) << 8 ) : ( ( 1 << ( 3 ) ) >> 8 ) ) , _ISxdigit = ( ( 4 ) < 8 ? ( ( 1 << ( 4 ) ) << 8 ) : ( ( 1 << ( 4 ) ) >> 8 ) ) , _ISspace = ( ( 5 ) < 8 ? ( ( 1 << ( 5 ) ) << 8 ) : ( ( 1 << ( 5 ) ) >> 8 ) ) , _ISprint = ( ( 6 ) < 8 ? ( ( 1 << ( 6 ) ) << 8 ) : ( ( 1 << ( 6 ) ) >> 8 ) ) , _ISgraph = ( ( 7 ) < 8 ? ( ( 1 << ( 7 ) ) << 8 ) : ( ( 1 << ( 7 ) ) >> 8 ) ) , _ISblank = ( ( 8 ) < 8 ? ( ( 1 << ( 8 ) ) << 8 ) : ( ( 1 << ( 8 ) ) >> 8 ) ) , _IScntrl = ( ( 9 ) < 8 ? ( ( 1 << ( 9 ) ) << 8 ) : ( ( 1 << ( 9 ) ) >> 8 ) ) , _ISpunct = ( ( 10 ) < 8 ? ( ( 1 << ( 10 ) ) << 8 ) : ( ( 1 << ( 10 ) ) >> 8 ) ) , _ISalnum = ( ( 11 ) < 8 ? ( ( 1 << ( 11 ) ) << 8 ) : ( ( 1 << ( 11 ) ) >> 8 ) ) } ;
extern const unsigned short int * * __ctype_b_loc ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern const __int32_t * * __ctype_tolower_loc ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ; extern const __int32_t * * __ctype_toupper_loc ( void ) __attribute__ ( ( __nothrow__ ) ) __attribute__ ( ( __const__ ) ) ;
extern int isalnum ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isalpha ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int iscntrl ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isdigit ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int islower ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isgraph ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isprint ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int ispunct ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isspace ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isupper ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int isxdigit ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int tolower ( int __c ) __attribute__ ( ( __nothrow__ ) ) ; extern int toupper ( int __c ) __attribute__ ( ( __nothrow__ ) ) ;
extern int isblank ( int ) __attribute__ ( ( __nothrow__ ) ) ;
extern int isctype ( int __c , int __mask ) __attribute__ ( ( __nothrow__ ) ) ;
extern int isascii ( int __c ) __attribute__ ( ( __nothrow__ ) ) ; extern int toascii ( int __c ) __attribute__ ( ( __nothrow__ ) ) ; extern int _toupper ( int ) __attribute__ ( ( __nothrow__ ) ) ; extern int _tolower ( int ) __attribute__ ( ( __nothrow__ ) ) ;
extern int isalnum_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isalpha_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int iscntrl_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isdigit_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int islower_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isgraph_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isprint_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int ispunct_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isspace_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isupper_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isxdigit_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int isblank_l ( int , locale_t ) __attribute__ ( ( __nothrow__ ) ) ; extern int __tolower_l ( int __c , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) ; extern int tolower_l ( int __c , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) ; extern int __toupper_l ( int __c , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) ; extern int toupper_l ( int __c , locale_t __l ) __attribute__ ( ( __nothrow__ ) ) ;

extern int git__prefixcmp ( const char * str , const char * prefix ) ; extern int git__prefixcmp_icase ( const char * str , const char * prefix ) ; extern int git__prefixncmp ( const char * str , size_t str_n , const char * prefix ) ; extern int git__prefixncmp_icase ( const char * str , size_t str_n , const char * prefix ) ; extern int git__suffixcmp ( const char * str , const char * suffix ) ; static __inline__ int git__signum ( int val ) { return ( ( val > 0 ) - ( val < 0 ) ) ; } extern int git__strntol32 ( int32_t * n , const char * buff , size_t buff_len , const char * * end_buf , int base ) ; extern int git__strntol64 ( int64_t * n , const char * buff , size_t buff_len , const char * * end_buf , int base ) ; extern void git__hexdump ( const char * buffer , size_t n ) ; extern uint32_t git__hash ( const void * key , int len , uint32_t seed ) ;
extern char * git__strtok ( char * * end , const char * sep ) ; extern char * git__strsep ( char * * end , const char * sep ) ; extern void git__strntolower ( char * str , size_t len ) ; extern void git__strtolower ( char * str ) ; extern size_t git__linenlen ( const char * buffer , size_t buffer_len ) ; static __inline__ const char * git__next_line ( const char * s ) { while ( * s && * s != '\n' ) s ++ ; while ( * s == '\n' || * s == '\r' ) s ++ ; return s ; } static __inline__ const void * git__memrchr ( const void * s , int c , size_t n ) { const unsigned char * cp ; if ( n != 0 ) { cp = ( unsigned char * ) s + n ; do { if ( * ( -- cp ) == ( unsigned char ) c ) return cp ; } while ( -- n != 0 ) ; } return ( ( void * ) 0 ) ; } extern const void * git__memmem ( const void * haystack , size_t haystacklen , const void * needle , size_t needlelen ) ; typedef int ( * git__tsort_cmp ) ( const void * a , const void * b ) ; extern void git__tsort ( void * * dst , size_t size , git__tsort_cmp cmp ) ; typedef int ( * git__sort_r_cmp ) ( const void * a , const void * b , void * payload ) ; extern void git__tsort_r ( void * * dst , size_t size , git__sort_r_cmp cmp , void * payload ) ; extern void git__qsort_r ( void * els , size_t nel , size_t elsize , git__sort_r_cmp cmp , void * payload ) ; extern int git__bsearch ( void * * array , size_t array_len , const void * key , int ( * compare ) ( const void * key , const void * element ) , size_t * position ) ; extern int git__bsearch_r ( void * * array , size_t array_len , const void * key , int ( * compare_r ) ( const void * key , const void * element , void * payload ) , void * payload , size_t * position ) ;
extern int git__strcmp_cb ( const void * a , const void * b ) ; extern int git__strcasecmp_cb ( const void * a , const void * b ) ; extern int git__strcasecmp ( const char * a , const char * b ) ; extern int git__strncasecmp ( const char * a , const char * b , size_t sz ) ; extern int git__strcasesort_cmp ( const char * a , const char * b ) ; static __inline__ int git__strlcmp ( const char * a , const char * b , size_t b_len ) { int cmp = strncmp ( a , b , b_len ) ; return cmp ? cmp : ( int ) a [ b_len ] ; } typedef struct { git_atomic32 refcount ; void * owner ; } git_refcount ; typedef void ( * git_refcount_freeptr ) ( void * r ) ;
static signed char from_hex [ ] = { - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , 0 , 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , 10 , 11 , 12 , 13 , 14 , 15 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , 10 , 11 , 12 , 13 , 14 , 15 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , - 1 , } ; static __inline__ int git__fromhex ( char h ) { return from_hex [ ( unsigned char ) h ] ; } static __inline__ int git__ishex ( const char * str ) { unsigned i ; for ( i = 0 ; str [ i ] != '\0' ; i ++ ) if ( git__fromhex ( str [ i ] ) < 0 ) return 0 ; return 1 ; } static __inline__ size_t git__size_t_bitmask ( size_t v ) { v -- ; v |= v >> 1 ; v |= v >> 2 ; v |= v >> 4 ; v |= v >> 8 ; v |= v >> 16 ; return v ; } static __inline__ size_t git__size_t_powerof2 ( size_t v ) { return git__size_t_bitmask ( v ) + 1 ; } static __inline__ _Bool git__isspace_nonlf ( int c ) { return ( c == ' ' || c == '\t' || c == '\f' || c == '\r' || c == '\v' ) ; } static __inline__ _Bool git__iswildcard ( int c ) { return ( c == '*' || c == '?' || c == '[' ) ; } extern int git__parse_bool ( int * out , const char * value ) ; extern size_t git__unescape ( char * str ) ; static __inline__ void git__memzero ( void * data , size_t size ) {
volatile uint8_t * scan = ( volatile uint8_t * ) data ; while ( size -- ) * scan ++ = 0x0 ;
}
static __inline__ uint64_t git_time_monotonic ( void ) { struct timeval tv ;
struct timespec tp ; if ( clock_gettime ( 1 , & tp ) == 0 ) return ( tp . tv_sec * 1000 ) + ( tp . tv_nsec / 1.0E6 ) ;
gettimeofday ( & tv , ( ( void * ) 0 ) ) ; return ( tv . tv_sec * 1000 ) + ( tv . tv_usec / 1000 ) ; }
extern int git__getenv ( git_str * out , const char * name ) ; extern int git__online_cpus ( void ) ; static __inline__ int git__noop ( void ) { return 0 ; } static __inline__ int git__noop_args ( void * a , ... ) { do { __typeof__ ( a ) _unused __attribute__ ( ( unused ) ) ; _unused = ( a ) ; } while ( 0 ) ; return 0 ; }
extern git_allocator git__allocator ; static __inline__ void * git__malloc ( size_t len ) { void * p = git__allocator . gmalloc ( len , "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h" , 19 ) ; if ( ! p ) git_error_set_oom ( ) ; return p ; } static __inline__ void * git__realloc ( void * ptr , size_t size ) { void * p = git__allocator . grealloc ( ptr , size , "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h" , 29 ) ; if ( ! p ) git_error_set_oom ( ) ; return p ; } static __inline__ void git__free ( void * ptr ) { git__allocator . gfree ( ptr ) ; } extern void * git__calloc ( size_t nelem , size_t elsize ) ; extern void * git__mallocarray ( size_t nelem , size_t elsize ) ; extern void * git__reallocarray ( void * ptr , size_t nelem , size_t elsize ) ; extern char * git__strdup ( const char * str ) ; extern char * git__strndup ( const char * str , size_t n ) ; extern char * git__substrdup ( const char * str , size_t n ) ; int git_allocator_global_init ( void ) ; int git_allocator_setup ( git_allocator * allocator ) ;
typedef int ( * git_runtime_init_fn ) ( void ) ; typedef void ( * git_runtime_shutdown_fn ) ( void ) ; int git_runtime_init ( git_runtime_init_fn init_fns [ ] , size_t cnt ) ; int git_runtime_init_count ( void ) ; int git_runtime_shutdown ( void ) ; int git_runtime_shutdown_register ( git_runtime_shutdown_fn callback ) ;
int git_stdalloc_init_allocator ( git_allocator * allocator ) ;
int git_debugalloc_init_allocator ( git_allocator * allocator ) ;
extern void * git_failalloc_malloc ( size_t len , const char * file , int line ) ; extern void * git_failalloc_realloc ( void * ptr , size_t size , const char * file , int line ) ; extern void git_failalloc_free ( void * ptr ) ;
int git_win32_leakcheck_init_allocator ( git_allocator * allocator ) ;
git_allocator git__allocator = { git_failalloc_malloc , git_failalloc_realloc , git_failalloc_free } ; void * git__calloc ( size_t nelem , size_t elsize ) { size_t newsize ; void * ptr ; if ( ( __builtin_umull_overflow ( nelem , elsize , & newsize ) ? ( git_error_set_oom ( ) , 1 ) : 0 ) ) return ( ( void * ) 0 ) ; if ( ( ptr = git__malloc ( newsize ) ) ) memset ( ptr , 0 , newsize ) ; return ptr ; } void * git__reallocarray ( void * ptr , size_t nelem , size_t elsize ) { size_t newsize ; if ( ( __builtin_umull_overflow ( nelem , elsize , & newsize ) ? ( git_error_set_oom ( ) , 1 ) : 0 ) ) return ( ( void * ) 0 ) ; return git__realloc ( ptr , newsize ) ; } void * git__mallocarray ( size_t nelem , size_t elsize ) { return git__reallocarray ( ( ( void * ) 0 ) , nelem , elsize ) ; } char * git__strdup ( const char * str ) { size_t len = strlen ( str ) + 1 ; void * ptr = git__malloc ( len ) ; if ( ptr ) memcpy ( ptr , str , len ) ; return ptr ; } char * git__strndup ( const char * str , size_t n ) { size_t len = strnlen ( str , n ) ; char * ptr = git__malloc ( len + 1 ) ; if ( ptr ) { memcpy ( ptr , str , len ) ; ptr [ len ] = '\0' ; } return ptr ; } char * git__substrdup ( const char * str , size_t n ) { char * ptr = git__malloc ( n + 1 ) ; if ( ptr ) { memcpy ( ptr , str , n ) ; ptr [ n ] = '\0' ; } return ptr ; } static int setup_default_allocator ( void ) {
return git_stdalloc_init_allocator ( & git__allocator ) ;
} int git_allocator_global_init ( void ) { if ( git__allocator . gmalloc != git_failalloc_malloc ) return 0 ; return setup_default_allocator ( ) ; } int git_allocator_setup ( git_allocator * allocator ) { if ( ! allocator ) return setup_default_allocator ( ) ; memcpy ( & git__allocator , allocator , sizeof ( * allocator ) ) ; return 0 ; }
