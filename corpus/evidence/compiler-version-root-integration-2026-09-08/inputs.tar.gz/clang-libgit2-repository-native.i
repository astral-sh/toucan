# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 389 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2







# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/common.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/common.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/src/util/git2_features.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h"
# 1 "/usr/include/time.h" 1 3 4
# 25 "/usr/include/time.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 480 "/usr/include/features.h" 3 4
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 481 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 26 "/usr/include/time.h" 2 3 4



# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 18 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 3 4
typedef long unsigned int size_t;
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 30 "/usr/include/time.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/time.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/time.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 27 "/usr/include/x86_64-linux-gnu/bits/time.h" 2 3 4
# 73 "/usr/include/x86_64-linux-gnu/bits/time.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timex.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/timex.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 23 "/usr/include/x86_64-linux-gnu/bits/timex.h" 2 3 4



struct timex
{
# 58 "/usr/include/x86_64-linux-gnu/bits/timex.h" 3 4
  unsigned int modes;
  __syscall_slong_t offset;
  __syscall_slong_t freq;
  __syscall_slong_t maxerror;
  __syscall_slong_t esterror;
  int status;
  __syscall_slong_t constant;
  __syscall_slong_t precision;
  __syscall_slong_t tolerance;
  struct timeval time;
  __syscall_slong_t tick;
  __syscall_slong_t ppsfreq;
  __syscall_slong_t jitter;
  int shift;
  __syscall_slong_t stabil;
  __syscall_slong_t jitcnt;
  __syscall_slong_t calcnt;
  __syscall_slong_t errcnt;
  __syscall_slong_t stbcnt;

  int tai;


  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32;

};
# 74 "/usr/include/x86_64-linux-gnu/bits/time.h" 2 3 4




extern int clock_adjtime (__clockid_t __clock_id, struct timex *__utx) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 34 "/usr/include/time.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 38 "/usr/include/time.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 39 "/usr/include/time.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_tm.h" 1 3 4






struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;


  long int tm_gmtoff;
  const char *tm_zone;




};
# 40 "/usr/include/time.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 1 3 4





# 1 "/usr/include/x86_64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/endian.h" 2 3 4
# 7 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 2 3 4




struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 43 "/usr/include/time.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 47 "/usr/include/time.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 48 "/usr/include/time.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_itimerspec.h" 1 3 4







struct itimerspec
  {
    struct timespec it_interval;
    struct timespec it_value;
  };
# 49 "/usr/include/time.h" 2 3 4
struct sigevent;




typedef __pid_t pid_t;





# 1 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 61 "/usr/include/time.h" 2 3 4
# 72 "/usr/include/time.h" 3 4
extern clock_t clock (void) __attribute__ ((__nothrow__ ));



extern time_t time (time_t *__timer) __attribute__ ((__nothrow__ ));


extern double difftime (time_t __time1, time_t __time0)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern time_t mktime (struct tm *__tp) __attribute__ ((__nothrow__ ));
# 100 "/usr/include/time.h" 3 4
extern size_t strftime (char *__restrict __s, size_t __maxsize,
   const char *__restrict __format,
   const struct tm *__restrict __tp)
   __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3, 4)));




extern char *strptime (const char *__restrict __s,
         const char *__restrict __fmt, struct tm *__tp)
     __attribute__ ((__nothrow__ ));






extern size_t strftime_l (char *__restrict __s, size_t __maxsize,
     const char *__restrict __format,
     const struct tm *__restrict __tp,
     locale_t __loc) __attribute__ ((__nothrow__ ));



extern char *strptime_l (const char *__restrict __s,
    const char *__restrict __fmt, struct tm *__tp,
    locale_t __loc) __attribute__ ((__nothrow__ ));






extern struct tm *gmtime (const time_t *__timer) __attribute__ ((__nothrow__ ));



extern struct tm *localtime (const time_t *__timer) __attribute__ ((__nothrow__ ));
# 155 "/usr/include/time.h" 3 4
extern struct tm *gmtime_r (const time_t *__restrict __timer,
       struct tm *__restrict __tp) __attribute__ ((__nothrow__ ));



extern struct tm *localtime_r (const time_t *__restrict __timer,
          struct tm *__restrict __tp) __attribute__ ((__nothrow__ ));
# 180 "/usr/include/time.h" 3 4
extern char *asctime (const struct tm *__tp) __attribute__ ((__nothrow__ ));



extern char *ctime (const time_t *__timer) __attribute__ ((__nothrow__ ));
# 198 "/usr/include/time.h" 3 4
extern char *asctime_r (const struct tm *__restrict __tp,
   char *__restrict __buf) __attribute__ ((__nothrow__ ));



extern char *ctime_r (const time_t *__restrict __timer,
        char *__restrict __buf) __attribute__ ((__nothrow__ ));
# 218 "/usr/include/time.h" 3 4
extern char *__tzname[2];
extern int __daylight;
extern long int __timezone;




extern char *tzname[2];



extern void tzset (void) __attribute__ ((__nothrow__ ));



extern int daylight;
extern long int timezone;
# 247 "/usr/include/time.h" 3 4
extern time_t timegm (struct tm *__tp) __attribute__ ((__nothrow__ ));
# 264 "/usr/include/time.h" 3 4
extern time_t timelocal (struct tm *__tp) __attribute__ ((__nothrow__ ));







extern int dysize (int __year) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
# 282 "/usr/include/time.h" 3 4
extern int nanosleep (const struct timespec *__requested_time,
        struct timespec *__remaining);


extern int clock_getres (clockid_t __clock_id, struct timespec *__res) __attribute__ ((__nothrow__ ));


extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));


extern int clock_settime (clockid_t __clock_id, const struct timespec *__tp)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 324 "/usr/include/time.h" 3 4
extern int clock_nanosleep (clockid_t __clock_id, int __flags,
       const struct timespec *__req,
       struct timespec *__rem);
# 339 "/usr/include/time.h" 3 4
extern int clock_getcpuclockid (pid_t __pid, clockid_t *__clock_id) __attribute__ ((__nothrow__ ));




extern int timer_create (clockid_t __clock_id,
    struct sigevent *__restrict __evp,
    timer_t *__restrict __timerid) __attribute__ ((__nothrow__ ));


extern int timer_delete (timer_t __timerid) __attribute__ ((__nothrow__ ));



extern int timer_settime (timer_t __timerid, int __flags,
     const struct itimerspec *__restrict __value,
     struct itimerspec *__restrict __ovalue) __attribute__ ((__nothrow__ ));


extern int timer_gettime (timer_t __timerid, struct itimerspec *__value)
     __attribute__ ((__nothrow__ ));
# 377 "/usr/include/time.h" 3 4
extern int timer_getoverrun (timer_t __timerid) __attribute__ ((__nothrow__ ));






extern int timespec_get (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 400 "/usr/include/time.h" 3 4
extern int timespec_getres (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ ));
# 426 "/usr/include/time.h" 3 4
extern int getdate_err;
# 435 "/usr/include/time.h" 3 4
extern struct tm *getdate (const char *__string);
# 449 "/usr/include/time.h" 3 4
extern int getdate_r (const char *__restrict __string,
        struct tm *__restrict __resbufp);
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h" 2
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 87 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h" 1 3 4
# 24 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h" 3 4
typedef int wchar_t;
# 88 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 119 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 120 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ )) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 159 "/usr/include/stdlib.h" 3 4
extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));






extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ ))


     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ ))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ ))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ ))



     __attribute__ ((__nonnull__ (1)));

__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ ))


     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ ))



     __attribute__ ((__nonnull__ (1)));
# 278 "/usr/include/stdlib.h" 3 4
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));

extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));

extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));
# 298 "/usr/include/stdlib.h" 3 4
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));



extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));
# 316 "/usr/include/stdlib.h" 3 4
extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));



extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));
# 340 "/usr/include/stdlib.h" 3 4
extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 4)));

extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 4)));

__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 4)));





extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ ))



     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ ))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ ))




     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ ))




     __attribute__ ((__nonnull__ (1, 4)));
# 415 "/usr/include/stdlib.h" 3 4
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));

extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));

extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));
# 436 "/usr/include/stdlib.h" 3 4
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));
# 457 "/usr/include/stdlib.h" 3 4
extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));



extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ )) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/x86_64-linux-gnu/sys/types.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;






typedef __ino64_t ino64_t;




typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;






typedef __off64_t off64_t;
# 103 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;
# 134 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __useconds_t useconds_t;



typedef __suseconds_t suseconds_t;





# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 145 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 156 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4


typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{



  return ((__uint16_t) ((((__bsx) >> 8) & 0xff) | (((__bsx) & 0xff) << 8)));

}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{



  return ((((__bsx) & 0xff000000u) >> 24) | (((__bsx) & 0x00ff0000u) >> 8) | (((__bsx) & 0x0000ff00u) << 8) | (((__bsx) & 0x000000ffu) << 24));

}
# 69 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{



  return ((((__bsx) & 0xff00000000000000ull) >> 56) | (((__bsx) & 0x00ff000000000000ull) >> 40) | (((__bsx) & 0x0000ff0000000000ull) >> 24) | (((__bsx) & 0x000000ff00000000ull) >> 8) | (((__bsx) & 0x00000000ff000000ull) << 8) | (((__bsx) & 0x0000000000ff0000ull) << 24) | (((__bsx) & 0x000000000000ff00ull) << 40) | (((__bsx) & 0x00000000000000ffull) << 56));

}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/x86_64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4
# 49 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
typedef long int __fd_mask;
# 59 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
typedef struct
  {



    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];





  } fd_set;






typedef __fd_mask fd_mask;
# 102 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 180 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 219 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;





# 1 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 2 3 4
# 45 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;



  int __kind;

  short __spins;
  short __elision;
  __pthread_list_t __list;
# 53 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;

  int __cur_writer;
  int __shared;
  signed char __rwelision;




  unsigned char __pad1[7];


  unsigned long int __pad2;


  unsigned int __flags;
# 55 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 3 4
};
# 90 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ ));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ ));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ ));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ ));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ ));







extern double drand48 (void) __attribute__ ((__nothrow__ ));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ ));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ ));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ ));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ )) ;


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ )) ;




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__)) ;


extern void free (void *__ptr) __attribute__ ((__nothrow__ ));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__))

                       ;


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) ;



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ ));
# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
                                         ;



extern void abort (void) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;




extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;






extern int putenv (char *__string) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ ));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 837 "/usr/include/stdlib.h" 3 4
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
# 859 "/usr/include/stdlib.h" 3 4
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 881 "/usr/include/stdlib.h" 3 4
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 891 "/usr/include/stdlib.h" 3 4
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
# 901 "/usr/include/stdlib.h" 3 4
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 913 "/usr/include/stdlib.h" 3 4
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;





extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
                              ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ )) ;






typedef int (*__compar_fn_t) (const void *, const void *);


typedef __compar_fn_t comparison_fn_t;



typedef int (*__compar_d_fn_t) (const void *, const void *, void *);




extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));

extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));




extern int abs (int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ ));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ ));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ))
                                      ;

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ ))

                                    ;






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3))) ;







extern int posix_openpt (int __oflag) ;







extern int grantpt (int __fd) __attribute__ ((__nothrow__ ));



extern int unlockpt (int __fd) __attribute__ ((__nothrow__ ));




extern char *ptsname (int __fd) __attribute__ ((__nothrow__ )) ;






extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;


extern int getpt (void);






extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h" 2
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/inttypes.h" 1 3
# 21 "/usr/lib/llvm-18/lib/clang/18/include/inttypes.h" 3
# 1 "/usr/include/inttypes.h" 1 3 4
# 27 "/usr/include/inttypes.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 1 3 4
# 52 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 3 4
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 53 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 2 3 4
# 28 "/usr/include/inttypes.h" 2 3 4






typedef int __gwchar_t;
# 332 "/usr/include/inttypes.h" 3 4
typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
# 351 "/usr/include/inttypes.h" 3 4
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ ));


extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ ));


extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));


extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));





extern intmax_t strtoimax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoimax") __attribute__ ((__nothrow__ ));


extern uintmax_t strtoumax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoumax") __attribute__ ((__nothrow__ ));


extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoimax") __attribute__ ((__nothrow__ ));



extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoumax") __attribute__ ((__nothrow__ ));
# 22 "/usr/lib/llvm-18/lib/clang/18/include/inttypes.h" 2 3
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h" 2
# 119 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h"
extern __attribute__((visibility("default"))) int git_libgit2_version(int *major, int *minor, int *rev);
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h"
extern __attribute__((visibility("default"))) const char * git_libgit2_prerelease(void);







typedef enum {




 GIT_FEATURE_THREADS = (1 << 0),


 GIT_FEATURE_HTTPS = (1 << 1),


 GIT_FEATURE_SSH = (1 << 2),


 GIT_FEATURE_NSEC = (1 << 3),


 GIT_FEATURE_HTTP_PARSER = (1 << 4),


 GIT_FEATURE_REGEX = (1 << 5),


 GIT_FEATURE_I18N = (1 << 6),


 GIT_FEATURE_AUTH_NTLM = (1 << 7),


 GIT_FEATURE_AUTH_NEGOTIATE = (1 << 8),


 GIT_FEATURE_COMPRESSION = (1 << 9),


 GIT_FEATURE_SHA1 = (1 << 10),


 GIT_FEATURE_SHA256 = (1 << 11)
} git_feature_t;






extern __attribute__((visibility("default"))) int git_libgit2_features(void);
# 205 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h"
extern __attribute__((visibility("default"))) const char * git_libgit2_feature_backend(
 git_feature_t feature);







typedef enum {
 GIT_OPT_GET_MWINDOW_SIZE,
 GIT_OPT_SET_MWINDOW_SIZE,
 GIT_OPT_GET_MWINDOW_MAPPED_LIMIT,
 GIT_OPT_SET_MWINDOW_MAPPED_LIMIT,
 GIT_OPT_GET_SEARCH_PATH,
 GIT_OPT_SET_SEARCH_PATH,
 GIT_OPT_SET_CACHE_OBJECT_LIMIT,
 GIT_OPT_SET_CACHE_MAX_SIZE,
 GIT_OPT_ENABLE_CACHING,
 GIT_OPT_GET_CACHED_MEMORY,
 GIT_OPT_GET_TEMPLATE_PATH,
 GIT_OPT_SET_TEMPLATE_PATH,
 GIT_OPT_SET_SSL_CERT_LOCATIONS,
 GIT_OPT_SET_USER_AGENT,
 GIT_OPT_ENABLE_STRICT_OBJECT_CREATION,
 GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION,
 GIT_OPT_SET_SSL_CIPHERS,
 GIT_OPT_GET_USER_AGENT,
 GIT_OPT_ENABLE_OFS_DELTA,
 GIT_OPT_ENABLE_FSYNC_GITDIR,
 GIT_OPT_GET_WINDOWS_SHAREMODE,
 GIT_OPT_SET_WINDOWS_SHAREMODE,
 GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION,
 GIT_OPT_SET_ALLOCATOR,
 GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY,
 GIT_OPT_GET_PACK_MAX_OBJECTS,
 GIT_OPT_SET_PACK_MAX_OBJECTS,
 GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS,
 GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE,
 GIT_OPT_GET_MWINDOW_FILE_LIMIT,
 GIT_OPT_SET_MWINDOW_FILE_LIMIT,
 GIT_OPT_SET_ODB_PACKED_PRIORITY,
 GIT_OPT_SET_ODB_LOOSE_PRIORITY,
 GIT_OPT_GET_EXTENSIONS,
 GIT_OPT_SET_EXTENSIONS,
 GIT_OPT_GET_OWNER_VALIDATION,
 GIT_OPT_SET_OWNER_VALIDATION,
 GIT_OPT_GET_HOMEDIR,
 GIT_OPT_SET_HOMEDIR,
 GIT_OPT_SET_SERVER_CONNECT_TIMEOUT,
 GIT_OPT_GET_SERVER_CONNECT_TIMEOUT,
 GIT_OPT_SET_SERVER_TIMEOUT,
 GIT_OPT_GET_SERVER_TIMEOUT,
 GIT_OPT_SET_USER_AGENT_PRODUCT,
 GIT_OPT_GET_USER_AGENT_PRODUCT,
 GIT_OPT_ADD_SSL_X509_CERT
} git_libgit2_opt_t;
# 569 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/common.h"
extern __attribute__((visibility("default"))) int git_libgit2_opts(int option, ...);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/errors.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/errors.h"
extern __attribute__((visibility("default"))) void git_error_clear(void);
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/errors.h"
extern __attribute__((visibility("default"))) void git_error_set(int error_class, const char *fmt, ...)
                 __attribute__((format (printf, 2, 3)));
# 60 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/errors.h"
extern __attribute__((visibility("default"))) int git_error_set_str(int error_class, const char *string);
# 71 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/errors.h"
extern __attribute__((visibility("default"))) void git_error_set_oom(void);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/cc-compat.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/cc-compat.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 1 3
# 55 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg___gnuc_va_list.h" 1 3
# 12 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg___gnuc_va_list.h" 3
typedef __builtin_va_list __gnuc_va_list;
# 56 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg_va_list.h" 1 3
# 12 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg_va_list.h" 3
typedef __builtin_va_list va_list;
# 61 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg_va_arg.h" 1 3
# 66 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg___va_copy.h" 1 3
# 71 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stdarg_va_copy.h" 1 3
# 76 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 2 3
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/cc-compat.h" 2
# 99 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/cc-compat.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdbool.h" 1 3
# 100 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/cc-compat.h" 2
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2

typedef struct git_str git_str;
# 56 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h"
# 1 "/usr/include/assert.h" 1 3 4
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/usr/include/errno.h" 1 3 4
# 28 "/usr/include/errno.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/errno.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/errno.h" 3 4
# 1 "/usr/include/linux/errno.h" 1 3 4
# 1 "/usr/include/x86_64-linux-gnu/asm/errno.h" 1 3 4
# 1 "/usr/include/asm-generic/errno.h" 1 3 4




# 1 "/usr/include/asm-generic/errno-base.h" 1 3 4
# 6 "/usr/include/asm-generic/errno.h" 2 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/errno.h" 2 3 4
# 2 "/usr/include/linux/errno.h" 2 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/errno.h" 2 3 4
# 29 "/usr/include/errno.h" 2 3 4








extern int *__errno_location (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));







extern char *program_invocation_name;
extern char *program_invocation_short_name;

# 1 "/usr/include/x86_64-linux-gnu/bits/types/error_t.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/error_t.h" 3 4
typedef int error_t;
# 49 "/usr/include/errno.h" 2 3 4
# 58 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 1 3
# 21 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 3
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4
extern long int __sysconf (int __name) __attribute__ ((__nothrow__ ));
# 82 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/xopen_lim.h" 1 3 4
# 64 "/usr/include/x86_64-linux-gnu/bits/xopen_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/uio_lim.h" 1 3 4
# 65 "/usr/include/x86_64-linux-gnu/bits/xopen_lim.h" 2 3 4
# 204 "/usr/include/limits.h" 2 3 4
# 22 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 2 3
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2

# 1 "/usr/include/stdio.h" 1 3 4
# 28 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 29 "/usr/include/stdio.h" 2 3 4





# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 35 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 1 3 4
# 38 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 1 3 4
# 13 "/usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h" 3 4
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
# 6 "/usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h" 2 3 4




typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
# 41 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h" 3 4
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
# 42 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__FILE.h" 1 3 4



struct _IO_FILE;
typedef struct _IO_FILE __FILE;
# 43 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/FILE.h" 1 3 4



struct _IO_FILE;


typedef struct _IO_FILE FILE;
# 44 "/usr/include/stdio.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h" 3 4
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;




typedef void _IO_lock_t;





struct _IO_FILE
{
  int _flags;


  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;


  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;

  struct _IO_marker *_markers;

  struct _IO_FILE *_chain;

  int _fileno;
  int _flags2;
  __off_t _old_offset;


  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];

  _IO_lock_t *_lock;







  __off64_t _offset;

  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;

  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
# 45 "/usr/include/stdio.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h" 3 4
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);







typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);







typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);


typedef int cookie_close_function_t (void *__cookie);






typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
# 48 "/usr/include/stdio.h" 2 3 4





typedef __gnuc_va_list va_list;
# 85 "/usr/include/stdio.h" 3 4
typedef __fpos_t fpos_t;




typedef __fpos64_t fpos64_t;
# 129 "/usr/include/stdio.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdio_lim.h" 1 3 4
# 130 "/usr/include/stdio.h" 2 3 4
# 149 "/usr/include/stdio.h" 3 4
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;






extern int remove (const char *__filename) __attribute__ ((__nothrow__ ));

extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ ));



extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ ));
# 176 "/usr/include/stdio.h" 3 4
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ ));






extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 194 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) ;
# 206 "/usr/include/stdio.h" 3 4
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) ;



extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ )) ;




extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ )) ;
# 228 "/usr/include/stdio.h" 3 4
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;






extern int fflush (FILE *__stream);
# 245 "/usr/include/stdio.h" 3 4
extern int fflush_unlocked (FILE *__stream);
# 255 "/usr/include/stdio.h" 3 4
extern int fcloseall (void);
# 264 "/usr/include/stdio.h" 3 4
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) ;




extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
# 289 "/usr/include/stdio.h" 3 4
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) ;
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));




extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;





extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;




extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;




extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
# 334 "/usr/include/stdio.h" 3 4
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ ))
  __attribute__ ((__nonnull__ (1)));



extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int printf (const char *__restrict __format, ...);

extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));





extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));




extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);

extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));



extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));

extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));





extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;




extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));







extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));




extern int scanf (const char *__restrict __format, ...) ;

extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ ));
# 442 "/usr/include/stdio.h" 3 4
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf") __attribute__ ((__nonnull__ (1)));


extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf") ;

extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ ));
# 490 "/usr/include/stdio.h" 3 4
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));





extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;


extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__format__ (__scanf__, 2, 0)));






extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")



     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")

     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ ))



     __attribute__ ((__format__ (__scanf__, 2, 0)));
# 575 "/usr/include/stdio.h" 3 4
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern int getchar (void);






extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
# 600 "/usr/include/stdio.h" 3 4
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 611 "/usr/include/stdio.h" 3 4
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));





extern int putchar (int __c);
# 627 "/usr/include/stdio.h" 3 4
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);






extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));


extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));







extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
                                                          __attribute__ ((__nonnull__ (3)));
# 677 "/usr/include/stdio.h" 3 4
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream)
                                                   __attribute__ ((__nonnull__ (3)));
# 694 "/usr/include/stdio.h" 3 4
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));







extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));







extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));





extern int puts (const char *__s);






extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));






extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));




extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
# 755 "/usr/include/stdio.h" 3 4
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
# 766 "/usr/include/stdio.h" 3 4
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));







extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));




extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 803 "/usr/include/stdio.h" 3 4
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));




extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
# 829 "/usr/include/stdio.h" 3 4
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));




extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
# 851 "/usr/include/stdio.h" 3 4
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));



extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

extern int feof (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







extern void perror (const char *__s) __attribute__ ((__cold__));




extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 897 "/usr/include/stdio.h" 3 4
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));





extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) ;






extern char *ctermid (char *__s) __attribute__ ((__nothrow__ ))
                                     ;





extern char *cuserid (char *__s)
                                     ;




struct obstack;


extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));







extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 959 "/usr/include/stdio.h" 3 4
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 120 "/usr/include/string.h" 3 4
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 133 "/usr/include/string.h" 3 4
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
                                           ;





extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;






extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))

                                         ;



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
# 444 "/usr/include/string.h" 3 4
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;




extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ ));

extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ ));





extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 24 "/usr/include/strings.h" 2 3 4
# 34 "/usr/include/strings.h" 3 4
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));



extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ ));


extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ ));



extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;




extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern char *strfry (char *__string) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                          ;
# 540 "/usr/include/string.h" 3 4
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2


# 1 "/usr/include/x86_64-linux-gnu/sys/stat.h" 1 3 4
# 101 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stat.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stat.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_stat.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/struct_stat.h" 3 4
struct stat
  {



    __dev_t st_dev;




    __ino_t st_ino;







    __nlink_t st_nlink;
    __mode_t st_mode;

    __uid_t st_uid;
    __gid_t st_gid;

    int __pad0;

    __dev_t st_rdev;




    __off_t st_size;



    __blksize_t st_blksize;

    __blkcnt_t st_blocks;
# 74 "/usr/include/x86_64-linux-gnu/bits/struct_stat.h" 3 4
    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 89 "/usr/include/x86_64-linux-gnu/bits/struct_stat.h" 3 4
    __syscall_slong_t __glibc_reserved[3];
# 99 "/usr/include/x86_64-linux-gnu/bits/struct_stat.h" 3 4
  };



struct stat64
  {



    __dev_t st_dev;

    __ino64_t st_ino;
    __nlink_t st_nlink;
    __mode_t st_mode;






    __uid_t st_uid;
    __gid_t st_gid;

    int __pad0;
    __dev_t st_rdev;
    __off_t st_size;





    __blksize_t st_blksize;
    __blkcnt64_t st_blocks;







    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
# 151 "/usr/include/x86_64-linux-gnu/bits/struct_stat.h" 3 4
    __syscall_slong_t __glibc_reserved[3];




  };
# 26 "/usr/include/x86_64-linux-gnu/bits/stat.h" 2 3 4
# 102 "/usr/include/x86_64-linux-gnu/sys/stat.h" 2 3 4
# 205 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int stat (const char *__restrict __file,
   struct stat *__restrict __buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern int fstat (int __fd, struct stat *__buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 240 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int stat64 (const char *__restrict __file,
     struct stat64 *__restrict __buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int fstat64 (int __fd, struct stat64 *__buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 264 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int fstatat (int __fd, const char *__restrict __file,
      struct stat *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
# 291 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int fstatat64 (int __fd, const char *__restrict __file,
        struct stat64 *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
# 313 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int lstat (const char *__restrict __file,
    struct stat *__restrict __buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
# 338 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int lstat64 (const char *__restrict __file,
      struct stat64 *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
# 352 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int chmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int lchmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




extern int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__ ));





extern int fchmodat (int __fd, const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;






extern __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__ ));




extern __mode_t getumask (void) __attribute__ ((__nothrow__ ));



extern int mkdir (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int mkdirat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));






extern int mknod (const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int mknodat (int __fd, const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));





extern int mkfifo (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int mkfifoat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));






extern int utimensat (int __fd, const char *__path,
        const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 452 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
extern int futimens (int __fd, const struct timespec __times[2]) __attribute__ ((__nothrow__ ));
# 465 "/usr/include/x86_64-linux-gnu/sys/stat.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/statx.h" 1 3 4
# 31 "/usr/include/x86_64-linux-gnu/bits/statx.h" 3 4
# 1 "/usr/include/linux/stat.h" 1 3 4




# 1 "/usr/include/linux/types.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/asm/types.h" 1 3 4
# 1 "/usr/include/asm-generic/types.h" 1 3 4






# 1 "/usr/include/asm-generic/int-ll64.h" 1 3 4
# 12 "/usr/include/asm-generic/int-ll64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/asm/bitsperlong.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/asm/bitsperlong.h" 3 4
# 1 "/usr/include/asm-generic/bitsperlong.h" 1 3 4
# 12 "/usr/include/x86_64-linux-gnu/asm/bitsperlong.h" 2 3 4
# 13 "/usr/include/asm-generic/int-ll64.h" 2 3 4







typedef __signed__ char __s8;
typedef unsigned char __u8;

typedef __signed__ short __s16;
typedef unsigned short __u16;

typedef __signed__ int __s32;
typedef unsigned int __u32;


__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
# 8 "/usr/include/asm-generic/types.h" 2 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/types.h" 2 3 4
# 6 "/usr/include/linux/types.h" 2 3 4



# 1 "/usr/include/linux/posix_types.h" 1 3 4




# 1 "/usr/include/linux/stddef.h" 1 3 4
# 6 "/usr/include/linux/posix_types.h" 2 3 4
# 25 "/usr/include/linux/posix_types.h" 3 4
typedef struct {
 unsigned long fds_bits[1024 / (8 * sizeof(long))];
} __kernel_fd_set;


typedef void (*__kernel_sighandler_t)(int);


typedef int __kernel_key_t;
typedef int __kernel_mqd_t;

# 1 "/usr/include/x86_64-linux-gnu/asm/posix_types.h" 1 3 4






# 1 "/usr/include/x86_64-linux-gnu/asm/posix_types_64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/asm/posix_types_64.h" 3 4
typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;


typedef unsigned long __kernel_old_dev_t;


# 1 "/usr/include/asm-generic/posix_types.h" 1 3 4
# 15 "/usr/include/asm-generic/posix_types.h" 3 4
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;



typedef __kernel_ulong_t __kernel_ino_t;



typedef unsigned int __kernel_mode_t;



typedef int __kernel_pid_t;



typedef int __kernel_ipc_pid_t;



typedef unsigned int __kernel_uid_t;
typedef unsigned int __kernel_gid_t;



typedef __kernel_long_t __kernel_suseconds_t;



typedef int __kernel_daddr_t;



typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
# 72 "/usr/include/asm-generic/posix_types.h" 3 4
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_ptrdiff_t;




typedef struct {
 int val[2];
} __kernel_fsid_t;





typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef __kernel_long_t __kernel_old_time_t;
typedef __kernel_long_t __kernel_time_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef char * __kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
# 19 "/usr/include/x86_64-linux-gnu/asm/posix_types_64.h" 2 3 4
# 8 "/usr/include/x86_64-linux-gnu/asm/posix_types.h" 2 3 4
# 37 "/usr/include/linux/posix_types.h" 2 3 4
# 10 "/usr/include/linux/types.h" 2 3 4


typedef __signed__ __int128 __s128 __attribute__((aligned(16)));
typedef unsigned __int128 __u128 __attribute__((aligned(16)));
# 31 "/usr/include/linux/types.h" 3 4
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u64 __be64;

typedef __u16 __sum16;
typedef __u32 __wsum;
# 55 "/usr/include/linux/types.h" 3 4
typedef unsigned __poll_t;
# 6 "/usr/include/linux/stat.h" 2 3 4
# 56 "/usr/include/linux/stat.h" 3 4
struct statx_timestamp {
 __s64 tv_sec;
 __u32 tv_nsec;
 __s32 __reserved;
};
# 99 "/usr/include/linux/stat.h" 3 4
struct statx {

 __u32 stx_mask;
 __u32 stx_blksize;
 __u64 stx_attributes;

 __u32 stx_nlink;
 __u32 stx_uid;
 __u32 stx_gid;
 __u16 stx_mode;
 __u16 __spare0[1];

 __u64 stx_ino;
 __u64 stx_size;
 __u64 stx_blocks;
 __u64 stx_attributes_mask;

 struct statx_timestamp stx_atime;
 struct statx_timestamp stx_btime;
 struct statx_timestamp stx_ctime;
 struct statx_timestamp stx_mtime;

 __u32 stx_rdev_major;
 __u32 stx_rdev_minor;
 __u32 stx_dev_major;
 __u32 stx_dev_minor;

 __u64 stx_mnt_id;
 __u32 stx_dio_mem_align;
 __u32 stx_dio_offset_align;

 __u64 __spare3[12];

};
# 32 "/usr/include/x86_64-linux-gnu/bits/statx.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/statx-generic.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/statx-generic.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_statx_timestamp.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/statx-generic.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_statx.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/statx-generic.h" 2 3 4
# 61 "/usr/include/x86_64-linux-gnu/bits/statx-generic.h" 3 4
int statx (int __dirfd, const char *__restrict __path, int __flags,
           unsigned int __mask, struct statx *__restrict __buf)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 5)));
# 40 "/usr/include/x86_64-linux-gnu/bits/statx.h" 2 3 4
# 466 "/usr/include/x86_64-linux-gnu/sys/stat.h" 2 3 4
# 65 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 85 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h"
# 1 "/usr/include/unistd.h" 1 3 4
# 202 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix_opt.h" 1 3 4
# 203 "/usr/include/unistd.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/environments.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/environments.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/environments.h" 2 3 4
# 207 "/usr/include/unistd.h" 2 3 4
# 226 "/usr/include/unistd.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 227 "/usr/include/unistd.h" 2 3 4
# 274 "/usr/include/unistd.h" 3 4
typedef __socklen_t socklen_t;
# 287 "/usr/include/unistd.h" 3 4
extern int access (const char *__name, int __type) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




extern int euidaccess (const char *__name, int __type)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int eaccess (const char *__name, int __type)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int execveat (int __fd, const char *__path, char *const __argv[],
                     char *const __envp[], int __flags)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));






extern int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
# 339 "/usr/include/unistd.h" 3 4
extern __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ ));
# 350 "/usr/include/unistd.h" 3 4
extern __off64_t lseek64 (int __fd, __off64_t __offset, int __whence)
     __attribute__ ((__nothrow__ ));






extern int close (int __fd);




extern void closefrom (int __lowfd) __attribute__ ((__nothrow__ ));







extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
                                                  ;





extern ssize_t write (int __fd, const void *__buf, size_t __n)
                                         ;
# 389 "/usr/include/unistd.h" 3 4
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset)
                                                  ;






extern ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset)
                                         ;
# 422 "/usr/include/unistd.h" 3 4
extern ssize_t pread64 (int __fd, void *__buf, size_t __nbytes,
   __off64_t __offset)
                                                  ;


extern ssize_t pwrite64 (int __fd, const void *__buf, size_t __n,
    __off64_t __offset)
                                         ;







extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ )) ;




extern int pipe2 (int __pipedes[2], int __flags) __attribute__ ((__nothrow__ )) ;
# 452 "/usr/include/unistd.h" 3 4
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ ));
# 464 "/usr/include/unistd.h" 3 4
extern unsigned int sleep (unsigned int __seconds);







extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ ));






extern int usleep (__useconds_t __useconds);
# 489 "/usr/include/unistd.h" 3 4
extern int pause (void);



extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;



extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ )) ;




extern int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;






extern int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;



extern int chdir (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;



extern int fchdir (int __fd) __attribute__ ((__nothrow__ )) ;
# 531 "/usr/include/unistd.h" 3 4
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ )) ;





extern char *get_current_dir_name (void) __attribute__ ((__nothrow__ ));







extern char *getwd (char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__))
                                       ;




extern int dup (int __fd) __attribute__ ((__nothrow__ )) ;


extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ ));




extern int dup3 (int __fd, int __fd2, int __flags) __attribute__ ((__nothrow__ ));



extern char **__environ;

extern char **environ;





extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));




extern int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern int execvpe (const char *__file, char *const __argv[],
      char *const __envp[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));





extern int nice (int __inc) __attribute__ ((__nothrow__ )) ;




extern void _exit (int __status) __attribute__ ((__noreturn__));





# 1 "/usr/include/x86_64-linux-gnu/bits/confname.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/confname.h" 3 4
enum
  {
    _PC_LINK_MAX,

    _PC_MAX_CANON,

    _PC_MAX_INPUT,

    _PC_NAME_MAX,

    _PC_PATH_MAX,

    _PC_PIPE_BUF,

    _PC_CHOWN_RESTRICTED,

    _PC_NO_TRUNC,

    _PC_VDISABLE,

    _PC_SYNC_IO,

    _PC_ASYNC_IO,

    _PC_PRIO_IO,

    _PC_SOCK_MAXBUF,

    _PC_FILESIZEBITS,

    _PC_REC_INCR_XFER_SIZE,

    _PC_REC_MAX_XFER_SIZE,

    _PC_REC_MIN_XFER_SIZE,

    _PC_REC_XFER_ALIGN,

    _PC_ALLOC_SIZE_MIN,

    _PC_SYMLINK_MAX,

    _PC_2_SYMLINKS

  };


enum
  {
    _SC_ARG_MAX,

    _SC_CHILD_MAX,

    _SC_CLK_TCK,

    _SC_NGROUPS_MAX,

    _SC_OPEN_MAX,

    _SC_STREAM_MAX,

    _SC_TZNAME_MAX,

    _SC_JOB_CONTROL,

    _SC_SAVED_IDS,

    _SC_REALTIME_SIGNALS,

    _SC_PRIORITY_SCHEDULING,

    _SC_TIMERS,

    _SC_ASYNCHRONOUS_IO,

    _SC_PRIORITIZED_IO,

    _SC_SYNCHRONIZED_IO,

    _SC_FSYNC,

    _SC_MAPPED_FILES,

    _SC_MEMLOCK,

    _SC_MEMLOCK_RANGE,

    _SC_MEMORY_PROTECTION,

    _SC_MESSAGE_PASSING,

    _SC_SEMAPHORES,

    _SC_SHARED_MEMORY_OBJECTS,

    _SC_AIO_LISTIO_MAX,

    _SC_AIO_MAX,

    _SC_AIO_PRIO_DELTA_MAX,

    _SC_DELAYTIMER_MAX,

    _SC_MQ_OPEN_MAX,

    _SC_MQ_PRIO_MAX,

    _SC_VERSION,

    _SC_PAGESIZE,


    _SC_RTSIG_MAX,

    _SC_SEM_NSEMS_MAX,

    _SC_SEM_VALUE_MAX,

    _SC_SIGQUEUE_MAX,

    _SC_TIMER_MAX,




    _SC_BC_BASE_MAX,

    _SC_BC_DIM_MAX,

    _SC_BC_SCALE_MAX,

    _SC_BC_STRING_MAX,

    _SC_COLL_WEIGHTS_MAX,

    _SC_EQUIV_CLASS_MAX,

    _SC_EXPR_NEST_MAX,

    _SC_LINE_MAX,

    _SC_RE_DUP_MAX,

    _SC_CHARCLASS_NAME_MAX,


    _SC_2_VERSION,

    _SC_2_C_BIND,

    _SC_2_C_DEV,

    _SC_2_FORT_DEV,

    _SC_2_FORT_RUN,

    _SC_2_SW_DEV,

    _SC_2_LOCALEDEF,


    _SC_PII,

    _SC_PII_XTI,

    _SC_PII_SOCKET,

    _SC_PII_INTERNET,

    _SC_PII_OSI,

    _SC_POLL,

    _SC_SELECT,

    _SC_UIO_MAXIOV,

    _SC_IOV_MAX = _SC_UIO_MAXIOV,

    _SC_PII_INTERNET_STREAM,

    _SC_PII_INTERNET_DGRAM,

    _SC_PII_OSI_COTS,

    _SC_PII_OSI_CLTS,

    _SC_PII_OSI_M,

    _SC_T_IOV_MAX,



    _SC_THREADS,

    _SC_THREAD_SAFE_FUNCTIONS,

    _SC_GETGR_R_SIZE_MAX,

    _SC_GETPW_R_SIZE_MAX,

    _SC_LOGIN_NAME_MAX,

    _SC_TTY_NAME_MAX,

    _SC_THREAD_DESTRUCTOR_ITERATIONS,

    _SC_THREAD_KEYS_MAX,

    _SC_THREAD_STACK_MIN,

    _SC_THREAD_THREADS_MAX,

    _SC_THREAD_ATTR_STACKADDR,

    _SC_THREAD_ATTR_STACKSIZE,

    _SC_THREAD_PRIORITY_SCHEDULING,

    _SC_THREAD_PRIO_INHERIT,

    _SC_THREAD_PRIO_PROTECT,

    _SC_THREAD_PROCESS_SHARED,


    _SC_NPROCESSORS_CONF,

    _SC_NPROCESSORS_ONLN,

    _SC_PHYS_PAGES,

    _SC_AVPHYS_PAGES,

    _SC_ATEXIT_MAX,

    _SC_PASS_MAX,


    _SC_XOPEN_VERSION,

    _SC_XOPEN_XCU_VERSION,

    _SC_XOPEN_UNIX,

    _SC_XOPEN_CRYPT,

    _SC_XOPEN_ENH_I18N,

    _SC_XOPEN_SHM,


    _SC_2_CHAR_TERM,

    _SC_2_C_VERSION,

    _SC_2_UPE,


    _SC_XOPEN_XPG2,

    _SC_XOPEN_XPG3,

    _SC_XOPEN_XPG4,


    _SC_CHAR_BIT,

    _SC_CHAR_MAX,

    _SC_CHAR_MIN,

    _SC_INT_MAX,

    _SC_INT_MIN,

    _SC_LONG_BIT,

    _SC_WORD_BIT,

    _SC_MB_LEN_MAX,

    _SC_NZERO,

    _SC_SSIZE_MAX,

    _SC_SCHAR_MAX,

    _SC_SCHAR_MIN,

    _SC_SHRT_MAX,

    _SC_SHRT_MIN,

    _SC_UCHAR_MAX,

    _SC_UINT_MAX,

    _SC_ULONG_MAX,

    _SC_USHRT_MAX,


    _SC_NL_ARGMAX,

    _SC_NL_LANGMAX,

    _SC_NL_MSGMAX,

    _SC_NL_NMAX,

    _SC_NL_SETMAX,

    _SC_NL_TEXTMAX,


    _SC_XBS5_ILP32_OFF32,

    _SC_XBS5_ILP32_OFFBIG,

    _SC_XBS5_LP64_OFF64,

    _SC_XBS5_LPBIG_OFFBIG,


    _SC_XOPEN_LEGACY,

    _SC_XOPEN_REALTIME,

    _SC_XOPEN_REALTIME_THREADS,


    _SC_ADVISORY_INFO,

    _SC_BARRIERS,

    _SC_BASE,

    _SC_C_LANG_SUPPORT,

    _SC_C_LANG_SUPPORT_R,

    _SC_CLOCK_SELECTION,

    _SC_CPUTIME,

    _SC_THREAD_CPUTIME,

    _SC_DEVICE_IO,

    _SC_DEVICE_SPECIFIC,

    _SC_DEVICE_SPECIFIC_R,

    _SC_FD_MGMT,

    _SC_FIFO,

    _SC_PIPE,

    _SC_FILE_ATTRIBUTES,

    _SC_FILE_LOCKING,

    _SC_FILE_SYSTEM,

    _SC_MONOTONIC_CLOCK,

    _SC_MULTI_PROCESS,

    _SC_SINGLE_PROCESS,

    _SC_NETWORKING,

    _SC_READER_WRITER_LOCKS,

    _SC_SPIN_LOCKS,

    _SC_REGEXP,

    _SC_REGEX_VERSION,

    _SC_SHELL,

    _SC_SIGNALS,

    _SC_SPAWN,

    _SC_SPORADIC_SERVER,

    _SC_THREAD_SPORADIC_SERVER,

    _SC_SYSTEM_DATABASE,

    _SC_SYSTEM_DATABASE_R,

    _SC_TIMEOUTS,

    _SC_TYPED_MEMORY_OBJECTS,

    _SC_USER_GROUPS,

    _SC_USER_GROUPS_R,

    _SC_2_PBS,

    _SC_2_PBS_ACCOUNTING,

    _SC_2_PBS_LOCATE,

    _SC_2_PBS_MESSAGE,

    _SC_2_PBS_TRACK,

    _SC_SYMLOOP_MAX,

    _SC_STREAMS,

    _SC_2_PBS_CHECKPOINT,


    _SC_V6_ILP32_OFF32,

    _SC_V6_ILP32_OFFBIG,

    _SC_V6_LP64_OFF64,

    _SC_V6_LPBIG_OFFBIG,


    _SC_HOST_NAME_MAX,

    _SC_TRACE,

    _SC_TRACE_EVENT_FILTER,

    _SC_TRACE_INHERIT,

    _SC_TRACE_LOG,


    _SC_LEVEL1_ICACHE_SIZE,

    _SC_LEVEL1_ICACHE_ASSOC,

    _SC_LEVEL1_ICACHE_LINESIZE,

    _SC_LEVEL1_DCACHE_SIZE,

    _SC_LEVEL1_DCACHE_ASSOC,

    _SC_LEVEL1_DCACHE_LINESIZE,

    _SC_LEVEL2_CACHE_SIZE,

    _SC_LEVEL2_CACHE_ASSOC,

    _SC_LEVEL2_CACHE_LINESIZE,

    _SC_LEVEL3_CACHE_SIZE,

    _SC_LEVEL3_CACHE_ASSOC,

    _SC_LEVEL3_CACHE_LINESIZE,

    _SC_LEVEL4_CACHE_SIZE,

    _SC_LEVEL4_CACHE_ASSOC,

    _SC_LEVEL4_CACHE_LINESIZE,



    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,

    _SC_RAW_SOCKETS,


    _SC_V7_ILP32_OFF32,

    _SC_V7_ILP32_OFFBIG,

    _SC_V7_LP64_OFF64,

    _SC_V7_LPBIG_OFFBIG,


    _SC_SS_REPL_MAX,


    _SC_TRACE_EVENT_NAME_MAX,

    _SC_TRACE_NAME_MAX,

    _SC_TRACE_SYS_MAX,

    _SC_TRACE_USER_EVENT_MAX,


    _SC_XOPEN_STREAMS,


    _SC_THREAD_ROBUST_PRIO_INHERIT,

    _SC_THREAD_ROBUST_PRIO_PROTECT,


    _SC_MINSIGSTKSZ,


    _SC_SIGSTKSZ

  };


enum
  {
    _CS_PATH,


    _CS_V6_WIDTH_RESTRICTED_ENVS,



    _CS_GNU_LIBC_VERSION,

    _CS_GNU_LIBPTHREAD_VERSION,


    _CS_V5_WIDTH_RESTRICTED_ENVS,



    _CS_V7_WIDTH_RESTRICTED_ENVS,



    _CS_LFS_CFLAGS = 1000,

    _CS_LFS_LDFLAGS,

    _CS_LFS_LIBS,

    _CS_LFS_LINTFLAGS,

    _CS_LFS64_CFLAGS,

    _CS_LFS64_LDFLAGS,

    _CS_LFS64_LIBS,

    _CS_LFS64_LINTFLAGS,


    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,

    _CS_XBS5_ILP32_OFF32_LDFLAGS,

    _CS_XBS5_ILP32_OFF32_LIBS,

    _CS_XBS5_ILP32_OFF32_LINTFLAGS,

    _CS_XBS5_ILP32_OFFBIG_CFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,

    _CS_XBS5_ILP32_OFFBIG_LIBS,

    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,

    _CS_XBS5_LP64_OFF64_CFLAGS,

    _CS_XBS5_LP64_OFF64_LDFLAGS,

    _CS_XBS5_LP64_OFF64_LIBS,

    _CS_XBS5_LP64_OFF64_LINTFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,

    _CS_XBS5_LPBIG_OFFBIG_LIBS,

    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFF32_LIBS,

    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V6_LP64_OFF64_CFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V6_LP64_OFF64_LIBS,

    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,


    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFF32_LIBS,

    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,

    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,

    _CS_POSIX_V7_LP64_OFF64_CFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,

    _CS_POSIX_V7_LP64_OFF64_LIBS,

    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,

    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,


    _CS_V6_ENV,

    _CS_V7_ENV

  };
# 631 "/usr/include/unistd.h" 2 3 4


extern long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ ));


extern long int sysconf (int __name) __attribute__ ((__nothrow__ ));



extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ ))
                                                  ;




extern __pid_t getpid (void) __attribute__ ((__nothrow__ ));


extern __pid_t getppid (void) __attribute__ ((__nothrow__ ));


extern __pid_t getpgrp (void) __attribute__ ((__nothrow__ ));


extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ ));

extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ ));






extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ ));
# 682 "/usr/include/unistd.h" 3 4
extern int setpgrp (void) __attribute__ ((__nothrow__ ));






extern __pid_t setsid (void) __attribute__ ((__nothrow__ ));



extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ ));



extern __uid_t getuid (void) __attribute__ ((__nothrow__ ));


extern __uid_t geteuid (void) __attribute__ ((__nothrow__ ));


extern __gid_t getgid (void) __attribute__ ((__nothrow__ ));


extern __gid_t getegid (void) __attribute__ ((__nothrow__ ));




extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ ))
                                                  ;


extern int group_member (__gid_t __gid) __attribute__ ((__nothrow__ ));






extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__ )) ;




extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ )) ;




extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ )) ;






extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__ )) ;




extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ )) ;




extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__ )) ;





extern int getresuid (__uid_t *__ruid, __uid_t *__euid, __uid_t *__suid)
     __attribute__ ((__nothrow__ ));



extern int getresgid (__gid_t *__rgid, __gid_t *__egid, __gid_t *__sgid)
     __attribute__ ((__nothrow__ ));



extern int setresuid (__uid_t __ruid, __uid_t __euid, __uid_t __suid)
     __attribute__ ((__nothrow__ )) ;



extern int setresgid (__gid_t __rgid, __gid_t __egid, __gid_t __sgid)
     __attribute__ ((__nothrow__ )) ;






extern __pid_t fork (void) __attribute__ ((__nothrow__));







extern __pid_t vfork (void) __attribute__ ((__nothrow__ ));






extern __pid_t _Fork (void) __attribute__ ((__nothrow__ ));





extern char *ttyname (int __fd) __attribute__ ((__nothrow__ ));



extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                                   ;



extern int isatty (int __fd) __attribute__ ((__nothrow__ ));




extern int ttyslot (void) __attribute__ ((__nothrow__ ));




extern int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;




extern int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4))) ;




extern int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;




extern ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)))
                                                   ;





extern int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3))) ;


extern ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)))
                                                   ;



extern int unlink (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));



extern int rmdir (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ ));


extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ ));






extern char *getlogin (void);







extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)))
                                                  ;




extern int setlogin (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







# 1 "/usr/include/x86_64-linux-gnu/bits/getopt_posix.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/getopt_posix.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/getopt_core.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/getopt_core.h" 3 4
extern char *optarg;
# 50 "/usr/include/x86_64-linux-gnu/bits/getopt_core.h" 3 4
extern int optind;




extern int opterr;



extern int optopt;
# 91 "/usr/include/x86_64-linux-gnu/bits/getopt_core.h" 3 4
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
# 28 "/usr/include/x86_64-linux-gnu/bits/getopt_posix.h" 2 3 4
# 904 "/usr/include/unistd.h" 2 3 4







extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;






extern int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;



extern int sethostid (long int __id) __attribute__ ((__nothrow__ )) ;





extern int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                   ;
extern int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;




extern int vhangup (void) __attribute__ ((__nothrow__ ));


extern int revoke (const char *__file) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;







extern int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int acct (const char *__name) __attribute__ ((__nothrow__ ));



extern char *getusershell (void) __attribute__ ((__nothrow__ ));
extern void endusershell (void) __attribute__ ((__nothrow__ ));
extern void setusershell (void) __attribute__ ((__nothrow__ ));





extern int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ )) ;






extern int chroot (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;



extern char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));







extern int fsync (int __fd);





extern int syncfs (int __fd) __attribute__ ((__nothrow__ ));






extern long int gethostid (void);


extern void sync (void) __attribute__ ((__nothrow__ ));





extern int getpagesize (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern int getdtablesize (void) __attribute__ ((__nothrow__ ));
# 1026 "/usr/include/unistd.h" 3 4
extern int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 1038 "/usr/include/unistd.h" 3 4
extern int truncate64 (const char *__file, __off64_t __length)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 1049 "/usr/include/unistd.h" 3 4
extern int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ )) ;
# 1059 "/usr/include/unistd.h" 3 4
extern int ftruncate64 (int __fd, __off64_t __length) __attribute__ ((__nothrow__ )) ;
# 1070 "/usr/include/unistd.h" 3 4
extern int brk (void *__addr) __attribute__ ((__nothrow__ )) ;





extern void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ ));
# 1091 "/usr/include/unistd.h" 3 4
extern long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ ));
# 1114 "/usr/include/unistd.h" 3 4
extern int lockf (int __fd, int __cmd, __off_t __len) ;
# 1124 "/usr/include/unistd.h" 3 4
extern int lockf64 (int __fd, int __cmd, __off64_t __len) ;
# 1142 "/usr/include/unistd.h" 3 4
ssize_t copy_file_range (int __infd, __off64_t *__pinoff,
    int __outfd, __off64_t *__poutoff,
    size_t __length, unsigned int __flags);





extern int fdatasync (int __fildes);
# 1162 "/usr/include/unistd.h" 3 4
extern char *crypt (const char *__key, const char *__salt)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));







extern void swab (const void *__restrict __from, void *__restrict __to,
    ssize_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)))

                                          ;
# 1201 "/usr/include/unistd.h" 3 4
int getentropy (void *__buffer, size_t __length)
                                          ;
# 1211 "/usr/include/unistd.h" 3 4
extern int close_range (unsigned int __fd, unsigned int __max_fd,
   int __flags) __attribute__ ((__nothrow__ ));
# 1221 "/usr/include/unistd.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 1 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 3 4
extern __pid_t gettid (void) __attribute__ ((__nothrow__ ));



# 1 "/usr/include/linux/close_range.h" 1 3 4
# 39 "/usr/include/x86_64-linux-gnu/bits/unistd_ext.h" 2 3 4
# 1222 "/usr/include/unistd.h" 2 3 4
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2


# 1 "/usr/include/pthread.h" 1 3 4
# 22 "/usr/include/pthread.h" 3 4
# 1 "/usr/include/sched.h" 1 3 4
# 29 "/usr/include/sched.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 30 "/usr/include/sched.h" 2 3 4
# 43 "/usr/include/sched.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/sched.h" 1 3 4
# 80 "/usr/include/x86_64-linux-gnu/bits/sched.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_sched_param.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/types/struct_sched_param.h" 3 4
struct sched_param
{
  int sched_priority;
};
# 81 "/usr/include/x86_64-linux-gnu/bits/sched.h" 2 3 4





extern int clone (int (*__fn) (void *__arg), void *__child_stack,
    int __flags, void *__arg, ...) __attribute__ ((__nothrow__ ));


extern int unshare (int __flags) __attribute__ ((__nothrow__ ));


extern int sched_getcpu (void) __attribute__ ((__nothrow__ ));


extern int getcpu (unsigned int *, unsigned int *) __attribute__ ((__nothrow__ ));


extern int setns (int __fd, int __nstype) __attribute__ ((__nothrow__ ));
# 44 "/usr/include/sched.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/cpu-set.h" 1 3 4
# 32 "/usr/include/x86_64-linux-gnu/bits/cpu-set.h" 3 4
typedef unsigned long int __cpu_mask;






typedef struct
{
  __cpu_mask __bits[1024 / (8 * sizeof (__cpu_mask))];
} cpu_set_t;
# 117 "/usr/include/x86_64-linux-gnu/bits/cpu-set.h" 3 4
extern int __sched_cpucount (size_t __setsize, const cpu_set_t *__setp)
     __attribute__ ((__nothrow__ ));
extern cpu_set_t *__sched_cpualloc (size_t __count) __attribute__ ((__nothrow__ )) ;
extern void __sched_cpufree (cpu_set_t *__set) __attribute__ ((__nothrow__ ));
# 45 "/usr/include/sched.h" 2 3 4
# 54 "/usr/include/sched.h" 3 4
extern int sched_setparam (__pid_t __pid, const struct sched_param *__param)
     __attribute__ ((__nothrow__ ));


extern int sched_getparam (__pid_t __pid, struct sched_param *__param) __attribute__ ((__nothrow__ ));


extern int sched_setscheduler (__pid_t __pid, int __policy,
          const struct sched_param *__param) __attribute__ ((__nothrow__ ));


extern int sched_getscheduler (__pid_t __pid) __attribute__ ((__nothrow__ ));


extern int sched_yield (void) __attribute__ ((__nothrow__ ));


extern int sched_get_priority_max (int __algorithm) __attribute__ ((__nothrow__ ));


extern int sched_get_priority_min (int __algorithm) __attribute__ ((__nothrow__ ));



extern int sched_rr_get_interval (__pid_t __pid, struct timespec *__t) __attribute__ ((__nothrow__ ));
# 130 "/usr/include/sched.h" 3 4
extern int sched_setaffinity (__pid_t __pid, size_t __cpusetsize,
         const cpu_set_t *__cpuset) __attribute__ ((__nothrow__ ));


extern int sched_getaffinity (__pid_t __pid, size_t __cpusetsize,
         cpu_set_t *__cpuset) __attribute__ ((__nothrow__ ));
# 23 "/usr/include/pthread.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/setjmp.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/setjmp.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/setjmp.h" 2 3 4




typedef long int __jmp_buf[8];
# 28 "/usr/include/pthread.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 29 "/usr/include/pthread.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct___jmp_buf_tag.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/types/struct___jmp_buf_tag.h" 3 4
struct __jmp_buf_tag
  {




    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };
# 32 "/usr/include/pthread.h" 2 3 4





enum
{
  PTHREAD_CREATE_JOINABLE,

  PTHREAD_CREATE_DETACHED

};



enum
{
  PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_ADAPTIVE_NP

  ,
  PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL



  , PTHREAD_MUTEX_FAST_NP = PTHREAD_MUTEX_TIMED_NP

};




enum
{
  PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_STALLED_NP = PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_ROBUST,
  PTHREAD_MUTEX_ROBUST_NP = PTHREAD_MUTEX_ROBUST
};





enum
{
  PTHREAD_PRIO_NONE,
  PTHREAD_PRIO_INHERIT,
  PTHREAD_PRIO_PROTECT
};
# 104 "/usr/include/pthread.h" 3 4
enum
{
  PTHREAD_RWLOCK_PREFER_READER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP,
  PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_READER_NP
};
# 124 "/usr/include/pthread.h" 3 4
enum
{
  PTHREAD_INHERIT_SCHED,

  PTHREAD_EXPLICIT_SCHED

};



enum
{
  PTHREAD_SCOPE_SYSTEM,

  PTHREAD_SCOPE_PROCESS

};



enum
{
  PTHREAD_PROCESS_PRIVATE,

  PTHREAD_PROCESS_SHARED

};
# 159 "/usr/include/pthread.h" 3 4
struct _pthread_cleanup_buffer
{
  void (*__routine) (void *);
  void *__arg;
  int __canceltype;
  struct _pthread_cleanup_buffer *__prev;
};


enum
{
  PTHREAD_CANCEL_ENABLE,

  PTHREAD_CANCEL_DISABLE

};
enum
{
  PTHREAD_CANCEL_DEFERRED,

  PTHREAD_CANCEL_ASYNCHRONOUS

};
# 202 "/usr/include/pthread.h" 3 4
extern int pthread_create (pthread_t *__restrict __newthread,
      const pthread_attr_t *__restrict __attr,
      void *(*__start_routine) (void *),
      void *__restrict __arg) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));





extern void pthread_exit (void *__retval) __attribute__ ((__noreturn__));







extern int pthread_join (pthread_t __th, void **__thread_return);




extern int pthread_tryjoin_np (pthread_t __th, void **__thread_return) __attribute__ ((__nothrow__ ));
# 233 "/usr/include/pthread.h" 3 4
extern int pthread_timedjoin_np (pthread_t __th, void **__thread_return,
     const struct timespec *__abstime);
# 243 "/usr/include/pthread.h" 3 4
extern int pthread_clockjoin_np (pthread_t __th, void **__thread_return,
                                 clockid_t __clockid,
     const struct timespec *__abstime);
# 269 "/usr/include/pthread.h" 3 4
extern int pthread_detach (pthread_t __th) __attribute__ ((__nothrow__ ));



extern pthread_t pthread_self (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern int pthread_equal (pthread_t __thread1, pthread_t __thread2)
  __attribute__ ((__nothrow__ )) __attribute__ ((__const__));







extern int pthread_attr_init (pthread_attr_t *__attr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_destroy (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getdetachstate (const pthread_attr_t *__attr,
     int *__detachstate)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setdetachstate (pthread_attr_t *__attr,
     int __detachstate)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getguardsize (const pthread_attr_t *__attr,
          size_t *__guardsize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setguardsize (pthread_attr_t *__attr,
          size_t __guardsize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getschedparam (const pthread_attr_t *__restrict __attr,
           struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setschedparam (pthread_attr_t *__restrict __attr,
           const struct sched_param *__restrict
           __param) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_getschedpolicy (const pthread_attr_t *__restrict
     __attr, int *__restrict __policy)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setschedpolicy (pthread_attr_t *__attr, int __policy)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getinheritsched (const pthread_attr_t *__restrict
      __attr, int *__restrict __inherit)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setinheritsched (pthread_attr_t *__attr,
      int __inherit)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getscope (const pthread_attr_t *__restrict __attr,
      int *__restrict __scope)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_attr_setscope (pthread_attr_t *__attr, int __scope)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_getstackaddr (const pthread_attr_t *__restrict
          __attr, void **__restrict __stackaddr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__deprecated__));





extern int pthread_attr_setstackaddr (pthread_attr_t *__attr,
          void *__stackaddr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__));


extern int pthread_attr_getstacksize (const pthread_attr_t *__restrict
          __attr, size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern int pthread_attr_setstacksize (pthread_attr_t *__attr,
          size_t __stacksize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_attr_getstack (const pthread_attr_t *__restrict __attr,
      void **__restrict __stackaddr,
      size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3)));




extern int pthread_attr_setstack (pthread_attr_t *__attr, void *__stackaddr,
      size_t __stacksize) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int pthread_attr_setaffinity_np (pthread_attr_t *__attr,
     size_t __cpusetsize,
     const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));



extern int pthread_attr_getaffinity_np (const pthread_attr_t *__attr,
     size_t __cpusetsize,
     cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));


extern int pthread_getattr_default_np (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_attr_setsigmask_np (pthread_attr_t *__attr,
           const __sigset_t *sigmask);




extern int pthread_attr_getsigmask_np (const pthread_attr_t *__attr,
           __sigset_t *sigmask);







extern int pthread_setattr_default_np (const pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




extern int pthread_getattr_np (pthread_t __th, pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));







extern int pthread_setschedparam (pthread_t __target_thread, int __policy,
      const struct sched_param *__param)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));


extern int pthread_getschedparam (pthread_t __target_thread,
      int *__restrict __policy,
      struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));


extern int pthread_setschedprio (pthread_t __target_thread, int __prio)
     __attribute__ ((__nothrow__ ));




extern int pthread_getname_np (pthread_t __target_thread, char *__buf,
          size_t __buflen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));


extern int pthread_setname_np (pthread_t __target_thread, const char *__name)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));





extern int pthread_getconcurrency (void) __attribute__ ((__nothrow__ ));


extern int pthread_setconcurrency (int __level) __attribute__ ((__nothrow__ ));



extern int pthread_yield (void) __attribute__ ((__nothrow__ ));

extern int pthread_yield (void) __asm__ ("" "sched_yield") __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("pthread_yield is deprecated, use sched_yield instead")));
# 489 "/usr/include/pthread.h" 3 4
extern int pthread_setaffinity_np (pthread_t __th, size_t __cpusetsize,
       const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));


extern int pthread_getaffinity_np (pthread_t __th, size_t __cpusetsize,
       cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));
# 509 "/usr/include/pthread.h" 3 4
extern int pthread_once (pthread_once_t *__once_control,
    void (*__init_routine) (void)) __attribute__ ((__nonnull__ (1, 2)));
# 521 "/usr/include/pthread.h" 3 4
extern int pthread_setcancelstate (int __state, int *__oldstate);



extern int pthread_setcanceltype (int __type, int *__oldtype);


extern int pthread_cancel (pthread_t __th);




extern void pthread_testcancel (void);




struct __cancel_jmp_buf_tag
{
  __jmp_buf __cancel_jmp_buf;
  int __mask_was_saved;
};

typedef struct
{
  struct __cancel_jmp_buf_tag __cancel_jmp_buf[1];
  void *__pad[4];
} __pthread_unwind_buf_t __attribute__ ((__aligned__));
# 557 "/usr/include/pthread.h" 3 4
struct __pthread_cleanup_frame
{
  void (*__cancel_routine) (void *);
  void *__cancel_arg;
  int __do_it;
  int __cancel_type;
};
# 697 "/usr/include/pthread.h" 3 4
extern void __pthread_register_cancel (__pthread_unwind_buf_t *__buf)
                            ;
# 709 "/usr/include/pthread.h" 3 4
extern void __pthread_unregister_cancel (__pthread_unwind_buf_t *__buf)
                         ;
# 732 "/usr/include/pthread.h" 3 4
extern void __pthread_register_cancel_defer (__pthread_unwind_buf_t *__buf)
                            ;
# 745 "/usr/include/pthread.h" 3 4
extern void __pthread_unregister_cancel_restore (__pthread_unwind_buf_t *__buf)
                         ;



extern void __pthread_unwind_next (__pthread_unwind_buf_t *__buf)
                             __attribute__ ((__noreturn__))

     __attribute__ ((__weak__))

     ;
# 773 "/usr/include/pthread.h" 3 4
extern int __sigsetjmp (struct __jmp_buf_tag __env[1],
   int __savemask) __attribute__ ((__nothrow__));






extern int pthread_mutex_init (pthread_mutex_t *__mutex,
          const pthread_mutexattr_t *__mutexattr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_destroy (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_trylock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_lock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_mutex_timedlock (pthread_mutex_t *__restrict __mutex,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 817 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_clocklock (pthread_mutex_t *__restrict __mutex,
        clockid_t __clockid,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 835 "/usr/include/pthread.h" 3 4
extern int pthread_mutex_unlock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutex_getprioceiling (const pthread_mutex_t *
      __restrict __mutex,
      int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern int pthread_mutex_setprioceiling (pthread_mutex_t *__restrict __mutex,
      int __prioceiling,
      int *__restrict __old_ceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));




extern int pthread_mutex_consistent (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutex_consistent_np (pthread_mutex_t *) __asm__ ("" "pthread_mutex_consistent") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))

  __attribute__ ((__deprecated__ ("pthread_mutex_consistent_np is deprecated, use pthread_mutex_consistent")));
# 874 "/usr/include/pthread.h" 3 4
extern int pthread_mutexattr_init (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_destroy (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_getpshared (const pthread_mutexattr_t *
      __restrict __attr,
      int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_setpshared (pthread_mutexattr_t *__attr,
      int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_gettype (const pthread_mutexattr_t *__restrict
          __attr, int *__restrict __kind)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_getprotocol (const pthread_mutexattr_t *
       __restrict __attr,
       int *__restrict __protocol)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern int pthread_mutexattr_setprotocol (pthread_mutexattr_t *__attr,
       int __protocol)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_getprioceiling (const pthread_mutexattr_t *
          __restrict __attr,
          int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_setprioceiling (pthread_mutexattr_t *__attr,
          int __prioceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_mutexattr_getrobust (const pthread_mutexattr_t *__attr,
     int *__robustness)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_mutexattr_getrobust_np (pthread_mutexattr_t *, int *) __asm__ ("" "pthread_mutexattr_getrobust") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))


  __attribute__ ((__deprecated__ ("pthread_mutexattr_getrobust_np is deprecated, use pthread_mutexattr_getrobust")));







extern int pthread_mutexattr_setrobust (pthread_mutexattr_t *__attr,
     int __robustness)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_mutexattr_setrobust_np (pthread_mutexattr_t *, int) __asm__ ("" "pthread_mutexattr_setrobust") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))


  __attribute__ ((__deprecated__ ("pthread_mutexattr_setrobust_np is deprecated, use pthread_mutexattr_setrobust")));
# 967 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_init (pthread_rwlock_t *__restrict __rwlock,
    const pthread_rwlockattr_t *__restrict
    __attr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_destroy (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_rdlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_tryrdlock (pthread_rwlock_t *__rwlock)
  __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_rwlock_timedrdlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 1004 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_clockrdlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 1023 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_wrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlock_trywrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));




extern int pthread_rwlock_timedwrlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
# 1051 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_clockwrlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
# 1071 "/usr/include/pthread.h" 3 4
extern int pthread_rwlock_unlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));





extern int pthread_rwlockattr_init (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_destroy (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_getpshared (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_rwlockattr_setpshared (pthread_rwlockattr_t *__attr,
       int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_rwlockattr_getkind_np (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pref)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_rwlockattr_setkind_np (pthread_rwlockattr_t *__attr,
       int __pref) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







extern int pthread_cond_init (pthread_cond_t *__restrict __cond,
         const pthread_condattr_t *__restrict __cond_attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_destroy (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_signal (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_cond_broadcast (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int pthread_cond_wait (pthread_cond_t *__restrict __cond,
         pthread_mutex_t *__restrict __mutex)
     __attribute__ ((__nonnull__ (1, 2)));
# 1145 "/usr/include/pthread.h" 3 4
extern int pthread_cond_timedwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 3)));
# 1171 "/usr/include/pthread.h" 3 4
extern int pthread_cond_clockwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       __clockid_t __clock_id,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 4)));
# 1194 "/usr/include/pthread.h" 3 4
extern int pthread_condattr_init (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_condattr_destroy (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_condattr_getpshared (const pthread_condattr_t *
     __restrict __attr,
     int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_condattr_setpshared (pthread_condattr_t *__attr,
     int __pshared) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int pthread_condattr_getclock (const pthread_condattr_t *
          __restrict __attr,
          __clockid_t *__restrict __clock_id)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_condattr_setclock (pthread_condattr_t *__attr,
          __clockid_t __clock_id)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 1230 "/usr/include/pthread.h" 3 4
extern int pthread_spin_init (pthread_spinlock_t *__lock, int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_destroy (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_lock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_trylock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));


extern int pthread_spin_unlock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));






extern int pthread_barrier_init (pthread_barrier_t *__restrict __barrier,
     const pthread_barrierattr_t *__restrict
     __attr, unsigned int __count)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrier_destroy (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrier_wait (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));



extern int pthread_barrierattr_init (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrierattr_destroy (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_barrierattr_getpshared (const pthread_barrierattr_t *
        __restrict __attr,
        int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int pthread_barrierattr_setpshared (pthread_barrierattr_t *__attr,
        int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 1297 "/usr/include/pthread.h" 3 4
extern int pthread_key_create (pthread_key_t *__key,
          void (*__destr_function) (void *))
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int pthread_key_delete (pthread_key_t __key) __attribute__ ((__nothrow__ ));


extern void *pthread_getspecific (pthread_key_t __key) __attribute__ ((__nothrow__ ));


extern int pthread_setspecific (pthread_key_t __key,
    const void *__pointer)
  __attribute__ ((__nothrow__ )) ;




extern int pthread_getcpuclockid (pthread_t __thread_id,
      __clockid_t *__clock_id)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 1332 "/usr/include/pthread.h" 3 4
extern int pthread_atfork (void (*__prepare) (void),
      void (*__parent) (void),
      void (*__child) (void)) __attribute__ ((__nothrow__ ));
# 89 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 101 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h"
# 1 "/usr/include/arpa/inet.h" 1 3 4
# 22 "/usr/include/arpa/inet.h" 3 4
# 1 "/usr/include/netinet/in.h" 1 3 4
# 23 "/usr/include/netinet/in.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/socket.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/types/struct_iovec.h" 2 3 4


struct iovec
  {
    void *iov_base;
    size_t iov_len;
  };
# 27 "/usr/include/x86_64-linux-gnu/sys/socket.h" 2 3 4

# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/sys/socket.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/socket.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/socket.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/socket.h" 2 3 4
# 38 "/usr/include/x86_64-linux-gnu/bits/socket.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/socket_type.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/socket_type.h" 3 4
enum __socket_type
{
  SOCK_STREAM = 1,


  SOCK_DGRAM = 2,


  SOCK_RAW = 3,

  SOCK_RDM = 4,

  SOCK_SEQPACKET = 5,


  SOCK_DCCP = 6,

  SOCK_PACKET = 10,







  SOCK_CLOEXEC = 02000000,


  SOCK_NONBLOCK = 00004000


};
# 39 "/usr/include/x86_64-linux-gnu/bits/socket.h" 2 3 4
# 180 "/usr/include/x86_64-linux-gnu/bits/socket.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/sockaddr.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/sockaddr.h" 3 4
typedef unsigned short int sa_family_t;
# 181 "/usr/include/x86_64-linux-gnu/bits/socket.h" 2 3 4


struct sockaddr
  {
    sa_family_t sa_family;
    char sa_data[14];
  };
# 196 "/usr/include/x86_64-linux-gnu/bits/socket.h" 3 4
struct sockaddr_storage
  {
    sa_family_t ss_family;
    char __ss_padding[(128 - (sizeof (unsigned short int)) - sizeof (unsigned long int))];
    unsigned long int __ss_align;
  };



enum
  {
    MSG_OOB = 0x01,

    MSG_PEEK = 0x02,

    MSG_DONTROUTE = 0x04,



    MSG_TRYHARD = MSG_DONTROUTE,


    MSG_CTRUNC = 0x08,

    MSG_PROXY = 0x10,

    MSG_TRUNC = 0x20,

    MSG_DONTWAIT = 0x40,

    MSG_EOR = 0x80,

    MSG_WAITALL = 0x100,

    MSG_FIN = 0x200,

    MSG_SYN = 0x400,

    MSG_CONFIRM = 0x800,

    MSG_RST = 0x1000,

    MSG_ERRQUEUE = 0x2000,

    MSG_NOSIGNAL = 0x4000,

    MSG_MORE = 0x8000,

    MSG_WAITFORONE = 0x10000,

    MSG_BATCH = 0x40000,

    MSG_ZEROCOPY = 0x4000000,

    MSG_FASTOPEN = 0x20000000,


    MSG_CMSG_CLOEXEC = 0x40000000



  };




struct msghdr
  {
    void *msg_name;
    socklen_t msg_namelen;

    struct iovec *msg_iov;
    size_t msg_iovlen;

    void *msg_control;
    size_t msg_controllen;




    int msg_flags;
  };


struct cmsghdr
  {
    size_t cmsg_len;




    int cmsg_level;
    int cmsg_type;

    __extension__ unsigned char __cmsg_data [];

  };
# 316 "/usr/include/x86_64-linux-gnu/bits/socket.h" 3 4
extern struct cmsghdr *__cmsg_nxthdr (struct msghdr *__mhdr,
          struct cmsghdr *__cmsg) __attribute__ ((__nothrow__ ));
# 363 "/usr/include/x86_64-linux-gnu/bits/socket.h" 3 4
enum
  {
    SCM_RIGHTS = 0x01


    , SCM_CREDENTIALS = 0x02

    , SCM_SECURITY = 0x03

    , SCM_PIDFD = 0x04


  };



struct ucred
{
  pid_t pid;
  uid_t uid;
  gid_t gid;
};




# 1 "/usr/include/x86_64-linux-gnu/asm/socket.h" 1 3 4
# 1 "/usr/include/asm-generic/socket.h" 1 3 4





# 1 "/usr/include/x86_64-linux-gnu/asm/sockios.h" 1 3 4
# 1 "/usr/include/asm-generic/sockios.h" 1 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/sockios.h" 2 3 4
# 7 "/usr/include/asm-generic/socket.h" 2 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/socket.h" 2 3 4
# 390 "/usr/include/x86_64-linux-gnu/bits/socket.h" 2 3 4






struct linger
  {
    int l_onoff;
    int l_linger;
  };
# 34 "/usr/include/x86_64-linux-gnu/sys/socket.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_osockaddr.h" 1 3 4





struct osockaddr
{
  unsigned short int sa_family;
  unsigned char sa_data[14];
};
# 37 "/usr/include/x86_64-linux-gnu/sys/socket.h" 2 3 4




enum
{
  SHUT_RD = 0,

  SHUT_WR,

  SHUT_RDWR

};
# 79 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
typedef union { struct sockaddr *__restrict __sockaddr__; struct sockaddr_at *__restrict __sockaddr_at__; struct sockaddr_ax25 *__restrict __sockaddr_ax25__; struct sockaddr_dl *__restrict __sockaddr_dl__; struct sockaddr_eon *__restrict __sockaddr_eon__; struct sockaddr_in *__restrict __sockaddr_in__; struct sockaddr_in6 *__restrict __sockaddr_in6__; struct sockaddr_inarp *__restrict __sockaddr_inarp__; struct sockaddr_ipx *__restrict __sockaddr_ipx__; struct sockaddr_iso *__restrict __sockaddr_iso__; struct sockaddr_ns *__restrict __sockaddr_ns__; struct sockaddr_un *__restrict __sockaddr_un__; struct sockaddr_x25 *__restrict __sockaddr_x25__;
       } __SOCKADDR_ARG __attribute__ ((__transparent_union__));


typedef union { const struct sockaddr *__restrict __sockaddr__; const struct sockaddr_at *__restrict __sockaddr_at__; const struct sockaddr_ax25 *__restrict __sockaddr_ax25__; const struct sockaddr_dl *__restrict __sockaddr_dl__; const struct sockaddr_eon *__restrict __sockaddr_eon__; const struct sockaddr_in *__restrict __sockaddr_in__; const struct sockaddr_in6 *__restrict __sockaddr_in6__; const struct sockaddr_inarp *__restrict __sockaddr_inarp__; const struct sockaddr_ipx *__restrict __sockaddr_ipx__; const struct sockaddr_iso *__restrict __sockaddr_iso__; const struct sockaddr_ns *__restrict __sockaddr_ns__; const struct sockaddr_un *__restrict __sockaddr_un__; const struct sockaddr_x25 *__restrict __sockaddr_x25__;
       } __CONST_SOCKADDR_ARG __attribute__ ((__transparent_union__));





struct mmsghdr
  {
    struct msghdr msg_hdr;
    unsigned int msg_len;

  };






extern int socket (int __domain, int __type, int __protocol) __attribute__ ((__nothrow__ ));





extern int socketpair (int __domain, int __type, int __protocol,
         int __fds[2]) __attribute__ ((__nothrow__ ));


extern int bind (int __fd, __CONST_SOCKADDR_ARG __addr, socklen_t __len)
     __attribute__ ((__nothrow__ ));


extern int getsockname (int __fd, __SOCKADDR_ARG __addr,
   socklen_t *__restrict __len) __attribute__ ((__nothrow__ ));
# 126 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int connect (int __fd, __CONST_SOCKADDR_ARG __addr, socklen_t __len);



extern int getpeername (int __fd, __SOCKADDR_ARG __addr,
   socklen_t *__restrict __len) __attribute__ ((__nothrow__ ));






extern ssize_t send (int __fd, const void *__buf, size_t __n, int __flags);






extern ssize_t recv (int __fd, void *__buf, size_t __n, int __flags);






extern ssize_t sendto (int __fd, const void *__buf, size_t __n,
         int __flags, __CONST_SOCKADDR_ARG __addr,
         socklen_t __addr_len);
# 163 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern ssize_t recvfrom (int __fd, void *__restrict __buf, size_t __n,
    int __flags, __SOCKADDR_ARG __addr,
    socklen_t *__restrict __addr_len);
# 174 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern ssize_t sendmsg (int __fd, const struct msghdr *__message,
   int __flags);
# 195 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int sendmmsg (int __fd, struct mmsghdr *__vmessages,
       unsigned int __vlen, int __flags);
# 216 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern ssize_t recvmsg (int __fd, struct msghdr *__message, int __flags);
# 235 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int recvmmsg (int __fd, struct mmsghdr *__vmessages,
       unsigned int __vlen, int __flags,
       struct timespec *__tmo);
# 255 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int getsockopt (int __fd, int __level, int __optname,
         void *__restrict __optval,
         socklen_t *__restrict __optlen) __attribute__ ((__nothrow__ ));
# 277 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int setsockopt (int __fd, int __level, int __optname,
         const void *__optval, socklen_t __optlen) __attribute__ ((__nothrow__ ));
# 296 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int listen (int __fd, int __n) __attribute__ ((__nothrow__ ));
# 306 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int accept (int __fd, __SOCKADDR_ARG __addr,
     socklen_t *__restrict __addr_len);






extern int accept4 (int __fd, __SOCKADDR_ARG __addr,
      socklen_t *__restrict __addr_len, int __flags);
# 324 "/usr/include/x86_64-linux-gnu/sys/socket.h" 3 4
extern int shutdown (int __fd, int __how) __attribute__ ((__nothrow__ ));




extern int sockatmark (int __fd) __attribute__ ((__nothrow__ ));







extern int isfdtype (int __fd, int __fdtype) __attribute__ ((__nothrow__ ));
# 24 "/usr/include/netinet/in.h" 2 3 4






typedef uint32_t in_addr_t;
struct in_addr
  {
    in_addr_t s_addr;
  };


# 1 "/usr/include/x86_64-linux-gnu/bits/in.h" 1 3 4
# 145 "/usr/include/x86_64-linux-gnu/bits/in.h" 3 4
struct ip_opts
  {
    struct in_addr ip_dst;
    char ip_opts[40];
  };


struct in_pktinfo
  {
    int ipi_ifindex;
    struct in_addr ipi_spec_dst;
    struct in_addr ipi_addr;
  };
# 38 "/usr/include/netinet/in.h" 2 3 4


enum
  {
    IPPROTO_IP = 0,

    IPPROTO_ICMP = 1,

    IPPROTO_IGMP = 2,

    IPPROTO_IPIP = 4,

    IPPROTO_TCP = 6,

    IPPROTO_EGP = 8,

    IPPROTO_PUP = 12,

    IPPROTO_UDP = 17,

    IPPROTO_IDP = 22,

    IPPROTO_TP = 29,

    IPPROTO_DCCP = 33,

    IPPROTO_IPV6 = 41,

    IPPROTO_RSVP = 46,

    IPPROTO_GRE = 47,

    IPPROTO_ESP = 50,

    IPPROTO_AH = 51,

    IPPROTO_MTP = 92,

    IPPROTO_BEETPH = 94,

    IPPROTO_ENCAP = 98,

    IPPROTO_PIM = 103,

    IPPROTO_COMP = 108,

    IPPROTO_L2TP = 115,

    IPPROTO_SCTP = 132,

    IPPROTO_UDPLITE = 136,

    IPPROTO_MPLS = 137,

    IPPROTO_ETHERNET = 143,

    IPPROTO_RAW = 255,

    IPPROTO_MPTCP = 262,

    IPPROTO_MAX
  };





enum
  {
    IPPROTO_HOPOPTS = 0,

    IPPROTO_ROUTING = 43,

    IPPROTO_FRAGMENT = 44,

    IPPROTO_ICMPV6 = 58,

    IPPROTO_NONE = 59,

    IPPROTO_DSTOPTS = 60,

    IPPROTO_MH = 135

  };



typedef uint16_t in_port_t;


enum
  {
    IPPORT_ECHO = 7,
    IPPORT_DISCARD = 9,
    IPPORT_SYSTAT = 11,
    IPPORT_DAYTIME = 13,
    IPPORT_NETSTAT = 15,
    IPPORT_FTP = 21,
    IPPORT_TELNET = 23,
    IPPORT_SMTP = 25,
    IPPORT_TIMESERVER = 37,
    IPPORT_NAMESERVER = 42,
    IPPORT_WHOIS = 43,
    IPPORT_MTP = 57,

    IPPORT_TFTP = 69,
    IPPORT_RJE = 77,
    IPPORT_FINGER = 79,
    IPPORT_TTYLINK = 87,
    IPPORT_SUPDUP = 95,


    IPPORT_EXECSERVER = 512,
    IPPORT_LOGINSERVER = 513,
    IPPORT_CMDSERVER = 514,
    IPPORT_EFSSERVER = 520,


    IPPORT_BIFFUDP = 512,
    IPPORT_WHOSERVER = 513,
    IPPORT_ROUTESERVER = 520,


    IPPORT_RESERVED = 1024,


    IPPORT_USERRESERVED = 5000
  };
# 221 "/usr/include/netinet/in.h" 3 4
struct in6_addr
  {
    union
      {
 uint8_t __u6_addr8[16];
 uint16_t __u6_addr16[8];
 uint32_t __u6_addr32[4];
      } __in6_u;





  };


extern const struct in6_addr in6addr_any;
extern const struct in6_addr in6addr_loopback;
# 247 "/usr/include/netinet/in.h" 3 4
struct sockaddr_in
  {
    sa_family_t sin_family;
    in_port_t sin_port;
    struct in_addr sin_addr;


    unsigned char sin_zero[sizeof (struct sockaddr)
      - (sizeof (unsigned short int))
      - sizeof (in_port_t)
      - sizeof (struct in_addr)];
  };



struct sockaddr_in6
  {
    sa_family_t sin6_family;
    in_port_t sin6_port;
    uint32_t sin6_flowinfo;
    struct in6_addr sin6_addr;
    uint32_t sin6_scope_id;
  };




struct ip_mreq
  {

    struct in_addr imr_multiaddr;


    struct in_addr imr_interface;
  };


struct ip_mreqn
  {

    struct in_addr imr_multiaddr;


    struct in_addr imr_address;


    int imr_ifindex;
  };

struct ip_mreq_source
  {

    struct in_addr imr_multiaddr;


    struct in_addr imr_interface;


    struct in_addr imr_sourceaddr;
  };




struct ipv6_mreq
  {

    struct in6_addr ipv6mr_multiaddr;


    unsigned int ipv6mr_interface;
  };




struct group_req
  {

    uint32_t gr_interface;


    struct sockaddr_storage gr_group;
  };

struct group_source_req
  {

    uint32_t gsr_interface;


    struct sockaddr_storage gsr_group;


    struct sockaddr_storage gsr_source;
  };



struct ip_msfilter
  {

    struct in_addr imsf_multiaddr;


    struct in_addr imsf_interface;


    uint32_t imsf_fmode;


    uint32_t imsf_numsrc;

    struct in_addr imsf_slist[1];
  };





struct group_filter
  {

    uint32_t gf_interface;


    struct sockaddr_storage gf_group;


    uint32_t gf_fmode;


    uint32_t gf_numsrc;

    struct sockaddr_storage gf_slist[1];
};
# 397 "/usr/include/netinet/in.h" 3 4
extern uint32_t ntohl (uint32_t __netlong) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern uint16_t ntohs (uint16_t __netshort)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern uint32_t htonl (uint32_t __hostlong)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern uint16_t htons (uint16_t __hostshort)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




# 1 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 1 3 4
# 409 "/usr/include/netinet/in.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 410 "/usr/include/netinet/in.h" 2 3 4
# 525 "/usr/include/netinet/in.h" 3 4
extern int bindresvport (int __sockfd, struct sockaddr_in *__sock_in) __attribute__ ((__nothrow__ ));


extern int bindresvport6 (int __sockfd, struct sockaddr_in6 *__sock_in)
     __attribute__ ((__nothrow__ ));
# 555 "/usr/include/netinet/in.h" 3 4
struct cmsghdr;



struct in6_pktinfo
  {
    struct in6_addr ipi6_addr;
    unsigned int ipi6_ifindex;
  };


struct ip6_mtuinfo
  {
    struct sockaddr_in6 ip6m_addr;
    uint32_t ip6m_mtu;
  };



extern int inet6_option_space (int __nbytes)
     __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));
extern int inet6_option_init (void *__bp, struct cmsghdr **__cmsgp,
         int __type) __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));
extern int inet6_option_append (struct cmsghdr *__cmsg,
    const uint8_t *__typep, int __multx,
    int __plusy) __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));
extern uint8_t *inet6_option_alloc (struct cmsghdr *__cmsg, int __datalen,
        int __multx, int __plusy)
     __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));
extern int inet6_option_next (const struct cmsghdr *__cmsg,
         uint8_t **__tptrp)
     __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));
extern int inet6_option_find (const struct cmsghdr *__cmsg,
         uint8_t **__tptrp, int __type)
     __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));



extern int inet6_opt_init (void *__extbuf, socklen_t __extlen) __attribute__ ((__nothrow__ ));
extern int inet6_opt_append (void *__extbuf, socklen_t __extlen, int __offset,
        uint8_t __type, socklen_t __len, uint8_t __align,
        void **__databufp) __attribute__ ((__nothrow__ ));
extern int inet6_opt_finish (void *__extbuf, socklen_t __extlen, int __offset)
     __attribute__ ((__nothrow__ ));
extern int inet6_opt_set_val (void *__databuf, int __offset, void *__val,
         socklen_t __vallen) __attribute__ ((__nothrow__ ));
extern int inet6_opt_next (void *__extbuf, socklen_t __extlen, int __offset,
      uint8_t *__typep, socklen_t *__lenp,
      void **__databufp) __attribute__ ((__nothrow__ ));
extern int inet6_opt_find (void *__extbuf, socklen_t __extlen, int __offset,
      uint8_t __type, socklen_t *__lenp,
      void **__databufp) __attribute__ ((__nothrow__ ));
extern int inet6_opt_get_val (void *__databuf, int __offset, void *__val,
         socklen_t __vallen) __attribute__ ((__nothrow__ ));



extern socklen_t inet6_rth_space (int __type, int __segments) __attribute__ ((__nothrow__ ));
extern void *inet6_rth_init (void *__bp, socklen_t __bp_len, int __type,
        int __segments) __attribute__ ((__nothrow__ ));
extern int inet6_rth_add (void *__bp, const struct in6_addr *__addr) __attribute__ ((__nothrow__ ));
extern int inet6_rth_reverse (const void *__in, void *__out) __attribute__ ((__nothrow__ ));
extern int inet6_rth_segments (const void *__bp) __attribute__ ((__nothrow__ ));
extern struct in6_addr *inet6_rth_getaddr (const void *__bp, int __index)
     __attribute__ ((__nothrow__ ));





extern int getipv4sourcefilter (int __s, struct in_addr __interface_addr,
    struct in_addr __group, uint32_t *__fmode,
    uint32_t *__numsrc, struct in_addr *__slist)
     __attribute__ ((__nothrow__ ));


extern int setipv4sourcefilter (int __s, struct in_addr __interface_addr,
    struct in_addr __group, uint32_t __fmode,
    uint32_t __numsrc,
    const struct in_addr *__slist)
     __attribute__ ((__nothrow__ ));



extern int getsourcefilter (int __s, uint32_t __interface_addr,
       const struct sockaddr *__group,
       socklen_t __grouplen, uint32_t *__fmode,
       uint32_t *__numsrc,
       struct sockaddr_storage *__slist) __attribute__ ((__nothrow__ ));


extern int setsourcefilter (int __s, uint32_t __interface_addr,
       const struct sockaddr *__group,
       socklen_t __grouplen, uint32_t __fmode,
       uint32_t __numsrc,
       const struct sockaddr_storage *__slist) __attribute__ ((__nothrow__ ));
# 23 "/usr/include/arpa/inet.h" 2 3 4
# 34 "/usr/include/arpa/inet.h" 3 4
extern in_addr_t inet_addr (const char *__cp) __attribute__ ((__nothrow__ ));


extern in_addr_t inet_lnaof (struct in_addr __in) __attribute__ ((__nothrow__ ));



extern struct in_addr inet_makeaddr (in_addr_t __net, in_addr_t __host)
     __attribute__ ((__nothrow__ ));


extern in_addr_t inet_netof (struct in_addr __in) __attribute__ ((__nothrow__ ));



extern in_addr_t inet_network (const char *__cp) __attribute__ ((__nothrow__ ));



extern char *inet_ntoa (struct in_addr __in) __attribute__ ((__nothrow__ ));




extern int inet_pton (int __af, const char *__restrict __cp,
        void *__restrict __buf) __attribute__ ((__nothrow__ ));




extern const char *inet_ntop (int __af, const void *__restrict __cp,
         char *__restrict __buf, socklen_t __len)
     __attribute__ ((__nothrow__ ));






extern int inet_aton (const char *__cp, struct in_addr *__inp) __attribute__ ((__nothrow__ ));



extern char *inet_neta (in_addr_t __net, char *__buf, size_t __len) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use inet_ntop instead")));




extern char *inet_net_ntop (int __af, const void *__cp, int __bits,
       char *__buf, size_t __len) __attribute__ ((__nothrow__ ));




extern int inet_net_pton (int __af, const char *__cp,
     void *__buf, size_t __len) __attribute__ ((__nothrow__ ));




extern unsigned int inet_nsap_addr (const char *__cp,
        unsigned char *__buf, int __len) __attribute__ ((__nothrow__ ));



extern char *inet_nsap_ntoa (int __len, const unsigned char *__cp,
        char *__buf) __attribute__ ((__nothrow__ ));
# 102 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h" 1
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h"
typedef int64_t git_off_t;
typedef int64_t git_time_t;




typedef uint64_t git_object_size_t;

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/buffer.h" 1
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/buffer.h"
typedef struct {






 char *ptr;




 size_t reserved;





 size_t size;
} git_buf;
# 71 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/buffer.h"
extern __attribute__((visibility("default"))) void git_buf_dispose(git_buf *buffer);
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/experimental.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h" 2
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
typedef enum {





 GIT_OID_SHA1 = 1


} git_oid_t;
# 103 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
typedef struct git_oid {







 unsigned char id[20];
} git_oid;
# 137 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_fromstr(git_oid *out, const char *str);
# 146 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_fromstrp(git_oid *out, const char *str);
# 159 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_fromstrn(git_oid *out, const char *str, size_t length);
# 168 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_fromraw(git_oid *out, const unsigned char *raw);
# 184 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_fmt(char *out, const git_oid *id);
# 196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_nfmt(char *out, size_t n, const git_oid *id);
# 213 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_pathfmt(char *out, const git_oid *id);
# 226 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) char * git_oid_tostr_s(const git_oid *oid);
# 247 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) char * git_oid_tostr(char *out, size_t n, const git_oid *id);
# 256 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_cpy(git_oid *out, const git_oid *src);
# 265 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_cmp(const git_oid *a, const git_oid *b);
# 274 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_equal(const git_oid *a, const git_oid *b);
# 285 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_ncmp(const git_oid *a, const git_oid *b, size_t len);
# 294 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_streq(const git_oid *id, const char *str);
# 304 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_strcmp(const git_oid *id, const char *str);







extern __attribute__((visibility("default"))) int git_oid_is_zero(const git_oid *id);




typedef struct git_oid_shorten git_oid_shorten;
# 333 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) git_oid_shorten * git_oid_shorten_new(size_t min_length);
# 359 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oid.h"
extern __attribute__((visibility("default"))) int git_oid_shorten_add(git_oid_shorten *os, const char *text_id);






extern __attribute__((visibility("default"))) void git_oid_shorten_free(git_oid_shorten *os);
# 71 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h" 2


typedef enum {
 GIT_OBJECT_ANY = -2,
 GIT_OBJECT_INVALID = -1,
 GIT_OBJECT_COMMIT = 1,
 GIT_OBJECT_TREE = 2,
 GIT_OBJECT_BLOB = 3,
 GIT_OBJECT_TAG = 4,
 GIT_OBJECT_OFS_DELTA = 6,
 GIT_OBJECT_REF_DELTA = 7
} git_object_t;





typedef struct git_odb git_odb;


typedef struct git_odb_backend git_odb_backend;




typedef struct git_odb_object git_odb_object;


typedef struct git_odb_stream git_odb_stream;


typedef struct git_odb_writepack git_odb_writepack;


typedef struct git_midx_writer git_midx_writer;


typedef struct git_refdb git_refdb;


typedef struct git_refdb_backend git_refdb_backend;


typedef struct git_commit_graph git_commit_graph;


typedef struct git_commit_graph_writer git_commit_graph_writer;





typedef struct git_repository git_repository;


typedef struct git_worktree git_worktree;


typedef struct git_object git_object;


typedef struct git_revwalk git_revwalk;


typedef struct git_tag git_tag;


typedef struct git_blob git_blob;


typedef struct git_commit git_commit;


typedef struct git_tree_entry git_tree_entry;


typedef struct git_tree git_tree;


typedef struct git_treebuilder git_treebuilder;


typedef struct git_index git_index;


typedef struct git_index_iterator git_index_iterator;


typedef struct git_index_conflict_iterator git_index_conflict_iterator;


typedef struct git_config git_config;


typedef struct git_config_backend git_config_backend;


typedef struct git_reflog_entry git_reflog_entry;


typedef struct git_reflog git_reflog;


typedef struct git_note git_note;


typedef struct git_packbuilder git_packbuilder;


typedef struct git_time {
 git_time_t time;
 int offset;
 char sign;
} git_time;


typedef struct git_signature {
 char *name;
 char *email;
 git_time when;
} git_signature;


typedef struct git_reference git_reference;


typedef struct git_reference_iterator git_reference_iterator;


typedef struct git_transaction git_transaction;
# 214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h"
typedef struct git_annotated_commit git_annotated_commit;


typedef struct git_status_list git_status_list;


typedef struct git_rebase git_rebase;


typedef enum {
 GIT_REFERENCE_INVALID = 0,
 GIT_REFERENCE_DIRECT = 1,
 GIT_REFERENCE_SYMBOLIC = 2,
 GIT_REFERENCE_ALL = GIT_REFERENCE_DIRECT | GIT_REFERENCE_SYMBOLIC
} git_reference_t;


typedef enum {
 GIT_BRANCH_LOCAL = 1,
 GIT_BRANCH_REMOTE = 2,
 GIT_BRANCH_ALL = GIT_BRANCH_LOCAL|GIT_BRANCH_REMOTE
} git_branch_t;


typedef enum {
 GIT_FILEMODE_UNREADABLE = 0000000,
 GIT_FILEMODE_TREE = 0040000,
 GIT_FILEMODE_BLOB = 0100644,
 GIT_FILEMODE_BLOB_EXECUTABLE = 0100755,
 GIT_FILEMODE_LINK = 0120000,
 GIT_FILEMODE_COMMIT = 0160000
} git_filemode_t;





typedef struct git_refspec git_refspec;





typedef struct git_remote git_remote;





typedef struct git_transport git_transport;





typedef struct git_push git_push;


typedef struct git_remote_head git_remote_head;
typedef struct git_remote_callbacks git_remote_callbacks;




typedef struct git_cert git_cert;




typedef struct git_submodule git_submodule;
# 311 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h"
typedef enum {
 GIT_SUBMODULE_UPDATE_CHECKOUT = 1,
 GIT_SUBMODULE_UPDATE_REBASE = 2,
 GIT_SUBMODULE_UPDATE_MERGE = 3,
 GIT_SUBMODULE_UPDATE_NONE = 4,

 GIT_SUBMODULE_UPDATE_DEFAULT = 0
} git_submodule_update_t;
# 347 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h"
typedef enum {
 GIT_SUBMODULE_IGNORE_UNSPECIFIED = -1,

 GIT_SUBMODULE_IGNORE_NONE = 1,
 GIT_SUBMODULE_IGNORE_UNTRACKED = 2,
 GIT_SUBMODULE_IGNORE_DIRTY = 3,
 GIT_SUBMODULE_IGNORE_ALL = 4
} git_submodule_ignore_t;
# 366 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/types.h"
typedef enum {
 GIT_SUBMODULE_RECURSE_NO = 0,
 GIT_SUBMODULE_RECURSE_YES = 1,
 GIT_SUBMODULE_RECURSE_ONDEMAND = 2
} git_submodule_recurse_t;

typedef struct git_writestream git_writestream;


struct git_writestream {
 int (*write)(git_writestream *stream, const char *buffer, size_t len);
 int (*close)(git_writestream *stream);
 void (*free)(git_writestream *stream);
};


typedef struct git_mailmap git_mailmap;
# 106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/errors.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/errors.h"
typedef enum {



 GIT_OK = 0,




 GIT_ERROR = -1,

 GIT_ENOTFOUND = -3,
 GIT_EEXISTS = -4,
 GIT_EAMBIGUOUS = -5,
 GIT_EBUFS = -6,






 GIT_EUSER = -7,

 GIT_EBAREREPO = -8,
 GIT_EUNBORNBRANCH = -9,
 GIT_EUNMERGED = -10,
 GIT_ENONFASTFORWARD = -11,
 GIT_EINVALIDSPEC = -12,
 GIT_ECONFLICT = -13,
 GIT_ELOCKED = -14,
 GIT_EMODIFIED = -15,
 GIT_EAUTH = -16,
 GIT_ECERTIFICATE = -17,
 GIT_EAPPLIED = -18,
 GIT_EPEEL = -19,
 GIT_EEOF = -20,
 GIT_EINVALID = -21,
 GIT_EUNCOMMITTED = -22,
 GIT_EDIRECTORY = -23,
 GIT_EMERGECONFLICT = -24,

 GIT_PASSTHROUGH = -30,
 GIT_ITEROVER = -31,
 GIT_RETRY = -32,
 GIT_EMISMATCH = -33,
 GIT_EINDEXDIRTY = -34,
 GIT_EAPPLYFAIL = -35,
 GIT_EOWNER = -36,
 GIT_TIMEOUT = -37,
 GIT_EUNCHANGED = -38,
 GIT_ENOTSUPPORTED = -39,
 GIT_EREADONLY = -40
} git_error_code;





typedef enum {
 GIT_ERROR_NONE = 0,
 GIT_ERROR_NOMEMORY,
 GIT_ERROR_OS,
 GIT_ERROR_INVALID,
 GIT_ERROR_REFERENCE,
 GIT_ERROR_ZLIB,
 GIT_ERROR_REPOSITORY,
 GIT_ERROR_CONFIG,
 GIT_ERROR_REGEX,
 GIT_ERROR_ODB,
 GIT_ERROR_INDEX,
 GIT_ERROR_OBJECT,
 GIT_ERROR_NET,
 GIT_ERROR_TAG,
 GIT_ERROR_TREE,
 GIT_ERROR_INDEXER,
 GIT_ERROR_SSL,
 GIT_ERROR_SUBMODULE,
 GIT_ERROR_THREAD,
 GIT_ERROR_STASH,
 GIT_ERROR_CHECKOUT,
 GIT_ERROR_FETCHHEAD,
 GIT_ERROR_MERGE,
 GIT_ERROR_SSH,
 GIT_ERROR_FILTER,
 GIT_ERROR_REVERT,
 GIT_ERROR_CALLBACK,
 GIT_ERROR_CHERRYPICK,
 GIT_ERROR_DESCRIBE,
 GIT_ERROR_REBASE,
 GIT_ERROR_FILESYSTEM,
 GIT_ERROR_PATCH,
 GIT_ERROR_WORKTREE,
 GIT_ERROR_SHA,
 GIT_ERROR_HTTP,
 GIT_ERROR_INTERNAL,
 GIT_ERROR_GRAFTS
} git_error_t;







typedef struct {
 char *message;
 int klass;
} git_error;
# 149 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/errors.h"
extern __attribute__((visibility("default"))) const git_error * git_error_last(void);
# 107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/thread.h" 1
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/thread.h"
typedef struct {



 volatile int val;

} git_atomic32;



typedef struct {



 volatile int64_t val;

} git_atomic64;

typedef git_atomic64 git_atomic_ssize;
# 74 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/thread.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/pthread.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/pthread.h"
typedef struct {
 pthread_t thread;
} git_thread;

static __inline__ int git_threads_global_init(void) { return 0; }
# 75 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/thread.h" 2





static __inline__ void git_atomic32_set(git_atomic32 *a, int val)
{



 __atomic_store_n(&a->val, val, 5);





}





static __inline__ int git_atomic32_inc(git_atomic32 *a)
{



 return __atomic_add_fetch(&a->val, 1, 5);





}





static __inline__ int git_atomic32_add(git_atomic32 *a, int32_t addend)
{



 return __atomic_add_fetch(&a->val, addend, 5);





}





static __inline__ int git_atomic32_dec(git_atomic32 *a)
{



 return __atomic_sub_fetch(&a->val, 1, 5);





}





static __inline__ int git_atomic32_get(git_atomic32 *a)
{



 return __atomic_load_n(&a->val, 5);





}

static __inline__ void * git_atomic__compare_and_swap(
 void * volatile *ptr, void *oldval, void *newval)
{



 void *foundval = oldval;
 __atomic_compare_exchange(ptr, &foundval, &newval, 0, 5, 5);
 return foundval;





}

static __inline__ volatile void * git_atomic__swap(
 void * volatile *ptr, void *newval)
{



 void * foundval = ((void*)0);
 __atomic_exchange(ptr, &newval, &foundval, 5);
 return foundval;





}

static __inline__ volatile void * git_atomic__load(void * volatile *ptr)
{




 return (volatile void *)__atomic_load_n(ptr, 5);





}







static __inline__ int64_t git_atomic64_add(git_atomic64 *a, int64_t addend)
{



 return __atomic_add_fetch(&a->val, addend, 5);





}




static __inline__ void git_atomic64_set(git_atomic64 *a, int64_t val)
{



 __atomic_store_n(&a->val, val, 5);





}





static __inline__ int64_t git_atomic64_get(git_atomic64 *a)
{



 return __atomic_load_n(&a->val, 5);





}
# 453 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/thread.h"
int git_tlsdata_init(pthread_key_t *key, void ( *destroy_fn)(void *));
# 462 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/thread.h"
int git_tlsdata_set(pthread_key_t key, void *value);







void *git_tlsdata_get(pthread_key_t key);







int git_tlsdata_dispose(pthread_key_t key);
# 108 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/integer.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/integer.h"
static __inline__ int git__is_sizet(int64_t p)
{
 size_t r = (size_t)p;
 return p == (int64_t)r;
}


static __inline__ int git__is_ssizet(size_t p)
{
 ssize_t r = (ssize_t)p;
 return p == (size_t)r;
}


static __inline__ int git__is_uint16(size_t p)
{
 uint16_t r = (uint16_t)p;
 return p == (size_t)r;
}


static __inline__ int git__is_uint32(size_t p)
{
 uint32_t r = (uint32_t)p;
 return p == (size_t)r;
}


static __inline__ int git__is_ulong(int64_t p)
{
 unsigned long r = (unsigned long)p;
 return p == (int64_t)r;
}


static __inline__ int git__is_int(int64_t p)
{
 int r = (int)p;
 return p == (int64_t)r;
}
# 109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/assert_safe.h" 1
# 110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h" 2


# 1 "/usr/include/fcntl.h" 1 3 4
# 35 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fcntl.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/fcntl.h" 3 4
struct flock
  {
    short int l_type;
    short int l_whence;

    __off_t l_start;
    __off_t l_len;




    __pid_t l_pid;
  };


struct flock64
  {
    short int l_type;
    short int l_whence;
    __off64_t l_start;
    __off64_t l_len;
    __pid_t l_pid;
  };



# 1 "/usr/include/x86_64-linux-gnu/bits/fcntl-linux.h" 1 3 4
# 265 "/usr/include/x86_64-linux-gnu/bits/fcntl-linux.h" 3 4
enum __pid_type
  {
    F_OWNER_TID = 0,
    F_OWNER_PID,
    F_OWNER_PGRP,
    F_OWNER_GID = F_OWNER_PGRP
  };


struct f_owner_ex
  {
    enum __pid_type type;
    __pid_t pid;
  };
# 355 "/usr/include/x86_64-linux-gnu/bits/fcntl-linux.h" 3 4
# 1 "/usr/include/linux/falloc.h" 1 3 4
# 356 "/usr/include/x86_64-linux-gnu/bits/fcntl-linux.h" 2 3 4



struct file_handle
{
  unsigned int handle_bytes;
  int handle_type;

  unsigned char f_handle[0];
};
# 387 "/usr/include/x86_64-linux-gnu/bits/fcntl-linux.h" 3 4
extern __ssize_t readahead (int __fd, __off64_t __offset, size_t __count)
    __attribute__ ((__nothrow__ ));






extern int sync_file_range (int __fd, __off64_t __offset, __off64_t __count,
       unsigned int __flags);






extern __ssize_t vmsplice (int __fdout, const struct iovec *__iov,
      size_t __count, unsigned int __flags);





extern __ssize_t splice (int __fdin, __off64_t *__offin, int __fdout,
    __off64_t *__offout, size_t __len,
    unsigned int __flags);





extern __ssize_t tee (int __fdin, int __fdout, size_t __len,
        unsigned int __flags);






extern int fallocate (int __fd, int __mode, __off_t __offset, __off_t __len);
# 437 "/usr/include/x86_64-linux-gnu/bits/fcntl-linux.h" 3 4
extern int fallocate64 (int __fd, int __mode, __off64_t __offset,
   __off64_t __len);




extern int name_to_handle_at (int __dfd, const char *__name,
         struct file_handle *__handle, int *__mnt_id,
         int __flags) __attribute__ ((__nothrow__ ));





extern int open_by_handle_at (int __mountdirfd, struct file_handle *__handle,
         int __flags);
# 62 "/usr/include/x86_64-linux-gnu/bits/fcntl.h" 2 3 4
# 36 "/usr/include/fcntl.h" 2 3 4
# 78 "/usr/include/fcntl.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stat.h" 1 3 4
# 79 "/usr/include/fcntl.h" 2 3 4
# 177 "/usr/include/fcntl.h" 3 4
extern int fcntl (int __fd, int __cmd, ...);
# 186 "/usr/include/fcntl.h" 3 4
extern int fcntl64 (int __fd, int __cmd, ...);
# 209 "/usr/include/fcntl.h" 3 4
extern int open (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));
# 219 "/usr/include/fcntl.h" 3 4
extern int open64 (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));
# 233 "/usr/include/fcntl.h" 3 4
extern int openat (int __fd, const char *__file, int __oflag, ...)
     __attribute__ ((__nonnull__ (2)));
# 244 "/usr/include/fcntl.h" 3 4
extern int openat64 (int __fd, const char *__file, int __oflag, ...)
     __attribute__ ((__nonnull__ (2)));
# 255 "/usr/include/fcntl.h" 3 4
extern int creat (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));
# 265 "/usr/include/fcntl.h" 3 4
extern int creat64 (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));
# 301 "/usr/include/fcntl.h" 3 4
extern int posix_fadvise (int __fd, off_t __offset, off_t __len,
     int __advise) __attribute__ ((__nothrow__ ));
# 313 "/usr/include/fcntl.h" 3 4
extern int posix_fadvise64 (int __fd, off64_t __offset, off64_t __len,
       int __advise) __attribute__ ((__nothrow__ ));
# 323 "/usr/include/fcntl.h" 3 4
extern int posix_fallocate (int __fd, off_t __offset, off_t __len);
# 334 "/usr/include/fcntl.h" 3 4
extern int posix_fallocate64 (int __fd, off64_t __offset, off64_t __len);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h" 2
# 110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h"
typedef int64_t off64_t;


typedef int git_file;
# 128 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h"
extern ssize_t p_read(git_file fd, void *buf, size_t cnt);
extern int p_write(git_file fd, const void *buf, size_t cnt);

extern ssize_t p_pread(int fd, void *data, size_t size, off64_t offset);
extern ssize_t p_pwrite(int fd, const void *data, size_t size, off64_t offset);




extern int p_open(const char *path, int flags, ...);
extern int p_creat(const char *path, mode_t mode);
extern int p_getcwd(char *buffer_out, size_t size);
extern int p_rename(const char *from, const char *to);

extern int git__page_size(size_t *page_size);
extern int git__mmap_alignment(size_t *page_size);





extern size_t p_fsync__cnt;







# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h" 2


# 1 "/usr/include/dirent.h" 1 3 4
# 61 "/usr/include/dirent.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/dirent.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/dirent.h" 3 4
struct dirent
  {

    __ino_t d_ino;
    __off_t d_off;




    unsigned short int d_reclen;
    unsigned char d_type;
    char d_name[256];
  };


struct dirent64
  {
    __ino64_t d_ino;
    __off64_t d_off;
    unsigned short int d_reclen;
    unsigned char d_type;
    char d_name[256];
  };
# 62 "/usr/include/dirent.h" 2 3 4
# 97 "/usr/include/dirent.h" 3 4
enum
  {
    DT_UNKNOWN = 0,

    DT_FIFO = 1,

    DT_CHR = 2,

    DT_DIR = 4,

    DT_BLK = 6,

    DT_REG = 8,

    DT_LNK = 10,

    DT_SOCK = 12,

    DT_WHT = 14

  };
# 127 "/usr/include/dirent.h" 3 4
typedef struct __dirstream DIR;






extern int closedir (DIR *__dirp) __attribute__ ((__nonnull__ (1)));






extern DIR *opendir (const char *__name) __attribute__ ((__nonnull__ (1)))
 __attribute__ ((__malloc__)) ;






extern DIR *fdopendir (int __fd)
 __attribute__ ((__malloc__)) ;
# 164 "/usr/include/dirent.h" 3 4
extern struct dirent *readdir (DIR *__dirp) __attribute__ ((__nonnull__ (1)));
# 175 "/usr/include/dirent.h" 3 4
extern struct dirent64 *readdir64 (DIR *__dirp) __attribute__ ((__nonnull__ (1)));
# 185 "/usr/include/dirent.h" 3 4
extern int readdir_r (DIR *__restrict __dirp,
        struct dirent *__restrict __entry,
        struct dirent **__restrict __result)
     __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__deprecated__));
# 203 "/usr/include/dirent.h" 3 4
extern int readdir64_r (DIR *__restrict __dirp,
   struct dirent64 *__restrict __entry,
   struct dirent64 **__restrict __result)
  __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__deprecated__));




extern void rewinddir (DIR *__dirp) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern void seekdir (DIR *__dirp, long int __pos) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern long int telldir (DIR *__dirp) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int dirfd (DIR *__dirp) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 247 "/usr/include/dirent.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 248 "/usr/include/dirent.h" 2 3 4
# 257 "/usr/include/dirent.h" 3 4
extern int scandir (const char *__restrict __dir,
      struct dirent ***__restrict __namelist,
      int (*__selector) (const struct dirent *),
      int (*__cmp) (const struct dirent **,
      const struct dirent **))
     __attribute__ ((__nonnull__ (1, 2)));
# 280 "/usr/include/dirent.h" 3 4
extern int scandir64 (const char *__restrict __dir,
        struct dirent64 ***__restrict __namelist,
        int (*__selector) (const struct dirent64 *),
        int (*__cmp) (const struct dirent64 **,
        const struct dirent64 **))
     __attribute__ ((__nonnull__ (1, 2)));
# 295 "/usr/include/dirent.h" 3 4
extern int scandirat (int __dfd, const char *__restrict __dir,
        struct dirent ***__restrict __namelist,
        int (*__selector) (const struct dirent *),
        int (*__cmp) (const struct dirent **,
        const struct dirent **))
     __attribute__ ((__nonnull__ (2, 3)));
# 317 "/usr/include/dirent.h" 3 4
extern int scandirat64 (int __dfd, const char *__restrict __dir,
   struct dirent64 ***__restrict __namelist,
   int (*__selector) (const struct dirent64 *),
   int (*__cmp) (const struct dirent64 **,
          const struct dirent64 **))
     __attribute__ ((__nonnull__ (2, 3)));




extern int alphasort (const struct dirent **__e1,
        const struct dirent **__e2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 342 "/usr/include/dirent.h" 3 4
extern int alphasort64 (const struct dirent64 **__e1,
   const struct dirent64 **__e2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 355 "/usr/include/dirent.h" 3 4
extern __ssize_t getdirentries (int __fd, char *__restrict __buf,
    size_t __nbytes,
    __off_t *__restrict __basep)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)));
# 372 "/usr/include/dirent.h" 3 4
extern __ssize_t getdirentries64 (int __fd, char *__restrict __buf,
      size_t __nbytes,
      __off64_t *__restrict __basep)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)));






extern int versionsort (const struct dirent **__e1,
   const struct dirent **__e2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 398 "/usr/include/dirent.h" 3 4
extern int versionsort64 (const struct dirent64 **__e1,
     const struct dirent64 **__e2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));





# 1 "/usr/include/x86_64-linux-gnu/bits/dirent_ext.h" 1 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/dirent_ext.h" 3 4
extern __ssize_t getdents64 (int __fd, void *__buffer, size_t __length)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 407 "/usr/include/dirent.h" 2 3 4
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h" 2
# 1 "/usr/include/x86_64-linux-gnu/sys/param.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/sys/param.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 24 "/usr/include/x86_64-linux-gnu/sys/param.h" 2 3 4


# 1 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/sys/param.h" 2 3 4

# 1 "/usr/include/signal.h" 1 3 4
# 30 "/usr/include/signal.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/signum-generic.h" 1 3 4
# 76 "/usr/include/x86_64-linux-gnu/bits/signum-generic.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/signum-arch.h" 1 3 4
# 77 "/usr/include/x86_64-linux-gnu/bits/signum-generic.h" 2 3 4
# 31 "/usr/include/signal.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/sig_atomic_t.h" 1 3 4







typedef __sig_atomic_t sig_atomic_t;
# 33 "/usr/include/signal.h" 2 3 4
# 57 "/usr/include/signal.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h" 1 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 5 "/usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/__sigval_t.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/types/__sigval_t.h" 3 4
union sigval
{
  int sival_int;
  void *sival_ptr;
};

typedef union sigval __sigval_t;
# 7 "/usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h" 2 3 4
# 16 "/usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/siginfo-arch.h" 1 3 4
# 17 "/usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h" 2 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/types/siginfo_t.h" 3 4
typedef struct
  {
    int si_signo;

    int si_errno;

    int si_code;





    int __pad0;


    union
      {
 int _pad[((128 / sizeof (int)) - 4)];


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
   } _kill;


 struct
   {
     int si_tid;
     int si_overrun;
     __sigval_t si_sigval;
   } _timer;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     __sigval_t si_sigval;
   } _rt;


 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     int si_status;
     __clock_t si_utime;
     __clock_t si_stime;
   } _sigchld;


 struct
   {
     void *si_addr;

     short int si_addr_lsb;
     union
       {

  struct
    {
      void *_lower;
      void *_upper;
    } _addr_bnd;

  __uint32_t _pkey;
       } _bounds;
   } _sigfault;


 struct
   {
     long int si_band;
     int si_fd;
   } _sigpoll;



 struct
   {
     void *_call_addr;
     int _syscall;
     unsigned int _arch;
   } _sigsys;

      } _sifields;
  } siginfo_t ;
# 58 "/usr/include/signal.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/siginfo-consts.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/siginfo-consts.h" 3 4
enum
{
  SI_ASYNCNL = -60,
  SI_DETHREAD = -7,

  SI_TKILL,
  SI_SIGIO,

  SI_ASYNCIO,
  SI_MESGQ,
  SI_TIMER,





  SI_QUEUE,
  SI_USER,
  SI_KERNEL = 0x80
# 66 "/usr/include/x86_64-linux-gnu/bits/siginfo-consts.h" 3 4
};




enum
{
  ILL_ILLOPC = 1,

  ILL_ILLOPN,

  ILL_ILLADR,

  ILL_ILLTRP,

  ILL_PRVOPC,

  ILL_PRVREG,

  ILL_COPROC,

  ILL_BADSTK,

  ILL_BADIADDR

};


enum
{
  FPE_INTDIV = 1,

  FPE_INTOVF,

  FPE_FLTDIV,

  FPE_FLTOVF,

  FPE_FLTUND,

  FPE_FLTRES,

  FPE_FLTINV,

  FPE_FLTSUB,

  FPE_FLTUNK = 14,

  FPE_CONDTRAP

};


enum
{
  SEGV_MAPERR = 1,

  SEGV_ACCERR,

  SEGV_BNDERR,

  SEGV_PKUERR,

  SEGV_ACCADI,

  SEGV_ADIDERR,

  SEGV_ADIPERR,

  SEGV_MTEAERR,

  SEGV_MTESERR,

  SEGV_CPERR

};


enum
{
  BUS_ADRALN = 1,

  BUS_ADRERR,

  BUS_OBJERR,

  BUS_MCEERR_AR,

  BUS_MCEERR_AO

};




enum
{
  TRAP_BRKPT = 1,

  TRAP_TRACE,

  TRAP_BRANCH,

  TRAP_HWBKPT,

  TRAP_UNK

};




enum
{
  CLD_EXITED = 1,

  CLD_KILLED,

  CLD_DUMPED,

  CLD_TRAPPED,

  CLD_STOPPED,

  CLD_CONTINUED

};


enum
{
  POLL_IN = 1,

  POLL_OUT,

  POLL_MSG,

  POLL_ERR,

  POLL_PRI,

  POLL_HUP

};





# 1 "/usr/include/x86_64-linux-gnu/bits/siginfo-consts-arch.h" 1 3 4
# 216 "/usr/include/x86_64-linux-gnu/bits/siginfo-consts.h" 2 3 4
# 59 "/usr/include/signal.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/sigval_t.h" 1 3 4
# 16 "/usr/include/x86_64-linux-gnu/bits/types/sigval_t.h" 3 4
typedef __sigval_t sigval_t;
# 63 "/usr/include/signal.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/sigevent_t.h" 1 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 5 "/usr/include/x86_64-linux-gnu/bits/types/sigevent_t.h" 2 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/sigevent_t.h" 3 4
typedef struct sigevent
  {
    __sigval_t sigev_value;
    int sigev_signo;
    int sigev_notify;

    union
      {
 int _pad[((64 / sizeof (int)) - 4)];



 __pid_t _tid;

 struct
   {
     void (*_function) (__sigval_t);
     pthread_attr_t *_attribute;
   } _sigev_thread;
      } _sigev_un;
  } sigevent_t;
# 67 "/usr/include/signal.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/sigevent-consts.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/sigevent-consts.h" 3 4
enum
{
  SIGEV_SIGNAL = 0,

  SIGEV_NONE,

  SIGEV_THREAD,


  SIGEV_THREAD_ID = 4


};
# 68 "/usr/include/signal.h" 2 3 4




typedef void (*__sighandler_t) (int);




extern __sighandler_t __sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ ));

extern __sighandler_t sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ ));






extern __sighandler_t signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ ));
# 112 "/usr/include/signal.h" 3 4
extern int kill (__pid_t __pid, int __sig) __attribute__ ((__nothrow__ ));






extern int killpg (__pid_t __pgrp, int __sig) __attribute__ ((__nothrow__ ));



extern int raise (int __sig) __attribute__ ((__nothrow__ ));



extern __sighandler_t ssignal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ ));
extern int gsignal (int __sig) __attribute__ ((__nothrow__ ));




extern void psignal (int __sig, const char *__s);


extern void psiginfo (const siginfo_t *__pinfo, const char *__s);
# 151 "/usr/include/signal.h" 3 4
extern int sigpause (int __sig) __asm__ ("__xpg_sigpause")
  __attribute__ ((__deprecated__ ("Use the sigsuspend function instead")));
# 173 "/usr/include/signal.h" 3 4
extern int sigblock (int __mask) __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));


extern int sigsetmask (int __mask) __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));


extern int siggetmask (void) __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));
# 188 "/usr/include/signal.h" 3 4
typedef __sighandler_t sighandler_t;




typedef __sighandler_t sig_t;





extern int sigemptyset (sigset_t *__set) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int sigfillset (sigset_t *__set) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int sigaddset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int sigdelset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int sigismember (const sigset_t *__set, int __signo)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern int sigisemptyset (const sigset_t *__set) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int sigandset (sigset_t *__set, const sigset_t *__left,
        const sigset_t *__right) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3)));


extern int sigorset (sigset_t *__set, const sigset_t *__left,
       const sigset_t *__right) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3)));




# 1 "/usr/include/x86_64-linux-gnu/bits/sigaction.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/sigaction.h" 3 4
struct sigaction
  {


    union
      {

 __sighandler_t sa_handler;

 void (*sa_sigaction) (int, siginfo_t *, void *);
      }
    __sigaction_handler;







    __sigset_t sa_mask;


    int sa_flags;


    void (*sa_restorer) (void);
  };
# 230 "/usr/include/signal.h" 2 3 4


extern int sigprocmask (int __how, const sigset_t *__restrict __set,
   sigset_t *__restrict __oset) __attribute__ ((__nothrow__ ));






extern int sigsuspend (const sigset_t *__set) __attribute__ ((__nonnull__ (1)));


extern int sigaction (int __sig, const struct sigaction *__restrict __act,
        struct sigaction *__restrict __oact) __attribute__ ((__nothrow__ ));


extern int sigpending (sigset_t *__set) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







extern int sigwait (const sigset_t *__restrict __set, int *__restrict __sig)
     __attribute__ ((__nonnull__ (1, 2)));







extern int sigwaitinfo (const sigset_t *__restrict __set,
   siginfo_t *__restrict __info) __attribute__ ((__nonnull__ (1)));







extern int sigtimedwait (const sigset_t *__restrict __set,
    siginfo_t *__restrict __info,
    const struct timespec *__restrict __timeout)
     __attribute__ ((__nonnull__ (1)));
# 292 "/usr/include/signal.h" 3 4
extern int sigqueue (__pid_t __pid, int __sig, const union sigval __val)
     __attribute__ ((__nothrow__ ));







# 1 "/usr/include/x86_64-linux-gnu/bits/sigcontext.h" 1 3 4
# 31 "/usr/include/x86_64-linux-gnu/bits/sigcontext.h" 3 4
struct _fpx_sw_bytes
{
  __uint32_t magic1;
  __uint32_t extended_size;
  __uint64_t xstate_bv;
  __uint32_t xstate_size;
  __uint32_t __glibc_reserved1[7];
};

struct _fpreg
{
  unsigned short significand[4];
  unsigned short exponent;
};

struct _fpxreg
{
  unsigned short significand[4];
  unsigned short exponent;
  unsigned short __glibc_reserved1[3];
};

struct _xmmreg
{
  __uint32_t element[4];
};
# 123 "/usr/include/x86_64-linux-gnu/bits/sigcontext.h" 3 4
struct _fpstate
{

  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _fpxreg _st[8];
  struct _xmmreg _xmm[16];
  __uint32_t __glibc_reserved1[24];
};

struct sigcontext
{
  __uint64_t r8;
  __uint64_t r9;
  __uint64_t r10;
  __uint64_t r11;
  __uint64_t r12;
  __uint64_t r13;
  __uint64_t r14;
  __uint64_t r15;
  __uint64_t rdi;
  __uint64_t rsi;
  __uint64_t rbp;
  __uint64_t rbx;
  __uint64_t rdx;
  __uint64_t rax;
  __uint64_t rcx;
  __uint64_t rsp;
  __uint64_t rip;
  __uint64_t eflags;
  unsigned short cs;
  unsigned short gs;
  unsigned short fs;
  unsigned short __pad0;
  __uint64_t err;
  __uint64_t trapno;
  __uint64_t oldmask;
  __uint64_t cr2;
  __extension__ union
    {
      struct _fpstate * fpstate;
      __uint64_t __fpstate_word;
    };
  __uint64_t __reserved1 [8];
};



struct _xsave_hdr
{
  __uint64_t xstate_bv;
  __uint64_t __glibc_reserved1[2];
  __uint64_t __glibc_reserved2[5];
};

struct _ymmh_state
{
  __uint32_t ymmh_space[64];
};

struct _xstate
{
  struct _fpstate fpstate;
  struct _xsave_hdr xstate_hdr;
  struct _ymmh_state ymmh;
};
# 302 "/usr/include/signal.h" 2 3 4


extern int sigreturn (struct sigcontext *__scp) __attribute__ ((__nothrow__ ));






# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 312 "/usr/include/signal.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/stack_t.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/types/stack_t.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/types/stack_t.h" 2 3 4


typedef struct
  {
    void *ss_sp;
    int ss_flags;
    size_t ss_size;
  } stack_t;
# 314 "/usr/include/signal.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/sys/ucontext.h" 1 3 4
# 37 "/usr/include/x86_64-linux-gnu/sys/ucontext.h" 3 4
__extension__ typedef long long int greg_t;
# 46 "/usr/include/x86_64-linux-gnu/sys/ucontext.h" 3 4
typedef greg_t gregset_t[23];



enum
{
  REG_R8 = 0,

  REG_R9,

  REG_R10,

  REG_R11,

  REG_R12,

  REG_R13,

  REG_R14,

  REG_R15,

  REG_RDI,

  REG_RSI,

  REG_RBP,

  REG_RBX,

  REG_RDX,

  REG_RAX,

  REG_RCX,

  REG_RSP,

  REG_RIP,

  REG_EFL,

  REG_CSGSFS,

  REG_ERR,

  REG_TRAPNO,

  REG_OLDMASK,

  REG_CR2

};


struct _libc_fpxreg
{
  unsigned short int significand[4];
  unsigned short int exponent;
  unsigned short int __glibc_reserved1[3];
};

struct _libc_xmmreg
{
  __uint32_t element[4];
};

struct _libc_fpstate
{

  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _libc_fpxreg _st[8];
  struct _libc_xmmreg _xmm[16];
  __uint32_t __glibc_reserved1[24];
};


typedef struct _libc_fpstate *fpregset_t;


typedef struct
  {
    gregset_t gregs;

    fpregset_t fpregs;
    __extension__ unsigned long long __reserved1 [8];
} mcontext_t;


typedef struct ucontext_t
  {
    unsigned long int uc_flags;
    struct ucontext_t *uc_link;
    stack_t uc_stack;
    mcontext_t uc_mcontext;
    sigset_t uc_sigmask;
    struct _libc_fpstate __fpregs_mem;
    __extension__ unsigned long long int __ssp[4];
  } ucontext_t;
# 317 "/usr/include/signal.h" 2 3 4







extern int siginterrupt (int __sig, int __interrupt) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use sigaction with SA_RESTART instead")));

# 1 "/usr/include/x86_64-linux-gnu/bits/sigstack.h" 1 3 4
# 328 "/usr/include/signal.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/sigstksz.h" 1 3 4
# 329 "/usr/include/signal.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/ss_flags.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/ss_flags.h" 3 4
enum
{
  SS_ONSTACK = 1,

  SS_DISABLE

};
# 330 "/usr/include/signal.h" 2 3 4



extern int sigaltstack (const stack_t *__restrict __ss,
   stack_t *__restrict __oss) __attribute__ ((__nothrow__ ));




# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_sigstack.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/types/struct_sigstack.h" 3 4
struct sigstack
  {
    void *ss_sp;
    int ss_onstack;
  };
# 340 "/usr/include/signal.h" 2 3 4







extern int sigstack (struct sigstack *__ss, struct sigstack *__oss)
     __attribute__ ((__nothrow__ )) __attribute__ ((__deprecated__));






extern int sighold (int __sig) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use the sigprocmask function instead")));


extern int sigrelse (int __sig) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use the sigprocmask function instead")));


extern int sigignore (int __sig) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use the signal function instead")));


extern __sighandler_t sigset (int __sig, __sighandler_t __disp) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use the signal and sigprocmask functions instead")));







# 1 "/usr/include/x86_64-linux-gnu/bits/sigthread.h" 1 3 4
# 31 "/usr/include/x86_64-linux-gnu/bits/sigthread.h" 3 4
extern int pthread_sigmask (int __how,
       const __sigset_t *__restrict __newmask,
       __sigset_t *__restrict __oldmask)__attribute__ ((__nothrow__ ));


extern int pthread_kill (pthread_t __threadid, int __signo) __attribute__ ((__nothrow__ ));



extern int pthread_sigqueue (pthread_t __threadid, int __signo,
        const union sigval __value) __attribute__ ((__nothrow__ ));
# 377 "/usr/include/signal.h" 2 3 4






extern int __libc_current_sigrtmin (void) __attribute__ ((__nothrow__ ));

extern int __libc_current_sigrtmax (void) __attribute__ ((__nothrow__ ));





# 1 "/usr/include/x86_64-linux-gnu/bits/signal_ext.h" 1 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/signal_ext.h" 3 4
extern int tgkill (__pid_t __tgid, __pid_t __tid, int __signal);
# 392 "/usr/include/signal.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/sys/param.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/param.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/param.h" 3 4
# 1 "/usr/include/linux/param.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/asm/param.h" 1 3 4
# 1 "/usr/include/asm-generic/param.h" 1 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/param.h" 2 3 4
# 6 "/usr/include/linux/param.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/param.h" 2 3 4
# 32 "/usr/include/x86_64-linux-gnu/sys/param.h" 2 3 4
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h" 2
# 1 "/usr/include/x86_64-linux-gnu/sys/time.h" 1 3 4
# 52 "/usr/include/x86_64-linux-gnu/sys/time.h" 3 4
struct timezone
  {
    int tz_minuteswest;
    int tz_dsttime;
  };
# 67 "/usr/include/x86_64-linux-gnu/sys/time.h" 3 4
extern int gettimeofday (struct timeval *__restrict __tv,
    void *__restrict __tz) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 86 "/usr/include/x86_64-linux-gnu/sys/time.h" 3 4
extern int settimeofday (const struct timeval *__tv,
    const struct timezone *__tz)
     __attribute__ ((__nothrow__ ));





extern int adjtime (const struct timeval *__delta,
      struct timeval *__olddelta) __attribute__ ((__nothrow__ ));
# 114 "/usr/include/x86_64-linux-gnu/sys/time.h" 3 4
enum __itimer_which
  {

    ITIMER_REAL = 0,


    ITIMER_VIRTUAL = 1,



    ITIMER_PROF = 2

  };



struct itimerval
  {

    struct timeval it_interval;

    struct timeval it_value;
  };




typedef enum __itimer_which __itimer_which_t;







extern int getitimer (__itimer_which_t __which,
        struct itimerval *__value) __attribute__ ((__nothrow__ ));




extern int setitimer (__itimer_which_t __which,
        const struct itimerval *__restrict __new,
        struct itimerval *__restrict __old) __attribute__ ((__nothrow__ ));




extern int utimes (const char *__file, const struct timeval __tvp[2])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 189 "/usr/include/x86_64-linux-gnu/sys/time.h" 3 4
extern int lutimes (const char *__file, const struct timeval __tvp[2])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int futimes (int __fd, const struct timeval __tvp[2]) __attribute__ ((__nothrow__ ));
# 214 "/usr/include/x86_64-linux-gnu/sys/time.h" 3 4
extern int futimesat (int __fd, const char *__file,
        const struct timeval __tvp[2]) __attribute__ ((__nothrow__ ));
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h" 2


typedef int GIT_SOCKET;
# 45 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h"
extern char *p_realpath(const char *, char *);

static __inline__ int p_fsync(int fd)
{
 p_fsync__cnt++;
 return fsync(fd);
}
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/unix/posix.h"
static __inline__ int p_futimes(int f, const struct timeval t[2])
{
 struct timespec s[2];
 s[0].tv_sec = t[0].tv_sec;
 s[0].tv_nsec = t[0].tv_usec * 1000;
 s[1].tv_sec = t[1].tv_sec;
 s[1].tv_nsec = t[1].tv_usec * 1000;
 return futimens(f, s);
}
# 158 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/strnlen.h" 1
# 161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h" 2
# 199 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h"
# 1 "/usr/include/poll.h" 1 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/poll.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/sys/poll.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/poll.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/sys/poll.h" 2 3 4







typedef unsigned long int nfds_t;


struct pollfd
  {
    int fd;
    short int events;
    short int revents;
  };
# 54 "/usr/include/x86_64-linux-gnu/sys/poll.h" 3 4
extern int poll (struct pollfd *__fds, nfds_t __nfds, int __timeout)
                                                  ;
# 64 "/usr/include/x86_64-linux-gnu/sys/poll.h" 3 4
extern int ppoll (struct pollfd *__fds, nfds_t __nfds,
    const struct timespec *__timeout,
    const __sigset_t *__ss)
                                                  ;
# 2 "/usr/include/poll.h" 2 3 4
# 200 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/posix.h" 2
# 112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 171 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h" 2

struct git_str {
 char *ptr;
 size_t asize;
 size_t size;
};

typedef enum {
 GIT_STR_BOM_NONE = 0,
 GIT_STR_BOM_UTF8 = 1,
 GIT_STR_BOM_UTF16_LE = 2,
 GIT_STR_BOM_UTF16_BE = 3,
 GIT_STR_BOM_UTF32_LE = 4,
 GIT_STR_BOM_UTF32_BE = 5
} git_str_bom_t;

typedef struct {
 git_str_bom_t bom;
 unsigned int nul, cr, lf, crlf;
 unsigned int printable, nonprintable;
} git_str_text_stats;

extern char git_str__initstr[];
extern char git_str__oom[];
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
static __inline__ _Bool git_str_is_allocated(const git_str *str)
{
 return (str->ptr != ((void*)0) && str->asize > 0);
}







extern int git_str_init(git_str *str, size_t initial_size);

extern void git_str_dispose(git_str *str);
# 78 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
int git_str_grow(git_str *str, size_t target_size);
# 90 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
extern int git_str_grow_by(git_str *str, size_t additional_size);
# 103 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
extern int git_str_try_grow(
 git_str *str, size_t target_size, _Bool mark_oom);

extern void git_str_swap(git_str *str_a, git_str *str_b);
extern char *git_str_detach(git_str *str);
extern int git_str_attach(git_str *str, char *ptr, size_t asize);




extern void git_str_attach_notowned(
 git_str *str, const char *ptr, size_t size);
# 127 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
static __inline__ _Bool git_str_oom(const git_str *str)
{
 return (str->ptr == git_str__oom);
}
# 141 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
int git_str_set(git_str *str, const void *data, size_t datalen);

int git_str_sets(git_str *str, const char *string);
int git_str_putc(git_str *str, char c);
int git_str_putcn(git_str *str, char c, size_t len);
int git_str_put(git_str *str, const char *data, size_t len);
int git_str_puts(git_str *str, const char *string);
int git_str_printf(git_str *str, const char *format, ...) __attribute__((format (printf, 2, 3)));
int git_str_vprintf(git_str *str, const char *format, va_list ap);
void git_str_clear(git_str *str);
void git_str_consume_bytes(git_str *str, size_t len);
void git_str_consume(git_str *str, const char *end);
void git_str_truncate(git_str *str, size_t len);
void git_str_shorten(git_str *str, size_t amount);
void git_str_truncate_at_char(git_str *path, char separator);
void git_str_rtruncate_at_char(git_str *path, char separator);


int git_str_join_n(git_str *str, char separator, int len, ...);

int git_str_join(git_str *str, char separator, const char *str_a, const char *str_b);

int git_str_join3(git_str *str, char separator, const char *str_a, const char *str_b, const char *str_c);





static __inline__ int git_str_joinpath(git_str *str, const char *a, const char *b)
{
 return git_str_join(str, '/', a, b);
}

static __inline__ const char * git_str_cstr(const git_str *str)
{
 return str->ptr;
}

static __inline__ size_t git_str_len(const git_str *str)
{
 return str->size;
}

int git_str_copy_cstr(char *data, size_t datasize, const git_str *str);



static __inline__ ssize_t git_str_rfind_next(const git_str *str, char ch)
{
 ssize_t idx = (ssize_t)str->size - 1;
 while (idx >= 0 && str->ptr[idx] == ch) idx--;
 while (idx >= 0 && str->ptr[idx] != ch) idx--;
 return idx;
}

static __inline__ ssize_t git_str_rfind(const git_str *str, char ch)
{
 ssize_t idx = (ssize_t)str->size - 1;
 while (idx >= 0 && str->ptr[idx] != ch) idx--;
 return idx;
}

static __inline__ ssize_t git_str_find(const git_str *str, char ch)
{
 void *found = memchr(str->ptr, ch, str->size);
 return found ? (ssize_t)((const char *)found - str->ptr) : -1;
}


void git_str_rtrim(git_str *str);

int git_str_cmp(const git_str *a, const git_str *b);




int git_str_quote(git_str *str);
int git_str_unquote(git_str *str);


int git_str_encode_hexstr(git_str *str, const char *data, size_t len);


int git_str_encode_base64(git_str *str, const char *data, size_t len);

int git_str_decode_base64(git_str *str, const char *base64, size_t len);


int git_str_encode_base85(git_str *str, const char *data, size_t len);

int git_str_decode_base85(git_str *str, const char *base64, size_t len, size_t output_len);





int git_str_decode_percent(git_str *str, const char *encoded, size_t len);
# 257 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
int git_str_splice(
 git_str *str,
 size_t where,
 size_t nb_to_remove,
 const char *data,
 size_t nb_to_insert);
# 274 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
extern int git_str_puts_escaped(
 git_str *str,
 const char *string,
 const char *esc_chars,
 const char *esc_with);




static __inline__ int git_str_puts_escape_regex(git_str *str, const char *string)
{
 return git_str_puts_escaped(str, string, "^.[]$()|*+?{}\\", "\\");
}






extern void git_str_unescape(git_str *str);






extern int git_str_crlf_to_lf(git_str *tgt, const git_str *src);






extern int git_str_lf_to_crlf(git_str *tgt, const git_str *src);






extern int git_str_common_prefix(git_str *buf, char *const *const strings, size_t count);
# 323 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
extern int git_str_detect_bom(git_str_bom_t *bom, const git_str *str);
# 338 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/str.h"
extern _Bool git_str_gather_text_stats(
 git_str_text_stats *stats, const git_str *str, _Bool skip_bom);







int git_str_is_binary(const git_str *str);







int git_str_contains_nul(const git_str *str);
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h" 2




# 1 "/usr/include/ctype.h" 1 3 4
# 46 "/usr/include/ctype.h" 3 4
enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};
# 79 "/usr/include/ctype.h" 3 4
extern const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
# 108 "/usr/include/ctype.h" 3 4
extern int isalnum (int) __attribute__ ((__nothrow__ ));
extern int isalpha (int) __attribute__ ((__nothrow__ ));
extern int iscntrl (int) __attribute__ ((__nothrow__ ));
extern int isdigit (int) __attribute__ ((__nothrow__ ));
extern int islower (int) __attribute__ ((__nothrow__ ));
extern int isgraph (int) __attribute__ ((__nothrow__ ));
extern int isprint (int) __attribute__ ((__nothrow__ ));
extern int ispunct (int) __attribute__ ((__nothrow__ ));
extern int isspace (int) __attribute__ ((__nothrow__ ));
extern int isupper (int) __attribute__ ((__nothrow__ ));
extern int isxdigit (int) __attribute__ ((__nothrow__ ));



extern int tolower (int __c) __attribute__ ((__nothrow__ ));


extern int toupper (int __c) __attribute__ ((__nothrow__ ));




extern int isblank (int) __attribute__ ((__nothrow__ ));




extern int isctype (int __c, int __mask) __attribute__ ((__nothrow__ ));






extern int isascii (int __c) __attribute__ ((__nothrow__ ));



extern int toascii (int __c) __attribute__ ((__nothrow__ ));



extern int _toupper (int) __attribute__ ((__nothrow__ ));
extern int _tolower (int) __attribute__ ((__nothrow__ ));
# 251 "/usr/include/ctype.h" 3 4
extern int isalnum_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isalpha_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int iscntrl_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isdigit_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int islower_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isgraph_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isprint_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int ispunct_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isspace_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isupper_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isxdigit_l (int, locale_t) __attribute__ ((__nothrow__ ));

extern int isblank_l (int, locale_t) __attribute__ ((__nothrow__ ));



extern int __tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
extern int tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));


extern int __toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
extern int toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h" 2
# 55 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h"
extern int git__prefixcmp(const char *str, const char *prefix);
extern int git__prefixcmp_icase(const char *str, const char *prefix);
extern int git__prefixncmp(const char *str, size_t str_n, const char *prefix);
extern int git__prefixncmp_icase(const char *str, size_t str_n, const char *prefix);
extern int git__suffixcmp(const char *str, const char *suffix);

static __inline__ int git__signum(int val)
{
 return ((val > 0) - (val < 0));
}

extern int git__strntol32(int32_t *n, const char *buff, size_t buff_len, const char **end_buf, int base);
extern int git__strntol64(int64_t *n, const char *buff, size_t buff_len, const char **end_buf, int base);


extern void git__hexdump(const char *buffer, size_t n);
extern uint32_t git__hash(const void *key, int len, uint32_t seed);
# 80 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h"
extern char *git__strtok(char **end, const char *sep);
extern char *git__strsep(char **end, const char *sep);

extern void git__strntolower(char *str, size_t len);
extern void git__strtolower(char *str);

extern size_t git__linenlen(const char *buffer, size_t buffer_len);

static __inline__ const char * git__next_line(const char *s)
{
 while (*s && *s != '\n') s++;
 while (*s == '\n' || *s == '\r') s++;
 return s;
}

static __inline__ const void * git__memrchr(const void *s, int c, size_t n)
{
 const unsigned char *cp;

 if (n != 0) {
  cp = (unsigned char *)s + n;
  do {
   if (*(--cp) == (unsigned char)c)
    return cp;
  } while (--n != 0);
 }

 return ((void*)0);
}

extern const void * git__memmem(const void *haystack, size_t haystacklen,
    const void *needle, size_t needlelen);

typedef int (*git__tsort_cmp)(const void *a, const void *b);

extern void git__tsort(void **dst, size_t size, git__tsort_cmp cmp);

typedef int (*git__sort_r_cmp)(const void *a, const void *b, void *payload);

extern void git__tsort_r(
 void **dst, size_t size, git__sort_r_cmp cmp, void *payload);

extern void git__qsort_r(
 void *els, size_t nel, size_t elsize, git__sort_r_cmp cmp, void *payload);






extern int git__bsearch(
 void **array,
 size_t array_len,
 const void *key,
 int (*compare)(const void *key, const void *element),
 size_t *position);

extern int git__bsearch_r(
 void **array,
 size_t array_len,
 const void *key,
 int (*compare_r)(const void *key, const void *element, void *payload),
 void *payload,
 size_t *position);




extern int git__strcmp_cb(const void *a, const void *b);
extern int git__strcasecmp_cb(const void *a, const void *b);

extern int git__strcasecmp(const char *a, const char *b);
extern int git__strncasecmp(const char *a, const char *b, size_t sz);

extern int git__strcasesort_cmp(const char *a, const char *b);






static __inline__ int git__strlcmp(const char *a, const char *b, size_t b_len)
{
 int cmp = strncmp(a, b, b_len);
 return cmp ? cmp : (int)a[b_len];
}

typedef struct {
 git_atomic32 refcount;
 void *owner;
} git_refcount;

typedef void (*git_refcount_freeptr)(void *r);
# 193 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h"
static signed char from_hex[] = {
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1,
-1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
};

static __inline__ int git__fromhex(char h)
{
 return from_hex[(unsigned char) h];
}

static __inline__ int git__ishex(const char *str)
{
 unsigned i;
 for (i=0; str[i] != '\0'; i++)
  if (git__fromhex(str[i]) < 0)
   return 0;
 return 1;
}

static __inline__ size_t git__size_t_bitmask(size_t v)
{
 v--;
 v |= v >> 1;
 v |= v >> 2;
 v |= v >> 4;
 v |= v >> 8;
 v |= v >> 16;

 return v;
}

static __inline__ size_t git__size_t_powerof2(size_t v)
{
 return git__size_t_bitmask(v) + 1;
}

static __inline__ _Bool git__isspace_nonlf(int c)
{
 return (c == ' ' || c == '\t' || c == '\f' || c == '\r' || c == '\v');
}

static __inline__ _Bool git__iswildcard(int c)
{
 return (c == '*' || c == '?' || c == '[');
}







extern int git__parse_bool(int *out, const char *value);
# 268 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h"
extern size_t git__unescape(char *str);





static __inline__ void git__memzero(void *data, size_t size)
{



 volatile uint8_t *scan = (volatile uint8_t *)data;

 while (size--)
  *scan++ = 0x0;

}
# 336 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h"
static __inline__ uint64_t git_time_monotonic(void)
{
 struct timeval tv;


 struct timespec tp;
 if (clock_gettime(1, &tp) == 0)
  return (tp.tv_sec * 1000) + (tp.tv_nsec / 1.0E6);



 gettimeofday(&tv, ((void*)0));
 return (tv.tv_sec * 1000) + (tv.tv_usec / 1000);
}



extern int git__getenv(git_str *out, const char *name);

extern int git__online_cpus(void);

static __inline__ int git__noop(void) { return 0; }
static __inline__ int git__noop_args(void *a, ...) { do { __typeof__(a) _unused __attribute__((unused)); _unused = (a); } while (0); return 0; }

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/alloc.h" 1
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/alloc.h"
typedef struct {

 void * (*gmalloc)(size_t n, const char *file, int line);






 void * (*grealloc)(void *ptr, size_t size, const char *file, int line);





 void (*gfree)(void *ptr);
} git_allocator;
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/alloc.h"
int git_stdalloc_init_allocator(git_allocator *allocator);
# 74 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/alloc.h"
int git_win32_crtdbg_init_allocator(git_allocator *allocator);
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h" 2

extern git_allocator git__allocator;

static __inline__ void * git__malloc(size_t len)
{
 void *p = git__allocator.gmalloc(len, "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h", 19);

 if (!p)
  git_error_set_oom();

 return p;
}

static __inline__ void * git__realloc(void *ptr, size_t size)
{
 void *p = git__allocator.grealloc(ptr, size, "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h", 29);

 if (!p)
  git_error_set_oom();

 return p;
}

static __inline__ void git__free(void *ptr)
{
 git__allocator.gfree(ptr);
}

extern void *git__calloc(size_t nelem, size_t elsize);
extern void *git__mallocarray(size_t nelem, size_t elsize);
extern void *git__reallocarray(void *ptr, size_t nelem, size_t elsize);

extern char *git__strdup(const char *str);
extern char *git__strndup(const char *str, size_t n);
extern char *git__substrdup(const char *str, size_t n);





int git_allocator_global_init(void);
# 63 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/alloc.h"
int git_allocator_setup(git_allocator *allocator);
# 361 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/util.h" 2
# 172 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/ctype_compat.h" 1
# 173 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/git2_util.h" 2
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/common.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/errors.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/errors.h"
int git_error_global_init(void);




void git_error_vset(int error_class, const char *fmt, va_list ap);




_Bool git_error_exists(void);
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/errors.h"
static __inline__ int git_error_set_after_callback_function(
 int error_code, const char *action)
{
 if (error_code) {
  if (!git_error_exists())
   git_error_set(GIT_ERROR_CALLBACK,
    "%s callback returned %d", action, error_code);
 }
 return error_code;
}
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/errors.h"
int git_error_system_last(void);




void git_error_system_set(int code);
# 73 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/errors.h"
extern int git_error_save(git_error **out);





extern int git_error_restore(git_error *error);


extern void git_error_free(git_error *error);
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/common.h" 2





# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h" 1
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
typedef enum {
 GIT_ATTR_VALUE_UNSPECIFIED = 0,
 GIT_ATTR_VALUE_TRUE,
 GIT_ATTR_VALUE_FALSE,
 GIT_ATTR_VALUE_STRING
} git_attr_value_t;
# 106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) git_attr_value_t git_attr_value(const char *attr);
# 154 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
typedef struct {
 unsigned int version;


 unsigned int flags;




 git_oid *commit_id;






 git_oid attr_commit_id;
} git_attr_options;
# 195 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_get(
 const char **value_out,
 git_repository *repo,
 uint32_t flags,
 const char *path,
 const char *name);
# 218 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_get_ext(
 const char **value_out,
 git_repository *repo,
 git_attr_options *opts,
 const char *path,
 const char *name);
# 255 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_get_many(
 const char **values_out,
 git_repository *repo,
 uint32_t flags,
 const char *path,
 size_t num_attr,
 const char **names);
# 280 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_get_many_ext(
 const char **values_out,
 git_repository *repo,
 git_attr_options *opts,
 const char *path,
 size_t num_attr,
 const char **names);
# 304 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
typedef int (*git_attr_foreach_cb)(const char *name, const char *value, void *payload);
# 319 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_foreach(
 git_repository *repo,
 uint32_t flags,
 const char *path,
 git_attr_foreach_cb callback,
 void *payload);
# 339 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_foreach_ext(
 git_repository *repo,
 git_attr_options *opts,
 const char *path,
 git_attr_foreach_cb callback,
 void *payload);
# 357 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_cache_flush(
 git_repository *repo);
# 375 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/attr.h"
extern __attribute__((visibility("default"))) int git_attr_add_macro(
 git_repository *repo,
 const char *name,
 const char *values);
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h" 1
# 49 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
typedef enum {



 GIT_CONFIG_LEVEL_PROGRAMDATA = 1,




 GIT_CONFIG_LEVEL_SYSTEM = 2,





 GIT_CONFIG_LEVEL_XDG = 3,





 GIT_CONFIG_LEVEL_GLOBAL = 4,





 GIT_CONFIG_LEVEL_LOCAL = 5,





 GIT_CONFIG_LEVEL_WORKTREE = 6,





 GIT_CONFIG_LEVEL_APP = 7,
# 97 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
 GIT_CONFIG_HIGHEST_LEVEL = -1
} git_config_level_t;




typedef struct git_config_entry {

 const char *name;


 const char *value;


 const char *backend_type;





 const char *origin_path;


 unsigned int include_depth;


 git_config_level_t level;
} git_config_entry;






extern __attribute__((visibility("default"))) void git_config_entry_free(git_config_entry *entry);
# 140 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
typedef int (*git_config_foreach_cb)(const git_config_entry *entry, void *payload);




typedef struct git_config_iterator git_config_iterator;




typedef enum {
 GIT_CONFIGMAP_FALSE = 0,
 GIT_CONFIGMAP_TRUE = 1,
 GIT_CONFIGMAP_INT32,
 GIT_CONFIGMAP_STRING
} git_configmap_t;




typedef struct {
 git_configmap_t type;
 const char *str_match;
 int map_value;
} git_configmap;
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_find_global(git_buf *out);
# 200 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_find_xdg(git_buf *out);
# 212 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_find_system(git_buf *out);
# 223 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_find_programdata(git_buf *out);
# 235 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_open_default(git_config **out);
# 246 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_new(git_config **out);
# 275 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_add_file_ondisk(
 git_config *cfg,
 const char *path,
 git_config_level_t level,
 const git_repository *repo,
 int force);
# 294 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_open_ondisk(git_config **out, const char *path);
# 312 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_open_level(
 git_config **out,
 const git_config *parent,
 git_config_level_t level);
# 330 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_open_global(git_config **out, git_config *config);
# 343 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_set_writeorder(
 git_config *cfg,
 git_config_level_t *levels,
 size_t len);
# 362 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_snapshot(git_config **out, git_config *config);






extern __attribute__((visibility("default"))) void git_config_free(git_config *cfg);
# 381 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_entry(
 git_config_entry **out,
 const git_config *cfg,
 const char *name);
# 398 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_int32(int32_t *out, const git_config *cfg, const char *name);
# 412 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_int64(int64_t *out, const git_config *cfg, const char *name);
# 429 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_bool(int *out, const git_config *cfg, const char *name);
# 447 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_path(git_buf *out, const git_config *cfg, const char *name);
# 465 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_string(const char **out, const git_config *cfg, const char *name);
# 481 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_string_buf(git_buf *out, const git_config *cfg, const char *name);
# 500 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_multivar_foreach(const git_config *cfg, const char *name, const char *regexp, git_config_foreach_cb callback, void *payload);
# 516 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_multivar_iterator_new(git_config_iterator **out, const git_config *cfg, const char *name, const char *regexp);
# 528 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_next(git_config_entry **entry, git_config_iterator *iter);






extern __attribute__((visibility("default"))) void git_config_iterator_free(git_config_iterator *iter);
# 546 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_set_int32(git_config *cfg, const char *name, int32_t value);
# 557 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_set_int64(git_config *cfg, const char *name, int64_t value);
# 568 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_set_bool(git_config *cfg, const char *name, int value);
# 582 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_set_string(git_config *cfg, const char *name, const char *value);
# 595 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_set_multivar(git_config *cfg, const char *name, const char *regexp, const char *value);
# 605 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_delete_entry(git_config *cfg, const char *name);
# 618 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_delete_multivar(git_config *cfg, const char *name, const char *regexp);
# 636 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_foreach(
 const git_config *cfg,
 git_config_foreach_cb callback,
 void *payload);
# 651 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_iterator_new(git_config_iterator **out, const git_config *cfg);
# 668 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_iterator_glob_new(git_config_iterator **out, const git_config *cfg, const char *regexp);
# 690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_foreach_match(
 const git_config *cfg,
 const char *regexp,
 git_config_foreach_cb callback,
 void *payload);
# 730 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_get_mapped(
 int *out,
 const git_config *cfg,
 const char *name,
 const git_configmap *maps,
 size_t map_n);
# 746 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_lookup_map_value(
 int *out,
 const git_configmap *maps,
 size_t map_n,
 const char *value);
# 763 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_parse_bool(int *out, const char *value);
# 776 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_parse_int32(int32_t *out, const char *value);
# 789 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_parse_int64(int64_t *out, const char *value);
# 805 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_parse_path(git_buf *out, const char *value);
# 824 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_backend_foreach_match(
 git_config_backend *backend,
 const char *regexp,
 git_config_foreach_cb callback,
 void *payload);
# 847 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/config.h"
extern __attribute__((visibility("default"))) int git_config_lock(git_transaction **tx, git_config *cfg);
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h" 1
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
typedef enum {

 GIT_BLAME_NORMAL = 0,






 GIT_BLAME_TRACK_COPIES_SAME_FILE = (1<<0),







 GIT_BLAME_TRACK_COPIES_SAME_COMMIT_MOVES = (1<<1),







 GIT_BLAME_TRACK_COPIES_SAME_COMMIT_COPIES = (1<<2),







 GIT_BLAME_TRACK_COPIES_ANY_COMMIT_COPIES = (1<<3),





 GIT_BLAME_FIRST_PARENT = (1<<4),







 GIT_BLAME_USE_MAILMAP = (1<<5),


 GIT_BLAME_IGNORE_WHITESPACE = (1<<6)
} git_blame_flag_t;
# 91 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
typedef struct git_blame_options {
 unsigned int version;


 unsigned int flags;
# 106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
 uint16_t min_match_characters;


 git_oid newest_commit;





 git_oid oldest_commit;





 size_t min_line;





 size_t max_line;
} git_blame_options;
# 146 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) int git_blame_options_init(
 git_blame_options *opts,
 unsigned int version);




typedef struct git_blame_hunk {



 size_t lines_in_hunk;




 git_oid final_commit_id;





 size_t final_start_line_number;





 git_signature *final_signature;






 git_signature *final_committer;






 git_oid orig_commit_id;





 const char *orig_path;





 size_t orig_start_line_number;





 git_signature *orig_signature;






 git_signature *orig_committer;




 const char *summary;





 char boundary;
} git_blame_hunk;




typedef struct git_blame_line {
 const char *ptr;
 size_t len;
} git_blame_line;


typedef struct git_blame git_blame;







extern __attribute__((visibility("default"))) size_t git_blame_linecount(git_blame *blame);







extern __attribute__((visibility("default"))) size_t git_blame_hunkcount(git_blame *blame);
# 261 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) const git_blame_hunk * git_blame_hunk_byindex(
 git_blame *blame,
 size_t index);
# 273 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) const git_blame_hunk * git_blame_hunk_byline(
 git_blame *blame,
 size_t lineno);
# 284 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) const git_blame_line * git_blame_line_byindex(
 git_blame *blame,
 size_t idx);
# 296 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) uint32_t git_blame_get_hunk_count(git_blame *blame);
# 305 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) const git_blame_hunk * git_blame_get_hunk_byindex(
 git_blame *blame,
 uint32_t index);
# 316 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) const git_blame_hunk * git_blame_get_hunk_byline(
 git_blame *blame,
 size_t lineno);
# 330 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) int git_blame_file(
 git_blame **out,
 git_repository *repo,
 const char *path,
 git_blame_options *options);
# 349 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) int git_blame_file_from_buffer(
 git_blame **out,
 git_repository *repo,
 const char *path,
 const char *contents,
 size_t contents_len,
 git_blame_options *options);
# 374 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blame.h"
extern __attribute__((visibility("default"))) int git_blame_buffer(
 git_blame **out,
 git_blame *base,
 const char *buffer,
 size_t buffer_len);






extern __attribute__((visibility("default"))) void git_blame_free(git_blame *blame);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h" 1
# 45 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_lookup(
  git_object **object,
  git_repository *repo,
  const git_oid *id,
  git_object_t type);
# 78 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_lookup_prefix(
  git_object **object_out,
  git_repository *repo,
  const git_oid *id,
  size_t len,
  git_object_t type);
# 96 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_lookup_bypath(
  git_object **out,
  const git_object *treeish,
  const char *path,
  git_object_t type);







extern __attribute__((visibility("default"))) const git_oid * git_object_id(const git_object *obj);
# 122 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_short_id(git_buf *out, const git_object *obj);







extern __attribute__((visibility("default"))) git_object_t git_object_type(const git_object *obj);
# 144 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) git_repository * git_object_owner(const git_object *obj);
# 161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) void git_object_free(git_object *object);
# 172 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) const char * git_object_type2string(git_object_t type);







extern __attribute__((visibility("default"))) git_object_t git_object_string2type(const char *str);
# 189 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_typeisloose(git_object_t type);
# 214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_peel(
 git_object **peeled,
 const git_object *object,
 git_object_t target_type);
# 227 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_dup(git_object **dest, git_object *source);
# 270 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/object.h"
extern __attribute__((visibility("default"))) int git_object_rawcontent_is_valid(
 int *valid,
 const char *buf,
 size_t len,
 git_object_t object_type);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h" 2
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_lookup(
 git_tree **out, git_repository *repo, const git_oid *id);
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_lookup_prefix(
 git_tree **out,
 git_repository *repo,
 const git_oid *id,
 size_t len);
# 63 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) void git_tree_free(git_tree *tree);







extern __attribute__((visibility("default"))) const git_oid * git_tree_id(const git_tree *tree);







extern __attribute__((visibility("default"))) git_repository * git_tree_owner(const git_tree *tree);







extern __attribute__((visibility("default"))) size_t git_tree_entrycount(const git_tree *tree);
# 99 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) const git_tree_entry * git_tree_entry_byname(
 const git_tree *tree, const char *filename);
# 112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) const git_tree_entry * git_tree_entry_byindex(
 const git_tree *tree, size_t idx);
# 127 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) const git_tree_entry * git_tree_entry_byid(
 const git_tree *tree, const git_oid *id);
# 142 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_entry_bypath(
 git_tree_entry **out,
 const git_tree *root,
 const char *path);
# 157 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_entry_dup(git_tree_entry **dest, const git_tree_entry *source);
# 168 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) void git_tree_entry_free(git_tree_entry *entry);







extern __attribute__((visibility("default"))) const char * git_tree_entry_name(const git_tree_entry *entry);







extern __attribute__((visibility("default"))) const git_oid * git_tree_entry_id(const git_tree_entry *entry);







extern __attribute__((visibility("default"))) git_object_t git_tree_entry_type(const git_tree_entry *entry);







extern __attribute__((visibility("default"))) git_filemode_t git_tree_entry_filemode(const git_tree_entry *entry);
# 212 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) git_filemode_t git_tree_entry_filemode_raw(const git_tree_entry *entry);







extern __attribute__((visibility("default"))) int git_tree_entry_cmp(const git_tree_entry *e1, const git_tree_entry *e2);
# 232 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_entry_to_object(
 git_object **object_out,
 git_repository *repo,
 const git_tree_entry *entry);
# 254 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_treebuilder_new(
 git_treebuilder **out, git_repository *repo, const git_tree *source);







extern __attribute__((visibility("default"))) int git_treebuilder_clear(git_treebuilder *bld);







extern __attribute__((visibility("default"))) size_t git_treebuilder_entrycount(git_treebuilder *bld);
# 282 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) void git_treebuilder_free(git_treebuilder *bld);
# 294 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) const git_tree_entry * git_treebuilder_get(
 git_treebuilder *bld, const char *filename);
# 325 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_treebuilder_insert(
 const git_tree_entry **out,
 git_treebuilder *bld,
 const char *filename,
 const git_oid *id,
 git_filemode_t filemode);
# 339 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_treebuilder_remove(
 git_treebuilder *bld, const char *filename);
# 353 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
typedef int (*git_treebuilder_filter_cb)(
 const git_tree_entry *entry, void *payload);
# 368 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_treebuilder_filter(
 git_treebuilder *bld,
 git_treebuilder_filter_cb filter,
 void *payload);
# 383 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_treebuilder_write(
 git_oid *id, git_treebuilder *bld);
# 394 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
typedef int (*git_treewalk_cb)(
 const char *root, const git_tree_entry *entry, void *payload);


typedef enum {
 GIT_TREEWALK_PRE = 0,
 GIT_TREEWALK_POST = 1
} git_treewalk_mode;
# 420 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_walk(
 const git_tree *tree,
 git_treewalk_mode mode,
 git_treewalk_cb callback,
 void *payload);
# 434 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_dup(git_tree **out, git_tree *source);




typedef enum {

 GIT_TREE_UPDATE_UPSERT,

 GIT_TREE_UPDATE_REMOVE
} git_tree_update_t;




typedef struct {

 git_tree_update_t action;

 git_oid id;

 git_filemode_t filemode;

 const char *path;
} git_tree_update;
# 481 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tree.h"
extern __attribute__((visibility("default"))) int git_tree_create_updated(git_oid *out, git_repository *repo, git_tree *baseline, size_t nupdates, const git_tree_update *updates);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/strarray.h" 1
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/strarray.h"
typedef struct git_strarray {
 char **strings;
 size_t count;
} git_strarray;
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/strarray.h"
extern __attribute__((visibility("default"))) void git_strarray_dispose(git_strarray *array);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h" 2
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_lookup(git_reference **out, git_repository *repo, const char *name);
# 54 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_name_to_id(
 git_oid *out, git_repository *repo, const char *name);
# 68 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_dwim(git_reference **out, git_repository *repo, const char *shorthand);
# 112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_symbolic_create_matching(git_reference **out, git_repository *repo, const char *name, const char *target, int force, const char *current_value, const char *log_message);
# 148 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_symbolic_create(git_reference **out, git_repository *repo, const char *name, const char *target, int force, const char *log_message);
# 185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_create(git_reference **out, git_repository *repo, const char *name, const git_oid *id, int force, const char *log_message);
# 228 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_create_matching(git_reference **out, git_repository *repo, const char *name, const git_oid *id, int force, const git_oid *current_id, const char *log_message);
# 243 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) const git_oid * git_reference_target(const git_reference *ref);
# 254 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) const git_oid * git_reference_target_peel(const git_reference *ref);
# 264 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) const char * git_reference_symbolic_target(const git_reference *ref);
# 274 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) git_reference_t git_reference_type(const git_reference *ref);
# 284 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) const char * git_reference_name(const git_reference *ref);
# 302 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_resolve(git_reference **out, const git_reference *ref);







extern __attribute__((visibility("default"))) git_repository * git_reference_owner(const git_reference *ref);
# 332 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_symbolic_set_target(
 git_reference **out,
 git_reference *ref,
 const char *target,
 const char *log_message);
# 352 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_set_target(
 git_reference **out,
 git_reference *ref,
 const git_oid *id,
 const char *log_message);
# 382 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_rename(
 git_reference **new_ref,
 git_reference *ref,
 const char *new_name,
 int force,
 const char *log_message);
# 402 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_delete(git_reference *ref);
# 414 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_remove(git_repository *repo, const char *name);
# 428 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_list(git_strarray *array, git_repository *repo);
# 439 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
typedef int (*git_reference_foreach_cb)(git_reference *reference, void *payload);
# 450 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
typedef int (*git_reference_foreach_name_cb)(const char *name, void *payload);
# 468 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_foreach(
 git_repository *repo,
 git_reference_foreach_cb callback,
 void *payload);
# 486 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_foreach_name(
 git_repository *repo,
 git_reference_foreach_name_cb callback,
 void *payload);
# 500 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_dup(git_reference **dest, git_reference *source);






extern __attribute__((visibility("default"))) void git_reference_free(git_reference *ref);
# 516 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_cmp(
 const git_reference *ref1,
 const git_reference *ref2);
# 527 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_iterator_new(
 git_reference_iterator **out,
 git_repository *repo);
# 540 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_iterator_glob_new(
 git_reference_iterator **out,
 git_repository *repo,
 const char *glob);
# 552 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_next(git_reference **out, git_reference_iterator *iter);
# 565 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_next_name(const char **out, git_reference_iterator *iter);






extern __attribute__((visibility("default"))) void git_reference_iterator_free(git_reference_iterator *iter);
# 592 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_foreach_glob(
 git_repository *repo,
 const char *glob,
 git_reference_foreach_name_cb callback,
 void *payload);
# 606 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_has_log(git_repository *repo, const char *refname);
# 618 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_ensure_log(git_repository *repo, const char *refname);
# 628 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_is_branch(const git_reference *ref);
# 638 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_is_remote(const git_reference *ref);
# 648 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_is_tag(const git_reference *ref);
# 658 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_is_note(const git_reference *ref);




typedef enum {



 GIT_REFERENCE_FORMAT_NORMAL = 0u,







 GIT_REFERENCE_FORMAT_ALLOW_ONELEVEL = (1u << 0),
# 684 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
 GIT_REFERENCE_FORMAT_REFSPEC_PATTERN = (1u << 1),






 GIT_REFERENCE_FORMAT_REFSPEC_SHORTHAND = (1u << 2)
} git_reference_format_t;
# 714 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_normalize_name(
 char *buffer_out,
 size_t buffer_size,
 const char *name,
 unsigned int flags);
# 735 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_peel(
 git_object **out,
 const git_reference *ref,
 git_object_t type);
# 755 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) int git_reference_name_is_valid(int *valid, const char *refname);
# 769 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refs.h"
extern __attribute__((visibility("default"))) const char * git_reference_shorthand(const git_reference *ref);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h" 2
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef enum {

 GIT_DIFF_NORMAL = 0,






 GIT_DIFF_REVERSE = (1u << 0),


 GIT_DIFF_INCLUDE_IGNORED = (1u << 1),





 GIT_DIFF_RECURSE_IGNORED_DIRS = (1u << 2),


 GIT_DIFF_INCLUDE_UNTRACKED = (1u << 3),






 GIT_DIFF_RECURSE_UNTRACKED_DIRS = (1u << 4),


 GIT_DIFF_INCLUDE_UNMODIFIED = (1u << 5),





 GIT_DIFF_INCLUDE_TYPECHANGE = (1u << 6),






 GIT_DIFF_INCLUDE_TYPECHANGE_TREES = (1u << 7),


 GIT_DIFF_IGNORE_FILEMODE = (1u << 8),


 GIT_DIFF_IGNORE_SUBMODULES = (1u << 9),


 GIT_DIFF_IGNORE_CASE = (1u << 10),




 GIT_DIFF_INCLUDE_CASECHANGE = (1u << 11),
# 95 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 GIT_DIFF_DISABLE_PATHSPEC_MATCH = (1u << 12),





 GIT_DIFF_SKIP_BINARY_CHECK = (1u << 13),
# 111 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 GIT_DIFF_ENABLE_FAST_UNTRACKED_DIRS = (1u << 14),






 GIT_DIFF_UPDATE_INDEX = (1u << 15),


 GIT_DIFF_INCLUDE_UNREADABLE = (1u << 16),


 GIT_DIFF_INCLUDE_UNREADABLE_AS_UNTRACKED = (1u << 17),
# 134 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 GIT_DIFF_INDENT_HEURISTIC = (1u << 18),


 GIT_DIFF_IGNORE_BLANK_LINES = (1u << 19),


 GIT_DIFF_FORCE_TEXT = (1u << 20),

 GIT_DIFF_FORCE_BINARY = (1u << 21),


 GIT_DIFF_IGNORE_WHITESPACE = (1u << 22),

 GIT_DIFF_IGNORE_WHITESPACE_CHANGE = (1u << 23),

 GIT_DIFF_IGNORE_WHITESPACE_EOL = (1u << 24),






 GIT_DIFF_SHOW_UNTRACKED_CONTENT = (1u << 25),






 GIT_DIFF_SHOW_UNMODIFIED = (1u << 26),


 GIT_DIFF_PATIENCE = (1u << 28),

 GIT_DIFF_MINIMAL = (1u << 29),




 GIT_DIFF_SHOW_BINARY = (1u << 30)
} git_diff_option_t;
# 196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct git_diff git_diff;
# 206 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef enum {
 GIT_DIFF_FLAG_BINARY = (1u << 0),
 GIT_DIFF_FLAG_NOT_BINARY = (1u << 1),
 GIT_DIFF_FLAG_VALID_ID = (1u << 2),
 GIT_DIFF_FLAG_EXISTS = (1u << 3),
 GIT_DIFF_FLAG_VALID_SIZE = (1u << 4)
} git_diff_flag_t;
# 224 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef enum {
 GIT_DELTA_UNMODIFIED = 0,
 GIT_DELTA_ADDED = 1,
 GIT_DELTA_DELETED = 2,
 GIT_DELTA_MODIFIED = 3,
 GIT_DELTA_RENAMED = 4,
 GIT_DELTA_COPIED = 5,
 GIT_DELTA_IGNORED = 6,
 GIT_DELTA_UNTRACKED = 7,
 GIT_DELTA_TYPECHANGE = 8,
 GIT_DELTA_UNREADABLE = 9,
 GIT_DELTA_CONFLICTED = 10
} git_delta_t;
# 245 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct {





 git_oid id;





 const char *path;




 git_object_size_t size;




 uint32_t flags;





 uint16_t mode;







 uint16_t id_abbrev;
} git_diff_file;
# 324 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct {
 git_delta_t status;
 uint32_t flags;
 uint16_t similarity;
 uint16_t nfiles;
 git_diff_file old_file;
 git_diff_file new_file;
} git_diff_delta;
# 352 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef int (*git_diff_notify_cb)(
 const git_diff *diff_so_far,
 const git_diff_delta *delta_to_add,
 const char *matched_pathspec,
 void *payload);
# 369 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef int (*git_diff_progress_cb)(
 const git_diff *diff_so_far,
 const char *old_path,
 const char *new_path,
 void *payload);
# 383 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct {
 unsigned int version;





 uint32_t flags;




 git_submodule_ignore_t ignore_submodules;





 git_strarray pathspec;





 git_diff_notify_cb notify_cb;





 git_diff_progress_cb progress_cb;


 void *payload;







 uint32_t context_lines;




 uint32_t interhunk_lines;
# 445 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 git_oid_t oid_type;





 uint16_t id_abbrev;






 git_off_t max_size;





 const char *old_prefix;





 const char *new_prefix;
} git_diff_options;
# 492 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_options_init(
 git_diff_options *opts,
 unsigned int version);
# 504 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef int (*git_diff_file_cb)(
 const git_diff_delta *delta,
 float progress,
 void *payload);
# 518 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef enum {

 GIT_DIFF_BINARY_NONE,


 GIT_DIFF_BINARY_LITERAL,


 GIT_DIFF_BINARY_DELTA
} git_diff_binary_t;


typedef struct {

 git_diff_binary_t type;


 const char *data;


 size_t datalen;


 size_t inflatedlen;
} git_diff_binary_file;
# 553 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct {
# 562 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 unsigned int contains_data;
 git_diff_binary_file old_file;
 git_diff_binary_file new_file;
} git_diff_binary;
# 576 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef int (*git_diff_binary_cb)(
 const git_diff_delta *delta,
 const git_diff_binary *binary,
 void *payload);
# 590 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct {
 int old_start;
 int old_lines;
 int new_start;
 int new_lines;
 size_t header_len;
 char header[128];
} git_diff_hunk;
# 607 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef int (*git_diff_hunk_cb)(
 const git_diff_delta *delta,
 const git_diff_hunk *hunk,
 void *payload);
# 621 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef enum {

 GIT_DIFF_LINE_CONTEXT = ' ',
 GIT_DIFF_LINE_ADDITION = '+',
 GIT_DIFF_LINE_DELETION = '-',

 GIT_DIFF_LINE_CONTEXT_EOFNL = '=',
 GIT_DIFF_LINE_ADD_EOFNL = '>',
 GIT_DIFF_LINE_DEL_EOFNL = '<',




 GIT_DIFF_LINE_FILE_HDR = 'F',
 GIT_DIFF_LINE_HUNK_HDR = 'H',
 GIT_DIFF_LINE_BINARY = 'B'
} git_diff_line_t;
# 650 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct {
 char origin;
 int old_lineno;
 int new_lineno;
 int num_lines;
 size_t content_len;
 git_off_t content_offset;
 const char *content;
} git_diff_line;
# 674 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef int (*git_diff_line_cb)(
 const git_diff_delta *delta,
 const git_diff_hunk *hunk,
 const git_diff_line *line,
 void *payload);




typedef enum {

 GIT_DIFF_FIND_BY_CONFIG = 0,


 GIT_DIFF_FIND_RENAMES = (1u << 0),


 GIT_DIFF_FIND_RENAMES_FROM_REWRITES = (1u << 1),


 GIT_DIFF_FIND_COPIES = (1u << 2),






 GIT_DIFF_FIND_COPIES_FROM_UNMODIFIED = (1u << 3),


 GIT_DIFF_FIND_REWRITES = (1u << 4),

 GIT_DIFF_BREAK_REWRITES = (1u << 5),

 GIT_DIFF_FIND_AND_BREAK_REWRITES =
  (GIT_DIFF_FIND_REWRITES | GIT_DIFF_BREAK_REWRITES),







 GIT_DIFF_FIND_FOR_UNTRACKED = (1u << 6),


 GIT_DIFF_FIND_ALL = (0x0ff),


 GIT_DIFF_FIND_IGNORE_LEADING_WHITESPACE = 0,

 GIT_DIFF_FIND_IGNORE_WHITESPACE = (1u << 12),

 GIT_DIFF_FIND_DONT_IGNORE_WHITESPACE = (1u << 13),

 GIT_DIFF_FIND_EXACT_MATCH_ONLY = (1u << 14),
# 742 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 GIT_DIFF_BREAK_REWRITES_FOR_RENAMES_ONLY = (1u << 15),
# 751 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 GIT_DIFF_FIND_REMOVE_UNMODIFIED = (1u << 16)
} git_diff_find_t;




typedef struct {
 int (*file_signature)(
  void **out, const git_diff_file *file,
  const char *fullpath, void *payload);
 int (*buffer_signature)(
  void **out, const git_diff_file *file,
  const char *buf, size_t buflen, void *payload);
 void (*free_signature)(void *sig, void *payload);
 int (*similarity)(int *score, void *siga, void *sigb, void *payload);
 void *payload;
} git_diff_similarity_metric;






typedef struct {
 unsigned int version;






 uint32_t flags;





 uint16_t rename_threshold;





 uint16_t rename_from_rewrite_threshold;





 uint16_t copy_threshold;





 uint16_t break_rewrite_threshold;
# 815 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 size_t rename_limit;
# 827 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
 git_diff_similarity_metric *metric;
} git_diff_find_options;
# 846 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_find_options_init(
 git_diff_find_options *opts,
 unsigned int version);
# 862 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) void git_diff_free(git_diff *diff);
# 881 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_tree_to_tree(
 git_diff **diff,
 git_repository *repo,
 git_tree *old_tree,
 git_tree *new_tree,
 const git_diff_options *opts);
# 908 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_tree_to_index(
 git_diff **diff,
 git_repository *repo,
 git_tree *old_tree,
 git_index *index,
 const git_diff_options *opts);
# 936 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_index_to_workdir(
 git_diff **diff,
 git_repository *repo,
 git_index *index,
 const git_diff_options *opts);
# 966 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_tree_to_workdir(
 git_diff **diff,
 git_repository *repo,
 git_tree *old_tree,
 const git_diff_options *opts);
# 986 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_tree_to_workdir_with_index(
 git_diff **diff,
 git_repository *repo,
 git_tree *old_tree,
 const git_diff_options *opts);
# 1005 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_index_to_index(
 git_diff **diff,
 git_repository *repo,
 git_index *old_index,
 git_index *new_index,
 const git_diff_options *opts);
# 1026 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_merge(
 git_diff *onto,
 const git_diff *from);
# 1042 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_find_similar(
 git_diff *diff,
 const git_diff_find_options *options);
# 1062 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) size_t git_diff_num_deltas(const git_diff *diff);
# 1075 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) size_t git_diff_num_deltas_of_type(
 const git_diff *diff, git_delta_t type);
# 1095 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) const git_diff_delta * git_diff_get_delta(
 const git_diff *diff, size_t idx);







extern __attribute__((visibility("default"))) int git_diff_is_sorted_icase(const git_diff *diff);
# 1132 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_foreach(
 git_diff *diff,
 git_diff_file_cb file_cb,
 git_diff_binary_cb binary_cb,
 git_diff_hunk_cb hunk_cb,
 git_diff_line_cb line_cb,
 void *payload);
# 1151 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) char git_diff_status_char(git_delta_t status);




typedef enum {
 GIT_DIFF_FORMAT_PATCH = 1u,
 GIT_DIFF_FORMAT_PATCH_HEADER = 2u,
 GIT_DIFF_FORMAT_RAW = 3u,
 GIT_DIFF_FORMAT_NAME_ONLY = 4u,
 GIT_DIFF_FORMAT_NAME_STATUS = 5u,
 GIT_DIFF_FORMAT_PATCH_ID = 6u
} git_diff_format_t;
# 1177 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_print(
 git_diff *diff,
 git_diff_format_t format,
 git_diff_line_cb print_cb,
 void *payload);
# 1193 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_to_buf(
 git_buf *out,
 git_diff *diff,
 git_diff_format_t format);
# 1232 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_blobs(
 const git_blob *old_blob,
 const char *old_as_path,
 const git_blob *new_blob,
 const char *new_as_path,
 const git_diff_options *options,
 git_diff_file_cb file_cb,
 git_diff_binary_cb binary_cb,
 git_diff_hunk_cb hunk_cb,
 git_diff_line_cb line_cb,
 void *payload);
# 1269 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_blob_to_buffer(
 const git_blob *old_blob,
 const char *old_as_path,
 const char *buffer,
 size_t buffer_len,
 const char *buffer_as_path,
 const git_diff_options *options,
 git_diff_file_cb file_cb,
 git_diff_binary_cb binary_cb,
 git_diff_hunk_cb hunk_cb,
 git_diff_line_cb line_cb,
 void *payload);
# 1303 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_buffers(
 const void *old_buffer,
 size_t old_len,
 const char *old_as_path,
 const void *new_buffer,
 size_t new_len,
 const char *new_as_path,
 const git_diff_options *options,
 git_diff_file_cb file_cb,
 git_diff_binary_cb binary_cb,
 git_diff_hunk_cb hunk_cb,
 git_diff_line_cb line_cb,
 void *payload);






typedef struct {
 unsigned int version;
 git_oid_t oid_type;
} git_diff_parse_options;
# 1355 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_from_buffer(
 git_diff **out,
 const char *content,
 size_t content_len



 );






typedef struct git_diff_stats git_diff_stats;




typedef enum {

 GIT_DIFF_STATS_NONE = 0,


 GIT_DIFF_STATS_FULL = (1u << 0),


 GIT_DIFF_STATS_SHORT = (1u << 1),


 GIT_DIFF_STATS_NUMBER = (1u << 2),


 GIT_DIFF_STATS_INCLUDE_SUMMARY = (1u << 3)
} git_diff_stats_format_t;
# 1398 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_get_stats(
 git_diff_stats **out,
 git_diff *diff);







extern __attribute__((visibility("default"))) size_t git_diff_stats_files_changed(
 const git_diff_stats *stats);







extern __attribute__((visibility("default"))) size_t git_diff_stats_insertions(
 const git_diff_stats *stats);







extern __attribute__((visibility("default"))) size_t git_diff_stats_deletions(
 const git_diff_stats *stats);
# 1438 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_stats_to_buf(
 git_buf *out,
 const git_diff_stats *stats,
 git_diff_stats_format_t format,
 size_t width);







extern __attribute__((visibility("default"))) void git_diff_stats_free(git_diff_stats *stats);
# 1459 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
typedef struct git_diff_patchid_options {
 unsigned int version;
} git_diff_patchid_options;
# 1479 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_patchid_options_init(
 git_diff_patchid_options *opts,
 unsigned int version);
# 1502 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/diff.h"
extern __attribute__((visibility("default"))) int git_diff_patchid(git_oid *out, git_diff *diff, git_diff_patchid_options *opts);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h" 2
# 113 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
typedef enum {






 GIT_CHECKOUT_SAFE = 0,





 GIT_CHECKOUT_FORCE = (1u << 1),


 GIT_CHECKOUT_RECREATE_MISSING = (1u << 2),


 GIT_CHECKOUT_ALLOW_CONFLICTS = (1u << 4),


 GIT_CHECKOUT_REMOVE_UNTRACKED = (1u << 5),


 GIT_CHECKOUT_REMOVE_IGNORED = (1u << 6),


 GIT_CHECKOUT_UPDATE_ONLY = (1u << 7),





 GIT_CHECKOUT_DONT_UPDATE_INDEX = (1u << 8),


 GIT_CHECKOUT_NO_REFRESH = (1u << 9),


 GIT_CHECKOUT_SKIP_UNMERGED = (1u << 10),

 GIT_CHECKOUT_USE_OURS = (1u << 11),

 GIT_CHECKOUT_USE_THEIRS = (1u << 12),


 GIT_CHECKOUT_DISABLE_PATHSPEC_MATCH = (1u << 13),


 GIT_CHECKOUT_SKIP_LOCKED_DIRECTORIES = (1u << 18),


 GIT_CHECKOUT_DONT_OVERWRITE_IGNORED = (1u << 19),


 GIT_CHECKOUT_CONFLICT_STYLE_MERGE = (1u << 20),


 GIT_CHECKOUT_CONFLICT_STYLE_DIFF3 = (1u << 21),


 GIT_CHECKOUT_DONT_REMOVE_EXISTING = (1u << 22),


 GIT_CHECKOUT_DONT_WRITE_INDEX = (1u << 23),






 GIT_CHECKOUT_DRY_RUN = (1u << 24),


 GIT_CHECKOUT_CONFLICT_STYLE_ZDIFF3 = (1u << 25),







 GIT_CHECKOUT_NONE = (1u << 30),






 GIT_CHECKOUT_UPDATE_SUBMODULES = (1u << 16),

 GIT_CHECKOUT_UPDATE_SUBMODULES_IF_CHANGED = (1u << 17)
} git_checkout_strategy_t;
# 224 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
typedef enum {
 GIT_CHECKOUT_NOTIFY_NONE = 0,




 GIT_CHECKOUT_NOTIFY_CONFLICT = (1u << 0),






 GIT_CHECKOUT_NOTIFY_DIRTY = (1u << 1),




 GIT_CHECKOUT_NOTIFY_UPDATED = (1u << 2),




 GIT_CHECKOUT_NOTIFY_UNTRACKED = (1u << 3),




 GIT_CHECKOUT_NOTIFY_IGNORED = (1u << 4),

 GIT_CHECKOUT_NOTIFY_ALL = 0x0FFFFu
} git_checkout_notify_t;


typedef struct {
 size_t mkdir_calls;
 size_t stat_calls;
 size_t chmod_calls;
} git_checkout_perfdata;
# 275 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
typedef int (*git_checkout_notify_cb)(
 git_checkout_notify_t why,
 const char *path,
 const git_diff_file *baseline,
 const git_diff_file *target,
 const git_diff_file *workdir,
 void *payload);
# 291 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
typedef void (*git_checkout_progress_cb)(
 const char *path,
 size_t completed_steps,
 size_t total_steps,
 void *payload);







typedef void (*git_checkout_perfdata_cb)(
 const git_checkout_perfdata *perfdata,
 void *payload);
# 317 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
typedef struct git_checkout_options {
 unsigned int version;






 unsigned int checkout_strategy;

 int disable_filters;
 unsigned int dir_mode;
 unsigned int file_mode;
 int file_open_flags;







 unsigned int notify_flags;





 git_checkout_notify_cb notify_cb;


 void *notify_payload;


 git_checkout_progress_cb progress_cb;


 void *progress_payload;
# 364 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
 git_strarray paths;







 git_tree *baseline;





 git_index *baseline_index;

 const char *target_directory;

 const char *ancestor_label;
 const char *our_label;
 const char *their_label;


 git_checkout_perfdata_cb perfdata_cb;


 void *perfdata_payload;
} git_checkout_options;
# 410 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
extern __attribute__((visibility("default"))) int git_checkout_options_init(
 git_checkout_options *opts,
 unsigned int version);
# 431 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
extern __attribute__((visibility("default"))) int git_checkout_head(
 git_repository *repo,
 const git_checkout_options *opts);
# 444 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
extern __attribute__((visibility("default"))) int git_checkout_index(
 git_repository *repo,
 git_index *index,
 const git_checkout_options *opts);
# 460 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/checkout.h"
extern __attribute__((visibility("default"))) int git_checkout_tree(
 git_repository *repo,
 const git_object *treeish,
 const git_checkout_options *opts);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oidarray.h" 1
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oidarray.h"
typedef struct git_oidarray {
 git_oid *ids;
 size_t count;
} git_oidarray;
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/oidarray.h"
extern __attribute__((visibility("default"))) void git_oidarray_dispose(git_oidarray *array);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
typedef struct git_indexer git_indexer;






typedef struct git_indexer_progress {

 unsigned int total_objects;


 unsigned int indexed_objects;


 unsigned int received_objects;





 unsigned int local_objects;


 unsigned int total_deltas;


 unsigned int indexed_deltas;


 size_t received_bytes;
} git_indexer_progress;
# 68 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
typedef int (*git_indexer_progress_cb)(const git_indexer_progress *stats, void *payload);




typedef struct git_indexer_options {
 unsigned int version;
# 93 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
 git_indexer_progress_cb progress_cb;


 void *progress_cb_payload;


 unsigned char verify;
} git_indexer_options;
# 116 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
extern __attribute__((visibility("default"))) int git_indexer_options_init(
 git_indexer_options *opts,
 unsigned int version);
# 147 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
extern __attribute__((visibility("default"))) int git_indexer_new(
  git_indexer **out,
  const char *path,
  unsigned int mode,
  git_odb *odb,
  git_indexer_options *opts);
# 164 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
extern __attribute__((visibility("default"))) int git_indexer_append(git_indexer *idx, const void *data, size_t size, git_indexer_progress *stats);
# 175 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
extern __attribute__((visibility("default"))) int git_indexer_commit(git_indexer *idx, git_indexer_progress *stats);
# 188 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
extern __attribute__((visibility("default"))) const git_oid * git_indexer_hash(const git_indexer *idx);
# 200 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/indexer.h"
extern __attribute__((visibility("default"))) const char * git_indexer_name(const git_indexer *idx);






extern __attribute__((visibility("default"))) void git_indexer_free(git_indexer *idx);
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h" 2
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
typedef struct {
 int32_t seconds;

 uint32_t nanoseconds;
} git_index_time;
# 58 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
typedef struct git_index_entry {
 git_index_time ctime;
 git_index_time mtime;

 uint32_t dev;
 uint32_t ino;
 uint32_t mode;
 uint32_t uid;
 uint32_t gid;
 uint32_t file_size;

 git_oid id;

 uint16_t flags;
 uint16_t flags_extended;

 const char *path;
} git_index_entry;
# 95 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
typedef enum {
 GIT_INDEX_ENTRY_EXTENDED = (0x4000),
 GIT_INDEX_ENTRY_VALID = (0x8000)
} git_index_entry_flag_t;
# 132 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
typedef enum {
 GIT_INDEX_ENTRY_INTENT_TO_ADD = (1 << 13),
 GIT_INDEX_ENTRY_SKIP_WORKTREE = (1 << 14),

 GIT_INDEX_ENTRY_EXTENDED_FLAGS = (GIT_INDEX_ENTRY_INTENT_TO_ADD | GIT_INDEX_ENTRY_SKIP_WORKTREE),

 GIT_INDEX_ENTRY_UPTODATE = (1 << 2)
} git_index_entry_extended_flag_t;


typedef enum {
 GIT_INDEX_CAPABILITY_IGNORE_CASE = 1,
 GIT_INDEX_CAPABILITY_NO_FILEMODE = 2,
 GIT_INDEX_CAPABILITY_NO_SYMLINKS = 4,
 GIT_INDEX_CAPABILITY_FROM_OWNER = -1
} git_index_capability_t;
# 158 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
typedef int (*git_index_matched_path_cb)(
 const char *path, const char *matched_pathspec, void *payload);


typedef enum {
 GIT_INDEX_ADD_DEFAULT = 0,
 GIT_INDEX_ADD_FORCE = (1u << 0),
 GIT_INDEX_ADD_DISABLE_PATHSPEC_MATCH = (1u << 1),
 GIT_INDEX_ADD_CHECK_PATHSPEC = (1u << 2)
} git_index_add_option_t;


typedef enum {






 GIT_INDEX_STAGE_ANY = -1,


 GIT_INDEX_STAGE_NORMAL = 0,


 GIT_INDEX_STAGE_ANCESTOR = 1,


 GIT_INDEX_STAGE_OURS = 2,


 GIT_INDEX_STAGE_THEIRS = 3
} git_index_stage_t;
# 278 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_open(git_index **index_out, const char *index_path);
# 291 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_new(git_index **index_out);
# 300 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) void git_index_free(git_index *index);







extern __attribute__((visibility("default"))) git_repository * git_index_owner(const git_index *index);







extern __attribute__((visibility("default"))) int git_index_caps(const git_index *index);
# 329 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_set_caps(git_index *index, int caps);
# 341 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) unsigned int git_index_version(git_index *index);
# 354 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_set_version(git_index *index, unsigned int version);
# 373 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_read(git_index *index, int force);
# 382 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_write(git_index *index);







extern __attribute__((visibility("default"))) const char * git_index_path(const git_index *index);
# 404 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) const git_oid * git_index_checksum(git_index *index);
# 416 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_read_tree(git_index *index, const git_tree *tree);
# 437 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_write_tree(git_oid *out, git_index *index);
# 454 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_write_tree_to(git_oid *out, git_index *index, git_repository *repo);
# 473 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) size_t git_index_entrycount(const git_index *index);
# 484 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_clear(git_index *index);
# 497 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) const git_index_entry * git_index_get_byindex(
 git_index *index, size_t n);
# 512 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) const git_index_entry * git_index_get_bypath(
 git_index *index, const char *path, int stage);
# 523 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_remove(git_index *index, const char *path, int stage);
# 533 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_remove_directory(
 git_index *index, const char *dir, int stage);
# 550 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_add(git_index *index, const git_index_entry *source_entry);
# 562 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_entry_stage(const git_index_entry *entry);
# 571 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_entry_is_conflict(const git_index_entry *entry);
# 592 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_iterator_new(
 git_index_iterator **iterator_out,
 git_index *index);
# 603 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_iterator_next(
 const git_index_entry **out,
 git_index_iterator *iterator);






extern __attribute__((visibility("default"))) void git_index_iterator_free(git_index_iterator *iterator);
# 643 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_add_bypath(git_index *index, const char *path);
# 671 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_add_from_buffer(
 git_index *index,
 const git_index_entry *entry,
 const void *buffer, size_t len);
# 690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_remove_bypath(git_index *index, const char *path);
# 738 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_add_all(
 git_index *index,
 const git_strarray *pathspec,
 unsigned int flags,
 git_index_matched_path_cb callback,
 void *payload);
# 760 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_remove_all(
 git_index *index,
 const git_strarray *pathspec,
 git_index_matched_path_cb callback,
 void *payload);
# 789 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_update_all(
 git_index *index,
 const git_strarray *pathspec,
 git_index_matched_path_cb callback,
 void *payload);
# 804 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_find(size_t *at_pos, git_index *index, const char *path);
# 815 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_find_prefix(size_t *at_pos, git_index *index, const char *prefix);
# 840 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_conflict_add(
 git_index *index,
 const git_index_entry *ancestor_entry,
 const git_index_entry *our_entry,
 const git_index_entry *their_entry);
# 860 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_conflict_get(
 const git_index_entry **ancestor_out,
 const git_index_entry **our_out,
 const git_index_entry **their_out,
 git_index *index,
 const char *path);
# 874 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_conflict_remove(git_index *index, const char *path);







extern __attribute__((visibility("default"))) int git_index_conflict_cleanup(git_index *index);







extern __attribute__((visibility("default"))) int git_index_has_conflicts(const git_index *index);
# 901 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_conflict_iterator_new(
 git_index_conflict_iterator **iterator_out,
 git_index *index);
# 916 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/index.h"
extern __attribute__((visibility("default"))) int git_index_conflict_next(
 const git_index_entry **ancestor_out,
 const git_index_entry **our_out,
 const git_index_entry **their_out,
 git_index_conflict_iterator *iterator);






extern __attribute__((visibility("default"))) void git_index_conflict_iterator_free(
 git_index_conflict_iterator *iterator);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
typedef enum {






 GIT_ODB_LOOKUP_NO_REFRESH = (1 << 0)
} git_odb_lookup_flags_t;
# 43 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
typedef int (*git_odb_foreach_cb)(const git_oid *id, void *payload);


typedef struct {
 unsigned int version;





 git_oid_t oid_type;
} git_odb_options;
# 102 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_new(git_odb **odb);
# 120 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_open(git_odb **odb_out, const char *objects_dir);
# 138 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_add_disk_alternate(git_odb *odb, const char *path);






extern __attribute__((visibility("default"))) void git_odb_free(git_odb *db);
# 163 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_read(git_odb_object **obj, git_odb *db, const git_oid *id);
# 191 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_read_prefix(git_odb_object **obj, git_odb *db, const git_oid *short_id, size_t len);
# 210 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_read_header(size_t *len_out, git_object_t *type_out, git_odb *db, const git_oid *id);
# 219 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_exists(git_odb *db, const git_oid *id);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_exists_ext(git_odb *db, const git_oid *id, unsigned int flags);
# 243 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_exists_prefix(
 git_oid *out, git_odb *db, const git_oid *short_id, size_t len);





typedef struct git_odb_expand_id {

 git_oid id;





 unsigned short length;





 git_object_t type;
} git_odb_expand_id;
# 286 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_expand_ids(
 git_odb *db,
 git_odb_expand_id *ids,
 size_t count);
# 309 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_refresh(git_odb *db);
# 324 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_foreach(
 git_odb *db,
 git_odb_foreach_cb cb,
 void *payload);
# 347 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_write(git_oid *out, git_odb *odb, const void *data, size_t len, git_object_t type);
# 370 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_open_wstream(git_odb_stream **out, git_odb *db, git_object_size_t size, git_object_t type);
# 383 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_stream_write(git_odb_stream *stream, const char *buffer, size_t len);
# 398 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_stream_finalize_write(git_oid *out, git_odb_stream *stream);
# 410 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_stream_read(git_odb_stream *stream, char *buffer, size_t len);






extern __attribute__((visibility("default"))) void git_odb_stream_free(git_odb_stream *stream);
# 445 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_open_rstream(
 git_odb_stream **out,
 size_t *len,
 git_object_t *type,
 git_odb *db,
 const git_oid *oid);
# 471 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_write_pack(
 git_odb_writepack **out,
 git_odb *db,
 git_indexer_progress_cb progress_cb,
 void *progress_payload);
# 489 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_write_multi_pack_index(
 git_odb *db);
# 539 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_hash(git_oid *oid, const void *data, size_t len, git_object_t object_type);
# 554 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_hashfile(git_oid *oid, const char *path, git_object_t object_type);
# 570 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_object_dup(git_odb_object **dest, git_odb_object *source);
# 580 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) void git_odb_object_free(git_odb_object *object);
# 590 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) const git_oid * git_odb_object_id(git_odb_object *object);
# 603 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) const void * git_odb_object_data(git_odb_object *object);
# 614 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) size_t git_odb_object_size(git_odb_object *object);







extern __attribute__((visibility("default"))) git_object_t git_odb_object_type(git_odb_object *object);
# 637 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_add_backend(git_odb *odb, git_odb_backend *backend, int priority);
# 658 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_add_alternate(git_odb *odb, git_odb_backend *backend, int priority);







extern __attribute__((visibility("default"))) size_t git_odb_num_backends(git_odb *odb);
# 676 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_get_backend(git_odb_backend **out, git_odb *odb, size_t pos);
# 691 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb.h"
extern __attribute__((visibility("default"))) int git_odb_set_commit_graph(git_odb *odb, git_commit_graph *cgraph);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h" 1
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_lookup(
 git_commit **commit, git_repository *repo, const git_oid *id);
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_lookup_prefix(
 git_commit **commit, git_repository *repo, const git_oid *id, size_t len);
# 74 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) void git_commit_free(git_commit *commit);







extern __attribute__((visibility("default"))) const git_oid * git_commit_id(const git_commit *commit);







extern __attribute__((visibility("default"))) git_repository * git_commit_owner(const git_commit *commit);
# 102 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) const char * git_commit_message_encoding(const git_commit *commit);
# 113 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) const char * git_commit_message(const git_commit *commit);







extern __attribute__((visibility("default"))) const char * git_commit_message_raw(const git_commit *commit);
# 132 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) const char * git_commit_summary(git_commit *commit);
# 145 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) const char * git_commit_body(git_commit *commit);







extern __attribute__((visibility("default"))) git_time_t git_commit_time(const git_commit *commit);







extern __attribute__((visibility("default"))) int git_commit_time_offset(const git_commit *commit);







extern __attribute__((visibility("default"))) const git_signature * git_commit_committer(const git_commit *commit);







extern __attribute__((visibility("default"))) const git_signature * git_commit_author(const git_commit *commit);
# 190 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_committer_with_mailmap(
 git_signature **out, const git_commit *commit, const git_mailmap *mailmap);
# 204 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_author_with_mailmap(
 git_signature **out, const git_commit *commit, const git_mailmap *mailmap);







extern __attribute__((visibility("default"))) const char * git_commit_raw_header(const git_commit *commit);
# 222 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_tree(git_tree **tree_out, const git_commit *commit);
# 232 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) const git_oid * git_commit_tree_id(const git_commit *commit);







extern __attribute__((visibility("default"))) unsigned int git_commit_parentcount(const git_commit *commit);
# 250 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_parent(
 git_commit **out,
 const git_commit *commit,
 unsigned int n);
# 264 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) const git_oid * git_commit_parent_id(
 const git_commit *commit,
 unsigned int n);
# 282 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_nth_gen_ancestor(
 git_commit **ancestor,
 const git_commit *commit,
 unsigned int n);
# 297 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_header_field(git_buf *out, const git_commit *commit, const char *field);
# 317 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_extract_signature(git_buf *signature, git_buf *signed_data, git_repository *repo, git_oid *commit_id, const char *field);
# 363 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_create(
 git_oid *id,
 git_repository *repo,
 const char *update_ref,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message,
 const git_tree *tree,
 size_t parent_count,
 const git_commit *parents[]);
# 420 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_create_v(
 git_oid *id,
 git_repository *repo,
 const char *update_ref,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message,
 const git_tree *tree,
 size_t parent_count,
 ...);

typedef struct {
 unsigned int version;
# 442 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
 unsigned int allow_empty_commit : 1;


 const git_signature *author;


 const git_signature *committer;


 const char *message_encoding;
} git_commit_create_options;
# 472 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_create_from_stage(
 git_oid *id,
 git_repository *repo,
 const char *message,
 const git_commit_create_options *opts);
# 528 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_amend(
 git_oid *id,
 const git_commit *commit_to_amend,
 const char *update_ref,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message,
 const git_tree *tree);
# 573 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_create_buffer(
 git_buf *out,
 git_repository *repo,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message,
 const git_tree *tree,
 size_t parent_count,
 const git_commit *parents[]);
# 600 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_create_with_signature(
 git_oid *out,
 git_repository *repo,
 const char *commit_content,
 const char *signature,
 const char *signature_field);
# 615 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) int git_commit_dup(git_commit **out, git_commit *source);
# 643 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
typedef int (*git_commit_create_cb)(
 git_oid *out,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message,
 const git_tree *tree,
 size_t parent_count,
 const git_commit *parents[],
 void *payload);


typedef struct git_commitarray {
 git_commit *const *commits;
 size_t count;
} git_commitarray;
# 670 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/commit.h"
extern __attribute__((visibility("default"))) void git_commitarray_dispose(git_commitarray *array);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h" 2
# 43 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_open(git_repository **out, const char *path);
# 54 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_open_from_worktree(git_repository **out, git_worktree *wt);
# 67 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_wrap_odb(
 git_repository **out,
 git_odb *odb);
# 101 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_discover(
  git_buf *out,
  const char *start_path,
  int across_fs,
  const char *ceiling_dirs);




typedef enum {





 GIT_REPOSITORY_OPEN_NO_SEARCH = (1 << 0),
# 125 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
 GIT_REPOSITORY_OPEN_CROSS_FS = (1 << 1),






 GIT_REPOSITORY_OPEN_BARE = (1 << 2),






 GIT_REPOSITORY_OPEN_NO_DOTGIT = (1 << 3),
# 156 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
 GIT_REPOSITORY_OPEN_FROM_ENV = (1 << 4)
} git_repository_open_flag_t;
# 181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_open_ext(
 git_repository **out,
 const char *path,
 unsigned int flags,
 const char *ceiling_dirs);
# 202 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_open_bare(git_repository **out, const char *bare_path);
# 215 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) void git_repository_free(git_repository *repo);
# 236 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_init(
 git_repository **out,
 const char *path,
 unsigned is_bare);
# 249 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
typedef enum {



 GIT_REPOSITORY_INIT_BARE = (1u << 0),





 GIT_REPOSITORY_INIT_NO_REINIT = (1u << 1),






 GIT_REPOSITORY_INIT_NO_DOTGIT_DIR = (1u << 2),







 GIT_REPOSITORY_INIT_MKDIR = (1u << 3),





 GIT_REPOSITORY_INIT_MKPATH = (1u << 4),







 GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE = (1u << 5),





 GIT_REPOSITORY_INIT_RELATIVE_GITLINK = (1u << 6)
} git_repository_init_flag_t;
# 304 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
typedef enum {



 GIT_REPOSITORY_INIT_SHARED_UMASK = 0,





 GIT_REPOSITORY_INIT_SHARED_GROUP = 0002775,




 GIT_REPOSITORY_INIT_SHARED_ALL = 0002777
} git_repository_init_mode_t;







typedef struct {
 unsigned int version;




 uint32_t flags;





 uint32_t mode;
# 349 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
 const char *workdir_path;





 const char *description;






 const char *template_path;







 const char *initial_head;






 const char *origin_url;
# 387 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
} git_repository_init_options;
# 405 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_init_options_init(
 git_repository_init_options *opts,
 unsigned int version);
# 426 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_init_ext(
 git_repository **out,
 const char *repo_path,
 git_repository_init_options *opts);
# 444 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_head(git_reference **out, git_repository *repo);
# 454 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_head_for_worktree(git_reference **out, git_repository *repo,
 const char *name);
# 467 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_head_detached(git_repository *repo);
# 480 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_head_detached_for_worktree(git_repository *repo,
 const char *name);
# 493 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_head_unborn(git_repository *repo);
# 507 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_is_empty(git_repository *repo);




typedef enum {
 GIT_REPOSITORY_ITEM_GITDIR,
 GIT_REPOSITORY_ITEM_WORKDIR,
 GIT_REPOSITORY_ITEM_COMMONDIR,
 GIT_REPOSITORY_ITEM_INDEX,
 GIT_REPOSITORY_ITEM_OBJECTS,
 GIT_REPOSITORY_ITEM_REFS,
 GIT_REPOSITORY_ITEM_PACKED_REFS,
 GIT_REPOSITORY_ITEM_REMOTES,
 GIT_REPOSITORY_ITEM_CONFIG,
 GIT_REPOSITORY_ITEM_INFO,
 GIT_REPOSITORY_ITEM_HOOKS,
 GIT_REPOSITORY_ITEM_LOGS,
 GIT_REPOSITORY_ITEM_MODULES,
 GIT_REPOSITORY_ITEM_WORKTREES,
 GIT_REPOSITORY_ITEM_WORKTREE_CONFIG,
 GIT_REPOSITORY_ITEM__LAST
} git_repository_item_t;
# 545 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_item_path(git_buf *out, const git_repository *repo, git_repository_item_t item);
# 556 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) const char * git_repository_path(const git_repository *repo);
# 567 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) const char * git_repository_workdir(const git_repository *repo);
# 579 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) const char * git_repository_commondir(const git_repository *repo);
# 598 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_workdir(
 git_repository *repo, const char *workdir, int update_gitlink);







extern __attribute__((visibility("default"))) int git_repository_is_bare(const git_repository *repo);







extern __attribute__((visibility("default"))) int git_repository_is_worktree(const git_repository *repo);
# 631 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_config(git_config **out, git_repository *repo);
# 647 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_config_snapshot(git_config **out, git_repository *repo);
# 663 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_odb(git_odb **out, git_repository *repo);
# 679 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_refdb(git_refdb **out, git_repository *repo);
# 695 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_index(git_index **out, git_repository *repo);
# 713 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_message(git_buf *out, git_repository *repo);
# 723 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_message_remove(git_repository *repo);
# 732 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_state_cleanup(git_repository *repo);
# 746 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
typedef int (*git_repository_fetchhead_foreach_cb)(const char *ref_name,
 const char *remote_url,
 const git_oid *oid,
 unsigned int is_merge,
 void *payload);
# 763 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_fetchhead_foreach(
 git_repository *repo,
 git_repository_fetchhead_foreach_cb callback,
 void *payload);
# 777 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
typedef int (*git_repository_mergehead_foreach_cb)(const git_oid *oid,
 void *payload);
# 792 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_mergehead_foreach(
 git_repository *repo,
 git_repository_mergehead_foreach_cb callback,
 void *payload);
# 822 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_hashfile(
 git_oid *out,
 git_repository *repo,
 const char *path,
 git_object_t type,
 const char *as_path);
# 847 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_head(
 git_repository *repo,
 const char *refname);
# 867 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_head_detached(
 git_repository *repo,
 const git_oid *committish);
# 885 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_head_detached_from_annotated(
 git_repository *repo,
 const git_annotated_commit *committish);
# 906 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_detach_head(
 git_repository *repo);







typedef enum {
 GIT_REPOSITORY_STATE_NONE,
 GIT_REPOSITORY_STATE_MERGE,
 GIT_REPOSITORY_STATE_REVERT,
 GIT_REPOSITORY_STATE_REVERT_SEQUENCE,
 GIT_REPOSITORY_STATE_CHERRYPICK,
 GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE,
 GIT_REPOSITORY_STATE_BISECT,
 GIT_REPOSITORY_STATE_REBASE,
 GIT_REPOSITORY_STATE_REBASE_INTERACTIVE,
 GIT_REPOSITORY_STATE_REBASE_MERGE,
 GIT_REPOSITORY_STATE_APPLY_MAILBOX,
 GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE
} git_repository_state_t;
# 937 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_state(git_repository *repo);
# 951 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_namespace(git_repository *repo, const char *nmspace);







extern __attribute__((visibility("default"))) const char * git_repository_get_namespace(git_repository *repo);
# 968 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_is_shallow(git_repository *repo);
# 981 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_ident(const char **name, const char **email, const git_repository *repo);
# 995 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_ident(git_repository *repo, const char *name, const char *email);







extern __attribute__((visibility("default"))) git_oid_t git_repository_oid_type(git_repository *repo);
# 1014 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/repository.h"
extern __attribute__((visibility("default"))) int git_repository_commit_parents(git_commitarray *commits, git_repository *repo);
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h" 2
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h"
extern __attribute__((visibility("default"))) int git_annotated_commit_from_ref(
 git_annotated_commit **out,
 git_repository *repo,
 const git_reference *ref);
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h"
extern __attribute__((visibility("default"))) int git_annotated_commit_from_fetchhead(
 git_annotated_commit **out,
 git_repository *repo,
 const char *branch_name,
 const char *remote_url,
 const git_oid *id);
# 82 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h"
extern __attribute__((visibility("default"))) int git_annotated_commit_lookup(
 git_annotated_commit **out,
 git_repository *repo,
 const git_oid *id);
# 99 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/annotated_commit.h"
extern __attribute__((visibility("default"))) int git_annotated_commit_from_revspec(
 git_annotated_commit **out,
 git_repository *repo,
 const char *revspec);







extern __attribute__((visibility("default"))) const git_oid * git_annotated_commit_id(
 const git_annotated_commit *commit);







extern __attribute__((visibility("default"))) const char * git_annotated_commit_ref(
 const git_annotated_commit *commit);






extern __attribute__((visibility("default"))) void git_annotated_commit_free(
 git_annotated_commit *commit);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h" 2
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
typedef struct {
 unsigned int version;


 const char *ptr;


 size_t size;


 const char *path;


 unsigned int mode;
} git_merge_file_input;
# 66 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_file_input_init(
 git_merge_file_input *opts,
 unsigned int version);





typedef enum {





 GIT_MERGE_FIND_RENAMES = (1 << 0),






 GIT_MERGE_FAIL_ON_CONFLICT = (1 << 1),




 GIT_MERGE_SKIP_REUC = (1 << 2),







 GIT_MERGE_NO_RECURSIVE = (1 << 3),







 GIT_MERGE_VIRTUAL_BASE = (1 << 4)
} git_merge_flag_t;





typedef enum {






 GIT_MERGE_FILE_FAVOR_NORMAL = 0,






 GIT_MERGE_FILE_FAVOR_OURS = 1,






 GIT_MERGE_FILE_FAVOR_THEIRS = 2,







 GIT_MERGE_FILE_FAVOR_UNION = 3
} git_merge_file_favor_t;




typedef enum {

 GIT_MERGE_FILE_DEFAULT = 0,


 GIT_MERGE_FILE_STYLE_MERGE = (1 << 0),


 GIT_MERGE_FILE_STYLE_DIFF3 = (1 << 1),


 GIT_MERGE_FILE_SIMPLIFY_ALNUM = (1 << 2),


 GIT_MERGE_FILE_IGNORE_WHITESPACE = (1 << 3),


 GIT_MERGE_FILE_IGNORE_WHITESPACE_CHANGE = (1 << 4),


 GIT_MERGE_FILE_IGNORE_WHITESPACE_EOL = (1 << 5),


 GIT_MERGE_FILE_DIFF_PATIENCE = (1 << 6),


 GIT_MERGE_FILE_DIFF_MINIMAL = (1 << 7),


 GIT_MERGE_FILE_STYLE_ZDIFF3 = (1 << 8),






 GIT_MERGE_FILE_ACCEPT_CONFLICTS = (1 << 9)
} git_merge_file_flag_t;







typedef struct {
 unsigned int version;





 const char *ancestor_label;





 const char *our_label;





 const char *their_label;


 git_merge_file_favor_t favor;


 uint32_t flags;



 unsigned short marker_size;
} git_merge_file_options;
# 243 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_file_options_init(git_merge_file_options *opts, unsigned int version);




typedef struct {




 unsigned int automergeable;





 const char *path;


 unsigned int mode;


 const char *ptr;


 size_t len;
} git_merge_file_result;




typedef struct {
 unsigned int version;


 uint32_t flags;
# 287 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
 unsigned int rename_threshold;
# 296 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
 unsigned int target_limit;


 git_diff_similarity_metric *metric;







 unsigned int recursion_limit;





 const char *default_driver;





 git_merge_file_favor_t file_favor;


 uint32_t file_flags;
} git_merge_options;
# 342 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_options_init(git_merge_options *opts, unsigned int version);




typedef enum {

 GIT_MERGE_ANALYSIS_NONE = 0,





 GIT_MERGE_ANALYSIS_NORMAL = (1 << 0),





 GIT_MERGE_ANALYSIS_UP_TO_DATE = (1 << 1),






 GIT_MERGE_ANALYSIS_FASTFORWARD = (1 << 2),






 GIT_MERGE_ANALYSIS_UNBORN = (1 << 3)
} git_merge_analysis_t;




typedef enum {




 GIT_MERGE_PREFERENCE_NONE = 0,





 GIT_MERGE_PREFERENCE_NO_FASTFORWARD = (1 << 0),





 GIT_MERGE_PREFERENCE_FASTFORWARD_ONLY = (1 << 1)
} git_merge_preference_t;
# 412 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_analysis(
 git_merge_analysis_t *analysis_out,
 git_merge_preference_t *preference_out,
 git_repository *repo,
 const git_annotated_commit **their_heads,
 size_t their_heads_len);
# 431 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_analysis_for_ref(
 git_merge_analysis_t *analysis_out,
 git_merge_preference_t *preference_out,
 git_repository *repo,
 git_reference *our_ref,
 const git_annotated_commit **their_heads,
 size_t their_heads_len);
# 448 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_base(
 git_oid *out,
 git_repository *repo,
 const git_oid *one,
 const git_oid *two);
# 463 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_bases(
 git_oidarray *out,
 git_repository *repo,
 const git_oid *one,
 const git_oid *two);
# 478 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_base_many(
 git_oid *out,
 git_repository *repo,
 size_t length,
 const git_oid input_array[]);
# 524 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_bases_many(
 git_oidarray *out,
 git_repository *repo,
 size_t length,
 const git_oid input_array[]);
# 539 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_base_octopus(
 git_oid *out,
 git_repository *repo,
 size_t length,
 const git_oid input_array[]);
# 561 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_file(
 git_merge_file_result *out,
 const git_merge_file_input *ancestor,
 const git_merge_file_input *ours,
 const git_merge_file_input *theirs,
 const git_merge_file_options *opts);
# 582 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_file_from_index(
 git_merge_file_result *out,
 git_repository *repo,
 const git_index_entry *ancestor,
 const git_index_entry *ours,
 const git_index_entry *theirs,
 const git_merge_file_options *opts);






extern __attribute__((visibility("default"))) void git_merge_file_result_free(git_merge_file_result *result);
# 613 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_trees(
 git_index **out,
 git_repository *repo,
 const git_tree *ancestor_tree,
 const git_tree *our_tree,
 const git_tree *their_tree,
 const git_merge_options *opts);
# 636 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge_commits(
 git_index **out,
 git_repository *repo,
 const git_commit *our_commit,
 const git_commit *their_commit,
 const git_merge_options *opts);
# 661 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/merge.h"
extern __attribute__((visibility("default"))) int git_merge(
 git_repository *repo,
 const git_annotated_commit **their_heads,
 size_t their_heads_len,
 const git_merge_options *merge_opts,
 const git_checkout_options *checkout_opts);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h" 2
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h"
typedef struct {
 unsigned int version;


 unsigned int mainline;

 git_merge_options merge_opts;
 git_checkout_options checkout_opts;
} git_cherrypick_options;
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h"
extern __attribute__((visibility("default"))) int git_cherrypick_options_init(
 git_cherrypick_options *opts,
 unsigned int version);
# 75 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h"
extern __attribute__((visibility("default"))) int git_cherrypick_commit(
 git_index **out,
 git_repository *repo,
 git_commit *cherrypick_commit,
 git_commit *our_commit,
 unsigned int mainline,
 const git_merge_options *merge_options);
# 91 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cherrypick.h"
extern __attribute__((visibility("default"))) int git_cherrypick(
 git_repository *repo,
 git_commit *commit,
 const git_cherrypick_options *cherrypick_options);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/net.h" 1
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/net.h"
typedef enum {
 GIT_DIRECTION_FETCH = 0,
 GIT_DIRECTION_PUSH = 1
} git_direction;





struct git_remote_head {
 int local;
 git_oid oid;
 git_oid loid;
 char *name;




 char *symref_target;
};
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h" 2
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
extern __attribute__((visibility("default"))) int git_refspec_parse(git_refspec **refspec, const char *input, int is_fetch);






extern __attribute__((visibility("default"))) void git_refspec_free(git_refspec *refspec);







extern __attribute__((visibility("default"))) const char * git_refspec_src(const git_refspec *refspec);







extern __attribute__((visibility("default"))) const char * git_refspec_dst(const git_refspec *refspec);







extern __attribute__((visibility("default"))) const char * git_refspec_string(const git_refspec *refspec);







extern __attribute__((visibility("default"))) int git_refspec_force(const git_refspec *refspec);







extern __attribute__((visibility("default"))) git_direction git_refspec_direction(const git_refspec *spec);
# 88 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
extern __attribute__((visibility("default"))) int git_refspec_src_matches_negative(const git_refspec *refspec, const char *refname);
# 97 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
extern __attribute__((visibility("default"))) int git_refspec_src_matches(const git_refspec *refspec, const char *refname);
# 106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
extern __attribute__((visibility("default"))) int git_refspec_dst_matches(const git_refspec *refspec, const char *refname);
# 116 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
extern __attribute__((visibility("default"))) int git_refspec_transform(git_buf *out, const git_refspec *spec, const char *name);
# 126 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refspec.h"
extern __attribute__((visibility("default"))) int git_refspec_rtransform(git_buf *out, const git_refspec *spec, const char *name);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transport.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transport.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cert.h" 1
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cert.h"
typedef enum git_cert_t {




 GIT_CERT_NONE,




 GIT_CERT_X509,




 GIT_CERT_HOSTKEY_LIBSSH2,






 GIT_CERT_STRARRAY
} git_cert_t;




struct git_cert {



 git_cert_t cert_type;
};
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/cert.h"
typedef int (*git_transport_certificate_check_cb)(git_cert *cert, int valid, const char *host, void *payload);




typedef enum {

 GIT_CERT_SSH_MD5 = (1 << 0),

 GIT_CERT_SSH_SHA1 = (1 << 1),

 GIT_CERT_SSH_SHA256 = (1 << 2),

 GIT_CERT_SSH_RAW = (1 << 3)
} git_cert_ssh_t;

typedef enum {

 GIT_CERT_SSH_RAW_TYPE_UNKNOWN = 0,

 GIT_CERT_SSH_RAW_TYPE_RSA = 1,

 GIT_CERT_SSH_RAW_TYPE_DSS = 2,

 GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_256 = 3,

 GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_384 = 4,

 GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_521 = 5,

 GIT_CERT_SSH_RAW_TYPE_KEY_ED25519 = 6
} git_cert_ssh_raw_type_t;




typedef struct {
 git_cert parent;




 git_cert_ssh_t type;





 unsigned char hash_md5[16];





 unsigned char hash_sha1[20];





 unsigned char hash_sha256[32];





 git_cert_ssh_raw_type_t raw_type;





 const char *hostkey;





 size_t hostkey_len;
} git_cert_hostkey;




typedef struct {
 git_cert parent;




 void *data;




 size_t len;
} git_cert_x509;
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transport.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
typedef enum {




 GIT_CREDENTIAL_USERPASS_PLAINTEXT = (1u << 0),





 GIT_CREDENTIAL_SSH_KEY = (1u << 1),





 GIT_CREDENTIAL_SSH_CUSTOM = (1u << 2),





 GIT_CREDENTIAL_DEFAULT = (1u << 3),





 GIT_CREDENTIAL_SSH_INTERACTIVE = (1u << 4),
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
 GIT_CREDENTIAL_USERNAME = (1u << 5),
# 81 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
 GIT_CREDENTIAL_SSH_MEMORY = (1u << 6)
} git_credential_t;




typedef struct git_credential git_credential;

typedef struct git_credential_userpass_plaintext git_credential_userpass_plaintext;


typedef struct git_credential_username git_credential_username;


typedef struct git_credential git_credential_default;




typedef struct git_credential_ssh_key git_credential_ssh_key;




typedef struct git_credential_ssh_interactive git_credential_ssh_interactive;




typedef struct git_credential_ssh_custom git_credential_ssh_custom;
# 134 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
typedef int (*git_credential_acquire_cb)(
 git_credential **out,
 const char *url,
 const char *username_from_url,
 unsigned int allowed_types,
 void *payload);
# 149 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) void git_credential_free(git_credential *cred);







extern __attribute__((visibility("default"))) int git_credential_has_username(git_credential *cred);







extern __attribute__((visibility("default"))) const char * git_credential_get_username(git_credential *cred);
# 176 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_userpass_plaintext_new(
 git_credential **out,
 const char *username,
 const char *password);
# 188 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_default_new(git_credential **out);
# 200 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_username_new(git_credential **out, const char *username);
# 213 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_ssh_key_new(
 git_credential **out,
 const char *username,
 const char *publickey,
 const char *privatekey,
 const char *passphrase);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_ssh_key_memory_new(
 git_credential **out,
 const char *username,
 const char *publickey,
 const char *privatekey,
 const char *passphrase);






typedef struct _LIBSSH2_SESSION LIBSSH2_SESSION;
typedef struct _LIBSSH2_USERAUTH_KBDINT_PROMPT LIBSSH2_USERAUTH_KBDINT_PROMPT;
typedef struct _LIBSSH2_USERAUTH_KBDINT_RESPONSE LIBSSH2_USERAUTH_KBDINT_RESPONSE;
# 259 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
typedef void (*git_credential_ssh_interactive_cb)(
 const char *name,
 int name_len,
 const char *instruction, int instruction_len,
 int num_prompts, const LIBSSH2_USERAUTH_KBDINT_PROMPT *prompts,
 LIBSSH2_USERAUTH_KBDINT_RESPONSE *responses,
 void **abstract);
# 278 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_ssh_interactive_new(
 git_credential **out,
 const char *username,
 git_credential_ssh_interactive_cb prompt_callback,
 void *payload);
# 292 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_ssh_key_from_agent(
 git_credential **out,
 const char *username);
# 308 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
typedef int (*git_credential_sign_cb)(
 LIBSSH2_SESSION *session,
 unsigned char **sig, size_t *sig_len,
 const unsigned char *data, size_t data_len,
 void **abstract);
# 332 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential.h"
extern __attribute__((visibility("default"))) int git_credential_ssh_custom_new(
 git_credential **out,
 const char *username,
 const char *publickey,
 size_t publickey_len,
 git_credential_sign_cb sign_callback,
 void *payload);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transport.h" 2
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transport.h"
typedef int (*git_transport_message_cb)(const char *str, int len, void *payload);
# 45 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transport.h"
typedef int (*git_transport_cb)(git_transport **out, git_remote *owner, void *param);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h" 1
# 52 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
typedef enum {
 GIT_PACKBUILDER_ADDING_OBJECTS = 0,
 GIT_PACKBUILDER_DELTAFICATION = 1
} git_packbuilder_stage_t;
# 65 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_new(git_packbuilder **out, git_repository *repo);
# 78 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) unsigned int git_packbuilder_set_threads(git_packbuilder *pb, unsigned int n);
# 92 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_insert(git_packbuilder *pb, const git_oid *id, const char *name);
# 104 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_insert_tree(git_packbuilder *pb, const git_oid *id);
# 116 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_insert_commit(git_packbuilder *pb, const git_oid *id);
# 129 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_insert_walk(git_packbuilder *pb, git_revwalk *walk);
# 141 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_insert_recur(git_packbuilder *pb, const git_oid *id, const char *name);
# 153 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_write_buf(git_buf *buf, git_packbuilder *pb);
# 166 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_write(
 git_packbuilder *pb,
 const char *path,
 unsigned int mode,
 git_indexer_progress_cb progress_cb,
 void *progress_cb_payload);
# 184 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) const git_oid * git_packbuilder_hash(git_packbuilder *pb);
# 196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) const char * git_packbuilder_name(git_packbuilder *pb);
# 208 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
typedef int (*git_packbuilder_foreach_cb)(void *buf, size_t size, void *payload);
# 218 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_foreach(git_packbuilder *pb, git_packbuilder_foreach_cb cb, void *payload);







extern __attribute__((visibility("default"))) size_t git_packbuilder_object_count(git_packbuilder *pb);







extern __attribute__((visibility("default"))) size_t git_packbuilder_written(git_packbuilder *pb);
# 245 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
typedef int (*git_packbuilder_progress)(
 int stage,
 uint32_t current,
 uint32_t total,
 void *payload);
# 264 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pack.h"
extern __attribute__((visibility("default"))) int git_packbuilder_set_callbacks(
 git_packbuilder *pb,
 git_packbuilder_progress progress_cb,
 void *progress_cb_payload);






extern __attribute__((visibility("default"))) void git_packbuilder_free(git_packbuilder *pb);
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/proxy.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/proxy.h"
typedef enum {






 GIT_PROXY_NONE,



 GIT_PROXY_AUTO,



 GIT_PROXY_SPECIFIED
} git_proxy_t;







typedef struct {
 unsigned int version;




 git_proxy_t type;




 const char *url;
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/proxy.h"
 git_credential_acquire_cb credentials;







 git_transport_certificate_check_cb certificate_check;





 void *payload;
} git_proxy_options;
# 103 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/proxy.h"
extern __attribute__((visibility("default"))) int git_proxy_options_init(git_proxy_options *opts, unsigned int version);
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h" 2
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_create(
  git_remote **out,
  git_repository *repo,
  const char *name,
  const char *url);






typedef enum {




 GIT_REMOTE_REDIRECT_NONE = (1 << 0),





 GIT_REMOTE_REDIRECT_INITIAL = (1 << 1),




 GIT_REMOTE_REDIRECT_ALL = (1 << 2)
} git_remote_redirect_t;




typedef enum {

 GIT_REMOTE_CREATE_SKIP_INSTEADOF = (1 << 0),


 GIT_REMOTE_CREATE_SKIP_DEFAULT_FETCHSPEC = (1 << 1)
} git_remote_create_flags;




typedef enum {

 GIT_REMOTE_UPDATE_FETCHHEAD = (1 << 0),


 GIT_REMOTE_UPDATE_REPORT_UNCHANGED = (1 << 1)
} git_remote_update_flags;
# 97 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef struct git_remote_create_options {
 unsigned int version;





 git_repository *repository;





 const char *name;


 const char *fetchspec;


 unsigned int flags;
} git_remote_create_options;
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_create_options_init(
  git_remote_create_options *opts,
  unsigned int version);
# 151 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_create_with_opts(
  git_remote **out,
  const char *url,
  const git_remote_create_options *opts);
# 167 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_create_with_fetchspec(
  git_remote **out,
  git_repository *repo,
  const char *name,
  const char *url,
  const char *fetch);
# 185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_create_anonymous(
  git_remote **out,
  git_repository *repo,
  const char *url);
# 204 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_create_detached(
  git_remote **out,
  const char *url);
# 219 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_lookup(git_remote **out, git_repository *repo, const char *name);
# 231 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_dup(git_remote **dest, git_remote *source);







extern __attribute__((visibility("default"))) git_repository * git_remote_owner(const git_remote *remote);







extern __attribute__((visibility("default"))) const char * git_remote_name(const git_remote *remote);
# 259 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) const char * git_remote_url(const git_remote *remote);
# 271 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) const char * git_remote_pushurl(const git_remote *remote);
# 284 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_set_url(git_repository *repo, const char *remote, const char *url);
# 298 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_set_pushurl(git_repository *repo, const char *remote, const char *url);
# 308 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_set_instance_url(git_remote *remote, const char *url);
# 318 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_set_instance_pushurl(git_remote *remote, const char *url);
# 331 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_add_fetch(git_repository *repo, const char *remote, const char *refspec);
# 343 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_get_fetch_refspecs(git_strarray *array, const git_remote *remote);
# 356 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_add_push(git_repository *repo, const char *remote, const char *refspec);
# 368 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_get_push_refspecs(git_strarray *array, const git_remote *remote);







extern __attribute__((visibility("default"))) size_t git_remote_refspec_count(const git_remote *remote);
# 385 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) const git_refspec *git_remote_get_refspec(const git_remote *remote, size_t n);
# 407 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_ls(const git_remote_head ***out, size_t *size, git_remote *remote);
# 418 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_connected(const git_remote *remote);
# 429 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_stop(git_remote *remote);
# 439 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_disconnect(git_remote *remote);
# 449 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) void git_remote_free(git_remote *remote);
# 460 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_list(git_strarray *out, git_repository *repo);





typedef enum git_remote_completion_t {
 GIT_REMOTE_COMPLETION_DOWNLOAD,
 GIT_REMOTE_COMPLETION_INDEXING,
 GIT_REMOTE_COMPLETION_ERROR
} git_remote_completion_t;
# 481 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef int (*git_push_transfer_progress_cb)(
 unsigned int current,
 unsigned int total,
 size_t bytes,
 void *payload);




typedef struct {



 char *src_refname;



 char *dst_refname;



 git_oid src;



 git_oid dst;
} git_push_update;
# 518 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef int (*git_push_negotiation)(
 const git_push_update **updates,
 size_t len,
 void *payload);
# 535 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef int (*git_push_update_reference_cb)(const char *refname, const char *status, void *data);
# 551 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef int (*git_url_resolve_cb)(git_buf *url_resolved, const char *url, int direction, void *payload);
# 564 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef int (*git_remote_ready_cb)(git_remote *remote, int direction, void *payload);







struct git_remote_callbacks {
 unsigned int version;






 git_transport_message_cb sideband_progress;





 int (*completion)(git_remote_completion_t type,
  void *data);
# 596 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 git_credential_acquire_cb credentials;







 git_transport_certificate_check_cb certificate_check;






 git_indexer_progress_cb transfer_progress;
# 626 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 int (*update_tips)(const char *refname,
  const git_oid *a, const git_oid *b, void *data);







 git_packbuilder_progress pack_progress;







 git_push_transfer_progress_cb push_transfer_progress;




 git_push_update_reference_cb push_update_reference;





 git_push_negotiation push_negotiation;





 git_transport_cb transport;




 git_remote_ready_cb remote_ready;





 void *payload;
# 683 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 git_url_resolve_cb resolve_url;
# 692 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 int (*update_refs)(
  const char *refname,
  const git_oid *a,
  const git_oid *b,
  git_refspec *spec,
  void *data);
};
# 714 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_init_callbacks(
 git_remote_callbacks *opts,
 unsigned int version);


typedef enum {



 GIT_FETCH_PRUNE_UNSPECIFIED,



 GIT_FETCH_PRUNE,



 GIT_FETCH_NO_PRUNE
} git_fetch_prune_t;






typedef enum {



 GIT_REMOTE_DOWNLOAD_TAGS_UNSPECIFIED = 0,




 GIT_REMOTE_DOWNLOAD_TAGS_AUTO,



 GIT_REMOTE_DOWNLOAD_TAGS_NONE,



 GIT_REMOTE_DOWNLOAD_TAGS_ALL
} git_remote_autotag_option_t;


typedef enum {

 GIT_FETCH_DEPTH_FULL = 0,


 GIT_FETCH_DEPTH_UNSHALLOW = 2147483647
} git_fetch_depth_t;
# 776 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef struct {
 int version;




 git_remote_callbacks callbacks;




 git_fetch_prune_t prune;




 unsigned int update_fetchhead;
# 801 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 git_remote_autotag_option_t download_tags;




 git_proxy_options proxy_opts;
# 815 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 int depth;






 git_remote_redirect_t follow_redirects;




 git_strarray custom_headers;
} git_fetch_options;
# 852 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_fetch_options_init(
 git_fetch_options *opts,
 unsigned int version);





typedef struct {
 unsigned int version;
# 871 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 unsigned int pb_parallelism;




 git_remote_callbacks callbacks;




 git_proxy_options proxy_opts;






 git_remote_redirect_t follow_redirects;




 git_strarray custom_headers;




 git_strarray remote_push_options;
} git_push_options;
# 917 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_push_options_init(
 git_push_options *opts,
 unsigned int version);
# 928 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
typedef struct {
 unsigned int version;


 git_remote_callbacks callbacks;


 git_proxy_options proxy_opts;






 git_remote_redirect_t follow_redirects;


 git_strarray custom_headers;
} git_remote_connect_options;
# 968 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_connect_options_init(
  git_remote_connect_options *opts,
  unsigned int version);
# 987 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_connect(
 git_remote *remote,
 git_direction direction,
 const git_remote_callbacks *callbacks,
 const git_proxy_options *proxy_opts,
 const git_strarray *custom_headers);
# 1012 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_connect_ext(
 git_remote *remote,
 git_direction direction,
 const git_remote_connect_options *opts);
# 1037 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
 extern __attribute__((visibility("default"))) int git_remote_download(
 git_remote *remote,
 const git_strarray *refspecs,
 const git_fetch_options *opts);
# 1059 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_upload(
 git_remote *remote,
 const git_strarray *refspecs,
 const git_push_options *opts);
# 1081 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_update_tips(
  git_remote *remote,
  const git_remote_callbacks *callbacks,
  unsigned int update_flags,
  git_remote_autotag_option_t download_tags,
  const char *reflog_message);
# 1106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_fetch(
  git_remote *remote,
  const git_strarray *refspecs,
  const git_fetch_options *opts,
  const char *reflog_message);
# 1122 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_prune(
 git_remote *remote,
 const git_remote_callbacks *callbacks);
# 1139 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_push(
 git_remote *remote,
 const git_strarray *refspecs,
 const git_push_options *opts);







extern __attribute__((visibility("default"))) const git_indexer_progress * git_remote_stats(git_remote *remote);







extern __attribute__((visibility("default"))) git_remote_autotag_option_t git_remote_autotag(const git_remote *remote);
# 1171 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_set_autotag(git_repository *repo, const char *remote, git_remote_autotag_option_t value);







extern __attribute__((visibility("default"))) int git_remote_prune_refs(const git_remote *remote);
# 1201 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_rename(
 git_strarray *problems,
 git_repository *repo,
 const char *name,
 const char *new_name);
# 1214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_name_is_valid(int *valid, const char *remote_name);
# 1226 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_delete(git_repository *repo, const char *name);
# 1244 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/remote.h"
extern __attribute__((visibility("default"))) int git_remote_default_branch(git_buf *out, git_remote *remote);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h" 2
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
typedef enum {





 GIT_CLONE_LOCAL_AUTO,



 GIT_CLONE_LOCAL,



 GIT_CLONE_NO_LOCAL,




 GIT_CLONE_LOCAL_NO_LINKS
} git_clone_local_t;
# 73 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
typedef int (*git_remote_create_cb)(
 git_remote **out,
 git_repository *repo,
 const char *name,
 const char *url,
 void *payload);
# 94 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
typedef int (*git_repository_create_cb)(
 git_repository **out,
 const char *path,
 int bare,
 void *payload);
# 110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
typedef struct git_clone_options {
 unsigned int version;






 git_checkout_options checkout_opts;







 git_fetch_options fetch_opts;





 int bare;




 git_clone_local_t local;





 const char *checkout_branch;






 git_repository_create_cb repository_cb;





 void *repository_cb_payload;







 git_remote_create_cb remote_cb;





 void *remote_cb_payload;
} git_clone_options;
# 192 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
extern __attribute__((visibility("default"))) int git_clone_options_init(
 git_clone_options *opts,
 unsigned int version);
# 216 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/clone.h"
extern __attribute__((visibility("default"))) int git_clone(
 git_repository **out,
 const char *url,
 const char *local_path,
 const git_clone_options *options);
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h" 1
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
typedef enum {
 GIT_DESCRIBE_DEFAULT,
 GIT_DESCRIBE_TAGS,
 GIT_DESCRIBE_ALL
} git_describe_strategy_t;
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
typedef struct git_describe_options {
 unsigned int version;

 unsigned int max_candidates_tags;
 unsigned int describe_strategy;
 const char *pattern;




 int only_follow_first_parent;






 int show_commit_oid_as_fallback;
} git_describe_options;
# 91 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
extern __attribute__((visibility("default"))) int git_describe_options_init(git_describe_options *opts, unsigned int version);
# 100 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
typedef struct {
 unsigned int version;






 unsigned int abbreviated_size;




 int always_use_long_format;





 const char *dirty_suffix;
} git_describe_format_options;
# 141 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
extern __attribute__((visibility("default"))) int git_describe_format_options_init(git_describe_format_options *opts, unsigned int version);




typedef struct git_describe_result git_describe_result;
# 159 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
extern __attribute__((visibility("default"))) int git_describe_commit(
 git_describe_result **result,
 git_object *committish,
 git_describe_options *opts);
# 177 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
extern __attribute__((visibility("default"))) int git_describe_workdir(
 git_describe_result **out,
 git_repository *repo,
 git_describe_options *opts);
# 191 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/describe.h"
extern __attribute__((visibility("default"))) int git_describe_format(
 git_buf *out,
 const git_describe_result *result,
 const git_describe_format_options *opts);






extern __attribute__((visibility("default"))) void git_describe_result_free(git_describe_result *result);
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h" 1
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
typedef enum {
 GIT_FILTER_TO_WORKTREE = 0,
 GIT_FILTER_SMUDGE = GIT_FILTER_TO_WORKTREE,
 GIT_FILTER_TO_ODB = 1,
 GIT_FILTER_CLEAN = GIT_FILTER_TO_ODB
} git_filter_mode_t;




typedef enum {
 GIT_FILTER_DEFAULT = 0u,


 GIT_FILTER_ALLOW_UNSAFE = (1u << 0),


 GIT_FILTER_NO_SYSTEM_ATTRIBUTES = (1u << 1),


 GIT_FILTER_ATTRIBUTES_FROM_HEAD = (1u << 2),





 GIT_FILTER_ATTRIBUTES_FROM_COMMIT = (1u << 3)
} git_filter_flag_t;




typedef struct {
 unsigned int version;


 uint32_t flags;




 git_oid *commit_id;






 git_oid attr_commit_id;
} git_filter_options;
# 109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
typedef struct git_filter git_filter;
# 121 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
typedef struct git_filter_list git_filter_list;
# 138 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_load(
 git_filter_list **filters,
 git_repository *repo,
 git_blob *blob,
 const char *path,
 git_filter_mode_t mode,
 uint32_t flags);
# 161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_load_ext(
 git_filter_list **filters,
 git_repository *repo,
 git_blob *blob,
 const char *path,
 git_filter_mode_t mode,
 git_filter_options *opts);
# 181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_contains(
 git_filter_list *filters,
 const char *name);
# 194 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_apply_to_buffer(
 git_buf *out,
 git_filter_list *filters,
 const char *in,
 size_t in_len);
# 210 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_apply_to_file(
 git_buf *out,
 git_filter_list *filters,
 git_repository *repo,
 const char *path);
# 224 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_apply_to_blob(
 git_buf *out,
 git_filter_list *filters,
 git_blob *blob);
# 238 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_stream_buffer(
 git_filter_list *filters,
 const char *buffer,
 size_t len,
 git_writestream *target);
# 254 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_stream_file(
 git_filter_list *filters,
 git_repository *repo,
 const char *path,
 git_writestream *target);
# 268 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_stream_blob(
 git_filter_list *filters,
 git_blob *blob,
 git_writestream *target);






extern __attribute__((visibility("default"))) void git_filter_list_free(git_filter_list *filters);
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2






# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h" 1
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
typedef struct {
 unsigned int version;
# 42 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
 int quiet;
# 51 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
 int inmemory;
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
 const char *rewrite_notes_ref;




 git_merge_options merge_options;







 git_checkout_options checkout_options;
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
 git_commit_create_cb commit_create_cb;
# 106 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
 int (*signing_cb)(git_buf *, git_buf *, const char *, void *);






 void *payload;
} git_rebase_options;




typedef enum {




 GIT_REBASE_OPERATION_PICK = 0,





 GIT_REBASE_OPERATION_REWORD,





 GIT_REBASE_OPERATION_EDIT,





 GIT_REBASE_OPERATION_SQUASH,





 GIT_REBASE_OPERATION_FIXUP,





 GIT_REBASE_OPERATION_EXEC
} git_rebase_operation_t;
# 174 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
typedef struct {

 git_rebase_operation_t type;





 const git_oid id;





 const char *exec;
} git_rebase_operation;
# 201 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_options_init(
 git_rebase_options *opts,
 unsigned int version);
# 222 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_init(
 git_rebase **out,
 git_repository *repo,
 const git_annotated_commit *branch,
 const git_annotated_commit *upstream,
 const git_annotated_commit *onto,
 const git_rebase_options *opts);
# 239 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_open(
 git_rebase **out,
 git_repository *repo,
 const git_rebase_options *opts);







extern __attribute__((visibility("default"))) const char * git_rebase_orig_head_name(git_rebase *rebase);







extern __attribute__((visibility("default"))) const git_oid * git_rebase_orig_head_id(git_rebase *rebase);







extern __attribute__((visibility("default"))) const char * git_rebase_onto_name(git_rebase *rebase);







extern __attribute__((visibility("default"))) const git_oid * git_rebase_onto_id(git_rebase *rebase);







extern __attribute__((visibility("default"))) size_t git_rebase_operation_entrycount(git_rebase *rebase);
# 293 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) size_t git_rebase_operation_current(git_rebase *rebase);
# 302 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) git_rebase_operation * git_rebase_operation_byindex(
 git_rebase *rebase,
 size_t idx);
# 317 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_next(
 git_rebase_operation **operation,
 git_rebase *rebase);
# 336 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_inmemory_index(
 git_index **index,
 git_rebase *rebase);
# 362 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_commit(
 git_oid *id,
 git_rebase *rebase,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message);
# 378 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_abort(git_rebase *rebase);
# 388 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/rebase.h"
extern __attribute__((visibility("default"))) int git_rebase_finish(
 git_rebase *rebase,
 const git_signature *signature);






extern __attribute__((visibility("default"))) void git_rebase_free(git_rebase *rebase);
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/trace.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/trace.h"
typedef enum {

 GIT_TRACE_NONE = 0,


 GIT_TRACE_FATAL = 1,


 GIT_TRACE_ERROR = 2,


 GIT_TRACE_WARN = 3,


 GIT_TRACE_INFO = 4,


 GIT_TRACE_DEBUG = 5,


 GIT_TRACE_TRACE = 6
} git_trace_level_t;







typedef void (*git_trace_cb)(
 git_trace_level_t level,
 const char *msg);
# 68 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/trace.h"
extern __attribute__((visibility("default"))) int git_trace_set(git_trace_level_t level, git_trace_cb cb);
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revert.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revert.h"
typedef struct {
 unsigned int version;


 unsigned int mainline;

 git_merge_options merge_opts;
 git_checkout_options checkout_opts;
} git_revert_options;
# 54 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revert.h"
extern __attribute__((visibility("default"))) int git_revert_options_init(
 git_revert_options *opts,
 unsigned int version);
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revert.h"
extern __attribute__((visibility("default"))) int git_revert_commit(
 git_index **out,
 git_repository *repo,
 git_commit *revert_commit,
 git_commit *our_commit,
 unsigned int mainline,
 const git_merge_options *merge_options);
# 88 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revert.h"
extern __attribute__((visibility("default"))) int git_revert(
 git_repository *repo,
 git_commit *commit,
 const git_revert_options *given_opts);
# 33 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revparse.h" 1
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revparse.h"
extern __attribute__((visibility("default"))) int git_revparse_single(
 git_object **out, git_repository *repo, const char *spec);
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revparse.h"
extern __attribute__((visibility("default"))) int git_revparse_ext(
 git_object **object_out,
 git_reference **reference_out,
 git_repository *repo,
 const char *spec);





typedef enum {

 GIT_REVSPEC_SINGLE = 1 << 0,

 GIT_REVSPEC_RANGE = 1 << 1,

 GIT_REVSPEC_MERGE_BASE = 1 << 2
} git_revspec_t;




typedef struct {

 git_object *from;

 git_object *to;

 unsigned int flags;
} git_revspec;
# 105 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revparse.h"
extern __attribute__((visibility("default"))) int git_revparse(
 git_revspec *revspec,
 git_repository *repo,
 const char *spec);
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
typedef enum {



 GIT_STASH_DEFAULT = 0,





 GIT_STASH_KEEP_INDEX = (1 << 0),





 GIT_STASH_INCLUDE_UNTRACKED = (1 << 1),





 GIT_STASH_INCLUDE_IGNORED = (1 << 2),




 GIT_STASH_KEEP_ALL = (1 << 3)
} git_stash_flags;
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_save(
 git_oid *out,
 git_repository *repo,
 const git_signature *stasher,
 const char *message,
 uint32_t flags);
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
typedef struct git_stash_save_options {
 unsigned int version;


 uint32_t flags;


 const git_signature *stasher;


 const char *message;


 git_strarray paths;
} git_stash_save_options;
# 118 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_save_options_init(
 git_stash_save_options *opts, unsigned int version);
# 131 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_save_with_opts(
 git_oid *out,
 git_repository *repo,
 const git_stash_save_options *opts);


typedef enum {
 GIT_STASH_APPLY_DEFAULT = 0,




 GIT_STASH_APPLY_REINSTATE_INDEX = (1 << 0)
} git_stash_apply_flags;


typedef enum {
 GIT_STASH_APPLY_PROGRESS_NONE = 0,


 GIT_STASH_APPLY_PROGRESS_LOADING_STASH,


 GIT_STASH_APPLY_PROGRESS_ANALYZE_INDEX,


 GIT_STASH_APPLY_PROGRESS_ANALYZE_MODIFIED,


 GIT_STASH_APPLY_PROGRESS_ANALYZE_UNTRACKED,


 GIT_STASH_APPLY_PROGRESS_CHECKOUT_UNTRACKED,


 GIT_STASH_APPLY_PROGRESS_CHECKOUT_MODIFIED,


 GIT_STASH_APPLY_PROGRESS_DONE
} git_stash_apply_progress_t;
# 181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
typedef int (*git_stash_apply_progress_cb)(
 git_stash_apply_progress_t progress,
 void *payload);
# 192 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
typedef struct git_stash_apply_options {
 unsigned int version;


 uint32_t flags;


 git_checkout_options checkout_options;


 git_stash_apply_progress_cb progress_cb;
 void *progress_payload;
} git_stash_apply_options;
# 225 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_apply_options_init(
 git_stash_apply_options *opts, unsigned int version);
# 252 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_apply(
 git_repository *repo,
 size_t index,
 const git_stash_apply_options *options);
# 268 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
typedef int (*git_stash_cb)(
 size_t index,
 const char *message,
 const git_oid *stash_id,
 void *payload);
# 288 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_foreach(
 git_repository *repo,
 git_stash_cb callback,
 void *payload);
# 304 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_drop(
 git_repository *repo,
 size_t index);
# 320 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/stash.h"
extern __attribute__((visibility("default"))) int git_stash_pop(
 git_repository *repo,
 size_t index,
 const git_stash_apply_options *options);
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h" 1
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
typedef enum {
 GIT_STATUS_CURRENT = 0,

 GIT_STATUS_INDEX_NEW = (1u << 0),
 GIT_STATUS_INDEX_MODIFIED = (1u << 1),
 GIT_STATUS_INDEX_DELETED = (1u << 2),
 GIT_STATUS_INDEX_RENAMED = (1u << 3),
 GIT_STATUS_INDEX_TYPECHANGE = (1u << 4),

 GIT_STATUS_WT_NEW = (1u << 7),
 GIT_STATUS_WT_MODIFIED = (1u << 8),
 GIT_STATUS_WT_DELETED = (1u << 9),
 GIT_STATUS_WT_TYPECHANGE = (1u << 10),
 GIT_STATUS_WT_RENAMED = (1u << 11),
 GIT_STATUS_WT_UNREADABLE = (1u << 12),

 GIT_STATUS_IGNORED = (1u << 14),
 GIT_STATUS_CONFLICTED = (1u << 15)
} git_status_t;
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
typedef int (*git_status_cb)(
 const char *path, unsigned int status_flags, void *payload);
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
typedef enum {




 GIT_STATUS_SHOW_INDEX_AND_WORKDIR = 0,





 GIT_STATUS_SHOW_INDEX_ONLY = 1,





 GIT_STATUS_SHOW_WORKDIR_ONLY = 2
} git_status_show_t;
# 100 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
typedef enum {





 GIT_STATUS_OPT_INCLUDE_UNTRACKED = (1u << 0),






 GIT_STATUS_OPT_INCLUDE_IGNORED = (1u << 1),




 GIT_STATUS_OPT_INCLUDE_UNMODIFIED = (1u << 2),






 GIT_STATUS_OPT_EXCLUDE_SUBMODULES = (1u << 3),
# 134 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
 GIT_STATUS_OPT_RECURSE_UNTRACKED_DIRS = (1u << 4),





 GIT_STATUS_OPT_DISABLE_PATHSPEC_MATCH = (1u << 5),






 GIT_STATUS_OPT_RECURSE_IGNORED_DIRS = (1u << 6),






 GIT_STATUS_OPT_RENAMES_HEAD_TO_INDEX = (1u << 7),






 GIT_STATUS_OPT_RENAMES_INDEX_TO_WORKDIR = (1u << 8),





 GIT_STATUS_OPT_SORT_CASE_SENSITIVELY = (1u << 9),





 GIT_STATUS_OPT_SORT_CASE_INSENSITIVELY = (1u << 10),




 GIT_STATUS_OPT_RENAMES_FROM_REWRITES = (1u << 11),






 GIT_STATUS_OPT_NO_REFRESH = (1u << 12),







 GIT_STATUS_OPT_UPDATE_INDEX = (1u << 13),






 GIT_STATUS_OPT_INCLUDE_UNREADABLE = (1u << 14),





 GIT_STATUS_OPT_INCLUDE_UNREADABLE_AS_UNTRACKED = (1u << 15)
} git_status_opt_t;
# 222 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
typedef struct {



 unsigned int version;






 git_status_show_t show;







 unsigned int flags;







 git_strarray pathspec;





 git_tree *baseline;





 uint16_t rename_threshold;
} git_status_options;
# 280 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) int git_status_options_init(
 git_status_options *opts,
 unsigned int version);
# 298 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
typedef struct {
 git_status_t status;
 git_diff_delta *head_to_index;
 git_diff_delta *index_to_workdir;
} git_status_entry;
# 320 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) int git_status_foreach(
 git_repository *repo,
 git_status_cb callback,
 void *payload);
# 344 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) int git_status_foreach_ext(
 git_repository *repo,
 const git_status_options *opts,
 git_status_cb callback,
 void *payload);
# 376 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) int git_status_file(
 unsigned int *status_flags,
 git_repository *repo,
 const char *path);
# 394 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) int git_status_list_new(
 git_status_list **out,
 git_repository *repo,
 const git_status_options *opts);
# 408 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) size_t git_status_list_entrycount(
 git_status_list *statuslist);
# 420 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) const git_status_entry * git_status_byindex(
 git_status_list *statuslist,
 size_t idx);






extern __attribute__((visibility("default"))) void git_status_list_free(
 git_status_list *statuslist);
# 448 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/status.h"
extern __attribute__((visibility("default"))) int git_status_should_ignore(
 int *ignored,
 git_repository *repo,
 const char *path);
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h" 1
# 74 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
typedef enum {
 GIT_SUBMODULE_STATUS_IN_HEAD = (1u << 0),
 GIT_SUBMODULE_STATUS_IN_INDEX = (1u << 1),
 GIT_SUBMODULE_STATUS_IN_CONFIG = (1u << 2),
 GIT_SUBMODULE_STATUS_IN_WD = (1u << 3),
 GIT_SUBMODULE_STATUS_INDEX_ADDED = (1u << 4),
 GIT_SUBMODULE_STATUS_INDEX_DELETED = (1u << 5),
 GIT_SUBMODULE_STATUS_INDEX_MODIFIED = (1u << 6),
 GIT_SUBMODULE_STATUS_WD_UNINITIALIZED = (1u << 7),
 GIT_SUBMODULE_STATUS_WD_ADDED = (1u << 8),
 GIT_SUBMODULE_STATUS_WD_DELETED = (1u << 9),
 GIT_SUBMODULE_STATUS_WD_MODIFIED = (1u << 10),
 GIT_SUBMODULE_STATUS_WD_INDEX_MODIFIED = (1u << 11),
 GIT_SUBMODULE_STATUS_WD_WD_MODIFIED = (1u << 12),
 GIT_SUBMODULE_STATUS_WD_UNTRACKED = (1u << 13)
} git_submodule_status_t;
# 125 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
typedef int (*git_submodule_cb)(
 git_submodule *sm, const char *name, void *payload);
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
typedef struct git_submodule_update_options {
 unsigned int version;






 git_checkout_options checkout_opts;







 git_fetch_options fetch_opts;





 int allow_fetch;
} git_submodule_update_options;
# 180 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_update_options_init(
 git_submodule_update_options *opts, unsigned int version);
# 201 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_update(git_submodule *submodule, int init, git_submodule_update_options *options);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_lookup(
 git_submodule **out,
 git_repository *repo,
 const char *name);
# 243 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_dup(git_submodule **out, git_submodule *source);






extern __attribute__((visibility("default"))) void git_submodule_free(git_submodule *submodule);
# 270 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_foreach(
 git_repository *repo,
 git_submodule_cb callback,
 void *payload);
# 301 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_add_setup(
 git_submodule **out,
 git_repository *repo,
 const char *url,
 const char *path,
 int use_gitlink);
# 319 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_clone(
 git_repository **out,
 git_submodule *submodule,
 const git_submodule_update_options *opts);
# 335 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_add_finalize(git_submodule *submodule);
# 347 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_add_to_index(
 git_submodule *submodule,
 int write_index);
# 362 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) git_repository * git_submodule_owner(git_submodule *submodule);







extern __attribute__((visibility("default"))) const char * git_submodule_name(git_submodule *submodule);
# 381 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) const char * git_submodule_path(git_submodule *submodule);







extern __attribute__((visibility("default"))) const char * git_submodule_url(git_submodule *submodule);
# 399 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_resolve_url(git_buf *out, git_repository *repo, const char *url);







extern __attribute__((visibility("default"))) const char * git_submodule_branch(git_submodule *submodule);
# 420 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_set_branch(git_repository *repo, const char *name, const char *branch);
# 434 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_set_url(git_repository *repo, const char *name, const char *url);







extern __attribute__((visibility("default"))) const git_oid * git_submodule_index_id(git_submodule *submodule);







extern __attribute__((visibility("default"))) const git_oid * git_submodule_head_id(git_submodule *submodule);
# 463 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) const git_oid * git_submodule_wd_id(git_submodule *submodule);
# 488 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) git_submodule_ignore_t git_submodule_ignore(
 git_submodule *submodule);
# 501 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_set_ignore(
 git_repository *repo,
 const char *name,
 git_submodule_ignore_t ignore);
# 516 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) git_submodule_update_t git_submodule_update_strategy(
 git_submodule *submodule);
# 529 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_set_update(
 git_repository *repo,
 const char *name,
 git_submodule_update_t update);
# 546 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) git_submodule_recurse_t git_submodule_fetch_recurse_submodules(
 git_submodule *submodule);
# 559 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_set_fetch_recurse_submodules(
 git_repository *repo,
 const char *name,
 git_submodule_recurse_t fetch_recurse_submodules);
# 577 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_init(git_submodule *submodule, int overwrite);
# 592 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_repo_init(
 git_repository **out,
 const git_submodule *sm,
 int use_gitlink);
# 608 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_sync(git_submodule *submodule);
# 622 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_open(
 git_repository **repo,
 git_submodule *submodule);
# 636 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_reload(git_submodule *submodule, int force);
# 652 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_status(
 unsigned int *status,
 git_repository *repo,
 const char *name,
 git_submodule_ignore_t ignore);
# 672 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/submodule.h"
extern __attribute__((visibility("default"))) int git_submodule_location(
 unsigned int *location_status,
 git_submodule *submodule);
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h" 1
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_list(git_strarray *out, git_repository *repo);
# 45 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_lookup(git_worktree **out, git_repository *repo, const char *name);
# 58 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_open_from_repository(git_worktree **out, git_repository *repo);






extern __attribute__((visibility("default"))) void git_worktree_free(git_worktree *wt);
# 77 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_validate(const git_worktree *wt);
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
typedef struct git_worktree_add_options {
 unsigned int version;

 int lock;
 int checkout_existing;
 git_reference *ref;




 git_checkout_options checkout_options;
} git_worktree_add_options;
# 116 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_add_options_init(git_worktree_add_options *opts,
 unsigned int version);
# 133 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_add(git_worktree **out, git_repository *repo,
 const char *name, const char *path,
 const git_worktree_add_options *opts);
# 147 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_lock(git_worktree *wt, const char *reason);
# 156 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_unlock(git_worktree *wt);
# 170 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_is_locked(git_buf *reason, const git_worktree *wt);
# 179 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) const char * git_worktree_name(const git_worktree *wt);
# 188 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) const char * git_worktree_path(const git_worktree *wt);





typedef enum {

 GIT_WORKTREE_PRUNE_VALID = 1u << 0,

 GIT_WORKTREE_PRUNE_LOCKED = 1u << 1,

 GIT_WORKTREE_PRUNE_WORKING_TREE = 1u << 2
} git_worktree_prune_t;
# 210 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
typedef struct git_worktree_prune_options {
 unsigned int version;


 uint32_t flags;
} git_worktree_prune_options;
# 233 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_prune_options_init(
 git_worktree_prune_options *opts,
 unsigned int version);
# 257 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_is_prunable(git_worktree *wt,
 git_worktree_prune_options *opts);
# 272 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/worktree.h"
extern __attribute__((visibility("default"))) int git_worktree_prune(git_worktree *wt,
 git_worktree_prune_options *opts);
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential_helpers.h" 1
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential_helpers.h"
typedef struct git_credential_userpass_payload {
 const char *username;
 const char *password;
} git_credential_userpass_payload;
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/credential_helpers.h"
extern __attribute__((visibility("default"))) int git_credential_userpass(
  git_credential **out,
  const char *url,
  const char *user_from_url,
  unsigned int allowed_types,
  void *payload);
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 51 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/credential.h" 1
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/credential.h"
struct git_credential {
 git_credential_t credtype;


 void (*free)(git_credential *cred);
};


struct git_credential_userpass_plaintext {
 git_credential parent;
 char *username;
 char *password;
};


struct git_credential_username {
 git_credential parent;
 char username[1];
};




struct git_credential_ssh_key {
 git_credential parent;
 char *username;
 char *publickey;
 char *privatekey;
 char *passphrase;
};




struct git_credential_ssh_interactive {
 git_credential parent;
 char *username;




 git_credential_ssh_interactive_cb prompt_callback;

 void *payload;
};




struct git_credential_ssh_custom {
 git_credential parent;
 char *username;
 char *publickey;
 size_t publickey_len;




 git_credential_sign_cb sign_callback;

 void *payload;
};
# 52 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h" 2
# 89 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef git_attr_value_t git_attr_t;
# 107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_blob_create_fromworkdir(git_oid *id, git_repository *repo, const char *relative_path);
extern __attribute__((visibility("default"))) int git_blob_create_fromdisk(git_oid *id, git_repository *repo, const char *path);
extern __attribute__((visibility("default"))) int git_blob_create_fromstream(
 git_writestream **out,
 git_repository *repo,
 const char *hintpath);
extern __attribute__((visibility("default"))) int git_blob_create_fromstream_commit(
 git_oid *out,
 git_writestream *stream);
extern __attribute__((visibility("default"))) int git_blob_create_frombuffer(
 git_oid *id, git_repository *repo, const void *buffer, size_t len);






extern __attribute__((visibility("default"))) int git_blob_filtered_content(
 git_buf *out,
 git_blob *blob,
 const char *as_path,
 int check_for_binary_data);
# 148 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_filter_list_stream_data(
 git_filter_list *filters,
 git_buf *data,
 git_writestream *target);






extern __attribute__((visibility("default"))) int git_filter_list_apply_to_data(
 git_buf *out,
 git_filter_list *filters,
 git_buf *in);
# 187 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_treebuilder_write_with_buffer(
 git_oid *oid, git_treebuilder *bld, git_buf *tree);
# 229 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_buf_grow(git_buf *buffer, size_t target_size);
# 239 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_buf_set(
 git_buf *buffer, const void *data, size_t datalen);







extern __attribute__((visibility("default"))) int git_buf_is_binary(const git_buf *buf);







extern __attribute__((visibility("default"))) int git_buf_contains_nul(const git_buf *buf);
# 268 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void git_buf_free(git_buf *buffer);
# 285 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef int (*git_commit_signing_cb)(
 git_buf *signature,
 git_buf *signature_field,
 const char *commit_content,
 void *payload);
# 307 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef git_configmap git_cvar_map;
# 325 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef enum {

 GIT_DIFF_FORMAT_EMAIL_NONE = 0,


 GIT_DIFF_FORMAT_EMAIL_EXCLUDE_SUBJECT_PATCH_MARKER = (1 << 0)
} git_diff_format_email_flags_t;






typedef struct {
 unsigned int version;


 uint32_t flags;


 size_t patch_no;


 size_t total_patches;


 const git_oid *id;


 const char *summary;


 const char *body;


 const git_signature *author;
} git_diff_format_email_options;
# 374 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_diff_format_email(
 git_buf *out,
 git_diff *diff,
 const git_diff_format_email_options *opts);







extern __attribute__((visibility("default"))) int git_diff_commit_as_email(
 git_buf *out,
 git_repository *repo,
 git_commit *commit,
 size_t patch_no,
 size_t total_patches,
 uint32_t flags,
 const git_diff_options *diff_opts);
# 404 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_diff_format_email_options_init(
 git_diff_format_email_options *opts,
 unsigned int version);
# 503 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) const git_error * giterr_last(void);
# 515 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void giterr_clear(void);
# 527 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void giterr_set_str(int error_class, const char *string);
# 539 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void giterr_set_oom(void);
# 613 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_index_add_frombuffer(
 git_index *index,
 const git_index_entry *entry,
 const void *buffer, size_t len);
# 666 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) size_t git_object__size(git_object_t type);
# 687 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_remote_is_valid_name(const char *remote_name);
# 741 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_reference_is_valid_name(const char *refname);

extern __attribute__((visibility("default"))) int git_tag_create_frombuffer(
 git_oid *oid,
 git_repository *repo,
 const char *buffer,
 int force);
# 762 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef git_revspec_t git_revparse_mode_t;
# 783 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef git_credential git_cred;
typedef git_credential_userpass_plaintext git_cred_userpass_plaintext;
typedef git_credential_username git_cred_username;
typedef git_credential_default git_cred_default;
typedef git_credential_ssh_key git_cred_ssh_key;
typedef git_credential_ssh_interactive git_cred_ssh_interactive;
typedef git_credential_ssh_custom git_cred_ssh_custom;

typedef git_credential_acquire_cb git_cred_acquire_cb;
typedef git_credential_sign_cb git_cred_sign_callback;
typedef git_credential_sign_cb git_cred_sign_cb;
typedef git_credential_ssh_interactive_cb git_cred_ssh_interactive_callback;
typedef git_credential_ssh_interactive_cb git_cred_ssh_interactive_cb;
# 815 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void git_cred_free(git_credential *cred);
extern __attribute__((visibility("default"))) int git_cred_has_username(git_credential *cred);
extern __attribute__((visibility("default"))) const char * git_cred_get_username(git_credential *cred);
extern __attribute__((visibility("default"))) int git_cred_userpass_plaintext_new(
 git_credential **out,
 const char *username,
 const char *password);
extern __attribute__((visibility("default"))) int git_cred_default_new(git_credential **out);
extern __attribute__((visibility("default"))) int git_cred_username_new(git_credential **out, const char *username);
extern __attribute__((visibility("default"))) int git_cred_ssh_key_new(
 git_credential **out,
 const char *username,
 const char *publickey,
 const char *privatekey,
 const char *passphrase);
extern __attribute__((visibility("default"))) int git_cred_ssh_key_memory_new(
 git_credential **out,
 const char *username,
 const char *publickey,
 const char *privatekey,
 const char *passphrase);
extern __attribute__((visibility("default"))) int git_cred_ssh_interactive_new(
 git_credential **out,
 const char *username,
 git_credential_ssh_interactive_cb prompt_callback,
 void *payload);
extern __attribute__((visibility("default"))) int git_cred_ssh_key_from_agent(
 git_credential **out,
 const char *username);
extern __attribute__((visibility("default"))) int git_cred_ssh_custom_new(
 git_credential **out,
 const char *username,
 const char *publickey,
 size_t publickey_len,
 git_credential_sign_cb sign_callback,
 void *payload);



typedef git_credential_userpass_payload git_cred_userpass_payload;

extern __attribute__((visibility("default"))) int git_cred_userpass(
 git_credential **out,
 const char *url,
 const char *user_from_url,
 unsigned int allowed_types,
 void *payload);
# 875 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef git_trace_cb git_trace_callback;
# 898 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_oid_iszero(const git_oid *id);
# 922 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void git_oidarray_free(git_oidarray *array);
# 943 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
typedef git_indexer_progress git_transfer_progress;







typedef git_indexer_progress_cb git_transfer_progress_cb;







typedef git_push_transfer_progress_cb git_push_transfer_progress;







typedef int (*git_headlist_cb)(git_remote_head *rhead, void *payload);
# 991 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_strarray_copy(git_strarray *tgt, const git_strarray *src);
# 1003 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) void git_strarray_free(git_strarray *array);
# 1035 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/deprecated.h"
extern __attribute__((visibility("default"))) int git_blame_init_options(git_blame_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_checkout_init_options(git_checkout_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_cherrypick_init_options(git_cherrypick_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_clone_init_options(git_clone_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_describe_init_options(git_describe_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_describe_init_format_options(git_describe_format_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_diff_init_options(git_diff_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_diff_find_init_options(git_diff_find_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_diff_format_email_init_options(git_diff_format_email_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_diff_patchid_init_options(git_diff_patchid_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_fetch_init_options(git_fetch_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_indexer_init_options(git_indexer_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_merge_init_options(git_merge_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_merge_file_init_input(git_merge_file_input *input, unsigned int version);
extern __attribute__((visibility("default"))) int git_merge_file_init_options(git_merge_file_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_proxy_init_options(git_proxy_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_push_init_options(git_push_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_rebase_init_options(git_rebase_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_remote_create_init_options(git_remote_create_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_repository_init_init_options(git_repository_init_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_revert_init_options(git_revert_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_stash_apply_init_options(git_stash_apply_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_status_init_options(git_status_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_submodule_update_init_options(git_submodule_update_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_worktree_add_init_options(git_worktree_add_options *opts, unsigned int version);
extern __attribute__((visibility("default"))) int git_worktree_prune_init_options(git_worktree_prune_options *opts, unsigned int version);
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/common.h" 2






static __inline__ void git__init_structure(void *structure, size_t len, unsigned int version)
{
 memset(structure, 0, len);
 *((int*)structure) = version;
}
# 39 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/common.h"
static __inline__ int git_error__check_version(const void *structure, unsigned int expected_max, const char *name)
{
 unsigned int actual;

 if (!structure)
  return 0;

 actual = *(const unsigned int*)structure;
 if (actual > 0 && actual <= expected_max)
  return 0;

 git_error_set(GIT_ERROR_INVALID, "invalid version %d on %s", actual, name);
 return -1;
}
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2








# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/array.h" 1
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/array.h"
static __inline__ void * git_array__alloc(void *arr, size_t *size, size_t *asize, size_t item_size)
{
 size_t new_size;
 void *new_array;

 if (*size < *asize)
  return arr;

 if (*size < 8) {
  new_size = 8;
 } else {
  if ((__builtin_umull_overflow(*asize, 3, &new_size) ? (git_error_set_oom(), 1) : 0))
   goto on_oom;

  new_size /= 2;
 }

 if ((new_array = git__reallocarray(arr, new_size, item_size)) == ((void*)0))
  goto on_oom;

 *asize = new_size;

 return new_array;

on_oom:
 git__free(arr);
 *size = 0;
 *asize = 0;
 return ((void*)0);
}
# 92 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/array.h"
typedef int (*git_array_compare_cb)(const void *, const void *);

static __inline__ int git_array__search(
 size_t *out,
 void *array_ptr,
 size_t item_size,
 size_t array_len,
 git_array_compare_cb compare,
 const void *key)
{
 size_t lim;
 unsigned char *part, *array = array_ptr, *base = array_ptr;
 int cmp = -1;

 for (lim = array_len; lim != 0; lim >>= 1) {
  part = base + (lim >> 1) * item_size;
  cmp = (*compare)(key, part);

  if (cmp == 0) {
   base = part;
   break;
  }
  if (cmp > 0) {
   base = part + 1 * item_size;
   lim--;
  }
 }

 if (out)
  *out = (base - array) / item_size;

 return (cmp == 0) ? 0 : GIT_ENOTFOUND;
}
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/cache.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/cache.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/hashmap_oid.h" 1
# 10 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/hashmap_oid.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap.h" 1
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 1 3
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap.h" 2
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap.h"
typedef uint32_t git_hashmap_iter_t;
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/hashmap_oid.h" 2

static __inline__ uint32_t git_hashmap_oid_hashcode(const git_oid *oid)
{
 uint32_t hash;
 memcpy(&hash, oid->id, sizeof(uint32_t));
 return hash;
}
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/cache.h" 2

enum {
 GIT_CACHE_STORE_ANY = 0,
 GIT_CACHE_STORE_RAW = 1,
 GIT_CACHE_STORE_PARSED = 2
};

typedef struct {
 git_oid oid;
 int16_t type;
 uint16_t flags;
 size_t size;
 git_atomic32 refcount;
} git_cached_obj;

typedef struct { uint32_t n_buckets, size, n_occupied, upper_bound; uint32_t *flags; const git_oid * *keys; git_cached_obj * *vals; } git_cache_oidmap;;

typedef struct {
 git_cache_oidmap map;
 pthread_rwlock_t lock;
 ssize_t used_memory;
} git_cache;

extern _Bool git_cache__enabled;
extern ssize_t git_cache__max_storage;
extern git_atomic_ssize git_cache__current_storage;

int git_cache_set_max_object_size(git_object_t type, size_t size);

int git_cache_init(git_cache *cache);
void git_cache_dispose(git_cache *cache);
void git_cache_clear(git_cache *cache);
size_t git_cache_size(git_cache *cache);

void *git_cache_store_raw(git_cache *cache, git_odb_object *entry);
void *git_cache_store_parsed(git_cache *cache, git_object *entry);

git_odb_object *git_cache_get_raw(git_cache *cache, const git_oid *oid);
git_object *git_cache_get_parsed(git_cache *cache, const git_oid *oid);
void *git_cache_get_any(git_cache *cache, const git_oid *oid);

static __inline__ void git_cached_obj_incref(void *_obj)
{
 git_cached_obj *obj = _obj;
 git_atomic32_inc(&obj->refcount);
}

void git_cached_obj_decref(void *_obj);
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refdb.h" 1
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refdb.h"
extern __attribute__((visibility("default"))) int git_refdb_new(git_refdb **out, git_repository *repo);
# 49 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refdb.h"
extern __attribute__((visibility("default"))) int git_refdb_open(git_refdb **out, git_repository *repo);
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/refdb.h"
extern __attribute__((visibility("default"))) int git_refdb_compress(git_refdb *refdb);






extern __attribute__((visibility("default"))) void git_refdb_free(git_refdb *refdb);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2/experimental.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h"
typedef struct git_hash_sha1_ctx git_hash_sha1_ctx;
typedef struct git_hash_sha256_ctx git_hash_sha256_ctx;
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/collisiondetect.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/collisiondetect.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/collisiondetect.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha1dc/sha1.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha1dc/sha1.h"
void sha1_compression_states(uint32_t[5], const uint32_t[16], uint32_t[80], uint32_t[80][5]);
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha1dc/sha1.h"
typedef void(*sha1_recompression_type)(uint32_t*, uint32_t*, const uint32_t*, const uint32_t*);



typedef void(*collision_block_callback)(uint64_t, const uint32_t*, const uint32_t*, const uint32_t*, const uint32_t*);


typedef struct {
 uint64_t total;
 uint32_t ihv[5];
 unsigned char buffer[64];
 int found_collision;
 int safe_hash;
 int detect_coll;
 int ubc_check;
 int reduced_round_coll;
 collision_block_callback callback;

 uint32_t ihv1[5];
 uint32_t ihv2[5];
 uint32_t m1[80];
 uint32_t m2[80];
 uint32_t states[80][5];
} SHA1_CTX;


void SHA1DCInit(SHA1_CTX*);
# 73 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha1dc/sha1.h"
void SHA1DCSetSafeHash(SHA1_CTX*, int);





void SHA1DCSetUseUBC(SHA1_CTX*, int);





void SHA1DCSetUseDetectColl(SHA1_CTX*, int);



void SHA1DCSetDetectReducedRoundCollision(SHA1_CTX*, int);



void SHA1DCSetCallback(SHA1_CTX*, collision_block_callback);


void SHA1DCUpdate(SHA1_CTX*, const char*, size_t);



int SHA1DCFinal(unsigned char[20], SHA1_CTX*);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/collisiondetect.h" 2

struct git_hash_sha1_ctx {
 SHA1_CTX c;
};
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/builtin.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/builtin.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/builtin.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/rfc6234/sha.h" 1
# 91 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/rfc6234/sha.h"
enum {
    shaSuccess = 0,
    shaNull,
    shaInputTooLong,
    shaStateError,
    shaBadParam
};






enum {
    SHA1_Message_Block_Size = 64, SHA224_Message_Block_Size = 64,
    SHA256_Message_Block_Size = 64, SHA384_Message_Block_Size = 128,
    SHA512_Message_Block_Size = 128,
    USHA_Max_Message_Block_Size = SHA512_Message_Block_Size,
    SHA1HashSize = 20, SHA224HashSize = 28, SHA256HashSize = 32,
    SHA384HashSize = 48, SHA512HashSize = 64,
    USHAMaxHashSize = SHA512HashSize,

    SHA1HashSizeBits = 160, SHA224HashSizeBits = 224,
    SHA256HashSizeBits = 256, SHA384HashSizeBits = 384,
    SHA512HashSizeBits = 512, USHAMaxHashSizeBits = SHA512HashSizeBits
};




typedef enum SHAversion {
    SHA1, SHA224, SHA256, SHA384, SHA512
} SHAversion;





typedef struct SHA1Context {
    uint32_t Intermediate_Hash[SHA1HashSize/4];

    uint32_t Length_High;
    uint32_t Length_Low;

    int_least16_t Message_Block_Index;

    uint8_t Message_Block[SHA1_Message_Block_Size];

    int Computed;
    int Corrupted;
} SHA1Context;





typedef struct SHA256Context {
    uint32_t Intermediate_Hash[SHA256HashSize/4];

    uint32_t Length_High;
    uint32_t Length_Low;

    int_least16_t Message_Block_Index;

    uint8_t Message_Block[SHA256_Message_Block_Size];

    int Computed;
    int Corrupted;
} SHA256Context;





typedef struct SHA512Context {




    uint64_t Intermediate_Hash[SHA512HashSize/8];
    uint64_t Length_High, Length_Low;


    int_least16_t Message_Block_Index;

    uint8_t Message_Block[SHA512_Message_Block_Size];

    int Computed;
    int Corrupted;
} SHA512Context;





typedef struct SHA256Context SHA224Context;





typedef struct SHA512Context SHA384Context;






extern int SHA1Reset(SHA1Context *);
extern int SHA1Input(SHA1Context *, const uint8_t *bytes,
                     unsigned int bytecount);
extern int SHA1FinalBits(SHA1Context *, uint8_t bits,
                         unsigned int bit_count);
extern int SHA1Result(SHA1Context *,
                      uint8_t Message_Digest[SHA1HashSize]);


extern int SHA224Reset(SHA224Context *);
extern int SHA224Input(SHA224Context *, const uint8_t *bytes,
                       unsigned int bytecount);
extern int SHA224FinalBits(SHA224Context *, uint8_t bits,
                           unsigned int bit_count);
extern int SHA224Result(SHA224Context *,
                        uint8_t Message_Digest[SHA224HashSize]);


extern int SHA256Reset(SHA256Context *);
extern int SHA256Input(SHA256Context *, const uint8_t *bytes,
                       unsigned int bytecount);
extern int SHA256FinalBits(SHA256Context *, uint8_t bits,
                           unsigned int bit_count);
extern int SHA256Result(SHA256Context *,
                        uint8_t Message_Digest[SHA256HashSize]);


extern int SHA384Reset(SHA384Context *);
extern int SHA384Input(SHA384Context *, const uint8_t *bytes,
                       unsigned int bytecount);
extern int SHA384FinalBits(SHA384Context *, uint8_t bits,
                           unsigned int bit_count);
extern int SHA384Result(SHA384Context *,
                        uint8_t Message_Digest[SHA384HashSize]);


extern int SHA512Reset(SHA512Context *);
extern int SHA512Input(SHA512Context *, const uint8_t *bytes,
                       unsigned int bytecount);
extern int SHA512FinalBits(SHA512Context *, uint8_t bits,
                           unsigned int bit_count);
extern int SHA512Result(SHA512Context *,
                        uint8_t Message_Digest[SHA512HashSize]);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/builtin.h" 2

struct git_hash_sha256_ctx {
 SHA256Context c;
};
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash/sha.h" 2








int git_hash_sha1_global_init(void);

int git_hash_sha1_ctx_init(git_hash_sha1_ctx *ctx);
void git_hash_sha1_ctx_cleanup(git_hash_sha1_ctx *ctx);

int git_hash_sha1_init(git_hash_sha1_ctx *c);
int git_hash_sha1_update(git_hash_sha1_ctx *c, const void *data, size_t len);
int git_hash_sha1_final(unsigned char *out, git_hash_sha1_ctx *c);







int git_hash_sha256_global_init(void);

int git_hash_sha256_ctx_init(git_hash_sha256_ctx *ctx);
void git_hash_sha256_ctx_cleanup(git_hash_sha256_ctx *ctx);

int git_hash_sha256_init(git_hash_sha256_ctx *c);
int git_hash_sha256_update(git_hash_sha256_ctx *c, const void *data, size_t len);
int git_hash_sha256_final(unsigned char *out, git_hash_sha256_ctx *c);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hash.h" 2

typedef struct {
 void *data;
 size_t len;
} git_str_vec;

typedef enum {
 GIT_HASH_ALGORITHM_NONE = 0,
 GIT_HASH_ALGORITHM_SHA1,
 GIT_HASH_ALGORITHM_SHA256
} git_hash_algorithm_t;



typedef struct git_hash_ctx {
 union {
  git_hash_sha1_ctx sha1;
  git_hash_sha256_ctx sha256;
 } ctx;
 git_hash_algorithm_t algorithm;
} git_hash_ctx;

int git_hash_global_init(void);

int git_hash_ctx_init(git_hash_ctx *ctx, git_hash_algorithm_t algorithm);
void git_hash_ctx_cleanup(git_hash_ctx *ctx);

int git_hash_init(git_hash_ctx *c);
int git_hash_update(git_hash_ctx *c, const void *data, size_t len);
int git_hash_final(unsigned char *out, git_hash_ctx *c);

int git_hash_buf(unsigned char *out, const void *data, size_t len, git_hash_algorithm_t algorithm);
int git_hash_vec(unsigned char *out, git_str_vec *vec, size_t n, git_hash_algorithm_t algorithm);

int git_hash_fmt(char *out, unsigned char *hash, size_t hash_len);

static __inline__ size_t git_hash_size(git_hash_algorithm_t algorithm) {
 switch (algorithm) {
  case GIT_HASH_ALGORITHM_SHA1:
   return 20;
  case GIT_HASH_ALGORITHM_SHA256:
   return 32;
  default:
   return 0;
 }
}
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h" 2
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h"
extern const git_oid git_oid__empty_blob_sha1;
extern const git_oid git_oid__empty_tree_sha1;

static __inline__ git_oid_t git_oid_type(const git_oid *oid)
{



 do { __typeof__(oid) _unused __attribute__((unused)); _unused = (oid); } while (0);
 return GIT_OID_SHA1;

}

static __inline__ size_t git_oid_size(git_oid_t type)
{
 switch (type) {
 case GIT_OID_SHA1:
  return 20;






 }

 return 0;
}

static __inline__ size_t git_oid_hexsize(git_oid_t type)
{
 switch (type) {
 case GIT_OID_SHA1:
  return (20 * 2);






 }

 return 0;
}

static __inline__ _Bool git_oid_type_is_valid(git_oid_t type)
{
 return (type == GIT_OID_SHA1



 );
}

static __inline__ const char * git_oid_type_name(git_oid_t type)
{
 switch (type) {
 case GIT_OID_SHA1:
  return "sha1";





 }

 return "unknown";
}

static __inline__ git_oid_t git_oid_type_fromstr(const char *name)
{
 if (strcmp(name, "sha1") == 0)
  return GIT_OID_SHA1;






 return 0;
}

static __inline__ git_oid_t git_oid_type_fromstrn(const char *name, size_t len)
{
 if (len == ((sizeof("sha1")/sizeof("sha1"[0])) - 1) && strncmp(name, "sha1", len) == 0)
  return GIT_OID_SHA1;






 return 0;
}

static __inline__ git_hash_algorithm_t git_oid_algorithm(git_oid_t type)
{
 switch (type) {
 case GIT_OID_SHA1:
  return GIT_HASH_ALGORITHM_SHA1;






 }

 return 0;
}
# 144 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h"
char *git_oid_allocfmt(const git_oid *id);
# 154 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h"
static __inline__ void git_oid_fmt_substr(
 char *str,
 const git_oid *oid,
 size_t start,
 size_t count)
{
 static char hex[] = "0123456789abcdef";
 size_t i, end = start + count, min = start / 2, max = end / 2;

 if (start & 1)
  *str++ = hex[oid->id[min++] & 0x0f];

 for (i = min; i < max; i++) {
  *str++ = hex[oid->id[i] >> 4];
  *str++ = hex[oid->id[i] & 0x0f];
 }

 if (end & 1)
  *str++ = hex[oid->id[i] >> 4];
}

static __inline__ int git_oid_raw_ncmp(
 const unsigned char *sha1,
 const unsigned char *sha2,
 size_t len)
{
 if (len > (20 * 2))
  len = (20 * 2);

 while (len > 1) {
  if (*sha1 != *sha2)
   return 1;
  sha1++;
  sha2++;
  len -= 2;
 };

 if (len)
  if ((*sha1 ^ *sha2) & 0xf0)
   return 1;

 return 0;
}

static __inline__ int git_oid_raw_cmp(
 const unsigned char *sha1,
 const unsigned char *sha2,
 size_t size)
{
 return memcmp(sha1, sha2, size);
}

static __inline__ int git_oid_raw_cpy(
 unsigned char *dst,
 const unsigned char *src,
 size_t size)
{
 memcpy(dst, src, size);
 return 0;
}
# 222 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oid.h"
static __inline__ int git_oid__cmp(const git_oid *a, const git_oid *b)
{






 return git_oid_raw_cmp(a->id, b->id, git_oid_size(GIT_OID_SHA1));

}

static __inline__ void git_oid__cpy_prefix(
 git_oid *out, const git_oid *id, size_t len)
{




 memcpy(&out->id, id->id, (len + 1) / 2);

 if (len & 1)
  out->id[len / 2] &= 0xF0;
}

static __inline__ _Bool git_oid__is_hexstr(const char *str, git_oid_t type)
{
 size_t i;

 for (i = 0; str[i] != '\0'; i++) {
  if (git__fromhex(str[i]) < 0)
   return 0;
 }

 return (i == git_oid_hexsize(type));
}

static __inline__ void git_oid_clear(git_oid *out, git_oid_t type)
{
 memset(out->id, 0, git_oid_size(type));




}



int git_oid__fromstr(git_oid *out, const char *str, git_oid_t type);

int git_oid__fromstrp(git_oid *out, const char *str, git_oid_t type);

int git_oid__fromstrn(
 git_oid *out,
 const char *str,
 size_t length,
 git_oid_t type);

int git_oid__fromraw(git_oid *out, const unsigned char *raw, git_oid_t type);

int git_oid_global_init(void);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h" 2

extern _Bool git_reference__enable_symbolic_ref_target_validation;
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h"
typedef char git_refname_t[1024];

struct git_reference {
 git_refdb *db;
 git_reference_t type;

 union {
  git_oid oid;
  char *symbolic;
 } target;

 git_oid peel;
 char name[];
};
# 83 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h"
git_reference *git_reference__realloc(git_reference **ptr_to_ref, const char *name);

int git_reference__normalize_name(git_str *buf, const char *name, unsigned int flags);
int git_reference__update_terminal(git_repository *repo, const char *ref_name, const git_oid *oid, const git_signature *sig, const char *log_message);
int git_reference__name_is_valid(int *valid, const char *name, unsigned int flags);
int git_reference__is_branch(const char *ref_name);
int git_reference__is_remote(const char *ref_name);
int git_reference__is_tag(const char *ref_name);
int git_reference__is_note(const char *ref_name);
const char *git_reference__shorthand(const char *name);





int git_reference__cmp_cb(const void *a, const void *b);
# 117 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refs.h"
int git_reference_lookup_resolved(
 git_reference **reference_out,
 git_repository *repo,
 const char *name,
 int max_deref);

int git_reference__log_signature(git_signature **out, git_repository *repo);


int git_reference__update_for_commit(
 git_repository *repo,
 git_reference *ref,
 const char *ref_name,
 const git_oid *id,
 const char *operation);

int git_reference__is_unborn_head(_Bool *unborn, const git_reference *ref, git_repository *repo);
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/object.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/object.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/object.h" 2



extern _Bool git_object__strict_input_validation;


struct git_object {
 git_cached_obj cached;
 git_repository *repo;
};


void git_object__free(void *object);






int git_object__from_raw(
 git_object **object_out,
 const char *data,
 size_t size,
 git_object_t object_type,
 git_oid_t oid_type);

int git_object__init_from_odb_object(
 git_object **object_out,
 git_repository *repo,
 git_odb_object *odb_obj,
 git_object_t type);

int git_object__from_odb_object(
 git_object **object_out,
 git_repository *repo,
 git_odb_object *odb_obj,
 git_object_t type);

int git_object__resolve_to_type(git_object **obj, git_object_t type);

git_object_t git_object_stringn2type(const char *str, size_t len);

int git_object__parse_oid_header(
 git_oid *oid,
 const char **buffer_out,
 const char *buffer_end,
 const char *header,
 git_oid_t oid_type);

int git_object__write_oid_header(
 git_str *buf,
 const char *header,
 const git_oid *oid);

_Bool git_object__is_valid(
 git_repository *repo, const git_oid *id, git_object_t expected_type);

static __inline__ git_object_t git_object__type_from_filemode(git_filemode_t mode)
{
 switch (mode) {
 case GIT_FILEMODE_TREE:
  return GIT_OBJECT_TREE;
 case GIT_FILEMODE_COMMIT:
  return GIT_OBJECT_COMMIT;
 case GIT_FILEMODE_BLOB:
 case GIT_FILEMODE_BLOB_EXECUTABLE:
 case GIT_FILEMODE_LINK:
  return GIT_OBJECT_BLOB;
 default:
  return GIT_OBJECT_INVALID;
 }
}
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attrcache.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attrcache.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attr_file.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attr_file.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/vector.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/vector.h"
typedef int (*git_vector_cmp)(const void *, const void *);

enum {
 GIT_VECTOR_SORTED = (1u << 0),
 GIT_VECTOR_FLAG_MAX = (1u << 1)
};

typedef struct git_vector {
 size_t _alloc_size;
 git_vector_cmp _cmp;
 void **contents;
 size_t length;
 uint32_t flags;
} git_vector;



__attribute__((warn_unused_result)) int git_vector_init(
 git_vector *v, size_t initial_size, git_vector_cmp cmp);
void git_vector_dispose(git_vector *v);
void git_vector_dispose_deep(git_vector *v);
void git_vector_clear(git_vector *v);
__attribute__((warn_unused_result)) int git_vector_dup(
 git_vector *v, const git_vector *src, git_vector_cmp cmp);
void git_vector_swap(git_vector *a, git_vector *b);
int git_vector_size_hint(git_vector *v, size_t size_hint);

void **git_vector_detach(size_t *size, size_t *asize, git_vector *v);

void git_vector_sort(git_vector *v);


int git_vector_search(size_t *at_pos, const git_vector *v, const void *entry);


int git_vector_search2(size_t *at_pos, const git_vector *v, git_vector_cmp cmp, const void *key);





int git_vector_bsearch2(
 size_t *at_pos, git_vector *v, git_vector_cmp cmp, const void *key);


static __inline__ int git_vector_bsearch(size_t *at_pos, git_vector *v, const void *key)
{
 return git_vector_bsearch2(at_pos, v, v->_cmp, key);
}

static __inline__ void * git_vector_get(const git_vector *v, size_t position)
{
 return (position < v->length) ? v->contents[position] : ((void*)0);
}



static __inline__ size_t git_vector_length(const git_vector *v)
{
 return v->length;
}

static __inline__ void * git_vector_last(const git_vector *v)
{
 return (v->length > 0) ? git_vector_get(v, v->length - 1) : ((void*)0);
}







int git_vector_insert(git_vector *v, void *element);
int git_vector_insert_sorted(git_vector *v, void *element,
 int (*on_dup)(void **old, void *new));
int git_vector_remove(git_vector *v, size_t idx);
void git_vector_pop(git_vector *v);
void git_vector_uniq(git_vector *v, void (*git_free_cb)(void *));

void git_vector_remove_matching(
 git_vector *v,
 int (*match)(const git_vector *v, size_t idx, void *payload),
 void *payload);

int git_vector_resize_to(git_vector *v, size_t new_length);
int git_vector_insert_null(git_vector *v, size_t idx, size_t insert_len);
int git_vector_remove_range(git_vector *v, size_t idx, size_t remove_len);

int git_vector_set(void **old, git_vector *v, size_t position, void *value);
# 112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/vector.h"
static __inline__ void git_vector_set_cmp(git_vector *v, git_vector_cmp cmp)
{
 if (cmp != v->_cmp) {
  v->_cmp = cmp;
  do { (v)->flags = (0) ? ((v)->flags | GIT_VECTOR_SORTED) : ((v)->flags & ~GIT_VECTOR_SORTED); } while (0);
 }
}


int git_vector_verify_sorted(const git_vector *v);




void git_vector_reverse(git_vector *v);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attr_file.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/pool.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/pool.h"
typedef struct git_pool_page git_pool_page;
# 33 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/pool.h"
typedef struct {
 git_pool_page *pages;
 size_t item_size;
 size_t page_size;
} git_pool;
# 84 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/pool.h"
extern int git_pool_init(git_pool *pool, size_t item_size);

static __inline__ _Bool git_pool_is_initialized(git_pool *pool)
{
 return (pool->item_size > 0);
}




extern void git_pool_clear(git_pool *pool);




extern void git_pool_swap(git_pool *a, git_pool *b);




extern void *git_pool_malloc(git_pool *pool, size_t items);
extern void *git_pool_mallocz(git_pool *pool, size_t items);






extern char *git_pool_strndup(git_pool *pool, const char *str, size_t n);






extern char *git_pool_strdup(git_pool *pool, const char *str);






extern char *git_pool_strdup_safe(git_pool *pool, const char *str);






extern char *git_pool_strcat(git_pool *pool, const char *a, const char *b);





extern uint32_t git_pool__open_pages(git_pool *pool);

extern _Bool git_pool__ptr_in_pool(git_pool *pool, void *ptr);







extern int git_pool_global_init(void);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attr_file.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/map.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/map.h"
typedef struct {
 void *data;
 size_t len;



} git_map;






extern int p_mmap(git_map *out, size_t len, int prot, int flags, int fd, off64_t offset);
extern int p_munmap(git_map *map);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/utf8.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/utf8.h"
extern int git_utf8_iterate(uint32_t *out, const char *str, size_t str_len);
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/utf8.h"
extern size_t git_utf8_char_length(const char *str, size_t str_len);
# 50 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/utf8.h"
extern size_t git_utf8_valid_buf_length(const char *str, size_t str_len);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h" 2
# 42 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern char *git_fs_path_dirname(const char *path);
extern int git_fs_path_dirname_r(git_str *buffer, const char *path);
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern char *git_fs_path_basename(const char *path);
extern int git_fs_path_basename_r(git_str *buffer, const char *path);




extern size_t git_fs_path_basename_offset(git_str *buffer);
# 77 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_root(const char *path);




extern int git_fs_path_to_dir(git_str *path);




extern void git_fs_path_string_to_dir(char *path, size_t size);





size_t git_fs_path_dirlen(const char *path);





static __inline__ int git_fs_path_is_root(const char *name)
{
# 109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
 return (name[0] == '/' && name[1] == '\0');
}




static __inline__ int git_fs_path_is_dot_or_dotdot(const char *name)
{
 return (name[0] == '.' &&
     (name[1] == '\0' ||
    (name[1] == '.' && name[2] == '\0')));
}
# 162 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
static __inline__ int git_fs_path_is_relative(const char *p)
{
 return (p[0] == '.' && (p[1] == '/' || (p[1] == '.' && p[2] == '/')));
}




static __inline__ int git_fs_path_at_end_of_segment(const char *p)
{
 return !*p || *p == '/';
}

extern int git__percent_decode(git_str *decoded_out, const char *input);




extern int git_fs_path_fromurl(git_str *local_path_out, const char *file_url);
# 193 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern _Bool git_fs_path_exists(const char *path);





extern _Bool git_fs_path_isdir(const char *path);





extern _Bool git_fs_path_isfile(const char *path);





extern _Bool git_fs_path_islink(const char *path);




extern _Bool git_fs_path_is_empty_dir(const char *path);




extern int git_fs_path_lstat(const char *path, struct stat *st);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern _Bool git_fs_path_contains(git_str *dir, const char *item);
# 239 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern _Bool git_fs_path_contains_dir(git_str *parent, const char *subdir);
# 251 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern size_t git_fs_path_common_dirlen(const char *one, const char *two);
# 262 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_make_relative(git_str *path, const char *parent);
# 271 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern _Bool git_fs_path_contains_file(git_str *dir, const char *file);







extern int git_fs_path_join_unrooted(
 git_str *path_out, const char *path, const char *base, ssize_t *root_at);





extern void git_fs_path_squash_slashes(git_str *path);




extern int git_fs_path_prettify(git_str *path_out, const char *path, const char *base);





extern int git_fs_path_prettify_dir(git_str *path_out, const char *path, const char *base);
# 308 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_find_dir(git_str *dir);
# 320 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_resolve_relative(git_str *path, size_t ceiling);
# 331 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_apply_relative(git_str *target, const char *relpath);

enum {
 GIT_FS_PATH_DIR_IGNORE_CASE = (1u << 0),
 GIT_FS_PATH_DIR_PRECOMPOSE_UNICODE = (1u << 1),
 GIT_FS_PATH_DIR_INCLUDE_DOT_AND_DOTDOT = (1u << 2),
};
# 352 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_direach(
 git_str *pathbuf,
 uint32_t flags,
 int (*callback)(void *payload, git_str *path),
 void *payload);




extern int git_fs_path_cmp(
 const char *name1, size_t len1, int isdir1,
 const char *name2, size_t len2, int isdir2,
 int (*compare)(const char *, const char *, size_t));
# 384 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_walk_up(
 git_str *pathbuf,
 const char *ceiling,
 int (*callback)(void *payload, const char *path),
 void *payload);


enum {
 GIT_FS_PATH_NOTEQUAL = 0,
 GIT_FS_PATH_EQUAL = 1,
 GIT_FS_PATH_PREFIX = 2
};






static __inline__ int git_fs_path_equal_or_prefixed(
 const char *parent,
 const char *child,
 ssize_t *prefixlen)
{
 const char *p = parent, *c = child;
 int lastslash = 0;

 while (*p && *c) {
  lastslash = (*p == '/');

  if (*p++ != *c++)
   return GIT_FS_PATH_NOTEQUAL;
 }

 if (*p != '\0')
  return GIT_FS_PATH_NOTEQUAL;

 if (*c == '\0') {
  if (prefixlen)
   *prefixlen = p - parent;

  return GIT_FS_PATH_EQUAL;
 }

 if (*c == '/' || lastslash) {
  if (prefixlen)
   *prefixlen = (p - parent) - lastslash;

  return GIT_FS_PATH_PREFIX;
 }

 return GIT_FS_PATH_NOTEQUAL;
}


extern int git_fs_path_set_error(
 int errno_value, const char *path, const char *action);


extern _Bool git_fs_path_has_non_ascii(const char *path, size_t pathlen);
# 478 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern _Bool git_fs_path_does_decompose_unicode(const char *root);


typedef struct git_fs_path_diriter git_fs_path_diriter;
# 505 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
struct git_fs_path_diriter
{
 git_str path;
 size_t parent_len;

 unsigned int flags;

 DIR *dir;




};
# 531 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_diriter_init(
 git_fs_path_diriter *diriter,
 const char *path,
 unsigned int flags);
# 543 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_diriter_next(git_fs_path_diriter *diriter);
# 553 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_diriter_filename(
 const char **out,
 size_t *out_len,
 git_fs_path_diriter *diriter);
# 568 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_diriter_fullpath(
 const char **out,
 size_t *out_len,
 git_fs_path_diriter *diriter);
# 580 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_diriter_stat(struct stat *out, git_fs_path_diriter *diriter);






extern void git_fs_path_diriter_free(git_fs_path_diriter *diriter);
# 604 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern int git_fs_path_dirload(
 git_vector *contents,
 const char *path,
 size_t prefix_len,
 uint32_t flags);



extern _Bool git_fs_path_is_local_file_url(const char *file_url);
extern int git_fs_path_from_url_or_path(git_str *local_path_out, const char *url_or_path);
# 653 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
extern _Bool git_fs_path_str_is_valid_ext(
 const git_str *path,
 unsigned int flags,
 _Bool (*validate_char_cb)(char ch, void *payload),
 _Bool (*validate_component_cb)(const char *component, size_t len, void *payload),
 _Bool (*validate_length_cb)(const char *component, size_t len, size_t utf8_char_len),
 void *payload);

static __inline__ _Bool git_fs_path_is_valid_ext(
 const char *path,
 unsigned int flags,
 _Bool (*validate_char_cb)(char ch, void *payload),
 _Bool (*validate_component_cb)(const char *component, size_t len, void *payload),
 _Bool (*validate_length_cb)(const char *component, size_t len, size_t utf8_char_len),
 void *payload)
{
 const git_str str = { (char *)(path), 0, (size_t)((18446744073709551615UL)) };
 return git_fs_path_str_is_valid_ext(
  &str,
  flags,
  validate_char_cb,
  validate_component_cb,
  validate_length_cb,
  payload);
}
# 686 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
static __inline__ _Bool git_fs_path_is_valid(
 const char *path,
 unsigned int flags)
{
 const git_str str = { (char *)(path), 0, (size_t)((18446744073709551615UL)) };
 return git_fs_path_str_is_valid_ext(&str, flags, ((void*)0), ((void*)0), ((void*)0), ((void*)0));
}


static __inline__ _Bool git_fs_path_str_is_valid(
 const git_str *path,
 unsigned int flags)
{
 return git_fs_path_str_is_valid_ext(path, flags, ((void*)0), ((void*)0), ((void*)0), ((void*)0));
}

extern int git_fs_path_validate_str_length_with_suffix(
 git_str *path,
 size_t suffix_len);





static __inline__ int git_fs_path_validate_filesystem_with_suffix(
 const char *path,
 size_t path_len,
 size_t suffix_len)
{
# 727 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
 do { __typeof__(path) _unused __attribute__((unused)); _unused = (path); } while (0);
 do { __typeof__(path_len) _unused __attribute__((unused)); _unused = (path_len); } while (0);
 do { __typeof__(suffix_len) _unused __attribute__((unused)); _unused = (suffix_len); } while (0);
 return 0;

}
# 743 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/fs_path.h"
static __inline__ int git_fs_path_validate_filesystem(
 const char *path,
 size_t path_len)
{
 return git_fs_path_validate_filesystem_with_suffix(path, path_len, 0);
}




int git_fs_path_normalize_slashes(git_str *out, const char *path);

_Bool git_fs_path_supports_symlinks(const char *dir);

typedef enum {
 GIT_FS_PATH_OWNER_NONE = 0,


 GIT_FS_PATH_OWNER_CURRENT_USER = (1 << 0),


 GIT_FS_PATH_OWNER_ADMINISTRATOR = (1 << 1),






 GIT_FS_PATH_USER_IS_ADMINISTRATOR = (1 << 2),




 GIT_FS_PATH_OWNER_RUNNING_SUDO = (1 << 3),


 GIT_FS_PATH_OWNER_OTHER = (1 << 4)
} git_fs_path_owner_t;






void git_fs_path__set_owner(git_fs_path_owner_t owner);


int git_fs_path_owner_is(
 _Bool *out,
 const char *path,
 git_fs_path_owner_t owner_type);





int git_fs_path_owner_is_system(_Bool *out, const char *path);





int git_fs_path_owner_is_current_user(_Bool *out, const char *path);





int git_fs_path_find_executable(git_str *fullpath, const char *executable);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap_str.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap_str.h"
static __inline__ uint32_t git_hashmap_str_hash(const char *s)
{
 uint32_t h = (uint32_t)*s;

 if (h) {
  for (++s; *s; ++s)
   h = (h << 5) - h + (uint32_t)*s;
 }

 return h;
}

static __inline__ _Bool git_hashmap_str_equal(const char *one, const char *two)
{
 return strcmp(one, two) == 0;
}
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/hashmap_str.h"
typedef struct { uint32_t n_buckets, size, n_occupied, upper_bound; uint32_t *flags; const char * *keys; void * *vals; } git_hashset_str; __attribute__((unused)) static __inline__ uint32_t git_hashset_str_size(git_hashset_str *h) { return h->size; } static __inline__ int git_hashset_str__idx(uint32_t *out, git_hashset_str *h, const char * key) { if (h->n_buckets) { uint32_t k, i, last, mask, step = 0; do { if (!((h)->flags)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->flags"); return -1; } } while(0); mask = h->n_buckets - 1; k = git_hashmap_str_hash(key); i = k & mask; last = i; while (!((h->flags[i>>4]>>((i&0xfU)<<1))&2) && (((h->flags[i>>4]>>((i&0xfU)<<1))&1) || !git_hashmap_str_equal(h->keys[i], key))) { i = (i + (++step)) & mask; if (i == last) return GIT_ENOTFOUND; } if (((h->flags[i>>4]>>((i&0xfU)<<1))&3)) return GIT_ENOTFOUND; *out = i; return 0; } return GIT_ENOTFOUND; } __attribute__((unused)) static __inline__ _Bool git_hashset_str_contains(git_hashset_str *h, const char * key) { uint32_t idx; return git_hashset_str__idx(&idx, h, key) == 0; } static __inline__ int git_hashset_str__remove_at_idx(git_hashset_str *h, uint32_t idx) { if (idx < h->n_buckets && !((h->flags[idx>>4]>>((idx&0xfU)<<1))&3)) { (h->flags[idx>>4]|=1ul<<((idx&0xfU)<<1)); --h->size; return 0; } return GIT_ENOTFOUND; } __attribute__((unused)) static __inline__ int git_hashset_str_remove(git_hashset_str *h, const char * key) { uint32_t idx; int error; if ((error = git_hashset_str__idx(&idx, h, key)) == 0) error = git_hashset_str__remove_at_idx(h, idx); return error; } static __inline__ int git_hashset_str__resize(git_hashset_str *h, uint32_t new_n_buckets) { double git_hashmap__upper_bound = 0.77; uint32_t *new_flags = 0; uint32_t j = 1; { (--(new_n_buckets), (new_n_buckets)|=(new_n_buckets)>>1, (new_n_buckets)|=(new_n_buckets)>>2, (new_n_buckets)|=(new_n_buckets)>>4, (new_n_buckets)|=(new_n_buckets)>>8, (new_n_buckets)|=(new_n_buckets)>>16, ++(new_n_buckets)); if (new_n_buckets < 4) new_n_buckets = 4; if (h->size >= (uint32_t)(new_n_buckets * git_hashmap__upper_bound + 0.5)) { j = 0; } else { new_flags = git__reallocarray(((void*)0), ((new_n_buckets) < 16? 1 : (new_n_buckets)>>4), sizeof(uint32_t)); if (!new_flags) return -1; memset(new_flags, 0xaa, ((new_n_buckets) < 16? 1 : (new_n_buckets)>>4) * sizeof(uint32_t)); if (h->n_buckets < new_n_buckets) { const char * *new_keys = git__reallocarray(h->keys, new_n_buckets, sizeof(const char *)); if (!new_keys) { git__free(new_flags); return -1; } h->keys = new_keys; if (0) { void * *new_vals = git__reallocarray(h->vals, new_n_buckets, sizeof(void *)); if (!new_vals) { git__free(new_flags); return -1; } h->vals = new_vals; } } } } if (j) { for (j = 0; j != h->n_buckets; ++j) { if (((h->flags[j>>4]>>((j&0xfU)<<1))&3) == 0) { const char * key = h->keys[j]; void * val; uint32_t new_mask; new_mask = new_n_buckets - 1; if (0) val = h->vals[j]; (h->flags[j>>4]|=1ul<<((j&0xfU)<<1)); while (1) { uint32_t k, i, step = 0; k = git_hashmap_str_hash(key); i = k & new_mask; while (!((new_flags[i>>4]>>((i&0xfU)<<1))&2)) i = (i + (++step)) & new_mask; (new_flags[i>>4]&=~(2ul<<((i&0xfU)<<1))); if (i < h->n_buckets && ((h->flags[i>>4]>>((i&0xfU)<<1))&3) == 0) { { const char * tmp = h->keys[i]; h->keys[i] = key; key = tmp; } if (0) { void * tmp = h->vals[i]; h->vals[i] = val; val = tmp; } (h->flags[i>>4]|=1ul<<((i&0xfU)<<1)); } else { h->keys[i] = key; if (0) h->vals[i] = val; break; } } } } if (h->n_buckets > new_n_buckets) { h->keys = git__reallocarray(h->keys, new_n_buckets, sizeof(const char *)); if (0) h->vals = git__reallocarray(h->vals, new_n_buckets, sizeof(void *)); } git__free(h->flags); h->flags = new_flags; h->n_buckets = new_n_buckets; h->n_occupied = h->size; h->upper_bound = (uint32_t)(h->n_buckets * git_hashmap__upper_bound + 0.5); } return 0; } static __inline__ int git_hashset_str__put_idx(uint32_t *idx, _Bool *key_exists, git_hashset_str *h, const char * key) { uint32_t x; if (h->n_occupied >= h->upper_bound) { if (h->n_buckets > (h->size<<1)) { if (git_hashset_str__resize(h, h->n_buckets - 1) < 0) return -1; } else if (git_hashset_str__resize(h, h->n_buckets + 1) < 0) { return -1; } } do { if (!((h)->flags)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->flags"); return -1; } } while(0); do { if (!((h)->keys)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->keys"); return -1; } } while(0); { uint32_t k, i, site, last, mask = h->n_buckets - 1, step = 0; x = site = h->n_buckets; k = git_hashmap_str_hash(key); i = k & mask; if (((h->flags[i>>4]>>((i&0xfU)<<1))&2)) { x = i; } else { last = i; while (!((h->flags[i>>4]>>((i&0xfU)<<1))&2) && (((h->flags[i>>4]>>((i&0xfU)<<1))&1) || !git_hashmap_str_equal(h->keys[i], key))) { if (((h->flags[i>>4]>>((i&0xfU)<<1))&1)) site = i; i = (i + (++step)) & mask; if (i == last) { x = site; break; } } if (x == h->n_buckets) { if (((h->flags[i>>4]>>((i&0xfU)<<1))&2) && site != h->n_buckets) x = site; else x = i; } } } if (((h->flags[x>>4]>>((x&0xfU)<<1))&2)) { h->keys[x] = key; (h->flags[x>>4]&=~(3ul<<((x&0xfU)<<1))); ++h->size; ++h->n_occupied; *key_exists = 1; } else if (((h->flags[x>>4]>>((x&0xfU)<<1))&1)) { h->keys[x] = key; (h->flags[x>>4]&=~(3ul<<((x&0xfU)<<1))); ++h->size; *key_exists = 1; } else { *key_exists = 0; } *idx = x; return 0; } __attribute__((unused)) static __inline__ void git_hashset_str_clear(git_hashset_str *h) { if (h && h->flags) { memset(h->flags, 0xaa, ((h->n_buckets) < 16? 1 : (h->n_buckets)>>4) * sizeof(uint32_t)); h->size = h->n_occupied = 0; } } __attribute__((unused)) static __inline__ void git_hashset_str_dispose(git_hashset_str *h) { git__free(h->flags); git__free(h->keys); git__free(h->vals); memset(h, 0, sizeof(git_hashset_str)); } __attribute__((unused)) static __inline__ int git_hashset_str_add(git_hashset_str *h, const char * key) { uint32_t idx; _Bool key_exists; int error = git_hashset_str__put_idx(&idx, &key_exists, h, key); if (error) return error; if (!key_exists) { (h)->keys[idx] = key; } return 0; } __attribute__((unused)) static __inline__ int git_hashset_str_iterate(git_hashmap_iter_t *iter, const char * *key, git_hashset_str *h) { for (; *iter < h->n_buckets; (*iter)++) { if (((h->flags[*iter>>4]>>((*iter&0xfU)<<1))&3)) continue; *key = h->keys[*iter]; return 0; } return GIT_ITEROVER; } __attribute__((unused)) static __inline__ int git_hashset_str_foreach(git_hashset_str *h, int (*cb)(const char *)) { git_hashmap_iter_t iter = 0; const char * key; int ret; while ((ret = git_hashset_str_iterate(&iter, &key, h)) == 0) { if ((ret = cb(key)) != 0) return ret; } return ret == GIT_ITEROVER ? 0 : ret; };
typedef struct { uint32_t n_buckets, size, n_occupied, upper_bound; uint32_t *flags; const char * *keys; void * *vals; } git_hashmap_str; __attribute__((unused)) static __inline__ uint32_t git_hashmap_str_size(git_hashmap_str *h) { return h->size; } static __inline__ int git_hashmap_str__idx(uint32_t *out, git_hashmap_str *h, const char * key) { if (h->n_buckets) { uint32_t k, i, last, mask, step = 0; do { if (!((h)->flags)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->flags"); return -1; } } while(0); mask = h->n_buckets - 1; k = git_hashmap_str_hash(key); i = k & mask; last = i; while (!((h->flags[i>>4]>>((i&0xfU)<<1))&2) && (((h->flags[i>>4]>>((i&0xfU)<<1))&1) || !git_hashmap_str_equal(h->keys[i], key))) { i = (i + (++step)) & mask; if (i == last) return GIT_ENOTFOUND; } if (((h->flags[i>>4]>>((i&0xfU)<<1))&3)) return GIT_ENOTFOUND; *out = i; return 0; } return GIT_ENOTFOUND; } __attribute__((unused)) static __inline__ _Bool git_hashmap_str_contains(git_hashmap_str *h, const char * key) { uint32_t idx; return git_hashmap_str__idx(&idx, h, key) == 0; } static __inline__ int git_hashmap_str__remove_at_idx(git_hashmap_str *h, uint32_t idx) { if (idx < h->n_buckets && !((h->flags[idx>>4]>>((idx&0xfU)<<1))&3)) { (h->flags[idx>>4]|=1ul<<((idx&0xfU)<<1)); --h->size; return 0; } return GIT_ENOTFOUND; } __attribute__((unused)) static __inline__ int git_hashmap_str_remove(git_hashmap_str *h, const char * key) { uint32_t idx; int error; if ((error = git_hashmap_str__idx(&idx, h, key)) == 0) error = git_hashmap_str__remove_at_idx(h, idx); return error; } static __inline__ int git_hashmap_str__resize(git_hashmap_str *h, uint32_t new_n_buckets) { double git_hashmap__upper_bound = 0.77; uint32_t *new_flags = 0; uint32_t j = 1; { (--(new_n_buckets), (new_n_buckets)|=(new_n_buckets)>>1, (new_n_buckets)|=(new_n_buckets)>>2, (new_n_buckets)|=(new_n_buckets)>>4, (new_n_buckets)|=(new_n_buckets)>>8, (new_n_buckets)|=(new_n_buckets)>>16, ++(new_n_buckets)); if (new_n_buckets < 4) new_n_buckets = 4; if (h->size >= (uint32_t)(new_n_buckets * git_hashmap__upper_bound + 0.5)) { j = 0; } else { new_flags = git__reallocarray(((void*)0), ((new_n_buckets) < 16? 1 : (new_n_buckets)>>4), sizeof(uint32_t)); if (!new_flags) return -1; memset(new_flags, 0xaa, ((new_n_buckets) < 16? 1 : (new_n_buckets)>>4) * sizeof(uint32_t)); if (h->n_buckets < new_n_buckets) { const char * *new_keys = git__reallocarray(h->keys, new_n_buckets, sizeof(const char *)); if (!new_keys) { git__free(new_flags); return -1; } h->keys = new_keys; if (1) { void * *new_vals = git__reallocarray(h->vals, new_n_buckets, sizeof(void *)); if (!new_vals) { git__free(new_flags); return -1; } h->vals = new_vals; } } } } if (j) { for (j = 0; j != h->n_buckets; ++j) { if (((h->flags[j>>4]>>((j&0xfU)<<1))&3) == 0) { const char * key = h->keys[j]; void * val; uint32_t new_mask; new_mask = new_n_buckets - 1; if (1) val = h->vals[j]; (h->flags[j>>4]|=1ul<<((j&0xfU)<<1)); while (1) { uint32_t k, i, step = 0; k = git_hashmap_str_hash(key); i = k & new_mask; while (!((new_flags[i>>4]>>((i&0xfU)<<1))&2)) i = (i + (++step)) & new_mask; (new_flags[i>>4]&=~(2ul<<((i&0xfU)<<1))); if (i < h->n_buckets && ((h->flags[i>>4]>>((i&0xfU)<<1))&3) == 0) { { const char * tmp = h->keys[i]; h->keys[i] = key; key = tmp; } if (1) { void * tmp = h->vals[i]; h->vals[i] = val; val = tmp; } (h->flags[i>>4]|=1ul<<((i&0xfU)<<1)); } else { h->keys[i] = key; if (1) h->vals[i] = val; break; } } } } if (h->n_buckets > new_n_buckets) { h->keys = git__reallocarray(h->keys, new_n_buckets, sizeof(const char *)); if (1) h->vals = git__reallocarray(h->vals, new_n_buckets, sizeof(void *)); } git__free(h->flags); h->flags = new_flags; h->n_buckets = new_n_buckets; h->n_occupied = h->size; h->upper_bound = (uint32_t)(h->n_buckets * git_hashmap__upper_bound + 0.5); } return 0; } static __inline__ int git_hashmap_str__put_idx(uint32_t *idx, _Bool *key_exists, git_hashmap_str *h, const char * key) { uint32_t x; if (h->n_occupied >= h->upper_bound) { if (h->n_buckets > (h->size<<1)) { if (git_hashmap_str__resize(h, h->n_buckets - 1) < 0) return -1; } else if (git_hashmap_str__resize(h, h->n_buckets + 1) < 0) { return -1; } } do { if (!((h)->flags)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->flags"); return -1; } } while(0); do { if (!((h)->keys)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->keys"); return -1; } } while(0); { uint32_t k, i, site, last, mask = h->n_buckets - 1, step = 0; x = site = h->n_buckets; k = git_hashmap_str_hash(key); i = k & mask; if (((h->flags[i>>4]>>((i&0xfU)<<1))&2)) { x = i; } else { last = i; while (!((h->flags[i>>4]>>((i&0xfU)<<1))&2) && (((h->flags[i>>4]>>((i&0xfU)<<1))&1) || !git_hashmap_str_equal(h->keys[i], key))) { if (((h->flags[i>>4]>>((i&0xfU)<<1))&1)) site = i; i = (i + (++step)) & mask; if (i == last) { x = site; break; } } if (x == h->n_buckets) { if (((h->flags[i>>4]>>((i&0xfU)<<1))&2) && site != h->n_buckets) x = site; else x = i; } } } if (((h->flags[x>>4]>>((x&0xfU)<<1))&2)) { h->keys[x] = key; (h->flags[x>>4]&=~(3ul<<((x&0xfU)<<1))); ++h->size; ++h->n_occupied; *key_exists = 1; } else if (((h->flags[x>>4]>>((x&0xfU)<<1))&1)) { h->keys[x] = key; (h->flags[x>>4]&=~(3ul<<((x&0xfU)<<1))); ++h->size; *key_exists = 1; } else { *key_exists = 0; } *idx = x; return 0; } __attribute__((unused)) static __inline__ void git_hashmap_str_clear(git_hashmap_str *h) { if (h && h->flags) { memset(h->flags, 0xaa, ((h->n_buckets) < 16? 1 : (h->n_buckets)>>4) * sizeof(uint32_t)); h->size = h->n_occupied = 0; } } __attribute__((unused)) static __inline__ void git_hashmap_str_dispose(git_hashmap_str *h) { git__free(h->flags); git__free(h->keys); git__free(h->vals); memset(h, 0, sizeof(git_hashmap_str)); } __attribute__((unused)) static __inline__ int git_hashmap_str_get(void * *out, git_hashmap_str *h, const char * key) { uint32_t idx; int error; if ((error = git_hashmap_str__idx(&idx, h, key)) == 0) *out = (h)->vals[idx]; return error; } __attribute__((unused)) static __inline__ int git_hashmap_str_put(git_hashmap_str *h, const char * key, void * val) { uint32_t idx; _Bool key_exists; int error = git_hashmap_str__put_idx(&idx, &key_exists, h, key); if (error) return error; do { if (!((h)->vals)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "(h)->vals"); return -1; } } while(0); if (!key_exists) (h)->keys[idx] = key; (h)->vals[idx] = val; return 0; } __attribute__((unused)) static __inline__ int git_hashmap_str_iterate(git_hashmap_iter_t *iter, const char * *key, void * *val, git_hashmap_str *h) { for (; *iter < h->n_buckets; (*iter)++) { if (((h->flags[*iter>>4]>>((*iter&0xfU)<<1))&3)) continue; if (key) *key = h->keys[*iter]; if (val) *val = h->vals[*iter]; (*iter)++; return 0; } return GIT_ITEROVER; } __attribute__((unused)) static __inline__ int git_hashmap_str_foreach(git_hashmap_str *h, int (*cb)(const char *, void *)) { uint32_t idx = 0; const char * key; void * val; int ret; while ((ret = git_hashmap_str_iterate(&idx, &key, &val, h)) == 0) { if ((ret = cb(key, val)) != 0) return ret; } return ret == GIT_ITEROVER ? 0 : ret; };
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h" 2






extern int git_futils_readbuffer(git_str *obj, const char *path);
extern int git_futils_readbuffer_updated(
 git_str *obj,
 const char *path,
 unsigned char checksum[32],
 int *updated);
extern int git_futils_readbuffer_fd_full(git_str *obj, git_file fd);
extern int git_futils_readbuffer_fd(git_str *obj, git_file fd, size_t len);
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_writebuffer(
 const git_str *buf, const char *path, int open_flags, mode_t mode);
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_creat_withpath(const char *path, const mode_t dirmode, const mode_t mode);




extern int git_futils_creat_locked(const char *path, const mode_t mode);





extern int git_futils_creat_locked_withpath(const char *path, const mode_t dirmode, const mode_t mode);




extern int git_futils_mkdir_r(const char *path, const mode_t mode);
# 91 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
typedef enum {
 GIT_MKDIR_EXCL = 1,
 GIT_MKDIR_PATH = 2,
 GIT_MKDIR_CHMOD = 4,
 GIT_MKDIR_CHMOD_PATH = 8,
 GIT_MKDIR_SKIP_LAST = 16,
 GIT_MKDIR_SKIP_LAST2 = 32,
 GIT_MKDIR_VERIFY_DIR = 64,
 GIT_MKDIR_REMOVE_FILES = 128,
 GIT_MKDIR_REMOVE_SYMLINKS = 256
} git_futils_mkdir_flags;

struct git_futils_mkdir_perfdata
{
 size_t stat_calls;
 size_t mkdir_calls;
 size_t chmod_calls;
};

struct git_futils_mkdir_options
{
# 120 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
 git_pool *cache_pool;
 git_hashset_str *cache_pathset;

 struct git_futils_mkdir_perfdata perfdata;
};
# 140 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_mkdir_relative(const char *path, const char *base, mode_t mode, uint32_t flags, struct git_futils_mkdir_options *opts);





extern int git_futils_mkdir(const char *path, mode_t mode, uint32_t flags);





extern int git_futils_mkpath2file(const char *path, const mode_t mode);
# 166 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
typedef enum {
 GIT_RMDIR_EMPTY_HIERARCHY = 0,
 GIT_RMDIR_REMOVE_FILES = (1 << 0),
 GIT_RMDIR_SKIP_NONEMPTY = (1 << 1),
 GIT_RMDIR_EMPTY_PARENTS = (1 << 2),
 GIT_RMDIR_REMOVE_BLOCKERS = (1 << 3),
 GIT_RMDIR_SKIP_ROOT = (1 << 4)
} git_futils_rmdir_flags;
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_rmdir_r(const char *path, const char *base, uint32_t flags);
# 199 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_mktmp(git_str *path_out, const char *filename, mode_t mode);





extern int git_futils_mv_withpath(const char *from, const char *to, const mode_t dirmode);






extern int git_futils_cp(
 const char *from,
 const char *to,
 mode_t filemode);





extern int git_futils_touch(const char *path, time_t *when);
# 239 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
typedef enum {
 GIT_CPDIR_CREATE_EMPTY_DIRS = (1u << 0),
 GIT_CPDIR_COPY_SYMLINKS = (1u << 1),
 GIT_CPDIR_COPY_DOTFILES = (1u << 2),
 GIT_CPDIR_OVERWRITE = (1u << 3),
 GIT_CPDIR_CHMOD_DIRS = (1u << 4),
 GIT_CPDIR_SIMPLE_TO_MODE = (1u << 5),
 GIT_CPDIR_LINK_FILES = (1u << 6)
} git_futils_cpdir_flags;
# 261 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_cp_r(
 const char *from,
 const char *to,
 uint32_t flags,
 mode_t dirmode);




extern int git_futils_open_ro(const char *path);




extern int git_futils_truncate(const char *path, int mode);




extern int git_futils_filesize(uint64_t *out, git_file fd);
# 294 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern mode_t git_futils_canonical_mode(mode_t raw_mode);
# 312 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_mmap_ro(
 git_map *out,
 git_file fd,
 off64_t begin,
 size_t len);
# 328 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_mmap_ro_file(
 git_map *out,
 const char *path);





extern void git_futils_mmap_free(git_map *map);
# 345 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_fake_symlink(const char *target, const char *path);







typedef struct {
 struct timespec mtime;
 uint64_t size;
 unsigned int ino;
} git_futils_filestamp;
# 372 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_filestamp_check(
 git_futils_filestamp *stamp, const char *path);
# 385 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern void git_futils_filestamp_set(
 git_futils_filestamp *tgt, const git_futils_filestamp *src);




extern void git_futils_filestamp_set_from_stat(
 git_futils_filestamp *stamp, struct stat *st);
# 401 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_fsync_dir(const char *path);
# 410 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/futils.h"
extern int git_futils_fsync_parent(const char *path);
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attr_file.h" 2
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attr_file.h"
typedef enum {
 GIT_ATTR_FILE_SOURCE_MEMORY = 0,
 GIT_ATTR_FILE_SOURCE_FILE = 1,
 GIT_ATTR_FILE_SOURCE_INDEX = 2,
 GIT_ATTR_FILE_SOURCE_HEAD = 3,
 GIT_ATTR_FILE_SOURCE_COMMIT = 4,

 GIT_ATTR_FILE_NUM_SOURCES = 5
} git_attr_file_source_t;

typedef struct {

 git_attr_file_source_t type;





 const char *base;
 const char *filename;





 git_oid *commit_id;
} git_attr_file_source;

extern const char *git_attr__true;
extern const char *git_attr__false;
extern const char *git_attr__unset;

typedef struct {
 char *pattern;
 size_t length;
 char *containing_dir;
 size_t containing_dir_length;
 unsigned int flags;
} git_attr_fnmatch;

typedef struct {
 git_attr_fnmatch match;
 git_vector assigns;
} git_attr_rule;

typedef struct {
 git_refcount unused;
 const char *name;
 uint32_t name_hash;
} git_attr_name;

typedef struct {
 git_refcount rc;
 char *name;
 uint32_t name_hash;
 const char *value;
} git_attr_assignment;

typedef struct git_attr_file_entry git_attr_file_entry;

typedef struct {
 git_refcount rc;
 pthread_mutex_t lock;
 git_attr_file_entry *entry;
 git_attr_file_source source;
 git_vector rules;
 git_pool pool;
 unsigned int nonexistent:1;
 int session_key;
 union {
  git_oid oid;
  git_futils_filestamp stamp;
 } cache_data;
} git_attr_file;

struct git_attr_file_entry {
 git_attr_file *file[GIT_ATTR_FILE_NUM_SOURCES];
 const char *path;
 char fullpath[];
};

typedef struct {
 git_str full;
 char *path;
 char *basename;
 int is_dir;
} git_attr_path;





typedef struct {
 int key;
 unsigned int init_setup:1,
  init_sysdir:1;
 git_str sysdir;
 git_str tmp;
} git_attr_session;

extern int git_attr_session__init(git_attr_session *attr_session, git_repository *repo);
extern void git_attr_session__free(git_attr_session *session);

extern int git_attr_get_many_with_session(
 const char **values_out,
 git_repository *repo,
 git_attr_session *attr_session,
 git_attr_options *opts,
 const char *path,
 size_t num_attr,
 const char **names);

typedef int (*git_attr_file_parser)(
 git_repository *repo,
 git_attr_file *file,
 const char *data,
 _Bool allow_macros);





int git_attr_file__new(
 git_attr_file **out,
 git_attr_file_entry *entry,
 git_attr_file_source *source);

void git_attr_file__free(git_attr_file *file);

int git_attr_file__load(
 git_attr_file **out,
 git_repository *repo,
 git_attr_session *attr_session,
 git_attr_file_entry *ce,
 git_attr_file_source *source,
 git_attr_file_parser parser,
 _Bool allow_macros);

int git_attr_file__load_standalone(
 git_attr_file **out, const char *path);

int git_attr_file__out_of_date(
 git_repository *repo, git_attr_session *session, git_attr_file *file, git_attr_file_source *source);

int git_attr_file__parse_buffer(
 git_repository *repo, git_attr_file *attrs, const char *data, _Bool allow_macros);

int git_attr_file__clear_rules(
 git_attr_file *file, _Bool need_lock);

int git_attr_file__lookup_one(
 git_attr_file *file,
 git_attr_path *path,
 const char *attr,
 const char **value);






uint32_t git_attr_file__name_hash(const char *name);






extern int git_attr_fnmatch__parse(
 git_attr_fnmatch *spec,
 git_pool *pool,
 const char *source,
 const char **base);

extern _Bool git_attr_fnmatch__match(
 git_attr_fnmatch *rule,
 git_attr_path *path);

extern void git_attr_rule__free(git_attr_rule *rule);

extern _Bool git_attr_rule__match(
 git_attr_rule *rule,
 git_attr_path *path);

extern git_attr_assignment *git_attr_rule__lookup_assignment(
 git_attr_rule *rule, const char *name);

typedef enum { GIT_DIR_FLAG_TRUE = 1, GIT_DIR_FLAG_FALSE = 0, GIT_DIR_FLAG_UNKNOWN = -1 } git_dir_flag;

extern int git_attr_path__init(
 git_attr_path *out,
 const char *path,
 const char *base,
 git_dir_flag is_dir);
extern void git_attr_path__free(git_attr_path *info);

extern int git_attr_assignment__parse(
 git_repository *repo,
 git_pool *pool,
 git_vector *assigns,
 const char **scan);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/attrcache.h" 2




typedef struct git_attr_cache git_attr_cache;

extern int git_attr_cache__init(git_repository *repo);

extern const char *git_attr_cache_attributesfile(git_attr_cache *ac);
extern const char *git_attr_cache_excludesfile(git_attr_cache *ac);
extern git_pool *git_attr_cache_pool(git_attr_cache *ac);


extern int git_attr_cache__get(
 git_attr_file **file,
 git_repository *repo,
 git_attr_session *attr_session,
 git_attr_file_source *source,
 git_attr_file_parser parser,
 _Bool allow_macros);

extern _Bool git_attr_cache__is_cached(
 git_repository *repo,
 git_attr_file_source_t source_type,
 const char *filename);

extern int git_attr_cache__alloc_file_entry(
 git_attr_file_entry **out,
 git_repository *repo,
 const char *base,
 const char *path,
 git_pool *pool);

extern int git_attr_cache__insert_macro(
 git_repository *repo, git_attr_rule *macro);

extern git_attr_rule *git_attr_cache__lookup_macro(
 git_repository *repo, const char *name);
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/submodule.h" 1
# 82 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/submodule.h"
struct git_submodule {
 git_refcount rc;


 char *name;
 char *path;
 char *url;
 char *branch;
 git_submodule_update_t update;
 git_submodule_update_t update_default;
 git_submodule_ignore_t ignore;
 git_submodule_ignore_t ignore_default;
 git_submodule_recurse_t fetch_recurse;
 git_submodule_recurse_t fetch_recurse_default;


 git_repository *repo;
 uint32_t flags;
 git_oid head_oid;
 git_oid index_oid;
 git_oid wd_oid;
};


enum {
 GIT_SUBMODULE_STATUS__WD_SCANNED = (1u << 20),
 GIT_SUBMODULE_STATUS__HEAD_OID_VALID = (1u << 21),
 GIT_SUBMODULE_STATUS__INDEX_OID_VALID = (1u << 22),
 GIT_SUBMODULE_STATUS__WD_OID_VALID = (1u << 23),
 GIT_SUBMODULE_STATUS__HEAD_NOT_SUBMODULE = (1u << 24),
 GIT_SUBMODULE_STATUS__INDEX_NOT_SUBMODULE = (1u << 25),
 GIT_SUBMODULE_STATUS__WD_NOT_SUBMODULE = (1u << 26),
 GIT_SUBMODULE_STATUS__INDEX_MULTIPLE_ENTRIES = (1u << 27)
};




typedef struct { uint32_t n_buckets, size, n_occupied, upper_bound; uint32_t *flags; const char * *keys; git_submodule * *vals; } git_submodule_cache;;


extern int git_submodule_cache_init(git_submodule_cache **out, git_repository *repo);


extern int git_submodule_cache_free(git_submodule_cache *cache);


extern int git_submodule__lookup_with_cache(
 git_submodule **out, git_repository *repo, const char *path, git_submodule_cache *cache);


extern int git_submodule__status(
 unsigned int *out_status,
 git_oid *out_head_id,
 git_oid *out_index_id,
 git_oid *out_wd_id,
 git_submodule *sm,
 git_submodule_ignore_t ign);


extern int git_submodule_open_bare(
 git_repository **repo,
 git_submodule *submodule);

extern int git_submodule_parse_ignore(
 git_submodule_ignore_t *out, const char *value);
extern int git_submodule_parse_update(
 git_submodule_update_t *out, const char *value);
# 161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/submodule.h"
extern int git_submodule_name_is_valid(git_repository *repo, const char *name, int flags);
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/diff_driver.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/diff_driver.h"
typedef struct git_diff_driver git_diff_driver;
typedef struct git_diff_driver_registry git_diff_driver_registry;

git_diff_driver_registry *git_diff_driver_registry_new(void);
void git_diff_driver_registry_free(git_diff_driver_registry *);

int git_diff_driver_lookup(git_diff_driver **, git_repository *,
 git_attr_session *attrsession, const char *);
void git_diff_driver_free(git_diff_driver *);


void git_diff_driver_update_options(uint32_t *option_flags, git_diff_driver *);


int git_diff_driver_content_is_binary(
 git_diff_driver *, const char *content, size_t content_len);

typedef long (*git_diff_find_context_fn)(
 const char *, long, char *, long, void *);

typedef int (*git_diff_find_context_line)(
 git_diff_driver *, git_str *);

typedef struct {
 git_diff_driver *driver;
 git_diff_find_context_line match_line;
 git_str line;
} git_diff_find_context_payload;

void git_diff_find_context_init(
 git_diff_find_context_fn *findfn_out,
 git_diff_find_context_payload *payload_out,
 git_diff_driver *driver);

void git_diff_find_context_clear(git_diff_find_context_payload *);
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/grafts.h" 1
# 11 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/grafts.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oidarray.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/oidarray.h"
typedef struct { git_oid *ptr; size_t size, asize; } git_array_oid_t;

extern void git_oidarray__reverse(git_oidarray *arr);
extern void git_oidarray__from_array(git_oidarray *out, const git_array_oid_t *array);
extern void git_oidarray__to_array(git_array_oid_t *out, const git_oidarray *array);

int git_oidarray__add(git_array_oid_t *arr, git_oid *id);
_Bool git_oidarray__remove(git_array_oid_t *arr, git_oid *id);
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/grafts.h" 2


typedef struct {
 git_oid oid;
 git_array_oid_t parents;
} git_commit_graft;

typedef struct git_grafts git_grafts;

int git_grafts_new(git_grafts **out, git_oid_t oid_type);
int git_grafts_open(git_grafts **out, const char *path, git_oid_t oid_type);
int git_grafts_open_or_refresh(git_grafts **out, const char *path, git_oid_t oid_type);
void git_grafts_free(git_grafts *grafts);
void git_grafts_clear(git_grafts *grafts);

int git_grafts_refresh(git_grafts *grafts);
int git_grafts_parse(git_grafts *grafts, const char *buf, size_t len);
int git_grafts_add(git_grafts *grafts, const git_oid *oid, git_array_oid_t parents);
int git_grafts_remove(git_grafts *grafts, const git_oid *oid);
int git_grafts_get(git_commit_graft **out, git_grafts *grafts, const git_oid *oid);
int git_grafts_oids(git_oid **out, size_t *out_len, git_grafts *grafts);
size_t git_grafts_size(git_grafts *grafts);
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h" 2
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h"
extern _Bool git_repository__fsync_gitdir;
extern _Bool git_repository__validate_ownership;


typedef enum {
 GIT_CONFIGMAP_AUTO_CRLF = 0,
 GIT_CONFIGMAP_EOL,
 GIT_CONFIGMAP_SYMLINKS,
 GIT_CONFIGMAP_IGNORECASE,
 GIT_CONFIGMAP_FILEMODE,
 GIT_CONFIGMAP_IGNORESTAT,
 GIT_CONFIGMAP_TRUSTCTIME,
 GIT_CONFIGMAP_ABBREV,
 GIT_CONFIGMAP_PRECOMPOSE,
 GIT_CONFIGMAP_SAFE_CRLF,
 GIT_CONFIGMAP_LOGALLREFUPDATES,
 GIT_CONFIGMAP_PROTECTHFS,
 GIT_CONFIGMAP_PROTECTNTFS,
 GIT_CONFIGMAP_FSYNCOBJECTFILES,
 GIT_CONFIGMAP_LONGPATHS,
 GIT_CONFIGMAP_CACHE_MAX
} git_configmap_item;
# 68 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h"
typedef enum {

 GIT_CONFIGMAP_NOT_CACHED = -1,


 GIT_SAFE_CRLF_FALSE = 0,
 GIT_SAFE_CRLF_FAIL = 1,
 GIT_SAFE_CRLF_WARN = 2,


 GIT_AUTO_CRLF_FALSE = 0,
 GIT_AUTO_CRLF_TRUE = 1,
 GIT_AUTO_CRLF_INPUT = 2,
 GIT_AUTO_CRLF_DEFAULT = GIT_AUTO_CRLF_FALSE,


 GIT_EOL_UNSET = 0,
 GIT_EOL_CRLF = 1,
 GIT_EOL_LF = 2,



 GIT_EOL_NATIVE = GIT_EOL_LF,

 GIT_EOL_DEFAULT = GIT_EOL_NATIVE,


 GIT_SYMLINKS_DEFAULT = GIT_CONFIGMAP_TRUE,

 GIT_IGNORECASE_DEFAULT = GIT_CONFIGMAP_FALSE,

 GIT_FILEMODE_DEFAULT = GIT_CONFIGMAP_TRUE,

 GIT_IGNORESTAT_DEFAULT = GIT_CONFIGMAP_FALSE,

 GIT_TRUSTCTIME_DEFAULT = GIT_CONFIGMAP_TRUE,

 GIT_ABBREV_FALSE = (20 * 2),
 GIT_ABBREV_MINIMUM = 4,
 GIT_ABBREV_DEFAULT = 7,

 GIT_PRECOMPOSE_DEFAULT = GIT_CONFIGMAP_FALSE,

 GIT_SAFE_CRLF_DEFAULT = GIT_CONFIGMAP_FALSE,

 GIT_LOGALLREFUPDATES_FALSE = GIT_CONFIGMAP_FALSE,
 GIT_LOGALLREFUPDATES_TRUE = GIT_CONFIGMAP_TRUE,
 GIT_LOGALLREFUPDATES_UNSET = 2,
 GIT_LOGALLREFUPDATES_ALWAYS = 3,
 GIT_LOGALLREFUPDATES_DEFAULT = GIT_LOGALLREFUPDATES_UNSET,

 GIT_PROTECTHFS_DEFAULT = GIT_CONFIGMAP_FALSE,

 GIT_PROTECTNTFS_DEFAULT = GIT_CONFIGMAP_TRUE,

 GIT_FSYNCOBJECTFILES_DEFAULT = GIT_CONFIGMAP_FALSE,

 GIT_LONGPATHS_DEFAULT = GIT_CONFIGMAP_FALSE
} git_configmap_value;


enum {
 GIT_REPOSITORY_INIT__HAS_DOTGIT = (1u << 16),
 GIT_REPOSITORY_INIT__NATURAL_WD = (1u << 17),
 GIT_REPOSITORY_INIT__IS_REINIT = (1u << 18)
};


struct git_repository {
 git_odb *_odb;
 git_refdb *_refdb;
 git_config *_config;
 git_index *_index;

 git_cache objects;
 git_attr_cache *attrcache;
 git_diff_driver_registry *diff_drivers;

 char *gitlink;
 char *gitdir;
 char *commondir;
 char *workdir;
 char *namespace;

 char *ident_name;
 char *ident_email;

 struct { git_str *ptr; size_t size, asize; } reserved_names;

 unsigned use_env:1,
          is_bare:1,
          is_worktree:1;
 git_oid_t oid_type;

 unsigned int lru_counter;

 git_grafts *grafts;
 git_grafts *shallow_grafts;

 git_atomic32 attr_session_key;

 intptr_t configmap_cache[GIT_CONFIGMAP_CACHE_MAX];
 git_submodule_cache *submodule_cache;
};

static __inline__ git_attr_cache * git_repository_attr_cache(git_repository *repo)
{
 return repo->attrcache;
}

int git_repository_head_commit(git_commit **commit, git_repository *repo);
int git_repository_head_tree(git_tree **tree, git_repository *repo);
int git_repository_create_head(const char *git_dir, const char *ref_name);

typedef int (*git_repository_foreach_worktree_cb)(git_repository *, void *);

int git_repository_foreach_worktree(git_repository *repo,
        git_repository_foreach_worktree_cb cb,
        void *payload);
# 195 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h"
int git_repository_config__weakptr(git_config **out, git_repository *repo);
int git_repository_odb__weakptr(git_odb **out, git_repository *repo);
int git_repository_refdb__weakptr(git_refdb **out, git_repository *repo);
int git_repository_index__weakptr(git_index **out, git_repository *repo);
int git_repository_grafts__weakptr(git_grafts **out, git_repository *repo);
int git_repository_shallow_grafts__weakptr(git_grafts **out, git_repository *repo);







int git_repository__configmap_lookup(int *out, git_repository *repo, git_configmap_item item);
void git_repository__configmap_lookup_cache_clear(git_repository *repo);


int git_repository__abbrev_length(int *out, git_repository *repo);

int git_repository__item_path(git_str *out, const git_repository *repo, git_repository_item_t item);

static __inline__ int git_repository__ensure_not_bare(
 git_repository *repo,
 const char *operation_name)
{
 if (!git_repository_is_bare(repo))
  return 0;

 git_error_set(
  GIT_ERROR_REPOSITORY,
  "cannot %s. This operation is not allowed against bare repositories.",
  operation_name);

 return GIT_EBAREREPO;
}

int git_repository__set_orig_head(git_repository *repo, const git_oid *orig_head);

int git_repository__cleanup_files(git_repository *repo, const char *files[], size_t files_len);


extern git_str git_repository__reserved_names_win32[];
extern size_t git_repository__reserved_names_win32_len;

extern git_str git_repository__reserved_names_posix[];
extern size_t git_repository__reserved_names_posix_len;
# 252 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.h"
_Bool git_repository__reserved_names(
 git_str **out, size_t *outlen, git_repository *repo, _Bool include_ntfs);

int git_repository__shallow_roots(git_oid **out, size_t *out_len, git_repository *repo);
int git_repository__shallow_roots_write(git_repository *repo, git_oidarray *roots);





int git_repository_initialbranch(git_str *out, git_repository *repo);







int git_repository_workdir_path(git_str *out, git_repository *repo, const char *path);

int git_repository__extensions(char ***out, size_t *out_len);
int git_repository__set_extensions(const char **extensions, size_t len);
void git_repository__free_extensions(void);





int git_repository__set_objectformat(
 git_repository *repo,
 git_oid_t oid_type);


int git_repository__new(git_repository **out, git_oid_t oid_type);
# 9 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2




# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h" 1
# 90 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_new(git_repository **out);
# 108 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository__cleanup(git_repository *repo);
# 125 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_reinit_filesystem(
 git_repository *repo,
 int recurse_submodules);
# 143 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_config(git_repository *repo, git_config *config);
# 159 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_odb(git_repository *repo, git_odb *odb);
# 175 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_refdb(git_repository *repo, git_refdb *refdb);
# 191 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_index(git_repository *repo, git_index *index);
# 204 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_set_bare(git_repository *repo);
# 218 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_submodule_cache_all(
 git_repository *repo);
# 234 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/repository.h"
extern __attribute__((visibility("default"))) int git_repository_submodule_cache_clear(
 git_repository *repo);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/buf.h" 1
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/buf.h"
extern int git_buf_sanitize(git_buf *from_user);






extern int git_buf_tostr(git_str *out, git_buf *buf);





extern int git_buf_fromstr(git_buf *out, git_str *str);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tree.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tree.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h" 1
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
typedef struct {
 unsigned int version;





 git_oid_t oid_type;
} git_odb_backend_pack_options;
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
typedef enum {
 GIT_ODB_BACKEND_LOOSE_FSYNC = (1 << 0)
} git_odb_backend_loose_flag_t;


typedef struct {
 unsigned int version;


 uint32_t flags;
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
 int compression_level;


 unsigned int dir_mode;


 unsigned int file_mode;





 git_oid_t oid_type;
} git_odb_backend_loose_options;
# 142 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
extern __attribute__((visibility("default"))) int git_odb_backend_pack(
 git_odb_backend **out,
 const char *objects_dir);
# 156 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
extern __attribute__((visibility("default"))) int git_odb_backend_one_pack(
 git_odb_backend **out,
 const char *index_file);
# 171 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
extern __attribute__((visibility("default"))) int git_odb_backend_loose(
 git_odb_backend **out,
 const char *objects_dir,
 int compression_level,
 int do_fsync,
 unsigned int dir_mode,
 unsigned int file_mode);




typedef enum {
 GIT_STREAM_RDONLY = (1 << 1),
 GIT_STREAM_WRONLY = (1 << 2),
 GIT_STREAM_RW = (GIT_STREAM_RDONLY | GIT_STREAM_WRONLY)
} git_odb_stream_t;
# 196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
struct git_odb_stream {
 git_odb_backend *backend;
 unsigned int mode;
 void *hash_ctx;





 git_object_size_t declared_size;
 git_object_size_t received_bytes;




 int (*read)(git_odb_stream *stream, char *buffer, size_t len);




 int (*write)(git_odb_stream *stream, const char *buffer, size_t len);
# 228 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/odb_backend.h"
 int (*finalize_write)(git_odb_stream *stream, const git_oid *oid);







 void (*free)(git_odb_stream *stream);
};


struct git_odb_writepack {
 git_odb_backend *backend;

 int (*append)(git_odb_writepack *writepack, const void *data, size_t size, git_indexer_progress *stats);
 int (*commit)(git_odb_writepack *writepack, git_indexer_progress *stats);
 void (*free)(git_odb_writepack *writepack);
};
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h" 1
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
typedef struct {
 unsigned int version;





} git_commit_graph_open_options;
# 56 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_open_options_init(
 git_commit_graph_open_options *opts,
 unsigned int version);
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_open(
 git_commit_graph **cgraph_out,
 const char *objects_dir



 );
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) void git_commit_graph_free(git_commit_graph *cgraph);






typedef enum {




 GIT_COMMIT_GRAPH_SPLIT_STRATEGY_SINGLE_FILE = 0
} git_commit_graph_split_strategy_t;







typedef struct {
 unsigned int version;
# 119 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
 git_commit_graph_split_strategy_t split_strategy;





 float size_multiple;





 size_t max_commits;
} git_commit_graph_writer_options;
# 152 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_writer_options_init(
 git_commit_graph_writer_options *opts,
 unsigned int version);
# 165 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_writer_new(
  git_commit_graph_writer **out,
  const char *objects_info_dir,
  const git_commit_graph_writer_options *options);






extern __attribute__((visibility("default"))) void git_commit_graph_writer_free(git_commit_graph_writer *w);
# 185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_writer_add_index_file(
  git_commit_graph_writer *w,
  git_repository *repo,
  const char *idx_path);
# 198 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_writer_add_revwalk(
  git_commit_graph_writer *w,
  git_revwalk *walk);







extern __attribute__((visibility("default"))) int git_commit_graph_writer_commit(
  git_commit_graph_writer *w);
# 218 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/commit_graph.h"
extern __attribute__((visibility("default"))) int git_commit_graph_writer_dump(
  git_buf *buffer,
  git_commit_graph_writer *w);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit_graph.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit_graph.h"
typedef struct git_commit_graph_file {
 git_map graph_map;


 git_oid_t oid_type;


 const uint32_t *oid_fanout;

 uint32_t num_commits;


 unsigned char *oid_lookup;
# 51 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit_graph.h"
 const unsigned char *commit_data;






 const unsigned char *extra_edge_list;

 size_t num_extra_edge_list;


 unsigned char checksum[20];
} git_commit_graph_file;





typedef struct git_commit_graph_entry {

 size_t generation;


 git_time_t commit_time;


 size_t parent_count;






 size_t parent_indices[2];


 size_t extra_parents_index;


 git_oid tree_oid;


 git_oid sha1;
} git_commit_graph_entry;


struct git_commit_graph {

 git_str filename;


 git_commit_graph_file *file;


 git_oid_t oid_type;


 _Bool checked;
};


int git_commit_graph_new(
 git_commit_graph **cgraph_out,
 const char *objects_dir,
 _Bool open_file,
 git_oid_t oid_type);


int git_commit_graph_validate(git_commit_graph *cgraph);


int git_commit_graph_file_open(
 git_commit_graph_file **file_out,
 const char *path,
 git_oid_t oid_type);
# 135 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit_graph.h"
int git_commit_graph_get_file(git_commit_graph_file **file_out, git_commit_graph *cgraph);


void git_commit_graph_refresh(git_commit_graph *cgraph);




struct git_commit_graph_writer {




 git_str objects_info_dir;


 git_oid_t oid_type;


 git_vector commits;
};

int git_commit_graph__writer_dump(
 git_str *cgraph,
 git_commit_graph_writer *w);





_Bool git_commit_graph_file_needs_refresh(
  const git_commit_graph_file *file, const char *path);

int git_commit_graph_entry_find(
  git_commit_graph_entry *e,
  const git_commit_graph_file *file,
  const git_oid *short_oid,
  size_t len);
int git_commit_graph_entry_parent(
  git_commit_graph_entry *parent,
  const git_commit_graph_file *file,
  const git_commit_graph_entry *entry,
  size_t n);
int git_commit_graph_file_close(git_commit_graph_file *cgraph);
void git_commit_graph_file_free(git_commit_graph_file *cgraph);


int git_commit_graph_file_parse(
  git_commit_graph_file *file,
  const unsigned char *data,
  size_t size);
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/filter.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/filter.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) git_filter * git_filter_lookup(const char *name);
# 66 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_new(
 git_filter_list **out,
 git_repository *repo,
 git_filter_mode_t mode,
 uint32_t options);
# 90 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) int git_filter_list_push(
 git_filter_list *fl, git_filter *filter, void *payload);
# 104 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) size_t git_filter_list_length(const git_filter_list *fl);




typedef struct git_filter_source git_filter_source;







extern __attribute__((visibility("default"))) git_repository * git_filter_source_repo(const git_filter_source *src);







extern __attribute__((visibility("default"))) const char * git_filter_source_path(const git_filter_source *src);
# 134 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) uint16_t git_filter_source_filemode(const git_filter_source *src);
# 144 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) const git_oid * git_filter_source_id(const git_filter_source *src);







extern __attribute__((visibility("default"))) git_filter_mode_t git_filter_source_mode(const git_filter_source *src);







extern __attribute__((visibility("default"))) uint32_t git_filter_source_flags(const git_filter_source *src);
# 176 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
typedef int (*git_filter_init_fn)(git_filter *self);
# 190 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
typedef void (*git_filter_shutdown_fn)(git_filter *self);
# 218 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
typedef int (*git_filter_check_fn)(
 git_filter *self,
 void **payload,
 const git_filter_source *src,
 const char **attr_values);
# 245 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
typedef int (*git_filter_apply_fn)(
 git_filter *self,
 void **payload,
 git_buf *to,
 const git_buf *from,
 const git_filter_source *src);
# 269 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
typedef int (*git_filter_stream_fn)(
 git_writestream **out,
 git_filter *self,
 void **payload,
 const git_filter_source *src,
 git_writestream *next);
# 288 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
typedef void (*git_filter_cleanup_fn)(
 git_filter *self,
 void *payload);
# 299 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
struct git_filter {

 unsigned int version;
# 313 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
 const char *attributes;


 git_filter_init_fn initialize;


 git_filter_shutdown_fn shutdown;







 git_filter_check_fn check;
# 337 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
 git_filter_apply_fn apply;
# 347 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
 git_filter_stream_fn stream;


 git_filter_cleanup_fn cleanup;
};
# 367 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) int git_filter_init(git_filter *filter, unsigned int version);
# 395 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) int git_filter_register(
 const char *name, git_filter *filter, int priority);
# 411 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/filter.h"
extern __attribute__((visibility("default"))) int git_filter_unregister(const char *name);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/filter.h" 2




typedef struct {
 git_filter_options options;
 git_attr_session *attr_session;
 git_str *temp_buf;
} git_filter_session;



extern int git_filter_global_init(void);

extern void git_filter_free(git_filter *filter);

extern int git_filter_list__load(
 git_filter_list **filters,
 git_repository *repo,
 git_blob *blob,
 const char *path,
 git_filter_mode_t mode,
 git_filter_session *filter_session);

int git_filter_list__apply_to_buffer(
 git_str *out,
 git_filter_list *filters,
 const char *in,
 size_t in_len);
int git_filter_list__apply_to_file(
 git_str *out,
 git_filter_list *filters,
 git_repository *repo,
 const char *path);
int git_filter_list__apply_to_blob(
 git_str *out,
 git_filter_list *filters,
 git_blob *blob);





extern int git_filter_list__convert_buf(
 git_str *out,
 git_filter_list *filters,
 git_str *in);

extern int git_filter_list__apply_to_file(
 git_str *out,
 git_filter_list *filters,
 git_repository *repo,
 const char *path);





extern git_filter *git_crlf_filter_new(void);
extern git_filter *git_ident_filter_new(void);

extern int git_filter_buffered_stream_new(
 git_writestream **out,
 git_filter *filter,
 int (*write_fn)(git_filter *, void **, git_str *, const git_str *, const git_filter_source *),
 git_str *temp_buf,
 void **payload,
 const git_filter_source *source,
 git_writestream *target);
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h" 2
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h"
extern _Bool git_odb__strict_hash_verification;


typedef struct {
 void *data;
 size_t len;
 git_object_t type;
} git_rawobj;


struct git_odb_object {
 git_cached_obj cached;
 void *buffer;
};


struct git_odb {
 git_refcount rc;
 pthread_mutex_t lock;
 git_odb_options options;
 git_vector backends;
 git_cache own_cache;
 git_commit_graph *cgraph;
 unsigned int do_fsync :1;
};

typedef enum {
 GIT_ODB_CAP_FROM_OWNER = -1
} git_odb_cap_t;




int git_odb__set_caps(git_odb *odb, int caps);




int git_odb__add_default_backends(
 git_odb *db, const char *objects_dir,
 _Bool as_alternates, int alternate_depth);





int git_odb__hashobj(git_oid *id, git_rawobj *obj, git_oid_t oid_type);




int git_odb__format_object_header(size_t *out_len, char *hdr, size_t hdr_size, git_object_size_t obj_len, git_object_t obj_type);
# 94 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h"
int git_odb__hashfd(
 git_oid *out,
 git_file fd,
 size_t size,
 git_object_t object_type,
 git_oid_t oid_type);





int git_odb__hashfd_filtered(
 git_oid *out,
 git_file fd,
 size_t len,
 git_object_t object_type,
 git_oid_t oid_type,
 git_filter_list *fl);
# 121 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/odb.h"
int git_odb__hashlink(git_oid *out, const char *path, git_oid_t oid_type);




int git_odb__error_mismatch(
 const git_oid *expected, const git_oid *actual);




int git_odb__error_notfound(
 const char *message, const git_oid *oid, size_t oid_len);




int git_odb__error_ambiguous(const char *message);





int git_odb__read_header_or_object(
 git_odb_object **out, size_t *len_p, git_object_t *type_p,
 git_odb *db, const git_oid *id);






int git_odb__get_commit_graph_file(git_commit_graph_file **out, git_odb *odb);


int git_odb__freshen(git_odb *db, const git_oid *id);


void git_odb_object__free(void *object);



int git_odb__new(git_odb **out, const git_odb_options *opts);

int git_odb__open(
 git_odb **out,
 const char *objects_dir,
 const git_odb_options *opts);

int git_odb__hash(
 git_oid *out,
 const void *data,
 size_t len,
 git_object_t object_type,
 git_oid_t oid_type);

int git_odb__hashfile(
 git_oid *out,
 const char *path,
 git_object_t object_type,
 git_oid_t oid_type);

extern __attribute__((visibility("default"))) int git_odb__backend_loose(
 git_odb_backend **out,
 const char *objects_dir,
 git_odb_backend_loose_options *opts);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tree.h" 2



struct git_tree_entry {
 uint16_t attr;
 uint16_t filename_len;
 git_oid oid;
 const char *filename;
};

struct git_tree {
 git_object object;
 git_odb_object *odb_obj;
 struct { git_tree_entry *ptr; size_t size, asize; } entries;
};

typedef struct { uint32_t n_buckets, size, n_occupied, upper_bound; uint32_t *flags; const char * *keys; git_tree_entry * *vals; } git_treebuilder_entrymap;;

struct git_treebuilder {
 git_repository *repo;
 git_treebuilder_entrymap map;
 git_str write_cache;
};

static __inline__ _Bool git_tree_entry__is_tree(const struct git_tree_entry *e)
{
 return (((((e->attr)) & 0170000) == (0040000)) && !(((e->attr) & 0170000) == 0160000));
}

void git_tree__free(void *tree);
int git_tree__parse(void *tree, git_odb_object *obj, git_oid_t oid_type);
int git_tree__parse_raw(void *_tree, const char *data, size_t size, git_oid_t oid_type);




int git_tree__write_index(
 git_oid *oid, git_index *index, git_repository *repo);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit.h" 2





struct git_commit {
 git_object object;

 struct { git_oid *ptr; size_t size, asize; } parent_ids;
 git_oid tree_id;

 git_signature *author;
 git_signature *committer;

 char *message_encoding;
 char *raw_message;
 char *raw_header;

 char *summary;
 char *body;
};

typedef struct {
 git_oid_t oid_type;
 unsigned int flags;
} git_commit__parse_options;

typedef enum {

 GIT_COMMIT_PARSE_QUICK = (1 << 0)
} git_commit__parse_flags;

int git_commit__header_field(
 git_str *out,
 const git_commit *commit,
 const char *field);

int git_commit__extract_signature(
 git_str *signature,
 git_str *signed_data,
 git_repository *repo,
 git_oid *commit_id,
 const char *field);

int git_commit__create_buffer(
 git_str *out,
 git_repository *repo,
 const git_signature *author,
 const git_signature *committer,
 const char *message_encoding,
 const char *message,
 const git_tree *tree,
 size_t parent_count,
 const git_commit *parents[]);

int git_commit__parse(
 void *commit,
 git_odb_object *obj,
 git_oid_t oid_type);

int git_commit__parse_raw(
 void *commit,
 const char *data,
 size_t size,
 git_oid_t oid_type);

int git_commit__parse_ext(
 git_commit *commit,
 git_odb_object *odb_obj,
 git_commit__parse_options *parse_opts);

void git_commit__free(void *commit);
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tag.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tag.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h" 1
# 33 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_lookup(
 git_tag **out, git_repository *repo, const git_oid *id);
# 48 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_lookup_prefix(
 git_tag **out, git_repository *repo, const git_oid *id, size_t len);
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) void git_tag_free(git_tag *tag);







extern __attribute__((visibility("default"))) const git_oid * git_tag_id(const git_tag *tag);







extern __attribute__((visibility("default"))) git_repository * git_tag_owner(const git_tag *tag);
# 89 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_target(git_object **target_out, const git_tag *tag);







extern __attribute__((visibility("default"))) const git_oid * git_tag_target_id(const git_tag *tag);







extern __attribute__((visibility("default"))) git_object_t git_tag_target_type(const git_tag *tag);







extern __attribute__((visibility("default"))) const char * git_tag_name(const git_tag *tag);







extern __attribute__((visibility("default"))) const git_signature * git_tag_tagger(const git_tag *tag);







extern __attribute__((visibility("default"))) const char * git_tag_message(const git_tag *tag);
# 171 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_create(
 git_oid *oid,
 git_repository *repo,
 const char *tag_name,
 const git_object *target,
 const git_signature *tagger,
 const char *message,
 int force);
# 203 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_annotation_create(
 git_oid *oid,
 git_repository *repo,
 const char *tag_name,
 const git_object *target,
 const git_signature *tagger,
 const char *message);
# 220 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_create_from_buffer(
 git_oid *oid,
 git_repository *repo,
 const char *buffer,
 int force);
# 256 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_create_lightweight(
 git_oid *oid,
 git_repository *repo,
 const char *tag_name,
 const git_object *target,
 int force);
# 276 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_delete(
 git_repository *repo,
 const char *tag_name);
# 293 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_list(
 git_strarray *tag_names,
 git_repository *repo);
# 315 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_list_match(
 git_strarray *tag_names,
 const char *pattern,
 git_repository *repo);
# 330 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
typedef int (*git_tag_foreach_cb)(const char *name, git_oid *oid, void *payload);
# 340 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_foreach(
 git_repository *repo,
 git_tag_foreach_cb callback,
 void *payload);
# 356 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_peel(
 git_object **tag_target_out,
 const git_tag *tag);
# 368 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_dup(git_tag **out, git_tag *source);
# 380 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/tag.h"
extern __attribute__((visibility("default"))) int git_tag_name_is_valid(int *valid, const char *name);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tag.h" 2



struct git_tag {
 git_object object;

 git_oid target;
 git_object_t type;

 char *tag_name;
 git_signature *tagger;
 char *message;
};

void git_tag__free(void *tag);
int git_tag__parse(void *tag, git_odb_object *obj, git_oid_t oid_type);
int git_tag__parse_raw(void *tag, const char *data, size_t size, git_oid_t oid_type);
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/blob.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/blob.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h" 1
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_lookup(
 git_blob **blob,
 git_repository *repo,
 const git_oid *id);
# 54 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_lookup_prefix(git_blob **blob, git_repository *repo, const git_oid *id, size_t len);
# 67 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) void git_blob_free(git_blob *blob);







extern __attribute__((visibility("default"))) const git_oid * git_blob_id(const git_blob *blob);







extern __attribute__((visibility("default"))) git_repository * git_blob_owner(const git_blob *blob);
# 96 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) const void * git_blob_rawcontent(const git_blob *blob);







extern __attribute__((visibility("default"))) git_object_size_t git_blob_rawsize(const git_blob *blob);






typedef enum {

 GIT_BLOB_FILTER_CHECK_FOR_BINARY = (1 << 0),





 GIT_BLOB_FILTER_NO_SYSTEM_ATTRIBUTES = (1 << 1),





 GIT_BLOB_FILTER_ATTRIBUTES_FROM_HEAD = (1 << 2),





 GIT_BLOB_FILTER_ATTRIBUTES_FROM_COMMIT = (1 << 3)
} git_blob_filter_flag_t;
# 144 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
typedef struct {

 int version;






 uint32_t flags;
# 168 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
 git_oid *commit_id;






 git_oid attr_commit_id;
} git_blob_filter_options;
# 201 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_filter_options_init(
 git_blob_filter_options *opts,
 unsigned int version);
# 227 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_filter(
 git_buf *out,
 git_blob *blob,
 const char *as_path,
 git_blob_filter_options *opts);
# 244 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_create_from_workdir(git_oid *id, git_repository *repo, const char *relative_path);
# 257 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_create_from_disk(
 git_oid *id,
 git_repository *repo,
 const char *path);
# 287 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_create_from_stream(
 git_writestream **out,
 git_repository *repo,
 const char *hintpath);
# 301 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_create_from_stream_commit(
 git_oid *out,
 git_writestream *stream);
# 314 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_create_from_buffer(
 git_oid *id, git_repository *repo, const void *buffer, size_t len);
# 328 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_is_binary(const git_blob *blob);
# 340 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_data_is_binary(const char *data, size_t len);
# 350 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/blob.h"
extern __attribute__((visibility("default"))) int git_blob_dup(git_blob **out, git_blob *source);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/blob.h" 2




struct git_blob {
 git_object object;

 union {
  git_odb_object *odb;
  struct {
   const char *data;
   git_object_size_t size;
  } raw;
 } data;
 unsigned int raw:1;
};
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/blob.h"
void git_blob__free(void *blob);
int git_blob__parse(void *blob, git_odb_object *obj, git_oid_t oid_type);
int git_blob__parse_raw(void *blob, const char *data, size_t size, git_oid_t oid_type);
int git_blob__getbuf(git_str *buffer, git_blob *blob);

extern int git_blob__create_from_paths(
 git_oid *out_oid,
 struct stat *out_st,
 git_repository *repo,
 const char *full_path,
 const char *hint_path,
 mode_t hint_mode,
 _Bool apply_filters);
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h" 1
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_find_global_file(git_str *path, const char *filename);
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_find_xdg_file(git_str *path, const char *filename);
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_find_system_file(git_str *path, const char *filename);
# 49 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_find_programdata_file(git_str *path, const char *filename);







extern int git_sysdir_find_template_dir(git_str *path);
# 68 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_find_homedir(git_str *path);
# 81 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_expand_global_file(git_str *path, const char *filename);
# 92 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_expand_homedir_file(git_str *path, const char *filename);

typedef enum {
 GIT_SYSDIR_SYSTEM = 0,
 GIT_SYSDIR_GLOBAL = 1,
 GIT_SYSDIR_XDG = 2,
 GIT_SYSDIR_PROGRAMDATA = 3,
 GIT_SYSDIR_TEMPLATE = 4,
 GIT_SYSDIR_HOME = 5,
 GIT_SYSDIR__MAX = 6
} git_sysdir_t;






extern int git_sysdir_global_init(void);
# 118 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_get(const git_str **out, git_sysdir_t which);
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/sysdir.h"
extern int git_sysdir_set(git_sysdir_t which, const char *paths);




extern int git_sysdir_reset(void);
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/filebuf.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/filebuf.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h" 1
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h" 1
# 254 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 72 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 73 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3
# 87 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h" 1 3
# 88 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3
# 107 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_max_align_t.h" 1 3
# 19 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_max_align_t.h" 3
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
# 108 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_offsetof.h" 1 3
# 113 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3
# 255 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h" 2
 typedef size_t z_size_t;
# 393 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h"
typedef unsigned char Byte;

typedef unsigned int uInt;
typedef unsigned long uLong;





   typedef Byte Bytef;

typedef char charf;
typedef int intf;
typedef uInt uIntf;
typedef uLong uLongf;


   typedef void const *voidpc;
   typedef void *voidpf;
   typedef void *voidp;







# 1 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 1 3
# 421 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h" 2
# 431 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h"
   typedef unsigned z_crc_t;
# 452 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdarg.h" 1 3
# 453 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zconf.h" 2
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h" 2
# 81 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
typedef voidpf (*alloc_func)(voidpf opaque, uInt items, uInt size);
typedef void (*free_func)(voidpf opaque, voidpf address);

struct internal_state;

typedef struct z_stream_s {
            Bytef *next_in;
    uInt avail_in;
    uLong total_in;

    Bytef *next_out;
    uInt avail_out;
    uLong total_out;

            char *msg;
    struct internal_state *state;

    alloc_func zalloc;
    free_func zfree;
    voidpf opaque;

    int data_type;

    uLong adler;
    uLong reserved;
} z_stream;

typedef z_stream *z_streamp;





typedef struct gz_header_s {
    int text;
    uLong time;
    int xflags;
    int os;
    Bytef *extra;
    uInt extra_len;
    uInt extra_max;
    Bytef *name;
    uInt name_max;
    Bytef *comment;
    uInt comm_max;
    int hcrc;
    int done;

} gz_header;

typedef gz_header *gz_headerp;
# 220 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern const char * zlibVersion(void);
# 250 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflate(z_streamp strm, int flush);
# 363 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateEnd(z_streamp strm);
# 401 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflate(z_streamp strm, int flush);
# 521 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateEnd(z_streamp strm);
# 611 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateSetDictionary(z_streamp strm,
                                         const Bytef *dictionary,
                                         uInt dictLength);
# 655 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateGetDictionary(z_streamp strm,
                                         Bytef *dictionary,
                                         uInt *dictLength);
# 677 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateCopy(z_streamp dest,
                                z_streamp source);
# 695 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateReset(z_streamp strm);
# 706 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateParams(z_streamp strm,
                                  int level,
                                  int strategy);
# 744 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateTune(z_streamp strm,
                                int good_length,
                                int max_lazy,
                                int nice_length,
                                int max_chain);
# 761 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong deflateBound(z_streamp strm,
                                   uLong sourceLen);
# 776 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflatePending(z_streamp strm,
                                   unsigned *pending,
                                   int *bits);
# 791 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflatePrime(z_streamp strm,
                                 int bits,
                                 int value);
# 808 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateSetHeader(z_streamp strm,
                                     gz_headerp head);
# 888 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateSetDictionary(z_streamp strm,
                                         const Bytef *dictionary,
                                         uInt dictLength);
# 911 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateGetDictionary(z_streamp strm,
                                         Bytef *dictionary,
                                         uInt *dictLength);
# 926 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateSync(z_streamp strm);
# 945 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateCopy(z_streamp dest,
                                z_streamp source);
# 961 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateReset(z_streamp strm);
# 972 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateReset2(z_streamp strm,
                                  int windowBits);
# 986 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflatePrime(z_streamp strm,
                                 int bits,
                                 int value);
# 1007 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern long inflateMark(z_streamp strm);
# 1035 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateGetHeader(z_streamp strm,
                                     gz_headerp head);
# 1097 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
typedef unsigned (*in_func)(void *,
                                    unsigned char * *);
typedef int (*out_func)(void *, unsigned char *, unsigned);

extern int inflateBack(z_streamp strm,
                                in_func in, void *in_desc,
                                out_func out, void *out_desc);
# 1171 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int inflateBackEnd(z_streamp strm);







extern uLong zlibCompileFlags(void);
# 1232 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int compress(Bytef *dest, uLongf *destLen,
                             const Bytef *source, uLong sourceLen);
# 1247 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int compress2(Bytef *dest, uLongf *destLen,
                              const Bytef *source, uLong sourceLen,
                              int level);
# 1263 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong compressBound(uLong sourceLen);






extern int uncompress(Bytef *dest, uLongf *destLen,
                               const Bytef *source, uLong sourceLen);
# 1288 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int uncompress2(Bytef *dest, uLongf *destLen,
                                const Bytef *source, uLong *sourceLen);
# 1305 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
typedef struct gzFile_s *gzFile;
# 1345 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern gzFile gzdopen(int fd, const char *mode);
# 1368 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzbuffer(gzFile file, unsigned size);
# 1384 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzsetparams(gzFile file, int level, int strategy);
# 1395 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzread(gzFile file, voidp buf, unsigned len);
# 1425 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern z_size_t gzfread(voidp buf, z_size_t size, z_size_t nitems,
                                 gzFile file);
# 1451 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzwrite(gzFile file, voidpc buf, unsigned len);





extern z_size_t gzfwrite(voidpc buf, z_size_t size,
                                  z_size_t nitems, gzFile file);
# 1471 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzprintf(gzFile file, const char *format, ...);
# 1486 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzputs(gzFile file, const char *s);







extern char * gzgets(gzFile file, char *buf, int len);
# 1508 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzputc(gzFile file, int c);





extern int gzgetc(gzFile file);
# 1523 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzungetc(int c, gzFile file);
# 1535 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzflush(gzFile file, int flush);
# 1570 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzrewind(gzFile file);
# 1598 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzeof(gzFile file);
# 1613 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzdirect(gzFile file);
# 1634 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzclose(gzFile file);
# 1647 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int gzclose_r(gzFile file);
extern int gzclose_w(gzFile file);
# 1659 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern const char * gzerror(gzFile file, int *errnum);
# 1675 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern void gzclearerr(gzFile file);
# 1692 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong adler32(uLong adler, const Bytef *buf, uInt len);
# 1712 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong adler32_z(uLong adler, const Bytef *buf,
                                z_size_t len);
# 1730 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong crc32(uLong crc, const Bytef *buf, uInt len);
# 1748 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong crc32_z(uLong crc, const Bytef *buf,
                              z_size_t len);
# 1771 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern uLong crc32_combine_op(uLong crc1, uLong crc2, uLong op);
# 1784 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern int deflateInit_(z_streamp strm, int level,
                                 const char *version, int stream_size);
extern int inflateInit_(z_streamp strm,
                                 const char *version, int stream_size);
extern int deflateInit2_(z_streamp strm, int level, int method,
                                  int windowBits, int memLevel,
                                  int strategy, const char *version,
                                  int stream_size);
extern int inflateInit2_(z_streamp strm, int windowBits,
                                  const char *version, int stream_size);
extern int inflateBackInit_(z_streamp strm, int windowBits,
                                     unsigned char *window,
                                     const char *version,
                                     int stream_size);
# 1837 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
struct gzFile_s {
    unsigned have;
    unsigned char *next;
    off64_t pos;
};
extern int gzgetc_(gzFile file);
# 1859 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
   extern gzFile gzopen64(const char *, const char *);
   extern off64_t gzseek64(gzFile, off64_t, int);
   extern off64_t gztell64(gzFile);
   extern off64_t gzoffset64(gzFile);
   extern uLong adler32_combine64(uLong, uLong, off64_t);
   extern uLong crc32_combine64(uLong, uLong, off64_t);
   extern uLong crc32_combine_gen64(off64_t);
# 1896 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
   extern gzFile gzopen(const char *, const char *);
   extern off_t gzseek(gzFile, off_t, int);
   extern off_t gztell(gzFile);
   extern off_t gzoffset(gzFile);
   extern uLong adler32_combine(uLong, uLong, off_t);
   extern uLong crc32_combine(uLong, uLong, off_t);
   extern uLong crc32_combine_gen(off_t);
# 1914 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/deps/zlib/zlib.h"
extern const char * zError(int);
extern int inflateSyncPoint(z_streamp);
extern const z_crc_t * get_crc_table(void);
extern int inflateUndermine(z_streamp, int);
extern int inflateValidate(z_streamp, int);
extern unsigned long inflateCodesUsed(z_streamp);
extern int inflateResetKeep(z_streamp);
extern int deflateResetKeep(z_streamp);






extern int gzvprintf(gzFile file,
                                           const char *format,
                                           va_list va);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/filebuf.h" 2
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/filebuf.h"
typedef struct git_filebuf git_filebuf;
struct git_filebuf {
 char *path_original;
 char *path_lock;

 int (*write)(git_filebuf *file, void *source, size_t len);

 _Bool compute_digest;
 git_hash_ctx digest;

 unsigned char *buffer;
 unsigned char *z_buf;

 z_stream zs;
 int flush_mode;

 size_t buf_size, buf_pos;
 git_file fd;
 _Bool fd_is_open;
 _Bool created_lock;
 _Bool did_rename;
 _Bool do_not_buffer;
 _Bool do_fsync;
 int last_error;
};
# 82 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/filebuf.h"
int git_filebuf_write(git_filebuf *lock, const void *buff, size_t len);
int git_filebuf_reserve(git_filebuf *file, void **buff, size_t len);
int git_filebuf_printf(git_filebuf *file, const char *format, ...) __attribute__((format (printf, 2, 3)));

int git_filebuf_open(git_filebuf *lock, const char *path, int flags, mode_t mode);
int git_filebuf_open_withsize(git_filebuf *file, const char *path, int flags, mode_t mode, size_t size);
int git_filebuf_commit(git_filebuf *lock);
int git_filebuf_commit_at(git_filebuf *lock, const char *path);
void git_filebuf_cleanup(git_filebuf *lock);
int git_filebuf_hash(unsigned char *out, git_filebuf *file);
int git_filebuf_flush(git_filebuf *file);
int git_filebuf_stats(time_t *mtime, size_t *size, git_filebuf *file);

static __inline__ int git_filebuf_hash_flags(git_hash_algorithm_t algorithm)
{
 switch (algorithm) {
 case GIT_HASH_ALGORITHM_SHA1:
  return (1 << 0);
 case GIT_HASH_ALGORITHM_SHA256:
  return (1 << 1);
 default:
  return 0;
 }
}
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/index.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/index.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tree-cache.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/tree-cache.h"
typedef struct git_tree_cache {
 struct git_tree_cache **children;
 size_t children_count;

 git_oid_t oid_type;

 ssize_t entry_count;
 git_oid oid;
 size_t namelen;
 char name[];
} git_tree_cache;

int git_tree_cache_write(git_str *out, git_tree_cache *tree);
int git_tree_cache_read(git_tree_cache **tree, const char *buffer, size_t buffer_size, git_oid_t oid_type, git_pool *pool);
void git_tree_cache_invalidate_path(git_tree_cache *tree, const char *path);
const git_tree_cache *git_tree_cache_get(const git_tree_cache *tree, const char *path);
int git_tree_cache_new(git_tree_cache **out, const char *name, git_oid_t oid_type, git_pool *pool);



int git_tree_cache_read_tree(git_tree_cache **out, const git_tree *tree, git_oid_t oid_type, git_pool *pool);
void git_tree_cache_free(git_tree_cache *tree);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/index.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/index_map.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/index_map.h"
typedef struct {
 unsigned int ignore_case;
 uint32_t n_buckets, size, n_occupied, upper_bound; uint32_t *flags; git_index_entry * *keys; git_index_entry * *vals;
} git_index_entrymap;



extern int git_index_entrymap_get(git_index_entry **out, git_index_entrymap *map, git_index_entry *e);
extern int git_index_entrymap_put(git_index_entrymap *map, git_index_entry *e);
extern int git_index_entrymap_remove(git_index_entrymap *map, git_index_entry *e);
extern int git_index_entrymap_resize(git_index_entrymap *map, size_t count);
extern void git_index_entrymap_swap(git_index_entrymap *a, git_index_entrymap *b);
extern void git_index_entrymap_clear(git_index_entrymap *map);
extern void git_index_entrymap_dispose(git_index_entrymap *map);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/index.h" 2






extern _Bool git_index__enforce_unsaved_safety;

struct git_index {
 git_refcount rc;

 char *index_file_path;
 git_futils_filestamp stamp;
 unsigned char checksum[32];

 git_vector entries;
 git_index_entrymap entries_map;

 git_vector deleted;
 git_atomic32 readers;

 git_oid_t oid_type;

 unsigned int on_disk:1;
 unsigned int ignore_case:1;
 unsigned int distrust_filemode:1;
 unsigned int no_symlinks:1;
 unsigned int dirty:1;

 git_tree_cache *tree;
 git_pool tree_pool;

 git_vector names;
 git_vector reuc;

 git_vector_cmp entries_cmp_path;
 git_vector_cmp entries_search;
 git_vector_cmp entries_search_path;
 git_vector_cmp reuc_search;

 unsigned int version;
};

struct git_index_iterator {
 git_index *index;
 git_vector snap;
 size_t cur;
};

struct git_index_conflict_iterator {
 git_index *index;
 size_t cur;
};

extern void git_index_entry__init_from_stat(
 git_index_entry *entry, struct stat *st, _Bool trust_mode);


extern int git_index_entry_cmp(const void *a, const void *b);
extern int git_index_entry_icmp(const void *a, const void *b);


extern int git_index_entry_srch(const void *a, const void *b);
extern int git_index_entry_isrch(const void *a, const void *b);


static __inline__ _Bool git_index_time_eq(const git_index_time *one, const git_index_time *two)
{
 if (one->seconds != two->seconds)
  return 0;


 if (one->nanoseconds != two->nanoseconds)
  return 0;


 return 1;
}






static __inline__ _Bool git_index_entry_newer_than_index(
 const git_index_entry *entry, git_index *index)
{

 if (!index || index->stamp.mtime.tv_sec == 0)
  return 0;



 if ((int32_t)index->stamp.mtime.tv_sec < entry->mtime.seconds)
  return 1;
 else if ((int32_t)index->stamp.mtime.tv_sec > entry->mtime.seconds)
  return 0;
 else
  return (uint32_t)index->stamp.mtime.tv_nsec <= entry->mtime.nanoseconds;



}







extern int git_index__find_pos(
 size_t *at_pos, git_index *index, const char *path, size_t path_len, int stage);

extern int git_index__fill(git_index *index, const git_vector *source_entries);

extern void git_index__set_ignore_case(git_index *index, _Bool ignore_case);

extern unsigned int git_index__create_mode(unsigned int mode);

static __inline__ const git_futils_filestamp * git_index__filestamp(git_index *index)
{
 return &index->stamp;
}

static __inline__ unsigned char * git_index__checksum(git_index *index)
{
 return index->checksum;
}



extern int git_index__new(
 git_index **index_out,
 git_oid_t oid_type);

extern int git_index__open(
 git_index **index_out,
 const char *index_path,
 git_oid_t oid_type);




extern int git_index_snapshot_new(git_vector *snap, git_index *index);
extern void git_index_snapshot_release(git_vector *snap, git_index *index);


extern int git_index_snapshot_find(
 size_t *at_pos, git_vector *snap, git_vector_cmp entry_srch,
 const char *path, size_t path_len, int stage);


int git_index_read_index(git_index *index, const git_index *new_index);

static __inline__ int git_index_is_dirty(git_index *index)
{
 return index->dirty;
}

extern int git_index_read_safely(git_index *index);

typedef struct {
 git_index *index;
 git_filebuf file;
 unsigned int should_write:1;
} git_indexwriter;




extern int git_indexwriter_init(git_indexwriter *writer, git_index *index);






extern int git_indexwriter_init_for_operation(
 git_indexwriter *writer,
 git_repository *repo,
 unsigned int *checkout_strategy);


extern int git_indexwriter_commit(git_indexwriter *writer);




extern void git_indexwriter_cleanup(git_indexwriter *writer);
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/config.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/config.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 1
# 12 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h" 1
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
typedef int (*git_apply_delta_cb)(
 const git_diff_delta *delta,
 void *payload);
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
typedef int (*git_apply_hunk_cb)(
 const git_diff_hunk *hunk,
 void *payload);
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
typedef enum {




 GIT_APPLY_CHECK = (1 << 0)
} git_apply_flags_t;
# 95 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
typedef struct {
 unsigned int version;


 git_apply_delta_cb delta_cb;


 git_apply_hunk_cb hunk_cb;


 void *payload;


 unsigned int flags;
} git_apply_options;
# 127 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
extern __attribute__((visibility("default"))) int git_apply_options_init(git_apply_options *opts, unsigned int version);
# 140 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
extern __attribute__((visibility("default"))) int git_apply_to_tree(
 git_index **out,
 git_repository *repo,
 git_tree *preimage,
 git_diff *diff,
 const git_apply_options *options);


typedef enum {




 GIT_APPLY_LOCATION_WORKDIR = 0,





 GIT_APPLY_LOCATION_INDEX = 1,





 GIT_APPLY_LOCATION_BOTH = 2
} git_apply_location_t;
# 178 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/apply.h"
extern __attribute__((visibility("default"))) int git_apply(
 git_repository *repo,
 git_diff *diff,
 git_apply_location_t location,
 const git_apply_options *options);
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h" 1
# 53 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_create(
 git_reference **out,
 git_repository *repo,
 const char *branch_name,
 const git_commit *target,
 int force);
# 77 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_create_from_annotated(
 git_reference **ref_out,
 git_repository *repo,
 const char *branch_name,
 const git_annotated_commit *target,
 int force);
# 94 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_delete(git_reference *branch);


typedef struct git_branch_iterator git_branch_iterator;
# 110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_iterator_new(
 git_branch_iterator **out,
 git_repository *repo,
 git_branch_t list_flags);
# 123 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_next(git_reference **out, git_branch_t *out_type, git_branch_iterator *iter);






extern __attribute__((visibility("default"))) void git_branch_iterator_free(git_branch_iterator *iter);
# 153 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_move(
 git_reference **out,
 git_reference *branch,
 const char *new_branch_name,
 int force);
# 177 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_lookup(
 git_reference **out,
 git_repository *repo,
 const char *branch_name,
 git_branch_t branch_type);
# 198 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_name(
  const char **out,
  const git_reference *ref);
# 216 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_upstream(
 git_reference **out,
 const git_reference *branch);
# 235 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_set_upstream(
 git_reference *branch,
 const char *branch_name);
# 253 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_upstream_name(
 git_buf *out,
 git_repository *repo,
 const char *refname);
# 266 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_is_head(
 const git_reference *branch);
# 279 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_is_checked_out(
 const git_reference *branch);
# 298 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_remote_name(
 git_buf *out,
 git_repository *repo,
 const char *refname);
# 314 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
 extern __attribute__((visibility("default"))) int git_branch_upstream_remote(git_buf *buf, git_repository *repo, const char *refname);
# 327 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
 extern __attribute__((visibility("default"))) int git_branch_upstream_merge(git_buf *buf, git_repository *repo, const char *refname);
# 339 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/branch.h"
extern __attribute__((visibility("default"))) int git_branch_name_is_valid(int *valid, const char *name);
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/email.h" 1
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/email.h"
typedef enum {

 GIT_EMAIL_CREATE_DEFAULT = 0,


 GIT_EMAIL_CREATE_OMIT_NUMBERS = (1u << 0),





 GIT_EMAIL_CREATE_ALWAYS_NUMBER = (1u << 1),


 GIT_EMAIL_CREATE_NO_RENAMES = (1u << 2)
} git_email_create_flags_t;




typedef struct {
 unsigned int version;


 uint32_t flags;


 git_diff_options diff_opts;


 git_diff_find_options diff_find_opts;







 const char *subject_prefix;





 size_t start_number;


 size_t reroll_number;
} git_email_create_options;
# 99 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/email.h"
extern __attribute__((visibility("default"))) int git_email_create_from_commit(
 git_buf *out,
 git_commit *commit,
 const git_email_create_options *opts);
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2/experimental.h" 1
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/global.h" 1
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/global.h"
extern __attribute__((visibility("default"))) int git_libgit2_init(void);
# 45 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/global.h"
extern __attribute__((visibility("default"))) int git_libgit2_shutdown(void);
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/graph.h" 1
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/graph.h"
extern __attribute__((visibility("default"))) int git_graph_ahead_behind(size_t *ahead, size_t *behind, git_repository *repo, const git_oid *local, const git_oid *upstream);
# 53 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/graph.h"
extern __attribute__((visibility("default"))) int git_graph_descendant_of(
 git_repository *repo,
 const git_oid *commit,
 const git_oid *ancestor);
# 69 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/graph.h"
extern __attribute__((visibility("default"))) int git_graph_reachable_from_any(
 git_repository *repo,
 const git_oid *commit,
 const git_oid descendant_array[],
 size_t length);
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/ignore.h" 1
# 46 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/ignore.h"
extern __attribute__((visibility("default"))) int git_ignore_add_rule(
 git_repository *repo,
 const char *rules);
# 61 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/ignore.h"
extern __attribute__((visibility("default"))) int git_ignore_clear_internal_rules(
 git_repository *repo);
# 80 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/ignore.h"
extern __attribute__((visibility("default"))) int git_ignore_path_is_ignored(
 int *ignored,
 git_repository *repo,
 const char *path);
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h" 1
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h"
extern __attribute__((visibility("default"))) int git_mailmap_new(git_mailmap **out);






extern __attribute__((visibility("default"))) void git_mailmap_free(git_mailmap *mm);
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h"
extern __attribute__((visibility("default"))) int git_mailmap_add_entry(
 git_mailmap *mm, const char *real_name, const char *real_email,
 const char *replace_name, const char *replace_email);
# 69 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h"
extern __attribute__((visibility("default"))) int git_mailmap_from_buffer(
 git_mailmap **out, const char *buf, size_t len);
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h"
extern __attribute__((visibility("default"))) int git_mailmap_from_repository(
 git_mailmap **out, git_repository *repo);
# 101 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h"
extern __attribute__((visibility("default"))) int git_mailmap_resolve(
 const char **real_name, const char **real_email,
 const git_mailmap *mm, const char *name, const char *email);
# 115 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/mailmap.h"
extern __attribute__((visibility("default"))) int git_mailmap_resolve_signature(
 git_signature **out, const git_mailmap *mm, const git_signature *sig);
# 39 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/message.h" 1
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/message.h"
extern __attribute__((visibility("default"))) int git_message_prettify(git_buf *out, const char *message, int strip_comments, char comment_char);




typedef struct {
  const char *key;
  const char *value;
} git_message_trailer;







typedef struct {
  git_message_trailer *trailers;
  size_t count;


  char *_trailer_block;
} git_message_trailer_array;
# 73 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/message.h"
extern __attribute__((visibility("default"))) int git_message_trailers(git_message_trailer_array *arr, const char *message);







extern __attribute__((visibility("default"))) void git_message_trailer_array_free(git_message_trailer_array *arr);
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h" 1
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
typedef int (*git_note_foreach_cb)(
 const git_oid *blob_id,
 const git_oid *annotated_object_id,
 void *payload);




typedef struct git_iterator git_note_iterator;
# 51 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_iterator_new(
 git_note_iterator **out,
 git_repository *repo,
 const char *notes_ref);
# 66 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_commit_iterator_new(
 git_note_iterator **out,
 git_commit *notes_commit);






extern __attribute__((visibility("default"))) void git_note_iterator_free(git_note_iterator *it);
# 88 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_next(
 git_oid *note_id,
 git_oid *annotated_id,
 git_note_iterator *it);
# 107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_read(
 git_note **out,
 git_repository *repo,
 const char *notes_ref,
 const git_oid *oid);
# 126 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_commit_read(
 git_note **out,
 git_repository *repo,
 git_commit *notes_commit,
 const git_oid *oid);







extern __attribute__((visibility("default"))) const git_signature * git_note_author(const git_note *note);







extern __attribute__((visibility("default"))) const git_signature * git_note_committer(const git_note *note);
# 155 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) const char * git_note_message(const git_note *note);
# 164 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) const git_oid * git_note_id(const git_note *note);
# 181 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_create(
 git_oid *out,
 git_repository *repo,
 const char *notes_ref,
 const git_signature *author,
 const git_signature *committer,
 const git_oid *oid,
 const char *note,
 int force);
# 211 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_commit_create(
 git_oid *notes_commit_out,
 git_oid *notes_blob_out,
 git_repository *repo,
 git_commit *parent,
 const git_signature *author,
 const git_signature *committer,
 const git_oid *oid,
 const char *note,
 int allow_note_overwrite);
# 234 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_remove(
 git_repository *repo,
 const char *notes_ref,
 const git_signature *author,
 const git_signature *committer,
 const git_oid *oid);
# 259 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_commit_remove(
  git_oid *notes_commit_out,
  git_repository *repo,
  git_commit *notes_commit,
  const git_signature *author,
  const git_signature *committer,
  const git_oid *oid);






extern __attribute__((visibility("default"))) void git_note_free(git_note *note);
# 282 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_default_ref(git_buf *out, git_repository *repo);
# 300 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/notes.h"
extern __attribute__((visibility("default"))) int git_note_foreach(
 git_repository *repo,
 const char *notes_ref,
 git_note_foreach_cb note_cb,
 void *payload);
# 43 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2





# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h" 1
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
typedef struct git_patch git_patch;







extern __attribute__((visibility("default"))) git_repository * git_patch_owner(const git_patch *patch);
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_from_diff(
 git_patch **out, git_diff *diff, size_t idx);
# 78 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_from_blobs(
 git_patch **out,
 const git_blob *old_blob,
 const char *old_as_path,
 const git_blob *new_blob,
 const char *new_as_path,
 const git_diff_options *opts);
# 103 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_from_blob_and_buffer(
 git_patch **out,
 const git_blob *old_blob,
 const char *old_as_path,
 const void *buffer,
 size_t buffer_len,
 const char *buffer_as_path,
 const git_diff_options *opts);
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_from_buffers(
 git_patch **out,
 const void *old_buffer,
 size_t old_len,
 const char *old_as_path,
 const void *new_buffer,
 size_t new_len,
 const char *new_as_path,
 const git_diff_options *opts);






extern __attribute__((visibility("default"))) void git_patch_free(git_patch *patch);
# 154 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) const git_diff_delta * git_patch_get_delta(const git_patch *patch);







extern __attribute__((visibility("default"))) size_t git_patch_num_hunks(const git_patch *patch);
# 180 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_line_stats(
 size_t *total_context,
 size_t *total_additions,
 size_t *total_deletions,
 const git_patch *patch);
# 199 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_get_hunk(
 const git_diff_hunk **out,
 size_t *lines_in_hunk,
 git_patch *patch,
 size_t hunk_idx);
# 212 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_num_lines_in_hunk(
 const git_patch *patch,
 size_t hunk_idx);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_get_line_in_hunk(
 const git_diff_line **out,
 git_patch *patch,
 size_t hunk_idx,
 size_t line_of_hunk);
# 252 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) size_t git_patch_size(
 git_patch *patch,
 int include_context,
 int include_hunk_headers,
 int include_file_headers);
# 270 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_print(
 git_patch *patch,
 git_diff_line_cb print_cb,
 void *payload);
# 282 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/patch.h"
extern __attribute__((visibility("default"))) int git_patch_to_buf(
 git_buf *out,
 git_patch *patch);
# 49 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
typedef struct git_pathspec git_pathspec;




typedef struct git_pathspec_match_list git_pathspec_match_list;




typedef enum {
 GIT_PATHSPEC_DEFAULT = 0,





 GIT_PATHSPEC_IGNORE_CASE = (1u << 0),





 GIT_PATHSPEC_USE_CASE = (1u << 1),





 GIT_PATHSPEC_NO_GLOB = (1u << 2),







 GIT_PATHSPEC_NO_MATCH_ERROR = (1u << 3),






 GIT_PATHSPEC_FIND_FAILURES = (1u << 4),







 GIT_PATHSPEC_FAILURES_ONLY = (1u << 5)
} git_pathspec_flag_t;
# 89 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) int git_pathspec_new(
 git_pathspec **out, const git_strarray *pathspec);






extern __attribute__((visibility("default"))) void git_pathspec_free(git_pathspec *ps);
# 112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) int git_pathspec_matches_path(
 const git_pathspec *ps, uint32_t flags, const char *path);
# 137 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) int git_pathspec_match_workdir(
 git_pathspec_match_list **out,
 git_repository *repo,
 uint32_t flags,
 git_pathspec *ps);
# 166 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) int git_pathspec_match_index(
 git_pathspec_match_list **out,
 git_index *index,
 uint32_t flags,
 git_pathspec *ps);
# 190 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) int git_pathspec_match_tree(
 git_pathspec_match_list **out,
 git_tree *tree,
 uint32_t flags,
 git_pathspec *ps);
# 214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) int git_pathspec_match_diff(
 git_pathspec_match_list **out,
 git_diff *diff,
 uint32_t flags,
 git_pathspec *ps);






extern __attribute__((visibility("default"))) void git_pathspec_match_list_free(git_pathspec_match_list *m);







extern __attribute__((visibility("default"))) size_t git_pathspec_match_list_entrycount(
 const git_pathspec_match_list *m);
# 246 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) const char * git_pathspec_match_list_entry(
 const git_pathspec_match_list *m, size_t pos);
# 259 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) const git_diff_delta * git_pathspec_match_list_diff_entry(
 const git_pathspec_match_list *m, size_t pos);
# 271 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) size_t git_pathspec_match_list_failed_entrycount(
 const git_pathspec_match_list *m);
# 283 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/pathspec.h"
extern __attribute__((visibility("default"))) const char * git_pathspec_match_list_failed_entry(
 const git_pathspec_match_list *m, size_t pos);
# 50 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h" 1
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) int git_reflog_read(git_reflog **out, git_repository *repo, const char *name);
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) int git_reflog_write(git_reflog *reflog);
# 60 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) int git_reflog_append(git_reflog *reflog, const git_oid *id, const git_signature *committer, const char *msg);
# 75 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) int git_reflog_rename(git_repository *repo, const char *old_name, const char *name);
# 84 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) int git_reflog_delete(git_repository *repo, const char *name);







extern __attribute__((visibility("default"))) size_t git_reflog_entrycount(git_reflog *reflog);
# 105 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) const git_reflog_entry * git_reflog_entry_byindex(const git_reflog *reflog, size_t idx);
# 124 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reflog.h"
extern __attribute__((visibility("default"))) int git_reflog_drop(
 git_reflog *reflog,
 size_t idx,
 int rewrite_previous_entry);







extern __attribute__((visibility("default"))) const git_oid * git_reflog_entry_id_old(const git_reflog_entry *entry);







extern __attribute__((visibility("default"))) const git_oid * git_reflog_entry_id_new(const git_reflog_entry *entry);







extern __attribute__((visibility("default"))) const git_signature * git_reflog_entry_committer(const git_reflog_entry *entry);







extern __attribute__((visibility("default"))) const char * git_reflog_entry_message(const git_reflog_entry *entry);






extern __attribute__((visibility("default"))) void git_reflog_free(git_reflog *reflog);
# 54 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2




# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reset.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reset.h"
typedef enum {
 GIT_RESET_SOFT = 1,
 GIT_RESET_MIXED = 2,
 GIT_RESET_HARD = 3
} git_reset_t;
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reset.h"
extern __attribute__((visibility("default"))) int git_reset(
 git_repository *repo,
 const git_object *target,
 git_reset_t reset_type,
 const git_checkout_options *checkout_opts);
# 92 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reset.h"
extern __attribute__((visibility("default"))) int git_reset_from_annotated(
 git_repository *repo,
 const git_annotated_commit *target,
 git_reset_t reset_type,
 const git_checkout_options *checkout_opts);
# 116 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/reset.h"
extern __attribute__((visibility("default"))) int git_reset_default(
 git_repository *repo,
 const git_object *target,
 const git_strarray* pathspecs);
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
typedef enum {




 GIT_SORT_NONE = 0,






 GIT_SORT_TOPOLOGICAL = 1 << 0,






 GIT_SORT_TIME = 1 << 1,






 GIT_SORT_REVERSE = 1 << 2
} git_sort_t;
# 73 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_new(git_revwalk **out, git_repository *repo);
# 89 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_reset(git_revwalk *walker);
# 108 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_push(git_revwalk *walk, const git_oid *id);
# 126 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_push_glob(git_revwalk *walk, const char *glob);







extern __attribute__((visibility("default"))) int git_revwalk_push_head(git_revwalk *walk);
# 149 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_hide(git_revwalk *walk, const git_oid *commit_id);
# 168 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_hide_glob(git_revwalk *walk, const char *glob);







extern __attribute__((visibility("default"))) int git_revwalk_hide_head(git_revwalk *walk);
# 187 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_push_ref(git_revwalk *walk, const char *refname);
# 198 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_hide_ref(git_revwalk *walk, const char *refname);
# 218 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_next(git_oid *out, git_revwalk *walk);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_sorting(git_revwalk *walk, unsigned int sort_mode);
# 245 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_push_range(git_revwalk *walk, const char *range);
# 255 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_simplify_first_parent(git_revwalk *walk);







extern __attribute__((visibility("default"))) void git_revwalk_free(git_revwalk *walk);
# 272 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) git_repository * git_revwalk_repository(git_revwalk *walk);
# 283 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
typedef int (*git_revwalk_hide_cb)(
 const git_oid *commit_id,
 void *payload);
# 295 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/revwalk.h"
extern __attribute__((visibility("default"))) int git_revwalk_add_hide_cb(
 git_revwalk *walk,
 git_revwalk_hide_cb hide_cb,
 void *payload);
# 62 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h" 1
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) int git_signature_new(git_signature **out, const char *name, const char *email, git_time_t time, int offset);
# 53 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) int git_signature_now(git_signature **out, const char *name, const char *email);
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) int git_signature_default_from_env(
 git_signature **author_out,
 git_signature **committer_out,
 git_repository *repo);
# 107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) int git_signature_default(git_signature **out, git_repository *repo);
# 120 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) int git_signature_from_buffer(git_signature **out, const char *buf);
# 132 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) int git_signature_dup(git_signature **dest, const git_signature *sig);
# 143 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/signature.h"
extern __attribute__((visibility("default"))) void git_signature_free(git_signature *sig);
# 63 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2





# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h" 1
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_new(git_transaction **out, git_repository *repo);
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_lock_ref(git_transaction *tx, const char *refname);
# 59 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_set_target(git_transaction *tx, const char *refname, const git_oid *target, const git_signature *sig, const char *msg);
# 74 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_set_symbolic_target(git_transaction *tx, const char *refname, const char *target, const git_signature *sig, const char *msg);
# 87 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_set_reflog(git_transaction *tx, const char *refname, const git_reflog *reflog);
# 96 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_remove(git_transaction *tx, const char *refname);
# 107 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) int git_transaction_commit(git_transaction *tx);
# 117 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/transaction.h"
extern __attribute__((visibility("default"))) void git_transaction_free(git_transaction *tx);
# 69 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/version.h" 1
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/build/libgit2/include/git2.h" 2
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/config.h" 2
# 25 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/config.h"
struct git_config {
 git_refcount rc;
 git_vector readers;
 git_vector writers;
};

extern int git_config__global_location(git_str *buf);

extern int git_config__find_global(git_str *path);
extern int git_config__find_xdg(git_str *path);
extern int git_config__find_system(git_str *path);
extern int git_config__find_programdata(git_str *path);

extern int git_config_rename_section(
 git_repository *repo,
 const char *old_section_name,
 const char *new_section_name);

extern int git_config__normalize_name(const char *in, char **out);


extern int git_config__lookup_entry(
 git_config_entry **out,
 const git_config *cfg,
 const char *key,
 _Bool no_errors);


extern int git_config__update_entry(
 git_config *cfg,
 const char *key,
 const char *value,
 _Bool overwrite_existing,
 _Bool only_if_existing);

int git_config__get_path(
 git_str *out,
 const git_config *cfg,
 const char *name);

int git_config__get_string_buf(
 git_str *out, const git_config *cfg, const char *name);







extern char *git_config__get_string_force(
 const git_config *cfg, const char *key, const char *fallback_value);

extern int git_config__get_bool_force(
 const git_config *cfg, const char *key, int fallback_value);

extern int git_config__get_int_force(
 const git_config *cfg, const char *key, int fallback_value);




extern int git_config__configmap_lookup(
 int *out, git_config *config, git_configmap_item item);





int git_config_lookup_map_enum(git_configmap_t *type_out,
 const char **str_out, const git_configmap *maps,
 size_t map_n, int enum_val);
# 110 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/config.h"
extern __attribute__((visibility("default"))) int git_config_unlock(
 git_config *config,
 void *data,
 int commit);
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refdb.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refdb.h"
struct git_refdb {
 git_refcount rc;
 git_repository *repo;
 git_refdb_backend *backend;
};

void git_refdb__free(git_refdb *db);

int git_refdb_exists(
 int *exists,
 git_refdb *refdb,
 const char *ref_name);

int git_refdb_lookup(
 git_reference **out,
 git_refdb *refdb,
 const char *ref_name);
# 52 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refdb.h"
int git_refdb_resolve(
 git_reference **out,
 git_refdb *db,
 const char *ref_name,
 int max_nesting);

int git_refdb_rename(
 git_reference **out,
 git_refdb *db,
 const char *old_name,
 const char *new_name,
 int force,
 const git_signature *who,
 const char *message);

int git_refdb_iterator(git_reference_iterator **out, git_refdb *db, const char *glob);
int git_refdb_iterator_next(git_reference **out, git_reference_iterator *iter);
int git_refdb_iterator_next_name(const char **out, git_reference_iterator *iter);
void git_refdb_iterator_free(git_reference_iterator *iter);

int git_refdb_write(git_refdb *refdb, git_reference *ref, int force, const git_signature *who, const char *message, const git_oid *old_id, const char *old_target);
int git_refdb_delete(git_refdb *refdb, const char *ref_name, const git_oid *old_id, const char *old_target);

int git_refdb_reflog_read(git_reflog **out, git_refdb *db, const char *name);
int git_refdb_reflog_write(git_reflog *reflog);
# 104 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refdb.h"
int git_refdb_should_write_reflog(int *out, git_refdb *db, const git_reference *ref);
# 120 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refdb.h"
int git_refdb_should_write_head_reflog(int *out, git_refdb *db, const git_reference *ref);

int git_refdb_has_log(git_refdb *db, const char *refname);
int git_refdb_ensure_log(git_refdb *refdb, const char *refname);

int git_refdb_lock(void **payload, git_refdb *db, const char *refname);
int git_refdb_unlock(git_refdb *db, void *payload, int success, int update_reflog, const git_reference *ref, const git_signature *sig, const char *message);
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/remote.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/remote.h"
typedef enum {

 GIT_REMOTE_CAPABILITY_TIP_OID = (1 << 0),


 GIT_REMOTE_CAPABILITY_REACHABLE_OID = (1 << 1),


 GIT_REMOTE_CAPABILITY_PUSH_OPTIONS = (1 << 2),
} git_remote_capability_t;
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/remote.h"
extern __attribute__((visibility("default"))) void git_remote_connect_options_dispose(
  git_remote_connect_options *opts);
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h" 1
# 35 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
typedef struct {
 const git_remote_head * const *refs;
 size_t refs_len;
 git_oid *shallow_roots;
 size_t shallow_roots_len;
 int depth;
} git_fetch_negotiation;

struct git_transport {
 unsigned int version;





 int (*connect)(
  git_transport *transport,
  const char *url,
  int direction,
  const git_remote_connect_options *connect_opts);






 int (*set_connect_opts)(
  git_transport *transport,
  const git_remote_connect_options *connect_opts);







 int (*capabilities)(
  unsigned int *capabilities,
  git_transport *transport);
# 94 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
 int (*ls)(
  const git_remote_head ***out,
  size_t *size,
  git_transport *transport);


 int (*push)(
  git_transport *transport,
  git_push *push);
# 111 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
 int (*negotiate_fetch)(
  git_transport *transport,
  git_repository *repo,
  const git_fetch_negotiation *fetch_data);







 int (*shallow_roots)(
  git_oidarray *out,
  git_transport *transport);







 int (*download_pack)(
  git_transport *transport,
  git_repository *repo,
  git_indexer_progress *stats);


 int (*is_connected)(git_transport *transport);


 void (*cancel)(git_transport *transport);







 int (*close)(git_transport *transport);


 void (*free)(git_transport *transport);
};
# 169 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_init(
 git_transport *opts,
 unsigned int version);
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_new(git_transport **out, git_remote *owner, const char *url);
# 199 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_ssh_with_paths(git_transport **out, git_remote *owner, void *payload);
# 214 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_register(
 const char *prefix,
 git_transport_cb cb,
 void *param);
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_unregister(
 const char *prefix);
# 244 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_dummy(
 git_transport **out,
 git_remote *owner,
            void *payload);
# 257 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_local(
 git_transport **out,
 git_remote *owner,
            void *payload);
# 270 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_smart(
 git_transport **out,
 git_remote *owner,
                                             void *payload);
# 287 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_smart_certificate_check(git_transport *transport, git_cert *cert, int valid, const char *hostname);
# 301 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_smart_credentials(git_credential **out, git_transport *transport, const char *user, int methods);
# 313 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_transport_remote_connect_options(
  git_remote_connect_options *out,
  git_transport *transport);







typedef enum {
 GIT_SERVICE_UPLOADPACK_LS = 1,
 GIT_SERVICE_UPLOADPACK = 2,
 GIT_SERVICE_RECEIVEPACK_LS = 3,
 GIT_SERVICE_RECEIVEPACK = 4
} git_smart_service_t;

typedef struct git_smart_subtransport git_smart_subtransport;
typedef struct git_smart_subtransport_stream git_smart_subtransport_stream;
# 340 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
struct git_smart_subtransport_stream {
 git_smart_subtransport *subtransport;






 int (*read)(
  git_smart_subtransport_stream *stream,
  char *buffer,
  size_t buf_size,
  size_t *bytes_read);






 int (*write)(
  git_smart_subtransport_stream *stream,
  const char *buffer,
  size_t len);


 void (*free)(
  git_smart_subtransport_stream *stream);
};





struct git_smart_subtransport {



 int (*action)(
   git_smart_subtransport_stream **out,
   git_smart_subtransport *transport,
   const char *url,
   git_smart_service_t action);
# 393 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
 int (*close)(git_smart_subtransport *transport);


 void (*free)(git_smart_subtransport *transport);
};
# 407 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
typedef int (*git_smart_subtransport_cb)(
 git_smart_subtransport **out,
 git_transport *owner,
 void *param);
# 426 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
typedef struct git_smart_subtransport_definition {

 git_smart_subtransport_cb callback;





 unsigned rpc;


 void *param;
} git_smart_subtransport_definition;
# 452 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_smart_subtransport_http(
 git_smart_subtransport **out,
 git_transport *owner,
 void *param);
# 465 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_smart_subtransport_git(
 git_smart_subtransport **out,
 git_transport *owner,
 void *param);
# 478 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/transport.h"
extern __attribute__((visibility("default"))) int git_smart_subtransport_ssh(
 git_smart_subtransport **out,
 git_transport *owner,
 void *param);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refspec.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/refspec.h"
struct git_refspec {
 char *string;
 char *src;
 char *dst;
 unsigned int force :1,
  push : 1,
  pattern :1,
  matching :1;
};



int git_refspec__transform(git_str *out, const git_refspec *spec, const char *name);
int git_refspec__rtransform(git_str *out, const git_refspec *spec, const char *name);

int git_refspec__parse(
 struct git_refspec *refspec,
 const char *str,
 _Bool is_fetch);

void git_refspec__dispose(git_refspec *refspec);

int git_refspec__serialize(git_str *out, const git_refspec *refspec);







int git_refspec_is_wildcard(const git_refspec *spec);







int git_refspec_is_negative(const git_refspec *spec);





int git_refspec__dwim_one(git_vector *out, git_refspec *spec, git_vector *refs);
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/net.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/util/net.h"
extern _Bool git_net_hostname_matches_cert(
 const char *hostname,
 const char *pattern);





typedef struct git_net_url {
 char *scheme;
 char *host;
 char *port;
 char *path;
 char *query;
 char *fragment;
 char *username;
 char *password;

 unsigned int port_specified;
} git_net_url;




extern _Bool git_net_str_is_url(const char *str);


extern int git_net_url_dup(git_net_url *out, git_net_url *in);


extern int git_net_url_parse(git_net_url *url, const char *str);


extern int git_net_url_parse_scp(git_net_url *url, const char *str);





extern int git_net_url_parse_standard_or_scp(git_net_url *url, const char *str);





extern int git_net_url_parse_http(
 git_net_url *url,
 const char *str);


extern int git_net_url_joinpath(
 git_net_url *out,
 git_net_url *in,
 const char *path);


extern _Bool git_net_url_valid(git_net_url *url);


extern _Bool git_net_url_is_default_port(git_net_url *url);


extern _Bool git_net_url_is_ipv6(git_net_url *url);


extern int git_net_url_apply_redirect(
 git_net_url *url,
 const char *redirect_location,
 _Bool allow_offsite,
 const char *service_suffix);


extern void git_net_url_swap(git_net_url *a, git_net_url *b);


extern int git_net_url_fmt(git_str *out, git_net_url *url);


extern int git_net_url_fmt_path(git_str *buf, git_net_url *url);


extern _Bool git_net_url_matches_pattern(
 git_net_url *url,
 const char *pattern);
extern _Bool git_net_url_matches_pattern_list(
 git_net_url *url,
 const char *pattern_list);


extern void git_net_url_dispose(git_net_url *url);
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/proxy.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/proxy.h"
extern int git_proxy_options_dup(git_proxy_options *tgt, const git_proxy_options *src);
extern void git_proxy_options_dispose(git_proxy_options *opts);
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h" 2



struct git_remote {
 char *name;
 char *url;
 char *pushurl;
 git_vector refs;
 git_vector refspecs;
 git_vector active_refspecs;
 git_vector passive_refspecs;
 git_vector local_heads;
 git_transport *transport;
 git_repository *repo;
 git_push *push;
 git_indexer_progress stats;
 unsigned int need_pack;
 git_remote_autotag_option_t download_tags;
 int prune_refs;
 int passed_refspecs;
 git_fetch_negotiation nego;
};

int git_remote__urlfordirection(git_str *url_out, struct git_remote *remote, int direction, const git_remote_callbacks *callbacks);
int git_remote__http_proxy(char **out, git_remote *remote, git_net_url *url);

git_refspec *git_remote__matching_refspec(git_remote *remote, const char *refname);
git_refspec *git_remote__matching_dst_refspec(git_remote *remote, const char *refname);

int git_remote__default_branch(git_str *out, git_remote *remote);

int git_remote_connect_options_dup(
 git_remote_connect_options *dst,
 const git_remote_connect_options *src);
int git_remote_connect_options_normalize(
 git_remote_connect_options *dst,
 git_repository *repo,
 const git_remote_connect_options *src);

int git_remote_capabilities(unsigned int *out, git_remote *remote);
int git_remote_oid_type(git_oid_t *out, git_remote *remote);
# 72 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/remote.h"
static __inline__ int git_remote_connect_options__from_fetch_opts(
 git_remote_connect_options *out,
 git_remote *remote,
 const git_fetch_options *fetch_opts)
{
 git_remote_connect_options tmp = { 1, {1}, {1} };
 if (fetch_opts) { (&tmp)->callbacks = (fetch_opts)->callbacks; (&tmp)->proxy_opts = (fetch_opts)->proxy_opts; (&tmp)->custom_headers = (fetch_opts)->custom_headers; (&tmp)->follow_redirects = (fetch_opts)->follow_redirects; };
 return git_remote_connect_options_normalize(out, remote->repo, &tmp);
}

static __inline__ int git_remote_connect_options__from_push_opts(
 git_remote_connect_options *out,
 git_remote *remote,
 const git_push_options *push_opts)
{
 git_remote_connect_options tmp = { 1, {1}, {1} };
 if (push_opts) { (&tmp)->callbacks = (push_opts)->callbacks; (&tmp)->proxy_opts = (push_opts)->proxy_opts; (&tmp)->custom_headers = (push_opts)->custom_headers; (&tmp)->follow_redirects = (push_opts)->follow_redirects; };
 return git_remote_connect_options_normalize(out, remote->repo, &tmp);
}



static __inline__ void git_remote_connect_options__dispose(
 git_remote_connect_options *opts)
{
 git_proxy_options_dispose(&opts->proxy_opts);
 git_strarray_dispose(&opts->custom_headers);
}
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/merge.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/merge.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit_list.h" 1
# 26 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/commit_list.h"
typedef struct git_commit_list_node {
 git_oid oid;
 int64_t time;
 uint32_t generation;
 unsigned int seen:1,
    uninteresting:1,
    topo_delay:1,
    parsed:1,
    added:1,
    flags : 4;

 uint16_t in_degree;
 uint16_t out_degree;

 struct git_commit_list_node **parents;
} git_commit_list_node;

typedef struct git_commit_list {
 git_commit_list_node *item;
 struct git_commit_list *next;
} git_commit_list;

git_commit_list_node *git_commit_list_alloc_node(git_revwalk *walk);
int git_commit_list_generation_cmp(const void *a, const void *b);
int git_commit_list_time_cmp(const void *a, const void *b);
void git_commit_list_free(git_commit_list **list_p);
git_commit_list *git_commit_list_create(git_commit_list_node *item, git_commit_list *next);
git_commit_list *git_commit_list_insert(git_commit_list_node *item, git_commit_list **list_p);
git_commit_list *git_commit_list_insert_by_date(git_commit_list_node *item, git_commit_list **list_p);
int git_commit_list_parse(git_revwalk *walk, git_commit_list_node *commit);
git_commit_list_node *git_commit_list_pop(git_commit_list **stack);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/merge.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/ignore.h" 1
# 27 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/ignore.h"
typedef struct {
 git_repository *repo;
 git_str dir;
 git_attr_file *ign_internal;
 git_vector ign_path;
 git_vector ign_global;
 size_t dir_root;
 int ignore_case;
 int depth;
} git_ignores;

extern int git_ignore__for_path(
 git_repository *repo, const char *path, git_ignores *ign);

extern int git_ignore__push_dir(git_ignores *ign, const char *dir);

extern int git_ignore__pop_dir(git_ignores *ign);

extern void git_ignore__free(git_ignores *ign);

enum {
 GIT_IGNORE_UNCHECKED = -2,
 GIT_IGNORE_NOTFOUND = -1,
 GIT_IGNORE_FALSE = 0,
 GIT_IGNORE_TRUE = 1
};

extern int git_ignore__lookup(int *out, git_ignores *ign, const char *path, git_dir_flag dir_flag);







extern int git_ignore__check_pathspec_for_exact_ignores(
 git_repository *repo, git_vector *pathspec, _Bool no_fnmatch);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h" 2

typedef struct git_iterator git_iterator;

typedef enum {
 GIT_ITERATOR_EMPTY = 0,
 GIT_ITERATOR_TREE = 1,
 GIT_ITERATOR_INDEX = 2,
 GIT_ITERATOR_WORKDIR = 3,
 GIT_ITERATOR_FS = 4
} git_iterator_t;

typedef enum {

 GIT_ITERATOR_IGNORE_CASE = (1u << 0),

 GIT_ITERATOR_DONT_IGNORE_CASE = (1u << 1),

 GIT_ITERATOR_INCLUDE_TREES = (1u << 2),

 GIT_ITERATOR_DONT_AUTOEXPAND = (1u << 3),

 GIT_ITERATOR_PRECOMPOSE_UNICODE = (1u << 4),

 GIT_ITERATOR_DONT_PRECOMPOSE_UNICODE = (1u << 5),

 GIT_ITERATOR_INCLUDE_CONFLICTS = (1u << 6),

 GIT_ITERATOR_DESCEND_SYMLINKS = (1u << 7),

 GIT_ITERATOR_INCLUDE_HASH = (1u << 8)
} git_iterator_flag_t;

typedef enum {
 GIT_ITERATOR_STATUS_NORMAL = 0,
 GIT_ITERATOR_STATUS_IGNORED = 1,
 GIT_ITERATOR_STATUS_EMPTY = 2,
 GIT_ITERATOR_STATUS_FILTERED = 3
} git_iterator_status_t;

typedef struct {
 const char *start;
 const char *end;




 git_strarray pathlist;


 unsigned int flags;


 git_oid_t oid_type;
} git_iterator_options;



typedef struct {
 int (*current)(const git_index_entry **, git_iterator *);
 int (*advance)(const git_index_entry **, git_iterator *);
 int (*advance_into)(const git_index_entry **, git_iterator *);
 int (*advance_over)(
  const git_index_entry **, git_iterator_status_t *, git_iterator *);
 int (*reset)(git_iterator *);
 void (*free)(git_iterator *);
} git_iterator_callbacks;

struct git_iterator {
 git_iterator_t type;
 git_iterator_callbacks *cb;

 git_repository *repo;
 git_index *index;

 char *start;
 size_t start_len;

 char *end;
 size_t end_len;

 _Bool started;
 _Bool ended;
 git_vector pathlist;
 size_t pathlist_walk_idx;
 int (*strcomp)(const char *a, const char *b);
 int (*strncomp)(const char *a, const char *b, size_t n);
 int (*prefixcomp)(const char *str, const char *prefix);
 int (*entry_srch)(const void *key, const void *array_member);
 size_t stat_calls;
 unsigned int flags;
};

extern int git_iterator_for_nothing(
 git_iterator **out,
 git_iterator_options *options);




extern int git_iterator_for_tree(
 git_iterator **out,
 git_tree *tree,
 git_iterator_options *options);




extern int git_iterator_for_index(
 git_iterator **out,
 git_repository *repo,
 git_index *index,
 git_iterator_options *options);

extern int git_iterator_for_workdir_ext(
 git_iterator **out,
 git_repository *repo,
 const char *repo_workdir,
 git_index *index,
 git_tree *tree,
 git_iterator_options *options);




static __inline__ int git_iterator_for_workdir(
 git_iterator **out,
 git_repository *repo,
 git_index *index,
 git_tree *tree,
 git_iterator_options *options)
{
 return git_iterator_for_workdir_ext(out, repo, ((void*)0), index, tree, options);
}




extern int git_iterator_for_filesystem(
 git_iterator **out,
 const char *root,
 git_iterator_options *options);

extern void git_iterator_free(git_iterator *iter);
# 171 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h"
static __inline__ int git_iterator_current(
 const git_index_entry **entry, git_iterator *iter)
{
 return iter->cb->current(entry, iter);
}
# 184 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h"
static __inline__ int git_iterator_advance(
 const git_index_entry **entry, git_iterator *iter)
{
 return iter->cb->advance(entry, iter);
}
# 205 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h"
static __inline__ int git_iterator_advance_into(
 const git_index_entry **entry, git_iterator *iter)
{
 return iter->cb->advance_into(entry, iter);
}
# 221 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/iterator.h"
static __inline__ int git_iterator_advance_over(
 const git_index_entry **entry,
 git_iterator_status_t *status,
 git_iterator *iter)
{
 return iter->cb->advance_over(entry, status, iter);
}




static __inline__ int git_iterator_reset(git_iterator *iter)
{
 return iter->cb->reset(iter);
}





extern int git_iterator_reset_range(
 git_iterator *iter, const char *start, const char *end);

static __inline__ git_iterator_t git_iterator_type(git_iterator *iter)
{
 return iter->type;
}

static __inline__ git_repository * git_iterator_owner(git_iterator *iter)
{
 return iter->repo;
}

static __inline__ git_index * git_iterator_index(git_iterator *iter)
{
 return iter->index;
}

static __inline__ git_iterator_flag_t git_iterator_flags(git_iterator *iter)
{
 return iter->flags;
}

static __inline__ _Bool git_iterator_ignore_case(git_iterator *iter)
{
 return ((iter->flags & GIT_ITERATOR_IGNORE_CASE) != 0);
}

extern int git_iterator_set_ignore_case(
 git_iterator *iter, _Bool ignore_case);

extern int git_iterator_current_tree_entry(
 const git_tree_entry **entry_out, git_iterator *iter);

extern int git_iterator_current_parent_tree(
 const git_tree **tree_out, git_iterator *iter, size_t depth);

extern _Bool git_iterator_current_is_ignored(git_iterator *iter);

extern _Bool git_iterator_current_tree_is_ignored(git_iterator *iter);






extern int git_iterator_current_workdir_path(
 git_str **path, git_iterator *iter);






extern git_index *git_iterator_index(git_iterator *iter);

typedef int (*git_iterator_foreach_cb)(
 const git_index_entry *entry,
 void *data);





extern int git_iterator_foreach(
 git_iterator *iterator,
 git_iterator_foreach_cb cb,
 void *data);

typedef int (*git_iterator_walk_cb)(
 const git_index_entry **entries,
 void *data);






extern int git_iterator_walk(
 git_iterator **iterators,
 size_t cnt,
 git_iterator_walk_cb cb,
 void *data);
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/merge.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h" 1
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
typedef struct git_merge_driver git_merge_driver;







extern __attribute__((visibility("default"))) git_merge_driver * git_merge_driver_lookup(const char *name);
# 49 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
typedef struct git_merge_driver_source git_merge_driver_source;







extern __attribute__((visibility("default"))) git_repository * git_merge_driver_source_repo(
 const git_merge_driver_source *src);







extern __attribute__((visibility("default"))) const git_index_entry * git_merge_driver_source_ancestor(
 const git_merge_driver_source *src);







extern __attribute__((visibility("default"))) const git_index_entry * git_merge_driver_source_ours(
 const git_merge_driver_source *src);







extern __attribute__((visibility("default"))) const git_index_entry * git_merge_driver_source_theirs(
 const git_merge_driver_source *src);







extern __attribute__((visibility("default"))) const git_merge_file_options * git_merge_driver_source_file_options(
 const git_merge_driver_source *src);
# 112 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
typedef int (*git_merge_driver_init_fn)(git_merge_driver *self);
# 126 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
typedef void (*git_merge_driver_shutdown_fn)(git_merge_driver *self);
# 154 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
typedef int (*git_merge_driver_apply_fn)(
 git_merge_driver *self,
 const char **path_out,
 uint32_t *mode_out,
 git_buf *merged_out,
 const char *filter_name,
 const git_merge_driver_source *src);
# 169 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
struct git_merge_driver {

 unsigned int version;


 git_merge_driver_init_fn initialize;


 git_merge_driver_shutdown_fn shutdown;







 git_merge_driver_apply_fn apply;
};
# 209 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
extern __attribute__((visibility("default"))) int git_merge_driver_register(
 const char *name, git_merge_driver *driver);
# 225 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/merge.h"
extern __attribute__((visibility("default"))) int git_merge_driver_unregister(const char *name);
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/merge.h" 2
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/merge.h"
typedef enum {

 GIT_MERGE_DIFF_NONE = 0,


 GIT_MERGE_DIFF_BOTH_MODIFIED = (1 << 0),


 GIT_MERGE_DIFF_BOTH_ADDED = (1 << 1),


 GIT_MERGE_DIFF_BOTH_DELETED = (1 << 2),


 GIT_MERGE_DIFF_MODIFIED_DELETED = (1 << 3),


 GIT_MERGE_DIFF_RENAMED_MODIFIED = (1 << 4),


 GIT_MERGE_DIFF_RENAMED_DELETED = (1 << 5),




 GIT_MERGE_DIFF_RENAMED_ADDED = (1 << 6),



 GIT_MERGE_DIFF_BOTH_RENAMED = (1 << 7),



 GIT_MERGE_DIFF_BOTH_RENAMED_1_TO_2 = (1 << 8),



 GIT_MERGE_DIFF_BOTH_RENAMED_2_TO_1 = (1 << 9),



 GIT_MERGE_DIFF_DIRECTORY_FILE = (1 << 10),


 GIT_MERGE_DIFF_DF_CHILD = (1 << 11)
} git_merge_diff_t;

typedef struct {
 git_repository *repo;
 git_pool pool;






 git_vector staged;





 git_vector conflicts;




 git_vector resolved;
} git_merge_diff_list;




typedef struct {
 git_merge_diff_t type;

 git_index_entry ancestor_entry;

 git_index_entry our_entry;
 git_delta_t our_status;

 git_index_entry their_entry;
 git_delta_t their_status;

} git_merge_diff;

int git_merge__bases_many(
 git_commit_list **out,
 git_revwalk *walk,
 git_commit_list_node *one,
 git_vector *twos,
 uint32_t minimum_generation);





git_merge_diff_list *git_merge_diff_list__alloc(git_repository *repo);

int git_merge_diff_list__find_differences(
 git_merge_diff_list *merge_diff_list,
 git_iterator *ancestor_iterator,
 git_iterator *ours_iter,
 git_iterator *theirs_iter);

int git_merge_diff_list__find_renames(git_repository *repo, git_merge_diff_list *merge_diff_list, const git_merge_options *opts);

void git_merge_diff_list__free(git_merge_diff_list *diff_list);



int git_merge__setup(
 git_repository *repo,
 const git_annotated_commit *our_head,
 const git_annotated_commit *heads[],
 size_t heads_len);

int git_merge__iterators(
 git_index **out,
 git_repository *repo,
 git_iterator *ancestor_iter,
 git_iterator *our_iter,
 git_iterator *their_iter,
 const git_merge_options *given_opts);

int git_merge__check_result(git_repository *repo, git_index *index_new);

int git_merge__append_conflicts_to_merge_msg(git_repository *repo, git_index *index);



static __inline__ const char * git_merge_file__best_path(
 const char *ancestor,
 const char *ours,
 const char *theirs)
{
 if (!ancestor) {
  if (ours && theirs && strcmp(ours, theirs) == 0)
   return ours;

  return ((void*)0);
 }

 if (ours && strcmp(ancestor, ours) == 0)
  return theirs;
 else if(theirs && strcmp(ancestor, theirs) == 0)
  return ours;

 return ((void*)0);
}

static __inline__ uint32_t git_merge_file__best_mode(
 uint32_t ancestor, uint32_t ours, uint32_t theirs)
{





 if (!ancestor) {
  if (ours == GIT_FILEMODE_BLOB_EXECUTABLE ||
   theirs == GIT_FILEMODE_BLOB_EXECUTABLE)
   return GIT_FILEMODE_BLOB_EXECUTABLE;

  return GIT_FILEMODE_BLOB;
 } else if (ours && theirs) {
  if (ancestor == ours)
   return theirs;

  return ours;
 }

 return 0;
}
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/annotated_commit.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/annotated_commit.h"
typedef enum {
 GIT_ANNOTATED_COMMIT_REAL = 1,
 GIT_ANNOTATED_COMMIT_VIRTUAL = 2
} git_annotated_commit_t;







struct git_annotated_commit {
 git_annotated_commit_t type;


 git_commit *commit;
 git_tree *tree;


 git_index *index;
 git_array_oid_t parents;


 const char *description;

 const char *ref_name;
 const char *remote_url;

 char id_str[(20 * 2) + 1];
};

extern int git_annotated_commit_from_head(git_annotated_commit **out,
 git_repository *repo);
extern int git_annotated_commit_from_commit(git_annotated_commit **out,
 git_commit *commit);
# 34 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/worktree.h" 1
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/worktree.h"
struct git_worktree {



 char *name;


 char *worktree_path;

 char *gitlink_path;


 char *gitdir_path;


 char *commondir_path;

 char *parent_path;

 unsigned int locked:1;
};

char *git_worktree__read_link(const char *base, const char *file);
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/path.h" 1
# 13 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/path.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/path.h" 1
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/path.h"
typedef enum {

 GIT_PATH_GITFILE_GITIGNORE,

 GIT_PATH_GITFILE_GITMODULES,

 GIT_PATH_GITFILE_GITATTRIBUTES
} git_path_gitfile;





typedef enum {

 GIT_PATH_FS_GENERIC,

 GIT_PATH_FS_NTFS,

 GIT_PATH_FS_HFS
} git_path_fs;
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/include/git2/sys/path.h"
extern __attribute__((visibility("default"))) int git_path_is_gitfile(const char *path, size_t pathlen, git_path_gitfile gitfile, git_path_fs fs);
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/path.h" 2
# 28 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/path.h"
extern _Bool git_path_str_is_valid(
 git_repository *repo,
 const git_str *path,
 uint16_t file_mode,
 unsigned int flags);

static __inline__ _Bool git_path_is_valid(
 git_repository *repo,
 const char *path,
 uint16_t file_mode,
 unsigned int flags)
{
 git_str str = { (char *)(path), 0, (size_t)((18446744073709551615UL)) };
 return git_path_str_is_valid(repo, &str, file_mode, flags);
}

static __inline__ int git_path_validate_str_length(
 git_repository *repo,
 const git_str *path)
{
 if (!git_path_str_is_valid(repo, path, 0, (1 << 9))) {
  if (path->size == (18446744073709551615UL))
   git_error_set(GIT_ERROR_FILESYSTEM, "path too long: '%s'", path->ptr);
  else
   git_error_set(GIT_ERROR_FILESYSTEM, "path too long: '%.*s'", (int)path->size, path->ptr);

  return -1;
 }

 return 0;
}

static __inline__ int git_path_validate_length(
 git_repository *repo,
 const char *path)
{
 git_str str = { (char *)(path), 0, (size_t)((18446744073709551615UL)) };
 return git_path_validate_str_length(repo, &str);
}
# 37 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2





_Bool git_repository__validate_ownership = 1;
_Bool git_repository__fsync_gitdir = 0;

static const struct {
    git_repository_item_t parent;
 git_repository_item_t fallback;
    const char *name;
    _Bool directory;
} items[] = {
 { GIT_REPOSITORY_ITEM_GITDIR, GIT_REPOSITORY_ITEM__LAST, ((void*)0), 1 },
 { GIT_REPOSITORY_ITEM_WORKDIR, GIT_REPOSITORY_ITEM__LAST, ((void*)0), 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM__LAST, ((void*)0), 1 },
 { GIT_REPOSITORY_ITEM_GITDIR, GIT_REPOSITORY_ITEM__LAST, "index", 0 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "objects", 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "refs", 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "packed-refs", 0 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "remotes", 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "config", 0 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "info", 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "hooks", 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "logs", 1 },
 { GIT_REPOSITORY_ITEM_GITDIR, GIT_REPOSITORY_ITEM__LAST, "modules", 1 },
 { GIT_REPOSITORY_ITEM_COMMONDIR, GIT_REPOSITORY_ITEM_GITDIR, "worktrees", 1 },
 { GIT_REPOSITORY_ITEM_GITDIR, GIT_REPOSITORY_ITEM_GITDIR, "config.worktree", 0 }
};

static int check_repositoryformatversion(int *version, git_config *config);
static int check_extensions(git_config *config, int version);
static int load_global_config(git_config **config, _Bool use_env);
static int load_objectformat(git_repository *repo, git_config *config);
# 83 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
git_str git_repository__reserved_names_win32[] = {
 { ".git", 0, ((sizeof(".git")/sizeof(".git"[0])) - 1) },
 { "GIT~1", 0, ((sizeof("GIT~1")/sizeof("GIT~1"[0])) - 1) }
};
size_t git_repository__reserved_names_win32_len = 2;

git_str git_repository__reserved_names_posix[] = {
 { ".git", 0, ((sizeof(".git")/sizeof(".git"[0])) - 1) },
};
size_t git_repository__reserved_names_posix_len = 1;

static void set_odb(git_repository *repo, git_odb *odb)
{
 if (odb) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((odb)->rc.owner), repo); };
  { git_atomic32_inc(&(odb)->rc.refcount); };
 }

 if ((odb = (void *)git_atomic__swap((void * volatile *)&(repo->_odb), odb)) != ((void*)0)) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((odb)->rc.owner), ((void*)0)); };
  git_odb_free(odb);
 }
}

static void set_refdb(git_repository *repo, git_refdb *refdb)
{
 if (refdb) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((refdb)->rc.owner), repo); };
  { git_atomic32_inc(&(refdb)->rc.refcount); };
 }

 if ((refdb = (void *)git_atomic__swap((void * volatile *)&(repo->_refdb), refdb)) != ((void*)0)) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((refdb)->rc.owner), ((void*)0)); };
  git_refdb_free(refdb);
 }
}

static void set_config(git_repository *repo, git_config *config)
{
 if (config) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((config)->rc.owner), repo); };
  { git_atomic32_inc(&(config)->rc.refcount); };
 }

 if ((config = (void *)git_atomic__swap((void * volatile *)&(repo->_config), config)) != ((void*)0)) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((config)->rc.owner), ((void*)0)); };
  git_config_free(config);
 }

 git_repository__configmap_lookup_cache_clear(repo);
}

static void set_index(git_repository *repo, git_index *index)
{
 if (index) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((index)->rc.owner), repo); };
  { git_atomic32_inc(&(index)->rc.refcount); };
 }

 if ((index = (void *)git_atomic__swap((void * volatile *)&(repo->_index), index)) != ((void*)0)) {
  { (void)(void *)git_atomic__swap((void * volatile *)&((index)->rc.owner), ((void*)0)); };
  git_index_free(index);
 }
}

int git_repository__cleanup(git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 git_repository_submodule_cache_clear(repo);
 git_cache_clear(&repo->objects);
 git_attr_cache_flush(repo);
 git_grafts_free(repo->grafts);
 repo->grafts = ((void*)0);
 git_grafts_free(repo->shallow_grafts);
 repo->shallow_grafts = ((void*)0);

 set_config(repo, ((void*)0));
 set_index(repo, ((void*)0));
 set_odb(repo, ((void*)0));
 set_refdb(repo, ((void*)0));

 return 0;
}

void git_repository_free(git_repository *repo)
{
 size_t i;

 if (repo == ((void*)0))
  return;

 git_repository__cleanup(repo);

 git_cache_dispose(&repo->objects);

 git_diff_driver_registry_free(repo->diff_drivers);
 repo->diff_drivers = ((void*)0);

 for (i = 0; i < repo->reserved_names.size; i++)
  git_str_dispose((((i) < (repo->reserved_names).size) ? &(repo->reserved_names).ptr[(i)] : (void *)((void*)0)));
 do { git__free((repo->reserved_names).ptr); do { (repo->reserved_names).size = (repo->reserved_names).asize = 0; (repo->reserved_names).ptr = ((void*)0); } while (0); } while (0);

 git__free(repo->gitlink);
 git__free(repo->gitdir);
 git__free(repo->commondir);
 git__free(repo->workdir);
 git__free(repo->namespace);
 git__free(repo->ident_name);
 git__free(repo->ident_email);

 git__memzero(repo, sizeof(*repo));
 git__free(repo);
}


static int lookup_commondir(
 _Bool *separate,
 git_str *commondir,
 git_str *repository_path,
 uint32_t flags)
{
 git_str common_link = { git_str__initstr, 0, 0 };
 int error;


 if ((flags & GIT_REPOSITORY_OPEN_FROM_ENV)) {
  error = git__getenv(commondir, "GIT_COMMON_DIR");

  if (!error || error != GIT_ENOTFOUND)
   goto done;
 }





 if (!git_fs_path_contains_file(repository_path, "commondir")) {
  if ((error = git_str_set(commondir, repository_path->ptr, repository_path->size)) == 0)
      error = git_fs_path_to_dir(commondir);

  *separate = 0;
  goto done;
 }

 *separate = 1;

 if ((error = git_str_joinpath(&common_link, repository_path->ptr, "commondir")) < 0 ||
     (error = git_futils_readbuffer(&common_link, common_link.ptr)) < 0)
  goto done;

 git_str_rtrim(&common_link);
 if (git_fs_path_is_relative(common_link.ptr)) {
  if ((error = git_str_joinpath(commondir, repository_path->ptr, common_link.ptr)) < 0)
   goto done;
 } else {
  git_str_swap(commondir, &common_link);
 }


 error = git_fs_path_prettify_dir(commondir, commondir->ptr, ((void*)0));

done:
 git_str_dispose(&common_link);
 return error;
}

static __inline__ int validate_repo_path(git_str *path)
{






 static size_t suffix_len =
  ((sizeof("objects/pack/pack-.pack.lock")/sizeof("objects/pack/pack-.pack.lock"[0])) - 1) +
  (20 * 2);

 return git_fs_path_validate_str_length_with_suffix(
  path, suffix_len);
}






static int is_valid_repository_path(
 _Bool *out,
 git_str *repository_path,
 git_str *common_path,
 uint32_t flags)
{
 _Bool separate_commondir = 0;
 int error;

 *out = 0;

 if ((error = lookup_commondir(&separate_commondir,
   common_path, repository_path, flags)) < 0)
  return error;


 if (git_fs_path_contains_file(repository_path, "HEAD") == 0)
  return 0;


 if (git_fs_path_contains_dir(common_path, "objects/") == 0)
  return 0;
 if (git_fs_path_contains_dir(common_path, "refs/") == 0)
  return 0;


 if ((error = validate_repo_path(common_path)) < 0 ||
     (separate_commondir &&
      (error = validate_repo_path(repository_path)) < 0))
  return error;

 *out = 1;
 return 0;
}

static git_repository *repository_alloc(void)
{
 git_repository *repo = git__calloc(1, sizeof(git_repository));

 if (repo == ((void*)0) ||
  git_cache_init(&repo->objects) < 0)
  goto on_error;

 do { (repo->reserved_names).size = 0; (repo->reserved_names).asize = 4; (repo->reserved_names).ptr = git__calloc(4, sizeof(*(repo->reserved_names).ptr)); } while (0);
 if (!repo->reserved_names.ptr)
  goto on_error;


 git_repository__configmap_lookup_cache_clear(repo);

 return repo;

on_error:
 if (repo)
  git_cache_dispose(&repo->objects);

 git__free(repo);
 return ((void*)0);
}

int git_repository__new(git_repository **out, git_oid_t oid_type)
{
 git_repository *repo;

 *out = repo = repository_alloc();
 do { if ((repo) == ((void*)0)) { return -1; } } while(0);

 do { if (!(git_oid_type_is_valid(oid_type))) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "git_oid_type_is_valid(oid_type)"); return -1; } } while(0);

 repo->is_bare = 1;
 repo->is_worktree = 0;
 repo->oid_type = oid_type;

 return 0;
}







int git_repository_new(git_repository** out)
{
 return git_repository__new(out, GIT_OID_SHA1);
}


static int load_config_data(git_repository *repo, const git_config *config)
{
 int is_bare;

 int err = git_config_get_bool(&is_bare, config, "core.bare");
 if (err < 0 && err != GIT_ENOTFOUND)
  return err;


 if (err != GIT_ENOTFOUND)
  repo->is_bare = is_bare && !repo->is_worktree;
 else
  repo->is_bare = 0;

 return 0;
}

static int load_workdir(
 git_repository *repo,
 git_config *config,
 git_str *parent_path)
{
 git_config_entry *ce = ((void*)0);
 git_str worktree = { git_str__initstr, 0, 0 };
 git_str path = { git_str__initstr, 0, 0 };
 git_str workdir_env = { git_str__initstr, 0, 0 };
 const char *value = ((void*)0);
 int error;

 if (repo->is_bare)
  return 0;


 if (repo->use_env) {
  error = git__getenv(&workdir_env, "GIT_WORK_TREE");

  if (error == 0)
   value = workdir_env.ptr;
  else if (error == GIT_ENOTFOUND)
   error = 0;
  else
   goto cleanup;
 }


 if (!value) {
  if ((error = git_config__lookup_entry(&ce, config,
    "core.worktree", 0)) < 0)
   return error;

  if (ce && ce->value)
   value = ce->value;
 }

 if (repo->is_worktree) {
  char *gitlink = git_worktree__read_link(repo->gitdir, "gitdir");
  if (!gitlink) {
   error = -1;
   goto cleanup;
  }

  git_str_attach(&worktree, gitlink, 0);

  if ((git_fs_path_dirname_r(&worktree, worktree.ptr)) < 0 ||
      git_fs_path_to_dir(&worktree) < 0) {
   error = -1;
   goto cleanup;
  }

  repo->workdir = git_str_detach(&worktree);
 } else if (value) {
  if (!*value) {
   git_error_set(GIT_ERROR_NET, "working directory cannot be set to empty path");
   error = -1;
   goto cleanup;
  }

  if ((error = git_fs_path_prettify_dir(&worktree,
    value, repo->gitdir)) < 0)
   goto cleanup;

  repo->workdir = git_str_detach(&worktree);
 } else if (parent_path && git_fs_path_isdir(parent_path->ptr)) {
  repo->workdir = git_str_detach(parent_path);
 } else {
  if (git_fs_path_dirname_r(&worktree, repo->gitdir) < 0 ||
      git_fs_path_to_dir(&worktree) < 0) {
   error = -1;
   goto cleanup;
  }

  repo->workdir = git_str_detach(&worktree);
 }

 do { if ((repo->workdir) == ((void*)0)) { return -1; } } while(0);

cleanup:
 git_str_dispose(&path);
 git_str_dispose(&workdir_env);
 git_config_entry_free(ce);
 return error;
}
# 470 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
static size_t find_ceiling_dir_offset(
 const char *path,
 const char *ceiling_directories)
{
 char buf[4096 + 1];
 char buf2[4096 + 1];
 const char *ceil, *sep;
 size_t len, max_len = 0, min_len;

 do { if (!(path)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "path"); return -1; } } while(0);

 min_len = (size_t)(git_fs_path_root(path) + 1);

 if (ceiling_directories == ((void*)0) || min_len == 0)
  return min_len;

 for (sep = ceil = ceiling_directories; *sep; ceil = sep + 1) {
  for (sep = ceil; *sep && *sep != ':'; sep++);
  len = sep - ceil;

  if (len == 0 || len >= sizeof(buf) || git_fs_path_root(ceil) == -1)
   continue;

  strncpy(buf, ceil, len);
  buf[len] = '\0';

  if (p_realpath(buf, buf2) == ((void*)0))
   continue;

  len = strlen(buf2);
  if (len > 0 && buf2[len-1] == '/')
   buf[--len] = '\0';

  if (!strncmp(path, buf2, len) &&
   (path[len] == '/' || !path[len]) &&
   len > max_len)
  {
   max_len = len;
  }
 }

 return (max_len <= min_len ? min_len : max_len);
}






static int read_gitfile(git_str *path_out, const char *file_path)
{
 int error = 0;
 git_str file = { git_str__initstr, 0, 0 };
 size_t prefix_len = strlen("gitdir:");

 do { if (!(path_out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "path_out"); return -1; } } while(0);
 do { if (!(file_path)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "file_path"); return -1; } } while(0);

 if (git_futils_readbuffer(&file, file_path) < 0)
  return -1;

 git_str_rtrim(&file);

                              ;

 if (git_str_len(&file) <= prefix_len ||
  memcmp(git_str_cstr(&file), "gitdir:", prefix_len) != 0)
 {
  git_error_set(GIT_ERROR_REPOSITORY,
   "the `.git` file at '%s' is malformed", file_path);
  error = -1;
 }
 else if ((error = git_fs_path_dirname_r(path_out, file_path)) >= 0) {
  const char *gitlink = git_str_cstr(&file) + prefix_len;
  while (*gitlink && (!!((*__ctype_b_loc ())[(int) (((unsigned char)(*gitlink)))] & (unsigned short int) _ISspace))) gitlink++;

  error = git_fs_path_prettify_dir(
   path_out, gitlink, git_str_cstr(path_out));
 }

 git_str_dispose(&file);
 return error;
}

typedef struct {
 const char *repo_path;
 git_str tmp;
 _Bool *is_safe;
} validate_ownership_data;

static int validate_ownership_cb(const git_config_entry *entry, void *payload)
{
 validate_ownership_data *data = payload;
 const char *test_path;

 if (strcmp(entry->value, "") == 0) {
  *data->is_safe = 0;
 } else if (strcmp(entry->value, "*") == 0) {
  *data->is_safe = 1;
 } else {
  if (git_str_sets(&data->tmp, entry->value) < 0)
   return -1;

  if (!git_fs_path_is_root(data->tmp.ptr)) {

   if (!data->tmp.size ||
       data->tmp.ptr[data->tmp.size - 1] == '/')
    return 0;

   if (git_fs_path_to_dir(&data->tmp) < 0)
    return -1;
  }

  test_path = data->tmp.ptr;
# 608 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
  if (strncmp(test_path, "%(prefix)//", strlen("%(prefix)//")) == 0)
   test_path += strlen("%(prefix)/");

  if (strcmp(test_path, data->repo_path) == 0)
   *data->is_safe = 1;
 }

 return 0;
}

static int validate_ownership_config(
 _Bool *is_safe,
 const char *path,
 _Bool use_env)
{
 validate_ownership_data ownership_data = {
  path, { git_str__initstr, 0, 0 }, is_safe
 };
 git_config *config;
 int error;

 if (load_global_config(&config, use_env) != 0)
  return 0;

 error = git_config_get_multivar_foreach(config,
  "safe.directory", ((void*)0),
  validate_ownership_cb,
  &ownership_data);

 if (error == GIT_ENOTFOUND)
  error = 0;

 git_config_free(config);
 git_str_dispose(&ownership_data.tmp);

 return error;
}

static int validate_ownership_path(_Bool *is_safe, const char *path)
{
 git_fs_path_owner_t owner_level =
  GIT_FS_PATH_OWNER_CURRENT_USER |
  GIT_FS_PATH_USER_IS_ADMINISTRATOR |
  GIT_FS_PATH_OWNER_RUNNING_SUDO;
 int error = 0;

 if (path)
  error = git_fs_path_owner_is(is_safe, path, owner_level);

 if (error == GIT_ENOTFOUND) {
  *is_safe = 1;
  error = 0;
 } else if (error == GIT_EINVALID) {
  *is_safe = 0;
  error = 0;
 }

 return error;
}

static int validate_ownership(git_repository *repo)
{
 const char *validation_paths[3] = { ((void*)0) }, *path;
 size_t validation_len = 0, i;
 _Bool is_safe = 0;
 int error = 0;
# 684 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 if (repo->workdir)
  validation_paths[validation_len++] = repo->workdir;

 if (repo->gitlink)
  validation_paths[validation_len++] = repo->gitlink;

 validation_paths[validation_len++] = repo->gitdir;

 for (i = 0; i < validation_len; i++) {
  path = validation_paths[i];

  if ((error = validate_ownership_path(&is_safe, path)) < 0)
   goto done;

  if (!is_safe)
   break;
 }

 if (is_safe ||
     (error = validate_ownership_config(
   &is_safe, validation_paths[0], repo->use_env)) < 0)
  goto done;

 if (!is_safe) {
  size_t path_len = git_fs_path_is_root(path) ?
   strlen(path) : git_fs_path_dirlen(path);

  git_error_set(GIT_ERROR_CONFIG,
   "repository path '%.*s' is not owned by current user",
   (int)((path_len) < (2147483647) ? (path_len) : (2147483647)), path);
  error = GIT_EOWNER;
 }

done:
 return error;
}

struct repo_paths {
 git_str gitdir;
 git_str workdir;
 git_str gitlink;
 git_str commondir;
};



static __inline__ void repo_paths_dispose(struct repo_paths *paths)
{
 git_str_dispose(&paths->gitdir);
 git_str_dispose(&paths->workdir);
 git_str_dispose(&paths->gitlink);
 git_str_dispose(&paths->commondir);
}

static int find_repo_traverse(
 struct repo_paths *out,
 const char *start_path,
 const char *ceiling_dirs,
 uint32_t flags)
{
 git_str path = { git_str__initstr, 0, 0 };
 git_str repo_link = { git_str__initstr, 0, 0 };
 git_str common_link = { git_str__initstr, 0, 0 };
 struct stat st;
 dev_t initial_device = 0;
 int min_iterations;
 _Bool in_dot_git, is_valid;
 size_t ceiling_offset = 0;
 int error;

 git_str_clear(&out->gitdir);

 if ((error = git_fs_path_prettify(&path, start_path, ((void*)0))) < 0)
  return error;
# 771 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 if (flags & (GIT_REPOSITORY_OPEN_BARE | GIT_REPOSITORY_OPEN_NO_DOTGIT)) {
  in_dot_git = 1;
  min_iterations = 1;
 } else {
  in_dot_git = 0;
  min_iterations = 2;
 }

 for (;;) {
  if (!(flags & GIT_REPOSITORY_OPEN_NO_DOTGIT)) {
   if (!in_dot_git) {
    if ((error = git_str_joinpath(&path, path.ptr, ".git")) < 0)
     goto out;
   }
   in_dot_git = !in_dot_git;
  }

  if (stat(path.ptr, &st) == 0) {

   if (initial_device == 0)
    initial_device = st.st_dev;
   else if (st.st_dev != initial_device &&
     !(flags & GIT_REPOSITORY_OPEN_CROSS_FS))
    break;

   if (((((st.st_mode)) & 0170000) == (0040000))) {
    if ((error = is_valid_repository_path(&is_valid, &path, &common_link, flags)) < 0)
     goto out;

    if (is_valid) {
     if ((error = git_fs_path_to_dir(&path)) < 0 ||
         (error = git_str_set(&out->gitdir, path.ptr, path.size)) < 0)
      goto out;

     if ((error = git_str_attach(&out->gitlink, git_worktree__read_link(path.ptr, "gitdir"), 0)) < 0)
      goto out;

     git_str_swap(&common_link, &out->commondir);

     break;
    }
   } else if (((((st.st_mode)) & 0170000) == (0100000)) && git__suffixcmp(path.ptr, "/" ".git") == 0) {
    if ((error = read_gitfile(&repo_link, path.ptr)) < 0 ||
        (error = is_valid_repository_path(&is_valid, &repo_link, &common_link, flags)) < 0)
     goto out;

    if (is_valid) {
     git_str_swap(&out->gitdir, &repo_link);

     if ((error = git_str_put(&out->gitlink, path.ptr, path.size)) < 0)
      goto out;

     git_str_swap(&common_link, &out->commondir);
    }
    break;
   }
  }







  if ((error = git_fs_path_dirname_r(&path, path.ptr)) < 0)
   goto out;





  if (min_iterations && (--min_iterations == 0))
   ceiling_offset = find_ceiling_dir_offset(path.ptr, ceiling_dirs);


  if (min_iterations == 0 &&
      (path.ptr[ceiling_offset] == 0 || (flags & GIT_REPOSITORY_OPEN_NO_SEARCH)))
   break;
 }

 if (!(flags & GIT_REPOSITORY_OPEN_BARE)) {
  if (!git_str_len(&out->gitdir))
   git_str_clear(&out->workdir);
  else if ((error = git_fs_path_dirname_r(&out->workdir, path.ptr)) < 0 ||
    (error = git_fs_path_to_dir(&out->workdir)) < 0)
   goto out;
 }



 if (!git_str_len(&out->gitdir)) {
  git_error_set(GIT_ERROR_REPOSITORY, "could not find repository at '%s'", start_path);
  error = GIT_ENOTFOUND;
  goto out;
 }

out:
 if (error)
  repo_paths_dispose(out);

 git_str_dispose(&path);
 git_str_dispose(&repo_link);
 git_str_dispose(&common_link);
 return error;
}

static int load_grafts(git_repository *repo)
{
 git_str path = { git_str__initstr, 0, 0 };
 int error;


 if (repo->grafts && repo->shallow_grafts) {
  if ((error = git_grafts_refresh(repo->grafts)) < 0 ||
      (error = git_grafts_refresh(repo->shallow_grafts)) < 0)
   return error;
 }


 if ((error = git_repository__item_path(&path, repo, GIT_REPOSITORY_ITEM_INFO)) < 0) {
  if (error != GIT_ENOTFOUND)
   return error;


  if (!repo->grafts && (error = git_grafts_new(&repo->grafts, repo->oid_type)) < 0)
   return error;

  if (!repo->shallow_grafts && (error = git_grafts_new(&repo->shallow_grafts, repo->oid_type)) < 0)
   return error;

  return 0;
 }


 if ((error = git_str_joinpath(&path, path.ptr, "grafts")) < 0 ||
     (error = git_grafts_open_or_refresh(&repo->grafts, path.ptr, repo->oid_type)) < 0)
  goto error;

 git_str_clear(&path);

 if ((error = git_str_joinpath(&path, repo->gitdir, "shallow")) < 0 ||
     (error = git_grafts_open_or_refresh(&repo->shallow_grafts, path.ptr, repo->oid_type)) < 0)
  goto error;

error:
 git_str_dispose(&path);
 return error;
}

static int find_repo(
 struct repo_paths *out,
 const char *start_path,
 const char *ceiling_dirs,
 uint32_t flags)
{
 _Bool use_env = !!(flags & GIT_REPOSITORY_OPEN_FROM_ENV);
 git_str gitdir_buf = { git_str__initstr, 0, 0 },
         ceiling_dirs_buf = { git_str__initstr, 0, 0 },
         across_fs_buf = { git_str__initstr, 0, 0 };
 int error;

 if (use_env && !start_path) {
  error = git__getenv(&gitdir_buf, "GIT_DIR");

  if (!error) {
   start_path = gitdir_buf.ptr;
   flags |= GIT_REPOSITORY_OPEN_NO_SEARCH;
   flags |= GIT_REPOSITORY_OPEN_NO_DOTGIT;
  } else if (error == GIT_ENOTFOUND) {
   start_path = ".";
  } else {
   goto done;
  }
 }

 if (use_env && !ceiling_dirs) {
  error = git__getenv(&ceiling_dirs_buf,
   "GIT_CEILING_DIRECTORIES");

  if (!error)
   ceiling_dirs = ceiling_dirs_buf.ptr;
  else if (error != GIT_ENOTFOUND)
   goto done;
 }

 if (use_env) {
  error = git__getenv(&across_fs_buf,
   "GIT_DISCOVERY_ACROSS_FILESYSTEM");

  if (!error) {
   int across_fs = 0;

   if ((error = git_config_parse_bool(&across_fs,
    git_str_cstr(&across_fs_buf))) < 0)
    goto done;

   if (across_fs)
    flags |= GIT_REPOSITORY_OPEN_CROSS_FS;
  } else if (error != GIT_ENOTFOUND) {
   goto done;
  }
 }

 error = find_repo_traverse(out, start_path, ceiling_dirs, flags);

done:
 git_str_dispose(&gitdir_buf);
 git_str_dispose(&ceiling_dirs_buf);
 git_str_dispose(&across_fs_buf);

 return error;
}

static int obtain_config_and_set_oid_type(
 git_config **config_ptr,
 git_repository *repo)
{
 int error;
 git_config *config = ((void*)0);
 int version = 0;






 error = git_repository_config_snapshot(&config, repo);
 if (error < 0 && error != GIT_ENOTFOUND)
  goto out;

 if (config &&
     (error = check_repositoryformatversion(&version, config)) < 0)
  goto out;

 if ((error = check_extensions(config, version)) < 0)
  goto out;

 if (version > 0) {
  if ((error = load_objectformat(repo, config)) < 0)
   goto out;
 } else {
  repo->oid_type = GIT_OID_SHA1;
 }

out:
 *config_ptr = config;

 return error;
}

int git_repository_open_bare(
 git_repository **repo_ptr,
 const char *bare_path)
{
 git_str path = { git_str__initstr, 0, 0 }, common_path = { git_str__initstr, 0, 0 };
 git_repository *repo = ((void*)0);
 _Bool is_valid;
 int error;
 git_config *config;

 if ((error = git_fs_path_prettify_dir(&path, bare_path, ((void*)0))) < 0 ||
     (error = is_valid_repository_path(&is_valid, &path, &common_path, 0)) < 0)
  return error;

 if (!is_valid) {
  git_str_dispose(&path);
  git_str_dispose(&common_path);
  git_error_set(GIT_ERROR_REPOSITORY, "path is not a repository: %s", bare_path);
  return GIT_ENOTFOUND;
 }

 repo = repository_alloc();
 do { if ((repo) == ((void*)0)) { return -1; } } while(0);

 repo->gitdir = git_str_detach(&path);
 do { if ((repo->gitdir) == ((void*)0)) { return -1; } } while(0);
 repo->commondir = git_str_detach(&common_path);
 do { if ((repo->commondir) == ((void*)0)) { return -1; } } while(0);


 repo->is_bare = 1;
 repo->is_worktree = 0;
 repo->workdir = ((void*)0);

 if ((error = obtain_config_and_set_oid_type(&config, repo)) < 0)
  goto cleanup;

 *repo_ptr = repo;

cleanup:
 git_config_free(config);

 return error;
}

static int repo_load_namespace(git_repository *repo)
{
 git_str namespace_buf = { git_str__initstr, 0, 0 };
 int error;

 if (!repo->use_env)
  return 0;

 error = git__getenv(&namespace_buf, "GIT_NAMESPACE");

 if (error == 0)
  repo->namespace = git_str_detach(&namespace_buf);
 else if (error != GIT_ENOTFOUND)
  return error;

 return 0;
}

static int repo_is_worktree(unsigned *out, const git_repository *repo)
{
 git_str gitdir_link = { git_str__initstr, 0, 0 };
 int error;


 if (repo->commondir && repo->gitdir
     && !strcmp(repo->commondir, repo->gitdir)) {
  *out = 0;
  return 0;
 }

 if ((error = git_str_joinpath(&gitdir_link, repo->gitdir, "gitdir")) < 0)
  return -1;



 *out = !!git_fs_path_exists(gitdir_link.ptr);

 git_str_dispose(&gitdir_link);
 return error;
}

int git_repository_open_ext(
 git_repository **repo_ptr,
 const char *start_path,
 unsigned int flags,
 const char *ceiling_dirs)
{
 struct repo_paths paths = { { git_str__initstr, 0, 0 } };
 git_repository *repo = ((void*)0);
 git_config *config = ((void*)0);
 unsigned is_worktree;
 int error;

 if (repo_ptr)
  *repo_ptr = ((void*)0);

 error = find_repo(&paths, start_path, ceiling_dirs, flags);

 if (error < 0 || !repo_ptr)
  goto cleanup;

 repo = repository_alloc();
 do { if ((repo) == ((void*)0)) { return -1; } } while(0);

 repo->use_env = !!(flags & GIT_REPOSITORY_OPEN_FROM_ENV);

 repo->gitdir = git_str_detach(&paths.gitdir);
 do { if ((repo->gitdir) == ((void*)0)) { return -1; } } while(0);

 if (paths.gitlink.size) {
  repo->gitlink = git_str_detach(&paths.gitlink);
  do { if ((repo->gitlink) == ((void*)0)) { return -1; } } while(0);
 }
 if (paths.commondir.size) {
  repo->commondir = git_str_detach(&paths.commondir);
  do { if ((repo->commondir) == ((void*)0)) { return -1; } } while(0);
 }

 if ((error = repo_is_worktree(&is_worktree, repo)) < 0)
  goto cleanup;

 repo->is_worktree = is_worktree;

 error = obtain_config_and_set_oid_type(&config, repo);
 if (error < 0)
  goto cleanup;

 if ((error = load_grafts(repo)) < 0)
  goto cleanup;

 if ((flags & GIT_REPOSITORY_OPEN_BARE) != 0) {
  repo->is_bare = 1;
 } else {
  if (config &&
      ((error = load_config_data(repo, config)) < 0 ||
       (error = load_workdir(repo, config, &paths.workdir)) < 0))
   goto cleanup;
 }

 if ((error = repo_load_namespace(repo)) < 0)
  goto cleanup;





 if (git_repository__validate_ownership &&
     (error = validate_ownership(repo)) < 0)
  goto cleanup;

cleanup:
 repo_paths_dispose(&paths);
 git_config_free(config);

 if (error < 0)
  git_repository_free(repo);
 else if (repo_ptr)
  *repo_ptr = repo;

 return error;
}

int git_repository_open(git_repository **repo_out, const char *path)
{
 return git_repository_open_ext(
  repo_out, path, GIT_REPOSITORY_OPEN_NO_SEARCH, ((void*)0));
}

int git_repository_open_from_worktree(git_repository **repo_out, git_worktree *wt)
{
 git_str path = { git_str__initstr, 0, 0 };
 git_repository *repo = ((void*)0);
 size_t len;
 int err;

 do { if (!(repo_out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo_out"); return -1; } } while(0);
 do { if (!(wt)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "wt"); return -1; } } while(0);

 *repo_out = ((void*)0);
 len = strlen(wt->gitlink_path);

 if (len <= 4 || strcasecmp(wt->gitlink_path + len - 4, ".git")) {
  err = -1;
  goto out;
 }

 if ((err = git_str_set(&path, wt->gitlink_path, len - 4)) < 0)
  goto out;

 if ((err = git_repository_open(&repo, path.ptr)) < 0)
  goto out;

 *repo_out = repo;

out:
 git_str_dispose(&path);

 return err;
}

int git_repository_wrap_odb(git_repository **out, git_odb *odb)
{
 git_repository *repo;

 repo = repository_alloc();
 do { if ((repo) == ((void*)0)) { return -1; } } while(0);

 do { if (!(git_oid_type_is_valid(odb->options.oid_type))) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "git_oid_type_is_valid(odb->options.oid_type)"); return -1; } } while(0);
 repo->oid_type = odb->options.oid_type;

 git_repository_set_odb(repo, odb);
 *out = repo;

 return 0;
}

int git_repository_discover(
 git_buf *out,
 const char *start_path,
 int across_fs,
 const char *ceiling_dirs)
{
 struct repo_paths paths = { { git_str__initstr, 0, 0 } };
 uint32_t flags = across_fs ? GIT_REPOSITORY_OPEN_CROSS_FS : 0;
 int error;

 do { if (!(start_path)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "start_path"); return -1; } } while(0);

 if ((error = find_repo(&paths, start_path, ceiling_dirs, flags)) == 0)
  error = git_buf_fromstr(out, &paths.gitdir);

 repo_paths_dispose(&paths);
 return error;
}

static int has_config_worktree(_Bool *out, git_config *cfg)
{
 int worktreeconfig = 0, error;

 *out = 0;

 error = git_config_get_bool(&worktreeconfig, cfg, "extensions.worktreeconfig");

 if (error == 0)
  *out = worktreeconfig;
 else if (error == GIT_ENOTFOUND)
  *out = 0;
 else
  return error;

 return 0;
}

static int load_config(
 git_config **out,
 git_repository *repo,
 const char *global_config_path,
 const char *xdg_config_path,
 const char *system_config_path,
 const char *programdata_path)
{
 git_str config_path = { git_str__initstr, 0, 0 };
 git_config *cfg = ((void*)0);
 git_config_level_t write_order;
 _Bool has_worktree;
 int error;

 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);

 if ((error = git_config_new(&cfg)) < 0)
  return error;

 if (repo) {
  if ((error = git_repository__item_path(&config_path, repo, GIT_REPOSITORY_ITEM_CONFIG)) == 0)
   error = git_config_add_file_ondisk(cfg, config_path.ptr, GIT_CONFIG_LEVEL_LOCAL, repo, 0);

  if (error && error != GIT_ENOTFOUND)
   goto on_error;

  if ((error = has_config_worktree(&has_worktree, cfg)) == 0 &&
      has_worktree &&
      (error = git_repository__item_path(&config_path, repo, GIT_REPOSITORY_ITEM_WORKTREE_CONFIG)) == 0)
   error = git_config_add_file_ondisk(cfg, config_path.ptr, GIT_CONFIG_LEVEL_WORKTREE, repo, 0);

  if (error && error != GIT_ENOTFOUND)
   goto on_error;

  git_str_dispose(&config_path);
 }

 if (global_config_path != ((void*)0) &&
  (error = git_config_add_file_ondisk(
   cfg, global_config_path, GIT_CONFIG_LEVEL_GLOBAL, repo, 0)) < 0 &&
  error != GIT_ENOTFOUND)
  goto on_error;

 if (xdg_config_path != ((void*)0) &&
  (error = git_config_add_file_ondisk(
   cfg, xdg_config_path, GIT_CONFIG_LEVEL_XDG, repo, 0)) < 0 &&
  error != GIT_ENOTFOUND)
  goto on_error;

 if (system_config_path != ((void*)0) &&
  (error = git_config_add_file_ondisk(
   cfg, system_config_path, GIT_CONFIG_LEVEL_SYSTEM, repo, 0)) < 0 &&
  error != GIT_ENOTFOUND)
  goto on_error;

 if (programdata_path != ((void*)0) &&
  (error = git_config_add_file_ondisk(
   cfg, programdata_path, GIT_CONFIG_LEVEL_PROGRAMDATA, repo, 0)) < 0 &&
  error != GIT_ENOTFOUND)
  goto on_error;

 git_error_clear();

 write_order = GIT_CONFIG_LEVEL_LOCAL;

 if ((error = git_config_set_writeorder(cfg, &write_order, 1)) < 0)
  goto on_error;

 *out = cfg;
 return 0;

on_error:
 git_str_dispose(&config_path);
 git_config_free(cfg);
 *out = ((void*)0);
 return error;
}

static const char *path_unless_empty(git_str *buf)
{
 return git_str_len(buf) > 0 ? git_str_cstr(buf) : ((void*)0);
}

static __inline__ int config_path_system(git_str *out, _Bool use_env)
{
 if (use_env) {
  git_str no_system_buf = { git_str__initstr, 0, 0 };
  int no_system = 0;
  int error;

  error = git__getenv(&no_system_buf, "GIT_CONFIG_NOSYSTEM");

  if (error && error != GIT_ENOTFOUND)
   return error;

  error = git_config_parse_bool(&no_system, no_system_buf.ptr);
  git_str_dispose(&no_system_buf);

  if (no_system)
   return 0;

  error = git__getenv(out, "GIT_CONFIG_SYSTEM");

  if (error == 0 || error != GIT_ENOTFOUND)
   return 0;
 }

 git_config__find_system(out);
 return 0;
}

static __inline__ int config_path_global(git_str *out, _Bool use_env)
{
 if (use_env) {
  int error = git__getenv(out, "GIT_CONFIG_GLOBAL");

  if (error == 0 || error != GIT_ENOTFOUND)
   return 0;
 }

 git_config__find_global(out);
 return 0;
}

int git_repository_config__weakptr(git_config **out, git_repository *repo)
{
 int error = 0;

 if (repo->_config == ((void*)0)) {
  git_str system_buf = { git_str__initstr, 0, 0 };
  git_str global_buf = { git_str__initstr, 0, 0 };
  git_str xdg_buf = { git_str__initstr, 0, 0 };
  git_str programdata_buf = { git_str__initstr, 0, 0 };
  _Bool use_env = repo->use_env;
  git_config *config;

  if (!(error = config_path_system(&system_buf, use_env)) &&
      !(error = config_path_global(&global_buf, use_env))) {
   git_config__find_xdg(&xdg_buf);
   git_config__find_programdata(&programdata_buf);
  }

  if (!error) {




   if (git_str_len(&global_buf) == 0)
    git_config__global_location(&global_buf);

   error = load_config(
    &config, repo,
    path_unless_empty(&global_buf),
    path_unless_empty(&xdg_buf),
    path_unless_empty(&system_buf),
    path_unless_empty(&programdata_buf));
  }

  if (!error) {
   { (void)(void *)git_atomic__swap((void * volatile *)&((config)->rc.owner), repo); };

   if (git_atomic__compare_and_swap((void * volatile *)&repo->_config, ((void*)0), config) != ((void*)0)) {
    { (void)(void *)git_atomic__swap((void * volatile *)&((config)->rc.owner), ((void*)0)); };
    git_config_free(config);
   }
  }

  git_str_dispose(&global_buf);
  git_str_dispose(&xdg_buf);
  git_str_dispose(&system_buf);
  git_str_dispose(&programdata_buf);
 }

 *out = repo->_config;
 return error;
}

int git_repository_config(git_config **out, git_repository *repo)
{
 if (git_repository_config__weakptr(out, repo) < 0)
  return -1;

 { git_atomic32_inc(&(*out)->rc.refcount); };
 return 0;
}

int git_repository_config_snapshot(git_config **out, git_repository *repo)
{
 int error;
 git_config *weak;

 if ((error = git_repository_config__weakptr(&weak, repo)) < 0)
  return error;

 return git_config_snapshot(out, weak);
}

int git_repository_set_config(git_repository *repo, git_config *config)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(config)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "config"); return -1; } } while(0);

 set_config(repo, config);
 return 0;
}

static int repository_odb_path(git_str *out, git_repository *repo)
{
 int error = GIT_ENOTFOUND;

 if (repo->use_env)
  error = git__getenv(out, "GIT_OBJECT_DIRECTORY");

 if (error == GIT_ENOTFOUND)
  error = git_repository__item_path(out, repo,
   GIT_REPOSITORY_ITEM_OBJECTS);

 return error;
}

static int repository_odb_alternates(
 git_odb *odb,
 git_repository *repo)
{
 git_str alternates = { git_str__initstr, 0, 0 };
 char *sep, *alt;
 int error;

 if (!repo->use_env)
  return 0;

 error = git__getenv(&alternates, "GIT_ALTERNATE_OBJECT_DIRECTORIES");

 if (error != 0)
  return (error == GIT_ENOTFOUND) ? 0 : error;

 alt = alternates.ptr;

 while (*alt) {
  sep = strchr(alt, ':');

  if (sep)
   *sep = '\0';

  error = git_odb_add_disk_alternate(odb, alt);

  if (sep)
   alt = sep + 1;
  else
   break;
 }

 git_str_dispose(&alternates);
 return 0;
}

int git_repository_odb__weakptr(git_odb **out, git_repository *repo)
{
 int error = 0;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);

 *out = (void *)git_atomic__load((void * volatile *)&(repo->_odb));
 if (*out == ((void*)0)) {
  git_str odb_path = { git_str__initstr, 0, 0 };
  git_odb_options odb_opts = { 1 };
  git_odb *odb;

  odb_opts.oid_type = repo->oid_type;

  if ((error = repository_odb_path(&odb_path, repo)) < 0 ||
      (error = git_odb__new(&odb, &odb_opts)) < 0 ||
      (error = repository_odb_alternates(odb, repo)) < 0)
   return error;

  { (void)(void *)git_atomic__swap((void * volatile *)&((odb)->rc.owner), repo); };

  if ((error = git_odb__set_caps(odb, GIT_ODB_CAP_FROM_OWNER)) < 0 ||
   (error = git_odb__add_default_backends(odb, odb_path.ptr, 0, 0)) < 0) {
   git_odb_free(odb);
   return error;
  }

  if (git_atomic__compare_and_swap((void * volatile *)&repo->_odb, ((void*)0), odb) != ((void*)0)) {
   { (void)(void *)git_atomic__swap((void * volatile *)&((odb)->rc.owner), ((void*)0)); };
   git_odb_free(odb);
  }

  git_str_dispose(&odb_path);
  *out = (void *)git_atomic__load((void * volatile *)&(repo->_odb));
 }

 return error;
}

int git_repository_odb(git_odb **out, git_repository *repo)
{
 if (git_repository_odb__weakptr(out, repo) < 0)
  return -1;

 { git_atomic32_inc(&(*out)->rc.refcount); };
 return 0;
}

int git_repository_set_odb(git_repository *repo, git_odb *odb)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(odb)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "odb"); return -1; } } while(0);

 set_odb(repo, odb);
 return 0;
}

int git_repository_refdb__weakptr(git_refdb **out, git_repository *repo)
{
 int error = 0;

 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 if (repo->_refdb == ((void*)0)) {
  git_refdb *refdb;

  error = git_refdb_open(&refdb, repo);
  if (!error) {
   { (void)(void *)git_atomic__swap((void * volatile *)&((refdb)->rc.owner), repo); };

   if (git_atomic__compare_and_swap((void * volatile *)&repo->_refdb, ((void*)0), refdb) != ((void*)0)) {
    { (void)(void *)git_atomic__swap((void * volatile *)&((refdb)->rc.owner), ((void*)0)); };
    git_refdb_free(refdb);
   }
  }
 }

 *out = repo->_refdb;
 return error;
}

int git_repository_refdb(git_refdb **out, git_repository *repo)
{
 if (git_repository_refdb__weakptr(out, repo) < 0)
  return -1;

 { git_atomic32_inc(&(*out)->rc.refcount); };
 return 0;
}

int git_repository_set_refdb(git_repository *repo, git_refdb *refdb)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(refdb)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "refdb"); return -1; } } while(0);

 set_refdb(repo, refdb);
 return 0;
}

static int repository_index_path(git_str *out, git_repository *repo)
{
 int error = GIT_ENOTFOUND;

 if (repo->use_env)
  error = git__getenv(out, "GIT_INDEX_FILE");

 if (error == GIT_ENOTFOUND)
  error = git_repository__item_path(out, repo,
   GIT_REPOSITORY_ITEM_INDEX);

 return error;
}

int git_repository_index__weakptr(git_index **out, git_repository *repo)
{
 int error = 0;

 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 if (repo->_index == ((void*)0)) {
  git_str index_path = { git_str__initstr, 0, 0 };
  git_index *index;

  if ((error = repository_index_path(&index_path, repo)) < 0)
   return error;

  error = git_index__open(&index, index_path.ptr, repo->oid_type);

  if (!error) {
   { (void)(void *)git_atomic__swap((void * volatile *)&((index)->rc.owner), repo); };

   if (git_atomic__compare_and_swap((void * volatile *)&repo->_index, ((void*)0), index) != ((void*)0)) {
    { (void)(void *)git_atomic__swap((void * volatile *)&((index)->rc.owner), ((void*)0)); };
    git_index_free(index);
   }

   error = git_index_set_caps(repo->_index,
                              GIT_INDEX_CAPABILITY_FROM_OWNER);
  }

  git_str_dispose(&index_path);
 }

 *out = repo->_index;
 return error;
}

int git_repository_index(git_index **out, git_repository *repo)
{
 if (git_repository_index__weakptr(out, repo) < 0)
  return -1;

 { git_atomic32_inc(&(*out)->rc.refcount); };
 return 0;
}

int git_repository_set_index(git_repository *repo, git_index *index)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 set_index(repo, index);
 return 0;
}

int git_repository_grafts__weakptr(git_grafts **out, git_repository *repo)
{
 do { if (!(out && repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out && repo"); return -1; } } while(0);
 do { if (!(repo->grafts)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "repo->grafts"); return -1; } } while(0);
 *out = repo->grafts;
 return 0;
}

int git_repository_shallow_grafts__weakptr(git_grafts **out, git_repository *repo)
{
 do { if (!(out && repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out && repo"); return -1; } } while(0);
 do { if (!(repo->shallow_grafts)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "repo->shallow_grafts"); return -1; } } while(0);
 *out = repo->shallow_grafts;
 return 0;
}

int git_repository_set_namespace(git_repository *repo, const char *namespace)
{
 git__free(repo->namespace);

 if (namespace == ((void*)0)) {
  repo->namespace = ((void*)0);
  return 0;
 }

 return (repo->namespace = git__strdup(namespace)) ? 0 : -1;
}

const char *git_repository_get_namespace(git_repository *repo)
{
 return repo->namespace;
}
# 1819 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
_Bool git_repository__reserved_names(
 git_str **out, size_t *outlen, git_repository *repo, _Bool include_ntfs)
{
 do { __typeof__(repo) _unused __attribute__((unused)); _unused = (repo); } while (0);

 if (include_ntfs) {
  *out = git_repository__reserved_names_win32;
  *outlen = git_repository__reserved_names_win32_len;
 } else {
  *out = git_repository__reserved_names_posix;
  *outlen = git_repository__reserved_names_posix_len;
 }

 return 1;
}


static int check_repositoryformatversion(int *version, git_config *config)
{
 int error;

 error = git_config_get_int32(version, config, "core.repositoryformatversion");


 if (error == GIT_ENOTFOUND)
  return 0;

 if (error < 0)
  return -1;

 if (*version < 0) {
  git_error_set(GIT_ERROR_REPOSITORY,
   "invalid repository version %d", *version);
 }

 if (1 < *version) {
  git_error_set(GIT_ERROR_REPOSITORY,
   "unsupported repository version %d; only versions up to %d are supported",
   *version, 1);
  return -1;
 }

 return 0;
}

static const char *builtin_extensions[] = {
 "noop",
 "objectformat",
 "worktreeconfig",
 "preciousobjects"
};

static git_vector user_extensions = { 0, git__strcmp_cb };

static int check_valid_extension(const git_config_entry *entry, void *payload)
{
 git_str cfg = { git_str__initstr, 0, 0 };
 _Bool reject;
 const char *extension;
 size_t i;
 int error = 0;

 do { __typeof__(payload) _unused __attribute__((unused)); _unused = (payload); } while (0);

 for ((i) = 0; (i) < (&user_extensions)->length && ((extension) = (&user_extensions)->contents[(i)], 1); (i)++ ) {
  git_str_clear(&cfg);





  if ((reject = (extension[0] == '!')) == 1)
   extension = &extension[1];

  if ((error = git_str_printf(&cfg, "extensions.%s", extension)) < 0)
   goto done;

  if (strcmp(entry->name, cfg.ptr) == 0) {
   if (reject)
    goto fail;

   goto done;
  }
 }

 for (i = 0; i < (sizeof(builtin_extensions)/sizeof(builtin_extensions[0])); i++) {
  git_str_clear(&cfg);
  extension = builtin_extensions[i];

  if ((error = git_str_printf(&cfg, "extensions.%s", extension)) < 0)
   goto done;

  if (strcmp(entry->name, cfg.ptr) == 0)
   goto done;
 }

fail:
 git_error_set(GIT_ERROR_REPOSITORY, "unsupported extension name %s", entry->name);
 error = -1;

done:
 git_str_dispose(&cfg);
 return error;
}

static int check_extensions(git_config *config, int version)
{
 if (version < 1)
  return 0;

 return git_config_foreach_match(config, "^extensions\\.", check_valid_extension, ((void*)0));
}

static int load_objectformat(git_repository *repo, git_config *config)
{
 git_config_entry *entry = ((void*)0);
 int error;

 if ((error = git_config_get_entry(&entry, config, "extensions.objectformat")) < 0) {
  if (error == GIT_ENOTFOUND) {
   repo->oid_type = GIT_OID_SHA1;
   git_error_clear();
   error = 0;
  }

  goto done;
 }

 if ((repo->oid_type = git_oid_type_fromstr(entry->value)) == 0) {
  git_error_set(GIT_ERROR_REPOSITORY,
   "unknown object format '%s'", entry->value);
  error = GIT_EINVALID;
 }

done:
 git_config_entry_free(entry);
 return error;
}

int git_repository__set_objectformat(
 git_repository *repo,
 git_oid_t oid_type)
{
 git_config *cfg;
# 1971 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 if (oid_type == GIT_OID_SHA1)
  return 0;

 if (!git_repository_is_empty(repo) && repo->oid_type != oid_type) {
  git_error_set(GIT_ERROR_REPOSITORY,
   "cannot change object id type of existing repository");
  return -1;
 }

 if (git_repository_config__weakptr(&cfg, repo) < 0)
  return -1;

 if (git_config_set_int32(cfg,
   "core.repositoryformatversion", 1) < 0 ||
     git_config_set_string(cfg, "extensions.objectformat",
   git_oid_type_name(oid_type)) < 0)
  return -1;






 if (repo->oid_type != oid_type) {
  set_index(repo, ((void*)0));
  set_odb(repo, ((void*)0));
  set_refdb(repo, ((void*)0));

  repo->oid_type = oid_type;
 }

 return 0;
}

int git_repository__extensions(char ***out, size_t *out_len)
{
 git_vector extensions;
 const char *builtin, *user;
 char *extension;
 size_t i, j;

 if (git_vector_init(&extensions, 8, git__strcmp_cb) < 0)
  return -1;

 for (i = 0; i < (sizeof(builtin_extensions)/sizeof(builtin_extensions[0])); i++) {
  _Bool match = 0;

  builtin = builtin_extensions[i];

  for ((j) = 0; (j) < (&user_extensions)->length && ((user) = (&user_extensions)->contents[(j)], 1); (j)++ ) {
   if (user[0] == '!' && strcmp(builtin, &user[1]) == 0) {
    match = 1;
    break;
   }
  }

  if (match)
   continue;

  if ((extension = git__strdup(builtin)) == ((void*)0) ||
      git_vector_insert(&extensions, extension) < 0)
   return -1;
 }

 for ((i) = 0; (i) < (&user_extensions)->length && ((user) = (&user_extensions)->contents[(i)], 1); (i)++ ) {
  if (user[0] == '!')
   continue;

  if ((extension = git__strdup(user)) == ((void*)0) ||
      git_vector_insert(&extensions, extension) < 0)
   return -1;
 }

 git_vector_sort(&extensions);

 *out = (char **)git_vector_detach(out_len, ((void*)0), &extensions);
 return 0;
}

static int dup_ext_err(void **old, void *extension)
{
 do { __typeof__(old) _unused __attribute__((unused)); _unused = (old); } while (0);
 do { __typeof__(extension) _unused __attribute__((unused)); _unused = (extension); } while (0);
 return GIT_EEXISTS;
}

int git_repository__set_extensions(const char **extensions, size_t len)
{
 char *extension;
 size_t i, j;
 int error;

 git_repository__free_extensions();

 for (i = 0; i < len; i++) {
  _Bool is_builtin = 0;

  for (j = 0; j < (sizeof(builtin_extensions)/sizeof(builtin_extensions[0])); j++) {
   if (strcmp(builtin_extensions[j], extensions[i]) == 0) {
    is_builtin = 1;
    break;
   }
  }

  if (is_builtin)
   continue;

  if ((extension = git__strdup(extensions[i])) == ((void*)0))
   return -1;

  if ((error = git_vector_insert_sorted(&user_extensions, extension, dup_ext_err)) < 0) {
   git__free(extension);

   if (error != GIT_EEXISTS)
    return -1;
  }
 }

 return 0;
}

void git_repository__free_extensions(void)
{
 git_vector_dispose_deep(&user_extensions);
}

int git_repository_create_head(const char *git_dir, const char *ref_name)
{
 git_str ref_path = { git_str__initstr, 0, 0 };
 git_filebuf ref = {0};
 const char *fmt;
 int error;

 if ((error = git_str_joinpath(&ref_path, git_dir, "HEAD")) < 0 ||
     (error = git_filebuf_open(&ref, ref_path.ptr, 0, 0666)) < 0)
  goto out;

 if (git__prefixcmp(ref_name, "refs/") == 0)
  fmt = "ref: %s\n";
 else
  fmt = "ref: " "refs/" "heads/" "%s\n";

 if ((error = git_filebuf_printf(&ref, fmt, ref_name)) < 0 ||
     (error = git_filebuf_commit(&ref)) < 0)
  goto out;

out:
 git_str_dispose(&ref_path);
 git_filebuf_cleanup(&ref);
 return error;
}

static _Bool is_chmod_supported(const char *file_path)
{
 struct stat st1, st2;

 if (stat(file_path, &st1) < 0)
  return 0;

 if (chmod(file_path, st1.st_mode ^ 0100) < 0)
  return 0;

 if (stat(file_path, &st2) < 0)
  return 0;

 return (st1.st_mode != st2.st_mode);
}

static _Bool is_filesystem_case_insensitive(const char *gitdir_path)
{
 git_str path = { git_str__initstr, 0, 0 };
 int is_insensitive = -1;

 if (!git_str_joinpath(&path, gitdir_path, "CoNfIg"))
  is_insensitive = git_fs_path_exists(git_str_cstr(&path));

 git_str_dispose(&path);
 return is_insensitive;
}





static int load_global_config(git_config **config, _Bool use_env)
{
 git_str global_buf = { git_str__initstr, 0, 0 };
 git_str xdg_buf = { git_str__initstr, 0, 0 };
 git_str system_buf = { git_str__initstr, 0, 0 };
 git_str programdata_buf = { git_str__initstr, 0, 0 };
 int error;

 if (!(error = config_path_system(&system_buf, use_env)) &&
     !(error = config_path_global(&global_buf, use_env))) {
  git_config__find_xdg(&xdg_buf);
  git_config__find_programdata(&programdata_buf);

  error = load_config(config, ((void*)0),
                      path_unless_empty(&global_buf),
                      path_unless_empty(&xdg_buf),
                      path_unless_empty(&system_buf),
                      path_unless_empty(&programdata_buf));
 }

 git_str_dispose(&global_buf);
 git_str_dispose(&xdg_buf);
 git_str_dispose(&system_buf);
 git_str_dispose(&programdata_buf);

 return error;
}

static _Bool are_symlinks_supported(const char *wd_path, _Bool use_env)
{
 git_config *config = ((void*)0);
 int symlinks = 0;
# 2201 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 do { __typeof__(use_env) _unused __attribute__((unused)); _unused = (use_env); } while (0);


 if (!(symlinks = git_fs_path_supports_symlinks(wd_path)))
  goto done;

done:
 git_config_free(config);
 return symlinks != 0;
}

static int create_empty_file(const char *path, mode_t mode)
{
 int fd;

 if ((fd = p_creat(path, mode)) < 0) {
  git_error_set(GIT_ERROR_OS, "error while creating '%s'", path);
  return -1;
 }

 if (close(fd) < 0) {
  git_error_set(GIT_ERROR_OS, "error while closing '%s'", path);
  return -1;
 }

 return 0;
}

static int repo_local_config(
 git_config **out,
 git_str *config_dir,
 git_repository *repo,
 const char *repo_dir)
{
 int error = 0;
 git_config *parent;
 const char *cfg_path;

 if (git_str_joinpath(config_dir, repo_dir, "config") < 0)
  return -1;
 cfg_path = git_str_cstr(config_dir);


 if (!git_fs_path_isfile(cfg_path) &&
  (error = create_empty_file(cfg_path, 0666)) < 0)
  return error;


 if (!repo)
  return git_config_open_ondisk(out, cfg_path);


 if ((error = git_repository_config__weakptr(&parent, repo)) < 0)
  return error;

 if (git_config_open_level(out, parent, GIT_CONFIG_LEVEL_LOCAL) < 0) {
  git_error_clear();

  if (!(error = git_config_add_file_ondisk(
    parent, cfg_path, GIT_CONFIG_LEVEL_LOCAL, repo, 0)))
   error = git_config_open_level(out, parent, GIT_CONFIG_LEVEL_LOCAL);
 }

 git_config_free(parent);

 return error;
}

static int repo_init_fs_configs(
 git_config *cfg,
 const char *cfg_path,
 const char *repo_dir,
 const char *work_dir,
 _Bool update_ignorecase,
 _Bool use_env)
{
 int error = 0;

 if (!work_dir)
  work_dir = repo_dir;

 if ((error = git_config_set_bool(
   cfg, "core.filemode", is_chmod_supported(cfg_path))) < 0)
  return error;

 if (!are_symlinks_supported(work_dir, use_env)) {
  if ((error = git_config_set_bool(cfg, "core.symlinks", 0)) < 0)
   return error;
 } else if (git_config_delete_entry(cfg, "core.symlinks") < 0)
  git_error_clear();

 if (update_ignorecase) {
  if (is_filesystem_case_insensitive(repo_dir)) {
   if ((error = git_config_set_bool(cfg, "core.ignorecase", 1)) < 0)
    return error;
  } else if (git_config_delete_entry(cfg, "core.ignorecase") < 0)
   git_error_clear();
 }
# 2308 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 return 0;
}

static int repo_init_config(
 const char *repo_dir,
 const char *work_dir,
 uint32_t flags,
 uint32_t mode,
 git_oid_t oid_type)
{
 int error = 0;
 git_str cfg_path = { git_str__initstr, 0, 0 }, worktree_path = { git_str__initstr, 0, 0 };
 git_config *config = ((void*)0);
 _Bool is_bare = ((flags & GIT_REPOSITORY_INIT_BARE) != 0);
 _Bool is_reinit = ((flags & GIT_REPOSITORY_INIT__IS_REINIT) != 0);
 _Bool use_env = ((flags & GIT_REPOSITORY_OPEN_FROM_ENV) != 0);
 int version = 0;

 if ((error = repo_local_config(&config, &cfg_path, ((void*)0), repo_dir)) < 0)
  goto cleanup;

 if (is_reinit &&
     (error = check_repositoryformatversion(&version, config)) < 0)
  goto cleanup;

 if ((error = check_extensions(config, version)) < 0)
  goto cleanup;





 do { if ((error = git_config_set_bool(config, "core.bare", is_bare)) < 0) goto cleanup; } while (0);
 do { if ((error = git_config_set_int32(config, "core.repositoryformatversion", version)) < 0) goto cleanup; } while (0);

 if ((error = repo_init_fs_configs(
   config, cfg_path.ptr, repo_dir, work_dir,
   !is_reinit, use_env)) < 0)
  goto cleanup;

 if (!is_bare) {
  do { if ((error = git_config_set_bool(config, "core.logallrefupdates", 1)) < 0) goto cleanup; } while (0);

  if (!(flags & GIT_REPOSITORY_INIT__NATURAL_WD)) {
   if ((error = git_str_sets(&worktree_path, work_dir)) < 0)
    goto cleanup;

   if ((flags & GIT_REPOSITORY_INIT_RELATIVE_GITLINK))
    if ((error = git_fs_path_make_relative(&worktree_path, repo_dir)) < 0)
     goto cleanup;

   do { if ((error = git_config_set_string(config, "core.worktree", worktree_path.ptr)) < 0) goto cleanup; } while (0);
  } else if (is_reinit) {
   if (git_config_delete_entry(config, "core.worktree") < 0)
    git_error_clear();
  }
 }

 if (mode == GIT_REPOSITORY_INIT_SHARED_GROUP) {
  do { if ((error = git_config_set_int32(config, "core.sharedrepository", 1)) < 0) goto cleanup; } while (0);
  do { if ((error = git_config_set_bool(config, "receive.denyNonFastforwards", 1)) < 0) goto cleanup; } while (0);
 }
 else if (mode == GIT_REPOSITORY_INIT_SHARED_ALL) {
  do { if ((error = git_config_set_int32(config, "core.sharedrepository", 2)) < 0) goto cleanup; } while (0);
  do { if ((error = git_config_set_bool(config, "receive.denyNonFastforwards", 1)) < 0) goto cleanup; } while (0);
 }

 if (oid_type != GIT_OID_SHA1) {
  do { if ((error = git_config_set_int32(config, "core.repositoryformatversion", 1)) < 0) goto cleanup; } while (0);
  do { if ((error = git_config_set_string(config, "extensions.objectformat", git_oid_type_name(oid_type))) < 0) goto cleanup; } while (0);
 }

cleanup:
 git_str_dispose(&cfg_path);
 git_str_dispose(&worktree_path);
 git_config_free(config);

 return error;
}

static int repo_reinit_submodule_fs(git_submodule *sm, const char *n, void *p)
{
 git_repository *smrepo = ((void*)0);
 do { __typeof__(n) _unused __attribute__((unused)); _unused = (n); } while (0); do { __typeof__(p) _unused __attribute__((unused)); _unused = (p); } while (0);

 if (git_submodule_open(&smrepo, sm) < 0 ||
  git_repository_reinit_filesystem(smrepo, 1) < 0)
  git_error_clear();
 git_repository_free(smrepo);

 return 0;
}

int git_repository_reinit_filesystem(git_repository *repo, int recurse)
{
 int error = 0;
 git_str path = { git_str__initstr, 0, 0 };
 git_config *config = ((void*)0);
 const char *repo_dir = git_repository_path(repo);

 if (!(error = repo_local_config(&config, &path, repo, repo_dir)))
  error = repo_init_fs_configs(config, path.ptr, repo_dir,
   git_repository_workdir(repo), 1, repo->use_env);

 git_config_free(config);
 git_str_dispose(&path);

 git_repository__configmap_lookup_cache_clear(repo);

 if (!repo->is_bare && recurse)
  (void)git_submodule_foreach(repo, repo_reinit_submodule_fs, ((void*)0));

 return error;
}

static int repo_write_template(
 const char *git_dir,
 _Bool allow_overwrite,
 const char *file,
 mode_t mode,
 _Bool hidden,
 const char *content)
{
 git_str path = { git_str__initstr, 0, 0 };
 int fd, error = 0, flags;

 if (git_str_joinpath(&path, git_dir, file) < 0)
  return -1;

 if (allow_overwrite)
  flags = 01 | 0100 | 01000;
 else
  flags = 01 | 0100 | 0200;

 fd = p_open(git_str_cstr(&path), flags, mode);

 if (fd >= 0) {
  error = p_write(fd, content, strlen(content));

  close(fd);
 }
 else if ((*__errno_location ()) != 17)
  error = fd;







 do { __typeof__(hidden) _unused __attribute__((unused)); _unused = (hidden); } while (0);


 git_str_dispose(&path);

 if (error)
  git_error_set(GIT_ERROR_OS,
   "failed to initialize repository with template '%s'", file);

 return error;
}

static int repo_write_gitlink(
 const char *in_dir, const char *to_repo, _Bool use_relative_path)
{
 int error;
 git_str buf = { git_str__initstr, 0, 0 };
 git_str path_to_repo = { git_str__initstr, 0, 0 };
 struct stat st;

 git_fs_path_dirname_r(&buf, to_repo);
 git_fs_path_to_dir(&buf);
 if (git_str_oom(&buf))
  return -1;


 if (git__suffixcmp(to_repo, "/" ".git" "/") == 0 &&
  strcmp(in_dir, buf.ptr) == 0)
 {
  error = GIT_PASSTHROUGH;
  goto cleanup;
 }

 if ((error = git_str_joinpath(&buf, in_dir, ".git")) < 0)
  goto cleanup;

 if (!stat(buf.ptr, &st) && !((((st.st_mode)) & 0170000) == (0100000))) {
  git_error_set(GIT_ERROR_REPOSITORY,
   "cannot overwrite gitlink file into path '%s'", in_dir);
  error = GIT_EEXISTS;
  goto cleanup;
 }

 git_str_clear(&buf);

 error = git_str_sets(&path_to_repo, to_repo);

 if (!error && use_relative_path)
  error = git_fs_path_make_relative(&path_to_repo, in_dir);

 if (!error)
  error = git_str_printf(&buf, "%s %s\n", "gitdir:", path_to_repo.ptr);

 if (!error)
  error = repo_write_template(in_dir, 1, ".git", 0666, 1, buf.ptr);

cleanup:
 git_str_dispose(&buf);
 git_str_dispose(&path_to_repo);
 return error;
}

static mode_t pick_dir_mode(git_repository_init_options *opts)
{
 if (opts->mode == GIT_REPOSITORY_INIT_SHARED_UMASK)
  return 0777;
 if (opts->mode == GIT_REPOSITORY_INIT_SHARED_GROUP)
  return (0775 | 02000);
 if (opts->mode == GIT_REPOSITORY_INIT_SHARED_ALL)
  return (0777 | 02000);
 return opts->mode;
}

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repo_template.h" 1
# 39 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repo_template.h"
typedef struct {
 const char *path;
 mode_t mode;
 const char *content;
} repo_template_item;

static repo_template_item repo_template[] = {
 { "objects/" "info/", 0777, ((void*)0) },
 { "objects/" "pack/", 0777, ((void*)0) },
 { "refs/" "heads/", 0777, ((void*)0) },
 { "refs/" "tags/", 0777, ((void*)0) },
 { "hooks/", 0777, ((void*)0) },
 { "info/", 0777, ((void*)0) },
 { "description", 0666, "Unnamed repository; edit this file 'description' to name the repository.\n" },
 { "hooks/" "README.sample", 0777, "#!/bin/sh\n""#\n""# Place appropriately named executable hook scripts into this directory\n""# to intercept various actions that git takes.  See `git help hooks` for\n""# more information.\n" },
 { "info/" "exclude", 0666, "# File patterns to ignore; see `git help ignore` for more information.\n""# Lines that start with '#' are comments.\n" },
 { ((void*)0), 0, ((void*)0) }
};
# 2532 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c" 2

static int repo_init_structure(
 const char *repo_dir,
 const char *work_dir,
 git_repository_init_options *opts)
{
 int error = 0;
 repo_template_item *tpl;
 _Bool external_tpl =
   opts->template_path != ((void*)0) ||
  (opts->flags & GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE) != 0;
 mode_t dmode = pick_dir_mode(opts);
 _Bool chmod = opts->mode != GIT_REPOSITORY_INIT_SHARED_UMASK;
# 2558 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 if ((opts->flags & GIT_REPOSITORY_INIT_BARE) == 0 &&
  (opts->flags & GIT_REPOSITORY_INIT__NATURAL_WD) == 0)
 {
  if (repo_write_gitlink(work_dir, repo_dir, opts->flags & GIT_REPOSITORY_INIT_RELATIVE_GITLINK) < 0)
   return -1;
 }


 if (external_tpl) {
  git_config *cfg = ((void*)0);
  const char *tdir = ((void*)0);
  _Bool default_template = 0;
  git_str template_buf = { git_str__initstr, 0, 0 };

  if (opts->template_path)
   tdir = opts->template_path;
  else if ((error = git_config_open_default(&cfg)) >= 0) {
   if (!git_config__get_path(&template_buf, cfg, "init.templatedir"))
    tdir = template_buf.ptr;
   git_error_clear();
  }

  if (!tdir) {
   if (!(error = git_sysdir_find_template_dir(&template_buf)))
    tdir = template_buf.ptr;
   default_template = 1;
  }







  if (tdir && strcmp(tdir, "") != 0) {
   uint32_t cpflags = GIT_CPDIR_COPY_SYMLINKS |
    GIT_CPDIR_SIMPLE_TO_MODE |
    GIT_CPDIR_COPY_DOTFILES;
   if (opts->mode != GIT_REPOSITORY_INIT_SHARED_UMASK)
     cpflags |= GIT_CPDIR_CHMOD_DIRS;
   error = git_futils_cp_r(tdir, repo_dir, cpflags, dmode);
  }

  git_str_dispose(&template_buf);
  git_config_free(cfg);






  if (error < 0) {
   if (!default_template && error != GIT_ENOTFOUND)
    return error;


   git_error_clear();
   external_tpl = 0;
   error = 0;
  }
 }





 for (tpl = repo_template; !error && tpl->path; ++tpl) {
  if (!tpl->content) {
   uint32_t mkdir_flags = GIT_MKDIR_PATH;
   if (chmod)
    mkdir_flags |= GIT_MKDIR_CHMOD;

   error = git_futils_mkdir_relative(
    tpl->path, repo_dir, dmode, mkdir_flags, ((void*)0));
  }
  else if (!external_tpl) {
   const char *content = tpl->content;

   if (opts->description && strcmp(tpl->path, "description") == 0)
    content = opts->description;

   error = repo_write_template(
    repo_dir, 0, tpl->path, tpl->mode, 0, content);
  }
 }

 return error;
}

static int mkdir_parent(git_str *buf, uint32_t mode, _Bool skip2)
{



 return git_futils_mkdir(
  buf->ptr, mode & ~(02000 | 0002),
  GIT_MKDIR_PATH | GIT_MKDIR_VERIFY_DIR |
  (skip2 ? GIT_MKDIR_SKIP_LAST2 : GIT_MKDIR_SKIP_LAST));
}

static int repo_init_directories(
 git_str *repo_path,
 git_str *wd_path,
 const char *given_repo,
 git_repository_init_options *opts)
{
 int error = 0;
 _Bool is_bare, add_dotgit, has_dotgit, natural_wd;
 mode_t dirmode;
# 2690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/libgit2-1.9.1/src/libgit2/repository.c"
 is_bare = ((opts->flags & GIT_REPOSITORY_INIT_BARE) != 0);

 add_dotgit =
  (opts->flags & GIT_REPOSITORY_INIT_NO_DOTGIT_DIR) == 0 &&
  !is_bare &&
  git__suffixcmp(given_repo, "/" ".git") != 0 &&
  git__suffixcmp(given_repo, "/" ".git" "/") != 0;

 if (git_str_joinpath(repo_path, given_repo, add_dotgit ? ".git" "/" : "") < 0)
  return -1;

                                    ;

 has_dotgit = (git__suffixcmp(repo_path->ptr, "/" ".git" "/") == 0);
 if (has_dotgit)
  opts->flags |= GIT_REPOSITORY_INIT__HAS_DOTGIT;



 if (!is_bare) {
  if (opts->workdir_path) {
   if (git_fs_path_join_unrooted(
     wd_path, opts->workdir_path, repo_path->ptr, ((void*)0)) < 0)
    return -1;
  } else if (has_dotgit) {
   if (git_fs_path_dirname_r(wd_path, repo_path->ptr) < 0)
    return -1;
  } else {
   git_error_set(GIT_ERROR_REPOSITORY, "cannot pick working directory"
    " for non-bare repository that isn't a '.git' directory");
   return -1;
  }

  if (git_fs_path_to_dir(wd_path) < 0)
   return -1;
 } else {
  git_str_clear(wd_path);
 }

 natural_wd =
  has_dotgit &&
  wd_path->size > 0 &&
  wd_path->size + strlen(".git" "/") == repo_path->size &&
  memcmp(repo_path->ptr, wd_path->ptr, wd_path->size) == 0;
 if (natural_wd)
  opts->flags |= GIT_REPOSITORY_INIT__NATURAL_WD;



 dirmode = pick_dir_mode(opts);

 if ((opts->flags & GIT_REPOSITORY_INIT_MKPATH) != 0) {

  if (wd_path->size > 0 &&
   (error = mkdir_parent(wd_path, dirmode, 0)) < 0)
   return error;


  if (!natural_wd &&
   (error = mkdir_parent(repo_path, dirmode, has_dotgit)) < 0)
   return error;
 }

 if ((opts->flags & GIT_REPOSITORY_INIT_MKDIR) != 0 ||
  (opts->flags & GIT_REPOSITORY_INIT_MKPATH) != 0)
 {

  if (wd_path->size > 0 &&
   (error = git_futils_mkdir(
    wd_path->ptr, dirmode & ~02000,
    GIT_MKDIR_VERIFY_DIR)) < 0)
   return error;


  if (!natural_wd &&
   (error = git_futils_mkdir(
    repo_path->ptr, dirmode & ~02000,
    GIT_MKDIR_VERIFY_DIR | GIT_MKDIR_SKIP_LAST)) < 0)
   return error;
 }

 if ((opts->flags & GIT_REPOSITORY_INIT_MKDIR) != 0 ||
  (opts->flags & GIT_REPOSITORY_INIT_MKPATH) != 0 ||
  has_dotgit)
 {

  error = git_futils_mkdir(repo_path->ptr, dirmode,
   GIT_MKDIR_VERIFY_DIR | ((dirmode & 02000) ? GIT_MKDIR_CHMOD : 0));
 }



 if (!error) {
  error = git_fs_path_prettify_dir(repo_path, repo_path->ptr, ((void*)0));

  if (!error && wd_path->size > 0)
   error = git_fs_path_prettify_dir(wd_path, wd_path->ptr, ((void*)0));
 }

 return error;
}

static int repo_init_head(const char *repo_dir, const char *given)
{
 git_config *cfg = ((void*)0);
 git_str head_path = { git_str__initstr, 0, 0 }, cfg_branch = { git_str__initstr, 0, 0 };
 const char *initial_head = ((void*)0);
 int error;

 if ((error = git_str_joinpath(&head_path, repo_dir, "HEAD")) < 0)
  goto out;





 if (git_fs_path_exists(head_path.ptr) && !given)
  goto out;

 if (given) {
  initial_head = given;
 } else if ((error = git_config_open_default(&cfg)) >= 0 &&
            (error = git_config__get_string_buf(&cfg_branch, cfg, "init.defaultbranch")) >= 0 &&
            *cfg_branch.ptr) {
  initial_head = cfg_branch.ptr;
 }

 if (!initial_head)
  initial_head = "master";

 error = git_repository_create_head(repo_dir, initial_head);

out:
 git_config_free(cfg);
 git_str_dispose(&head_path);
 git_str_dispose(&cfg_branch);

 return error;
}

static int repo_init_create_origin(git_repository *repo, const char *url)
{
 int error;
 git_remote *remote;

 if (!(error = git_remote_create(&remote, repo, "origin", url))) {
  git_remote_free(remote);
 }

 return error;
}

int git_repository_init(
 git_repository **repo_out, const char *path, unsigned is_bare)
{
 git_repository_init_options opts = {1};

 opts.flags = GIT_REPOSITORY_INIT_MKPATH;
 if (is_bare)
  opts.flags |= GIT_REPOSITORY_INIT_BARE;

 return git_repository_init_ext(repo_out, path, &opts);
}

int git_repository_init_ext(
 git_repository **out,
 const char *given_repo,
 git_repository_init_options *opts)
{
 git_str repo_path = { git_str__initstr, 0, 0 }, wd_path = { git_str__initstr, 0, 0 },
  common_path = { git_str__initstr, 0, 0 };
 const char *wd;
 _Bool is_valid;
 git_oid_t oid_type = GIT_OID_SHA1;
 int error;

 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);
 do { if (!(given_repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "given_repo"); return -1; } } while(0);
 do { if (!(opts)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "opts"); return -1; } } while(0);

 if (git_error__check_version(opts,1,"git_repository_init_options") < 0) return -1;






 if ((error = repo_init_directories(&repo_path, &wd_path, given_repo, opts)) < 0)
  goto out;

 wd = (opts->flags & GIT_REPOSITORY_INIT_BARE) ? ((void*)0) : git_str_cstr(&wd_path);

 if ((error = is_valid_repository_path(&is_valid, &repo_path, &common_path, opts->flags)) < 0)
  goto out;

 if (is_valid) {
  if ((opts->flags & GIT_REPOSITORY_INIT_NO_REINIT) != 0) {
   git_error_set(GIT_ERROR_REPOSITORY,
    "attempt to reinitialize '%s'", given_repo);
   error = GIT_EEXISTS;
   goto out;
  }

  opts->flags |= GIT_REPOSITORY_INIT__IS_REINIT;

  if ((error = repo_init_config(repo_path.ptr, wd, opts->flags, opts->mode, oid_type)) < 0)
   goto out;


 } else {
  if ((error = repo_init_structure(repo_path.ptr, wd, opts)) < 0 ||
      (error = repo_init_config(repo_path.ptr, wd, opts->flags, opts->mode, oid_type)) < 0 ||
      (error = repo_init_head(repo_path.ptr, opts->initial_head)) < 0)
   goto out;
 }

 if ((error = git_repository_open(out, repo_path.ptr)) < 0)
  goto out;

 if (opts->origin_url &&
     (error = repo_init_create_origin(*out, opts->origin_url)) < 0)
  goto out;

out:
 git_str_dispose(&common_path);
 git_str_dispose(&repo_path);
 git_str_dispose(&wd_path);

 return error;
}

int git_repository_head_detached(git_repository *repo)
{
 git_reference *ref;
 git_odb *odb = ((void*)0);
 int exists;

 if (git_repository_odb__weakptr(&odb, repo) < 0)
  return -1;

 if (git_reference_lookup(&ref, repo, "HEAD") < 0)
  return -1;

 if (git_reference_type(ref) == GIT_REFERENCE_SYMBOLIC) {
  git_reference_free(ref);
  return 0;
 }

 exists = git_odb_exists(odb, git_reference_target(ref));

 git_reference_free(ref);
 return exists;
}

int git_repository_head_detached_for_worktree(git_repository *repo, const char *name)
{
 git_reference *ref = ((void*)0);
 int error;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(name)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "name"); return -1; } } while(0);

 if ((error = git_repository_head_for_worktree(&ref, repo, name)) < 0)
  goto out;

 error = (git_reference_type(ref) != GIT_REFERENCE_SYMBOLIC);
out:
 git_reference_free(ref);

 return error;
}

int git_repository_head(git_reference **head_out, git_repository *repo)
{
 git_reference *head;
 int error;

 do { if (!(head_out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "head_out"); return -1; } } while(0);

 if ((error = git_reference_lookup(&head, repo, "HEAD")) < 0)
  return error;

 if (git_reference_type(head) == GIT_REFERENCE_DIRECT) {
  *head_out = head;
  return 0;
 }

 error = git_reference_lookup_resolved(head_out, repo, git_reference_symbolic_target(head), -1);
 git_reference_free(head);

 return error == GIT_ENOTFOUND ? GIT_EUNBORNBRANCH : error;
}

int git_repository_head_for_worktree(git_reference **out, git_repository *repo, const char *name)
{
 git_repository *worktree_repo = ((void*)0);
 git_worktree *worktree = ((void*)0);
 git_reference *head = ((void*)0);
 int error;

 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(name)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "name"); return -1; } } while(0);

 *out = ((void*)0);

 if ((error = git_worktree_lookup(&worktree, repo, name)) < 0 ||
     (error = git_repository_open_from_worktree(&worktree_repo, worktree)) < 0 ||
     (error = git_reference_lookup(&head, worktree_repo, "HEAD")) < 0)
  goto out;

 if (git_reference_type(head) != GIT_REFERENCE_DIRECT) {
  if ((error = git_reference_lookup_resolved(out, worktree_repo, git_reference_symbolic_target(head), -1)) < 0)
   goto out;
 } else {
  *out = head;
  head = ((void*)0);
 }

out:
 git_reference_free(head);
 git_worktree_free(worktree);
 git_repository_free(worktree_repo);
 return error;
}

int git_repository_foreach_worktree(git_repository *repo,
        git_repository_foreach_worktree_cb cb,
        void *payload)
{
 git_strarray worktrees = {0};
 git_repository *worktree_repo = ((void*)0);
 git_worktree *worktree = ((void*)0);
 int error;
 size_t i;




 if (!repo->commondir)
  return cb(repo, payload);

 if ((error = git_repository_open(&worktree_repo, repo->commondir)) < 0 ||
     (error = cb(worktree_repo, payload) != 0))
  goto out;

 git_repository_free(worktree_repo);
 worktree_repo = ((void*)0);

 if ((error = git_worktree_list(&worktrees, repo)) < 0)
  goto out;

 for (i = 0; i < worktrees.count; i++) {
  git_repository_free(worktree_repo);
  worktree_repo = ((void*)0);
  git_worktree_free(worktree);
  worktree = ((void*)0);

  if ((error = git_worktree_lookup(&worktree, repo, worktrees.strings[i]) < 0) ||
      (error = git_repository_open_from_worktree(&worktree_repo, worktree)) < 0) {
   if (error != GIT_ENOTFOUND)
    goto out;
   error = 0;
   continue;
  }

  if ((error = cb(worktree_repo, payload)) != 0)
   goto out;
 }

out:
 git_strarray_dispose(&worktrees);
 git_repository_free(worktree_repo);
 git_worktree_free(worktree);
 return error;
}

int git_repository_head_unborn(git_repository *repo)
{
 git_reference *ref = ((void*)0);
 int error;

 error = git_repository_head(&ref, repo);
 git_reference_free(ref);

 if (error == GIT_EUNBORNBRANCH) {
  git_error_clear();
  return 1;
 }

 if (error < 0)
  return -1;

 return 0;
}

static int repo_contains_no_reference(git_repository *repo)
{
 git_reference_iterator *iter;
 const char *refname;
 int error;

 if ((error = git_reference_iterator_new(&iter, repo)) < 0)
  return error;

 error = git_reference_next_name(&refname, iter);
 git_reference_iterator_free(iter);

 if (error == GIT_ITEROVER)
  return 1;

 return error;
}

int git_repository_initialbranch(git_str *out, git_repository *repo)
{
 git_config *config;
 git_config_entry *entry = ((void*)0);
 const char *branch;
 int valid, error;

 if ((error = git_repository_config__weakptr(&config, repo)) < 0)
  return error;

 if ((error = git_config_get_entry(&entry, config, "init.defaultbranch")) == 0 &&
  *entry->value) {
  branch = entry->value;
 }
 else if (!error || error == GIT_ENOTFOUND) {
  branch = "master";
 }
 else {
  goto done;
 }

 if ((error = git_str_puts(out, "refs/" "heads/")) < 0 ||
     (error = git_str_puts(out, branch)) < 0 ||
     (error = git_reference_name_is_valid(&valid, out->ptr)) < 0)
     goto done;

 if (!valid) {
  git_error_set(GIT_ERROR_INVALID, "the value of init.defaultBranch is not a valid branch name");
  error = -1;
 }

done:
 git_config_entry_free(entry);
 return error;
}

int git_repository_is_empty(git_repository *repo)
{
 git_reference *head = ((void*)0);
 git_str initialbranch = { git_str__initstr, 0, 0 };
 int result = 0;

 if ((result = git_reference_lookup(&head, repo, "HEAD")) < 0 ||
     (result = git_repository_initialbranch(&initialbranch, repo)) < 0)
  goto done;

 result = (git_reference_type(head) == GIT_REFERENCE_SYMBOLIC &&
           strcmp(git_reference_symbolic_target(head), initialbranch.ptr) == 0 &&
           repo_contains_no_reference(repo));

done:
 git_reference_free(head);
 git_str_dispose(&initialbranch);

 return result;
}

static const char *resolved_parent_path(const git_repository *repo, git_repository_item_t item, git_repository_item_t fallback)
{
 const char *parent;

 switch (item) {
  case GIT_REPOSITORY_ITEM_GITDIR:
   parent = git_repository_path(repo);
   break;
  case GIT_REPOSITORY_ITEM_WORKDIR:
   parent = git_repository_workdir(repo);
   break;
  case GIT_REPOSITORY_ITEM_COMMONDIR:
   parent = git_repository_commondir(repo);
   break;
  default:
   git_error_set(GIT_ERROR_INVALID, "invalid item directory");
   return ((void*)0);
 }
 if (!parent && fallback != GIT_REPOSITORY_ITEM__LAST)
  return resolved_parent_path(repo, fallback, GIT_REPOSITORY_ITEM__LAST);

 return parent;
}

int git_repository_item_path(
 git_buf *out,
 const git_repository *repo,
 git_repository_item_t item)
{
 { git_str str = { git_str__initstr, 0, 0 }; int error; if ((error = git_buf_tostr(&str, out)) == 0 && (error = git_repository__item_path(&str, repo, item)) == 0) error = git_buf_fromstr(out, &str); git_str_dispose(&str); return error; };
}

int git_repository__item_path(
 git_str *out,
 const git_repository *repo,
 git_repository_item_t item)
{
 const char *parent = resolved_parent_path(repo, items[item].parent, items[item].fallback);
 if (parent == ((void*)0)) {
  git_error_set(GIT_ERROR_INVALID, "path cannot exist in repository");
  return GIT_ENOTFOUND;
 }

 if (git_str_sets(out, parent) < 0)
  return -1;

 if (items[item].name) {
  if (git_str_joinpath(out, parent, items[item].name) < 0)
   return -1;
 }

 if (items[item].directory) {
  if (git_fs_path_to_dir(out) < 0)
   return -1;
 }

 return 0;
}

const char *git_repository_path(const git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return ((void*)0); } } while(0);
 return repo->gitdir;
}

const char *git_repository_workdir(const git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return ((void*)0); } } while(0);

 if (repo->is_bare)
  return ((void*)0);

 return repo->workdir;
}

int git_repository_workdir_path(
 git_str *out, git_repository *repo, const char *path)
{
 int error;

 if (!repo->workdir) {
  git_error_set(GIT_ERROR_REPOSITORY, "repository has no working directory");
  return GIT_EBAREREPO;
 }

 if (!(error = git_str_joinpath(out, repo->workdir, path)))
  error = git_path_validate_str_length(repo, out);

 return error;
}

const char *git_repository_commondir(const git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return ((void*)0); } } while(0);
 return repo->commondir;
}

int git_repository_set_workdir(
 git_repository *repo, const char *workdir, int update_gitlink)
{
 int error = 0;
 git_str path = { git_str__initstr, 0, 0 };

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(workdir)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "workdir"); return -1; } } while(0);

 if (git_fs_path_prettify_dir(&path, workdir, ((void*)0)) < 0)
  return -1;

 if (repo->workdir && strcmp(repo->workdir, path.ptr) == 0) {
  git_str_dispose(&path);
  return 0;
 }

 if (update_gitlink) {
  git_config *config;

  if (git_repository_config__weakptr(&config, repo) < 0) {
   git_str_dispose(&path);
   return -1;
  }

  error = repo_write_gitlink(path.ptr, git_repository_path(repo), 0);


  if (error == GIT_PASSTHROUGH)
   error = git_config_delete_entry(config, "core.worktree");
  else if (!error)
   error = git_config_set_string(config, "core.worktree", path.ptr);

  if (!error)
   error = git_config_set_bool(config, "core.bare", 0);
 }

 if (!error) {
  char *old_workdir = repo->workdir;

  repo->workdir = git_str_detach(&path);
  repo->is_bare = 0;

  git__free(old_workdir);
 }
 git_str_dispose(&path);

 return error;
}

int git_repository_is_bare(const git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 return repo->is_bare;
}

int git_repository_is_worktree(const git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 return repo->is_worktree;
}

int git_repository_set_bare(git_repository *repo)
{
 int error;
 git_config *config;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 if (repo->is_bare)
  return 0;

 if ((error = git_repository_config__weakptr(&config, repo)) < 0)
  return error;

 if ((error = git_config_set_bool(config, "core.bare", 1)) < 0)
  return error;

 if ((error = git_config__update_entry(config, "core.worktree", ((void*)0), 1, 1)) < 0)
  return error;

 git__free(repo->workdir);
 repo->workdir = ((void*)0);
 repo->is_bare = 1;

 return 0;
}

int git_repository_head_commit(git_commit **commit, git_repository *repo)
{
 git_reference *head;
 git_object *obj;
 int error;

 if ((error = git_repository_head(&head, repo)) < 0)
  return error;

 if ((error = git_reference_peel(&obj, head, GIT_OBJECT_COMMIT)) < 0)
  goto cleanup;

 *commit = (git_commit *)obj;

cleanup:
 git_reference_free(head);
 return error;
}

int git_repository_head_tree(git_tree **tree, git_repository *repo)
{
 git_reference *head;
 git_object *obj;
 int error;

 if ((error = git_repository_head(&head, repo)) < 0)
  return error;

 if ((error = git_reference_peel(&obj, head, GIT_OBJECT_TREE)) < 0)
  goto cleanup;

 *tree = (git_tree *)obj;

cleanup:
 git_reference_free(head);
 return error;
}

int git_repository__set_orig_head(git_repository *repo, const git_oid *orig_head)
{
 git_filebuf file = {0};
 git_str file_path = { git_str__initstr, 0, 0 };
 char orig_head_str[(20 * 2)];
 int error = 0;

 git_oid_fmt(orig_head_str, orig_head);

 if ((error = git_str_joinpath(&file_path, repo->gitdir, "ORIG_HEAD")) == 0 &&
  (error = git_filebuf_open(&file, file_path.ptr, (1 << 3), 0666)) == 0 &&
  (error = git_filebuf_printf(&file, "%.*s\n", (int)git_oid_hexsize(repo->oid_type), orig_head_str)) == 0)
  error = git_filebuf_commit(&file);

 if (error < 0)
  git_filebuf_cleanup(&file);

 git_str_dispose(&file_path);

 return error;
}

static int git_repository__message(git_str *out, git_repository *repo)
{
 git_str path = { git_str__initstr, 0, 0 };
 struct stat st;
 int error;

 if (git_str_joinpath(&path, repo->gitdir, "MERGE_MSG") < 0)
  return -1;

 if ((error = stat(git_str_cstr(&path), &st)) < 0) {
  if ((*__errno_location ()) == 2)
   error = GIT_ENOTFOUND;
  git_error_set(GIT_ERROR_OS, "could not access message file");
 } else {
  error = git_futils_readbuffer(out, git_str_cstr(&path));
 }

 git_str_dispose(&path);

 return error;
}

int git_repository_message(git_buf *out, git_repository *repo)
{
 { git_str str = { git_str__initstr, 0, 0 }; int error; if ((error = git_buf_tostr(&str, out)) == 0 && (error = git_repository__message(&str, repo)) == 0) error = git_buf_fromstr(out, &str); git_str_dispose(&str); return error; };
}

int git_repository_message_remove(git_repository *repo)
{
 git_str path = { git_str__initstr, 0, 0 };
 int error;

 if (git_str_joinpath(&path, repo->gitdir, "MERGE_MSG") < 0)
  return -1;

 error = unlink(git_str_cstr(&path));
 git_str_dispose(&path);

 return error;
}

int git_repository_hashfile(
 git_oid *out,
 git_repository *repo,
 const char *path,
 git_object_t type,
 const char *as_path)
{
 int error;
 git_filter_list *fl = ((void*)0);
 git_file fd = -1;
 uint64_t len;
 git_str full_path = { git_str__initstr, 0, 0 };
 const char *workdir = git_repository_workdir(repo);


 do { if (!(out)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out"); return -1; } } while(0);
 do { if (!(path)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "path"); return -1; } } while(0);
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 if ((error = git_fs_path_join_unrooted(&full_path, path, workdir, ((void*)0))) < 0 ||
     (error = git_path_validate_str_length(repo, &full_path)) < 0)
  return error;





 if (!as_path) {
  if (workdir && !git__prefixcmp(full_path.ptr, workdir))
   as_path = full_path.ptr + strlen(workdir);
  else
   as_path = "";
 }


 if (strlen(as_path) > 0) {
  error = git_filter_list_load(
   &fl, repo, ((void*)0), as_path,
   GIT_FILTER_TO_ODB, GIT_FILTER_DEFAULT);

  if (error < 0)
   return error;
 }



 fd = git_futils_open_ro(full_path.ptr);
 if (fd < 0) {
  error = fd;
  goto cleanup;
 }

 if ((error = git_futils_filesize(&len, fd)) < 0)
  goto cleanup;

 if (!git__is_sizet(len)) {
  git_error_set(GIT_ERROR_OS, "file size overflow for 32-bit systems");
  error = -1;
  goto cleanup;
 }

 error = git_odb__hashfd_filtered(out, fd, (size_t)len, type, repo->oid_type, fl);

cleanup:
 if (fd >= 0)
  close(fd);
 git_filter_list_free(fl);
 git_str_dispose(&full_path);

 return error;
}

static int checkout_message(git_str *out, git_reference *old, const char *new)
{
 const char *idstr;

 git_str_puts(out, "checkout: moving from ");

 if (git_reference_type(old) == GIT_REFERENCE_SYMBOLIC) {
  git_str_puts(out, git_reference__shorthand(git_reference_symbolic_target(old)));
 } else {
  if ((idstr = git_oid_tostr_s(git_reference_target(old))) == ((void*)0))
   return -1;

  git_str_puts(out, idstr);
 }

 git_str_puts(out, " to ");

 if (git_reference__is_branch(new) ||
  git_reference__is_tag(new) ||
  git_reference__is_remote(new))
  git_str_puts(out, git_reference__shorthand(new));
 else
  git_str_puts(out, new);

 if (git_str_oom(out))
  return -1;

 return 0;
}

static int detach(git_repository *repo, const git_oid *id, const char *new)
{
 int error;
 git_str log_message = { git_str__initstr, 0, 0 };
 git_object *object = ((void*)0), *peeled = ((void*)0);
 git_reference *new_head = ((void*)0), *current = ((void*)0);

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(id)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "id"); return -1; } } while(0);

 if ((error = git_reference_lookup(&current, repo, "HEAD")) < 0)
  return error;

 if ((error = git_object_lookup(&object, repo, id, GIT_OBJECT_ANY)) < 0)
  goto cleanup;

 if ((error = git_object_peel(&peeled, object, GIT_OBJECT_COMMIT)) < 0)
  goto cleanup;

 if (new == ((void*)0) &&
     (new = git_oid_tostr_s(git_object_id(peeled))) == ((void*)0)) {
  error = -1;
  goto cleanup;
 }

 if ((error = checkout_message(&log_message, current, new)) < 0)
  goto cleanup;

 error = git_reference_create(&new_head, repo, "HEAD", git_object_id(peeled), 1, git_str_cstr(&log_message));

cleanup:
 git_str_dispose(&log_message);
 git_object_free(object);
 git_object_free(peeled);
 git_reference_free(current);
 git_reference_free(new_head);
 return error;
}

int git_repository_set_head(
 git_repository *repo,
 const char *refname)
{
 git_reference *ref = ((void*)0), *current = ((void*)0), *new_head = ((void*)0);
 git_str log_message = { git_str__initstr, 0, 0 };
 int error;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(refname)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "refname"); return -1; } } while(0);

 if ((error = git_reference_lookup(&current, repo, "HEAD")) < 0)
  return error;

 if ((error = checkout_message(&log_message, current, refname)) < 0)
  goto cleanup;

 error = git_reference_lookup(&ref, repo, refname);
 if (error < 0 && error != GIT_ENOTFOUND)
  goto cleanup;

 if (ref && current->type == GIT_REFERENCE_SYMBOLIC && strcmp(current->target.symbolic, ref->name) &&
     git_reference_is_branch(ref) && git_branch_is_checked_out(ref)) {
  git_error_set(GIT_ERROR_REPOSITORY, "cannot set HEAD to reference '%s' as it is the current HEAD "
   "of a linked repository.", git_reference_name(ref));
  error = -1;
  goto cleanup;
 }

 if (!error) {
  if (git_reference_is_branch(ref)) {
   error = git_reference_symbolic_create(&new_head, repo, "HEAD",
     git_reference_name(ref), 1, git_str_cstr(&log_message));
  } else {
   error = detach(repo, git_reference_target(ref),
    git_reference_is_tag(ref) || git_reference_is_remote(ref) ? refname : ((void*)0));
  }
 } else if (git_reference__is_branch(refname)) {
  error = git_reference_symbolic_create(&new_head, repo, "HEAD", refname,
    1, git_str_cstr(&log_message));
 }

cleanup:
 git_str_dispose(&log_message);
 git_reference_free(current);
 git_reference_free(ref);
 git_reference_free(new_head);
 return error;
}

int git_repository_set_head_detached(
 git_repository *repo,
 const git_oid *committish)
{
 return detach(repo, committish, ((void*)0));
}

int git_repository_set_head_detached_from_annotated(
 git_repository *repo,
 const git_annotated_commit *committish)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 do { if (!(committish)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "committish"); return -1; } } while(0);

 return detach(repo, git_annotated_commit_id(committish), committish->description);
}

int git_repository_detach_head(git_repository *repo)
{
 git_reference *old_head = ((void*)0), *new_head = ((void*)0), *current = ((void*)0);
 git_object *object = ((void*)0);
 git_str log_message = { git_str__initstr, 0, 0 };
 const char *idstr;
 int error;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 if ((error = git_reference_lookup(&current, repo, "HEAD")) < 0)
  return error;

 if ((error = git_repository_head(&old_head, repo)) < 0)
  goto cleanup;

 if ((error = git_object_lookup(&object, repo, git_reference_target(old_head), GIT_OBJECT_COMMIT)) < 0)
  goto cleanup;

 if ((idstr = git_oid_tostr_s(git_object_id(object))) == ((void*)0)) {
  error = -1;
  goto cleanup;
 }

 if ((error = checkout_message(&log_message, current, idstr)) < 0)
  goto cleanup;

 error = git_reference_create(&new_head, repo, "HEAD", git_reference_target(old_head),
   1, git_str_cstr(&log_message));

cleanup:
 git_str_dispose(&log_message);
 git_object_free(object);
 git_reference_free(old_head);
 git_reference_free(new_head);
 git_reference_free(current);
 return error;
}





int git_repository_state(git_repository *repo)
{
 git_str repo_path = { git_str__initstr, 0, 0 };
 int state = GIT_REPOSITORY_STATE_NONE;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 if (git_str_puts(&repo_path, repo->gitdir) < 0)
  return -1;

 if (git_fs_path_contains_file(&repo_path, "rebase-merge/" "interactive"))
  state = GIT_REPOSITORY_STATE_REBASE_INTERACTIVE;
 else if (git_fs_path_contains_dir(&repo_path, "rebase-merge/"))
  state = GIT_REPOSITORY_STATE_REBASE_MERGE;
 else if (git_fs_path_contains_file(&repo_path, "rebase-apply/" "rebasing"))
  state = GIT_REPOSITORY_STATE_REBASE;
 else if (git_fs_path_contains_file(&repo_path, "rebase-apply/" "applying"))
  state = GIT_REPOSITORY_STATE_APPLY_MAILBOX;
 else if (git_fs_path_contains_dir(&repo_path, "rebase-apply/"))
  state = GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE;
 else if (git_fs_path_contains_file(&repo_path, "MERGE_HEAD"))
  state = GIT_REPOSITORY_STATE_MERGE;
 else if (git_fs_path_contains_file(&repo_path, "REVERT_HEAD")) {
  state = GIT_REPOSITORY_STATE_REVERT;
  if (git_fs_path_contains_file(&repo_path, "sequencer/" "todo")) {
   state = GIT_REPOSITORY_STATE_REVERT_SEQUENCE;
  }
 } else if (git_fs_path_contains_file(&repo_path, "CHERRY_PICK_HEAD")) {
  state = GIT_REPOSITORY_STATE_CHERRYPICK;
  if (git_fs_path_contains_file(&repo_path, "sequencer/" "todo")) {
   state = GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE;
  }
 } else if (git_fs_path_contains_file(&repo_path, "BISECT_LOG"))
  state = GIT_REPOSITORY_STATE_BISECT;

 git_str_dispose(&repo_path);
 return state;
}

int git_repository__cleanup_files(
 git_repository *repo, const char *files[], size_t files_len)
{
 git_str buf = { git_str__initstr, 0, 0 };
 size_t i;
 int error;

 for (error = 0, i = 0; !error && i < files_len; ++i) {
  const char *path;

  if (git_str_joinpath(&buf, repo->gitdir, files[i]) < 0)
   return -1;

  path = git_str_cstr(&buf);

  if (git_fs_path_isfile(path)) {
   error = unlink(path);
  } else if (git_fs_path_isdir(path)) {
   error = git_futils_rmdir_r(path, ((void*)0),
    GIT_RMDIR_REMOVE_FILES | GIT_RMDIR_REMOVE_BLOCKERS);
  }

  git_str_clear(&buf);
 }

 git_str_dispose(&buf);
 return error;
}

static const char *state_files[] = {
 "MERGE_HEAD",
 "MERGE_MODE",
 "MERGE_MSG",
 "REVERT_HEAD",
 "CHERRY_PICK_HEAD",
 "BISECT_LOG",
 "rebase-merge/",
 "rebase-apply/",
 "sequencer/",
};

int git_repository_state_cleanup(git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 return git_repository__cleanup_files(repo, state_files, (sizeof(state_files)/sizeof(state_files[0])));
}

int git_repository__shallow_roots(
 git_oid **out,
 size_t *out_len,
 git_repository *repo)
{
 int error = 0;

 if (!repo->shallow_grafts && (error = load_grafts(repo)) < 0)
  return error;

 if ((error = git_grafts_refresh(repo->shallow_grafts)) < 0)
  return error;

 if ((error = git_grafts_oids(out, out_len, repo->shallow_grafts)) < 0)
  return error;

 return 0;
}

int git_repository__shallow_roots_write(git_repository *repo, git_oidarray *roots)
{
 git_filebuf file = {0};
 git_str path = { git_str__initstr, 0, 0 };
 char oid_str[(20 * 2) + 1];
 size_t i;
 int filebuf_hash, error = 0;

 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 filebuf_hash = git_filebuf_hash_flags(git_oid_algorithm(repo->oid_type));
 do { if (!(filebuf_hash)) { git_error_set(GIT_ERROR_INTERNAL, "%s: '%s'", "unrecoverable internal error", "filebuf_hash"); return -1; } } while(0);

 if ((error = git_str_joinpath(&path, repo->gitdir, "shallow")) < 0)
  goto on_error;

 if ((error = git_filebuf_open(&file, git_str_cstr(&path), filebuf_hash, 0666)) < 0)
  goto on_error;

 for (i = 0; i < roots->count; i++) {
  git_oid_tostr(oid_str, sizeof(oid_str), &roots->ids[i]);
  git_filebuf_write(&file, oid_str, git_oid_hexsize(repo->oid_type));
  git_filebuf_write(&file, "\n", 1);
 }

 git_filebuf_commit(&file);

 if ((error = load_grafts(repo)) < 0) {
  error = -1;
  goto on_error;
 }

 if (!roots->count)
  remove(path.ptr);

on_error:
 git_str_dispose(&path);

 return error;
}

int git_repository_is_shallow(git_repository *repo)
{
 git_str path = { git_str__initstr, 0, 0 };
 struct stat st;
 int error;

 if ((error = git_str_joinpath(&path, repo->gitdir, "shallow")) < 0)
  return error;

 error = git_fs_path_lstat(path.ptr, &st);
 git_str_dispose(&path);

 if (error == GIT_ENOTFOUND) {
  git_error_clear();
  return 0;
 }

 if (error < 0)
  return error;

 return st.st_size == 0 ? 0 : 1;
}

int git_repository_init_options_init(
 git_repository_init_options *opts, unsigned int version)
{
 do { git_repository_init_options _tmpl = {1}; if (git_error__check_version(&(version),_tmpl.version,"git_repository_init_options") < 0) return -1; memcpy((opts), &_tmpl, sizeof(_tmpl)); } while (0);


 return 0;
}


int git_repository_init_init_options(
 git_repository_init_options *opts, unsigned int version)
{
 return git_repository_init_options_init(opts, version);
}


int git_repository_ident(const char **name, const char **email, const git_repository *repo)
{
 *name = repo->ident_name;
 *email = repo->ident_email;

 return 0;
}

int git_repository_set_ident(git_repository *repo, const char *name, const char *email)
{
 char *tmp_name = ((void*)0), *tmp_email = ((void*)0);

 if (name) {
  tmp_name = git__strdup(name);
  do { if ((tmp_name) == ((void*)0)) { return -1; } } while(0);
 }

 if (email) {
  tmp_email = git__strdup(email);
  do { if ((tmp_email) == ((void*)0)) { return -1; } } while(0);
 }

 tmp_name = (void *)git_atomic__swap((void * volatile *)&(repo->ident_name), tmp_name);
 tmp_email = (void *)git_atomic__swap((void * volatile *)&(repo->ident_email), tmp_email);

 git__free(tmp_name);
 git__free(tmp_email);

 return 0;
}

int git_repository_submodule_cache_all(git_repository *repo)
{
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);
 return git_submodule_cache_init(&repo->submodule_cache, repo);
}

int git_repository_submodule_cache_clear(git_repository *repo)
{
 int error = 0;
 do { if (!(repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "repo"); return -1; } } while(0);

 error = git_submodule_cache_free(repo->submodule_cache);
 repo->submodule_cache = ((void*)0);
 return error;
}

git_oid_t git_repository_oid_type(git_repository *repo)
{
 return repo ? repo->oid_type : 0;
}

struct mergehead_data {
 git_repository *repo;
 git_vector *parents;
};

static int insert_mergehead(const git_oid *oid, void *payload)
{
 git_commit *commit;
 struct mergehead_data *data = (struct mergehead_data *)payload;

 if (git_commit_lookup(&commit, data->repo, oid) < 0)
  return -1;

 return git_vector_insert(data->parents, commit);
}

int git_repository_commit_parents(git_commitarray *out, git_repository *repo)
{
 git_commit *first_parent = ((void*)0), *commit;
 git_reference *head_ref = ((void*)0);
 git_vector parents = {0};
 struct mergehead_data data;
 size_t i;
 int error;

 do { if (!(out && repo)) { git_error_set(GIT_ERROR_INVALID, "%s: '%s'", "invalid argument", "out && repo"); return -1; } } while(0);

 out->count = 0;
 out->commits = ((void*)0);

 error = git_revparse_ext((git_object **)&first_parent, &head_ref, repo, "HEAD");

 if (error != 0) {
  if (error == GIT_ENOTFOUND)
   error = 0;

  goto done;
 }

 if ((error = git_vector_insert(&parents, first_parent)) < 0)
  goto done;

 data.repo = repo;
 data.parents = &parents;

 error = git_repository_mergehead_foreach(repo, insert_mergehead, &data);

 if (error == GIT_ENOTFOUND)
  error = 0;
 else if (error != 0)
  goto done;

 out->commits = (git_commit **)git_vector_detach(&out->count, ((void*)0), &parents);

done:
 for ((i) = 0; (i) < (&parents)->length && ((commit) = (&parents)->contents[(i)], 1); (i)++ )
  git__free(commit);

 git_reference_free(head_ref);
 return error;
}

int git_repository__abbrev_length(int *out, git_repository *repo)
{
 size_t oid_hexsize;
 int len;
 int error;

 oid_hexsize = git_oid_hexsize(repo->oid_type);

 if ((error = git_repository__configmap_lookup(&len, repo, GIT_CONFIGMAP_ABBREV)) < 0)
  return error;

 if (len < GIT_ABBREV_MINIMUM) {
  git_error_set(GIT_ERROR_CONFIG, "invalid oid abbreviation setting: '%d'", len);
  return -1;
 }

 if (len == GIT_ABBREV_FALSE || (size_t)len > oid_hexsize)
  len = (int)oid_hexsize;

 *out = len;

 return error;
}
