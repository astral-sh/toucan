# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_common.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 389 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_common.c" 2
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_common.c"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd_errors.h" 1
# 60 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd_errors.h"
typedef enum {
  ZSTD_error_no_error = 0,
  ZSTD_error_GENERIC = 1,
  ZSTD_error_prefix_unknown = 10,
  ZSTD_error_version_unsupported = 12,
  ZSTD_error_frameParameter_unsupported = 14,
  ZSTD_error_frameParameter_windowTooLarge = 16,
  ZSTD_error_corruption_detected = 20,
  ZSTD_error_checksum_wrong = 22,
  ZSTD_error_literals_headerWrong = 24,
  ZSTD_error_dictionary_corrupted = 30,
  ZSTD_error_dictionary_wrong = 32,
  ZSTD_error_dictionaryCreation_failed = 34,
  ZSTD_error_parameter_unsupported = 40,
  ZSTD_error_parameter_combination_unsupported = 41,
  ZSTD_error_parameter_outOfBound = 42,
  ZSTD_error_tableLog_tooLarge = 44,
  ZSTD_error_maxSymbolValue_tooLarge = 46,
  ZSTD_error_maxSymbolValue_tooSmall = 48,
  ZSTD_error_cannotProduce_uncompressedBlock = 49,
  ZSTD_error_stabilityCondition_notRespected = 50,
  ZSTD_error_stage_wrong = 60,
  ZSTD_error_init_missing = 62,
  ZSTD_error_memory_allocation = 64,
  ZSTD_error_workSpace_tooSmall= 66,
  ZSTD_error_dstSize_tooSmall = 70,
  ZSTD_error_srcSize_wrong = 72,
  ZSTD_error_dstBuffer_null = 74,
  ZSTD_error_noForwardProgress_destFull = 80,
  ZSTD_error_noForwardProgress_inputEmpty = 82,

  ZSTD_error_frameIndex_tooLarge = 100,
  ZSTD_error_seekableIO = 102,
  ZSTD_error_dstBuffer_wrong = 104,
  ZSTD_error_srcBuffer_wrong = 105,
  ZSTD_error_sequenceProducer_failed = 106,
  ZSTD_error_externalSequences_invalid = 107,
  ZSTD_error_maxCode = 120
} ZSTD_ErrorCode;

__attribute__ ((visibility ("default"))) const char* ZSTD_getErrorString(ZSTD_ErrorCode code);
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 72 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 73 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3
# 18 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3
# 87 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h" 1 3
# 24 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 88 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3
# 107 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_max_align_t.h" 1 3
# 19 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_max_align_t.h" 3
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
# 108 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_offsetof.h" 1 3
# 113 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/portability_macros.h" 1
# 162 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/portability_macros.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/cet.h" 1 3
# 163 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/portability_macros.h" 2
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h" 2
# 226 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 1 3
# 17 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 1 3
# 17 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 1 3
# 17 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
typedef long long __m64 __attribute__((__vector_size__(8), __aligned__(8)));

typedef long long __v1di __attribute__((__vector_size__(8)));
typedef int __v2si __attribute__((__vector_size__(8)));
typedef short __v4hi __attribute__((__vector_size__(8)));
typedef char __v8qi __attribute__((__vector_size__(8)));
# 36 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__,
                                      __target__("mmx,no-evex512")))
_mm_empty(void) {
  __builtin_ia32_emms();
}
# 53 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cvtsi32_si64(int __i)
{
    return (__m64)__builtin_ia32_vec_init_v2si(__i, 0);
}
# 70 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cvtsi64_si32(__m64 __m)
{
    return __builtin_ia32_vec_ext_v2si((__v2si)__m, 0);
}
# 86 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cvtsi64_m64(long long __i)
{
    return (__m64)__i;
}
# 102 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cvtm64_si64(__m64 __m)
{
    return (long long)__m;
}
# 132 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_packs_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_packsswb((__v4hi)__m1, (__v4hi)__m2);
}
# 162 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_packs_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_packssdw((__v2si)__m1, (__v2si)__m2);
}
# 192 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_packs_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_packuswb((__v4hi)__m1, (__v4hi)__m2);
}
# 219 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_unpackhi_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_punpckhbw((__v8qi)__m1, (__v8qi)__m2);
}
# 242 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_unpackhi_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_punpckhwd((__v4hi)__m1, (__v4hi)__m2);
}
# 263 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_unpackhi_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_punpckhdq((__v2si)__m1, (__v2si)__m2);
}
# 290 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_unpacklo_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_punpcklbw((__v8qi)__m1, (__v8qi)__m2);
}
# 313 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_unpacklo_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_punpcklwd((__v4hi)__m1, (__v4hi)__m2);
}
# 334 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_unpacklo_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_punpckldq((__v2si)__m1, (__v2si)__m2);
}
# 355 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_add_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddb((__v8qi)__m1, (__v8qi)__m2);
}
# 376 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_add_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddw((__v4hi)__m1, (__v4hi)__m2);
}
# 397 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_add_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddd((__v2si)__m1, (__v2si)__m2);
}
# 419 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_adds_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddsb((__v8qi)__m1, (__v8qi)__m2);
}
# 442 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_adds_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddsw((__v4hi)__m1, (__v4hi)__m2);
}
# 464 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_adds_pu8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddusb((__v8qi)__m1, (__v8qi)__m2);
}
# 486 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_adds_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_paddusw((__v4hi)__m1, (__v4hi)__m2);
}
# 507 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sub_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubb((__v8qi)__m1, (__v8qi)__m2);
}
# 528 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sub_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubw((__v4hi)__m1, (__v4hi)__m2);
}
# 549 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sub_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubd((__v2si)__m1, (__v2si)__m2);
}
# 572 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_subs_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubsb((__v8qi)__m1, (__v8qi)__m2);
}
# 595 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_subs_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubsw((__v4hi)__m1, (__v4hi)__m2);
}
# 619 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_subs_pu8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubusb((__v8qi)__m1, (__v8qi)__m2);
}
# 643 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_subs_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_psubusw((__v4hi)__m1, (__v4hi)__m2);
}
# 670 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_madd_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pmaddwd((__v4hi)__m1, (__v4hi)__m2);
}
# 691 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_mulhi_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pmulhw((__v4hi)__m1, (__v4hi)__m2);
}
# 712 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_mullo_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pmullw((__v4hi)__m1, (__v4hi)__m2);
}
# 735 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sll_pi16(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psllw((__v4hi)__m, __count);
}
# 757 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_slli_pi16(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psllwi((__v4hi)__m, __count);
}
# 780 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sll_pi32(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_pslld((__v2si)__m, __count);
}
# 802 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_slli_pi32(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_pslldi((__v2si)__m, __count);
}
# 822 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sll_si64(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psllq((__v1di)__m, __count);
}
# 842 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_slli_si64(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psllqi((__v1di)__m, __count);
}
# 866 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sra_pi16(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psraw((__v4hi)__m, __count);
}
# 889 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srai_pi16(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psrawi((__v4hi)__m, __count);
}
# 913 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_sra_pi32(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psrad((__v2si)__m, __count);
}
# 936 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srai_pi32(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psradi((__v2si)__m, __count);
}
# 959 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srl_pi16(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psrlw((__v4hi)__m, __count);
}
# 981 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srli_pi16(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psrlwi((__v4hi)__m, __count);
}
# 1004 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srl_pi32(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psrld((__v2si)__m, __count);
}
# 1026 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srli_pi32(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psrldi((__v2si)__m, __count);
}
# 1046 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srl_si64(__m64 __m, __m64 __count)
{
    return (__m64)__builtin_ia32_psrlq((__v1di)__m, __count);
}
# 1067 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_srli_si64(__m64 __m, int __count)
{
    return (__m64)__builtin_ia32_psrlqi((__v1di)__m, __count);
}
# 1085 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_and_si64(__m64 __m1, __m64 __m2)
{
    return __builtin_ia32_pand((__v1di)__m1, (__v1di)__m2);
}
# 1106 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_andnot_si64(__m64 __m1, __m64 __m2)
{
    return __builtin_ia32_pandn((__v1di)__m1, (__v1di)__m2);
}
# 1124 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_or_si64(__m64 __m1, __m64 __m2)
{
    return __builtin_ia32_por((__v1di)__m1, (__v1di)__m2);
}
# 1142 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_xor_si64(__m64 __m1, __m64 __m2)
{
    return __builtin_ia32_pxor((__v1di)__m1, (__v1di)__m2);
}
# 1164 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cmpeq_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pcmpeqb((__v8qi)__m1, (__v8qi)__m2);
}
# 1186 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cmpeq_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pcmpeqw((__v4hi)__m1, (__v4hi)__m2);
}
# 1208 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cmpeq_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pcmpeqd((__v2si)__m1, (__v2si)__m2);
}
# 1230 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cmpgt_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pcmpgtb((__v8qi)__m1, (__v8qi)__m2);
}
# 1252 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cmpgt_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pcmpgtw((__v4hi)__m1, (__v4hi)__m2);
}
# 1274 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_cmpgt_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_ia32_pcmpgtd((__v2si)__m1, (__v2si)__m2);
}
# 1287 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_setzero_si64(void)
{
    return __extension__ (__m64){ 0LL };
}
# 1308 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_set_pi32(int __i1, int __i0)
{
    return (__m64)__builtin_ia32_vec_init_v2si(__i0, __i1);
}
# 1331 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_set_pi16(short __s3, short __s2, short __s1, short __s0)
{
    return (__m64)__builtin_ia32_vec_init_v4hi(__s0, __s1, __s2, __s3);
}
# 1362 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_set_pi8(char __b7, char __b6, char __b5, char __b4, char __b3, char __b2,
            char __b1, char __b0)
{
    return (__m64)__builtin_ia32_vec_init_v8qi(__b0, __b1, __b2, __b3,
                                               __b4, __b5, __b6, __b7);
}
# 1383 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_set1_pi32(int __i)
{
    return _mm_set_pi32(__i, __i);
}
# 1402 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_set1_pi16(short __w)
{
    return _mm_set_pi16(__w, __w, __w, __w);
}
# 1420 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_set1_pi8(char __b)
{
    return _mm_set_pi8(__b, __b, __b, __b, __b, __b, __b, __b);
}
# 1441 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_setr_pi32(int __i0, int __i1)
{
    return _mm_set_pi32(__i1, __i0);
}
# 1464 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_setr_pi16(short __w0, short __w1, short __w2, short __w3)
{
    return _mm_set_pi16(__w3, __w2, __w1, __w0);
}
# 1495 "/usr/lib/llvm-18/lib/clang/18/include/mmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,no-evex512"), __min_vector_width__(64)))
_mm_setr_pi8(char __b0, char __b1, char __b2, char __b3, char __b4, char __b5,
             char __b6, char __b7)
{
    return _mm_set_pi8(__b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}
# 18 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 2 3

typedef int __v4si __attribute__((__vector_size__(16)));
typedef float __v4sf __attribute__((__vector_size__(16)));
typedef float __m128 __attribute__((__vector_size__(16), __aligned__(16)));

typedef float __m128_u __attribute__((__vector_size__(16), __aligned__(1)));


typedef unsigned int __v4su __attribute__((__vector_size__(16)));




# 1 "/usr/lib/llvm-18/lib/clang/18/include/mm_malloc.h" 1 3
# 13 "/usr/lib/llvm-18/lib/clang/18/include/mm_malloc.h" 3
# 1 "/usr/include/stdlib.h" 1 3 4
# 26 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 480 "/usr/include/features.h" 3 4
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 481 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 27 "/usr/include/stdlib.h" 2 3 4





# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 87 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_wchar_t.h" 1 3 4
# 88 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4




# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 33 "/usr/include/stdlib.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/waitflags.h" 1 3 4
# 41 "/usr/include/stdlib.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/waitstatus.h" 1 3 4
# 42 "/usr/include/stdlib.h" 2 3 4
# 56 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 119 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 120 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 57 "/usr/include/stdlib.h" 2 3 4


typedef struct
  {
    int quot;
    int rem;
  } div_t;



typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;





__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
# 98 "/usr/include/stdlib.h" 3 4
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ )) ;



extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;

extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;



extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 177 "/usr/include/stdlib.h" 3 4
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));




__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 505 "/usr/include/stdlib.h" 3 4
extern char *l64a (long int __n) __attribute__ ((__nothrow__ )) ;


extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;




# 1 "/usr/include/x86_64-linux-gnu/sys/types.h" 1 3 4
# 29 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 30 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;


typedef __loff_t loff_t;




typedef __ino_t ino_t;
# 59 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __dev_t dev_t;




typedef __gid_t gid_t;




typedef __mode_t mode_t;




typedef __nlink_t nlink_t;




typedef __uid_t uid_t;





typedef __off_t off_t;
# 97 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
typedef __pid_t pid_t;





typedef __id_t id_t;




typedef __ssize_t ssize_t;





typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;





typedef __key_t key_t;




# 1 "/usr/include/x86_64-linux-gnu/bits/types/clock_t.h" 1 3 4






typedef __clock_t clock_t;
# 127 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/clockid_t.h" 1 3 4






typedef __clockid_t clockid_t;
# 129 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/time_t.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/bits/types/time_t.h" 3 4
typedef __time_t time_t;
# 130 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/timer_t.h" 1 3 4






typedef __timer_t timer_t;
# 131 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 144 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 145 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4



typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 156 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4


typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;


typedef int register_t __attribute__ ((__mode__ (__word__)));
# 176 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/endian.h" 1 3 4
# 24 "/usr/include/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/endian.h" 1 3 4
# 35 "/usr/include/x86_64-linux-gnu/bits/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/endianness.h" 1 3 4
# 36 "/usr/include/x86_64-linux-gnu/bits/endian.h" 2 3 4
# 25 "/usr/include/endian.h" 2 3 4
# 35 "/usr/include/endian.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 3 4
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{



  return ((__uint16_t) ((((__bsx) >> 8) & 0xff) | (((__bsx) & 0xff) << 8)));

}






static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{



  return ((((__bsx) & 0xff000000u) >> 24) | (((__bsx) & 0x00ff0000u) >> 8) | (((__bsx) & 0x0000ff00u) << 8) | (((__bsx) & 0x000000ffu) << 24));

}
# 69 "/usr/include/x86_64-linux-gnu/bits/byteswap.h" 3 4
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{



  return ((((__bsx) & 0xff00000000000000ull) >> 56) | (((__bsx) & 0x00ff000000000000ull) >> 40) | (((__bsx) & 0x0000ff0000000000ull) >> 24) | (((__bsx) & 0x000000ff00000000ull) >> 8) | (((__bsx) & 0x00000000ff000000ull) << 8) | (((__bsx) & 0x0000000000ff0000ull) << 24) | (((__bsx) & 0x000000000000ff00ull) << 40) | (((__bsx) & 0x00000000000000ffull) << 56));

}
# 36 "/usr/include/endian.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 1 3 4
# 32 "/usr/include/x86_64-linux-gnu/bits/uintn-identity.h" 3 4
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}

static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}

static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
# 37 "/usr/include/endian.h" 2 3 4
# 177 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/sys/select.h" 1 3 4
# 30 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/select.h" 1 3 4
# 31 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/types/sigset_t.h" 1 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h" 1 3 4




typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
# 5 "/usr/include/x86_64-linux-gnu/bits/types/sigset_t.h" 2 3 4


typedef __sigset_t sigset_t;
# 34 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h" 1 3 4







struct timeval
{




  __time_t tv_sec;
  __suseconds_t tv_usec;

};
# 38 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 3 4
struct timespec
{



  __time_t tv_sec;




  __syscall_slong_t tv_nsec;
# 31 "/usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h" 3 4
};
# 40 "/usr/include/x86_64-linux-gnu/sys/select.h" 2 3 4



typedef __suseconds_t suseconds_t;





typedef long int __fd_mask;
# 59 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
typedef struct
  {






    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];


  } fd_set;






typedef __fd_mask fd_mask;
# 102 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
# 127 "/usr/include/x86_64-linux-gnu/sys/select.h" 3 4
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
# 180 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4





typedef __blksize_t blksize_t;






typedef __blkcnt_t blkcnt_t;



typedef __fsblkcnt_t fsblkcnt_t;



typedef __fsfilcnt_t fsfilcnt_t;
# 227 "/usr/include/x86_64-linux-gnu/sys/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 1 3 4
# 44 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 1 3 4
# 21 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h" 2 3 4
# 45 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h" 3 4
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
# 47 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4




typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;

typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
# 76 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 3 4
struct __pthread_mutex_s
{
  int __lock;
  unsigned int __count;
  int __owner;

  unsigned int __nusers;



  int __kind;

  short __spins;
  short __elision;
  __pthread_list_t __list;
# 53 "/usr/include/x86_64-linux-gnu/bits/struct_mutex.h" 3 4
};
# 77 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4
# 89 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 1 3 4
# 23 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 3 4
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;

  int __cur_writer;
  int __shared;
  signed char __rwelision;




  unsigned char __pad1[7];


  unsigned long int __pad2;


  unsigned int __flags;
# 55 "/usr/include/x86_64-linux-gnu/bits/struct_rwlock.h" 3 4
};
# 90 "/usr/include/x86_64-linux-gnu/bits/thread-shared-types.h" 2 3 4




struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};

typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;

typedef struct
{
  int __data ;
} __once_flag;
# 24 "/usr/include/x86_64-linux-gnu/bits/pthreadtypes.h" 2 3 4



typedef unsigned long int pthread_t;




typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;




typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;



typedef unsigned int pthread_key_t;



typedef int pthread_once_t;


union pthread_attr_t
{
  char __size[56];
  long int __align;
};

typedef union pthread_attr_t pthread_attr_t;




typedef union
{
  struct __pthread_mutex_s __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;


typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;





typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;

typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;





typedef volatile int pthread_spinlock_t;




typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;

typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;
# 228 "/usr/include/x86_64-linux-gnu/sys/types.h" 2 3 4
# 515 "/usr/include/stdlib.h" 2 3 4






extern long int random (void) __attribute__ ((__nothrow__ ));


extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ ));





extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));



extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };

extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));

extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)));

extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));





extern int rand (void) __attribute__ ((__nothrow__ ));

extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ ));



extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ ));







extern double drand48 (void) __attribute__ ((__nothrow__ ));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern long int lrand48 (void) __attribute__ ((__nothrow__ ));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern long int mrand48 (void) __attribute__ ((__nothrow__ ));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ ));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;

  };


extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));

extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ )) ;


extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));



extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ )) ;




extern void *malloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;

extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;






extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__)) ;


extern void free (void *__ptr) __attribute__ ((__nothrow__ ));







extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__))

                       ;


extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) ;



# 1 "/usr/include/alloca.h" 1 3 4
# 24 "/usr/include/alloca.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 25 "/usr/include/alloca.h" 2 3 4







extern void *alloca (size_t __size) __attribute__ ((__nothrow__ ));
# 707 "/usr/include/stdlib.h" 2 3 4





extern void *valloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;




extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;




extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
                                         ;



extern void abort (void) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));



extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));







extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));






extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern void exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));





extern void quick_exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));





extern void _Exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));




extern char *getenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 786 "/usr/include/stdlib.h" 3 4
extern int putenv (char *__string) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));





extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));


extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));






extern int clearenv (void) __attribute__ ((__nothrow__ ));
# 814 "/usr/include/stdlib.h" 3 4
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 827 "/usr/include/stdlib.h" 3 4
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
# 849 "/usr/include/stdlib.h" 3 4
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
# 870 "/usr/include/stdlib.h" 3 4
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 923 "/usr/include/stdlib.h" 3 4
extern int system (const char *__command) ;
# 940 "/usr/include/stdlib.h" 3 4
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ )) ;






typedef int (*__compar_fn_t) (const void *, const void *);
# 960 "/usr/include/stdlib.h" 3 4
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;







extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
# 980 "/usr/include/stdlib.h" 3 4
extern int abs (int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;


__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;






extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;


__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
# 1012 "/usr/include/stdlib.h" 3 4
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;




extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;




extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;




extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));

extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));





extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ ));


extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ));


extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ ));



extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ))
                                      ;

extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ ))

                                    ;






extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
# 1099 "/usr/include/stdlib.h" 3 4
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3))) ;
# 1145 "/usr/include/stdlib.h" 3 4
extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 1155 "/usr/include/stdlib.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/stdlib-float.h" 1 3 4
# 1156 "/usr/include/stdlib.h" 2 3 4
# 14 "/usr/lib/llvm-18/lib/clang/18/include/mm_malloc.h" 2 3





extern int posix_memalign(void **__memptr, size_t __alignment, size_t __size);
# 30 "/usr/lib/llvm-18/lib/clang/18/include/mm_malloc.h" 3
static __inline__ void *__attribute__((__always_inline__, __nodebug__,
                                       __malloc__, __alloc_size__(1),
                                       __alloc_align__(2)))
_mm_malloc(size_t __size, size_t __align) {
  if (__align == 1) {
    return malloc(__size);
  }

  if (!(__align & (__align - 1)) && __align < sizeof(void *))
    __align = sizeof(void *);

  void *__mallocedMemory;





  if (posix_memalign(&__mallocedMemory, __align, __size))
    return 0;


  return __mallocedMemory;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_free(void *__p)
{





  free(__p);

}
# 32 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 2 3
# 57 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_add_ss(__m128 __a, __m128 __b)
{
  __a[0] += __b[0];
  return __a;
}
# 77 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_add_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4sf)__a + (__v4sf)__b);
}
# 99 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_sub_ss(__m128 __a, __m128 __b)
{
  __a[0] -= __b[0];
  return __a;
}
# 120 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_sub_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4sf)__a - (__v4sf)__b);
}
# 142 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_mul_ss(__m128 __a, __m128 __b)
{
  __a[0] *= __b[0];
  return __a;
}
# 162 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_mul_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4sf)__a * (__v4sf)__b);
}
# 184 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_div_ss(__m128 __a, __m128 __b)
{
  __a[0] /= __b[0];
  return __a;
}
# 203 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_div_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4sf)__a / (__v4sf)__b);
}
# 221 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_sqrt_ss(__m128 __a)
{
  return (__m128)__builtin_ia32_sqrtss((__v4sf)__a);
}
# 238 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_sqrt_ps(__m128 __a)
{
  return __builtin_ia32_sqrtps((__v4sf)__a);
}
# 256 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_rcp_ss(__m128 __a)
{
  return (__m128)__builtin_ia32_rcpss((__v4sf)__a);
}
# 273 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_rcp_ps(__m128 __a)
{
  return (__m128)__builtin_ia32_rcpps((__v4sf)__a);
}
# 292 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_rsqrt_ss(__m128 __a)
{
  return __builtin_ia32_rsqrtss((__v4sf)__a);
}
# 309 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_rsqrt_ps(__m128 __a)
{
  return __builtin_ia32_rsqrtps((__v4sf)__a);
}
# 332 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_min_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_minss((__v4sf)__a, (__v4sf)__b);
}
# 351 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_min_ps(__m128 __a, __m128 __b)
{
  return __builtin_ia32_minps((__v4sf)__a, (__v4sf)__b);
}
# 374 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_max_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_maxss((__v4sf)__a, (__v4sf)__b);
}
# 393 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_max_ps(__m128 __a, __m128 __b)
{
  return __builtin_ia32_maxps((__v4sf)__a, (__v4sf)__b);
}
# 411 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_and_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4su)__a & (__v4su)__b);
}
# 433 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_andnot_ps(__m128 __a, __m128 __b)
{
  return (__m128)(~(__v4su)__a & (__v4su)__b);
}
# 451 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_or_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4su)__a | (__v4su)__b);
}
# 470 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_xor_ps(__m128 __a, __m128 __b)
{
  return (__m128)((__v4su)__a ^ (__v4su)__b);
}
# 492 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpeq_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpeqss((__v4sf)__a, (__v4sf)__b);
}
# 510 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpeq_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpeqps((__v4sf)__a, (__v4sf)__b);
}
# 533 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmplt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltss((__v4sf)__a, (__v4sf)__b);
}
# 552 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmplt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltps((__v4sf)__a, (__v4sf)__b);
}
# 576 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmple_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpless((__v4sf)__a, (__v4sf)__b);
}
# 595 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmple_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpleps((__v4sf)__a, (__v4sf)__b);
}
# 618 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpgt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpltss((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
# 639 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpgt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltps((__v4sf)__b, (__v4sf)__a);
}
# 663 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpge_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpless((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
# 684 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpge_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpleps((__v4sf)__b, (__v4sf)__a);
}
# 707 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpneq_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpneqss((__v4sf)__a, (__v4sf)__b);
}
# 726 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpneq_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpneqps((__v4sf)__a, (__v4sf)__b);
}
# 750 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpnlt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltss((__v4sf)__a, (__v4sf)__b);
}
# 770 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpnlt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltps((__v4sf)__a, (__v4sf)__b);
}
# 795 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpnle_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnless((__v4sf)__a, (__v4sf)__b);
}
# 815 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpnle_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnleps((__v4sf)__a, (__v4sf)__b);
}
# 840 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpngt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpnltss((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
# 862 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpngt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltps((__v4sf)__b, (__v4sf)__a);
}
# 887 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpnge_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpnless((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
# 909 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpnge_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnleps((__v4sf)__b, (__v4sf)__a);
}
# 934 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpord_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpordss((__v4sf)__a, (__v4sf)__b);
}
# 954 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpord_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpordps((__v4sf)__a, (__v4sf)__b);
}
# 979 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpunord_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpunordss((__v4sf)__a, (__v4sf)__b);
}
# 999 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cmpunord_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpunordps((__v4sf)__a, (__v4sf)__b);
}
# 1023 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_comieq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comieq((__v4sf)__a, (__v4sf)__b);
}
# 1048 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_comilt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comilt((__v4sf)__a, (__v4sf)__b);
}
# 1072 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_comile_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comile((__v4sf)__a, (__v4sf)__b);
}
# 1096 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_comigt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comigt((__v4sf)__a, (__v4sf)__b);
}
# 1120 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_comige_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comige((__v4sf)__a, (__v4sf)__b);
}
# 1144 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_comineq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comineq((__v4sf)__a, (__v4sf)__b);
}
# 1168 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_ucomieq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomieq((__v4sf)__a, (__v4sf)__b);
}
# 1192 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_ucomilt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomilt((__v4sf)__a, (__v4sf)__b);
}
# 1217 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_ucomile_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomile((__v4sf)__a, (__v4sf)__b);
}
# 1242 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_ucomigt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomigt((__v4sf)__a, (__v4sf)__b);
}
# 1267 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_ucomige_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomige((__v4sf)__a, (__v4sf)__b);
}
# 1291 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_ucomineq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomineq((__v4sf)__a, (__v4sf)__b);
}
# 1309 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvtss_si32(__m128 __a)
{
  return __builtin_ia32_cvtss2si((__v4sf)__a);
}
# 1327 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvt_ss2si(__m128 __a)
{
  return _mm_cvtss_si32(__a);
}
# 1347 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvtss_si64(__m128 __a)
{
  return __builtin_ia32_cvtss2si64((__v4sf)__a);
}
# 1365 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtps_pi32(__m128 __a)
{
  return (__m64)__builtin_ia32_cvtps2pi((__v4sf)__a);
}
# 1381 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvt_ps2pi(__m128 __a)
{
  return _mm_cvtps_pi32(__a);
}
# 1400 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvttss_si32(__m128 __a)
{
  return __builtin_ia32_cvttss2si((__v4sf)__a);
}
# 1419 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvtt_ss2si(__m128 __a)
{
  return _mm_cvttss_si32(__a);
}
# 1439 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvttss_si64(__m128 __a)
{
  return __builtin_ia32_cvttss2si64((__v4sf)__a);
}
# 1458 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvttps_pi32(__m128 __a)
{
  return (__m64)__builtin_ia32_cvttps2pi((__v4sf)__a);
}
# 1475 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtt_ps2pi(__m128 __a)
{
  return _mm_cvttps_pi32(__a);
}
# 1497 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvtsi32_ss(__m128 __a, int __b)
{
  __a[0] = __b;
  return __a;
}
# 1520 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvt_si2ss(__m128 __a, int __b)
{
  return _mm_cvtsi32_ss(__a, __b);
}
# 1544 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvtsi64_ss(__m128 __a, long long __b)
{
  __a[0] = __b;
  return __a;
}
# 1570 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtpi32_ps(__m128 __a, __m64 __b)
{
  return __builtin_ia32_cvtpi2ps((__v4sf)__a, (__v2si)__b);
}
# 1593 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvt_pi2ps(__m128 __a, __m64 __b)
{
  return _mm_cvtpi32_ps(__a, __b);
}
# 1610 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ float __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_cvtss_f32(__m128 __a)
{
  return __a[0];
}
# 1631 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_loadh_pi(__m128 __a, const __m64 *__p)
{
  typedef float __mm_loadh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_loadh_pi_struct {
    __mm_loadh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  __mm_loadh_pi_v2f32 __b = ((const struct __mm_loadh_pi_struct*)__p)->__u;
  __m128 __bb = __builtin_shufflevector(__b, __b, 0, 1, 0, 1);
  return __builtin_shufflevector(__a, __bb, 0, 1, 4, 5);
}
# 1658 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_loadl_pi(__m128 __a, const __m64 *__p)
{
  typedef float __mm_loadl_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_loadl_pi_struct {
    __mm_loadl_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  __mm_loadl_pi_v2f32 __b = ((const struct __mm_loadl_pi_struct*)__p)->__u;
  __m128 __bb = __builtin_shufflevector(__b, __b, 0, 1, 0, 1);
  return __builtin_shufflevector(__a, __bb, 4, 5, 2, 3);
}
# 1685 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_load_ss(const float *__p)
{
  struct __mm_load_ss_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  float __u = ((const struct __mm_load_ss_struct*)__p)->__u;
  return __extension__ (__m128){ __u, 0, 0, 0 };
}
# 1707 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_load1_ps(const float *__p)
{
  struct __mm_load1_ps_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  float __u = ((const struct __mm_load1_ps_struct*)__p)->__u;
  return __extension__ (__m128){ __u, __u, __u, __u };
}
# 1730 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_load_ps(const float *__p)
{
  return *(const __m128*)__p;
}
# 1747 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_loadu_ps(const float *__p)
{
  struct __loadu_ps {
    __m128_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_ps*)__p)->__v;
}
# 1769 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_loadr_ps(const float *__p)
{
  __m128 __a = _mm_load_ps(__p);
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 3, 2, 1, 0);
}
# 1783 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_undefined_ps(void)
{
  return (__m128)__builtin_ia32_undef128();
}
# 1803 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_set_ss(float __w)
{
  return __extension__ (__m128){ __w, 0, 0, 0 };
}
# 1821 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_set1_ps(float __w)
{
  return __extension__ (__m128){ __w, __w, __w, __w };
}
# 1840 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_set_ps1(float __w)
{
    return _mm_set1_ps(__w);
}
# 1867 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_set_ps(float __z, float __y, float __x, float __w)
{
  return __extension__ (__m128){ __w, __x, __y, __z };
}
# 1895 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_setr_ps(float __z, float __y, float __x, float __w)
{
  return __extension__ (__m128){ __z, __y, __x, __w };
}
# 1910 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_setzero_ps(void)
{
  return __extension__ (__m128){ 0.0f, 0.0f, 0.0f, 0.0f };
}
# 1927 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_storeh_pi(__m64 *__p, __m128 __a)
{
  typedef float __mm_storeh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_storeh_pi_struct {
    __mm_storeh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pi_struct*)__p)->__u = __builtin_shufflevector(__a, __a, 2, 3);
}
# 1948 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_storel_pi(__m64 *__p, __m128 __a)
{
  typedef float __mm_storeh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_storeh_pi_struct {
    __mm_storeh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pi_struct*)__p)->__u = __builtin_shufflevector(__a, __a, 0, 1);
}
# 1969 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_store_ss(float *__p, __m128 __a)
{
  struct __mm_store_ss_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store_ss_struct*)__p)->__u = __a[0];
}
# 1990 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_storeu_ps(float *__p, __m128 __a)
{
  struct __storeu_ps {
    __m128_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_ps*)__p)->__v = __a;
}
# 2011 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_store_ps(float *__p, __m128 __a)
{
  *(__m128*)__p = __a;
}
# 2030 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_store1_ps(float *__p, __m128 __a)
{
  __a = __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 0, 0, 0, 0);
  _mm_store_ps(__p, __a);
}
# 2050 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_store_ps1(float *__p, __m128 __a)
{
  _mm_store1_ps(__p, __a);
}
# 2069 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_storer_ps(float *__p, __m128 __a)
{
  __a = __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 3, 2, 1, 0);
  _mm_store_ps(__p, __a);
}
# 2127 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_stream_pi(void *__p, __m64 __a)
{
  __builtin_ia32_movntq((__m64 *)__p, __a);
}
# 2146 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_stream_ps(void *__p, __m128 __a)
{
  __builtin_nontemporal_store((__v4sf)__a, (__v4sf*)__p);
}
# 2165 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
void _mm_sfence(void);
# 2238 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_max_pi16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pmaxsw((__v4hi)__a, (__v4hi)__b);
}
# 2257 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_max_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pmaxub((__v8qi)__a, (__v8qi)__b);
}
# 2276 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_min_pi16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pminsw((__v4hi)__a, (__v4hi)__b);
}
# 2295 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_min_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pminub((__v8qi)__a, (__v8qi)__b);
}
# 2313 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_movemask_pi8(__m64 __a)
{
  return __builtin_ia32_pmovmskb((__v8qi)__a);
}
# 2332 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_mulhi_pu16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pmulhuw((__v4hi)__a, (__v4hi)__b);
}
# 2398 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_maskmove_si64(__m64 __d, __m64 __n, char *__p)
{
  __builtin_ia32_maskmovq((__v8qi)__d, (__v8qi)__n, __p);
}
# 2417 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_avg_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pavgb((__v8qi)__a, (__v8qi)__b);
}
# 2436 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_avg_pu16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_pavgw((__v4hi)__a, (__v4hi)__b);
}
# 2458 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_sad_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_ia32_psadbw((__v8qi)__a, (__v8qi)__b);
}
# 2518 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
unsigned int _mm_getcsr(void);
# 2572 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
void _mm_setcsr(unsigned int __i);
# 2637 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_unpackhi_ps(__m128 __a, __m128 __b)
{
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 2, 6, 3, 7);
}
# 2659 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_unpacklo_ps(__m128 __a, __m128 __b)
{
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 0, 4, 1, 5);
}
# 2681 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_move_ss(__m128 __a, __m128 __b)
{
  __a[0] = __b[0];
  return __a;
}
# 2703 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_movehl_ps(__m128 __a, __m128 __b)
{
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 6, 7, 2, 3);
}
# 2724 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_movelh_ps(__m128 __a, __m128 __b)
{
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 0, 1, 4, 5);
}
# 2742 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtpi16_ps(__m64 __a)
{
  __m64 __b, __c;
  __m128 __r;

  __b = _mm_setzero_si64();
  __b = _mm_cmpgt_pi16(__b, __a);
  __c = _mm_unpackhi_pi16(__a, __b);
  __r = _mm_setzero_ps();
  __r = _mm_cvtpi32_ps(__r, __c);
  __r = _mm_movelh_ps(__r, __r);
  __c = _mm_unpacklo_pi16(__a, __b);
  __r = _mm_cvtpi32_ps(__r, __c);

  return __r;
}
# 2772 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtpu16_ps(__m64 __a)
{
  __m64 __b, __c;
  __m128 __r;

  __b = _mm_setzero_si64();
  __c = _mm_unpackhi_pi16(__a, __b);
  __r = _mm_setzero_ps();
  __r = _mm_cvtpi32_ps(__r, __c);
  __r = _mm_movelh_ps(__r, __r);
  __c = _mm_unpacklo_pi16(__a, __b);
  __r = _mm_cvtpi32_ps(__r, __c);

  return __r;
}
# 2801 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtpi8_ps(__m64 __a)
{
  __m64 __b;

  __b = _mm_setzero_si64();
  __b = _mm_cmpgt_pi8(__b, __a);
  __b = _mm_unpacklo_pi8(__a, __b);

  return _mm_cvtpi16_ps(__b);
}
# 2826 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtpu8_ps(__m64 __a)
{
  __m64 __b;

  __b = _mm_setzero_si64();
  __b = _mm_unpacklo_pi8(__a, __b);

  return _mm_cvtpi16_ps(__b);
}
# 2853 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtpi32x2_ps(__m64 __a, __m64 __b)
{
  __m128 __c;

  __c = _mm_setzero_ps();
  __c = _mm_cvtpi32_ps(__c, __b);
  __c = _mm_movelh_ps(__c, __c);

  return _mm_cvtpi32_ps(__c, __a);
}
# 2882 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtps_pi16(__m128 __a)
{
  __m64 __b, __c;

  __b = _mm_cvtps_pi32(__a);
  __a = _mm_movehl_ps(__a, __a);
  __c = _mm_cvtps_pi32(__a);

  return _mm_packs_pi32(__b, __c);
}
# 2912 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse,no-evex512"), __min_vector_width__(64)))
_mm_cvtps_pi8(__m128 __a)
{
  __m64 __b, __c;

  __b = _mm_cvtps_pi16(__a);
  __c = _mm_setzero_si64();

  return _mm_packs_pi16(__b, __c);
}
# 2937 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse,no-evex512"), __min_vector_width__(128)))
_mm_movemask_ps(__m128 __a)
{
  return __builtin_ia32_movmskps((__v4sf)__a);
}
# 3018 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 3
# 1 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 1 3
# 3019 "/usr/lib/llvm-18/lib/clang/18/include/xmmintrin.h" 2 3
# 18 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 2 3

typedef double __m128d __attribute__((__vector_size__(16), __aligned__(16)));
typedef long long __m128i __attribute__((__vector_size__(16), __aligned__(16)));

typedef double __m128d_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef long long __m128i_u
    __attribute__((__vector_size__(16), __aligned__(1)));


typedef double __v2df __attribute__((__vector_size__(16)));
typedef long long __v2di __attribute__((__vector_size__(16)));
typedef short __v8hi __attribute__((__vector_size__(16)));
typedef char __v16qi __attribute__((__vector_size__(16)));


typedef unsigned long long __v2du __attribute__((__vector_size__(16)));
typedef unsigned short __v8hu __attribute__((__vector_size__(16)));
typedef unsigned char __v16qu __attribute__((__vector_size__(16)));



typedef signed char __v16qs __attribute__((__vector_size__(16)));



typedef _Float16 __v8hf __attribute__((__vector_size__(16), __aligned__(16)));
typedef _Float16 __m128h __attribute__((__vector_size__(16), __aligned__(16)));
typedef _Float16 __m128h_u __attribute__((__vector_size__(16), __aligned__(1)));

typedef __bf16 __v8bf __attribute__((__vector_size__(16), __aligned__(16)));
typedef __bf16 __m128bh __attribute__((__vector_size__(16), __aligned__(16)));
# 74 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_add_sd(__m128d __a,
                                                        __m128d __b) {
  __a[0] += __b[0];
  return __a;
}
# 92 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_add_pd(__m128d __a,
                                                        __m128d __b) {
  return (__m128d)((__v2df)__a + (__v2df)__b);
}
# 114 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sub_sd(__m128d __a,
                                                        __m128d __b) {
  __a[0] -= __b[0];
  return __a;
}
# 132 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sub_pd(__m128d __a,
                                                        __m128d __b) {
  return (__m128d)((__v2df)__a - (__v2df)__b);
}
# 153 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_mul_sd(__m128d __a,
                                                        __m128d __b) {
  __a[0] *= __b[0];
  return __a;
}
# 171 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_mul_pd(__m128d __a,
                                                        __m128d __b) {
  return (__m128d)((__v2df)__a * (__v2df)__b);
}
# 193 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_div_sd(__m128d __a,
                                                        __m128d __b) {
  __a[0] /= __b[0];
  return __a;
}
# 212 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_div_pd(__m128d __a,
                                                        __m128d __b) {
  return (__m128d)((__v2df)__a / (__v2df)__b);
}
# 236 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sqrt_sd(__m128d __a,
                                                         __m128d __b) {
  __m128d __c = __builtin_ia32_sqrtsd((__v2df)__b);
  return __extension__(__m128d){__c[0], __a[1]};
}
# 253 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sqrt_pd(__m128d __a) {
  return __builtin_ia32_sqrtpd((__v2df)__a);
}
# 275 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_min_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_minsd((__v2df)__a, (__v2df)__b);
}
# 294 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_min_pd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_minpd((__v2df)__a, (__v2df)__b);
}
# 317 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_max_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_maxsd((__v2df)__a, (__v2df)__b);
}
# 336 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_max_pd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_maxpd((__v2df)__a, (__v2df)__b);
}
# 353 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_and_pd(__m128d __a,
                                                        __m128d __b) {
  return (__m128d)((__v2du)__a & (__v2du)__b);
}
# 373 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_andnot_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)(~(__v2du)__a & (__v2du)__b);
}
# 390 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_or_pd(__m128d __a,
                                                       __m128d __b) {
  return (__m128d)((__v2du)__a | (__v2du)__b);
}
# 407 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_xor_pd(__m128d __a,
                                                        __m128d __b) {
  return (__m128d)((__v2du)__a ^ (__v2du)__b);
}
# 425 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpeq_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpeqpd((__v2df)__a, (__v2df)__b);
}
# 444 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmplt_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltpd((__v2df)__a, (__v2df)__b);
}
# 464 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmple_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplepd((__v2df)__a, (__v2df)__b);
}
# 484 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpgt_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltpd((__v2df)__b, (__v2df)__a);
}
# 504 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpge_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplepd((__v2df)__b, (__v2df)__a);
}
# 526 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpord_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpordpd((__v2df)__a, (__v2df)__b);
}
# 549 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpunord_pd(__m128d __a,
                                                             __m128d __b) {
  return (__m128d)__builtin_ia32_cmpunordpd((__v2df)__a, (__v2df)__b);
}
# 569 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpneq_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpneqpd((__v2df)__a, (__v2df)__b);
}
# 589 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpnlt_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltpd((__v2df)__a, (__v2df)__b);
}
# 609 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpnle_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlepd((__v2df)__a, (__v2df)__b);
}
# 629 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpngt_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltpd((__v2df)__b, (__v2df)__a);
}
# 649 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpnge_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlepd((__v2df)__b, (__v2df)__a);
}
# 671 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpeq_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpeqsd((__v2df)__a, (__v2df)__b);
}
# 695 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmplt_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltsd((__v2df)__a, (__v2df)__b);
}
# 719 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmple_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplesd((__v2df)__a, (__v2df)__b);
}
# 743 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpgt_sd(__m128d __a,
                                                          __m128d __b) {
  __m128d __c = __builtin_ia32_cmpltsd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
# 768 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpge_sd(__m128d __a,
                                                          __m128d __b) {
  __m128d __c = __builtin_ia32_cmplesd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
# 795 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpord_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpordsd((__v2df)__a, (__v2df)__b);
}
# 822 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpunord_sd(__m128d __a,
                                                             __m128d __b) {
  return (__m128d)__builtin_ia32_cmpunordsd((__v2df)__a, (__v2df)__b);
}
# 846 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpneq_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpneqsd((__v2df)__a, (__v2df)__b);
}
# 870 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpnlt_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltsd((__v2df)__a, (__v2df)__b);
}
# 894 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpnle_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlesd((__v2df)__a, (__v2df)__b);
}
# 918 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpngt_sd(__m128d __a,
                                                           __m128d __b) {
  __m128d __c = __builtin_ia32_cmpnltsd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
# 943 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpnge_sd(__m128d __a,
                                                           __m128d __b) {
  __m128d __c = __builtin_ia32_cmpnlesd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
# 967 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_comieq_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdeq((__v2df)__a, (__v2df)__b);
}
# 992 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_comilt_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdlt((__v2df)__a, (__v2df)__b);
}
# 1017 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_comile_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdle((__v2df)__a, (__v2df)__b);
}
# 1042 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_comigt_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdgt((__v2df)__a, (__v2df)__b);
}
# 1067 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_comige_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdge((__v2df)__a, (__v2df)__b);
}
# 1092 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_comineq_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_comisdneq((__v2df)__a, (__v2df)__b);
}
# 1115 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_ucomieq_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdeq((__v2df)__a, (__v2df)__b);
}
# 1140 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_ucomilt_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdlt((__v2df)__a, (__v2df)__b);
}
# 1165 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_ucomile_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdle((__v2df)__a, (__v2df)__b);
}
# 1190 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_ucomigt_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdgt((__v2df)__a, (__v2df)__b);
}
# 1215 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_ucomige_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdge((__v2df)__a, (__v2df)__b);
}
# 1240 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_ucomineq_sd(__m128d __a,
                                                         __m128d __b) {
  return __builtin_ia32_ucomisdneq((__v2df)__a, (__v2df)__b);
}
# 1258 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtpd_ps(__m128d __a) {
  return __builtin_ia32_cvtpd2ps((__v2df)__a);
}
# 1276 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtps_pd(__m128 __a) {
  return (__m128d) __builtin_convertvector(
      __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 0, 1), __v2df);
}
# 1297 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtepi32_pd(__m128i __a) {
  return (__m128d) __builtin_convertvector(
      __builtin_shufflevector((__v4si)__a, (__v4si)__a, 0, 1), __v2df);
}
# 1315 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtpd_epi32(__m128d __a) {
  return __builtin_ia32_cvtpd2dq((__v2df)__a);
}
# 1330 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsd_si32(__m128d __a) {
  return __builtin_ia32_cvtsd2si((__v2df)__a);
}
# 1353 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsd_ss(__m128 __a,
                                                         __m128d __b) {
  return (__m128)__builtin_ia32_cvtsd2ss((__v4sf)__a, (__v2df)__b);
}
# 1375 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsi32_sd(__m128d __a,
                                                            int __b) {
  __a[0] = __b;
  return __a;
}
# 1400 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtss_sd(__m128d __a,
                                                          __m128 __b) {
  __a[0] = __b[0];
  return __a;
}
# 1423 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvttpd_epi32(__m128d __a) {
  return (__m128i)__builtin_ia32_cvttpd2dq((__v2df)__a);
}
# 1439 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvttsd_si32(__m128d __a) {
  return __builtin_ia32_cvttsd2si((__v2df)__a);
}
# 1454 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse2,no-evex512"), __min_vector_width__(64))) _mm_cvtpd_pi32(__m128d __a) {
  return (__m64)__builtin_ia32_cvtpd2pi((__v2df)__a);
}
# 1472 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse2,no-evex512"), __min_vector_width__(64))) _mm_cvttpd_pi32(__m128d __a) {
  return (__m64)__builtin_ia32_cvttpd2pi((__v2df)__a);
}
# 1487 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse2,no-evex512"), __min_vector_width__(64))) _mm_cvtpi32_pd(__m64 __a) {
  return __builtin_ia32_cvtpi2pd((__v2si)__a);
}
# 1502 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ double __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsd_f64(__m128d __a) {
  return __a[0];
}
# 1517 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_load_pd(double const *__dp) {
  return *(const __m128d *)__dp;
}
# 1533 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_load1_pd(double const *__dp) {
  struct __mm_load1_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_load1_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, __u};
}
# 1557 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadr_pd(double const *__dp) {
  __m128d __u = *(const __m128d *)__dp;
  return __builtin_shufflevector((__v2df)__u, (__v2df)__u, 1, 0);
}
# 1573 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadu_pd(double const *__dp) {
  struct __loadu_pd {
    __m128d_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_pd *)__dp)->__v;
}
# 1591 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadu_si64(void const *__a) {
  struct __loadu_si64 {
    long long __v;
  } __attribute__((__packed__, __may_alias__));
  long long __u = ((const struct __loadu_si64 *)__a)->__v;
  return __extension__(__m128i)(__v2di){__u, 0LL};
}
# 1610 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadu_si32(void const *__a) {
  struct __loadu_si32 {
    int __v;
  } __attribute__((__packed__, __may_alias__));
  int __u = ((const struct __loadu_si32 *)__a)->__v;
  return __extension__(__m128i)(__v4si){__u, 0, 0, 0};
}
# 1629 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadu_si16(void const *__a) {
  struct __loadu_si16 {
    short __v;
  } __attribute__((__packed__, __may_alias__));
  short __u = ((const struct __loadu_si16 *)__a)->__v;
  return __extension__(__m128i)(__v8hi){__u, 0, 0, 0, 0, 0, 0, 0};
}
# 1648 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_load_sd(double const *__dp) {
  struct __mm_load_sd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_load_sd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, 0};
}
# 1673 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadh_pd(__m128d __a,
                                                          double const *__dp) {
  struct __mm_loadh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_loadh_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__a[0], __u};
}
# 1699 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_loadl_pd(__m128d __a,
                                                          double const *__dp) {
  struct __mm_loadl_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_loadl_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, __a[1]};
}
# 1719 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_undefined_pd(void) {
  return (__m128d)__builtin_ia32_undef128();
}
# 1737 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set_sd(double __w) {
  return __extension__(__m128d){__w, 0};
}
# 1753 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set1_pd(double __w) {
  return __extension__(__m128d){__w, __w};
}
# 1769 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set_pd1(double __w) {
  return _mm_set1_pd(__w);
}
# 1787 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set_pd(double __w,
                                                        double __x) {
  return __extension__(__m128d){__x, __w};
}
# 1807 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_setr_pd(double __w,
                                                         double __x) {
  return __extension__(__m128d){__w, __x};
}
# 1821 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_setzero_pd(void) {
  return __extension__(__m128d){0.0, 0.0};
}
# 1840 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_move_sd(__m128d __a,
                                                         __m128d __b) {
  __a[0] = __b[0];
  return __a;
}
# 1857 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_store_sd(double *__dp,
                                                       __m128d __a) {
  struct __mm_store_sd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store_sd_struct *)__dp)->__u = __a[0];
}
# 1878 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_store_pd(double *__dp,
                                                       __m128d __a) {
  *(__m128d *)__dp = __a;
}
# 1897 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_store1_pd(double *__dp,
                                                        __m128d __a) {
  __a = __builtin_shufflevector((__v2df)__a, (__v2df)__a, 0, 0);
  _mm_store_pd(__dp, __a);
}
# 1917 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_store_pd1(double *__dp,
                                                        __m128d __a) {
  _mm_store1_pd(__dp, __a);
}
# 1934 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storeu_pd(double *__dp,
                                                        __m128d __a) {
  struct __storeu_pd {
    __m128d_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_pd *)__dp)->__v = __a;
}
# 1956 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storer_pd(double *__dp,
                                                        __m128d __a) {
  __a = __builtin_shufflevector((__v2df)__a, (__v2df)__a, 1, 0);
  *(__m128d *)__dp = __a;
}
# 1973 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storeh_pd(double *__dp,
                                                        __m128d __a) {
  struct __mm_storeh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pd_struct *)__dp)->__u = __a[1];
}
# 1992 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storel_pd(double *__dp,
                                                        __m128d __a) {
  struct __mm_storeh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pd_struct *)__dp)->__u = __a[0];
}
# 2016 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_add_epi8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v16qu)__a + (__v16qu)__b);
}
# 2037 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_add_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v8hu)__a + (__v8hu)__b);
}
# 2058 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_add_epi32(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v4su)__a + (__v4su)__b);
}
# 2075 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse2,no-evex512"), __min_vector_width__(64))) _mm_add_si64(__m64 __a,
                                                            __m64 __b) {
  return (__m64)__builtin_ia32_paddq((__v1di)__a, (__v1di)__b);
}
# 2096 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_add_epi64(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a + (__v2du)__b);
}
# 2116 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_adds_epi8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v16qs)__a, (__v16qs)__b);
}
# 2137 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_adds_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v8hi)__a, (__v8hi)__b);
}
# 2157 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_adds_epu8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v16qu)__a, (__v16qu)__b);
}
# 2177 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_adds_epu16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v8hu)__a, (__v8hu)__b);
}
# 2196 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_avg_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_ia32_pavgb128((__v16qi)__a, (__v16qi)__b);
}
# 2215 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_avg_epu16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_ia32_pavgw128((__v8hi)__a, (__v8hi)__b);
}
# 2240 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_madd_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_ia32_pmaddwd128((__v8hi)__a, (__v8hi)__b);
}
# 2259 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_max_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_max((__v8hi)__a, (__v8hi)__b);
}
# 2278 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_max_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_elementwise_max((__v16qu)__a, (__v16qu)__b);
}
# 2297 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_min_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_min((__v8hi)__a, (__v8hi)__b);
}
# 2316 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_min_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_elementwise_min((__v16qu)__a, (__v16qu)__b);
}
# 2335 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_mulhi_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_pmulhw128((__v8hi)__a, (__v8hi)__b);
}
# 2354 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_mulhi_epu16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_pmulhuw128((__v8hi)__a, (__v8hi)__b);
}
# 2373 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_mullo_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hu)__a * (__v8hu)__b);
}
# 2391 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse2,no-evex512"), __min_vector_width__(64))) _mm_mul_su32(__m64 __a,
                                                            __m64 __b) {
  return __builtin_ia32_pmuludq((__v2si)__a, (__v2si)__b);
}
# 2409 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_mul_epu32(__m128i __a,
                                                           __m128i __b) {
  return __builtin_ia32_pmuludq128((__v4si)__a, (__v4si)__b);
}
# 2430 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sad_epu8(__m128i __a,
                                                          __m128i __b) {
  return __builtin_ia32_psadbw128((__v16qi)__a, (__v16qi)__b);
}
# 2447 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sub_epi8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v16qu)__a - (__v16qu)__b);
}
# 2464 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sub_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v8hu)__a - (__v8hu)__b);
}
# 2481 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sub_epi32(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v4su)__a - (__v4su)__b);
}
# 2499 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("mmx,sse2,no-evex512"), __min_vector_width__(64))) _mm_sub_si64(__m64 __a,
                                                            __m64 __b) {
  return (__m64)__builtin_ia32_psubq((__v1di)__a, (__v1di)__b);
}
# 2516 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sub_epi64(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a - (__v2du)__b);
}
# 2536 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_subs_epi8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v16qs)__a, (__v16qs)__b);
}
# 2556 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_subs_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v8hi)__a, (__v8hi)__b);
}
# 2575 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_subs_epu8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v16qu)__a, (__v16qu)__b);
}
# 2594 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_subs_epu16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v8hu)__a, (__v8hu)__b);
}
# 2611 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_and_si128(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a & (__v2du)__b);
}
# 2630 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_andnot_si128(__m128i __a,
                                                              __m128i __b) {
  return (__m128i)(~(__v2du)__a & (__v2du)__b);
}
# 2646 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_or_si128(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v2du)__a | (__v2du)__b);
}
# 2663 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_xor_si128(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a ^ (__v2du)__b);
}
# 2706 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_slli_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psllwi128((__v8hi)__a, __count);
}
# 2724 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sll_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psllw128((__v8hi)__a, (__v8hi)__count);
}
# 2742 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_slli_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_pslldi128((__v4si)__a, __count);
}
# 2760 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sll_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_pslld128((__v4si)__a, (__v4si)__count);
}
# 2778 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_slli_epi64(__m128i __a,
                                                            int __count) {
  return __builtin_ia32_psllqi128((__v2di)__a, __count);
}
# 2796 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sll_epi64(__m128i __a,
                                                           __m128i __count) {
  return __builtin_ia32_psllq128((__v2di)__a, (__v2di)__count);
}
# 2815 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srai_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrawi128((__v8hi)__a, __count);
}
# 2834 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sra_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psraw128((__v8hi)__a, (__v8hi)__count);
}
# 2853 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srai_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psradi128((__v4si)__a, __count);
}
# 2872 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_sra_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrad128((__v4si)__a, (__v4si)__count);
}
# 2915 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srli_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrlwi128((__v8hi)__a, __count);
}
# 2933 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srl_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrlw128((__v8hi)__a, (__v8hi)__count);
}
# 2951 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srli_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrldi128((__v4si)__a, __count);
}
# 2969 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srl_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrld128((__v4si)__a, (__v4si)__count);
}
# 2987 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srli_epi64(__m128i __a,
                                                            int __count) {
  return __builtin_ia32_psrlqi128((__v2di)__a, __count);
}
# 3005 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_srl_epi64(__m128i __a,
                                                           __m128i __count) {
  return __builtin_ia32_psrlq128((__v2di)__a, (__v2di)__count);
}
# 3023 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpeq_epi8(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)((__v16qi)__a == (__v16qi)__b);
}
# 3041 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpeq_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hi)__a == (__v8hi)__b);
}
# 3059 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpeq_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v4si)__a == (__v4si)__b);
}
# 3078 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpgt_epi8(__m128i __a,
                                                            __m128i __b) {


  return (__m128i)((__v16qs)__a > (__v16qs)__b);
}
# 3100 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpgt_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hi)__a > (__v8hi)__b);
}
# 3120 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmpgt_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v4si)__a > (__v4si)__b);
}
# 3140 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmplt_epi8(__m128i __a,
                                                            __m128i __b) {
  return _mm_cmpgt_epi8(__b, __a);
}
# 3160 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmplt_epi16(__m128i __a,
                                                             __m128i __b) {
  return _mm_cmpgt_epi16(__b, __a);
}
# 3180 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cmplt_epi32(__m128i __a,
                                                             __m128i __b) {
  return _mm_cmpgt_epi32(__b, __a);
}
# 3203 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsi64_sd(__m128d __a,
                                                            long long __b) {
  __a[0] = __b;
  return __a;
}
# 3220 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsd_si64(__m128d __a) {
  return __builtin_ia32_cvtsd2si64((__v2df)__a);
}
# 3236 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvttsd_si64(__m128d __a) {
  return __builtin_ia32_cvttsd2si64((__v2df)__a);
}
# 3250 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtepi32_ps(__m128i __a) {
  return (__m128) __builtin_convertvector((__v4si)__a, __v4sf);
}
# 3264 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtps_epi32(__m128 __a) {
  return (__m128i)__builtin_ia32_cvtps2dq((__v4sf)__a);
}
# 3279 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvttps_epi32(__m128 __a) {
  return (__m128i)__builtin_ia32_cvttps2dq((__v4sf)__a);
}
# 3293 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsi32_si128(int __a) {
  return __extension__(__m128i)(__v4si){__a, 0, 0, 0};
}
# 3308 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsi64_si128(long long __a) {
  return __extension__(__m128i)(__v2di){__a, 0};
}
# 3323 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsi128_si32(__m128i __a) {
  __v4si __b = (__v4si)__a;
  return __b[0];
}
# 3339 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_cvtsi128_si64(__m128i __a) {
  return __a[0];
}
# 3353 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_load_si128(__m128i const *__p) {
  return *__p;
}
# 3368 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_loadu_si128(__m128i_u const *__p) {
  struct __loadu_si128 {
    __m128i_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_si128 *)__p)->__v;
}
# 3388 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_loadl_epi64(__m128i_u const *__p) {
  struct __mm_loadl_epi64_struct {
    long long __u;
  } __attribute__((__packed__, __may_alias__));
  return __extension__(__m128i){
      ((const struct __mm_loadl_epi64_struct *)__p)->__u, 0};
}
# 3406 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_undefined_si128(void) {
  return (__m128i)__builtin_ia32_undef128();
}
# 3426 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set_epi64x(long long __q1,
                                                            long long __q0) {
  return __extension__(__m128i)(__v2di){__q0, __q1};
}
# 3447 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set_epi64(__m64 __q1,
                                                           __m64 __q0) {
  return _mm_set_epi64x((long long)__q1, (long long)__q0);
}
# 3474 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set_epi32(int __i3, int __i2,
                                                           int __i1, int __i0) {
  return __extension__(__m128i)(__v4si){__i0, __i1, __i2, __i3};
}
# 3513 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_set_epi16(short __w7, short __w6, short __w5, short __w4, short __w3,
              short __w2, short __w1, short __w0) {
  return __extension__(__m128i)(__v8hi){__w0, __w1, __w2, __w3,
                                        __w4, __w5, __w6, __w7};
}
# 3562 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_set_epi8(char __b15, char __b14, char __b13, char __b12, char __b11,
             char __b10, char __b9, char __b8, char __b7, char __b6, char __b5,
             char __b4, char __b3, char __b2, char __b1, char __b0) {
  return __extension__(__m128i)(__v16qi){
      __b0, __b1, __b2, __b3, __b4, __b5, __b6, __b7,
      __b8, __b9, __b10, __b11, __b12, __b13, __b14, __b15};
}
# 3584 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set1_epi64x(long long __q) {
  return _mm_set_epi64x(__q, __q);
}
# 3601 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set1_epi64(__m64 __q) {
  return _mm_set_epi64(__q, __q);
}
# 3618 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set1_epi32(int __i) {
  return _mm_set_epi32(__i, __i, __i, __i);
}
# 3635 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set1_epi16(short __w) {
  return _mm_set_epi16(__w, __w, __w, __w, __w, __w, __w, __w);
}
# 3652 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_set1_epi8(char __b) {
  return _mm_set_epi8(__b, __b, __b, __b, __b, __b, __b, __b, __b, __b, __b,
                      __b, __b, __b, __b, __b);
}
# 3671 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_setr_epi64(__m64 __q0,
                                                            __m64 __q1) {
  return _mm_set_epi64(__q1, __q0);
}
# 3693 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_setr_epi32(int __i0, int __i1,
                                                            int __i2,
                                                            int __i3) {
  return _mm_set_epi32(__i3, __i2, __i1, __i0);
}
# 3724 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_setr_epi16(short __w0, short __w1, short __w2, short __w3, short __w4,
               short __w5, short __w6, short __w7) {
  return _mm_set_epi16(__w7, __w6, __w5, __w4, __w3, __w2, __w1, __w0);
}
# 3771 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128)))
_mm_setr_epi8(char __b0, char __b1, char __b2, char __b3, char __b4, char __b5,
              char __b6, char __b7, char __b8, char __b9, char __b10,
              char __b11, char __b12, char __b13, char __b14, char __b15) {
  return _mm_set_epi8(__b15, __b14, __b13, __b12, __b11, __b10, __b9, __b8,
                      __b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}
# 3787 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_setzero_si128(void) {
  return __extension__(__m128i)(__v2di){0LL, 0LL};
}
# 3803 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_store_si128(__m128i *__p,
                                                          __m128i __b) {
  *__p = __b;
}
# 3818 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storeu_si128(__m128i_u *__p,
                                                           __m128i __b) {
  struct __storeu_si128 {
    __m128i_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si128 *)__p)->__v = __b;
}
# 3838 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storeu_si64(void *__p,
                                                          __m128i __b) {
  struct __storeu_si64 {
    long long __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si64 *)__p)->__v = ((__v2di)__b)[0];
}
# 3858 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storeu_si32(void *__p,
                                                          __m128i __b) {
  struct __storeu_si32 {
    int __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si32 *)__p)->__v = ((__v4si)__b)[0];
}
# 3878 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storeu_si16(void *__p,
                                                          __m128i __b) {
  struct __storeu_si16 {
    short __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si16 *)__p)->__v = ((__v8hi)__b)[0];
}
# 3907 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_maskmoveu_si128(__m128i __d,
                                                              __m128i __n,
                                                              char *__p) {
  __builtin_ia32_maskmovdqu((__v16qi)__d, (__v16qi)__n, __p);
}
# 3926 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_storel_epi64(__m128i_u *__p,
                                                           __m128i __a) {
  struct __mm_storel_epi64_struct {
    long long __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storel_epi64_struct *)__p)->__u = __a[0];
}
# 3948 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_stream_pd(void *__p,
                                                        __m128d __a) {
  __builtin_nontemporal_store((__v2df)__a, (__v2df *)__p);
}
# 3966 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_stream_si128(void *__p,
                                                           __m128i __a) {
  __builtin_nontemporal_store((__v2di)__a, (__v2di *)__p);
}
# 3984 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void
    __attribute__((__always_inline__, __nodebug__, __target__("sse2")))
    _mm_stream_si32(void *__p, int __a) {
  __builtin_ia32_movnti((int *)__p, __a);
}
# 4004 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ void
    __attribute__((__always_inline__, __nodebug__, __target__("sse2")))
    _mm_stream_si64(void *__p, long long __a) {
  __builtin_ia32_movnti64((long long *)__p, __a);
}
# 4025 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
void _mm_clflush(void const *__p);
# 4036 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
void _mm_lfence(void);
# 4047 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
void _mm_mfence(void);
# 4075 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_packs_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_packsswb128((__v8hi)__a, (__v8hi)__b);
}
# 4102 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_packs_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_packssdw128((__v4si)__a, (__v4si)__b);
}
# 4129 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_packus_epi16(__m128i __a,
                                                              __m128i __b) {
  return (__m128i)__builtin_ia32_packuswb128((__v8hi)__a, (__v8hi)__b);
}
# 4204 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_movemask_epi8(__m128i __a) {
  return __builtin_ia32_pmovmskb128((__v16qi)__a);
}
# 4337 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpackhi_epi8(__m128i __a,
                                                               __m128i __b) {
  return (__m128i)__builtin_shufflevector(
      (__v16qi)__a, (__v16qi)__b, 8, 16 + 8, 9, 16 + 9, 10, 16 + 10, 11,
      16 + 11, 12, 16 + 12, 13, 16 + 13, 14, 16 + 14, 15, 16 + 15);
}
# 4365 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpackhi_epi16(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v8hi)__a, (__v8hi)__b, 4, 8 + 4, 5,
                                          8 + 5, 6, 8 + 6, 7, 8 + 7);
}
# 4388 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpackhi_epi32(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v4si)__a, (__v4si)__b, 2, 4 + 2, 3,
                                          4 + 3);
}
# 4409 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpackhi_epi64(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v2di)__a, (__v2di)__b, 1, 2 + 1);
}
# 4443 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpacklo_epi8(__m128i __a,
                                                               __m128i __b) {
  return (__m128i)__builtin_shufflevector(
      (__v16qi)__a, (__v16qi)__b, 0, 16 + 0, 1, 16 + 1, 2, 16 + 2, 3, 16 + 3, 4,
      16 + 4, 5, 16 + 5, 6, 16 + 6, 7, 16 + 7);
}
# 4472 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpacklo_epi16(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v8hi)__a, (__v8hi)__b, 0, 8 + 0, 1,
                                          8 + 1, 2, 8 + 2, 3, 8 + 3);
}
# 4495 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpacklo_epi32(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v4si)__a, (__v4si)__b, 0, 4 + 0, 1,
                                          4 + 1);
}
# 4516 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpacklo_epi64(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v2di)__a, (__v2di)__b, 0, 2 + 0);
}
# 4532 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_movepi64_pi64(__m128i __a) {
  return (__m64)__a[0];
}
# 4547 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_movpi64_epi64(__m64 __a) {
  return __extension__(__m128i)(__v2di){(long long)__a, 0};
}
# 4563 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_move_epi64(__m128i __a) {
  return __builtin_shufflevector((__v2di)__a, _mm_setzero_si128(), 0, 2);
}
# 4582 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpackhi_pd(__m128d __a,
                                                             __m128d __b) {
  return __builtin_shufflevector((__v2df)__a, (__v2df)__b, 1, 2 + 1);
}
# 4602 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_unpacklo_pd(__m128d __a,
                                                             __m128d __b) {
  return __builtin_shufflevector((__v2df)__a, (__v2df)__b, 0, 2 + 0);
}
# 4620 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_movemask_pd(__m128d __a) {
  return __builtin_ia32_movmskpd((__v2df)__a);
}
# 4666 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_castpd_ps(__m128d __a) {
  return (__m128)__a;
}
# 4681 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_castpd_si128(__m128d __a) {
  return (__m128i)__a;
}
# 4696 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_castps_pd(__m128 __a) {
  return (__m128d)__a;
}
# 4711 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_castps_si128(__m128 __a) {
  return (__m128i)__a;
}
# 4726 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_castsi128_ps(__m128i __a) {
  return (__m128)__a;
}
# 4741 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2,no-evex512"), __min_vector_width__(128))) _mm_castsi128_pd(__m128i __a) {
  return (__m128d)__a;
}
# 4756 "/usr/lib/llvm-18/lib/clang/18/include/emmintrin.h" 3
void _mm_pause(void);
# 227 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h" 2
# 274 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h"
static __inline __attribute__((unused)) int ZSTD_isPower2(size_t u) {
    return (u & (u-1)) == 0;
}
# 346 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/compiler.h"
static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
ptrdiff_t ZSTD_wrappedPtrDiff(unsigned char const* lhs, unsigned char const* rhs)
{
    return lhs - rhs;
}






static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
unsigned char const* ZSTD_wrappedPtrAdd(unsigned char const* ptr, ptrdiff_t add)
{
    return ptr + add;
}







static __inline __attribute__((unused))
__attribute__((no_sanitize("pointer-overflow")))
unsigned char const* ZSTD_wrappedPtrSub(unsigned char const* ptr, ptrdiff_t sub)
{
    return ptr - sub;
}







static __inline __attribute__((unused))
unsigned char* ZSTD_maybeNullPtrAdd(unsigned char* ptr, ptrdiff_t add)
{
    return add > 0 ? ptr + add : ptr;
}
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/debug.h" 1
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 1
# 39 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 1 3
# 21 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 3
# 1 "/usr/include/limits.h" 1 3 4
# 26 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/limits.h" 2 3 4
# 195 "/usr/include/limits.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 161 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 1 3 4
# 38 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/linux/limits.h" 1 3 4
# 39 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 81 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 1 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min.h" 1 3 4
# 30 "/usr/include/x86_64-linux-gnu/bits/pthread_stack_min-dynamic.h" 2 3 4
# 82 "/usr/include/x86_64-linux-gnu/bits/local_lim.h" 2 3 4
# 162 "/usr/include/x86_64-linux-gnu/bits/posix1_lim.h" 2 3 4
# 196 "/usr/include/limits.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/posix2_lim.h" 1 3 4
# 200 "/usr/include/limits.h" 2 3 4
# 22 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 2 3
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 2
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;



# 1 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))

                                         ;



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))


                                          ;
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 24 "/usr/include/strings.h" 2 3 4
# 34 "/usr/include/strings.h" 3 4
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
# 42 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 2
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h" 2
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h"
typedef ZSTD_ErrorCode ERR_enum;
# 52 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h"
static __attribute__((unused)) unsigned ERR_isError(size_t code) { return (code > ((size_t)-ZSTD_error_maxCode)); }

static __attribute__((unused)) ERR_enum ERR_getErrorCode(size_t code) { if (!ERR_isError(code)) return (ERR_enum)0; return (ERR_enum) (0-code); }
# 70 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h"
const char* ERR_getErrorString(ERR_enum code);

static __attribute__((unused)) const char* ERR_getErrorName(size_t code)
{
    return ERR_getErrorString(ERR_getErrorCode(code));
}
# 86 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/error_private.h"
static inline __attribute__((unused))
void _force_has_format_string(const char *format, ...) {
  (void)format;
}
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_common.c" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 1
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/cpu.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/cpu.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h" 1
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 18 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h" 2
# 40 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 1 3
# 52 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 3
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4







# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 53 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 2 3
# 41 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h" 2

  typedef uint8_t BYTE;
  typedef uint8_t U8;
  typedef int8_t S8;
  typedef uint16_t U16;
  typedef int16_t S16;
  typedef uint32_t U32;
  typedef int32_t S32;
  typedef uint64_t U64;
  typedef int64_t S64;
# 79 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
static __inline __attribute__((unused)) unsigned MEM_32bits(void);
static __inline __attribute__((unused)) unsigned MEM_64bits(void);
static __inline __attribute__((unused)) unsigned MEM_isLittleEndian(void);


static __inline __attribute__((unused)) U16 MEM_read16(const void* memPtr);
static __inline __attribute__((unused)) U32 MEM_read32(const void* memPtr);
static __inline __attribute__((unused)) U64 MEM_read64(const void* memPtr);
static __inline __attribute__((unused)) size_t MEM_readST(const void* memPtr);

static __inline __attribute__((unused)) void MEM_write16(void* memPtr, U16 value);
static __inline __attribute__((unused)) void MEM_write32(void* memPtr, U32 value);
static __inline __attribute__((unused)) void MEM_write64(void* memPtr, U64 value);


static __inline __attribute__((unused)) U16 MEM_readLE16(const void* memPtr);
static __inline __attribute__((unused)) U32 MEM_readLE24(const void* memPtr);
static __inline __attribute__((unused)) U32 MEM_readLE32(const void* memPtr);
static __inline __attribute__((unused)) U64 MEM_readLE64(const void* memPtr);
static __inline __attribute__((unused)) size_t MEM_readLEST(const void* memPtr);

static __inline __attribute__((unused)) void MEM_writeLE16(void* memPtr, U16 val);
static __inline __attribute__((unused)) void MEM_writeLE24(void* memPtr, U32 val);
static __inline __attribute__((unused)) void MEM_writeLE32(void* memPtr, U32 val32);
static __inline __attribute__((unused)) void MEM_writeLE64(void* memPtr, U64 val64);
static __inline __attribute__((unused)) void MEM_writeLEST(void* memPtr, size_t val);


static __inline __attribute__((unused)) U32 MEM_readBE32(const void* memPtr);
static __inline __attribute__((unused)) U64 MEM_readBE64(const void* memPtr);
static __inline __attribute__((unused)) size_t MEM_readBEST(const void* memPtr);

static __inline __attribute__((unused)) void MEM_writeBE32(void* memPtr, U32 val32);
static __inline __attribute__((unused)) void MEM_writeBE64(void* memPtr, U64 val64);
static __inline __attribute__((unused)) void MEM_writeBEST(void* memPtr, size_t val);


static __inline __attribute__((unused)) U32 MEM_swap32(U32 in);
static __inline __attribute__((unused)) U64 MEM_swap64(U64 in);
static __inline __attribute__((unused)) size_t MEM_swapST(size_t in);
# 137 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
static __inline __attribute__((unused)) unsigned MEM_32bits(void) { return sizeof(size_t)==4; }
static __inline __attribute__((unused)) unsigned MEM_64bits(void) { return sizeof(size_t)==8; }

static __inline __attribute__((unused)) unsigned MEM_isLittleEndian(void)
{

    return 1;
# 160 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
}
# 177 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
typedef __attribute__((aligned(1))) U16 unalign16;
typedef __attribute__((aligned(1))) U32 unalign32;
typedef __attribute__((aligned(1))) U64 unalign64;
typedef __attribute__((aligned(1))) size_t unalignArch;

static __inline __attribute__((unused)) U16 MEM_read16(const void* ptr) { return *(const unalign16*)ptr; }
static __inline __attribute__((unused)) U32 MEM_read32(const void* ptr) { return *(const unalign32*)ptr; }
static __inline __attribute__((unused)) U64 MEM_read64(const void* ptr) { return *(const unalign64*)ptr; }
static __inline __attribute__((unused)) size_t MEM_readST(const void* ptr) { return *(const unalignArch*)ptr; }

static __inline __attribute__((unused)) void MEM_write16(void* memPtr, U16 value) { *(unalign16*)memPtr = value; }
static __inline __attribute__((unused)) void MEM_write32(void* memPtr, U32 value) { *(unalign32*)memPtr = value; }
static __inline __attribute__((unused)) void MEM_write64(void* memPtr, U64 value) { *(unalign64*)memPtr = value; }
# 233 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/mem.h"
static __inline __attribute__((unused)) U32 MEM_swap32_fallback(U32 in)
{
    return ((in << 24) & 0xff000000 ) |
            ((in << 8) & 0x00ff0000 ) |
            ((in >> 8) & 0x0000ff00 ) |
            ((in >> 24) & 0x000000ff );
}

static __inline __attribute__((unused)) U32 MEM_swap32(U32 in)
{




    return __builtin_bswap32(in);





}

static __inline __attribute__((unused)) U64 MEM_swap64_fallback(U64 in)
{
     return ((in << 56) & 0xff00000000000000ULL) |
            ((in << 40) & 0x00ff000000000000ULL) |
            ((in << 24) & 0x0000ff0000000000ULL) |
            ((in << 8) & 0x000000ff00000000ULL) |
            ((in >> 8) & 0x00000000ff000000ULL) |
            ((in >> 24) & 0x0000000000ff0000ULL) |
            ((in >> 40) & 0x000000000000ff00ULL) |
            ((in >> 56) & 0x00000000000000ffULL);
}

static __inline __attribute__((unused)) U64 MEM_swap64(U64 in)
{




    return __builtin_bswap64(in);



}

static __inline __attribute__((unused)) size_t MEM_swapST(size_t in)
{
    if (MEM_32bits())
        return (size_t)MEM_swap32((U32)in);
    else
        return (size_t)MEM_swap64((U64)in);
}



static __inline __attribute__((unused)) U16 MEM_readLE16(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_read16(memPtr);
    else {
        const BYTE* p = (const BYTE*)memPtr;
        return (U16)(p[0] + (p[1]<<8));
    }
}

static __inline __attribute__((unused)) void MEM_writeLE16(void* memPtr, U16 val)
{
    if (MEM_isLittleEndian()) {
        MEM_write16(memPtr, val);
    } else {
        BYTE* p = (BYTE*)memPtr;
        p[0] = (BYTE)val;
        p[1] = (BYTE)(val>>8);
    }
}

static __inline __attribute__((unused)) U32 MEM_readLE24(const void* memPtr)
{
    return (U32)MEM_readLE16(memPtr) + ((U32)(((const BYTE*)memPtr)[2]) << 16);
}

static __inline __attribute__((unused)) void MEM_writeLE24(void* memPtr, U32 val)
{
    MEM_writeLE16(memPtr, (U16)val);
    ((BYTE*)memPtr)[2] = (BYTE)(val>>16);
}

static __inline __attribute__((unused)) U32 MEM_readLE32(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_read32(memPtr);
    else
        return MEM_swap32(MEM_read32(memPtr));
}

static __inline __attribute__((unused)) void MEM_writeLE32(void* memPtr, U32 val32)
{
    if (MEM_isLittleEndian())
        MEM_write32(memPtr, val32);
    else
        MEM_write32(memPtr, MEM_swap32(val32));
}

static __inline __attribute__((unused)) U64 MEM_readLE64(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_read64(memPtr);
    else
        return MEM_swap64(MEM_read64(memPtr));
}

static __inline __attribute__((unused)) void MEM_writeLE64(void* memPtr, U64 val64)
{
    if (MEM_isLittleEndian())
        MEM_write64(memPtr, val64);
    else
        MEM_write64(memPtr, MEM_swap64(val64));
}

static __inline __attribute__((unused)) size_t MEM_readLEST(const void* memPtr)
{
    if (MEM_32bits())
        return (size_t)MEM_readLE32(memPtr);
    else
        return (size_t)MEM_readLE64(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeLEST(void* memPtr, size_t val)
{
    if (MEM_32bits())
        MEM_writeLE32(memPtr, (U32)val);
    else
        MEM_writeLE64(memPtr, (U64)val);
}



static __inline __attribute__((unused)) U32 MEM_readBE32(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_swap32(MEM_read32(memPtr));
    else
        return MEM_read32(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeBE32(void* memPtr, U32 val32)
{
    if (MEM_isLittleEndian())
        MEM_write32(memPtr, MEM_swap32(val32));
    else
        MEM_write32(memPtr, val32);
}

static __inline __attribute__((unused)) U64 MEM_readBE64(const void* memPtr)
{
    if (MEM_isLittleEndian())
        return MEM_swap64(MEM_read64(memPtr));
    else
        return MEM_read64(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeBE64(void* memPtr, U64 val64)
{
    if (MEM_isLittleEndian())
        MEM_write64(memPtr, MEM_swap64(val64));
    else
        MEM_write64(memPtr, val64);
}

static __inline __attribute__((unused)) size_t MEM_readBEST(const void* memPtr)
{
    if (MEM_32bits())
        return (size_t)MEM_readBE32(memPtr);
    else
        return (size_t)MEM_readBE64(memPtr);
}

static __inline __attribute__((unused)) void MEM_writeBEST(void* memPtr, size_t val)
{
    if (MEM_32bits())
        MEM_writeBE32(memPtr, (U32)val);
    else
        MEM_writeBE64(memPtr, (U64)val);
}


static __inline __attribute__((unused)) void MEM_check(void) { (void)sizeof(char[((sizeof(size_t)==4) || (sizeof(size_t)==8)) ? 1 : -1]); }
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/cpu.h" 2





typedef struct {
    U32 f1c;
    U32 f1d;
    U32 f7b;
    U32 f7c;
} ZSTD_cpuid_t;

static __inline __attribute__((unused)) ZSTD_cpuid_t ZSTD_cpuid(void) {
    U32 f1c = 0;
    U32 f1d = 0;
    U32 f7b = 0;
    U32 f7c = 0;
# 122 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/cpu.h"
    U32 n;
    __asm__("cpuid" : "=a"(n) : "a"(0) : "ebx", "ecx", "edx");
    if (n >= 1) {
      U32 f1a;
      __asm__("cpuid" : "=a"(f1a), "=c"(f1c), "=d"(f1d) : "a"(1) : "ebx");
    }
    if (n >= 7) {
      U32 f7a;
      __asm__("cpuid"
              : "=a"(f7a), "=b"(f7b), "=c"(f7c)
              : "a"(7), "c"(0)
              : "edx");
    }

    {
        ZSTD_cpuid_t cpuid;
        cpuid.f1c = f1c;
        cpuid.f1d = f1d;
        cpuid.f7b = f7b;
        cpuid.f7c = f7c;
        return cpuid;
    }
}
# 153 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/cpu.h"
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse3(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 0)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pclmuldq(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 1)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_dtes64(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 2)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_monitor(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 3)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_dscpl(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 4)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_vmx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 5)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_smx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 6)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_eist(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 7)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tm2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 8)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_ssse3(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 9)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cnxtid(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 10)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_fma(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 12)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cx16(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 13)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_xtpr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 14)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pdcm(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 15)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pcid(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 17)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_dca(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 18)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse41(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 19)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse42(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 20)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_x2apic(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 21)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_movbe(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 22)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_popcnt(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 23)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tscdeadline(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 24)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_aes(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 25)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_xsave(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 26)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_osxsave(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 27)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 28)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_f16c(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 29)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_rdrand(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1c) & (1U << 30)) != 0; }


  static __inline __attribute__((unused)) int ZSTD_cpuid_fpu(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 0)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_vme(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 1)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_de(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 2)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pse(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 3)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tsc(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 4)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_msr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 5)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pae(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 6)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mce(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 7)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cx8(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 8)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_apic(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 9)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sep(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 11)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mtrr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 12)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pge(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 13)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mca(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 14)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_cmov(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 15)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pat(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 16)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pse36(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 17)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_psn(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 18)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_clfsh(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 19)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_ds(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 21)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_acpi(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 22)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mmx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 23)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_fxsr(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 24)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 25)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sse2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 26)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_ss(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 27)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_htt(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 28)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_tm(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 29)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pbe(ZSTD_cpuid_t const cpuid) { return ((cpuid.f1d) & (1U << 31)) != 0; }




  static __inline __attribute__((unused)) int ZSTD_cpuid_bmi1(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 3)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_hle(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 4)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 5)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_smep(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 7)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_bmi2(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 8)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_erms(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 9)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_invpcid(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 10)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_rtm(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 11)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_mpx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 14)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512f(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 16)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512dq(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 17)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_rdseed(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 18)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_adx(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 19)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_smap(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 20)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512ifma(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 21)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_pcommit(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 22)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_clflushopt(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 23)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_clwb(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 24)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512pf(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 26)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512er(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 27)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512cd(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 28)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_sha(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 29)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512bw(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 30)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512vl(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7b) & (1U << 31)) != 0; }


  static __inline __attribute__((unused)) int ZSTD_cpuid_prefetchwt1(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7c) & (1U << 0)) != 0; }
  static __inline __attribute__((unused)) int ZSTD_cpuid_avx512vbmi(ZSTD_cpuid_t const cpuid) { return ((cpuid.f7c) & (1U << 1)) != 0; }
# 24 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 2




# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 17 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h" 2



# 1 "/usr/lib/llvm-18/lib/clang/18/include/limits.h" 1 3
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h" 2
# 119 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_versionNumber(void);
# 128 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) const char* ZSTD_versionString(void);
# 160 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compress( void* dst, size_t dstCapacity,
                            const void* src, size_t srcSize,
                                  int compressionLevel);
# 173 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decompress( void* dst, size_t dstCapacity,
                              const void* src, size_t compressedSize);
# 205 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_getFrameContentSize(const void *src, size_t srcSize);







__attribute__((deprecated("Replaced by ZSTD_getFrameContentSize")))
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_getDecompressedSize(const void* src, size_t srcSize);
# 227 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_findFrameCompressedSize(const void* src, size_t srcSize);
# 250 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBound(size_t srcSize);
# 259 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_isError(size_t result);
__attribute__ ((visibility ("default"))) ZSTD_ErrorCode ZSTD_getErrorCode(size_t functionResult);
__attribute__ ((visibility ("default"))) const char* ZSTD_getErrorName(size_t result);
__attribute__ ((visibility ("default"))) int ZSTD_minCLevel(void);
__attribute__ ((visibility ("default"))) int ZSTD_maxCLevel(void);
__attribute__ ((visibility ("default"))) int ZSTD_defaultCLevel(void);
# 280 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef struct ZSTD_CCtx_s ZSTD_CCtx;
__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_createCCtx(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCCtx(ZSTD_CCtx* cctx);
# 292 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compressCCtx(ZSTD_CCtx* cctx,
                                     void* dst, size_t dstCapacity,
                               const void* src, size_t srcSize,
                                     int compressionLevel);







typedef struct ZSTD_DCtx_s ZSTD_DCtx;
__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_createDCtx(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDCtx(ZSTD_DCtx* dctx);






__attribute__ ((visibility ("default"))) size_t ZSTD_decompressDCtx(ZSTD_DCtx* dctx,
                                       void* dst, size_t dstCapacity,
                                 const void* src, size_t srcSize);
# 336 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef enum { ZSTD_fast=1,
               ZSTD_dfast=2,
               ZSTD_greedy=3,
               ZSTD_lazy=4,
               ZSTD_lazy2=5,
               ZSTD_btlazy2=6,
               ZSTD_btopt=7,
               ZSTD_btultra=8,
               ZSTD_btultra2=9


} ZSTD_strategy;

typedef enum {





    ZSTD_c_compressionLevel=100,
# 368 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
    ZSTD_c_windowLog=101,







    ZSTD_c_hashLog=102,





    ZSTD_c_chainLog=103,







    ZSTD_c_searchLog=104,



    ZSTD_c_minMatch=105,







    ZSTD_c_targetLength=106,







    ZSTD_c_strategy=107,




    ZSTD_c_targetCBlockSize=130,
# 428 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
    ZSTD_c_enableLongDistanceMatching=160,







    ZSTD_c_ldmHashLog=161,





    ZSTD_c_ldmMinMatch=162,



    ZSTD_c_ldmBucketSizeLog=163,



    ZSTD_c_ldmHashRateLog=164,







    ZSTD_c_contentSizeFlag=200,



    ZSTD_c_checksumFlag=201,
    ZSTD_c_dictIDFlag=202,







    ZSTD_c_nbWorkers=400,
# 480 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
    ZSTD_c_jobSize=401,




    ZSTD_c_overlapLog=402,
# 522 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
     ZSTD_c_experimentalParam1=500,
     ZSTD_c_experimentalParam2=10,
     ZSTD_c_experimentalParam3=1000,
     ZSTD_c_experimentalParam4=1001,
     ZSTD_c_experimentalParam5=1002,

     ZSTD_c_experimentalParam7=1004,
     ZSTD_c_experimentalParam8=1005,
     ZSTD_c_experimentalParam9=1006,
     ZSTD_c_experimentalParam10=1007,
     ZSTD_c_experimentalParam11=1008,
     ZSTD_c_experimentalParam12=1009,
     ZSTD_c_experimentalParam13=1010,
     ZSTD_c_experimentalParam14=1011,
     ZSTD_c_experimentalParam15=1012,
     ZSTD_c_experimentalParam16=1013,
     ZSTD_c_experimentalParam17=1014,
     ZSTD_c_experimentalParam18=1015,
     ZSTD_c_experimentalParam19=1016,
     ZSTD_c_experimentalParam20=1017
} ZSTD_cParameter;

typedef struct {
    size_t error;
    int lowerBound;
    int upperBound;
} ZSTD_bounds;
# 557 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_bounds ZSTD_cParam_getBounds(ZSTD_cParameter cParam);
# 570 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParameter(ZSTD_CCtx* cctx, ZSTD_cParameter param, int value);
# 587 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setPledgedSrcSize(ZSTD_CCtx* cctx, unsigned long long pledgedSrcSize);

typedef enum {
    ZSTD_reset_session_only = 1,
    ZSTD_reset_parameters = 2,
    ZSTD_reset_session_and_parameters = 3
} ZSTD_ResetDirective;
# 609 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_reset(ZSTD_CCtx* cctx, ZSTD_ResetDirective reset);
# 623 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compress2( ZSTD_CCtx* cctx,
                                   void* dst, size_t dstCapacity,
                             const void* src, size_t srcSize);
# 640 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef enum {

    ZSTD_d_windowLogMax=100,
# 661 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
     ZSTD_d_experimentalParam1=1000,
     ZSTD_d_experimentalParam2=1001,
     ZSTD_d_experimentalParam3=1002,
     ZSTD_d_experimentalParam4=1003,
     ZSTD_d_experimentalParam5=1004,
     ZSTD_d_experimentalParam6=1005

} ZSTD_dParameter;
# 677 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_bounds ZSTD_dParam_getBounds(ZSTD_dParameter dParam);
# 686 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_setParameter(ZSTD_DCtx* dctx, ZSTD_dParameter param, int value);







__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_reset(ZSTD_DCtx* dctx, ZSTD_ResetDirective reset);






typedef struct ZSTD_inBuffer_s {
  const void* src;
  size_t size;
  size_t pos;
} ZSTD_inBuffer;

typedef struct ZSTD_outBuffer_s {
  void* dst;
  size_t size;
  size_t pos;
} ZSTD_outBuffer;
# 776 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef ZSTD_CCtx ZSTD_CStream;


__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_createCStream(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCStream(ZSTD_CStream* zcs);


typedef enum {
    ZSTD_e_continue=0,
    ZSTD_e_flush=1,



    ZSTD_e_end=2




} ZSTD_EndDirective;
# 823 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream2( ZSTD_CCtx* cctx,
                                         ZSTD_outBuffer* output,
                                         ZSTD_inBuffer* input,
                                         ZSTD_EndDirective endOp);
# 842 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CStreamInSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_CStreamOutSize(void);
# 862 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_initCStream(ZSTD_CStream* zcs, int compressionLevel);






__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output, ZSTD_inBuffer* input);

__attribute__ ((visibility ("default"))) size_t ZSTD_flushStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output);

__attribute__ ((visibility ("default"))) size_t ZSTD_endStream(ZSTD_CStream* zcs, ZSTD_outBuffer* output);
# 908 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef ZSTD_DCtx ZSTD_DStream;


__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_createDStream(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeDStream(ZSTD_DStream* zds);
# 924 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream(ZSTD_DStream* zds);
# 948 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressStream(ZSTD_DStream* zds, ZSTD_outBuffer* output, ZSTD_inBuffer* input);

__attribute__ ((visibility ("default"))) size_t ZSTD_DStreamInSize(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_DStreamOutSize(void);
# 964 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_compress_usingDict(ZSTD_CCtx* ctx,
                                           void* dst, size_t dstCapacity,
                                     const void* src, size_t srcSize,
                                     const void* dict,size_t dictSize,
                                           int compressionLevel);







__attribute__ ((visibility ("default"))) size_t ZSTD_decompress_usingDict(ZSTD_DCtx* dctx,
                                             void* dst, size_t dstCapacity,
                                       const void* src, size_t srcSize,
                                       const void* dict,size_t dictSize);





typedef struct ZSTD_CDict_s ZSTD_CDict;
# 999 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict(const void* dictBuffer, size_t dictSize,
                                         int compressionLevel);




__attribute__ ((visibility ("default"))) size_t ZSTD_freeCDict(ZSTD_CDict* CDict);






__attribute__ ((visibility ("default"))) size_t ZSTD_compress_usingCDict(ZSTD_CCtx* cctx,
                                            void* dst, size_t dstCapacity,
                                      const void* src, size_t srcSize,
                                      const ZSTD_CDict* cdict);


typedef struct ZSTD_DDict_s ZSTD_DDict;




__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict(const void* dictBuffer, size_t dictSize);




__attribute__ ((visibility ("default"))) size_t ZSTD_freeDDict(ZSTD_DDict* ddict);




__attribute__ ((visibility ("default"))) size_t ZSTD_decompress_usingDDict(ZSTD_DCtx* dctx,
                                              void* dst, size_t dstCapacity,
                                        const void* src, size_t srcSize,
                                        const ZSTD_DDict* ddict);
# 1047 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromDict(const void* dict, size_t dictSize);





__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromCDict(const ZSTD_CDict* cdict);





__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromDDict(const ZSTD_DDict* ddict);
# 1071 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_getDictID_fromFrame(const void* src, size_t srcSize);
# 1108 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary(ZSTD_CCtx* cctx, const void* dict, size_t dictSize);
# 1122 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict);
# 1143 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refPrefix(ZSTD_CCtx* cctx,
                                 const void* prefix, size_t prefixSize);
# 1161 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);
# 1180 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refDDict(ZSTD_DCtx* dctx, const ZSTD_DDict* ddict);
# 1198 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refPrefix(ZSTD_DCtx* dctx,
                                 const void* prefix, size_t prefixSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CCtx(const ZSTD_CCtx* cctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DCtx(const ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CStream(const ZSTD_CStream* zcs);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DStream(const ZSTD_DStream* zds);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_CDict(const ZSTD_CDict* cdict);
__attribute__ ((visibility ("default"))) size_t ZSTD_sizeof_DDict(const ZSTD_DDict* ddict);
# 1313 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef struct ZSTD_CCtx_params_s ZSTD_CCtx_params;

typedef struct {
    unsigned int offset;




    unsigned int litLength;
    unsigned int matchLength;





    unsigned int rep;
# 1350 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
} ZSTD_Sequence;

typedef struct {
    unsigned windowLog;
    unsigned chainLog;
    unsigned hashLog;
    unsigned searchLog;
    unsigned minMatch;
    unsigned targetLength;
    ZSTD_strategy strategy;
} ZSTD_compressionParameters;

typedef struct {
    int contentSizeFlag;
    int checksumFlag;
    int noDictIDFlag;
} ZSTD_frameParameters;

typedef struct {
    ZSTD_compressionParameters cParams;
    ZSTD_frameParameters fParams;
} ZSTD_parameters;

typedef enum {
    ZSTD_dct_auto = 0,
    ZSTD_dct_rawContent = 1,
    ZSTD_dct_fullDict = 2
} ZSTD_dictContentType_e;

typedef enum {
    ZSTD_dlm_byCopy = 0,
    ZSTD_dlm_byRef = 1
} ZSTD_dictLoadMethod_e;

typedef enum {
    ZSTD_f_zstd1 = 0,
    ZSTD_f_zstd1_magicless = 1


} ZSTD_format_e;

typedef enum {

    ZSTD_d_validateChecksum = 0,
    ZSTD_d_ignoreChecksum = 1
} ZSTD_forceIgnoreChecksum_e;

typedef enum {

    ZSTD_rmd_refSingleDDict = 0,
    ZSTD_rmd_refMultipleDDicts = 1
} ZSTD_refMultipleDDicts_e;

typedef enum {
# 1436 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
    ZSTD_dictDefaultAttach = 0,
    ZSTD_dictForceAttach = 1,
    ZSTD_dictForceCopy = 2,
    ZSTD_dictForceLoad = 3
} ZSTD_dictAttachPref_e;

typedef enum {
  ZSTD_lcm_auto = 0,


  ZSTD_lcm_huffman = 1,

  ZSTD_lcm_uncompressed = 2
} ZSTD_literalCompressionMode_e;

typedef enum {




  ZSTD_ps_auto = 0,
  ZSTD_ps_enable = 1,
  ZSTD_ps_disable = 2
} ZSTD_ParamSwitch_e;
# 1487 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_findDecompressedSize(const void* src, size_t srcSize);
# 1502 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned long long ZSTD_decompressBound(const void* src, size_t srcSize);





__attribute__ ((visibility ("default"))) size_t ZSTD_frameHeaderSize(const void* src, size_t srcSize);

typedef enum { ZSTD_frame, ZSTD_skippableFrame } ZSTD_FrameType_e;

typedef struct {
    unsigned long long frameContentSize;
    unsigned long long windowSize;
    unsigned blockSizeMax;
    ZSTD_FrameType_e frameType;
    unsigned headerSize;
    unsigned dictID;
    unsigned checksumFlag;
    unsigned _reserved1;
    unsigned _reserved2;
} ZSTD_FrameHeader;







__attribute__ ((visibility ("default"))) size_t ZSTD_getFrameHeader(ZSTD_FrameHeader* zfhPtr, const void* src, size_t srcSize);



__attribute__ ((visibility ("default"))) size_t ZSTD_getFrameHeader_advanced(ZSTD_FrameHeader* zfhPtr, const void* src, size_t srcSize, ZSTD_format_e format);
# 1559 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressionMargin(const void* src, size_t srcSize);
# 1581 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef enum {
  ZSTD_sf_noBlockDelimiters = 0,
  ZSTD_sf_explicitBlockDelimiters = 1
} ZSTD_SequenceFormat_e;
# 1594 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_sequenceBound(size_t srcSize);
# 1624 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("For debugging only, will be replaced by ZSTD_extractSequences()")))
__attribute__ ((visibility ("default"))) size_t
ZSTD_generateSequences(ZSTD_CCtx* zc,
                       ZSTD_Sequence* outSeqs, size_t outSeqsCapacity,
                       const void* src, size_t srcSize);
# 1641 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_mergeBlockDelimiters(ZSTD_Sequence* sequences, size_t seqsSize);
# 1679 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t
ZSTD_compressSequences(ZSTD_CCtx* cctx,
                       void* dst, size_t dstCapacity,
                 const ZSTD_Sequence* inSeqs, size_t inSeqsSize,
                 const void* src, size_t srcSize);
# 1704 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t
ZSTD_compressSequencesAndLiterals(ZSTD_CCtx* cctx,
                                  void* dst, size_t dstCapacity,
                            const ZSTD_Sequence* inSeqs, size_t nbSequences,
                            const void* literals, size_t litSize, size_t litBufCapacity,
                            size_t decompressedSize);
# 1725 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_writeSkippableFrame(void* dst, size_t dstCapacity,
                                             const void* src, size_t srcSize,
                                                   unsigned magicVariant);
# 1740 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_readSkippableFrame(void* dst, size_t dstCapacity,
                                                  unsigned* magicVariant,
                                                  const void* src, size_t srcSize);




__attribute__ ((visibility ("default"))) unsigned ZSTD_isSkippableFrame(const void* buffer, size_t size);
# 1782 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCCtxSize(int maxCompressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCCtxSize_usingCParams(ZSTD_compressionParameters cParams);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCCtxSize_usingCCtxParams(const ZSTD_CCtx_params* params);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDCtxSize(void);
# 1807 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCStreamSize(int maxCompressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCStreamSize_usingCParams(ZSTD_compressionParameters cParams);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCStreamSize_usingCCtxParams(const ZSTD_CCtx_params* params);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDStreamSize(size_t maxWindowSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDStreamSize_fromFrame(const void* src, size_t srcSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCDictSize(size_t dictSize, int compressionLevel);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateCDictSize_advanced(size_t dictSize, ZSTD_compressionParameters cParams, ZSTD_dictLoadMethod_e dictLoadMethod);
__attribute__ ((visibility ("default"))) size_t ZSTD_estimateDDictSize(size_t dictSize, ZSTD_dictLoadMethod_e dictLoadMethod);
# 1843 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_initStaticCCtx(void* workspace, size_t workspaceSize);
__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_initStaticCStream(void* workspace, size_t workspaceSize);

__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_initStaticDCtx(void* workspace, size_t workspaceSize);
__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_initStaticDStream(void* workspace, size_t workspaceSize);

__attribute__ ((visibility ("default"))) const ZSTD_CDict* ZSTD_initStaticCDict(
                                        void* workspace, size_t workspaceSize,
                                        const void* dict, size_t dictSize,
                                        ZSTD_dictLoadMethod_e dictLoadMethod,
                                        ZSTD_dictContentType_e dictContentType,
                                        ZSTD_compressionParameters cParams);

__attribute__ ((visibility ("default"))) const ZSTD_DDict* ZSTD_initStaticDDict(
                                        void* workspace, size_t workspaceSize,
                                        const void* dict, size_t dictSize,
                                        ZSTD_dictLoadMethod_e dictLoadMethod,
                                        ZSTD_dictContentType_e dictContentType);







typedef void* (*ZSTD_allocFunction) (void* opaque, size_t size);
typedef void (*ZSTD_freeFunction) (void* opaque, void* address);
typedef struct { ZSTD_allocFunction customAlloc; ZSTD_freeFunction customFree; void* opaque; } ZSTD_customMem;
static

__attribute__((__unused__))



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wzero-as-null-pointer-constant"

ZSTD_customMem const ZSTD_defaultCMem = { ((void*)0), ((void*)0), ((void*)0) };

#pragma clang diagnostic pop


__attribute__ ((visibility ("default"))) ZSTD_CCtx* ZSTD_createCCtx_advanced(ZSTD_customMem customMem);
__attribute__ ((visibility ("default"))) ZSTD_CStream* ZSTD_createCStream_advanced(ZSTD_customMem customMem);
__attribute__ ((visibility ("default"))) ZSTD_DCtx* ZSTD_createDCtx_advanced(ZSTD_customMem customMem);
__attribute__ ((visibility ("default"))) ZSTD_DStream* ZSTD_createDStream_advanced(ZSTD_customMem customMem);

__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict_advanced(const void* dict, size_t dictSize,
                                                  ZSTD_dictLoadMethod_e dictLoadMethod,
                                                  ZSTD_dictContentType_e dictContentType,
                                                  ZSTD_compressionParameters cParams,
                                                  ZSTD_customMem customMem);
# 1906 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef struct POOL_ctx_s ZSTD_threadPool;
__attribute__ ((visibility ("default"))) ZSTD_threadPool* ZSTD_createThreadPool(size_t numThreads);
__attribute__ ((visibility ("default"))) void ZSTD_freeThreadPool (ZSTD_threadPool* pool);
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refThreadPool(ZSTD_CCtx* cctx, ZSTD_threadPool* pool);





__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict_advanced2(
    const void* dict, size_t dictSize,
    ZSTD_dictLoadMethod_e dictLoadMethod,
    ZSTD_dictContentType_e dictContentType,
    const ZSTD_CCtx_params* cctxParams,
    ZSTD_customMem customMem);

__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict_advanced(
    const void* dict, size_t dictSize,
    ZSTD_dictLoadMethod_e dictLoadMethod,
    ZSTD_dictContentType_e dictContentType,
    ZSTD_customMem customMem);
# 1939 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CDict* ZSTD_createCDict_byReference(const void* dictBuffer, size_t dictSize, int compressionLevel);




__attribute__ ((visibility ("default"))) ZSTD_compressionParameters ZSTD_getCParams(int compressionLevel, unsigned long long estimatedSrcSize, size_t dictSize);




__attribute__ ((visibility ("default"))) ZSTD_parameters ZSTD_getParams(int compressionLevel, unsigned long long estimatedSrcSize, size_t dictSize);




__attribute__ ((visibility ("default"))) size_t ZSTD_checkCParams(ZSTD_compressionParameters params);







__attribute__ ((visibility ("default"))) ZSTD_compressionParameters ZSTD_adjustCParams(ZSTD_compressionParameters cPar, unsigned long long srcSize, size_t dictSize);
# 1971 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setCParams(ZSTD_CCtx* cctx, ZSTD_compressionParameters cparams);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setFParams(ZSTD_CCtx* cctx, ZSTD_frameParameters fparams);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParams(ZSTD_CCtx* cctx, ZSTD_parameters params);





__attribute__((deprecated("use ZSTD_compress2")))
__attribute__ ((visibility ("default")))
size_t ZSTD_compress_advanced(ZSTD_CCtx* cctx,
                              void* dst, size_t dstCapacity,
                        const void* src, size_t srcSize,
                        const void* dict,size_t dictSize,
                              ZSTD_parameters params);





__attribute__((deprecated("use ZSTD_compress2 with ZSTD_CCtx_loadDictionary")))
__attribute__ ((visibility ("default")))
size_t ZSTD_compress_usingCDict_advanced(ZSTD_CCtx* cctx,
                                              void* dst, size_t dstCapacity,
                                        const void* src, size_t srcSize,
                                        const ZSTD_CDict* cdict,
                                              ZSTD_frameParameters fParams);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary_byReference(ZSTD_CCtx* cctx, const void* dict, size_t dictSize);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_loadDictionary_advanced(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, ZSTD_dictLoadMethod_e dictLoadMethod, ZSTD_dictContentType_e dictContentType);




__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_refPrefix_advanced(ZSTD_CCtx* cctx, const void* prefix, size_t prefixSize, ZSTD_dictContentType_e dictContentType);
# 2364 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_getParameter(const ZSTD_CCtx* cctx, ZSTD_cParameter param, int* value);
# 2384 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) ZSTD_CCtx_params* ZSTD_createCCtxParams(void);
__attribute__ ((visibility ("default"))) size_t ZSTD_freeCCtxParams(ZSTD_CCtx_params* params);




__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_reset(ZSTD_CCtx_params* params);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_init(ZSTD_CCtx_params* cctxParams, int compressionLevel);





__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_init_advanced(ZSTD_CCtx_params* cctxParams, ZSTD_parameters params);
# 2412 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_setParameter(ZSTD_CCtx_params* params, ZSTD_cParameter param, int value);






__attribute__ ((visibility ("default"))) size_t ZSTD_CCtxParams_getParameter(const ZSTD_CCtx_params* params, ZSTD_cParameter param, int* value);
# 2428 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_CCtx_setParametersUsingCCtxParams(
        ZSTD_CCtx* cctx, const ZSTD_CCtx_params* params);







__attribute__ ((visibility ("default"))) size_t ZSTD_compressStream2_simpleArgs (
                            ZSTD_CCtx* cctx,
                            void* dst, size_t dstCapacity, size_t* dstPos,
                      const void* src, size_t srcSize, size_t* srcPos,
                            ZSTD_EndDirective endOp);
# 2453 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) unsigned ZSTD_isFrame(const void* buffer, size_t size);






__attribute__ ((visibility ("default"))) ZSTD_DDict* ZSTD_createDDict_byReference(const void* dictBuffer, size_t dictSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary_byReference(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_loadDictionary_advanced(ZSTD_DCtx* dctx, const void* dict, size_t dictSize, ZSTD_dictLoadMethod_e dictLoadMethod, ZSTD_dictContentType_e dictContentType);




__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_refPrefix_advanced(ZSTD_DCtx* dctx, const void* prefix, size_t prefixSize, ZSTD_dictContentType_e dictContentType);
# 2488 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_setMaxWindowSize(ZSTD_DCtx* dctx, size_t maxWindowSize);






__attribute__ ((visibility ("default"))) size_t ZSTD_DCtx_getParameter(ZSTD_DCtx* dctx, ZSTD_dParameter param, int* value);
# 2602 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_DCtx_setParameter() instead")))
__attribute__ ((visibility ("default")))
size_t ZSTD_DCtx_setFormat(ZSTD_DCtx* dctx, ZSTD_format_e format);







__attribute__ ((visibility ("default"))) size_t ZSTD_decompressStream_simpleArgs (
                            ZSTD_DCtx* dctx,
                            void* dst, size_t dstCapacity, size_t* dstPos,
                      const void* src, size_t srcSize, size_t* srcPos);
# 2639 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_CCtx_reset, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_srcSize(ZSTD_CStream* zcs,
                         int compressionLevel,
                         unsigned long long pledgedSrcSize);
# 2657 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_CCtx_reset, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_usingDict(ZSTD_CStream* zcs,
                     const void* dict, size_t dictSize,
                           int compressionLevel);
# 2675 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_CCtx_reset, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_advanced(ZSTD_CStream* zcs,
                    const void* dict, size_t dictSize,
                          ZSTD_parameters params,
                          unsigned long long pledgedSrcSize);
# 2690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_CCtx_reset and ZSTD_CCtx_refCDict, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_usingCDict(ZSTD_CStream* zcs, const ZSTD_CDict* cdict);
# 2706 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_CCtx_reset and ZSTD_CCtx_refCDict, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default")))
size_t ZSTD_initCStream_usingCDict_advanced(ZSTD_CStream* zcs,
                               const ZSTD_CDict* cdict,
                                     ZSTD_frameParameters fParams,
                                     unsigned long long pledgedSrcSize);
# 2731 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_CCtx_reset, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default")))
size_t ZSTD_resetCStream(ZSTD_CStream* zcs, unsigned long long pledgedSrcSize);


typedef struct {
    unsigned long long ingested;
    unsigned long long consumed;
    unsigned long long produced;
    unsigned long long flushed;
    unsigned currentJobID;
    unsigned nbActiveWorkers;
} ZSTD_frameProgression;







__attribute__ ((visibility ("default"))) ZSTD_frameProgression ZSTD_getFrameProgression(const ZSTD_CCtx* cctx);
# 2766 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_toFlushNow(ZSTD_CCtx* cctx);
# 2779 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_DCtx_reset + ZSTD_DCtx_loadDictionary, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream_usingDict(ZSTD_DStream* zds, const void* dict, size_t dictSize);
# 2790 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_DCtx_reset + ZSTD_DCtx_refDDict, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default"))) size_t ZSTD_initDStream_usingDDict(ZSTD_DStream* zds, const ZSTD_DDict* ddict);
# 2800 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("use ZSTD_DCtx_reset, see zstd.h for detailed instructions")))
__attribute__ ((visibility ("default"))) size_t ZSTD_resetDStream(ZSTD_DStream* zds);
# 2930 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
typedef size_t (*ZSTD_sequenceProducer_F) (
  void* sequenceProducerState,
  ZSTD_Sequence* outSeqs, size_t outSeqsCapacity,
  const void* src, size_t srcSize,
  const void* dict, size_t dictSize,
  int compressionLevel,
  size_t windowSize
);
# 2958 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) void
ZSTD_registerSequenceProducer(
  ZSTD_CCtx* cctx,
  void* sequenceProducerState,
  ZSTD_sequenceProducer_F sequenceProducer
);
# 2974 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) void
ZSTD_CCtxParams_registerSequenceProducer(
  ZSTD_CCtx_params* params,
  void* sequenceProducerState,
  ZSTD_sequenceProducer_F sequenceProducer
);
# 3026 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("The buffer-less API is deprecated in favor of the normal streaming API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBegin(ZSTD_CCtx* cctx, int compressionLevel);
__attribute__((deprecated("The buffer-less API is deprecated in favor of the normal streaming API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBegin_usingDict(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, int compressionLevel);
__attribute__((deprecated("The buffer-less API is deprecated in favor of the normal streaming API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBegin_usingCDict(ZSTD_CCtx* cctx, const ZSTD_CDict* cdict);

__attribute__((deprecated("This function will likely be removed in a future release. It is misleading and has very limited utility.")))
__attribute__ ((visibility ("default")))
size_t ZSTD_copyCCtx(ZSTD_CCtx* cctx, const ZSTD_CCtx* preparedCCtx, unsigned long long pledgedSrcSize);

__attribute__((deprecated("The buffer-less API is deprecated in favor of the normal streaming API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressContinue(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
__attribute__((deprecated("The buffer-less API is deprecated in favor of the normal streaming API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressEnd(ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);


__attribute__((deprecated("use advanced API to access custom parameters")))
__attribute__ ((visibility ("default")))
size_t ZSTD_compressBegin_advanced(ZSTD_CCtx* cctx, const void* dict, size_t dictSize, ZSTD_parameters params, unsigned long long pledgedSrcSize);
__attribute__((deprecated("use advanced API to access custom parameters")))
__attribute__ ((visibility ("default")))
size_t ZSTD_compressBegin_usingCDict_advanced(ZSTD_CCtx* const cctx, const ZSTD_CDict* const cdict, ZSTD_frameParameters const fParams, unsigned long long const pledgedSrcSize);
# 3124 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__ ((visibility ("default"))) size_t ZSTD_decodingBufferSize_min(unsigned long long windowSize, unsigned long long frameContentSize);

__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBegin(ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBegin_usingDict(ZSTD_DCtx* dctx, const void* dict, size_t dictSize);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBegin_usingDDict(ZSTD_DCtx* dctx, const ZSTD_DDict* ddict);

__attribute__ ((visibility ("default"))) size_t ZSTD_nextSrcSizeToDecompress(ZSTD_DCtx* dctx);
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressContinue(ZSTD_DCtx* dctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);


__attribute__((deprecated("This function will likely be removed in the next minor release. It is misleading and has very limited utility.")))
__attribute__ ((visibility ("default"))) void ZSTD_copyDCtx(ZSTD_DCtx* dctx, const ZSTD_DCtx* preparedDCtx);
typedef enum { ZSTDnit_frameHeader, ZSTDnit_blockHeader, ZSTDnit_block, ZSTDnit_lastBlock, ZSTDnit_checksum, ZSTDnit_skippableFrame } ZSTD_nextInputType_e;
__attribute__ ((visibility ("default"))) ZSTD_nextInputType_e ZSTD_nextInputType(ZSTD_DCtx* dctx);
# 3185 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/../zstd.h"
__attribute__((deprecated("The block API is deprecated in favor of the normal compression API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_getBlockSize (const ZSTD_CCtx* cctx);
__attribute__((deprecated("The block API is deprecated in favor of the normal compression API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_compressBlock (ZSTD_CCtx* cctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
__attribute__((deprecated("The block API is deprecated in favor of the normal compression API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_decompressBlock(ZSTD_DCtx* dctx, void* dst, size_t dstCapacity, const void* src, size_t srcSize);
__attribute__((deprecated("The block API is deprecated in favor of the normal compression API. See docs.")))
__attribute__ ((visibility ("default"))) size_t ZSTD_insertBlock (ZSTD_DCtx* dctx, const void* blockStart, size_t blockSize);
# 29 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h" 1
# 21 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 1
# 22 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h" 2
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
               unsigned FSE_versionNumber(void);





               size_t FSE_compressBound(size_t size);


               unsigned FSE_isError(size_t code);
               const char* FSE_getErrorName(size_t code);
# 87 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
               unsigned FSE_optimalTableLog(unsigned maxTableLog, size_t srcSize, unsigned maxSymbolValue);
# 100 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
               size_t FSE_normalizeCount(short* normalizedCounter, unsigned tableLog,
                    const unsigned* count, size_t srcSize, unsigned maxSymbolValue, unsigned useLowProbCount);




               size_t FSE_NCountWriteBound(unsigned maxSymbolValue, unsigned tableLog);





               size_t FSE_writeNCount (void* buffer, size_t bufferSize,
                                 const short* normalizedCounter,
                                 unsigned maxSymbolValue, unsigned tableLog);



typedef unsigned FSE_CTable;




               size_t FSE_buildCTable(FSE_CTable* ct, const short* normalizedCounter, unsigned maxSymbolValue, unsigned tableLog);






               size_t FSE_compress_usingCTable (void* dst, size_t dstCapacity, const void* src, size_t srcSize, const FSE_CTable* ct);
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
               size_t FSE_readNCount (short* normalizedCounter,
                           unsigned* maxSymbolValuePtr, unsigned* tableLogPtr,
                           const void* rBuffer, size_t rBuffSize);




               size_t FSE_readNCount_bmi2(short* normalizedCounter,
                           unsigned* maxSymbolValuePtr, unsigned* tableLogPtr,
                           const void* rBuffer, size_t rBuffSize, int bmi2);

typedef unsigned FSE_DTable;
# 229 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h" 1
# 30 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h" 1
# 16 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
static __inline __attribute__((unused)) unsigned ZSTD_countTrailingZeros32_fallback(U32 val)
{
    ((void)0);
    {
        static const U32 DeBruijnBytePos[32] = {0, 1, 28, 2, 29, 14, 24, 3,
                                                30, 22, 20, 15, 25, 17, 4, 8,
                                                31, 27, 13, 23, 21, 19, 16, 7,
                                                26, 12, 18, 6, 11, 5, 10, 9};
        return DeBruijnBytePos[((U32) ((val & -(S32) val) * 0x077CB531U)) >> 27];
    }
}

static __inline __attribute__((unused)) unsigned ZSTD_countTrailingZeros32(U32 val)
{
    ((void)0);
# 44 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
    return (unsigned)__builtin_ctz(val);





}

static __inline __attribute__((unused)) unsigned ZSTD_countLeadingZeros32_fallback(U32 val)
{
    ((void)0);
    {
        static const U32 DeBruijnClz[32] = {0, 9, 1, 10, 13, 21, 2, 29,
                                            11, 14, 16, 18, 22, 25, 3, 30,
                                            8, 12, 20, 28, 15, 17, 24, 7,
                                            19, 27, 23, 6, 26, 5, 4, 31};
        val |= val >> 1;
        val |= val >> 2;
        val |= val >> 4;
        val |= val >> 8;
        val |= val >> 16;
        return 31 - DeBruijnClz[(val * 0x07C4ACDDU) >> 27];
    }
}

static __inline __attribute__((unused)) unsigned ZSTD_countLeadingZeros32(U32 val)
{
    ((void)0);
# 85 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
    return (unsigned)__builtin_clz(val);





}

static __inline __attribute__((unused)) unsigned ZSTD_countTrailingZeros64(U64 val)
{
    ((void)0);
# 109 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
    return (unsigned)__builtin_ctzll(val);
# 123 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
}

static __inline __attribute__((unused)) unsigned ZSTD_countLeadingZeros64(U64 val)
{
    ((void)0);
# 141 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
    return (unsigned)(__builtin_clzll(val));
# 155 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bits.h"
}

static __inline __attribute__((unused)) unsigned ZSTD_NbCommonBytes(size_t val)
{
    if (MEM_isLittleEndian()) {
        if (MEM_64bits()) {
            return ZSTD_countTrailingZeros64((U64)val) >> 3;
        } else {
            return ZSTD_countTrailingZeros32((U32)val) >> 3;
        }
    } else {
        if (MEM_64bits()) {
            return ZSTD_countLeadingZeros64((U64)val) >> 3;
        } else {
            return ZSTD_countLeadingZeros32((U32)val) >> 3;
        }
    }
}

static __inline __attribute__((unused)) unsigned ZSTD_highbit32(U32 val)
{
    ((void)0);
    return 31 - ZSTD_countLeadingZeros32(val);
}





static __inline __attribute__((unused))
U64 ZSTD_rotateRight_U64(U64 const value, U32 count) {
    ((void)0);
    count &= 0x3F;
    return (value >> count) | (U64)(value << ((0U - count) & 0x3F));
}

static __inline __attribute__((unused))
U32 ZSTD_rotateRight_U32(U32 const value, U32 count) {
    ((void)0);
    count &= 0x1F;
    return (value >> count) | (U32)(value << ((0U - count) & 0x1F));
}

static __inline __attribute__((unused))
U16 ZSTD_rotateRight_U16(U16 const value, U32 count) {
    ((void)0);
    count &= 0x0F;
    return (value >> count) | (U16)(value << ((0U - count) & 0x0F));
}
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h" 2
# 51 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
typedef size_t BitContainerType;




typedef struct {
    BitContainerType bitContainer;
    unsigned bitPos;
    char* startPtr;
    char* ptr;
    char* endPtr;
} BIT_CStream_t;

static __inline __attribute__((unused)) size_t BIT_initCStream(BIT_CStream_t* bitC, void* dstBuffer, size_t dstCapacity);
static __inline __attribute__((unused)) void BIT_addBits(BIT_CStream_t* bitC, BitContainerType value, unsigned nbBits);
static __inline __attribute__((unused)) void BIT_flushBits(BIT_CStream_t* bitC);
static __inline __attribute__((unused)) size_t BIT_closeCStream(BIT_CStream_t* bitC);
# 90 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
typedef struct {
    BitContainerType bitContainer;
    unsigned bitsConsumed;
    const char* ptr;
    const char* start;
    const char* limitPtr;
} BIT_DStream_t;

typedef enum { BIT_DStream_unfinished = 0,
               BIT_DStream_endOfBuffer = 1,
               BIT_DStream_completed = 2,
               BIT_DStream_overflow = 3
    } BIT_DStream_status;

static __inline __attribute__((unused)) size_t BIT_initDStream(BIT_DStream_t* bitD, const void* srcBuffer, size_t srcSize);
static __inline __attribute__((unused)) BitContainerType BIT_readBits(BIT_DStream_t* bitD, unsigned nbBits);
static __inline __attribute__((unused)) BIT_DStream_status BIT_reloadDStream(BIT_DStream_t* bitD);
static __inline __attribute__((unused)) unsigned BIT_endOfDStream(const BIT_DStream_t* bitD);
# 124 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
static __inline __attribute__((unused)) void BIT_addBitsFast(BIT_CStream_t* bitC, BitContainerType value, unsigned nbBits);


static __inline __attribute__((unused)) void BIT_flushBitsFast(BIT_CStream_t* bitC);


static __inline __attribute__((unused)) size_t BIT_readBitsFast(BIT_DStream_t* bitD, unsigned nbBits);



static const unsigned BIT_mask[] = {
    0, 1, 3, 7, 0xF, 0x1F,
    0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF,
    0xFFF, 0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF, 0x1FFFF,
    0x3FFFF, 0x7FFFF, 0xFFFFF, 0x1FFFFF, 0x3FFFFF, 0x7FFFFF,
    0xFFFFFF, 0x1FFFFFF, 0x3FFFFFF, 0x7FFFFFF, 0xFFFFFFF, 0x1FFFFFFF,
    0x3FFFFFFF, 0x7FFFFFFF};
# 150 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
static __inline __attribute__((unused)) size_t BIT_initCStream(BIT_CStream_t* bitC,
                                  void* startPtr, size_t dstCapacity)
{
    bitC->bitContainer = 0;
    bitC->bitPos = 0;
    bitC->startPtr = (char*)startPtr;
    bitC->ptr = bitC->startPtr;
    bitC->endPtr = bitC->startPtr + dstCapacity - sizeof(bitC->bitContainer);
    if (dstCapacity <= sizeof(bitC->bitContainer)) return ((size_t)-ZSTD_error_dstSize_tooSmall);
    return 0;
}

static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_getLowerBits(BitContainerType bitContainer, U32 const nbBits)
{
# 172 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
    ((void)0);
    return bitContainer & BIT_mask[nbBits];

}




static __inline __attribute__((unused)) void BIT_addBits(BIT_CStream_t* bitC,
                            BitContainerType value, unsigned nbBits)
{
    (void)sizeof(char[((sizeof(BIT_mask) / sizeof(BIT_mask[0])) == 32) ? 1 : -1]);
    ((void)0);
    ((void)0);
    bitC->bitContainer |= BIT_getLowerBits(value, nbBits) << bitC->bitPos;
    bitC->bitPos += nbBits;
}




static __inline __attribute__((unused)) void BIT_addBitsFast(BIT_CStream_t* bitC,
                                BitContainerType value, unsigned nbBits)
{
    ((void)0);
    ((void)0);
    bitC->bitContainer |= value << bitC->bitPos;
    bitC->bitPos += nbBits;
}




static __inline __attribute__((unused)) void BIT_flushBitsFast(BIT_CStream_t* bitC)
{
    size_t const nbBytes = bitC->bitPos >> 3;
    ((void)0);
    ((void)0);
    MEM_writeLEST(bitC->ptr, bitC->bitContainer);
    bitC->ptr += nbBytes;
    bitC->bitPos &= 7;
    bitC->bitContainer >>= nbBytes*8;
}






static __inline __attribute__((unused)) void BIT_flushBits(BIT_CStream_t* bitC)
{
    size_t const nbBytes = bitC->bitPos >> 3;
    ((void)0);
    ((void)0);
    MEM_writeLEST(bitC->ptr, bitC->bitContainer);
    bitC->ptr += nbBytes;
    if (bitC->ptr > bitC->endPtr) bitC->ptr = bitC->endPtr;
    bitC->bitPos &= 7;
    bitC->bitContainer >>= nbBytes*8;
}




static __inline __attribute__((unused)) size_t BIT_closeCStream(BIT_CStream_t* bitC)
{
    BIT_addBitsFast(bitC, 1, 1);
    BIT_flushBits(bitC);
    if (bitC->ptr >= bitC->endPtr) return 0;
    return (size_t)(bitC->ptr - bitC->startPtr) + (bitC->bitPos > 0);
}
# 254 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/bitstream.h"
static __inline __attribute__((unused)) size_t BIT_initDStream(BIT_DStream_t* bitD, const void* srcBuffer, size_t srcSize)
{
    if (srcSize < 1) { __builtin_memset((bitD),(0),(sizeof(*bitD))); return ((size_t)-ZSTD_error_srcSize_wrong); }

    bitD->start = (const char*)srcBuffer;
    bitD->limitPtr = bitD->start + sizeof(bitD->bitContainer);

    if (srcSize >= sizeof(bitD->bitContainer)) {
        bitD->ptr = (const char*)srcBuffer + srcSize - sizeof(bitD->bitContainer);
        bitD->bitContainer = MEM_readLEST(bitD->ptr);
        { BYTE const lastByte = ((const BYTE*)srcBuffer)[srcSize-1];
          bitD->bitsConsumed = lastByte ? 8 - ZSTD_highbit32(lastByte) : 0;
          if (lastByte == 0) return ((size_t)-ZSTD_error_GENERIC); }
    } else {
        bitD->ptr = bitD->start;
        bitD->bitContainer = *(const BYTE*)(bitD->start);
        switch(srcSize)
        {
        case 7: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[6]) << (sizeof(bitD->bitContainer)*8 - 16);
                ; __attribute__((__fallthrough__));

        case 6: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[5]) << (sizeof(bitD->bitContainer)*8 - 24);
                ; __attribute__((__fallthrough__));

        case 5: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[4]) << (sizeof(bitD->bitContainer)*8 - 32);
                ; __attribute__((__fallthrough__));

        case 4: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[3]) << 24;
                ; __attribute__((__fallthrough__));

        case 3: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[2]) << 16;
                ; __attribute__((__fallthrough__));

        case 2: bitD->bitContainer += (BitContainerType)(((const BYTE*)(srcBuffer))[1]) << 8;
                ; __attribute__((__fallthrough__));

        default: break;
        }
        { BYTE const lastByte = ((const BYTE*)srcBuffer)[srcSize-1];
            bitD->bitsConsumed = lastByte ? 8 - ZSTD_highbit32(lastByte) : 0;
            if (lastByte == 0) return ((size_t)-ZSTD_error_corruption_detected);
        }
        bitD->bitsConsumed += (U32)(sizeof(bitD->bitContainer) - srcSize)*8;
    }

    return srcSize;
}

static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_getUpperBits(BitContainerType bitContainer, U32 const start)
{
    return bitContainer >> start;
}

static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_getMiddleBits(BitContainerType bitContainer, U32 const start, U32 const nbBits)
{
    U32 const regMask = sizeof(bitContainer)*8 - 1;

    ((void)0);






    return (bitContainer >> (start & regMask)) & ((((U64)1) << nbBits) - 1);



}







static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_lookBits(const BIT_DStream_t* bitD, U32 nbBits)
{




    return BIT_getMiddleBits(bitD->bitContainer, (sizeof(bitD->bitContainer)*8) - bitD->bitsConsumed - nbBits, nbBits);





}



static __inline __attribute__((unused)) BitContainerType BIT_lookBitsFast(const BIT_DStream_t* bitD, U32 nbBits)
{
    U32 const regMask = sizeof(bitD->bitContainer)*8 - 1;
    ((void)0);
    return (bitD->bitContainer << (bitD->bitsConsumed & regMask)) >> (((regMask+1)-nbBits) & regMask);
}

static inline __attribute__((always_inline)) __attribute__((unused)) void BIT_skipBits(BIT_DStream_t* bitD, U32 nbBits)
{
    bitD->bitsConsumed += nbBits;
}





static inline __attribute__((always_inline)) __attribute__((unused)) BitContainerType BIT_readBits(BIT_DStream_t* bitD, unsigned nbBits)
{
    BitContainerType const value = BIT_lookBits(bitD, nbBits);
    BIT_skipBits(bitD, nbBits);
    return value;
}



static __inline __attribute__((unused)) BitContainerType BIT_readBitsFast(BIT_DStream_t* bitD, unsigned nbBits)
{
    BitContainerType const value = BIT_lookBitsFast(bitD, nbBits);
    ((void)0);
    BIT_skipBits(bitD, nbBits);
    return value;
}






static __inline __attribute__((unused)) BIT_DStream_status BIT_reloadDStream_internal(BIT_DStream_t* bitD)
{
    ((void)0);
    bitD->ptr -= bitD->bitsConsumed >> 3;
    ((void)0);
    bitD->bitsConsumed &= 7;
    bitD->bitContainer = MEM_readLEST(bitD->ptr);
    return BIT_DStream_unfinished;
}







static __inline __attribute__((unused)) BIT_DStream_status BIT_reloadDStreamFast(BIT_DStream_t* bitD)
{
    if ((__builtin_expect((bitD->ptr < bitD->limitPtr), 0)))
        return BIT_DStream_overflow;
    return BIT_reloadDStream_internal(bitD);
}






static inline __attribute__((always_inline)) __attribute__((unused)) BIT_DStream_status BIT_reloadDStream(BIT_DStream_t* bitD)
{

    if ((__builtin_expect((bitD->bitsConsumed > (sizeof(bitD->bitContainer)*8)), 0))) {
        static const BitContainerType zeroFilled = 0;
        bitD->ptr = (const char*)&zeroFilled;

        return BIT_DStream_overflow;
    }

    ((void)0);

    if (bitD->ptr >= bitD->limitPtr) {
        return BIT_reloadDStream_internal(bitD);
    }
    if (bitD->ptr == bitD->start) {

        if (bitD->bitsConsumed < sizeof(bitD->bitContainer)*8) return BIT_DStream_endOfBuffer;
        return BIT_DStream_completed;
    }

    { U32 nbBytes = bitD->bitsConsumed >> 3;
        BIT_DStream_status result = BIT_DStream_unfinished;
        if (bitD->ptr - nbBytes < bitD->start) {
            nbBytes = (U32)(bitD->ptr - bitD->start);
            result = BIT_DStream_endOfBuffer;
        }
        bitD->ptr -= nbBytes;
        bitD->bitsConsumed -= nbBytes*8;
        bitD->bitContainer = MEM_readLEST(bitD->ptr);
        return result;
    }
}




static __inline __attribute__((unused)) unsigned BIT_endOfDStream(const BIT_DStream_t* DStream)
{
    return ((DStream->ptr == DStream->start) && (DStream->bitsConsumed == sizeof(DStream->bitContainer)*8));
}
# 230 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h" 2
# 252 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
unsigned FSE_optimalTableLog_internal(unsigned maxTableLog, size_t srcSize, unsigned maxSymbolValue, unsigned minus);


size_t FSE_buildCTable_rle (FSE_CTable* ct, unsigned char symbolValue);
# 265 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
size_t FSE_buildCTable_wksp(FSE_CTable* ct, const short* normalizedCounter, unsigned maxSymbolValue, unsigned tableLog, void* workSpace, size_t wkspSize);



               size_t FSE_buildDTable_wksp(FSE_DTable* dt, const short* normalizedCounter, unsigned maxSymbolValue, unsigned tableLog, void* workSpace, size_t wkspSize);




size_t FSE_decompress_wksp_bmi2(void* dst, size_t dstCapacity, const void* cSrc, size_t cSrcSize, unsigned maxLog, void* workSpace, size_t wkspSize, int bmi2);



typedef enum {
   FSE_repeat_none,
   FSE_repeat_check,
   FSE_repeat_valid
 } FSE_repeat;
# 291 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
typedef struct {
    ptrdiff_t value;
    const void* stateTable;
    const void* symbolTT;
    unsigned stateLog;
} FSE_CState_t;

static void FSE_initCState(FSE_CState_t* CStatePtr, const FSE_CTable* ct);

static void FSE_encodeSymbol(BIT_CStream_t* bitC, FSE_CState_t* CStatePtr, unsigned symbol);

static void FSE_flushCState(BIT_CStream_t* bitC, const FSE_CState_t* CStatePtr);
# 351 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
typedef struct {
    size_t state;
    const void* table;
} FSE_DState_t;


static void FSE_initDState(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD, const FSE_DTable* dt);

static unsigned char FSE_decodeSymbol(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD);

static unsigned FSE_endOfDState(const FSE_DState_t* DStatePtr);
# 416 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h"
static unsigned char FSE_decodeSymbolFast(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD);






typedef struct {
    int deltaFindState;
    U32 deltaNbBits;
} FSE_symbolCompressionTransform;

static __inline __attribute__((unused)) void FSE_initCState(FSE_CState_t* statePtr, const FSE_CTable* ct)
{
    const void* ptr = ct;
    const U16* u16ptr = (const U16*) ptr;
    const U32 tableLog = MEM_read16(ptr);
    statePtr->value = (ptrdiff_t)1<<tableLog;
    statePtr->stateTable = u16ptr+2;
    statePtr->symbolTT = ct + 1 + (tableLog ? (1<<(tableLog-1)) : 1);
    statePtr->stateLog = tableLog;
}





static __inline __attribute__((unused)) void FSE_initCState2(FSE_CState_t* statePtr, const FSE_CTable* ct, U32 symbol)
{
    FSE_initCState(statePtr, ct);
    { const FSE_symbolCompressionTransform symbolTT = ((const FSE_symbolCompressionTransform*)(statePtr->symbolTT))[symbol];
        const U16* stateTable = (const U16*)(statePtr->stateTable);
        U32 nbBitsOut = (U32)((symbolTT.deltaNbBits + (1<<15)) >> 16);
        statePtr->value = (nbBitsOut << 16) - symbolTT.deltaNbBits;
        statePtr->value = stateTable[(statePtr->value >> nbBitsOut) + symbolTT.deltaFindState];
    }
}

static __inline __attribute__((unused)) void FSE_encodeSymbol(BIT_CStream_t* bitC, FSE_CState_t* statePtr, unsigned symbol)
{
    FSE_symbolCompressionTransform const symbolTT = ((const FSE_symbolCompressionTransform*)(statePtr->symbolTT))[symbol];
    const U16* const stateTable = (const U16*)(statePtr->stateTable);
    U32 const nbBitsOut = (U32)((statePtr->value + symbolTT.deltaNbBits) >> 16);
    BIT_addBits(bitC, (BitContainerType)statePtr->value, nbBitsOut);
    statePtr->value = stateTable[ (statePtr->value >> nbBitsOut) + symbolTT.deltaFindState];
}

static __inline __attribute__((unused)) void FSE_flushCState(BIT_CStream_t* bitC, const FSE_CState_t* statePtr)
{
    BIT_addBits(bitC, (BitContainerType)statePtr->value, statePtr->stateLog);
    BIT_flushBits(bitC);
}







static __inline __attribute__((unused)) U32 FSE_getMaxNbBits(const void* symbolTTPtr, U32 symbolValue)
{
    const FSE_symbolCompressionTransform* symbolTT = (const FSE_symbolCompressionTransform*) symbolTTPtr;
    return (symbolTT[symbolValue].deltaNbBits + ((1<<16)-1)) >> 16;
}





static __inline __attribute__((unused)) U32 FSE_bitCost(const void* symbolTTPtr, U32 tableLog, U32 symbolValue, U32 accuracyLog)
{
    const FSE_symbolCompressionTransform* symbolTT = (const FSE_symbolCompressionTransform*) symbolTTPtr;
    U32 const minNbBits = symbolTT[symbolValue].deltaNbBits >> 16;
    U32 const threshold = (minNbBits+1) << 16;
    ((void)0);
    ((void)0);
    { U32 const tableSize = 1 << tableLog;
        U32 const deltaFromThreshold = threshold - (symbolTT[symbolValue].deltaNbBits + tableSize);
        U32 const normalizedDeltaFromThreshold = (deltaFromThreshold << accuracyLog) >> tableLog;
        U32 const bitMultiplier = 1 << accuracyLog;
        ((void)0);
        ((void)0);
        return (minNbBits+1)*bitMultiplier - normalizedDeltaFromThreshold;
    }
}




typedef struct {
    U16 tableLog;
    U16 fastMode;
} FSE_DTableHeader;

typedef struct
{
    unsigned short newState;
    unsigned char symbol;
    unsigned char nbBits;
} FSE_decode_t;

static __inline __attribute__((unused)) void FSE_initDState(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD, const FSE_DTable* dt)
{
    const void* ptr = dt;
    const FSE_DTableHeader* const DTableH = (const FSE_DTableHeader*)ptr;
    DStatePtr->state = BIT_readBits(bitD, DTableH->tableLog);
    BIT_reloadDStream(bitD);
    DStatePtr->table = dt + 1;
}

static __inline __attribute__((unused)) BYTE FSE_peekSymbol(const FSE_DState_t* DStatePtr)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    return DInfo.symbol;
}

static __inline __attribute__((unused)) void FSE_updateState(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    U32 const nbBits = DInfo.nbBits;
    size_t const lowBits = BIT_readBits(bitD, nbBits);
    DStatePtr->state = DInfo.newState + lowBits;
}

static __inline __attribute__((unused)) BYTE FSE_decodeSymbol(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    U32 const nbBits = DInfo.nbBits;
    BYTE const symbol = DInfo.symbol;
    size_t const lowBits = BIT_readBits(bitD, nbBits);

    DStatePtr->state = DInfo.newState + lowBits;
    return symbol;
}



static __inline __attribute__((unused)) BYTE FSE_decodeSymbolFast(FSE_DState_t* DStatePtr, BIT_DStream_t* bitD)
{
    FSE_decode_t const DInfo = ((const FSE_decode_t*)(DStatePtr->table))[DStatePtr->state];
    U32 const nbBits = DInfo.nbBits;
    BYTE const symbol = DInfo.symbol;
    size_t const lowBits = BIT_readBitsFast(bitD, nbBits);

    DStatePtr->state = DInfo.newState + lowBits;
    return symbol;
}

static __inline __attribute__((unused)) unsigned FSE_endOfDState(const FSE_DState_t* DStatePtr)
{
    return DStatePtr->state == 0;
}
# 31 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 2
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h" 1
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_deps.h" 1
# 20 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h" 2


# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/fse.h" 1
# 23 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h" 2



size_t HUF_compressBound(size_t size);


unsigned HUF_isError(size_t code);
const char* HUF_getErrorName(size_t code);
# 57 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
typedef size_t HUF_CElt;






typedef U32 HUF_DTable;
# 80 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
typedef enum {




    HUF_flags_bmi2 = (1 << 0),




    HUF_flags_optimalDepth = (1 << 1),




    HUF_flags_preferRepeat = (1 << 2),




    HUF_flags_suspectUncompressible = (1 << 3),




    HUF_flags_disableAsm = (1 << 4),




    HUF_flags_disableFast = (1 << 5)
} HUF_flags_e;
# 130 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
unsigned HUF_minTableLog(unsigned symbolCardinality);
unsigned HUF_cardinality(const unsigned* count, unsigned maxSymbolValue);
unsigned HUF_optimalTableLog(unsigned maxTableLog, size_t srcSize, unsigned maxSymbolValue, void* workSpace,
 size_t wkspSize, HUF_CElt* table, const unsigned* count, int flags);
size_t HUF_writeCTable_wksp(void* dst, size_t maxDstSize, const HUF_CElt* CTable, unsigned maxSymbolValue, unsigned huffLog, void* workspace, size_t workspaceSize);
size_t HUF_compress4X_usingCTable(void* dst, size_t dstSize, const void* src, size_t srcSize, const HUF_CElt* CTable, int flags);
size_t HUF_estimateCompressedSize(const HUF_CElt* CTable, const unsigned* count, unsigned maxSymbolValue);
int HUF_validateCTable(const HUF_CElt* CTable, const unsigned* count, unsigned maxSymbolValue);

typedef enum {
   HUF_repeat_none,
   HUF_repeat_check,
   HUF_repeat_valid
 } HUF_repeat;







size_t HUF_compress4X_repeat(void* dst, size_t dstSize,
                       const void* src, size_t srcSize,
                       unsigned maxSymbolValue, unsigned tableLog,
                       void* workSpace, size_t wkspSize,
                       HUF_CElt* hufTable, HUF_repeat* repeat, int flags);







size_t HUF_buildCTable_wksp (HUF_CElt* tree,
                       const unsigned* count, U32 maxSymbolValue, U32 maxNbBits,
                             void* workSpace, size_t wkspSize);






size_t HUF_readStats(BYTE* huffWeight, size_t hwSize,
                     U32* rankStats, U32* nbSymbolsPtr, U32* tableLogPtr,
                     const void* src, size_t srcSize);
# 183 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
size_t HUF_readStats_wksp(BYTE* huffWeight, size_t hwSize,
                          U32* rankStats, U32* nbSymbolsPtr, U32* tableLogPtr,
                          const void* src, size_t srcSize,
                          void* workspace, size_t wkspSize,
                          int flags);



size_t HUF_readCTable (HUF_CElt* CTable, unsigned* maxSymbolValuePtr, const void* src, size_t srcSize, unsigned *hasZeroWeights);






U32 HUF_getNbBitsFromCTable(const HUF_CElt* symbolTable, U32 symbolValue);

typedef struct {
    BYTE tableLog;
    BYTE maxSymbolValue;
    BYTE unused[sizeof(size_t) - 2];
} HUF_CTableHeader;




HUF_CTableHeader HUF_readCTableHeader(HUF_CElt const* ctable);
# 223 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
U32 HUF_selectDecoder (size_t dstSize, size_t cSrcSize);
# 243 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/huf.h"
size_t HUF_compress1X_usingCTable(void* dst, size_t dstSize, const void* src, size_t srcSize, const HUF_CElt* CTable, int flags);






size_t HUF_compress1X_repeat(void* dst, size_t dstSize,
                       const void* src, size_t srcSize,
                       unsigned maxSymbolValue, unsigned tableLog,
                       void* workSpace, size_t wkspSize,
                       HUF_CElt* hufTable, HUF_repeat* repeat, int flags);

size_t HUF_decompress1X_DCtx_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);

size_t HUF_decompress1X2_DCtx_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);





size_t HUF_decompress1X_usingDTable(void* dst, size_t maxDstSize, const void* cSrc, size_t cSrcSize, const HUF_DTable* DTable, int flags);

size_t HUF_decompress1X1_DCtx_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);

size_t HUF_decompress4X_usingDTable(void* dst, size_t maxDstSize, const void* cSrc, size_t cSrcSize, const HUF_DTable* DTable, int flags);
size_t HUF_decompress4X_hufOnly_wksp(HUF_DTable* dctx, void* dst, size_t dstSize, const void* cSrc, size_t cSrcSize, void* workSpace, size_t wkspSize, int flags);

size_t HUF_readDTableX1_wksp(HUF_DTable* DTable, const void* src, size_t srcSize, void* workSpace, size_t wkspSize, int flags);


size_t HUF_readDTableX2_wksp(HUF_DTable* DTable, const void* src, size_t srcSize, void* workSpace, size_t wkspSize, int flags);
# 32 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 2



# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h" 1
# 547 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((const)) unsigned ZSTD_XXH_versionNumber (void);
# 556 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 557 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h" 2



typedef enum {
    XXH_OK = 0,
    XXH_ERROR
} XXH_errorcode;
# 585 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
    typedef uint32_t XXH32_hash_t;
# 635 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((pure)) XXH32_hash_t ZSTD_XXH32 (const void* input, size_t length, XXH32_hash_t seed);
# 644 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
typedef struct XXH32_state_s XXH32_state_t;
# 654 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((malloc)) XXH32_state_t* ZSTD_XXH32_createState(void);
# 665 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               XXH_errorcode ZSTD_XXH32_freeState(XXH32_state_t* statePtr);
# 674 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               void ZSTD_XXH32_copyState(XXH32_state_t* dst_state, const XXH32_state_t* src_state);
# 690 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               XXH_errorcode ZSTD_XXH32_reset (XXH32_state_t* statePtr, XXH32_hash_t seed);
# 711 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               XXH_errorcode ZSTD_XXH32_update (XXH32_state_t* statePtr, const void* input, size_t length);
# 727 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((pure)) XXH32_hash_t ZSTD_XXH32_digest (const XXH32_state_t* statePtr);







typedef struct {
    unsigned char digest[4];
} XXH32_canonical_t;
# 750 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               void ZSTD_XXH32_canonicalFromHash(XXH32_canonical_t* dst, XXH32_hash_t hash);
# 764 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((pure)) XXH32_hash_t ZSTD_XXH32_hashFromCanonical(const XXH32_canonical_t* src);
# 859 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
   typedef uint64_t XXH64_hash_t;
# 904 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((pure)) XXH64_hash_t ZSTD_XXH64(__attribute__((noescape)) const void* input, size_t length, XXH64_hash_t seed);
# 913 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
typedef struct XXH64_state_s XXH64_state_t;
# 923 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((malloc)) XXH64_state_t* ZSTD_XXH64_createState(void);
# 934 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               XXH_errorcode ZSTD_XXH64_freeState(XXH64_state_t* statePtr);
# 944 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               void ZSTD_XXH64_copyState(__attribute__((noescape)) XXH64_state_t* dst_state, const XXH64_state_t* src_state);
# 960 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               XXH_errorcode ZSTD_XXH64_reset (__attribute__((noescape)) XXH64_state_t* statePtr, XXH64_hash_t seed);
# 981 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               XXH_errorcode ZSTD_XXH64_update (__attribute__((noescape)) XXH64_state_t* statePtr, __attribute__((noescape)) const void* input, size_t length);
# 997 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((pure)) XXH64_hash_t ZSTD_XXH64_digest (__attribute__((noescape)) const XXH64_state_t* statePtr);






typedef struct { unsigned char digest[sizeof(XXH64_hash_t)]; } XXH64_canonical_t;
# 1017 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               void ZSTD_XXH64_canonicalFromHash(__attribute__((noescape)) XXH64_canonical_t* dst, XXH64_hash_t hash);
# 1031 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
               __attribute__((pure)) XXH64_hash_t ZSTD_XXH64_hashFromCanonical(__attribute__((noescape)) const XXH64_canonical_t* src);
# 1619 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
struct XXH32_state_s {
   XXH32_hash_t total_len_32;
   XXH32_hash_t large_len;
   XXH32_hash_t v[4];
   XXH32_hash_t mem32[4];
   XXH32_hash_t memsize;
   XXH32_hash_t reserved;
};
# 1643 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/xxhash.h"
struct XXH64_state_s {
   XXH64_hash_t total_len;
   XXH64_hash_t v[4];
   XXH64_hash_t mem64[4];
   XXH32_hash_t memsize;
   XXH32_hash_t reserved32;
   XXH64_hash_t reserved64;
};
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 2

# 1 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h" 1
# 14 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h"
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3
# 15 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h" 2
# 47 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h"
struct ZSTD_CCtx_s;
struct ZSTD_DCtx_s;
struct ZSTD_CCtx_params_s;

typedef struct {
# 60 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h"
    unsigned version;



    int streaming;



    unsigned dictionaryID;




    int dictionaryIsCold;



    size_t dictionarySize;



    size_t uncompressedSize;



    size_t compressedSize;



    struct ZSTD_CCtx_params_s const* params;



    struct ZSTD_CCtx_s const* cctx;



    struct ZSTD_DCtx_s const* dctx;
} ZSTD_Trace;
# 114 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h"
typedef unsigned long long ZSTD_TraceCtx;
# 123 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h"
__attribute__((__weak__)) ZSTD_TraceCtx ZSTD_trace_compress_begin(
    struct ZSTD_CCtx_s const* cctx);






__attribute__((__weak__)) void ZSTD_trace_compress_end(
    ZSTD_TraceCtx ctx,
    ZSTD_Trace const* trace);
# 142 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_trace.h"
__attribute__((__weak__)) ZSTD_TraceCtx ZSTD_trace_decompress_begin(
    struct ZSTD_DCtx_s const* dctx);






__attribute__((__weak__)) void ZSTD_trace_decompress_end(
    ZSTD_TraceCtx ctx,
    ZSTD_Trace const* trace);
# 38 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h" 2
# 65 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
static __attribute__((unused)) const U32 repStartValue[3] = { 1, 4, 8 };
# 79 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
static __attribute__((unused)) const size_t ZSTD_fcs_fieldSize[4] = { 0, 2, 4, 8 };
static __attribute__((unused)) const size_t ZSTD_did_fieldSize[4] = { 0, 1, 2, 4 };




static __attribute__((unused)) const size_t ZSTD_blockHeaderSize = 3;
typedef enum { bt_raw, bt_rle, bt_compressed, bt_reserved } blockType_e;







typedef enum { set_basic, set_rle, set_compressed, set_repeat } SymbolEncodingType_e;
# 119 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
static __attribute__((unused)) const U8 LL_bits[35 +1] = {
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 2, 2, 3, 3,
     4, 6, 7, 8, 9,10,11,12,
    13,14,15,16
};
static __attribute__((unused)) const S16 LL_defaultNorm[35 +1] = {
     4, 3, 2, 2, 2, 2, 2, 2,
     2, 2, 2, 2, 2, 1, 1, 1,
     2, 2, 2, 2, 2, 2, 2, 2,
     2, 3, 2, 1, 1, 1, 1, 1,
    -1,-1,-1,-1
};

static __attribute__((unused)) const U32 LL_defaultNormLog = 6;

static __attribute__((unused)) const U8 ML_bits[52 +1] = {
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, 0, 0, 0, 0, 0,
     1, 1, 1, 1, 2, 2, 3, 3,
     4, 4, 5, 7, 8, 9,10,11,
    12,13,14,15,16
};
static __attribute__((unused)) const S16 ML_defaultNorm[52 +1] = {
     1, 4, 3, 2, 2, 2, 2, 2,
     2, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1,-1,-1,
    -1,-1,-1,-1,-1
};

static __attribute__((unused)) const U32 ML_defaultNormLog = 6;

static __attribute__((unused)) const S16 OF_defaultNorm[28 +1] = {
     1, 1, 1, 1, 1, 1, 2, 2,
     2, 1, 1, 1, 1, 1, 1, 1,
     1, 1, 1, 1, 1, 1, 1, 1,
    -1,-1,-1,-1,-1
};

static __attribute__((unused)) const U32 OF_defaultNormLog = 5;





static void ZSTD_copy8(void* dst, const void* src) {



    __builtin_memcpy((dst),(src),(8));

}






static void ZSTD_copy16(void* dst, const void* src) {



    _mm_storeu_si128((__m128i*)dst, _mm_loadu_si128((const __m128i*)src));
# 196 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
}





typedef enum {
    ZSTD_no_overlap,
    ZSTD_overlap_src_before_dst

} ZSTD_overlap_e;
# 215 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
static __inline __attribute__((unused)) __attribute__((always_inline))
void ZSTD_wildcopy(void* dst, const void* src, ptrdiff_t length, ZSTD_overlap_e const ovtype)
{
    ptrdiff_t diff = (BYTE*)dst - (const BYTE*)src;
    const BYTE* ip = (const BYTE*)src;
    BYTE* op = (BYTE*)dst;
    BYTE* const oend = op + length;

    if (ovtype == ZSTD_overlap_src_before_dst && diff < 16) {

        do {
            do { ZSTD_copy8(op,ip); op+=8; ip+=8; } while (0);
        } while (op < oend);
    } else {
        ((void)0);






        ZSTD_copy16(op, ip);
        if (16 >= length) return;
        op += 16;
        ip += 16;
        do {
            do { ZSTD_copy16(op,ip); op+=16; ip+=16; } while (0);
            do { ZSTD_copy16(op,ip); op+=16; ip+=16; } while (0);
        }
        while (op < oend);
    }
}

static __inline __attribute__((unused)) size_t ZSTD_limitCopy(void* dst, size_t dstCapacity, const void* src, size_t srcSize)
{
    size_t const length = ((dstCapacity)<(srcSize) ? (dstCapacity) : (srcSize));
    if (length > 0) {
        __builtin_memcpy((dst),(src),(length));
    }
    return length;
}
# 268 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
typedef enum {
    ZSTD_bm_buffered = 0,
    ZSTD_bm_stable = 1
} ZSTD_bufferMode_e;
# 284 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_internal.h"
typedef struct {
    size_t nbBlocks;
    size_t compressedSize;
    unsigned long long decompressedBound;
} ZSTD_frameSizeInfo;





void ZSTD_invalidateRepCodes(ZSTD_CCtx* cctx);


typedef struct {
    blockType_e blockType;
    U32 lastBlock;
    U32 origSize;
} blockProperties_t;




size_t ZSTD_getcBlockSize(const void* src, size_t srcSize,
                          blockProperties_t* bpPtr);




size_t ZSTD_decodeSeqHeaders(ZSTD_DCtx* dctx, int* nbSeqPtr,
                       const void* src, size_t srcSize);




static __inline __attribute__((unused)) int ZSTD_cpuSupportsBmi2(void)
{
    ZSTD_cpuid_t cpuid = ZSTD_cpuid();
    return ZSTD_cpuid_bmi1(cpuid) && ZSTD_cpuid_bmi2(cpuid);
}
# 19 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_common.c" 2





unsigned ZSTD_versionNumber(void) { return (1 *100*100 + 5 *100 + 7); }

const char* ZSTD_versionString(void) { return "1.5.7"; }
# 36 "/home/dev-user/.cache/toucan/source-audit-corpus/sources/zstd-1.5.7/lib/common/zstd_common.c"
unsigned ZSTD_isError(size_t code) { return ERR_isError(code); }



const char* ZSTD_getErrorName(size_t code) { return ERR_getErrorName(code); }



ZSTD_ErrorCode ZSTD_getErrorCode(size_t code) { return ERR_getErrorCode(code); }



const char* ZSTD_getErrorString(ZSTD_ErrorCode code) { return ERR_getErrorString(code); }
