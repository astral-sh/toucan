__declspec(dllimport) int x; void g(void){typedef int x; {extern int x;static int*p=&x;} }
