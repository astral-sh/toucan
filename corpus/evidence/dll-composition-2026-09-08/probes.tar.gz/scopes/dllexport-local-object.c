__declspec(dllexport) int x; void g(void){int x; {extern int x;static int*p=&x;} }
