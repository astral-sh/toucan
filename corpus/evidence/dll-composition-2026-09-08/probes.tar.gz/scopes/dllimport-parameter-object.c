__declspec(dllimport) int x; void g(int x){ {extern int x;static int*p=&x;} }
