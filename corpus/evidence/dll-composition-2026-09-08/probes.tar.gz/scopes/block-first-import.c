void a(void){__declspec(dllimport) extern int x;} void b(int x){{extern int x;static int*p=&x;}}
