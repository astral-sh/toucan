__declspec(dllimport) extern int x;void a(void){static int x;static int*p=&x;}
