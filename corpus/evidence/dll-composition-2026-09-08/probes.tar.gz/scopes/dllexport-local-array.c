__declspec(dllexport) int x[4]; void g(void){int x; {extern int x[4];static int*p=x;} }
