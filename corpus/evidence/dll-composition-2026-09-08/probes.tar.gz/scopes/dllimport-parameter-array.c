__declspec(dllimport) int x[4]; void g(int x){ {extern int x[4];static int*p=x;} }
