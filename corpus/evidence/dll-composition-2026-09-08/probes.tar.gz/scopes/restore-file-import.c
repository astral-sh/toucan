__declspec(dllimport) extern int x;void a(void){{__declspec(dllexport) extern int x;}{int x;{extern int x;static int*p=&x;}}}
