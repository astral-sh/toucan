extern int x;void a(void){{__declspec(dllimport) extern int x;}{int x;{extern int x;static int*p=&x;}}}
