__declspec(dllexport) __inline__ int x(void){return 1;} void g(void){int x; {extern int x(void);} } int(*p)(void)=x;
