void * malloc(unsigned long long) __asm__("alias_5"); void g(int n){(void)sizeof(sizeof(int[(malloc(1),n)]));} __declspec(dllexport) void * malloc(unsigned long long);
