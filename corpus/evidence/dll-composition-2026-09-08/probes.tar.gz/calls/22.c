 void g(int n){(void)_Generic((__builtin_calloc(1,2),1),int:0);} __declspec(dllexport) void * __builtin_calloc(unsigned long long,unsigned long long);
