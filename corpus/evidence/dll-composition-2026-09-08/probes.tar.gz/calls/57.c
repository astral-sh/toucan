 void g(int n){(void)sizeof(sizeof(int[(__builtin_free((void*)0),n)]));} __declspec(dllexport) void __builtin_free(void*);
