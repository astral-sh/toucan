 void g(int n){(void)_Generic((__builtin_realloc((void*)0,2),1),int:0);} __declspec(dllexport) void * __builtin_realloc(void*,unsigned long long);
