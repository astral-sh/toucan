void * __builtin_malloc(unsigned long long); void g(int n){(void)sizeof(sizeof(int[(__builtin_malloc(1),n)]));} __declspec(dllexport) void * __builtin_malloc(unsigned long long);
