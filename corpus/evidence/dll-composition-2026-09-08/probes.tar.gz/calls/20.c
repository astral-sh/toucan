 void g(int n){(void)sizeof(int[(__builtin_calloc(1,2), n)]);} __declspec(dllexport) void * __builtin_calloc(unsigned long long,unsigned long long);
