void * __builtin_malloc(unsigned long long); void g(int n){(void)sizeof((__builtin_malloc(1), 1));} __declspec(dllexport) void * __builtin_malloc(unsigned long long);
