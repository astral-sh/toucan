 void g(int n){(void)__builtin_realloc((void*)0,2);} __declspec(dllexport) void * __builtin_realloc(void*,unsigned long long);
