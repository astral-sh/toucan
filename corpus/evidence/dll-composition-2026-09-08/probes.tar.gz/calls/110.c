 void g(int n){(void)sizeof(int[(calloc(1,2), n)]);} __declspec(dllexport) void * calloc(unsigned long long,unsigned long long);
