 void g(int n){(void)_Generic((__builtin_malloc(1),1),int:0);} __declspec(dllexport) void * __builtin_malloc(unsigned long long);
