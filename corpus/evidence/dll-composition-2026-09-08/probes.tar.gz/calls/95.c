 void g(int n){if(0){(void)malloc(1);}} __declspec(dllexport) void * malloc(unsigned long long);
