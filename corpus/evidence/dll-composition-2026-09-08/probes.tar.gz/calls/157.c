void free(void*) __asm__("alias_8"); void g(int n){(void)sizeof((free((void*)0), 1));} __declspec(dllexport) void free(void*);
