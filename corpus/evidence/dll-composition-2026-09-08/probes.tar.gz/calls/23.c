 void g(int n){if(0){(void)__builtin_calloc(1,2);}} __declspec(dllexport) void * __builtin_calloc(unsigned long long,unsigned long long);
