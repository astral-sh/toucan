 void g(int n){(void)sizeof((__builtin_calloc(1,2), 1));} __declspec(dllexport) void * __builtin_calloc(unsigned long long,unsigned long long);
