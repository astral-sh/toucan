void * calloc(unsigned long long,unsigned long long); void g(int n){(void)sizeof(sizeof(int[(calloc(1,2),n)]));} __declspec(dllexport) void * calloc(unsigned long long,unsigned long long);
