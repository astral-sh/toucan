 void g(int n){(void)sizeof((malloc(1), 1));} __declspec(dllexport) void * malloc(unsigned long long);
