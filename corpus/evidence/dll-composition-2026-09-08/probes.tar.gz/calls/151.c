void free(void*); void g(int n){(void)sizeof((free((void*)0), 1));} __declspec(dllexport) void free(void*);
