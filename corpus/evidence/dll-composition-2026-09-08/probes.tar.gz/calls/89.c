void __builtin_prefetch(const void*,...) __asm__("alias_4"); void g(int n){if(0){(void)__builtin_prefetch((void*)0);}} __declspec(dllexport) void __builtin_prefetch(const void*,...);
