void free(void*) __asm__("alias_8"); void g(int n){(void)sizeof(sizeof(int[(free((void*)0),n)]));} __declspec(dllexport) void free(void*);
