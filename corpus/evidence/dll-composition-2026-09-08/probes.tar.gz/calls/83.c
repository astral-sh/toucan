void __builtin_prefetch(const void*,...); void g(int n){if(0){(void)__builtin_prefetch((void*)0);}} __declspec(dllexport) void __builtin_prefetch(const void*,...);
