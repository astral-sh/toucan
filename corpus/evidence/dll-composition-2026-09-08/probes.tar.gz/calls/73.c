 void g(int n){(void)sizeof((__builtin_prefetch((void*)0), 1));} __declspec(dllexport) void __builtin_prefetch(const void*,...);
