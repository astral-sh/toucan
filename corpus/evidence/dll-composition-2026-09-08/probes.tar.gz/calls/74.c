 void g(int n){(void)sizeof(int[(__builtin_prefetch((void*)0), n)]);} __declspec(dllexport) void __builtin_prefetch(const void*,...);
