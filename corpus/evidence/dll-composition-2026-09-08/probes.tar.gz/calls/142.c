void * realloc(void*,unsigned long long) __asm__("alias_7"); void g(int n){(void)_Generic((realloc((void*)0,2),1),int:0);} __declspec(dllexport) void * realloc(void*,unsigned long long);
