void free(void*) __asm__("alias_8"); void g(int n){if(0){(void)free((void*)0);}} __declspec(dllexport) void free(void*);
