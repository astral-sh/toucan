 void g(int n){(void)_Generic((__builtin_prefetch((void*)0),1),int:0);} __declspec(dllexport) void __builtin_prefetch(const void*,...);
