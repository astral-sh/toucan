void __builtin_free(void*); void g(int n){(void)sizeof((__builtin_free((void*)0), 1));} __declspec(dllexport) void __builtin_free(void*);
