void free(void*); void g(int n){(void)free((void*)0);} __declspec(dllexport) void free(void*);
