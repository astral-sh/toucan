void * __builtin_malloc(unsigned long long) __asm__("alias_0"); void g(int n){(void)sizeof(sizeof(int[(__builtin_malloc(1),n)]));} __declspec(dllexport) void * __builtin_malloc(unsigned long long);
