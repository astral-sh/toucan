void free(void*) __asm__("alias_8"); void g(int n){(void)_Generic((free((void*)0),1),int:0);} __declspec(dllexport) void free(void*);
