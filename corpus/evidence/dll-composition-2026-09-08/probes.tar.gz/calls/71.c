void __builtin_free(void*) __asm__("alias_3"); void g(int n){if(0){(void)__builtin_free((void*)0);}} __declspec(dllexport) void __builtin_free(void*);
