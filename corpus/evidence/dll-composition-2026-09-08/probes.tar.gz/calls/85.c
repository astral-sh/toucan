void __builtin_prefetch(const void*,...) __asm__("alias_4"); void g(int n){(void)sizeof((__builtin_prefetch((void*)0), 1));} __declspec(dllexport) void __builtin_prefetch(const void*,...);
