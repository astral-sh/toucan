void * malloc(unsigned long long); void g(int n){(void)malloc(1);} __declspec(dllexport) void * malloc(unsigned long long);
