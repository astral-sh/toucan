void __builtin_free(void*); void g(int n){(void)__builtin_free((void*)0);} __declspec(dllexport) void __builtin_free(void*);
