void * realloc(void*,unsigned long long); void g(int n){(void)sizeof(sizeof(int[(realloc((void*)0,2),n)]));} __declspec(dllexport) void * realloc(void*,unsigned long long);
