 void g(int n){(void)realloc((void*)0,2);} __declspec(dllexport) void * realloc(void*,unsigned long long);
