 void g(int n){(void)sizeof(sizeof(int[(__builtin_realloc((void*)0,2),n)]));} __declspec(dllexport) void * __builtin_realloc(void*,unsigned long long);
