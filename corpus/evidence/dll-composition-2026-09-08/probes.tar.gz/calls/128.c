 void g(int n){(void)sizeof(int[(realloc((void*)0,2), n)]);} __declspec(dllexport) void * realloc(void*,unsigned long long);
