void * __builtin_malloc(unsigned long long) __asm__("alias_0"); void g(int n){if(0){(void)__builtin_malloc(1);}} __declspec(dllexport) void * __builtin_malloc(unsigned long long);
