 void g(int n){(void)_Generic((calloc(1,2),1),int:0);} __declspec(dllexport) void * calloc(unsigned long long,unsigned long long);
