void * __builtin_realloc(void*,unsigned long long); void g(int n){(void)sizeof((__builtin_realloc((void*)0,2), 1));} __declspec(dllexport) void * __builtin_realloc(void*,unsigned long long);
