void __builtin_free(void*) __asm__("alias_3"); void g(int n){(void)_Generic((__builtin_free((void*)0),1),int:0);} __declspec(dllexport) void __builtin_free(void*);
