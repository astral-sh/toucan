void * realloc(void*,unsigned long long); void g(int n){(void)sizeof((realloc((void*)0,2), 1));} __declspec(dllexport) void * realloc(void*,unsigned long long);
