void * calloc(unsigned long long,unsigned long long); void g(int n){if(0){(void)calloc(1,2);}} __declspec(dllexport) void * calloc(unsigned long long,unsigned long long);
