 void g(int n){(void)_Generic((malloc(1),1),int:0);} __declspec(dllexport) void * malloc(unsigned long long);
