void * __builtin_malloc(unsigned long long); void g(int n){(void)__builtin_malloc(1);} __declspec(dllexport) void * __builtin_malloc(unsigned long long);
