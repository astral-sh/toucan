 void g(int n){(void)sizeof(int[(malloc(1), n)]);} __declspec(dllexport) void * malloc(unsigned long long);
