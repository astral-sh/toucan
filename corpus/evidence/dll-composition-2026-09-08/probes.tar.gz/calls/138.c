void * realloc(void*,unsigned long long) __asm__("alias_7"); void g(int n){(void)realloc((void*)0,2);} __declspec(dllexport) void * realloc(void*,unsigned long long);
