void * __builtin_realloc(void*,unsigned long long); void g(int n){(void)sizeof(int[(__builtin_realloc((void*)0,2), n)]);} __declspec(dllexport) void * __builtin_realloc(void*,unsigned long long);
