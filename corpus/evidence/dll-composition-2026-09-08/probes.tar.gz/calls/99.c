void * malloc(unsigned long long); void g(int n){(void)sizeof(sizeof(int[(malloc(1),n)]));} __declspec(dllexport) void * malloc(unsigned long long);
