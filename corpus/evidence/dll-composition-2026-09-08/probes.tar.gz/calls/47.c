void * __builtin_realloc(void*,unsigned long long); void g(int n){if(0){(void)__builtin_realloc((void*)0,2);}} __declspec(dllexport) void * __builtin_realloc(void*,unsigned long long);
