VALUE = "toucan-zstd-workspace-probe"
