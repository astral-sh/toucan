/home/dev-user/.cache/toucan/project-consumers/uv-target/debug/deps/uv_client-a8102ba6566218cd.d: crates/uv-client/src/lib.rs crates/uv-client/src/base_client.rs crates/uv-client/src/cached_client.rs crates/uv-client/src/error.rs crates/uv-client/src/flat_index.rs crates/uv-client/src/html.rs crates/uv-client/src/httpcache/mod.rs crates/uv-client/src/httpcache/control.rs crates/uv-client/src/linehaul.rs crates/uv-client/src/middleware.rs crates/uv-client/src/registry_client.rs crates/uv-client/src/remote_metadata.rs crates/uv-client/src/retry.rs crates/uv-client/src/rkyvutil.rs crates/uv-client/src/tls.rs

/home/dev-user/.cache/toucan/project-consumers/uv-target/debug/deps/libuv_client-a8102ba6566218cd.rlib: crates/uv-client/src/lib.rs crates/uv-client/src/base_client.rs crates/uv-client/src/cached_client.rs crates/uv-client/src/error.rs crates/uv-client/src/flat_index.rs crates/uv-client/src/html.rs crates/uv-client/src/httpcache/mod.rs crates/uv-client/src/httpcache/control.rs crates/uv-client/src/linehaul.rs crates/uv-client/src/middleware.rs crates/uv-client/src/registry_client.rs crates/uv-client/src/remote_metadata.rs crates/uv-client/src/retry.rs crates/uv-client/src/rkyvutil.rs crates/uv-client/src/tls.rs

/home/dev-user/.cache/toucan/project-consumers/uv-target/debug/deps/libuv_client-a8102ba6566218cd.rmeta: crates/uv-client/src/lib.rs crates/uv-client/src/base_client.rs crates/uv-client/src/cached_client.rs crates/uv-client/src/error.rs crates/uv-client/src/flat_index.rs crates/uv-client/src/html.rs crates/uv-client/src/httpcache/mod.rs crates/uv-client/src/httpcache/control.rs crates/uv-client/src/linehaul.rs crates/uv-client/src/middleware.rs crates/uv-client/src/registry_client.rs crates/uv-client/src/remote_metadata.rs crates/uv-client/src/retry.rs crates/uv-client/src/rkyvutil.rs crates/uv-client/src/tls.rs

crates/uv-client/src/lib.rs:
crates/uv-client/src/base_client.rs:
crates/uv-client/src/cached_client.rs:
crates/uv-client/src/error.rs:
crates/uv-client/src/flat_index.rs:
crates/uv-client/src/html.rs:
crates/uv-client/src/httpcache/mod.rs:
crates/uv-client/src/httpcache/control.rs:
crates/uv-client/src/linehaul.rs:
crates/uv-client/src/middleware.rs:
crates/uv-client/src/registry_client.rs:
crates/uv-client/src/remote_metadata.rs:
crates/uv-client/src/retry.rs:
crates/uv-client/src/rkyvutil.rs:
crates/uv-client/src/tls.rs:
