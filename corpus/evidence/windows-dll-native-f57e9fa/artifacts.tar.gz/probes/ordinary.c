int ordinary=5;
