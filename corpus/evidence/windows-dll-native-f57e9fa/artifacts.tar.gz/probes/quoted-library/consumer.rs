#![no_std]
include!("bindings.rs");
fn injected() {}
