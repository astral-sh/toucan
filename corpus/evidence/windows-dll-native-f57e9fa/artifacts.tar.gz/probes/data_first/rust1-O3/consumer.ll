; ModuleID = 'consumer.f7f57611ce5e34b2-cgu.0'
source_filename = "consumer.f7f57611ce5e34b2-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@a_value = external dllimport global i32
@b_value = external dllimport local_unnamed_addr global i32
@a_special = external dllimport local_unnamed_addr global i32
@ordinary = external local_unnamed_addr global i32

; Function Attrs: nounwind uwtable
define noundef range(i32 0, 16) i32 @entry() unnamed_addr #0 {
start:
  %_1 = tail call noundef i32 @c_probe() #1
  %0 = icmp eq i32 %_1, 0
  br i1 %0, label %bb3, label %bb33

bb3:                                              ; preds = %start
  %_2 = load i32, ptr @a_value, align 4, !noundef !3
  %1 = icmp eq i32 %_2, 11
  %_4 = load i32, ptr @b_value, align 4
  %2 = icmp eq i32 %_4, 7
  %or.cond = select i1 %1, i1 %2, i1 false
  %_6 = load i32, ptr @a_special, align 4
  %3 = icmp eq i32 %_6, 23
  %or.cond1 = select i1 %or.cond, i1 %3, i1 false
  %_8 = load i32, ptr @ordinary, align 4
  %4 = icmp eq i32 %_8, 5
  %or.cond2 = select i1 %or.cond1, i1 %4, i1 false
  br i1 %or.cond2, label %bb11, label %bb33

bb11:                                             ; preds = %bb3
  %_10 = tail call noundef i32 @a_function(i32 noundef 2) #1
  %5 = icmp eq i32 %_10, 13
  br i1 %5, label %bb15, label %bb33

bb15:                                             ; preds = %bb11
  %_11 = tail call noundef i32 @b_function(i32 noundef 4) #1
  %6 = icmp eq i32 %_11, 28
  br i1 %6, label %bb19, label %bb33

bb19:                                             ; preds = %bb15
  %_13 = tail call noundef ptr @a_address_data() #1
  %_12.not = icmp eq ptr %_13, @a_value
  br i1 %_12.not, label %bb22, label %bb33

bb22:                                             ; preds = %bb19
  %7 = tail call noundef ptr @a_address_function() #1
  %_17.not = icmp eq ptr %7, @a_function
  br i1 %_17.not, label %bb28, label %bb33

bb28:                                             ; preds = %bb22
  store i32 17, ptr @a_value, align 4
  %_21 = tail call noundef i32 @a_function(i32 noundef 2) #1
  %8 = icmp eq i32 %_21, 19
  br i1 %8, label %bb31, label %bb33

bb31:                                             ; preds = %bb28
  store i32 11, ptr @a_value, align 4
  br label %bb33

bb33:                                             ; preds = %bb3, %bb11, %bb15, %bb28, %bb22, %bb19, %start, %bb31
  %_0.sroa.0.1 = phi i32 [ 10, %start ], [ 13, %bb19 ], [ 0, %bb31 ], [ 11, %bb3 ], [ 15, %bb28 ], [ 12, %bb11 ], [ 14, %bb22 ], [ 12, %bb15 ]
  ret i32 %_0.sroa.0.1
}

; Function Attrs: nounwind uwtable
declare noundef i32 @c_probe() unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport noundef i32 @a_function(i32 noundef) unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport noundef i32 @b_function(i32 noundef) unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport noundef ptr @a_address_data() unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport noundef ptr @a_address_function() unnamed_addr #0

attributes #0 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
!3 = !{}
