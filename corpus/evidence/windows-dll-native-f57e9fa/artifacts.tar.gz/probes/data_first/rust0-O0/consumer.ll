; ModuleID = 'consumer.26609c7a-cgu.0'
source_filename = "consumer.26609c7a-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@a_value = external dllimport global i32
@b_value = external dllimport global i32
@a_special = external dllimport global i32
@ordinary = external global i32

; Function Attrs: uwtable
define i32 @entry() unnamed_addr #0 {
start:
  %_24 = alloca i64*, align 8
  %_16 = alloca i8, align 1
  %_4 = alloca i8, align 1
  %_3 = alloca i8, align 1
  %_2 = alloca i8, align 1
  %0 = alloca i32, align 4
  %_1 = call i32 @c_probe()
  br label %bb1

bb1:                                              ; preds = %start
  %1 = icmp eq i32 %_1, 0
  br i1 %1, label %bb3, label %bb2

bb3:                                              ; preds = %bb1
  %_5 = load i32, i32* @a_value, align 4
  %2 = icmp eq i32 %_5, 11
  br i1 %2, label %bb11, label %bb10

bb2:                                              ; preds = %bb1
  store i32 10, i32* %0, align 4
  br label %bb34

bb34:                                             ; preds = %bb26, %bb33, %bb32, %bb29, %bb23, %bb20, %bb13, %bb2
  %3 = load i32, i32* %0, align 4
  ret i32 %3

bb11:                                             ; preds = %bb3
  %_8 = load i32, i32* @b_value, align 4
  %_7 = icmp ne i32 %_8, 7
  %4 = zext i1 %_7 to i8
  store i8 %4, i8* %_4, align 1
  br label %bb12

bb10:                                             ; preds = %bb3
  store i8 1, i8* %_4, align 1
  br label %bb12

bb12:                                             ; preds = %bb11, %bb10
  %5 = load i8, i8* %_4, align 1, !range !1, !noundef !2
  %6 = trunc i8 %5 to i1
  br i1 %6, label %bb7, label %bb8

bb8:                                              ; preds = %bb12
  %_11 = load i32, i32* @a_special, align 4
  %_10 = icmp ne i32 %_11, 23
  %7 = zext i1 %_10 to i8
  store i8 %7, i8* %_3, align 1
  br label %bb9

bb7:                                              ; preds = %bb12
  store i8 1, i8* %_3, align 1
  br label %bb9

bb9:                                              ; preds = %bb8, %bb7
  %8 = load i8, i8* %_3, align 1, !range !1, !noundef !2
  %9 = trunc i8 %8 to i1
  br i1 %9, label %bb4, label %bb5

bb5:                                              ; preds = %bb9
  %_14 = load i32, i32* @ordinary, align 4
  %_13 = icmp ne i32 %_14, 5
  %10 = zext i1 %_13 to i8
  store i8 %10, i8* %_2, align 1
  br label %bb6

bb4:                                              ; preds = %bb9
  store i8 1, i8* %_2, align 1
  br label %bb6

bb6:                                              ; preds = %bb5, %bb4
  %11 = load i8, i8* %_2, align 1, !range !1, !noundef !2
  %12 = trunc i8 %11 to i1
  br i1 %12, label %bb13, label %bb14

bb14:                                             ; preds = %bb6
  %_17 = call i32 @a_function(i32 2)
  br label %bb18

bb13:                                             ; preds = %bb6
  store i32 11, i32* %0, align 4
  br label %bb34

bb18:                                             ; preds = %bb14
  %13 = icmp eq i32 %_17, 13
  br i1 %13, label %bb16, label %bb15

bb16:                                             ; preds = %bb18
  %_19 = call i32 @b_function(i32 4)
  br label %bb19

bb15:                                             ; preds = %bb18
  store i8 1, i8* %_16, align 1
  br label %bb17

bb17:                                             ; preds = %bb19, %bb15
  %14 = load i8, i8* %_16, align 1, !range !1, !noundef !2
  %15 = trunc i8 %14 to i1
  br i1 %15, label %bb20, label %bb21

bb19:                                             ; preds = %bb16
  %_18 = icmp ne i32 %_19, 28
  %16 = zext i1 %_18 to i8
  store i8 %16, i8* %_16, align 1
  br label %bb17

bb21:                                             ; preds = %bb17
  %_21 = call i32* @a_address_data()
  br label %bb22

bb20:                                             ; preds = %bb17
  store i32 12, i32* %0, align 4
  br label %bb34

bb22:                                             ; preds = %bb21
  %_20 = icmp ne i32* %_21, @a_value
  br i1 %_20, label %bb23, label %bb24

bb24:                                             ; preds = %bb22
  %17 = call i64* @a_address_function()
  store i64* %17, i64** %_24, align 8
  br label %bb25

bb23:                                             ; preds = %bb22
  store i32 13, i32* %0, align 4
  br label %bb34

bb25:                                             ; preds = %bb24
  %18 = bitcast i64** %_24 to {}**
  %19 = load {}*, {}** %18, align 8
  %20 = icmp eq {}* %19, null
  %_25 = select i1 %20, i64 0, i64 1
  switch i64 %_25, label %bb27 [
    i64 0, label %bb26
    i64 1, label %bb28
  ]

bb27:                                             ; preds = %bb25
  unreachable

bb26:                                             ; preds = %bb25
  store i32 14, i32* %0, align 4
  br label %bb34

bb28:                                             ; preds = %bb25
  %21 = bitcast i64** %_24 to i32 (i32)**
  %callback = load i32 (i32)*, i32 (i32)** %21, align 8, !nonnull !2, !noundef !2
  %_28 = ptrtoint i32 (i32)* %callback to i64
  %_27 = icmp ne i64 %_28, ptrtoint (i32 (i32)* @a_function to i64)
  br i1 %_27, label %bb29, label %bb30

bb30:                                             ; preds = %bb28
  store i32 17, i32* @a_value, align 4
  %_33 = call i32 @a_function(i32 2)
  br label %bb31

bb29:                                             ; preds = %bb28
  store i32 14, i32* %0, align 4
  br label %bb34

bb31:                                             ; preds = %bb30
  %22 = icmp eq i32 %_33, 19
  br i1 %22, label %bb33, label %bb32

bb33:                                             ; preds = %bb31
  store i32 11, i32* @a_value, align 4
  store i32 0, i32* %0, align 4
  br label %bb34

bb32:                                             ; preds = %bb31
  store i32 15, i32* %0, align 4
  br label %bb34
}

; Function Attrs: uwtable
declare i32 @c_probe() unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i32 @a_function(i32) unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i32 @b_function(i32) unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i32* @a_address_data() unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i64* @a_address_function() unnamed_addr #0

attributes #0 = { uwtable "target-cpu"="x86-64" }

!llvm.module.flags = !{!0}

!0 = !{i32 7, !"PIC Level", i32 2}
!1 = !{i8 0, i8 2}
!2 = !{}
