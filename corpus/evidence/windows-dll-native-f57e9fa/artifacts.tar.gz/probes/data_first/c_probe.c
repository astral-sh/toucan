#include "api.h"
int c_probe(void) {
    if(a_value!=11 || b_value!=7 || a_special!=23 || ordinary!=5) return 1;
    if(a_function(2)!=13 || b_function(4)!=28) return 2;
    if(a_address_data()!=&a_value || a_address_function()!=&a_function) return 3;
    a_value=17;
    if(a_function(2)!=19) return 4;
    a_value=11;
    return 0;
}
