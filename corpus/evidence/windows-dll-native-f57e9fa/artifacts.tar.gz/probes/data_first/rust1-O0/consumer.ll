; ModuleID = 'consumer.f7f57611ce5e34b2-cgu.0'
source_filename = "consumer.f7f57611ce5e34b2-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@a_value = external dllimport global i32
@b_value = external dllimport global i32
@a_special = external dllimport global i32
@ordinary = external global i32

; Function Attrs: nounwind uwtable
define i32 @entry() unnamed_addr #0 {
start:
  %_22 = alloca [8 x i8], align 8
  %_0 = alloca [4 x i8], align 4
  %_2 = call i32 @c_probe() #1
  %_1 = icmp ne i32 %_2, 0
  br i1 %_1, label %bb2, label %bb3

bb3:                                              ; preds = %start
  %_4 = load i32, ptr @a_value, align 4
  %_3 = icmp ne i32 %_4, 11
  br i1 %_3, label %bb8, label %bb4

bb2:                                              ; preds = %start
  store i32 10, ptr %_0, align 4
  br label %bb26

bb4:                                              ; preds = %bb3
  %_7 = load i32, ptr @b_value, align 4
  %_6 = icmp ne i32 %_7, 7
  br i1 %_6, label %bb8, label %bb5

bb8:                                              ; preds = %bb6, %bb5, %bb4, %bb3
  store i32 11, ptr %_0, align 4
  br label %bb26

bb5:                                              ; preds = %bb4
  %_10 = load i32, ptr @a_special, align 4
  %_9 = icmp ne i32 %_10, 23
  br i1 %_9, label %bb8, label %bb6

bb6:                                              ; preds = %bb5
  %_13 = load i32, ptr @ordinary, align 4
  %_12 = icmp ne i32 %_13, 5
  br i1 %_12, label %bb8, label %bb7

bb7:                                              ; preds = %bb6
  %_16 = call i32 @a_function(i32 2) #1
  %_15 = icmp ne i32 %_16, 13
  br i1 %_15, label %bb12, label %bb10

bb10:                                             ; preds = %bb7
  %_18 = call i32 @b_function(i32 4) #1
  %_17 = icmp ne i32 %_18, 28
  br i1 %_17, label %bb12, label %bb13

bb12:                                             ; preds = %bb10, %bb7
  store i32 12, ptr %_0, align 4
  br label %bb26

bb13:                                             ; preds = %bb10
  %_20 = call ptr @a_address_data() #1
  %_19 = icmp ne ptr %_20, @a_value
  br i1 %_19, label %bb15, label %bb16

bb16:                                             ; preds = %bb13
  %0 = call ptr @a_address_function() #1
  store ptr %0, ptr %_22, align 8
  %1 = load ptr, ptr %_22, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_23 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_23 to i1
  br i1 %4, label %bb20, label %bb19

bb15:                                             ; preds = %bb13
  store i32 13, ptr %_0, align 4
  br label %bb26

bb20:                                             ; preds = %bb16
  %callback = load ptr, ptr %_22, align 8
  %_26 = ptrtoint ptr %callback to i64
  %_25 = icmp ne i64 %_26, ptrtoint (ptr @a_function to i64)
  br i1 %_25, label %bb21, label %bb22

bb19:                                             ; preds = %bb16
  store i32 14, ptr %_0, align 4
  br label %bb26

bb26:                                             ; preds = %bb2, %bb8, %bb12, %bb15, %bb21, %bb24, %bb25, %bb19
  %5 = load i32, ptr %_0, align 4
  ret i32 %5

bb22:                                             ; preds = %bb20
  store i32 17, ptr @a_value, align 4
  %_31 = call i32 @a_function(i32 2) #1
  %_30 = icmp ne i32 %_31, 19
  br i1 %_30, label %bb24, label %bb25

bb21:                                             ; preds = %bb20
  store i32 14, ptr %_0, align 4
  br label %bb26

bb25:                                             ; preds = %bb22
  store i32 11, ptr @a_value, align 4
  store i32 0, ptr %_0, align 4
  br label %bb26

bb24:                                             ; preds = %bb22
  store i32 15, ptr %_0, align 4
  br label %bb26

bb18:                                             ; No predecessors!
  unreachable
}

; Function Attrs: nounwind uwtable
declare i32 @c_probe() unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport i32 @a_function(i32) unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport i32 @b_function(i32) unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport ptr @a_address_data() unnamed_addr #0

; Function Attrs: nounwind uwtable
declare dllimport ptr @a_address_function() unnamed_addr #0

attributes #0 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
