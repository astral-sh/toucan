; ModuleID = 'consumer.26609c7a-cgu.0'
source_filename = "consumer.26609c7a-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@a_value = external dllimport global i32
@b_value = external dllimport local_unnamed_addr global i32
@a_special = external dllimport local_unnamed_addr global i32
@ordinary = external local_unnamed_addr global i32

; Function Attrs: uwtable
define i32 @entry() unnamed_addr #0 {
start:
  %_1 = tail call i32 @c_probe()
  %0 = icmp eq i32 %_1, 0
  br i1 %0, label %bb3, label %bb35

bb3:                                              ; preds = %start
  %_5 = load i32, i32* @a_value, align 4
  %1 = icmp ne i32 %_5, 11
  %_8 = load i32, i32* @b_value, align 4
  %_7 = icmp ne i32 %_8, 7
  %_4.0 = select i1 %1, i1 true, i1 %_7
  %_11 = load i32, i32* @a_special, align 4
  %_10 = icmp ne i32 %_11, 23
  %or.cond = select i1 %_4.0, i1 true, i1 %_10
  %_14 = load i32, i32* @ordinary, align 4
  %_13 = icmp ne i32 %_14, 5
  %or.cond4 = select i1 %or.cond, i1 true, i1 %_13
  br i1 %or.cond4, label %bb35, label %bb14

bb35:                                             ; preds = %bb30, %bb24, %bb21, %bb16, %bb14, %bb3, %start, %bb33
  %.0 = phi i32 [ 0, %bb33 ], [ 10, %start ], [ 11, %bb3 ], [ 12, %bb14 ], [ 12, %bb16 ], [ 13, %bb21 ], [ 14, %bb24 ], [ 15, %bb30 ]
  ret i32 %.0

bb14:                                             ; preds = %bb3
  %_17 = tail call i32 @a_function(i32 2)
  %2 = icmp eq i32 %_17, 13
  br i1 %2, label %bb16, label %bb35

bb16:                                             ; preds = %bb14
  %_19 = tail call i32 @b_function(i32 4)
  %_18.not = icmp eq i32 %_19, 28
  br i1 %_18.not, label %bb21, label %bb35

bb21:                                             ; preds = %bb16
  %_21 = tail call i32* @a_address_data()
  %_20.not = icmp eq i32* %_21, @a_value
  br i1 %_20.not, label %bb24, label %bb35

bb24:                                             ; preds = %bb21
  %3 = tail call i64* @a_address_function()
  %_27.not = icmp eq i64* %3, bitcast (i32 (i32)* @a_function to i64*)
  br i1 %_27.not, label %bb30, label %bb35

bb30:                                             ; preds = %bb24
  store i32 17, i32* @a_value, align 4
  %_33 = tail call i32 @a_function(i32 2)
  %4 = icmp eq i32 %_33, 19
  br i1 %4, label %bb33, label %bb35

bb33:                                             ; preds = %bb30
  store i32 11, i32* @a_value, align 4
  br label %bb35
}

; Function Attrs: uwtable
declare i32 @c_probe() unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i32 @a_function(i32) unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i32 @b_function(i32) unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i32* @a_address_data() unnamed_addr #0

; Function Attrs: uwtable
declare dllimport i64* @a_address_function() unnamed_addr #0

attributes #0 = { uwtable "target-cpu"="x86-64" }

!llvm.module.flags = !{!0}

!0 = !{i32 7, !"PIC Level", i32 2}
