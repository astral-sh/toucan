typedef int (*Callback)(int);
__declspec(dllexport) int a_value=11;
__declspec(dllexport) int a_function(int x){return a_value+x;}
__declspec(dllexport) int *a_address_data(void){return &a_value;}
__declspec(dllexport) Callback a_address_function(void){return &a_function;}
