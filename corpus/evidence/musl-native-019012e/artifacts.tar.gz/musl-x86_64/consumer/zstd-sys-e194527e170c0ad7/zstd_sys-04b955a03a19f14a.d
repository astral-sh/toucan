/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/zstd_sys-04b955a03a19f14a.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e194527e170c0ad7/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-04b955a03a19f14a.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e194527e170c0ad7/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-04b955a03a19f14a.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e194527e170c0ad7/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e194527e170c0ad7/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e194527e170c0ad7/out
