/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/zstd_sys-374eff848934ebbd.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-1ce1f40afaf099c0/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-374eff848934ebbd.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-1ce1f40afaf099c0/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-374eff848934ebbd.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-1ce1f40afaf099c0/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-1ce1f40afaf099c0/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-1ce1f40afaf099c0/out
