/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/zstd_sys-9155d6da14b46a90.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e1340cebda6f15a9/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-9155d6da14b46a90.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e1340cebda6f15a9/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-9155d6da14b46a90.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e1340cebda6f15a9/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e1340cebda6f15a9/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-e1340cebda6f15a9/out
