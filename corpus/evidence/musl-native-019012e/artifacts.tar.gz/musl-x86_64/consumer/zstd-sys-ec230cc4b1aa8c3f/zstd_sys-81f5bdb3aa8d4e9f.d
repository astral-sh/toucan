/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/zstd_sys-81f5bdb3aa8d4e9f.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-ec230cc4b1aa8c3f/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-81f5bdb3aa8d4e9f.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-ec230cc4b1aa8c3f/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/deps/libzstd_sys-81f5bdb3aa8d4e9f.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-ec230cc4b1aa8c3f/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-ec230cc4b1aa8c3f/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/x86_64-unknown-linux-musl/release/build/zstd-sys-ec230cc4b1aa8c3f/out
