/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/zstd_sys-1e7a70cdcdef1e56.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-7781a796bc6ecb23/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-1e7a70cdcdef1e56.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-7781a796bc6ecb23/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-1e7a70cdcdef1e56.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-7781a796bc6ecb23/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-7781a796bc6ecb23/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-7781a796bc6ecb23/out
