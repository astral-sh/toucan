/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/zstd_sys-685c8c83816e45ea.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-2d1b3191a463ff1a/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-685c8c83816e45ea.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-2d1b3191a463ff1a/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-685c8c83816e45ea.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-2d1b3191a463ff1a/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-2d1b3191a463ff1a/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-2d1b3191a463ff1a/out
