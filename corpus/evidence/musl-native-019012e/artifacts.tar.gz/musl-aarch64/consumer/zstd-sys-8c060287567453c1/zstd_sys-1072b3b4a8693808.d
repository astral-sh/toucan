/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/zstd_sys-1072b3b4a8693808.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-8c060287567453c1/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-1072b3b4a8693808.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-8c060287567453c1/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-1072b3b4a8693808.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-8c060287567453c1/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-8c060287567453c1/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-8c060287567453c1/out
