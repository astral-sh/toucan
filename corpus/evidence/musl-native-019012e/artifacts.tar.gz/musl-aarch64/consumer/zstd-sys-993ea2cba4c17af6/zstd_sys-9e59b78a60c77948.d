/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/zstd_sys-9e59b78a60c77948.d: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-993ea2cba4c17af6/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-9e59b78a60c77948.rlib: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-993ea2cba4c17af6/out/bindings.rs

/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/deps/libzstd_sys-9e59b78a60c77948.rmeta: /home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs /home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-993ea2cba4c17af6/out/bindings.rs

/home/runner/work/_temp/musl/consumer/zstd-sys/src/lib.rs:
/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-993ea2cba4c17af6/out/bindings.rs:

# env-dep:OUT_DIR=/home/runner/work/toucan/toucan/target/musl-consumer/aarch64-unknown-linux-musl/release/build/zstd-sys-993ea2cba4c17af6/out
