from pathlib import Path
import subprocess,json,hashlib
out=Path('/home/dev-user/.cache/toucan/remaining-query-probes');out.mkdir(exist_ok=True)
queries=['__has_feature','__has_extension','__has_c_attribute','__has_declspec_attribute','__building_module']; rows=[]
for q in queries:
 for kind,arg in [('valid','c_atomic' if q in queries[:2] else 'aligned'),('empty',''),('number','1'),('string','"foo"'),('nested','(foo)'),('comma','foo,bar'),('scoped','gnu::aligned'),('extra','foo bar'),('counter','__COUNTER__')]:
  for wrapper in ['direct','if','dead']:
   src=f'a {q}({arg})\nb __COUNTER__\n' if wrapper=='direct' else (f'#if 0 && {q}({arg})\nx\n#endif\n' if wrapper=='if' else f'#if 0\na {q}({arg})\n#endif\nx\n')
   for compiler in ['gcc','clang']:
    cmd=[compiler,'-std=gnu11','-E','-P','-x','c','-'];p=subprocess.run(cmd,input=src,capture_output=True,text=True,timeout=15)
    rows.append(dict(query=q,case=kind,wrapper=wrapper,command=cmd,source=src,status=p.returncode,stdout=p.stdout,stderr=p.stderr))
 for mode in ['c11','gnu11','c90','gnu90']:
  src=f'#define ARG aligned\n#define F c_atomic\na {q}(ARG)\nb {q}(F)\n#define W(x) {q}(x)\nc W(F)\nd {q}(__aligned__)\ne {q}(__c_atomic__)\n'
  cmd=['clang','-std='+mode,'-E','-P','-x','c','-'];p=subprocess.run(cmd,input=src,capture_output=True,text=True,timeout=15);rows.append(dict(query=q,case='expansion',mode=mode,command=cmd,source=src,status=p.returncode,stdout=p.stdout,stderr=p.stderr))
(out/'evidence.json').write_text(json.dumps(dict(versions={c:subprocess.check_output([c,'--version'],text=True) for c in ['gcc','clang']},rows=rows),indent=2)+'\n')
for q in queries:
 print(q,[(r['case'],r['status'],r['stdout'].strip()) for r in rows if r['query']==q and r.get('wrapper')=='direct' and r['command'][0]=='clang'])
 print('expansion',[(r['mode'],r['stdout'].strip()) for r in rows if r['query']==q and r['case']=='expansion'])
