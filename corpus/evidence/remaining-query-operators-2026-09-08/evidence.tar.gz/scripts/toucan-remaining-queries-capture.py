from pathlib import Path
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
repo=Path('/home/dev-user/.codex/worktrees/toucan-remaining-queries')
cache=Path('/home/dev-user/.cache/toucan/remaining-query-probes')
out=repo/'corpus/evidence/remaining-query-operators-2026-09-08'
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
logs={}
for name in ['native-final','gcc14-final','tests-final','lib-native','comments-native','clippy-final','fmt-final','diff-check']:
 path=Path('/tmp/toucan-remaining-queries-'+name+'.log')
 logs[name]=path.read_bytes()
for name in ['native-final','gcc14-final']:
 assert b'5880 native query cases' in logs[name]
 assert b'test result: ok. 8 passed; 0 failed; 0 ignored' in logs[name]
assert b'48 passed; 0 failed' in logs['lib-native']
assert b'6 passed; 0 failed' in logs['comments-native']
assert b'Finished' in logs['clippy-final'] and b'error:' not in logs['clippy-final']
assert not logs['fmt-final'] and not logs['diff-check']
out.mkdir(parents=True,exist_ok=True)
files=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{name:sha((repo/name).read_bytes()) for name in sorted(files) if not name.startswith('corpus/evidence/')}}
write(out/'source.json',source)
archive={'logs/'+name+'.log':data for name,data in logs.items()}
for name in ['evidence','namespaces','namespace-spacing','namespace-expansion','scope-token','scope-substitution','gcc-version-scopes','pragma-arguments']:
 archive['probes/'+name+'.json']=(cache/(name+'.json')).read_bytes()
for name in source['files']: archive['source/'+name]=(repo/name).read_bytes()
for name in ['remaining-query-probes','remaining-queries-capture']:
 path=Path('/tmp/toucan-'+name+'.py');archive['scripts/'+path.name]=path.read_bytes()
versions={compiler:subprocess.check_output([compiler,'--version'],text=True) for compiler in ['gcc','clang','/home/dev-user/.cache/toucan/gcc14-parameter-probe/gcc14']}
archive['versions.json']=(json.dumps(versions,indent=2)+'\n').encode()
primary={name:sha((cache/name).read_bytes()) for name in ['PPMacroExpansion.cpp','gcc13-lex.cc','gcc13-c-lex.cc']}
archive['primary-source-hashes.json']=(json.dumps(primary,indent=2)+'\n').encode()
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
 for name,data in sorted(archive.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(),mtime=0))
write(out/'files.json',{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(archive.items())})
write(out/'summary.json',{
 'base':source['base'],'source_manifest_sha256':sha((out/'source.json').read_bytes()),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes()),
 'native_query_matrix':{'cases':245,'routes':24,'comparisons_per_run':5880,'command_line_override_cases_per_run':20,'modes':['c90','gnu90','c11','gnu11'],'clang_targets':['x86_64-unknown-linux-gnu','aarch64-unknown-linux-gnu','x86_64-apple-darwin','aarch64-apple-darwin','x86_64-pc-windows-msvc'],'canonical':['GCC 13.3.0','Clang 18.1.3'],'additional':['GCC 14.2.0 with explicit -U__has_feature -U__has_extension','Clang 18.1.3'],'mismatches':0,'canonical_note':'The canonical run preceded test-only GCC14 oracle calibration; all four implementation source files are unchanged. The additional run exercises the final test harness, including raw availability capture and explicit GNU13 query-environment overrides.'},
 'preprocessor_tests':{'default_passed':57,'default_ignored':5,'native_library_passed':48,'native_comments_passed':6,'native_query_test_group_passed':8},'clippy':'all targets and all features, no warnings','format':'passed',
 'scope_contract':{'standalone_default':False,'frontend_configuration':'Clang or GNU language mode','strict_adjacent_colons':'preserve lexical adjacency for namespace recognition','strict_pasted_colons':'reject as invalid preprocessing token','separated_or_substitution_joined_colons':'reject as namespace separator','independent_of_identity_macro_overrides':True},
 'remaining':['Expanded _Pragma directives inside query arguments are rejected; exact native probes are retained for the next layer.','Facade capability catalogs, fuzz mocks, and frontend scope-punctuator routing are owned by the integrating parent.'],
 'not_claimed':['Full GNU14 operator semantics','Native Apple or Windows execution','Performance measurements','Sanitizer campaign','Complete C preprocessor conformance']})
frozen=cache/'frozen-binaries';frozen.mkdir(exist_ok=True)
path=Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/deps/feature_queries-f94ae56347273249')
shutil.copy2(path,frozen/path.name)
write(frozen/'manifest.json',{path.name:{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}})
print(json.dumps({'source_manifest':sha((out/'source.json').read_bytes()),'archive':sha((out/'evidence.tar.gz').read_bytes()),'files':len(archive),'archive_bytes':(out/'evidence.tar.gz').stat().st_size,'binary_sha256':sha(path.read_bytes())},indent=2))
