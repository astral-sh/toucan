from pathlib import Path
import subprocess,json,re,hashlib
root=Path(__file__).resolve().parent
cases={
 'object':'#define A 1\n#define A 2\nA\n',
 'identical':'#define A 1\n#define A 1\nA\n',
 'comments':'#define A 1 + 2\n#define A 1/**/+/**/2\nA\n',
 'whitespace':'#define A 1 + 2\n#define A 1+2\nA\n',
 'parameter_names':'#define A(x) ((x)+1)\n#define A(y) ((y)+1)\nA(3)\n',
 'object_to_function':'#define A 1\n#define A(x) ((x)+1)\nA(3)\n',
 'function_to_object':'#define A(x) ((x)+1)\n#define A 7\nA\n',
 'undef':'#define A 1\n#undef A\n#define A 2\nA\n',
 'inactive':'#define A 1\n#if 0\n#define A 2\n#endif\nA\n',
 'multiple':'#define A 1\n#define A 2\n#define A(x) (x)\n#define A 3\nA\n',
 'predefined':'#define A 3\nA\n',
 'predefined_pair':'#define A 3\nA\n',
}
requests=[]
for name,source in cases.items():
 path=root/f'{name}.h';path.write_text(source)
 defines=[['A','1']] if name=='predefined' else [['A','1'],['A(x)','(x)']] if name=='predefined_pair' else []
 requests.append(dict(name=name,source=source,path=str(path),defines=defines))
request=root/'requests.json';request.write_text(json.dumps(requests,indent=2)+'\n')
driver=root/'driver-target/debug/preprocess';cmd=[str(driver),str(request),str(root/'candidate.json')];subprocess.run(cmd,check=True)
actual=json.loads((root/'candidate.json').read_text()); rows=[]
for request in requests:
 candidate=next(row['result'] for row in actual if row['name']==request['name'] and row['policy']=='RecordAndReplace');assert 'error' not in candidate,candidate
 for compiler in ['gcc','clang']:
  command=[compiler,'-std=gnu11','-E','-P','-x','c',*[f'-D{name}={value}' for name,value in request['defines']],request['path']]
  p=subprocess.run(command,text=True,capture_output=True);assert p.returncode==0,p.stderr
  assert ''.join(p.stdout.split())==''.join(candidate['source'].split())
  warnings=len(re.findall(r'warning:.*redefined',p.stderr));assert warnings==len(candidate['redefinitions']),(request['name'],compiler,p.stderr,candidate)
  history_command=command[:];history_command.insert(3,'-dD');history=subprocess.run(history_command,text=True,capture_output=True);assert history.returncode==0
  definitions=re.findall(r'^#define (A(?:\([^\n]*?\))?)\s*(.*)$',history.stdout,re.M)
  definitions=definitions[len(request['defines']):]
  observed=[re.sub(r'\s','',name+value) for name,value in definitions]
  expected=[re.sub(r'\s','',entry['name']+('('+','.join(entry['parameters'])+')' if entry['parameters'] is not None else '')+entry['replacement']) for entry in candidate['history']]
  assert observed==expected,(request['name'],compiler,observed,expected)
  rows.append(dict(name=request['name'],compiler=compiler,command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,history_command=history_command,history_stdout=history.stdout,history_stderr=history.stderr,expanded_equal=True,history_equal=True,warning_count=warnings));print(request['name'],compiler,'pass',flush=True)
(root/'native.json').write_text(json.dumps(dict(driver_command=cmd,driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),rows=rows),indent=2)+'\n')
