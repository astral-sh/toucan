from pathlib import Path
import os,subprocess,json,hashlib
root=Path(__file__).resolve().parent;source=Path('/home/dev-user/.cache/toucan/macro-redefinitions-source');env=dict(os.environ,CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/home/dev-user/.cache/toucan/macro-redefinitions-target');rows=[]
for name,command in [
 ('preprocessor',['cargo','test','-p','toucan_preprocessor']),
 ('native',['cargo','test','-p','toucan_preprocessor','--test','macro_redefinitions','--','--ignored']),
 ('workspace-clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
 ('fuzz-clippy',['cargo','clippy','--manifest-path','fuzz/Cargo.toml','--bin','preprocess','--','-D','warnings']),
 ('selector-tests',['python3','-m','unittest','discover','-s','scripts/tests','-p','test_fuzz_campaign.py']),
 ('format',['cargo','fmt','--all','--','--check']),
 ('fuzz-format',['cargo','fmt','--manifest-path','fuzz/Cargo.toml','--all','--','--check']),
]:
 p=subprocess.run(command,cwd=source,env=env,text=True,capture_output=True);rows.append(dict(name=name,command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(name,p.returncode,flush=True);assert p.returncode==0,p.stdout+p.stderr
versions={}
for cmd in [['rustc','--version','--verbose'],['gcc','--version'],['clang','--version']]:
 p=subprocess.run(cmd,text=True,capture_output=True);versions[' '.join(cmd)]={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(root/'validation.json').write_text(json.dumps({'rows':rows,'versions':versions},indent=2)+'\n')
