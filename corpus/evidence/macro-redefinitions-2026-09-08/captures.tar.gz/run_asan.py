from pathlib import Path
import hashlib,importlib.util,json,os,re,shutil,subprocess,time,tarfile
source=Path('/home/dev-user/.cache/toucan/macro-redefinitions-source');root=Path(__file__).resolve().parent/'asan';root.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('campaign',source/'scripts/run_fuzz_campaign.py');campaign=importlib.util.module_from_spec(spec);spec.loader.exec_module(campaign)
snapshot=lambda:{str(path.relative_to(source)):hashlib.sha256(path.read_bytes()).hexdigest() for pattern in ['Cargo.toml','Cargo.lock','crates/**/*.rs','crates/**/Cargo.toml','fuzz/Cargo.toml','fuzz/Cargo.lock','fuzz/fuzz_targets/*.rs','fuzz/seeds/preprocess/*.h','scripts/run_fuzz_campaign.py'] for path in source.glob(pattern)}
before=snapshot();(root/'source.json').write_text(json.dumps(before,indent=2)+'\n')
corpus=root/'corpus';corpus.mkdir();coverage=[]
for path in sorted((source/'fuzz/seeds/preprocess').glob('*.h')):
 seeds=list(campaign.seed_preprocessor_policies(path.read_bytes()));settings=set()
 for data in seeds:
  value=sum(data);settings.add(((value>>9)%5,bool(value&256),value&1,bool(value&2),bool(value&4),bool(value&8)));(corpus/hashlib.sha256(data).hexdigest()).write_bytes(data)
 assert len(settings)==160
 coverage.append({'seed':path.name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'settings':sorted(settings)})
(corpus/'invalid-utf8').write_bytes(b'int valid;\xff');(root/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');initial_manifest=campaign.archive_initial_corpus(corpus,root)
artifacts=root/'artifacts';artifacts.mkdir();binary=Path('/home/dev-user/.cache/toucan/macro-redefinitions-asan-target/x86_64-unknown-linux-gnu/release/preprocess');assert '__asan_init' in subprocess.check_output(['nm',str(binary)],text=True)
shutil.copy2(binary,root/'preprocess');shutil.copy2(source/'fuzz/c.dict',root/'c.dict')
command=[str(root/'preprocess'),str(corpus),'-dict='+str(root/'c.dict'),'-max_total_time=60','-max_len=16384','-len_control=0','-timeout=5','-rss_limit_mb=1024','-seed=20260908','-artifact_prefix='+str(artifacts)+'/', '-print_final_stats=1'];started=time.monotonic()
with (root/'run.log').open('w') as stream:p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0'))
text=(root/'run.log').read_text();report={'command':command,'environment':{'ASAN_OPTIONS':'detect_leaks=0'},'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'preprocessor_selector_version':5,'original_seeds':len(coverage),'settings_per_seed':160,'initial_inputs':len(initial_manifest),'final_inputs':len(campaign.corpus_manifest(corpus)), 'returncode':p.returncode,'wall_seconds':time.monotonic()-started,'source_unchanged':before==snapshot(),'artifacts':campaign.corpus_manifest(artifacts),'statistics':{name:int(value) for name,value in re.findall(r'stat::(\w+):\s+(\d+)',text)}}
(root/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True);assert p.returncode==0 and not report['artifacts'] and report['source_unchanged']
