	.arch armv8-a
	.file	"records.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC0:
	.string	"size.git_apply_options=%zu\n"
	.align	3
.LC1:
	.string	"align.git_apply_options=%zu\n"
	.align	3
.LC2:
	.string	"offset.git_apply_options.version=%zu\n"
	.align	3
.LC3:
	.string	"offset.git_apply_options.delta_cb=%zu\n"
	.align	3
.LC4:
	.string	"offset.git_apply_options.hunk_cb=%zu\n"
	.align	3
.LC5:
	.string	"offset.git_apply_options.payload=%zu\n"
	.align	3
.LC6:
	.string	"offset.git_apply_options.flags=%zu\n"
	.align	3
.LC7:
	.string	"size.git_attr_options=%zu\n"
	.align	3
.LC8:
	.string	"align.git_attr_options=%zu\n"
	.align	3
.LC9:
	.string	"offset.git_attr_options.version=%zu\n"
	.align	3
.LC10:
	.string	"offset.git_attr_options.flags=%zu\n"
	.align	3
.LC11:
	.string	"offset.git_attr_options.commit_id=%zu\n"
	.align	3
.LC12:
	.string	"offset.git_attr_options.attr_commit_id=%zu\n"
	.align	3
.LC13:
	.string	"size.git_blame_hunk=%zu\n"
	.align	3
.LC14:
	.string	"align.git_blame_hunk=%zu\n"
	.align	3
.LC15:
	.string	"offset.git_blame_hunk.lines_in_hunk=%zu\n"
	.align	3
.LC16:
	.string	"offset.git_blame_hunk.final_commit_id=%zu\n"
	.align	3
.LC17:
	.string	"offset.git_blame_hunk.final_start_line_number=%zu\n"
	.align	3
.LC18:
	.string	"offset.git_blame_hunk.final_signature=%zu\n"
	.align	3
.LC19:
	.string	"offset.git_blame_hunk.final_committer=%zu\n"
	.align	3
.LC20:
	.string	"offset.git_blame_hunk.orig_commit_id=%zu\n"
	.align	3
.LC21:
	.string	"offset.git_blame_hunk.orig_path=%zu\n"
	.align	3
.LC22:
	.string	"offset.git_blame_hunk.orig_start_line_number=%zu\n"
	.align	3
.LC23:
	.string	"offset.git_blame_hunk.orig_signature=%zu\n"
	.align	3
.LC24:
	.string	"offset.git_blame_hunk.orig_committer=%zu\n"
	.align	3
.LC25:
	.string	"offset.git_blame_hunk.summary=%zu\n"
	.align	3
.LC26:
	.string	"offset.git_blame_hunk.boundary=%zu\n"
	.align	3
.LC27:
	.string	"size.git_blame_line=%zu\n"
	.align	3
.LC28:
	.string	"align.git_blame_line=%zu\n"
	.align	3
.LC29:
	.string	"offset.git_blame_line.ptr=%zu\n"
	.align	3
.LC30:
	.string	"offset.git_blame_line.len=%zu\n"
	.align	3
.LC31:
	.string	"size.git_blame_options=%zu\n"
	.align	3
.LC32:
	.string	"align.git_blame_options=%zu\n"
	.align	3
.LC33:
	.string	"offset.git_blame_options.version=%zu\n"
	.align	3
.LC34:
	.string	"offset.git_blame_options.flags=%zu\n"
	.align	3
.LC35:
	.string	"offset.git_blame_options.min_match_characters=%zu\n"
	.align	3
.LC36:
	.string	"offset.git_blame_options.newest_commit=%zu\n"
	.align	3
.LC37:
	.string	"offset.git_blame_options.oldest_commit=%zu\n"
	.align	3
.LC38:
	.string	"offset.git_blame_options.min_line=%zu\n"
	.align	3
.LC39:
	.string	"offset.git_blame_options.max_line=%zu\n"
	.align	3
.LC40:
	.string	"size.git_blob_filter_options=%zu\n"
	.align	3
.LC41:
	.string	"align.git_blob_filter_options=%zu\n"
	.align	3
.LC42:
	.string	"offset.git_blob_filter_options.version=%zu\n"
	.align	3
.LC43:
	.string	"offset.git_blob_filter_options.flags=%zu\n"
	.align	3
.LC44:
	.string	"offset.git_blob_filter_options.commit_id=%zu\n"
	.align	3
.LC45:
	.string	"offset.git_blob_filter_options.attr_commit_id=%zu\n"
	.align	3
.LC46:
	.string	"size.git_buf=%zu\n"
	.align	3
.LC47:
	.string	"align.git_buf=%zu\n"
	.align	3
.LC48:
	.string	"offset.git_buf.ptr=%zu\n"
	.align	3
.LC49:
	.string	"offset.git_buf.reserved=%zu\n"
	.align	3
.LC50:
	.string	"offset.git_buf.size=%zu\n"
	.align	3
.LC51:
	.string	"size.git_cert=%zu\n"
	.align	3
.LC52:
	.string	"align.git_cert=%zu\n"
	.align	3
.LC53:
	.string	"offset.git_cert.cert_type=%zu\n"
	.align	3
.LC54:
	.string	"size.git_cert_hostkey=%zu\n"
	.align	3
.LC55:
	.string	"align.git_cert_hostkey=%zu\n"
	.align	3
.LC56:
	.string	"offset.git_cert_hostkey.parent=%zu\n"
	.align	3
.LC57:
	.string	"offset.git_cert_hostkey.type=%zu\n"
	.align	3
.LC58:
	.string	"offset.git_cert_hostkey.hash_md5=%zu\n"
	.align	3
.LC59:
	.string	"offset.git_cert_hostkey.hash_sha1=%zu\n"
	.align	3
.LC60:
	.string	"offset.git_cert_hostkey.hash_sha256=%zu\n"
	.align	3
.LC61:
	.string	"offset.git_cert_hostkey.raw_type=%zu\n"
	.align	3
.LC62:
	.string	"offset.git_cert_hostkey.hostkey=%zu\n"
	.align	3
.LC63:
	.string	"offset.git_cert_hostkey.hostkey_len=%zu\n"
	.align	3
.LC64:
	.string	"size.git_cert_x509=%zu\n"
	.align	3
.LC65:
	.string	"align.git_cert_x509=%zu\n"
	.align	3
.LC66:
	.string	"offset.git_cert_x509.parent=%zu\n"
	.align	3
.LC67:
	.string	"offset.git_cert_x509.data=%zu\n"
	.align	3
.LC68:
	.string	"offset.git_cert_x509.len=%zu\n"
	.align	3
.LC69:
	.string	"size.git_checkout_options=%zu\n"
	.align	3
.LC70:
	.string	"align.git_checkout_options=%zu\n"
	.align	3
.LC71:
	.string	"offset.git_checkout_options.version=%zu\n"
	.align	3
.LC72:
	.string	"offset.git_checkout_options.checkout_strategy=%zu\n"
	.align	3
.LC73:
	.string	"offset.git_checkout_options.disable_filters=%zu\n"
	.align	3
.LC74:
	.string	"offset.git_checkout_options.dir_mode=%zu\n"
	.align	3
.LC75:
	.string	"offset.git_checkout_options.file_mode=%zu\n"
	.align	3
.LC76:
	.string	"offset.git_checkout_options.file_open_flags=%zu\n"
	.align	3
.LC77:
	.string	"offset.git_checkout_options.notify_flags=%zu\n"
	.align	3
.LC78:
	.string	"offset.git_checkout_options.notify_cb=%zu\n"
	.align	3
.LC79:
	.string	"offset.git_checkout_options.notify_payload=%zu\n"
	.align	3
.LC80:
	.string	"offset.git_checkout_options.progress_cb=%zu\n"
	.align	3
.LC81:
	.string	"offset.git_checkout_options.progress_payload=%zu\n"
	.align	3
.LC82:
	.string	"offset.git_checkout_options.paths=%zu\n"
	.align	3
.LC83:
	.string	"offset.git_checkout_options.baseline=%zu\n"
	.align	3
.LC84:
	.string	"offset.git_checkout_options.baseline_index=%zu\n"
	.align	3
.LC85:
	.string	"offset.git_checkout_options.target_directory=%zu\n"
	.align	3
.LC86:
	.string	"offset.git_checkout_options.ancestor_label=%zu\n"
	.align	3
.LC87:
	.string	"offset.git_checkout_options.our_label=%zu\n"
	.align	3
.LC88:
	.string	"offset.git_checkout_options.their_label=%zu\n"
	.align	3
.LC89:
	.string	"offset.git_checkout_options.perfdata_cb=%zu\n"
	.align	3
.LC90:
	.string	"offset.git_checkout_options.perfdata_payload=%zu\n"
	.align	3
.LC91:
	.string	"size.git_checkout_perfdata=%zu\n"
	.align	3
.LC92:
	.string	"align.git_checkout_perfdata=%zu\n"
	.align	3
.LC93:
	.string	"offset.git_checkout_perfdata.mkdir_calls=%zu\n"
	.align	3
.LC94:
	.string	"offset.git_checkout_perfdata.stat_calls=%zu\n"
	.align	3
.LC95:
	.string	"offset.git_checkout_perfdata.chmod_calls=%zu\n"
	.align	3
.LC96:
	.string	"size.git_cherrypick_options=%zu\n"
	.align	3
.LC97:
	.string	"align.git_cherrypick_options=%zu\n"
	.align	3
.LC98:
	.string	"offset.git_cherrypick_options.version=%zu\n"
	.align	3
.LC99:
	.string	"offset.git_cherrypick_options.mainline=%zu\n"
	.align	3
.LC100:
	.string	"offset.git_cherrypick_options.merge_opts=%zu\n"
	.align	3
.LC101:
	.string	"offset.git_cherrypick_options.checkout_opts=%zu\n"
	.align	3
.LC102:
	.string	"size.git_clone_options=%zu\n"
	.align	3
.LC103:
	.string	"align.git_clone_options=%zu\n"
	.align	3
.LC104:
	.string	"offset.git_clone_options.version=%zu\n"
	.align	3
.LC105:
	.string	"offset.git_clone_options.checkout_opts=%zu\n"
	.align	3
.LC106:
	.string	"offset.git_clone_options.fetch_opts=%zu\n"
	.align	3
.LC107:
	.string	"offset.git_clone_options.bare=%zu\n"
	.align	3
.LC108:
	.string	"offset.git_clone_options.local=%zu\n"
	.align	3
.LC109:
	.string	"offset.git_clone_options.checkout_branch=%zu\n"
	.align	3
.LC110:
	.string	"offset.git_clone_options.repository_cb=%zu\n"
	.align	3
.LC111:
	.string	"offset.git_clone_options.repository_cb_payload=%zu\n"
	.align	3
.LC112:
	.string	"offset.git_clone_options.remote_cb=%zu\n"
	.align	3
.LC113:
	.string	"offset.git_clone_options.remote_cb_payload=%zu\n"
	.align	3
.LC114:
	.string	"size.git_commit_create_options=%zu\n"
	.align	3
.LC115:
	.string	"align.git_commit_create_options=%zu\n"
	.align	3
.LC116:
	.string	"offset.git_commit_create_options.version=%zu\n"
	.align	3
.LC117:
	.string	"offset.git_commit_create_options.author=%zu\n"
	.align	3
.LC118:
	.string	"offset.git_commit_create_options.committer=%zu\n"
	.align	3
.LC119:
	.string	"offset.git_commit_create_options.message_encoding=%zu\n"
	.align	3
.LC120:
	.string	"size.git_commitarray=%zu\n"
	.align	3
.LC121:
	.string	"align.git_commitarray=%zu\n"
	.align	3
.LC122:
	.string	"offset.git_commitarray.commits=%zu\n"
	.align	3
.LC123:
	.string	"offset.git_commitarray.count=%zu\n"
	.align	3
.LC124:
	.string	"size.git_config_entry=%zu\n"
	.align	3
.LC125:
	.string	"align.git_config_entry=%zu\n"
	.align	3
.LC126:
	.string	"offset.git_config_entry.name=%zu\n"
	.align	3
.LC127:
	.string	"offset.git_config_entry.value=%zu\n"
	.align	3
.LC128:
	.string	"offset.git_config_entry.backend_type=%zu\n"
	.align	3
.LC129:
	.string	"offset.git_config_entry.origin_path=%zu\n"
	.align	3
.LC130:
	.string	"offset.git_config_entry.include_depth=%zu\n"
	.align	3
.LC131:
	.string	"offset.git_config_entry.level=%zu\n"
	.align	3
.LC132:
	.string	"size.git_credential=%zu\n"
	.align	3
.LC133:
	.string	"align.git_credential=%zu\n"
	.align	3
.LC134:
	.string	"offset.git_credential.credtype=%zu\n"
	.align	3
.LC135:
	.string	"offset.git_credential.free=%zu\n"
	.align	3
.LC136:
	.string	"size.git_credential_ssh_custom=%zu\n"
	.align	3
.LC137:
	.string	"align.git_credential_ssh_custom=%zu\n"
	.align	3
.LC138:
	.string	"offset.git_credential_ssh_custom.parent=%zu\n"
	.align	3
.LC139:
	.string	"offset.git_credential_ssh_custom.username=%zu\n"
	.align	3
.LC140:
	.string	"offset.git_credential_ssh_custom.publickey=%zu\n"
	.align	3
.LC141:
	.string	"offset.git_credential_ssh_custom.publickey_len=%zu\n"
	.align	3
.LC142:
	.string	"offset.git_credential_ssh_custom.sign_callback=%zu\n"
	.align	3
.LC143:
	.string	"offset.git_credential_ssh_custom.payload=%zu\n"
	.align	3
.LC144:
	.string	"size.git_credential_ssh_interactive=%zu\n"
	.align	3
.LC145:
	.string	"align.git_credential_ssh_interactive=%zu\n"
	.align	3
.LC146:
	.string	"offset.git_credential_ssh_interactive.parent=%zu\n"
	.align	3
.LC147:
	.string	"offset.git_credential_ssh_interactive.username=%zu\n"
	.align	3
.LC148:
	.string	"offset.git_credential_ssh_interactive.prompt_callback=%zu\n"
	.align	3
.LC149:
	.string	"offset.git_credential_ssh_interactive.payload=%zu\n"
	.align	3
.LC150:
	.string	"size.git_credential_ssh_key=%zu\n"
	.align	3
.LC151:
	.string	"align.git_credential_ssh_key=%zu\n"
	.align	3
.LC152:
	.string	"offset.git_credential_ssh_key.parent=%zu\n"
	.align	3
.LC153:
	.string	"offset.git_credential_ssh_key.username=%zu\n"
	.align	3
.LC154:
	.string	"offset.git_credential_ssh_key.publickey=%zu\n"
	.align	3
.LC155:
	.string	"offset.git_credential_ssh_key.privatekey=%zu\n"
	.align	3
.LC156:
	.string	"offset.git_credential_ssh_key.passphrase=%zu\n"
	.align	3
.LC157:
	.string	"size.git_credential_username=%zu\n"
	.align	3
.LC158:
	.string	"align.git_credential_username=%zu\n"
	.align	3
.LC159:
	.string	"offset.git_credential_username.parent=%zu\n"
	.align	3
.LC160:
	.string	"offset.git_credential_username.username=%zu\n"
	.align	3
.LC161:
	.string	"size.git_credential_userpass_payload=%zu\n"
	.align	3
.LC162:
	.string	"align.git_credential_userpass_payload=%zu\n"
	.align	3
.LC163:
	.string	"offset.git_credential_userpass_payload.username=%zu\n"
	.align	3
.LC164:
	.string	"offset.git_credential_userpass_payload.password=%zu\n"
	.align	3
.LC165:
	.string	"size.git_credential_userpass_plaintext=%zu\n"
	.align	3
.LC166:
	.string	"align.git_credential_userpass_plaintext=%zu\n"
	.align	3
.LC167:
	.string	"offset.git_credential_userpass_plaintext.parent=%zu\n"
	.align	3
.LC168:
	.string	"offset.git_credential_userpass_plaintext.username=%zu\n"
	.align	3
.LC169:
	.string	"offset.git_credential_userpass_plaintext.password=%zu\n"
	.align	3
.LC170:
	.string	"size.git_cvar_map=%zu\n"
	.align	3
.LC171:
	.string	"align.git_cvar_map=%zu\n"
	.align	3
.LC172:
	.string	"offset.git_cvar_map.type=%zu\n"
	.align	3
.LC173:
	.string	"offset.git_cvar_map.str_match=%zu\n"
	.align	3
.LC174:
	.string	"offset.git_cvar_map.map_value=%zu\n"
	.align	3
.LC175:
	.string	"size.git_describe_format_options=%zu\n"
	.align	3
.LC176:
	.string	"align.git_describe_format_options=%zu\n"
	.align	3
.LC177:
	.string	"offset.git_describe_format_options.version=%zu\n"
	.align	3
.LC178:
	.string	"offset.git_describe_format_options.abbreviated_size=%zu\n"
	.align	3
.LC179:
	.string	"offset.git_describe_format_options.always_use_long_format=%zu\n"
	.align	3
.LC180:
	.string	"offset.git_describe_format_options.dirty_suffix=%zu\n"
	.align	3
.LC181:
	.string	"size.git_describe_options=%zu\n"
	.align	3
.LC182:
	.string	"align.git_describe_options=%zu\n"
	.align	3
.LC183:
	.string	"offset.git_describe_options.version=%zu\n"
	.align	3
.LC184:
	.string	"offset.git_describe_options.max_candidates_tags=%zu\n"
	.align	3
.LC185:
	.string	"offset.git_describe_options.describe_strategy=%zu\n"
	.align	3
.LC186:
	.string	"offset.git_describe_options.pattern=%zu\n"
	.align	3
.LC187:
	.string	"offset.git_describe_options.only_follow_first_parent=%zu\n"
	.align	3
.LC188:
	.string	"offset.git_describe_options.show_commit_oid_as_fallback=%zu\n"
	.align	3
.LC189:
	.string	"size.git_diff_binary=%zu\n"
	.align	3
.LC190:
	.string	"align.git_diff_binary=%zu\n"
	.align	3
.LC191:
	.string	"offset.git_diff_binary.contains_data=%zu\n"
	.align	3
.LC192:
	.string	"offset.git_diff_binary.old_file=%zu\n"
	.align	3
.LC193:
	.string	"offset.git_diff_binary.new_file=%zu\n"
	.align	3
.LC194:
	.string	"size.git_diff_binary_file=%zu\n"
	.align	3
.LC195:
	.string	"align.git_diff_binary_file=%zu\n"
	.align	3
.LC196:
	.string	"offset.git_diff_binary_file.type=%zu\n"
	.align	3
.LC197:
	.string	"offset.git_diff_binary_file.data=%zu\n"
	.align	3
.LC198:
	.string	"offset.git_diff_binary_file.datalen=%zu\n"
	.align	3
.LC199:
	.string	"offset.git_diff_binary_file.inflatedlen=%zu\n"
	.align	3
.LC200:
	.string	"size.git_diff_delta=%zu\n"
	.align	3
.LC201:
	.string	"align.git_diff_delta=%zu\n"
	.align	3
.LC202:
	.string	"offset.git_diff_delta.status=%zu\n"
	.align	3
.LC203:
	.string	"offset.git_diff_delta.flags=%zu\n"
	.align	3
.LC204:
	.string	"offset.git_diff_delta.similarity=%zu\n"
	.align	3
.LC205:
	.string	"offset.git_diff_delta.nfiles=%zu\n"
	.align	3
.LC206:
	.string	"offset.git_diff_delta.old_file=%zu\n"
	.align	3
.LC207:
	.string	"offset.git_diff_delta.new_file=%zu\n"
	.align	3
.LC208:
	.string	"size.git_diff_file=%zu\n"
	.align	3
.LC209:
	.string	"align.git_diff_file=%zu\n"
	.align	3
.LC210:
	.string	"offset.git_diff_file.id=%zu\n"
	.align	3
.LC211:
	.string	"offset.git_diff_file.path=%zu\n"
	.align	3
.LC212:
	.string	"offset.git_diff_file.size=%zu\n"
	.align	3
.LC213:
	.string	"offset.git_diff_file.flags=%zu\n"
	.align	3
.LC214:
	.string	"offset.git_diff_file.mode=%zu\n"
	.align	3
.LC215:
	.string	"offset.git_diff_file.id_abbrev=%zu\n"
	.align	3
.LC216:
	.string	"size.git_diff_find_options=%zu\n"
	.align	3
.LC217:
	.string	"align.git_diff_find_options=%zu\n"
	.align	3
.LC218:
	.string	"offset.git_diff_find_options.version=%zu\n"
	.align	3
.LC219:
	.string	"offset.git_diff_find_options.flags=%zu\n"
	.align	3
.LC220:
	.string	"offset.git_diff_find_options.rename_threshold=%zu\n"
	.align	3
.LC221:
	.string	"offset.git_diff_find_options.rename_from_rewrite_threshold=%zu\n"
	.align	3
.LC222:
	.string	"offset.git_diff_find_options.copy_threshold=%zu\n"
	.align	3
.LC223:
	.string	"offset.git_diff_find_options.break_rewrite_threshold=%zu\n"
	.align	3
.LC224:
	.string	"offset.git_diff_find_options.rename_limit=%zu\n"
	.align	3
.LC225:
	.string	"offset.git_diff_find_options.metric=%zu\n"
	.align	3
.LC226:
	.string	"size.git_diff_format_email_options=%zu\n"
	.align	3
.LC227:
	.string	"align.git_diff_format_email_options=%zu\n"
	.align	3
.LC228:
	.string	"offset.git_diff_format_email_options.version=%zu\n"
	.align	3
.LC229:
	.string	"offset.git_diff_format_email_options.flags=%zu\n"
	.align	3
.LC230:
	.string	"offset.git_diff_format_email_options.patch_no=%zu\n"
	.align	3
.LC231:
	.string	"offset.git_diff_format_email_options.total_patches=%zu\n"
	.align	3
.LC232:
	.string	"offset.git_diff_format_email_options.id=%zu\n"
	.align	3
.LC233:
	.string	"offset.git_diff_format_email_options.summary=%zu\n"
	.align	3
.LC234:
	.string	"offset.git_diff_format_email_options.body=%zu\n"
	.align	3
.LC235:
	.string	"offset.git_diff_format_email_options.author=%zu\n"
	.align	3
.LC236:
	.string	"size.git_diff_hunk=%zu\n"
	.align	3
.LC237:
	.string	"align.git_diff_hunk=%zu\n"
	.align	3
.LC238:
	.string	"offset.git_diff_hunk.old_start=%zu\n"
	.align	3
.LC239:
	.string	"offset.git_diff_hunk.old_lines=%zu\n"
	.align	3
.LC240:
	.string	"offset.git_diff_hunk.new_start=%zu\n"
	.align	3
.LC241:
	.string	"offset.git_diff_hunk.new_lines=%zu\n"
	.align	3
.LC242:
	.string	"offset.git_diff_hunk.header_len=%zu\n"
	.align	3
.LC243:
	.string	"offset.git_diff_hunk.header=%zu\n"
	.align	3
.LC244:
	.string	"size.git_diff_line=%zu\n"
	.align	3
.LC245:
	.string	"align.git_diff_line=%zu\n"
	.align	3
.LC246:
	.string	"offset.git_diff_line.origin=%zu\n"
	.align	3
.LC247:
	.string	"offset.git_diff_line.old_lineno=%zu\n"
	.align	3
.LC248:
	.string	"offset.git_diff_line.new_lineno=%zu\n"
	.align	3
.LC249:
	.string	"offset.git_diff_line.num_lines=%zu\n"
	.align	3
.LC250:
	.string	"offset.git_diff_line.content_len=%zu\n"
	.align	3
.LC251:
	.string	"offset.git_diff_line.content_offset=%zu\n"
	.align	3
.LC252:
	.string	"offset.git_diff_line.content=%zu\n"
	.align	3
.LC253:
	.string	"size.git_diff_options=%zu\n"
	.align	3
.LC254:
	.string	"align.git_diff_options=%zu\n"
	.align	3
.LC255:
	.string	"offset.git_diff_options.version=%zu\n"
	.align	3
.LC256:
	.string	"offset.git_diff_options.flags=%zu\n"
	.align	3
.LC257:
	.string	"offset.git_diff_options.ignore_submodules=%zu\n"
	.align	3
.LC258:
	.string	"offset.git_diff_options.pathspec=%zu\n"
	.align	3
.LC259:
	.string	"offset.git_diff_options.notify_cb=%zu\n"
	.align	3
.LC260:
	.string	"offset.git_diff_options.progress_cb=%zu\n"
	.align	3
.LC261:
	.string	"offset.git_diff_options.payload=%zu\n"
	.align	3
.LC262:
	.string	"offset.git_diff_options.context_lines=%zu\n"
	.align	3
.LC263:
	.string	"offset.git_diff_options.interhunk_lines=%zu\n"
	.align	3
.LC264:
	.string	"offset.git_diff_options.oid_type=%zu\n"
	.align	3
.LC265:
	.string	"offset.git_diff_options.id_abbrev=%zu\n"
	.align	3
.LC266:
	.string	"offset.git_diff_options.max_size=%zu\n"
	.align	3
.LC267:
	.string	"offset.git_diff_options.old_prefix=%zu\n"
	.align	3
.LC268:
	.string	"offset.git_diff_options.new_prefix=%zu\n"
	.align	3
.LC269:
	.string	"size.git_diff_parse_options=%zu\n"
	.align	3
.LC270:
	.string	"align.git_diff_parse_options=%zu\n"
	.align	3
.LC271:
	.string	"offset.git_diff_parse_options.version=%zu\n"
	.align	3
.LC272:
	.string	"offset.git_diff_parse_options.oid_type=%zu\n"
	.align	3
.LC273:
	.string	"size.git_diff_patchid_options=%zu\n"
	.align	3
.LC274:
	.string	"align.git_diff_patchid_options=%zu\n"
	.align	3
.LC275:
	.string	"offset.git_diff_patchid_options.version=%zu\n"
	.align	3
.LC276:
	.string	"size.git_diff_similarity_metric=%zu\n"
	.align	3
.LC277:
	.string	"align.git_diff_similarity_metric=%zu\n"
	.align	3
.LC278:
	.string	"offset.git_diff_similarity_metric.file_signature=%zu\n"
	.align	3
.LC279:
	.string	"offset.git_diff_similarity_metric.buffer_signature=%zu\n"
	.align	3
.LC280:
	.string	"offset.git_diff_similarity_metric.free_signature=%zu\n"
	.align	3
.LC281:
	.string	"offset.git_diff_similarity_metric.similarity=%zu\n"
	.align	3
.LC282:
	.string	"offset.git_diff_similarity_metric.payload=%zu\n"
	.align	3
.LC283:
	.string	"size.git_email_create_options=%zu\n"
	.align	3
.LC284:
	.string	"align.git_email_create_options=%zu\n"
	.align	3
.LC285:
	.string	"offset.git_email_create_options.version=%zu\n"
	.align	3
.LC286:
	.string	"offset.git_email_create_options.flags=%zu\n"
	.align	3
.LC287:
	.string	"offset.git_email_create_options.diff_opts=%zu\n"
	.align	3
.LC288:
	.string	"offset.git_email_create_options.diff_find_opts=%zu\n"
	.align	3
.LC289:
	.string	"offset.git_email_create_options.subject_prefix=%zu\n"
	.align	3
.LC290:
	.string	"offset.git_email_create_options.start_number=%zu\n"
	.align	3
.LC291:
	.string	"offset.git_email_create_options.reroll_number=%zu\n"
	.align	3
.LC292:
	.string	"size.git_error=%zu\n"
	.align	3
.LC293:
	.string	"align.git_error=%zu\n"
	.align	3
.LC294:
	.string	"offset.git_error.message=%zu\n"
	.align	3
.LC295:
	.string	"offset.git_error.klass=%zu\n"
	.align	3
.LC296:
	.string	"size.git_fetch_options=%zu\n"
	.align	3
.LC297:
	.string	"align.git_fetch_options=%zu\n"
	.align	3
.LC298:
	.string	"offset.git_fetch_options.version=%zu\n"
	.align	3
.LC299:
	.string	"offset.git_fetch_options.callbacks=%zu\n"
	.align	3
.LC300:
	.string	"offset.git_fetch_options.prune=%zu\n"
	.align	3
.LC301:
	.string	"offset.git_fetch_options.update_fetchhead=%zu\n"
	.align	3
.LC302:
	.string	"offset.git_fetch_options.download_tags=%zu\n"
	.align	3
.LC303:
	.string	"offset.git_fetch_options.proxy_opts=%zu\n"
	.align	3
.LC304:
	.string	"offset.git_fetch_options.depth=%zu\n"
	.align	3
.LC305:
	.string	"offset.git_fetch_options.follow_redirects=%zu\n"
	.align	3
.LC306:
	.string	"offset.git_fetch_options.custom_headers=%zu\n"
	.align	3
.LC307:
	.string	"size.git_filter_options=%zu\n"
	.align	3
.LC308:
	.string	"align.git_filter_options=%zu\n"
	.align	3
.LC309:
	.string	"offset.git_filter_options.version=%zu\n"
	.align	3
.LC310:
	.string	"offset.git_filter_options.flags=%zu\n"
	.align	3
.LC311:
	.string	"offset.git_filter_options.commit_id=%zu\n"
	.align	3
.LC312:
	.string	"offset.git_filter_options.attr_commit_id=%zu\n"
	.align	3
.LC313:
	.string	"size.git_index_entry=%zu\n"
	.align	3
.LC314:
	.string	"align.git_index_entry=%zu\n"
	.align	3
.LC315:
	.string	"offset.git_index_entry.ctime=%zu\n"
	.align	3
.LC316:
	.string	"offset.git_index_entry.mtime=%zu\n"
	.align	3
.LC317:
	.string	"offset.git_index_entry.dev=%zu\n"
	.align	3
.LC318:
	.string	"offset.git_index_entry.ino=%zu\n"
	.align	3
.LC319:
	.string	"offset.git_index_entry.mode=%zu\n"
	.align	3
.LC320:
	.string	"offset.git_index_entry.uid=%zu\n"
	.align	3
.LC321:
	.string	"offset.git_index_entry.gid=%zu\n"
	.align	3
.LC322:
	.string	"offset.git_index_entry.file_size=%zu\n"
	.align	3
.LC323:
	.string	"offset.git_index_entry.id=%zu\n"
	.align	3
.LC324:
	.string	"offset.git_index_entry.flags=%zu\n"
	.align	3
.LC325:
	.string	"offset.git_index_entry.flags_extended=%zu\n"
	.align	3
.LC326:
	.string	"offset.git_index_entry.path=%zu\n"
	.align	3
.LC327:
	.string	"size.git_index_time=%zu\n"
	.align	3
.LC328:
	.string	"align.git_index_time=%zu\n"
	.align	3
.LC329:
	.string	"offset.git_index_time.seconds=%zu\n"
	.align	3
.LC330:
	.string	"offset.git_index_time.nanoseconds=%zu\n"
	.align	3
.LC331:
	.string	"size.git_indexer_options=%zu\n"
	.align	3
.LC332:
	.string	"align.git_indexer_options=%zu\n"
	.align	3
.LC333:
	.string	"offset.git_indexer_options.version=%zu\n"
	.align	3
.LC334:
	.string	"offset.git_indexer_options.progress_cb=%zu\n"
	.align	3
.LC335:
	.string	"offset.git_indexer_options.progress_cb_payload=%zu\n"
	.align	3
.LC336:
	.string	"offset.git_indexer_options.verify=%zu\n"
	.align	3
.LC337:
	.string	"size.git_indexer_progress=%zu\n"
	.align	3
.LC338:
	.string	"align.git_indexer_progress=%zu\n"
	.align	3
.LC339:
	.string	"offset.git_indexer_progress.total_objects=%zu\n"
	.align	3
.LC340:
	.string	"offset.git_indexer_progress.indexed_objects=%zu\n"
	.align	3
.LC341:
	.string	"offset.git_indexer_progress.received_objects=%zu\n"
	.align	3
.LC342:
	.string	"offset.git_indexer_progress.local_objects=%zu\n"
	.align	3
.LC343:
	.string	"offset.git_indexer_progress.total_deltas=%zu\n"
	.align	3
.LC344:
	.string	"offset.git_indexer_progress.indexed_deltas=%zu\n"
	.align	3
.LC345:
	.string	"offset.git_indexer_progress.received_bytes=%zu\n"
	.align	3
.LC346:
	.string	"size.git_merge_file_input=%zu\n"
	.align	3
.LC347:
	.string	"align.git_merge_file_input=%zu\n"
	.align	3
.LC348:
	.string	"offset.git_merge_file_input.version=%zu\n"
	.align	3
.LC349:
	.string	"offset.git_merge_file_input.ptr=%zu\n"
	.align	3
.LC350:
	.string	"offset.git_merge_file_input.size=%zu\n"
	.align	3
.LC351:
	.string	"offset.git_merge_file_input.path=%zu\n"
	.align	3
.LC352:
	.string	"offset.git_merge_file_input.mode=%zu\n"
	.align	3
.LC353:
	.string	"size.git_merge_file_options=%zu\n"
	.align	3
.LC354:
	.string	"align.git_merge_file_options=%zu\n"
	.align	3
.LC355:
	.string	"offset.git_merge_file_options.version=%zu\n"
	.align	3
.LC356:
	.string	"offset.git_merge_file_options.ancestor_label=%zu\n"
	.align	3
.LC357:
	.string	"offset.git_merge_file_options.our_label=%zu\n"
	.align	3
.LC358:
	.string	"offset.git_merge_file_options.their_label=%zu\n"
	.align	3
.LC359:
	.string	"offset.git_merge_file_options.favor=%zu\n"
	.align	3
.LC360:
	.string	"offset.git_merge_file_options.flags=%zu\n"
	.align	3
.LC361:
	.string	"offset.git_merge_file_options.marker_size=%zu\n"
	.align	3
.LC362:
	.string	"size.git_merge_file_result=%zu\n"
	.align	3
.LC363:
	.string	"align.git_merge_file_result=%zu\n"
	.align	3
.LC364:
	.string	"offset.git_merge_file_result.automergeable=%zu\n"
	.align	3
.LC365:
	.string	"offset.git_merge_file_result.path=%zu\n"
	.align	3
.LC366:
	.string	"offset.git_merge_file_result.mode=%zu\n"
	.align	3
.LC367:
	.string	"offset.git_merge_file_result.ptr=%zu\n"
	.align	3
.LC368:
	.string	"offset.git_merge_file_result.len=%zu\n"
	.align	3
.LC369:
	.string	"size.git_merge_options=%zu\n"
	.align	3
.LC370:
	.string	"align.git_merge_options=%zu\n"
	.align	3
.LC371:
	.string	"offset.git_merge_options.version=%zu\n"
	.align	3
.LC372:
	.string	"offset.git_merge_options.flags=%zu\n"
	.align	3
.LC373:
	.string	"offset.git_merge_options.rename_threshold=%zu\n"
	.align	3
.LC374:
	.string	"offset.git_merge_options.target_limit=%zu\n"
	.align	3
.LC375:
	.string	"offset.git_merge_options.metric=%zu\n"
	.align	3
.LC376:
	.string	"offset.git_merge_options.recursion_limit=%zu\n"
	.align	3
.LC377:
	.string	"offset.git_merge_options.default_driver=%zu\n"
	.align	3
.LC378:
	.string	"offset.git_merge_options.file_favor=%zu\n"
	.align	3
.LC379:
	.string	"offset.git_merge_options.file_flags=%zu\n"
	.align	3
.LC380:
	.string	"size.git_message_trailer=%zu\n"
	.align	3
.LC381:
	.string	"align.git_message_trailer=%zu\n"
	.align	3
.LC382:
	.string	"offset.git_message_trailer.key=%zu\n"
	.align	3
.LC383:
	.string	"offset.git_message_trailer.value=%zu\n"
	.align	3
.LC384:
	.string	"size.git_message_trailer_array=%zu\n"
	.align	3
.LC385:
	.string	"align.git_message_trailer_array=%zu\n"
	.align	3
.LC386:
	.string	"offset.git_message_trailer_array.trailers=%zu\n"
	.align	3
.LC387:
	.string	"offset.git_message_trailer_array.count=%zu\n"
	.align	3
.LC388:
	.string	"offset.git_message_trailer_array._trailer_block=%zu\n"
	.align	3
.LC389:
	.string	"size.git_odb_backend_loose_options=%zu\n"
	.align	3
.LC390:
	.string	"align.git_odb_backend_loose_options=%zu\n"
	.align	3
.LC391:
	.string	"offset.git_odb_backend_loose_options.version=%zu\n"
	.align	3
.LC392:
	.string	"offset.git_odb_backend_loose_options.flags=%zu\n"
	.align	3
.LC393:
	.string	"offset.git_odb_backend_loose_options.compression_level=%zu\n"
	.align	3
.LC394:
	.string	"offset.git_odb_backend_loose_options.dir_mode=%zu\n"
	.align	3
.LC395:
	.string	"offset.git_odb_backend_loose_options.file_mode=%zu\n"
	.align	3
.LC396:
	.string	"offset.git_odb_backend_loose_options.oid_type=%zu\n"
	.align	3
.LC397:
	.string	"size.git_odb_backend_pack_options=%zu\n"
	.align	3
.LC398:
	.string	"align.git_odb_backend_pack_options=%zu\n"
	.align	3
.LC399:
	.string	"offset.git_odb_backend_pack_options.version=%zu\n"
	.align	3
.LC400:
	.string	"offset.git_odb_backend_pack_options.oid_type=%zu\n"
	.align	3
.LC401:
	.string	"size.git_odb_expand_id=%zu\n"
	.align	3
.LC402:
	.string	"align.git_odb_expand_id=%zu\n"
	.align	3
.LC403:
	.string	"offset.git_odb_expand_id.id=%zu\n"
	.align	3
.LC404:
	.string	"offset.git_odb_expand_id.length=%zu\n"
	.align	3
.LC405:
	.string	"offset.git_odb_expand_id.type=%zu\n"
	.align	3
.LC406:
	.string	"size.git_odb_options=%zu\n"
	.align	3
.LC407:
	.string	"align.git_odb_options=%zu\n"
	.align	3
.LC408:
	.string	"offset.git_odb_options.version=%zu\n"
	.align	3
.LC409:
	.string	"offset.git_odb_options.oid_type=%zu\n"
	.align	3
.LC410:
	.string	"size.git_odb_stream=%zu\n"
	.align	3
.LC411:
	.string	"align.git_odb_stream=%zu\n"
	.align	3
.LC412:
	.string	"offset.git_odb_stream.backend=%zu\n"
	.align	3
.LC413:
	.string	"offset.git_odb_stream.mode=%zu\n"
	.align	3
.LC414:
	.string	"offset.git_odb_stream.hash_ctx=%zu\n"
	.align	3
.LC415:
	.string	"offset.git_odb_stream.declared_size=%zu\n"
	.align	3
.LC416:
	.string	"offset.git_odb_stream.received_bytes=%zu\n"
	.align	3
.LC417:
	.string	"offset.git_odb_stream.read=%zu\n"
	.align	3
.LC418:
	.string	"offset.git_odb_stream.write=%zu\n"
	.align	3
.LC419:
	.string	"offset.git_odb_stream.finalize_write=%zu\n"
	.align	3
.LC420:
	.string	"offset.git_odb_stream.free=%zu\n"
	.align	3
.LC421:
	.string	"size.git_odb_writepack=%zu\n"
	.align	3
.LC422:
	.string	"align.git_odb_writepack=%zu\n"
	.align	3
.LC423:
	.string	"offset.git_odb_writepack.backend=%zu\n"
	.align	3
.LC424:
	.string	"offset.git_odb_writepack.append=%zu\n"
	.align	3
.LC425:
	.string	"offset.git_odb_writepack.commit=%zu\n"
	.align	3
.LC426:
	.string	"offset.git_odb_writepack.free=%zu\n"
	.align	3
.LC427:
	.string	"size.git_oid=%zu\n"
	.align	3
.LC428:
	.string	"align.git_oid=%zu\n"
	.align	3
.LC429:
	.string	"offset.git_oid.id=%zu\n"
	.align	3
.LC430:
	.string	"size.git_oidarray=%zu\n"
	.align	3
.LC431:
	.string	"align.git_oidarray=%zu\n"
	.align	3
.LC432:
	.string	"offset.git_oidarray.ids=%zu\n"
	.align	3
.LC433:
	.string	"offset.git_oidarray.count=%zu\n"
	.align	3
.LC434:
	.string	"size.git_proxy_options=%zu\n"
	.align	3
.LC435:
	.string	"align.git_proxy_options=%zu\n"
	.align	3
.LC436:
	.string	"offset.git_proxy_options.version=%zu\n"
	.align	3
.LC437:
	.string	"offset.git_proxy_options.type=%zu\n"
	.align	3
.LC438:
	.string	"offset.git_proxy_options.url=%zu\n"
	.align	3
.LC439:
	.string	"offset.git_proxy_options.credentials=%zu\n"
	.align	3
.LC440:
	.string	"offset.git_proxy_options.certificate_check=%zu\n"
	.align	3
.LC441:
	.string	"offset.git_proxy_options.payload=%zu\n"
	.align	3
.LC442:
	.string	"size.git_push_options=%zu\n"
	.align	3
.LC443:
	.string	"align.git_push_options=%zu\n"
	.align	3
.LC444:
	.string	"offset.git_push_options.version=%zu\n"
	.align	3
.LC445:
	.string	"offset.git_push_options.pb_parallelism=%zu\n"
	.align	3
.LC446:
	.string	"offset.git_push_options.callbacks=%zu\n"
	.align	3
.LC447:
	.string	"offset.git_push_options.proxy_opts=%zu\n"
	.align	3
.LC448:
	.string	"offset.git_push_options.follow_redirects=%zu\n"
	.align	3
.LC449:
	.string	"offset.git_push_options.custom_headers=%zu\n"
	.align	3
.LC450:
	.string	"offset.git_push_options.remote_push_options=%zu\n"
	.align	3
.LC451:
	.string	"size.git_push_update=%zu\n"
	.align	3
.LC452:
	.string	"align.git_push_update=%zu\n"
	.align	3
.LC453:
	.string	"offset.git_push_update.src_refname=%zu\n"
	.align	3
.LC454:
	.string	"offset.git_push_update.dst_refname=%zu\n"
	.align	3
.LC455:
	.string	"offset.git_push_update.src=%zu\n"
	.align	3
.LC456:
	.string	"offset.git_push_update.dst=%zu\n"
	.align	3
.LC457:
	.string	"size.git_rebase_operation=%zu\n"
	.align	3
.LC458:
	.string	"align.git_rebase_operation=%zu\n"
	.align	3
.LC459:
	.string	"offset.git_rebase_operation.type=%zu\n"
	.align	3
.LC460:
	.string	"offset.git_rebase_operation.id=%zu\n"
	.align	3
.LC461:
	.string	"offset.git_rebase_operation.exec=%zu\n"
	.align	3
.LC462:
	.string	"size.git_rebase_options=%zu\n"
	.align	3
.LC463:
	.string	"align.git_rebase_options=%zu\n"
	.align	3
.LC464:
	.string	"offset.git_rebase_options.version=%zu\n"
	.align	3
.LC465:
	.string	"offset.git_rebase_options.quiet=%zu\n"
	.align	3
.LC466:
	.string	"offset.git_rebase_options.inmemory=%zu\n"
	.align	3
.LC467:
	.string	"offset.git_rebase_options.rewrite_notes_ref=%zu\n"
	.align	3
.LC468:
	.string	"offset.git_rebase_options.merge_options=%zu\n"
	.align	3
.LC469:
	.string	"offset.git_rebase_options.checkout_options=%zu\n"
	.align	3
.LC470:
	.string	"offset.git_rebase_options.commit_create_cb=%zu\n"
	.align	3
.LC471:
	.string	"offset.git_rebase_options.signing_cb=%zu\n"
	.align	3
.LC472:
	.string	"offset.git_rebase_options.payload=%zu\n"
	.align	3
.LC473:
	.string	"size.git_remote_callbacks=%zu\n"
	.align	3
.LC474:
	.string	"align.git_remote_callbacks=%zu\n"
	.align	3
.LC475:
	.string	"offset.git_remote_callbacks.version=%zu\n"
	.align	3
.LC476:
	.string	"offset.git_remote_callbacks.sideband_progress=%zu\n"
	.align	3
.LC477:
	.string	"offset.git_remote_callbacks.completion=%zu\n"
	.align	3
.LC478:
	.string	"offset.git_remote_callbacks.credentials=%zu\n"
	.align	3
.LC479:
	.string	"offset.git_remote_callbacks.certificate_check=%zu\n"
	.align	3
.LC480:
	.string	"offset.git_remote_callbacks.transfer_progress=%zu\n"
	.align	3
.LC481:
	.string	"offset.git_remote_callbacks.update_tips=%zu\n"
	.align	3
.LC482:
	.string	"offset.git_remote_callbacks.pack_progress=%zu\n"
	.align	3
.LC483:
	.string	"offset.git_remote_callbacks.push_transfer_progress=%zu\n"
	.align	3
.LC484:
	.string	"offset.git_remote_callbacks.push_update_reference=%zu\n"
	.align	3
.LC485:
	.string	"offset.git_remote_callbacks.push_negotiation=%zu\n"
	.align	3
.LC486:
	.string	"offset.git_remote_callbacks.transport=%zu\n"
	.align	3
.LC487:
	.string	"offset.git_remote_callbacks.remote_ready=%zu\n"
	.align	3
.LC488:
	.string	"offset.git_remote_callbacks.payload=%zu\n"
	.align	3
.LC489:
	.string	"offset.git_remote_callbacks.resolve_url=%zu\n"
	.align	3
.LC490:
	.string	"offset.git_remote_callbacks.update_refs=%zu\n"
	.align	3
.LC491:
	.string	"size.git_remote_connect_options=%zu\n"
	.align	3
.LC492:
	.string	"align.git_remote_connect_options=%zu\n"
	.align	3
.LC493:
	.string	"offset.git_remote_connect_options.version=%zu\n"
	.align	3
.LC494:
	.string	"offset.git_remote_connect_options.callbacks=%zu\n"
	.align	3
.LC495:
	.string	"offset.git_remote_connect_options.proxy_opts=%zu\n"
	.align	3
.LC496:
	.string	"offset.git_remote_connect_options.follow_redirects=%zu\n"
	.align	3
.LC497:
	.string	"offset.git_remote_connect_options.custom_headers=%zu\n"
	.align	3
.LC498:
	.string	"size.git_remote_create_options=%zu\n"
	.align	3
.LC499:
	.string	"align.git_remote_create_options=%zu\n"
	.align	3
.LC500:
	.string	"offset.git_remote_create_options.version=%zu\n"
	.align	3
.LC501:
	.string	"offset.git_remote_create_options.repository=%zu\n"
	.align	3
.LC502:
	.string	"offset.git_remote_create_options.name=%zu\n"
	.align	3
.LC503:
	.string	"offset.git_remote_create_options.fetchspec=%zu\n"
	.align	3
.LC504:
	.string	"offset.git_remote_create_options.flags=%zu\n"
	.align	3
.LC505:
	.string	"size.git_remote_head=%zu\n"
	.align	3
.LC506:
	.string	"align.git_remote_head=%zu\n"
	.align	3
.LC507:
	.string	"offset.git_remote_head.local=%zu\n"
	.align	3
.LC508:
	.string	"offset.git_remote_head.oid=%zu\n"
	.align	3
.LC509:
	.string	"offset.git_remote_head.loid=%zu\n"
	.align	3
.LC510:
	.string	"offset.git_remote_head.name=%zu\n"
	.align	3
.LC511:
	.string	"offset.git_remote_head.symref_target=%zu\n"
	.align	3
.LC512:
	.string	"size.git_repository_init_options=%zu\n"
	.align	3
.LC513:
	.string	"align.git_repository_init_options=%zu\n"
	.align	3
.LC514:
	.string	"offset.git_repository_init_options.version=%zu\n"
	.align	3
.LC515:
	.string	"offset.git_repository_init_options.flags=%zu\n"
	.align	3
.LC516:
	.string	"offset.git_repository_init_options.mode=%zu\n"
	.align	3
.LC517:
	.string	"offset.git_repository_init_options.workdir_path=%zu\n"
	.align	3
.LC518:
	.string	"offset.git_repository_init_options.description=%zu\n"
	.align	3
.LC519:
	.string	"offset.git_repository_init_options.template_path=%zu\n"
	.align	3
.LC520:
	.string	"offset.git_repository_init_options.initial_head=%zu\n"
	.align	3
.LC521:
	.string	"offset.git_repository_init_options.origin_url=%zu\n"
	.align	3
.LC522:
	.string	"size.git_revert_options=%zu\n"
	.align	3
.LC523:
	.string	"align.git_revert_options=%zu\n"
	.align	3
.LC524:
	.string	"offset.git_revert_options.version=%zu\n"
	.align	3
.LC525:
	.string	"offset.git_revert_options.mainline=%zu\n"
	.align	3
.LC526:
	.string	"offset.git_revert_options.merge_opts=%zu\n"
	.align	3
.LC527:
	.string	"offset.git_revert_options.checkout_opts=%zu\n"
	.align	3
.LC528:
	.string	"size.git_revspec=%zu\n"
	.align	3
.LC529:
	.string	"align.git_revspec=%zu\n"
	.align	3
.LC530:
	.string	"offset.git_revspec.from=%zu\n"
	.align	3
.LC531:
	.string	"offset.git_revspec.to=%zu\n"
	.align	3
.LC532:
	.string	"offset.git_revspec.flags=%zu\n"
	.align	3
.LC533:
	.string	"size.git_signature=%zu\n"
	.align	3
.LC534:
	.string	"align.git_signature=%zu\n"
	.align	3
.LC535:
	.string	"offset.git_signature.name=%zu\n"
	.align	3
.LC536:
	.string	"offset.git_signature.email=%zu\n"
	.align	3
.LC537:
	.string	"offset.git_signature.when=%zu\n"
	.align	3
.LC538:
	.string	"size.git_stash_apply_options=%zu\n"
	.align	3
.LC539:
	.string	"align.git_stash_apply_options=%zu\n"
	.align	3
.LC540:
	.string	"offset.git_stash_apply_options.version=%zu\n"
	.align	3
.LC541:
	.string	"offset.git_stash_apply_options.flags=%zu\n"
	.align	3
.LC542:
	.string	"offset.git_stash_apply_options.checkout_options=%zu\n"
	.align	3
.LC543:
	.string	"offset.git_stash_apply_options.progress_cb=%zu\n"
	.align	3
.LC544:
	.string	"offset.git_stash_apply_options.progress_payload=%zu\n"
	.align	3
.LC545:
	.string	"size.git_stash_save_options=%zu\n"
	.align	3
.LC546:
	.string	"align.git_stash_save_options=%zu\n"
	.align	3
.LC547:
	.string	"offset.git_stash_save_options.version=%zu\n"
	.align	3
.LC548:
	.string	"offset.git_stash_save_options.flags=%zu\n"
	.align	3
.LC549:
	.string	"offset.git_stash_save_options.stasher=%zu\n"
	.align	3
.LC550:
	.string	"offset.git_stash_save_options.message=%zu\n"
	.align	3
.LC551:
	.string	"offset.git_stash_save_options.paths=%zu\n"
	.align	3
.LC552:
	.string	"size.git_status_entry=%zu\n"
	.align	3
.LC553:
	.string	"align.git_status_entry=%zu\n"
	.align	3
.LC554:
	.string	"offset.git_status_entry.status=%zu\n"
	.align	3
.LC555:
	.string	"offset.git_status_entry.head_to_index=%zu\n"
	.align	3
.LC556:
	.string	"offset.git_status_entry.index_to_workdir=%zu\n"
	.align	3
.LC557:
	.string	"size.git_status_options=%zu\n"
	.align	3
.LC558:
	.string	"align.git_status_options=%zu\n"
	.align	3
.LC559:
	.string	"offset.git_status_options.version=%zu\n"
	.align	3
.LC560:
	.string	"offset.git_status_options.show=%zu\n"
	.align	3
.LC561:
	.string	"offset.git_status_options.flags=%zu\n"
	.align	3
.LC562:
	.string	"offset.git_status_options.pathspec=%zu\n"
	.align	3
.LC563:
	.string	"offset.git_status_options.baseline=%zu\n"
	.align	3
.LC564:
	.string	"offset.git_status_options.rename_threshold=%zu\n"
	.align	3
.LC565:
	.string	"size.git_strarray=%zu\n"
	.align	3
.LC566:
	.string	"align.git_strarray=%zu\n"
	.align	3
.LC567:
	.string	"offset.git_strarray.strings=%zu\n"
	.align	3
.LC568:
	.string	"offset.git_strarray.count=%zu\n"
	.align	3
.LC569:
	.string	"size.git_submodule_update_options=%zu\n"
	.align	3
.LC570:
	.string	"align.git_submodule_update_options=%zu\n"
	.align	3
.LC571:
	.string	"offset.git_submodule_update_options.version=%zu\n"
	.align	3
.LC572:
	.string	"offset.git_submodule_update_options.checkout_opts=%zu\n"
	.align	3
.LC573:
	.string	"offset.git_submodule_update_options.fetch_opts=%zu\n"
	.align	3
.LC574:
	.string	"offset.git_submodule_update_options.allow_fetch=%zu\n"
	.align	3
.LC575:
	.string	"size.git_time=%zu\n"
	.align	3
.LC576:
	.string	"align.git_time=%zu\n"
	.align	3
.LC577:
	.string	"offset.git_time.time=%zu\n"
	.align	3
.LC578:
	.string	"offset.git_time.offset=%zu\n"
	.align	3
.LC579:
	.string	"offset.git_time.sign=%zu\n"
	.align	3
.LC580:
	.string	"size.git_tree_update=%zu\n"
	.align	3
.LC581:
	.string	"align.git_tree_update=%zu\n"
	.align	3
.LC582:
	.string	"offset.git_tree_update.action=%zu\n"
	.align	3
.LC583:
	.string	"offset.git_tree_update.id=%zu\n"
	.align	3
.LC584:
	.string	"offset.git_tree_update.filemode=%zu\n"
	.align	3
.LC585:
	.string	"offset.git_tree_update.path=%zu\n"
	.align	3
.LC586:
	.string	"size.git_worktree_add_options=%zu\n"
	.align	3
.LC587:
	.string	"align.git_worktree_add_options=%zu\n"
	.align	3
.LC588:
	.string	"offset.git_worktree_add_options.version=%zu\n"
	.align	3
.LC589:
	.string	"offset.git_worktree_add_options.lock=%zu\n"
	.align	3
.LC590:
	.string	"offset.git_worktree_add_options.checkout_existing=%zu\n"
	.align	3
.LC591:
	.string	"offset.git_worktree_add_options.ref=%zu\n"
	.align	3
.LC592:
	.string	"offset.git_worktree_add_options.checkout_options=%zu\n"
	.align	3
.LC593:
	.string	"size.git_worktree_prune_options=%zu\n"
	.align	3
.LC594:
	.string	"align.git_worktree_prune_options=%zu\n"
	.align	3
.LC595:
	.string	"offset.git_worktree_prune_options.version=%zu\n"
	.align	3
.LC596:
	.string	"offset.git_worktree_prune_options.flags=%zu\n"
	.align	3
.LC597:
	.string	"size.git_writestream=%zu\n"
	.align	3
.LC598:
	.string	"align.git_writestream=%zu\n"
	.align	3
.LC599:
	.string	"offset.git_writestream.write=%zu\n"
	.align	3
.LC600:
	.string	"offset.git_writestream.close=%zu\n"
	.align	3
.LC601:
	.string	"offset.git_writestream.free=%zu\n"
	.section	.text.startup,"ax",@progbits
	.align	2
	.p2align 4,,11
	.global	main
	.type	main, %function
main:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	mov	x1, 40
	adrp	x0, .LC0
	mov	x29, sp
	add	x0, x0, :lo12:.LC0
	bl	printf
	mov	x1, 8
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
	bl	printf
	mov	x1, 0
	adrp	x0, .LC2
	add	x0, x0, :lo12:.LC2
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3
	add	x0, x0, :lo12:.LC3
	bl	printf
	mov	x1, 16
	adrp	x0, .LC4
	add	x0, x0, :lo12:.LC4
	bl	printf
	mov	x1, 24
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	bl	printf
	mov	x1, 32
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	bl	printf
	mov	x1, 40
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
	bl	printf
	mov	x1, 8
	adrp	x0, .LC8
	add	x0, x0, :lo12:.LC8
	bl	printf
	mov	x1, 0
	adrp	x0, .LC9
	add	x0, x0, :lo12:.LC9
	bl	printf
	mov	x1, 4
	adrp	x0, .LC10
	add	x0, x0, :lo12:.LC10
	bl	printf
	mov	x1, 8
	adrp	x0, .LC11
	add	x0, x0, :lo12:.LC11
	bl	printf
	mov	x1, 16
	adrp	x0, .LC12
	add	x0, x0, :lo12:.LC12
	bl	printf
	mov	x1, 128
	adrp	x0, .LC13
	add	x0, x0, :lo12:.LC13
	bl	printf
	mov	x1, 8
	adrp	x0, .LC14
	add	x0, x0, :lo12:.LC14
	bl	printf
	mov	x1, 0
	adrp	x0, .LC15
	add	x0, x0, :lo12:.LC15
	bl	printf
	mov	x1, 8
	adrp	x0, .LC16
	add	x0, x0, :lo12:.LC16
	bl	printf
	mov	x1, 32
	adrp	x0, .LC17
	add	x0, x0, :lo12:.LC17
	bl	printf
	mov	x1, 40
	adrp	x0, .LC18
	add	x0, x0, :lo12:.LC18
	bl	printf
	mov	x1, 48
	adrp	x0, .LC19
	add	x0, x0, :lo12:.LC19
	bl	printf
	mov	x1, 56
	adrp	x0, .LC20
	add	x0, x0, :lo12:.LC20
	bl	printf
	mov	x1, 80
	adrp	x0, .LC21
	add	x0, x0, :lo12:.LC21
	bl	printf
	mov	x1, 88
	adrp	x0, .LC22
	add	x0, x0, :lo12:.LC22
	bl	printf
	mov	x1, 96
	adrp	x0, .LC23
	add	x0, x0, :lo12:.LC23
	bl	printf
	mov	x1, 104
	adrp	x0, .LC24
	add	x0, x0, :lo12:.LC24
	bl	printf
	mov	x1, 112
	adrp	x0, .LC25
	add	x0, x0, :lo12:.LC25
	bl	printf
	mov	x1, 120
	adrp	x0, .LC26
	add	x0, x0, :lo12:.LC26
	bl	printf
	mov	x1, 16
	adrp	x0, .LC27
	add	x0, x0, :lo12:.LC27
	bl	printf
	mov	x1, 8
	adrp	x0, .LC28
	add	x0, x0, :lo12:.LC28
	bl	printf
	mov	x1, 0
	adrp	x0, .LC29
	add	x0, x0, :lo12:.LC29
	bl	printf
	mov	x1, 8
	adrp	x0, .LC30
	add	x0, x0, :lo12:.LC30
	bl	printf
	mov	x1, 72
	adrp	x0, .LC31
	add	x0, x0, :lo12:.LC31
	bl	printf
	mov	x1, 8
	adrp	x0, .LC32
	add	x0, x0, :lo12:.LC32
	bl	printf
	mov	x1, 0
	adrp	x0, .LC33
	add	x0, x0, :lo12:.LC33
	bl	printf
	mov	x1, 4
	adrp	x0, .LC34
	add	x0, x0, :lo12:.LC34
	bl	printf
	mov	x1, 8
	adrp	x0, .LC35
	add	x0, x0, :lo12:.LC35
	bl	printf
	mov	x1, 10
	adrp	x0, .LC36
	add	x0, x0, :lo12:.LC36
	bl	printf
	mov	x1, 30
	adrp	x0, .LC37
	add	x0, x0, :lo12:.LC37
	bl	printf
	mov	x1, 56
	adrp	x0, .LC38
	add	x0, x0, :lo12:.LC38
	bl	printf
	mov	x1, 64
	adrp	x0, .LC39
	add	x0, x0, :lo12:.LC39
	bl	printf
	mov	x1, 40
	adrp	x0, .LC40
	add	x0, x0, :lo12:.LC40
	bl	printf
	mov	x1, 8
	adrp	x0, .LC41
	add	x0, x0, :lo12:.LC41
	bl	printf
	mov	x1, 0
	adrp	x0, .LC42
	add	x0, x0, :lo12:.LC42
	bl	printf
	mov	x1, 4
	adrp	x0, .LC43
	add	x0, x0, :lo12:.LC43
	bl	printf
	mov	x1, 8
	adrp	x0, .LC44
	add	x0, x0, :lo12:.LC44
	bl	printf
	mov	x1, 16
	adrp	x0, .LC45
	add	x0, x0, :lo12:.LC45
	bl	printf
	mov	x1, 24
	adrp	x0, .LC46
	add	x0, x0, :lo12:.LC46
	bl	printf
	mov	x1, 8
	adrp	x0, .LC47
	add	x0, x0, :lo12:.LC47
	bl	printf
	mov	x1, 0
	adrp	x0, .LC48
	add	x0, x0, :lo12:.LC48
	bl	printf
	mov	x1, 8
	adrp	x0, .LC49
	add	x0, x0, :lo12:.LC49
	bl	printf
	mov	x1, 16
	adrp	x0, .LC50
	add	x0, x0, :lo12:.LC50
	bl	printf
	mov	x1, 4
	adrp	x0, .LC51
	add	x0, x0, :lo12:.LC51
	bl	printf
	mov	x1, 4
	adrp	x0, .LC52
	add	x0, x0, :lo12:.LC52
	bl	printf
	mov	x1, 0
	adrp	x0, .LC53
	add	x0, x0, :lo12:.LC53
	bl	printf
	mov	x1, 96
	adrp	x0, .LC54
	add	x0, x0, :lo12:.LC54
	bl	printf
	mov	x1, 8
	adrp	x0, .LC55
	add	x0, x0, :lo12:.LC55
	bl	printf
	mov	x1, 0
	adrp	x0, .LC56
	add	x0, x0, :lo12:.LC56
	bl	printf
	mov	x1, 4
	adrp	x0, .LC57
	add	x0, x0, :lo12:.LC57
	bl	printf
	mov	x1, 8
	adrp	x0, .LC58
	add	x0, x0, :lo12:.LC58
	bl	printf
	mov	x1, 24
	adrp	x0, .LC59
	add	x0, x0, :lo12:.LC59
	bl	printf
	mov	x1, 44
	adrp	x0, .LC60
	add	x0, x0, :lo12:.LC60
	bl	printf
	mov	x1, 76
	adrp	x0, .LC61
	add	x0, x0, :lo12:.LC61
	bl	printf
	mov	x1, 80
	adrp	x0, .LC62
	add	x0, x0, :lo12:.LC62
	bl	printf
	mov	x1, 88
	adrp	x0, .LC63
	add	x0, x0, :lo12:.LC63
	bl	printf
	mov	x1, 24
	adrp	x0, .LC64
	add	x0, x0, :lo12:.LC64
	bl	printf
	mov	x1, 8
	adrp	x0, .LC65
	add	x0, x0, :lo12:.LC65
	bl	printf
	mov	x1, 0
	adrp	x0, .LC66
	add	x0, x0, :lo12:.LC66
	bl	printf
	mov	x1, 8
	adrp	x0, .LC67
	add	x0, x0, :lo12:.LC67
	bl	printf
	mov	x1, 16
	adrp	x0, .LC68
	add	x0, x0, :lo12:.LC68
	bl	printf
	mov	x1, 144
	adrp	x0, .LC69
	add	x0, x0, :lo12:.LC69
	bl	printf
	mov	x1, 8
	adrp	x0, .LC70
	add	x0, x0, :lo12:.LC70
	bl	printf
	mov	x1, 0
	adrp	x0, .LC71
	add	x0, x0, :lo12:.LC71
	bl	printf
	mov	x1, 4
	adrp	x0, .LC72
	add	x0, x0, :lo12:.LC72
	bl	printf
	mov	x1, 8
	adrp	x0, .LC73
	add	x0, x0, :lo12:.LC73
	bl	printf
	mov	x1, 12
	adrp	x0, .LC74
	add	x0, x0, :lo12:.LC74
	bl	printf
	mov	x1, 16
	adrp	x0, .LC75
	add	x0, x0, :lo12:.LC75
	bl	printf
	mov	x1, 20
	adrp	x0, .LC76
	add	x0, x0, :lo12:.LC76
	bl	printf
	mov	x1, 24
	adrp	x0, .LC77
	add	x0, x0, :lo12:.LC77
	bl	printf
	mov	x1, 32
	adrp	x0, .LC78
	add	x0, x0, :lo12:.LC78
	bl	printf
	mov	x1, 40
	adrp	x0, .LC79
	add	x0, x0, :lo12:.LC79
	bl	printf
	mov	x1, 48
	adrp	x0, .LC80
	add	x0, x0, :lo12:.LC80
	bl	printf
	mov	x1, 56
	adrp	x0, .LC81
	add	x0, x0, :lo12:.LC81
	bl	printf
	mov	x1, 64
	adrp	x0, .LC82
	add	x0, x0, :lo12:.LC82
	bl	printf
	mov	x1, 80
	adrp	x0, .LC83
	add	x0, x0, :lo12:.LC83
	bl	printf
	mov	x1, 88
	adrp	x0, .LC84
	add	x0, x0, :lo12:.LC84
	bl	printf
	mov	x1, 96
	adrp	x0, .LC85
	add	x0, x0, :lo12:.LC85
	bl	printf
	mov	x1, 104
	adrp	x0, .LC86
	add	x0, x0, :lo12:.LC86
	bl	printf
	mov	x1, 112
	adrp	x0, .LC87
	add	x0, x0, :lo12:.LC87
	bl	printf
	mov	x1, 120
	adrp	x0, .LC88
	add	x0, x0, :lo12:.LC88
	bl	printf
	mov	x1, 128
	adrp	x0, .LC89
	add	x0, x0, :lo12:.LC89
	bl	printf
	mov	x1, 136
	adrp	x0, .LC90
	add	x0, x0, :lo12:.LC90
	bl	printf
	mov	x1, 24
	adrp	x0, .LC91
	add	x0, x0, :lo12:.LC91
	bl	printf
	mov	x1, 8
	adrp	x0, .LC92
	add	x0, x0, :lo12:.LC92
	bl	printf
	mov	x1, 0
	adrp	x0, .LC93
	add	x0, x0, :lo12:.LC93
	bl	printf
	mov	x1, 8
	adrp	x0, .LC94
	add	x0, x0, :lo12:.LC94
	bl	printf
	mov	x1, 16
	adrp	x0, .LC95
	add	x0, x0, :lo12:.LC95
	bl	printf
	mov	x1, 200
	adrp	x0, .LC96
	add	x0, x0, :lo12:.LC96
	bl	printf
	mov	x1, 8
	adrp	x0, .LC97
	add	x0, x0, :lo12:.LC97
	bl	printf
	mov	x1, 0
	adrp	x0, .LC98
	add	x0, x0, :lo12:.LC98
	bl	printf
	mov	x1, 4
	adrp	x0, .LC99
	add	x0, x0, :lo12:.LC99
	bl	printf
	mov	x1, 8
	adrp	x0, .LC100
	add	x0, x0, :lo12:.LC100
	bl	printf
	mov	x1, 56
	adrp	x0, .LC101
	add	x0, x0, :lo12:.LC101
	bl	printf
	mov	x1, 416
	adrp	x0, .LC102
	add	x0, x0, :lo12:.LC102
	bl	printf
	mov	x1, 8
	adrp	x0, .LC103
	add	x0, x0, :lo12:.LC103
	bl	printf
	mov	x1, 0
	adrp	x0, .LC104
	add	x0, x0, :lo12:.LC104
	bl	printf
	mov	x1, 8
	adrp	x0, .LC105
	add	x0, x0, :lo12:.LC105
	bl	printf
	mov	x1, 152
	adrp	x0, .LC106
	add	x0, x0, :lo12:.LC106
	bl	printf
	mov	x1, 368
	adrp	x0, .LC107
	add	x0, x0, :lo12:.LC107
	bl	printf
	mov	x1, 372
	adrp	x0, .LC108
	add	x0, x0, :lo12:.LC108
	bl	printf
	mov	x1, 376
	adrp	x0, .LC109
	add	x0, x0, :lo12:.LC109
	bl	printf
	mov	x1, 384
	adrp	x0, .LC110
	add	x0, x0, :lo12:.LC110
	bl	printf
	mov	x1, 392
	adrp	x0, .LC111
	add	x0, x0, :lo12:.LC111
	bl	printf
	mov	x1, 400
	adrp	x0, .LC112
	add	x0, x0, :lo12:.LC112
	bl	printf
	mov	x1, 408
	adrp	x0, .LC113
	add	x0, x0, :lo12:.LC113
	bl	printf
	mov	x1, 32
	adrp	x0, .LC114
	add	x0, x0, :lo12:.LC114
	bl	printf
	mov	x1, 8
	adrp	x0, .LC115
	add	x0, x0, :lo12:.LC115
	bl	printf
	mov	x1, 0
	adrp	x0, .LC116
	add	x0, x0, :lo12:.LC116
	bl	printf
	mov	x1, 8
	adrp	x0, .LC117
	add	x0, x0, :lo12:.LC117
	bl	printf
	mov	x1, 16
	adrp	x0, .LC118
	add	x0, x0, :lo12:.LC118
	bl	printf
	mov	x1, 24
	adrp	x0, .LC119
	add	x0, x0, :lo12:.LC119
	bl	printf
	mov	x1, 16
	adrp	x0, .LC120
	add	x0, x0, :lo12:.LC120
	bl	printf
	mov	x1, 8
	adrp	x0, .LC121
	add	x0, x0, :lo12:.LC121
	bl	printf
	mov	x1, 0
	adrp	x0, .LC122
	add	x0, x0, :lo12:.LC122
	bl	printf
	mov	x1, 8
	adrp	x0, .LC123
	add	x0, x0, :lo12:.LC123
	bl	printf
	mov	x1, 40
	adrp	x0, .LC124
	add	x0, x0, :lo12:.LC124
	bl	printf
	mov	x1, 8
	adrp	x0, .LC125
	add	x0, x0, :lo12:.LC125
	bl	printf
	mov	x1, 0
	adrp	x0, .LC126
	add	x0, x0, :lo12:.LC126
	bl	printf
	mov	x1, 8
	adrp	x0, .LC127
	add	x0, x0, :lo12:.LC127
	bl	printf
	mov	x1, 16
	adrp	x0, .LC128
	add	x0, x0, :lo12:.LC128
	bl	printf
	mov	x1, 24
	adrp	x0, .LC129
	add	x0, x0, :lo12:.LC129
	bl	printf
	mov	x1, 32
	adrp	x0, .LC130
	add	x0, x0, :lo12:.LC130
	bl	printf
	mov	x1, 36
	adrp	x0, .LC131
	add	x0, x0, :lo12:.LC131
	bl	printf
	mov	x1, 16
	adrp	x0, .LC132
	add	x0, x0, :lo12:.LC132
	bl	printf
	mov	x1, 8
	adrp	x0, .LC133
	add	x0, x0, :lo12:.LC133
	bl	printf
	mov	x1, 0
	adrp	x0, .LC134
	add	x0, x0, :lo12:.LC134
	bl	printf
	mov	x1, 8
	adrp	x0, .LC135
	add	x0, x0, :lo12:.LC135
	bl	printf
	mov	x1, 56
	adrp	x0, .LC136
	add	x0, x0, :lo12:.LC136
	bl	printf
	mov	x1, 8
	adrp	x0, .LC137
	add	x0, x0, :lo12:.LC137
	bl	printf
	mov	x1, 0
	adrp	x0, .LC138
	add	x0, x0, :lo12:.LC138
	bl	printf
	mov	x1, 16
	adrp	x0, .LC139
	add	x0, x0, :lo12:.LC139
	bl	printf
	mov	x1, 24
	adrp	x0, .LC140
	add	x0, x0, :lo12:.LC140
	bl	printf
	mov	x1, 32
	adrp	x0, .LC141
	add	x0, x0, :lo12:.LC141
	bl	printf
	mov	x1, 40
	adrp	x0, .LC142
	add	x0, x0, :lo12:.LC142
	bl	printf
	mov	x1, 48
	adrp	x0, .LC143
	add	x0, x0, :lo12:.LC143
	bl	printf
	mov	x1, 40
	adrp	x0, .LC144
	add	x0, x0, :lo12:.LC144
	bl	printf
	mov	x1, 8
	adrp	x0, .LC145
	add	x0, x0, :lo12:.LC145
	bl	printf
	mov	x1, 0
	adrp	x0, .LC146
	add	x0, x0, :lo12:.LC146
	bl	printf
	mov	x1, 16
	adrp	x0, .LC147
	add	x0, x0, :lo12:.LC147
	bl	printf
	mov	x1, 24
	adrp	x0, .LC148
	add	x0, x0, :lo12:.LC148
	bl	printf
	mov	x1, 32
	adrp	x0, .LC149
	add	x0, x0, :lo12:.LC149
	bl	printf
	mov	x1, 48
	adrp	x0, .LC150
	add	x0, x0, :lo12:.LC150
	bl	printf
	mov	x1, 8
	adrp	x0, .LC151
	add	x0, x0, :lo12:.LC151
	bl	printf
	mov	x1, 0
	adrp	x0, .LC152
	add	x0, x0, :lo12:.LC152
	bl	printf
	mov	x1, 16
	adrp	x0, .LC153
	add	x0, x0, :lo12:.LC153
	bl	printf
	mov	x1, 24
	adrp	x0, .LC154
	add	x0, x0, :lo12:.LC154
	bl	printf
	mov	x1, 32
	adrp	x0, .LC155
	add	x0, x0, :lo12:.LC155
	bl	printf
	mov	x1, 40
	adrp	x0, .LC156
	add	x0, x0, :lo12:.LC156
	bl	printf
	mov	x1, 24
	adrp	x0, .LC157
	add	x0, x0, :lo12:.LC157
	bl	printf
	mov	x1, 8
	adrp	x0, .LC158
	add	x0, x0, :lo12:.LC158
	bl	printf
	mov	x1, 0
	adrp	x0, .LC159
	add	x0, x0, :lo12:.LC159
	bl	printf
	mov	x1, 16
	adrp	x0, .LC160
	add	x0, x0, :lo12:.LC160
	bl	printf
	mov	x1, 16
	adrp	x0, .LC161
	add	x0, x0, :lo12:.LC161
	bl	printf
	mov	x1, 8
	adrp	x0, .LC162
	add	x0, x0, :lo12:.LC162
	bl	printf
	mov	x1, 0
	adrp	x0, .LC163
	add	x0, x0, :lo12:.LC163
	bl	printf
	mov	x1, 8
	adrp	x0, .LC164
	add	x0, x0, :lo12:.LC164
	bl	printf
	mov	x1, 32
	adrp	x0, .LC165
	add	x0, x0, :lo12:.LC165
	bl	printf
	mov	x1, 8
	adrp	x0, .LC166
	add	x0, x0, :lo12:.LC166
	bl	printf
	mov	x1, 0
	adrp	x0, .LC167
	add	x0, x0, :lo12:.LC167
	bl	printf
	mov	x1, 16
	adrp	x0, .LC168
	add	x0, x0, :lo12:.LC168
	bl	printf
	mov	x1, 24
	adrp	x0, .LC169
	add	x0, x0, :lo12:.LC169
	bl	printf
	mov	x1, 24
	adrp	x0, .LC170
	add	x0, x0, :lo12:.LC170
	bl	printf
	mov	x1, 8
	adrp	x0, .LC171
	add	x0, x0, :lo12:.LC171
	bl	printf
	mov	x1, 0
	adrp	x0, .LC172
	add	x0, x0, :lo12:.LC172
	bl	printf
	mov	x1, 8
	adrp	x0, .LC173
	add	x0, x0, :lo12:.LC173
	bl	printf
	mov	x1, 16
	adrp	x0, .LC174
	add	x0, x0, :lo12:.LC174
	bl	printf
	mov	x1, 24
	adrp	x0, .LC175
	add	x0, x0, :lo12:.LC175
	bl	printf
	mov	x1, 8
	adrp	x0, .LC176
	add	x0, x0, :lo12:.LC176
	bl	printf
	mov	x1, 0
	adrp	x0, .LC177
	add	x0, x0, :lo12:.LC177
	bl	printf
	mov	x1, 4
	adrp	x0, .LC178
	add	x0, x0, :lo12:.LC178
	bl	printf
	mov	x1, 8
	adrp	x0, .LC179
	add	x0, x0, :lo12:.LC179
	bl	printf
	mov	x1, 16
	adrp	x0, .LC180
	add	x0, x0, :lo12:.LC180
	bl	printf
	mov	x1, 32
	adrp	x0, .LC181
	add	x0, x0, :lo12:.LC181
	bl	printf
	mov	x1, 8
	adrp	x0, .LC182
	add	x0, x0, :lo12:.LC182
	bl	printf
	mov	x1, 0
	adrp	x0, .LC183
	add	x0, x0, :lo12:.LC183
	bl	printf
	mov	x1, 4
	adrp	x0, .LC184
	add	x0, x0, :lo12:.LC184
	bl	printf
	mov	x1, 8
	adrp	x0, .LC185
	add	x0, x0, :lo12:.LC185
	bl	printf
	mov	x1, 16
	adrp	x0, .LC186
	add	x0, x0, :lo12:.LC186
	bl	printf
	mov	x1, 24
	adrp	x0, .LC187
	add	x0, x0, :lo12:.LC187
	bl	printf
	mov	x1, 28
	adrp	x0, .LC188
	add	x0, x0, :lo12:.LC188
	bl	printf
	mov	x1, 72
	adrp	x0, .LC189
	add	x0, x0, :lo12:.LC189
	bl	printf
	mov	x1, 8
	adrp	x0, .LC190
	add	x0, x0, :lo12:.LC190
	bl	printf
	mov	x1, 0
	adrp	x0, .LC191
	add	x0, x0, :lo12:.LC191
	bl	printf
	mov	x1, 8
	adrp	x0, .LC192
	add	x0, x0, :lo12:.LC192
	bl	printf
	mov	x1, 40
	adrp	x0, .LC193
	add	x0, x0, :lo12:.LC193
	bl	printf
	mov	x1, 32
	adrp	x0, .LC194
	add	x0, x0, :lo12:.LC194
	bl	printf
	mov	x1, 8
	adrp	x0, .LC195
	add	x0, x0, :lo12:.LC195
	bl	printf
	mov	x1, 0
	adrp	x0, .LC196
	add	x0, x0, :lo12:.LC196
	bl	printf
	mov	x1, 8
	adrp	x0, .LC197
	add	x0, x0, :lo12:.LC197
	bl	printf
	mov	x1, 16
	adrp	x0, .LC198
	add	x0, x0, :lo12:.LC198
	bl	printf
	mov	x1, 24
	adrp	x0, .LC199
	add	x0, x0, :lo12:.LC199
	bl	printf
	mov	x1, 112
	adrp	x0, .LC200
	add	x0, x0, :lo12:.LC200
	bl	printf
	mov	x1, 8
	adrp	x0, .LC201
	add	x0, x0, :lo12:.LC201
	bl	printf
	mov	x1, 0
	adrp	x0, .LC202
	add	x0, x0, :lo12:.LC202
	bl	printf
	mov	x1, 4
	adrp	x0, .LC203
	add	x0, x0, :lo12:.LC203
	bl	printf
	mov	x1, 8
	adrp	x0, .LC204
	add	x0, x0, :lo12:.LC204
	bl	printf
	mov	x1, 10
	adrp	x0, .LC205
	add	x0, x0, :lo12:.LC205
	bl	printf
	mov	x1, 16
	adrp	x0, .LC206
	add	x0, x0, :lo12:.LC206
	bl	printf
	mov	x1, 64
	adrp	x0, .LC207
	add	x0, x0, :lo12:.LC207
	bl	printf
	mov	x1, 48
	adrp	x0, .LC208
	add	x0, x0, :lo12:.LC208
	bl	printf
	mov	x1, 8
	adrp	x0, .LC209
	add	x0, x0, :lo12:.LC209
	bl	printf
	mov	x1, 0
	adrp	x0, .LC210
	add	x0, x0, :lo12:.LC210
	bl	printf
	mov	x1, 24
	adrp	x0, .LC211
	add	x0, x0, :lo12:.LC211
	bl	printf
	mov	x1, 32
	adrp	x0, .LC212
	add	x0, x0, :lo12:.LC212
	bl	printf
	mov	x1, 40
	adrp	x0, .LC213
	add	x0, x0, :lo12:.LC213
	bl	printf
	mov	x1, 44
	adrp	x0, .LC214
	add	x0, x0, :lo12:.LC214
	bl	printf
	mov	x1, 46
	adrp	x0, .LC215
	add	x0, x0, :lo12:.LC215
	bl	printf
	mov	x1, 32
	adrp	x0, .LC216
	add	x0, x0, :lo12:.LC216
	bl	printf
	mov	x1, 8
	adrp	x0, .LC217
	add	x0, x0, :lo12:.LC217
	bl	printf
	mov	x1, 0
	adrp	x0, .LC218
	add	x0, x0, :lo12:.LC218
	bl	printf
	mov	x1, 4
	adrp	x0, .LC219
	add	x0, x0, :lo12:.LC219
	bl	printf
	mov	x1, 8
	adrp	x0, .LC220
	add	x0, x0, :lo12:.LC220
	bl	printf
	mov	x1, 10
	adrp	x0, .LC221
	add	x0, x0, :lo12:.LC221
	bl	printf
	mov	x1, 12
	adrp	x0, .LC222
	add	x0, x0, :lo12:.LC222
	bl	printf
	mov	x1, 14
	adrp	x0, .LC223
	add	x0, x0, :lo12:.LC223
	bl	printf
	mov	x1, 16
	adrp	x0, .LC224
	add	x0, x0, :lo12:.LC224
	bl	printf
	mov	x1, 24
	adrp	x0, .LC225
	add	x0, x0, :lo12:.LC225
	bl	printf
	mov	x1, 56
	adrp	x0, .LC226
	add	x0, x0, :lo12:.LC226
	bl	printf
	mov	x1, 8
	adrp	x0, .LC227
	add	x0, x0, :lo12:.LC227
	bl	printf
	mov	x1, 0
	adrp	x0, .LC228
	add	x0, x0, :lo12:.LC228
	bl	printf
	mov	x1, 4
	adrp	x0, .LC229
	add	x0, x0, :lo12:.LC229
	bl	printf
	mov	x1, 8
	adrp	x0, .LC230
	add	x0, x0, :lo12:.LC230
	bl	printf
	mov	x1, 16
	adrp	x0, .LC231
	add	x0, x0, :lo12:.LC231
	bl	printf
	mov	x1, 24
	adrp	x0, .LC232
	add	x0, x0, :lo12:.LC232
	bl	printf
	mov	x1, 32
	adrp	x0, .LC233
	add	x0, x0, :lo12:.LC233
	bl	printf
	mov	x1, 40
	adrp	x0, .LC234
	add	x0, x0, :lo12:.LC234
	bl	printf
	mov	x1, 48
	adrp	x0, .LC235
	add	x0, x0, :lo12:.LC235
	bl	printf
	mov	x1, 152
	adrp	x0, .LC236
	add	x0, x0, :lo12:.LC236
	bl	printf
	mov	x1, 8
	adrp	x0, .LC237
	add	x0, x0, :lo12:.LC237
	bl	printf
	mov	x1, 0
	adrp	x0, .LC238
	add	x0, x0, :lo12:.LC238
	bl	printf
	mov	x1, 4
	adrp	x0, .LC239
	add	x0, x0, :lo12:.LC239
	bl	printf
	mov	x1, 8
	adrp	x0, .LC240
	add	x0, x0, :lo12:.LC240
	bl	printf
	mov	x1, 12
	adrp	x0, .LC241
	add	x0, x0, :lo12:.LC241
	bl	printf
	mov	x1, 16
	adrp	x0, .LC242
	add	x0, x0, :lo12:.LC242
	bl	printf
	mov	x1, 24
	adrp	x0, .LC243
	add	x0, x0, :lo12:.LC243
	bl	printf
	mov	x1, 40
	adrp	x0, .LC244
	add	x0, x0, :lo12:.LC244
	bl	printf
	mov	x1, 8
	adrp	x0, .LC245
	add	x0, x0, :lo12:.LC245
	bl	printf
	mov	x1, 0
	adrp	x0, .LC246
	add	x0, x0, :lo12:.LC246
	bl	printf
	mov	x1, 4
	adrp	x0, .LC247
	add	x0, x0, :lo12:.LC247
	bl	printf
	mov	x1, 8
	adrp	x0, .LC248
	add	x0, x0, :lo12:.LC248
	bl	printf
	mov	x1, 12
	adrp	x0, .LC249
	add	x0, x0, :lo12:.LC249
	bl	printf
	mov	x1, 16
	adrp	x0, .LC250
	add	x0, x0, :lo12:.LC250
	bl	printf
	mov	x1, 24
	adrp	x0, .LC251
	add	x0, x0, :lo12:.LC251
	bl	printf
	mov	x1, 32
	adrp	x0, .LC252
	add	x0, x0, :lo12:.LC252
	bl	printf
	mov	x1, 96
	adrp	x0, .LC253
	add	x0, x0, :lo12:.LC253
	bl	printf
	mov	x1, 8
	adrp	x0, .LC254
	add	x0, x0, :lo12:.LC254
	bl	printf
	mov	x1, 0
	adrp	x0, .LC255
	add	x0, x0, :lo12:.LC255
	bl	printf
	mov	x1, 4
	adrp	x0, .LC256
	add	x0, x0, :lo12:.LC256
	bl	printf
	mov	x1, 8
	adrp	x0, .LC257
	add	x0, x0, :lo12:.LC257
	bl	printf
	mov	x1, 16
	adrp	x0, .LC258
	add	x0, x0, :lo12:.LC258
	bl	printf
	mov	x1, 32
	adrp	x0, .LC259
	add	x0, x0, :lo12:.LC259
	bl	printf
	mov	x1, 40
	adrp	x0, .LC260
	add	x0, x0, :lo12:.LC260
	bl	printf
	mov	x1, 48
	adrp	x0, .LC261
	add	x0, x0, :lo12:.LC261
	bl	printf
	mov	x1, 56
	adrp	x0, .LC262
	add	x0, x0, :lo12:.LC262
	bl	printf
	mov	x1, 60
	adrp	x0, .LC263
	add	x0, x0, :lo12:.LC263
	bl	printf
	mov	x1, 64
	adrp	x0, .LC264
	add	x0, x0, :lo12:.LC264
	bl	printf
	mov	x1, 68
	adrp	x0, .LC265
	add	x0, x0, :lo12:.LC265
	bl	printf
	mov	x1, 72
	adrp	x0, .LC266
	add	x0, x0, :lo12:.LC266
	bl	printf
	mov	x1, 80
	adrp	x0, .LC267
	add	x0, x0, :lo12:.LC267
	bl	printf
	mov	x1, 88
	adrp	x0, .LC268
	add	x0, x0, :lo12:.LC268
	bl	printf
	mov	x1, 8
	adrp	x0, .LC269
	add	x0, x0, :lo12:.LC269
	bl	printf
	mov	x1, 4
	adrp	x0, .LC270
	add	x0, x0, :lo12:.LC270
	bl	printf
	mov	x1, 0
	adrp	x0, .LC271
	add	x0, x0, :lo12:.LC271
	bl	printf
	mov	x1, 4
	adrp	x0, .LC272
	add	x0, x0, :lo12:.LC272
	bl	printf
	mov	x1, 4
	adrp	x0, .LC273
	add	x0, x0, :lo12:.LC273
	bl	printf
	mov	x1, 4
	adrp	x0, .LC274
	add	x0, x0, :lo12:.LC274
	bl	printf
	mov	x1, 0
	adrp	x0, .LC275
	add	x0, x0, :lo12:.LC275
	bl	printf
	mov	x1, 40
	adrp	x0, .LC276
	add	x0, x0, :lo12:.LC276
	bl	printf
	mov	x1, 8
	adrp	x0, .LC277
	add	x0, x0, :lo12:.LC277
	bl	printf
	mov	x1, 0
	adrp	x0, .LC278
	add	x0, x0, :lo12:.LC278
	bl	printf
	mov	x1, 8
	adrp	x0, .LC279
	add	x0, x0, :lo12:.LC279
	bl	printf
	mov	x1, 16
	adrp	x0, .LC280
	add	x0, x0, :lo12:.LC280
	bl	printf
	mov	x1, 24
	adrp	x0, .LC281
	add	x0, x0, :lo12:.LC281
	bl	printf
	mov	x1, 32
	adrp	x0, .LC282
	add	x0, x0, :lo12:.LC282
	bl	printf
	mov	x1, 160
	adrp	x0, .LC283
	add	x0, x0, :lo12:.LC283
	bl	printf
	mov	x1, 8
	adrp	x0, .LC284
	add	x0, x0, :lo12:.LC284
	bl	printf
	mov	x1, 0
	adrp	x0, .LC285
	add	x0, x0, :lo12:.LC285
	bl	printf
	mov	x1, 4
	adrp	x0, .LC286
	add	x0, x0, :lo12:.LC286
	bl	printf
	mov	x1, 8
	adrp	x0, .LC287
	add	x0, x0, :lo12:.LC287
	bl	printf
	mov	x1, 104
	adrp	x0, .LC288
	add	x0, x0, :lo12:.LC288
	bl	printf
	mov	x1, 136
	adrp	x0, .LC289
	add	x0, x0, :lo12:.LC289
	bl	printf
	mov	x1, 144
	adrp	x0, .LC290
	add	x0, x0, :lo12:.LC290
	bl	printf
	mov	x1, 152
	adrp	x0, .LC291
	add	x0, x0, :lo12:.LC291
	bl	printf
	mov	x1, 16
	adrp	x0, .LC292
	add	x0, x0, :lo12:.LC292
	bl	printf
	mov	x1, 8
	adrp	x0, .LC293
	add	x0, x0, :lo12:.LC293
	bl	printf
	mov	x1, 0
	adrp	x0, .LC294
	add	x0, x0, :lo12:.LC294
	bl	printf
	mov	x1, 8
	adrp	x0, .LC295
	add	x0, x0, :lo12:.LC295
	bl	printf
	mov	x1, 216
	adrp	x0, .LC296
	add	x0, x0, :lo12:.LC296
	bl	printf
	mov	x1, 8
	adrp	x0, .LC297
	add	x0, x0, :lo12:.LC297
	bl	printf
	mov	x1, 0
	adrp	x0, .LC298
	add	x0, x0, :lo12:.LC298
	bl	printf
	mov	x1, 8
	adrp	x0, .LC299
	add	x0, x0, :lo12:.LC299
	bl	printf
	mov	x1, 136
	adrp	x0, .LC300
	add	x0, x0, :lo12:.LC300
	bl	printf
	mov	x1, 140
	adrp	x0, .LC301
	add	x0, x0, :lo12:.LC301
	bl	printf
	mov	x1, 144
	adrp	x0, .LC302
	add	x0, x0, :lo12:.LC302
	bl	printf
	mov	x1, 152
	adrp	x0, .LC303
	add	x0, x0, :lo12:.LC303
	bl	printf
	mov	x1, 192
	adrp	x0, .LC304
	add	x0, x0, :lo12:.LC304
	bl	printf
	mov	x1, 196
	adrp	x0, .LC305
	add	x0, x0, :lo12:.LC305
	bl	printf
	mov	x1, 200
	adrp	x0, .LC306
	add	x0, x0, :lo12:.LC306
	bl	printf
	mov	x1, 40
	adrp	x0, .LC307
	add	x0, x0, :lo12:.LC307
	bl	printf
	mov	x1, 8
	adrp	x0, .LC308
	add	x0, x0, :lo12:.LC308
	bl	printf
	mov	x1, 0
	adrp	x0, .LC309
	add	x0, x0, :lo12:.LC309
	bl	printf
	mov	x1, 4
	adrp	x0, .LC310
	add	x0, x0, :lo12:.LC310
	bl	printf
	mov	x1, 8
	adrp	x0, .LC311
	add	x0, x0, :lo12:.LC311
	bl	printf
	mov	x1, 16
	adrp	x0, .LC312
	add	x0, x0, :lo12:.LC312
	bl	printf
	mov	x1, 72
	adrp	x0, .LC313
	add	x0, x0, :lo12:.LC313
	bl	printf
	mov	x1, 8
	adrp	x0, .LC314
	add	x0, x0, :lo12:.LC314
	bl	printf
	mov	x1, 0
	adrp	x0, .LC315
	add	x0, x0, :lo12:.LC315
	bl	printf
	mov	x1, 8
	adrp	x0, .LC316
	add	x0, x0, :lo12:.LC316
	bl	printf
	mov	x1, 16
	adrp	x0, .LC317
	add	x0, x0, :lo12:.LC317
	bl	printf
	mov	x1, 20
	adrp	x0, .LC318
	add	x0, x0, :lo12:.LC318
	bl	printf
	mov	x1, 24
	adrp	x0, .LC319
	add	x0, x0, :lo12:.LC319
	bl	printf
	mov	x1, 28
	adrp	x0, .LC320
	add	x0, x0, :lo12:.LC320
	bl	printf
	mov	x1, 32
	adrp	x0, .LC321
	add	x0, x0, :lo12:.LC321
	bl	printf
	mov	x1, 36
	adrp	x0, .LC322
	add	x0, x0, :lo12:.LC322
	bl	printf
	mov	x1, 40
	adrp	x0, .LC323
	add	x0, x0, :lo12:.LC323
	bl	printf
	mov	x1, 60
	adrp	x0, .LC324
	add	x0, x0, :lo12:.LC324
	bl	printf
	mov	x1, 62
	adrp	x0, .LC325
	add	x0, x0, :lo12:.LC325
	bl	printf
	mov	x1, 64
	adrp	x0, .LC326
	add	x0, x0, :lo12:.LC326
	bl	printf
	mov	x1, 8
	adrp	x0, .LC327
	add	x0, x0, :lo12:.LC327
	bl	printf
	mov	x1, 4
	adrp	x0, .LC328
	add	x0, x0, :lo12:.LC328
	bl	printf
	mov	x1, 0
	adrp	x0, .LC329
	add	x0, x0, :lo12:.LC329
	bl	printf
	mov	x1, 4
	adrp	x0, .LC330
	add	x0, x0, :lo12:.LC330
	bl	printf
	mov	x1, 32
	adrp	x0, .LC331
	add	x0, x0, :lo12:.LC331
	bl	printf
	mov	x1, 8
	adrp	x0, .LC332
	add	x0, x0, :lo12:.LC332
	bl	printf
	mov	x1, 0
	adrp	x0, .LC333
	add	x0, x0, :lo12:.LC333
	bl	printf
	mov	x1, 8
	adrp	x0, .LC334
	add	x0, x0, :lo12:.LC334
	bl	printf
	mov	x1, 16
	adrp	x0, .LC335
	add	x0, x0, :lo12:.LC335
	bl	printf
	mov	x1, 24
	adrp	x0, .LC336
	add	x0, x0, :lo12:.LC336
	bl	printf
	mov	x1, 32
	adrp	x0, .LC337
	add	x0, x0, :lo12:.LC337
	bl	printf
	mov	x1, 8
	adrp	x0, .LC338
	add	x0, x0, :lo12:.LC338
	bl	printf
	mov	x1, 0
	adrp	x0, .LC339
	add	x0, x0, :lo12:.LC339
	bl	printf
	mov	x1, 4
	adrp	x0, .LC340
	add	x0, x0, :lo12:.LC340
	bl	printf
	mov	x1, 8
	adrp	x0, .LC341
	add	x0, x0, :lo12:.LC341
	bl	printf
	mov	x1, 12
	adrp	x0, .LC342
	add	x0, x0, :lo12:.LC342
	bl	printf
	mov	x1, 16
	adrp	x0, .LC343
	add	x0, x0, :lo12:.LC343
	bl	printf
	mov	x1, 20
	adrp	x0, .LC344
	add	x0, x0, :lo12:.LC344
	bl	printf
	mov	x1, 24
	adrp	x0, .LC345
	add	x0, x0, :lo12:.LC345
	bl	printf
	mov	x1, 40
	adrp	x0, .LC346
	add	x0, x0, :lo12:.LC346
	bl	printf
	mov	x1, 8
	adrp	x0, .LC347
	add	x0, x0, :lo12:.LC347
	bl	printf
	mov	x1, 0
	adrp	x0, .LC348
	add	x0, x0, :lo12:.LC348
	bl	printf
	mov	x1, 8
	adrp	x0, .LC349
	add	x0, x0, :lo12:.LC349
	bl	printf
	mov	x1, 16
	adrp	x0, .LC350
	add	x0, x0, :lo12:.LC350
	bl	printf
	mov	x1, 24
	adrp	x0, .LC351
	add	x0, x0, :lo12:.LC351
	bl	printf
	mov	x1, 32
	adrp	x0, .LC352
	add	x0, x0, :lo12:.LC352
	bl	printf
	mov	x1, 48
	adrp	x0, .LC353
	add	x0, x0, :lo12:.LC353
	bl	printf
	mov	x1, 8
	adrp	x0, .LC354
	add	x0, x0, :lo12:.LC354
	bl	printf
	mov	x1, 0
	adrp	x0, .LC355
	add	x0, x0, :lo12:.LC355
	bl	printf
	mov	x1, 8
	adrp	x0, .LC356
	add	x0, x0, :lo12:.LC356
	bl	printf
	mov	x1, 16
	adrp	x0, .LC357
	add	x0, x0, :lo12:.LC357
	bl	printf
	mov	x1, 24
	adrp	x0, .LC358
	add	x0, x0, :lo12:.LC358
	bl	printf
	mov	x1, 32
	adrp	x0, .LC359
	add	x0, x0, :lo12:.LC359
	bl	printf
	mov	x1, 36
	adrp	x0, .LC360
	add	x0, x0, :lo12:.LC360
	bl	printf
	mov	x1, 40
	adrp	x0, .LC361
	add	x0, x0, :lo12:.LC361
	bl	printf
	mov	x1, 40
	adrp	x0, .LC362
	add	x0, x0, :lo12:.LC362
	bl	printf
	mov	x1, 8
	adrp	x0, .LC363
	add	x0, x0, :lo12:.LC363
	bl	printf
	mov	x1, 0
	adrp	x0, .LC364
	add	x0, x0, :lo12:.LC364
	bl	printf
	mov	x1, 8
	adrp	x0, .LC365
	add	x0, x0, :lo12:.LC365
	bl	printf
	mov	x1, 16
	adrp	x0, .LC366
	add	x0, x0, :lo12:.LC366
	bl	printf
	mov	x1, 24
	adrp	x0, .LC367
	add	x0, x0, :lo12:.LC367
	bl	printf
	mov	x1, 32
	adrp	x0, .LC368
	add	x0, x0, :lo12:.LC368
	bl	printf
	mov	x1, 48
	adrp	x0, .LC369
	add	x0, x0, :lo12:.LC369
	bl	printf
	mov	x1, 8
	adrp	x0, .LC370
	add	x0, x0, :lo12:.LC370
	bl	printf
	mov	x1, 0
	adrp	x0, .LC371
	add	x0, x0, :lo12:.LC371
	bl	printf
	mov	x1, 4
	adrp	x0, .LC372
	add	x0, x0, :lo12:.LC372
	bl	printf
	mov	x1, 8
	adrp	x0, .LC373
	add	x0, x0, :lo12:.LC373
	bl	printf
	mov	x1, 12
	adrp	x0, .LC374
	add	x0, x0, :lo12:.LC374
	bl	printf
	mov	x1, 16
	adrp	x0, .LC375
	add	x0, x0, :lo12:.LC375
	bl	printf
	mov	x1, 24
	adrp	x0, .LC376
	add	x0, x0, :lo12:.LC376
	bl	printf
	mov	x1, 32
	adrp	x0, .LC377
	add	x0, x0, :lo12:.LC377
	bl	printf
	mov	x1, 40
	adrp	x0, .LC378
	add	x0, x0, :lo12:.LC378
	bl	printf
	mov	x1, 44
	adrp	x0, .LC379
	add	x0, x0, :lo12:.LC379
	bl	printf
	mov	x1, 16
	adrp	x0, .LC380
	add	x0, x0, :lo12:.LC380
	bl	printf
	mov	x1, 8
	adrp	x0, .LC381
	add	x0, x0, :lo12:.LC381
	bl	printf
	mov	x1, 0
	adrp	x0, .LC382
	add	x0, x0, :lo12:.LC382
	bl	printf
	mov	x1, 8
	adrp	x0, .LC383
	add	x0, x0, :lo12:.LC383
	bl	printf
	mov	x1, 24
	adrp	x0, .LC384
	add	x0, x0, :lo12:.LC384
	bl	printf
	mov	x1, 8
	adrp	x0, .LC385
	add	x0, x0, :lo12:.LC385
	bl	printf
	mov	x1, 0
	adrp	x0, .LC386
	add	x0, x0, :lo12:.LC386
	bl	printf
	mov	x1, 8
	adrp	x0, .LC387
	add	x0, x0, :lo12:.LC387
	bl	printf
	mov	x1, 16
	adrp	x0, .LC388
	add	x0, x0, :lo12:.LC388
	bl	printf
	mov	x1, 24
	adrp	x0, .LC389
	add	x0, x0, :lo12:.LC389
	bl	printf
	mov	x1, 4
	adrp	x0, .LC390
	add	x0, x0, :lo12:.LC390
	bl	printf
	mov	x1, 0
	adrp	x0, .LC391
	add	x0, x0, :lo12:.LC391
	bl	printf
	mov	x1, 4
	adrp	x0, .LC392
	add	x0, x0, :lo12:.LC392
	bl	printf
	mov	x1, 8
	adrp	x0, .LC393
	add	x0, x0, :lo12:.LC393
	bl	printf
	mov	x1, 12
	adrp	x0, .LC394
	add	x0, x0, :lo12:.LC394
	bl	printf
	mov	x1, 16
	adrp	x0, .LC395
	add	x0, x0, :lo12:.LC395
	bl	printf
	mov	x1, 20
	adrp	x0, .LC396
	add	x0, x0, :lo12:.LC396
	bl	printf
	mov	x1, 8
	adrp	x0, .LC397
	add	x0, x0, :lo12:.LC397
	bl	printf
	mov	x1, 4
	adrp	x0, .LC398
	add	x0, x0, :lo12:.LC398
	bl	printf
	mov	x1, 0
	adrp	x0, .LC399
	add	x0, x0, :lo12:.LC399
	bl	printf
	mov	x1, 4
	adrp	x0, .LC400
	add	x0, x0, :lo12:.LC400
	bl	printf
	mov	x1, 28
	adrp	x0, .LC401
	add	x0, x0, :lo12:.LC401
	bl	printf
	mov	x1, 4
	adrp	x0, .LC402
	add	x0, x0, :lo12:.LC402
	bl	printf
	mov	x1, 0
	adrp	x0, .LC403
	add	x0, x0, :lo12:.LC403
	bl	printf
	mov	x1, 20
	adrp	x0, .LC404
	add	x0, x0, :lo12:.LC404
	bl	printf
	mov	x1, 24
	adrp	x0, .LC405
	add	x0, x0, :lo12:.LC405
	bl	printf
	mov	x1, 8
	adrp	x0, .LC406
	add	x0, x0, :lo12:.LC406
	bl	printf
	mov	x1, 4
	adrp	x0, .LC407
	add	x0, x0, :lo12:.LC407
	bl	printf
	mov	x1, 0
	adrp	x0, .LC408
	add	x0, x0, :lo12:.LC408
	bl	printf
	mov	x1, 4
	adrp	x0, .LC409
	add	x0, x0, :lo12:.LC409
	bl	printf
	mov	x1, 72
	adrp	x0, .LC410
	add	x0, x0, :lo12:.LC410
	bl	printf
	mov	x1, 8
	adrp	x0, .LC411
	add	x0, x0, :lo12:.LC411
	bl	printf
	mov	x1, 0
	adrp	x0, .LC412
	add	x0, x0, :lo12:.LC412
	bl	printf
	mov	x1, 8
	adrp	x0, .LC413
	add	x0, x0, :lo12:.LC413
	bl	printf
	mov	x1, 16
	adrp	x0, .LC414
	add	x0, x0, :lo12:.LC414
	bl	printf
	mov	x1, 24
	adrp	x0, .LC415
	add	x0, x0, :lo12:.LC415
	bl	printf
	mov	x1, 32
	adrp	x0, .LC416
	add	x0, x0, :lo12:.LC416
	bl	printf
	mov	x1, 40
	adrp	x0, .LC417
	add	x0, x0, :lo12:.LC417
	bl	printf
	mov	x1, 48
	adrp	x0, .LC418
	add	x0, x0, :lo12:.LC418
	bl	printf
	mov	x1, 56
	adrp	x0, .LC419
	add	x0, x0, :lo12:.LC419
	bl	printf
	mov	x1, 64
	adrp	x0, .LC420
	add	x0, x0, :lo12:.LC420
	bl	printf
	mov	x1, 32
	adrp	x0, .LC421
	add	x0, x0, :lo12:.LC421
	bl	printf
	mov	x1, 8
	adrp	x0, .LC422
	add	x0, x0, :lo12:.LC422
	bl	printf
	mov	x1, 0
	adrp	x0, .LC423
	add	x0, x0, :lo12:.LC423
	bl	printf
	mov	x1, 8
	adrp	x0, .LC424
	add	x0, x0, :lo12:.LC424
	bl	printf
	mov	x1, 16
	adrp	x0, .LC425
	add	x0, x0, :lo12:.LC425
	bl	printf
	mov	x1, 24
	adrp	x0, .LC426
	add	x0, x0, :lo12:.LC426
	bl	printf
	mov	x1, 20
	adrp	x0, .LC427
	add	x0, x0, :lo12:.LC427
	bl	printf
	mov	x1, 1
	adrp	x0, .LC428
	add	x0, x0, :lo12:.LC428
	bl	printf
	mov	x1, 0
	adrp	x0, .LC429
	add	x0, x0, :lo12:.LC429
	bl	printf
	mov	x1, 16
	adrp	x0, .LC430
	add	x0, x0, :lo12:.LC430
	bl	printf
	mov	x1, 8
	adrp	x0, .LC431
	add	x0, x0, :lo12:.LC431
	bl	printf
	mov	x1, 0
	adrp	x0, .LC432
	add	x0, x0, :lo12:.LC432
	bl	printf
	mov	x1, 8
	adrp	x0, .LC433
	add	x0, x0, :lo12:.LC433
	bl	printf
	mov	x1, 40
	adrp	x0, .LC434
	add	x0, x0, :lo12:.LC434
	bl	printf
	mov	x1, 8
	adrp	x0, .LC435
	add	x0, x0, :lo12:.LC435
	bl	printf
	mov	x1, 0
	adrp	x0, .LC436
	add	x0, x0, :lo12:.LC436
	bl	printf
	mov	x1, 4
	adrp	x0, .LC437
	add	x0, x0, :lo12:.LC437
	bl	printf
	mov	x1, 8
	adrp	x0, .LC438
	add	x0, x0, :lo12:.LC438
	bl	printf
	mov	x1, 16
	adrp	x0, .LC439
	add	x0, x0, :lo12:.LC439
	bl	printf
	mov	x1, 24
	adrp	x0, .LC440
	add	x0, x0, :lo12:.LC440
	bl	printf
	mov	x1, 32
	adrp	x0, .LC441
	add	x0, x0, :lo12:.LC441
	bl	printf
	mov	x1, 216
	adrp	x0, .LC442
	add	x0, x0, :lo12:.LC442
	bl	printf
	mov	x1, 8
	adrp	x0, .LC443
	add	x0, x0, :lo12:.LC443
	bl	printf
	mov	x1, 0
	adrp	x0, .LC444
	add	x0, x0, :lo12:.LC444
	bl	printf
	mov	x1, 4
	adrp	x0, .LC445
	add	x0, x0, :lo12:.LC445
	bl	printf
	mov	x1, 8
	adrp	x0, .LC446
	add	x0, x0, :lo12:.LC446
	bl	printf
	mov	x1, 136
	adrp	x0, .LC447
	add	x0, x0, :lo12:.LC447
	bl	printf
	mov	x1, 176
	adrp	x0, .LC448
	add	x0, x0, :lo12:.LC448
	bl	printf
	mov	x1, 184
	adrp	x0, .LC449
	add	x0, x0, :lo12:.LC449
	bl	printf
	mov	x1, 200
	adrp	x0, .LC450
	add	x0, x0, :lo12:.LC450
	bl	printf
	mov	x1, 56
	adrp	x0, .LC451
	add	x0, x0, :lo12:.LC451
	bl	printf
	mov	x1, 8
	adrp	x0, .LC452
	add	x0, x0, :lo12:.LC452
	bl	printf
	mov	x1, 0
	adrp	x0, .LC453
	add	x0, x0, :lo12:.LC453
	bl	printf
	mov	x1, 8
	adrp	x0, .LC454
	add	x0, x0, :lo12:.LC454
	bl	printf
	mov	x1, 16
	adrp	x0, .LC455
	add	x0, x0, :lo12:.LC455
	bl	printf
	mov	x1, 36
	adrp	x0, .LC456
	add	x0, x0, :lo12:.LC456
	bl	printf
	mov	x1, 32
	adrp	x0, .LC457
	add	x0, x0, :lo12:.LC457
	bl	printf
	mov	x1, 8
	adrp	x0, .LC458
	add	x0, x0, :lo12:.LC458
	bl	printf
	mov	x1, 0
	adrp	x0, .LC459
	add	x0, x0, :lo12:.LC459
	bl	printf
	mov	x1, 4
	adrp	x0, .LC460
	add	x0, x0, :lo12:.LC460
	bl	printf
	mov	x1, 24
	adrp	x0, .LC461
	add	x0, x0, :lo12:.LC461
	bl	printf
	mov	x1, 240
	adrp	x0, .LC462
	add	x0, x0, :lo12:.LC462
	bl	printf
	mov	x1, 8
	adrp	x0, .LC463
	add	x0, x0, :lo12:.LC463
	bl	printf
	mov	x1, 0
	adrp	x0, .LC464
	add	x0, x0, :lo12:.LC464
	bl	printf
	mov	x1, 4
	adrp	x0, .LC465
	add	x0, x0, :lo12:.LC465
	bl	printf
	mov	x1, 8
	adrp	x0, .LC466
	add	x0, x0, :lo12:.LC466
	bl	printf
	mov	x1, 16
	adrp	x0, .LC467
	add	x0, x0, :lo12:.LC467
	bl	printf
	mov	x1, 24
	adrp	x0, .LC468
	add	x0, x0, :lo12:.LC468
	bl	printf
	mov	x1, 72
	adrp	x0, .LC469
	add	x0, x0, :lo12:.LC469
	bl	printf
	mov	x1, 216
	adrp	x0, .LC470
	add	x0, x0, :lo12:.LC470
	bl	printf
	mov	x1, 224
	adrp	x0, .LC471
	add	x0, x0, :lo12:.LC471
	bl	printf
	mov	x1, 232
	adrp	x0, .LC472
	add	x0, x0, :lo12:.LC472
	bl	printf
	mov	x1, 128
	adrp	x0, .LC473
	add	x0, x0, :lo12:.LC473
	bl	printf
	mov	x1, 8
	adrp	x0, .LC474
	add	x0, x0, :lo12:.LC474
	bl	printf
	mov	x1, 0
	adrp	x0, .LC475
	add	x0, x0, :lo12:.LC475
	bl	printf
	mov	x1, 8
	adrp	x0, .LC476
	add	x0, x0, :lo12:.LC476
	bl	printf
	mov	x1, 16
	adrp	x0, .LC477
	add	x0, x0, :lo12:.LC477
	bl	printf
	mov	x1, 24
	adrp	x0, .LC478
	add	x0, x0, :lo12:.LC478
	bl	printf
	mov	x1, 32
	adrp	x0, .LC479
	add	x0, x0, :lo12:.LC479
	bl	printf
	mov	x1, 40
	adrp	x0, .LC480
	add	x0, x0, :lo12:.LC480
	bl	printf
	mov	x1, 48
	adrp	x0, .LC481
	add	x0, x0, :lo12:.LC481
	bl	printf
	mov	x1, 56
	adrp	x0, .LC482
	add	x0, x0, :lo12:.LC482
	bl	printf
	mov	x1, 64
	adrp	x0, .LC483
	add	x0, x0, :lo12:.LC483
	bl	printf
	mov	x1, 72
	adrp	x0, .LC484
	add	x0, x0, :lo12:.LC484
	bl	printf
	mov	x1, 80
	adrp	x0, .LC485
	add	x0, x0, :lo12:.LC485
	bl	printf
	mov	x1, 88
	adrp	x0, .LC486
	add	x0, x0, :lo12:.LC486
	bl	printf
	mov	x1, 96
	adrp	x0, .LC487
	add	x0, x0, :lo12:.LC487
	bl	printf
	mov	x1, 104
	adrp	x0, .LC488
	add	x0, x0, :lo12:.LC488
	bl	printf
	mov	x1, 112
	adrp	x0, .LC489
	add	x0, x0, :lo12:.LC489
	bl	printf
	mov	x1, 120
	adrp	x0, .LC490
	add	x0, x0, :lo12:.LC490
	bl	printf
	mov	x1, 200
	adrp	x0, .LC491
	add	x0, x0, :lo12:.LC491
	bl	printf
	mov	x1, 8
	adrp	x0, .LC492
	add	x0, x0, :lo12:.LC492
	bl	printf
	mov	x1, 0
	adrp	x0, .LC493
	add	x0, x0, :lo12:.LC493
	bl	printf
	mov	x1, 8
	adrp	x0, .LC494
	add	x0, x0, :lo12:.LC494
	bl	printf
	mov	x1, 136
	adrp	x0, .LC495
	add	x0, x0, :lo12:.LC495
	bl	printf
	mov	x1, 176
	adrp	x0, .LC496
	add	x0, x0, :lo12:.LC496
	bl	printf
	mov	x1, 184
	adrp	x0, .LC497
	add	x0, x0, :lo12:.LC497
	bl	printf
	mov	x1, 40
	adrp	x0, .LC498
	add	x0, x0, :lo12:.LC498
	bl	printf
	mov	x1, 8
	adrp	x0, .LC499
	add	x0, x0, :lo12:.LC499
	bl	printf
	mov	x1, 0
	adrp	x0, .LC500
	add	x0, x0, :lo12:.LC500
	bl	printf
	mov	x1, 8
	adrp	x0, .LC501
	add	x0, x0, :lo12:.LC501
	bl	printf
	mov	x1, 16
	adrp	x0, .LC502
	add	x0, x0, :lo12:.LC502
	bl	printf
	mov	x1, 24
	adrp	x0, .LC503
	add	x0, x0, :lo12:.LC503
	bl	printf
	mov	x1, 32
	adrp	x0, .LC504
	add	x0, x0, :lo12:.LC504
	bl	printf
	mov	x1, 64
	adrp	x0, .LC505
	add	x0, x0, :lo12:.LC505
	bl	printf
	mov	x1, 8
	adrp	x0, .LC506
	add	x0, x0, :lo12:.LC506
	bl	printf
	mov	x1, 0
	adrp	x0, .LC507
	add	x0, x0, :lo12:.LC507
	bl	printf
	mov	x1, 4
	adrp	x0, .LC508
	add	x0, x0, :lo12:.LC508
	bl	printf
	mov	x1, 24
	adrp	x0, .LC509
	add	x0, x0, :lo12:.LC509
	bl	printf
	mov	x1, 48
	adrp	x0, .LC510
	add	x0, x0, :lo12:.LC510
	bl	printf
	mov	x1, 56
	adrp	x0, .LC511
	add	x0, x0, :lo12:.LC511
	bl	printf
	mov	x1, 56
	adrp	x0, .LC512
	add	x0, x0, :lo12:.LC512
	bl	printf
	mov	x1, 8
	adrp	x0, .LC513
	add	x0, x0, :lo12:.LC513
	bl	printf
	mov	x1, 0
	adrp	x0, .LC514
	add	x0, x0, :lo12:.LC514
	bl	printf
	mov	x1, 4
	adrp	x0, .LC515
	add	x0, x0, :lo12:.LC515
	bl	printf
	mov	x1, 8
	adrp	x0, .LC516
	add	x0, x0, :lo12:.LC516
	bl	printf
	mov	x1, 16
	adrp	x0, .LC517
	add	x0, x0, :lo12:.LC517
	bl	printf
	mov	x1, 24
	adrp	x0, .LC518
	add	x0, x0, :lo12:.LC518
	bl	printf
	mov	x1, 32
	adrp	x0, .LC519
	add	x0, x0, :lo12:.LC519
	bl	printf
	mov	x1, 40
	adrp	x0, .LC520
	add	x0, x0, :lo12:.LC520
	bl	printf
	mov	x1, 48
	adrp	x0, .LC521
	add	x0, x0, :lo12:.LC521
	bl	printf
	mov	x1, 200
	adrp	x0, .LC522
	add	x0, x0, :lo12:.LC522
	bl	printf
	mov	x1, 8
	adrp	x0, .LC523
	add	x0, x0, :lo12:.LC523
	bl	printf
	mov	x1, 0
	adrp	x0, .LC524
	add	x0, x0, :lo12:.LC524
	bl	printf
	mov	x1, 4
	adrp	x0, .LC525
	add	x0, x0, :lo12:.LC525
	bl	printf
	mov	x1, 8
	adrp	x0, .LC526
	add	x0, x0, :lo12:.LC526
	bl	printf
	mov	x1, 56
	adrp	x0, .LC527
	add	x0, x0, :lo12:.LC527
	bl	printf
	mov	x1, 24
	adrp	x0, .LC528
	add	x0, x0, :lo12:.LC528
	bl	printf
	mov	x1, 8
	adrp	x0, .LC529
	add	x0, x0, :lo12:.LC529
	bl	printf
	mov	x1, 0
	adrp	x0, .LC530
	add	x0, x0, :lo12:.LC530
	bl	printf
	mov	x1, 8
	adrp	x0, .LC531
	add	x0, x0, :lo12:.LC531
	bl	printf
	mov	x1, 16
	adrp	x0, .LC532
	add	x0, x0, :lo12:.LC532
	bl	printf
	mov	x1, 32
	adrp	x0, .LC533
	add	x0, x0, :lo12:.LC533
	bl	printf
	mov	x1, 8
	adrp	x0, .LC534
	add	x0, x0, :lo12:.LC534
	bl	printf
	mov	x1, 0
	adrp	x0, .LC535
	add	x0, x0, :lo12:.LC535
	bl	printf
	mov	x1, 8
	adrp	x0, .LC536
	add	x0, x0, :lo12:.LC536
	bl	printf
	mov	x1, 16
	adrp	x0, .LC537
	add	x0, x0, :lo12:.LC537
	bl	printf
	mov	x1, 168
	adrp	x0, .LC538
	add	x0, x0, :lo12:.LC538
	bl	printf
	mov	x1, 8
	adrp	x0, .LC539
	add	x0, x0, :lo12:.LC539
	bl	printf
	mov	x1, 0
	adrp	x0, .LC540
	add	x0, x0, :lo12:.LC540
	bl	printf
	mov	x1, 4
	adrp	x0, .LC541
	add	x0, x0, :lo12:.LC541
	bl	printf
	mov	x1, 8
	adrp	x0, .LC542
	add	x0, x0, :lo12:.LC542
	bl	printf
	mov	x1, 152
	adrp	x0, .LC543
	add	x0, x0, :lo12:.LC543
	bl	printf
	mov	x1, 160
	adrp	x0, .LC544
	add	x0, x0, :lo12:.LC544
	bl	printf
	mov	x1, 40
	adrp	x0, .LC545
	add	x0, x0, :lo12:.LC545
	bl	printf
	mov	x1, 8
	adrp	x0, .LC546
	add	x0, x0, :lo12:.LC546
	bl	printf
	mov	x1, 0
	adrp	x0, .LC547
	add	x0, x0, :lo12:.LC547
	bl	printf
	mov	x1, 4
	adrp	x0, .LC548
	add	x0, x0, :lo12:.LC548
	bl	printf
	mov	x1, 8
	adrp	x0, .LC549
	add	x0, x0, :lo12:.LC549
	bl	printf
	mov	x1, 16
	adrp	x0, .LC550
	add	x0, x0, :lo12:.LC550
	bl	printf
	mov	x1, 24
	adrp	x0, .LC551
	add	x0, x0, :lo12:.LC551
	bl	printf
	mov	x1, 24
	adrp	x0, .LC552
	add	x0, x0, :lo12:.LC552
	bl	printf
	mov	x1, 8
	adrp	x0, .LC553
	add	x0, x0, :lo12:.LC553
	bl	printf
	mov	x1, 0
	adrp	x0, .LC554
	add	x0, x0, :lo12:.LC554
	bl	printf
	mov	x1, 8
	adrp	x0, .LC555
	add	x0, x0, :lo12:.LC555
	bl	printf
	mov	x1, 16
	adrp	x0, .LC556
	add	x0, x0, :lo12:.LC556
	bl	printf
	mov	x1, 48
	adrp	x0, .LC557
	add	x0, x0, :lo12:.LC557
	bl	printf
	mov	x1, 8
	adrp	x0, .LC558
	add	x0, x0, :lo12:.LC558
	bl	printf
	mov	x1, 0
	adrp	x0, .LC559
	add	x0, x0, :lo12:.LC559
	bl	printf
	mov	x1, 4
	adrp	x0, .LC560
	add	x0, x0, :lo12:.LC560
	bl	printf
	mov	x1, 8
	adrp	x0, .LC561
	add	x0, x0, :lo12:.LC561
	bl	printf
	mov	x1, 16
	adrp	x0, .LC562
	add	x0, x0, :lo12:.LC562
	bl	printf
	mov	x1, 32
	adrp	x0, .LC563
	add	x0, x0, :lo12:.LC563
	bl	printf
	mov	x1, 40
	adrp	x0, .LC564
	add	x0, x0, :lo12:.LC564
	bl	printf
	mov	x1, 16
	adrp	x0, .LC565
	add	x0, x0, :lo12:.LC565
	bl	printf
	mov	x1, 8
	adrp	x0, .LC566
	add	x0, x0, :lo12:.LC566
	bl	printf
	mov	x1, 0
	adrp	x0, .LC567
	add	x0, x0, :lo12:.LC567
	bl	printf
	mov	x1, 8
	adrp	x0, .LC568
	add	x0, x0, :lo12:.LC568
	bl	printf
	mov	x1, 376
	adrp	x0, .LC569
	add	x0, x0, :lo12:.LC569
	bl	printf
	mov	x1, 8
	adrp	x0, .LC570
	add	x0, x0, :lo12:.LC570
	bl	printf
	mov	x1, 0
	adrp	x0, .LC571
	add	x0, x0, :lo12:.LC571
	bl	printf
	mov	x1, 8
	adrp	x0, .LC572
	add	x0, x0, :lo12:.LC572
	bl	printf
	mov	x1, 152
	adrp	x0, .LC573
	add	x0, x0, :lo12:.LC573
	bl	printf
	mov	x1, 368
	adrp	x0, .LC574
	add	x0, x0, :lo12:.LC574
	bl	printf
	mov	x1, 16
	adrp	x0, .LC575
	add	x0, x0, :lo12:.LC575
	bl	printf
	mov	x1, 8
	adrp	x0, .LC576
	add	x0, x0, :lo12:.LC576
	bl	printf
	mov	x1, 0
	adrp	x0, .LC577
	add	x0, x0, :lo12:.LC577
	bl	printf
	mov	x1, 8
	adrp	x0, .LC578
	add	x0, x0, :lo12:.LC578
	bl	printf
	mov	x1, 12
	adrp	x0, .LC579
	add	x0, x0, :lo12:.LC579
	bl	printf
	mov	x1, 40
	adrp	x0, .LC580
	add	x0, x0, :lo12:.LC580
	bl	printf
	mov	x1, 8
	adrp	x0, .LC581
	add	x0, x0, :lo12:.LC581
	bl	printf
	mov	x1, 0
	adrp	x0, .LC582
	add	x0, x0, :lo12:.LC582
	bl	printf
	mov	x1, 4
	adrp	x0, .LC583
	add	x0, x0, :lo12:.LC583
	bl	printf
	mov	x1, 24
	adrp	x0, .LC584
	add	x0, x0, :lo12:.LC584
	bl	printf
	mov	x1, 32
	adrp	x0, .LC585
	add	x0, x0, :lo12:.LC585
	bl	printf
	mov	x1, 168
	adrp	x0, .LC586
	add	x0, x0, :lo12:.LC586
	bl	printf
	mov	x1, 8
	adrp	x0, .LC587
	add	x0, x0, :lo12:.LC587
	bl	printf
	mov	x1, 0
	adrp	x0, .LC588
	add	x0, x0, :lo12:.LC588
	bl	printf
	mov	x1, 4
	adrp	x0, .LC589
	add	x0, x0, :lo12:.LC589
	bl	printf
	mov	x1, 8
	adrp	x0, .LC590
	add	x0, x0, :lo12:.LC590
	bl	printf
	mov	x1, 16
	adrp	x0, .LC591
	add	x0, x0, :lo12:.LC591
	bl	printf
	mov	x1, 24
	adrp	x0, .LC592
	add	x0, x0, :lo12:.LC592
	bl	printf
	mov	x1, 8
	adrp	x0, .LC593
	add	x0, x0, :lo12:.LC593
	bl	printf
	mov	x1, 4
	adrp	x0, .LC594
	add	x0, x0, :lo12:.LC594
	bl	printf
	mov	x1, 0
	adrp	x0, .LC595
	add	x0, x0, :lo12:.LC595
	bl	printf
	mov	x1, 4
	adrp	x0, .LC596
	add	x0, x0, :lo12:.LC596
	bl	printf
	mov	x1, 24
	adrp	x0, .LC597
	add	x0, x0, :lo12:.LC597
	bl	printf
	mov	x1, 8
	adrp	x0, .LC598
	add	x0, x0, :lo12:.LC598
	bl	printf
	mov	x1, 0
	adrp	x0, .LC599
	add	x0, x0, :lo12:.LC599
	bl	printf
	mov	x1, 8
	adrp	x0, .LC600
	add	x0, x0, :lo12:.LC600
	bl	printf
	mov	x1, 16
	adrp	x0, .LC601
	add	x0, x0, :lo12:.LC601
	bl	printf
	mov	w0, 0
	ldp	x29, x30, [sp], 16
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
