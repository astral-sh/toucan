	.arch armv8-a
	.file	"constants.c"
	.text
	.align	2
	.p2align 4,,11
	.type	print_unsigned, %function
print_unsigned:
.LFB0:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	adrp	x2, .LC0
	adrp	x3, :got:__stack_chk_guard
	ldr	x3, [x3, :got_lo12:__stack_chk_guard]
	add	x2, x2, :lo12:.LC0
	stp	x29, x30, [sp, 48]
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	add	x29, sp, 48
	mov	x11, -3689348814741910324
	ldp	x5, x8, [x2]
	stp	x19, x20, [sp, 64]
	.cfi_offset 19, -16
	.cfi_offset 20, -8
	mov	x20, sp
	ldr	x2, [x3]
	str	x2, [sp, 40]
	mov	x2, 0
	mov	x6, 1
	movk	x11, 0xcccd, lsl 0
	.p2align 3,,7
.L12:
	adds	x2, x0, x1
	mov	x9, x1
	cinc	x2, x2, cs
	add	x7, x20, x6
	mov	x12, x0
	mov	x19, x6
	add	x6, x6, 1
	umulh	x3, x2, x11
	and	x4, x3, -4
	add	x3, x4, x3, lsr 2
	sub	x2, x2, x3
	subs	x2, x0, x2
	sbc	x1, x1, xzr
	umulh	x3, x2, x5
	madd	x3, x1, x5, x3
	mul	x10, x2, x5
	madd	x3, x2, x8, x3
	umulh	x4, x2, x5
	madd	x4, x1, x5, x4
	madd	x4, x2, x8, x4
	extr	x3, x3, x10, 1
	add	x3, x3, x3, lsl 2
	lsr	x1, x4, 1
	sub	x3, x0, x3, lsl 1
	extr	x0, x4, x10, 1
	add	w3, w3, 48
	strb	w3, [x7, -1]
	cbnz	x9, .L12
	cmp	x12, 9
	bhi	.L12
	sub	w19, w19, #1
	add	x19, x20, x19
	.p2align 3,,7
.L8:
	ldrb	w0, [x19]
	bl	putchar
	cmp	x19, x20
	sub	x19, x19, #1
	bne	.L8
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 40]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	bne	.L15
	ldp	x29, x30, [sp, 48]
	ldp	x19, x20, [sp, 64]
	add	sp, sp, 80
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret
.L15:
	.cfi_restore_state
	bl	__stack_chk_fail
	.cfi_endproc
.LFE0:
	.size	print_unsigned, .-print_unsigned
	.align	2
	.p2align 4,,11
	.type	print_signed.part.0, %function
print_signed.part.0:
.LFB3:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -16
	.cfi_offset 20, -8
	mov	x19, x0
	mov	x20, x1
	mov	w0, 45
	bl	putchar
	negs	x0, x19
	sbc	x1, xzr, x20
	ldp	x19, x20, [sp, 16]
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	b	print_unsigned
	.cfi_endproc
.LFE3:
	.size	print_signed.part.0, .-print_signed.part.0
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC1:
	.string	"enum_expression_size.GIT_APPLY_CHECK=%zu\n"
	.align	3
.LC2:
	.string	"enum_expression_signed.GIT_APPLY_CHECK=%d\n"
	.align	3
.LC3:
	.string	"constant.GIT_APPLY_CHECK="
	.align	3
.LC4:
	.string	"constant_size.GIT_APPLY_CHECK=%zu\n"
	.align	3
.LC5:
	.string	"constant_signed.GIT_APPLY_CHECK=%d\n"
	.align	3
.LC6:
	.string	"enum_expression_size.GIT_APPLY_LOCATION_BOTH=%zu\n"
	.align	3
.LC7:
	.string	"enum_expression_signed.GIT_APPLY_LOCATION_BOTH=%d\n"
	.align	3
.LC8:
	.string	"constant.GIT_APPLY_LOCATION_BOTH="
	.align	3
.LC9:
	.string	"constant_size.GIT_APPLY_LOCATION_BOTH=%zu\n"
	.align	3
.LC10:
	.string	"constant_signed.GIT_APPLY_LOCATION_BOTH=%d\n"
	.align	3
.LC11:
	.string	"enum_expression_size.GIT_APPLY_LOCATION_INDEX=%zu\n"
	.align	3
.LC12:
	.string	"enum_expression_signed.GIT_APPLY_LOCATION_INDEX=%d\n"
	.align	3
.LC13:
	.string	"constant.GIT_APPLY_LOCATION_INDEX="
	.align	3
.LC14:
	.string	"constant_size.GIT_APPLY_LOCATION_INDEX=%zu\n"
	.align	3
.LC15:
	.string	"constant_signed.GIT_APPLY_LOCATION_INDEX=%d\n"
	.align	3
.LC16:
	.string	"enum_expression_size.GIT_APPLY_LOCATION_WORKDIR=%zu\n"
	.align	3
.LC17:
	.string	"enum_expression_signed.GIT_APPLY_LOCATION_WORKDIR=%d\n"
	.align	3
.LC18:
	.string	"constant.GIT_APPLY_LOCATION_WORKDIR="
	.align	3
.LC19:
	.string	"constant_size.GIT_APPLY_LOCATION_WORKDIR=%zu\n"
	.align	3
.LC20:
	.string	"constant_signed.GIT_APPLY_LOCATION_WORKDIR=%d\n"
	.align	3
.LC21:
	.string	"enum_expression_size.GIT_ATTR_VALUE_FALSE=%zu\n"
	.align	3
.LC22:
	.string	"enum_expression_signed.GIT_ATTR_VALUE_FALSE=%d\n"
	.align	3
.LC23:
	.string	"constant.GIT_ATTR_VALUE_FALSE="
	.align	3
.LC24:
	.string	"constant_size.GIT_ATTR_VALUE_FALSE=%zu\n"
	.align	3
.LC25:
	.string	"constant_signed.GIT_ATTR_VALUE_FALSE=%d\n"
	.align	3
.LC26:
	.string	"enum_expression_size.GIT_ATTR_VALUE_STRING=%zu\n"
	.align	3
.LC27:
	.string	"enum_expression_signed.GIT_ATTR_VALUE_STRING=%d\n"
	.align	3
.LC28:
	.string	"constant.GIT_ATTR_VALUE_STRING="
	.align	3
.LC29:
	.string	"constant_size.GIT_ATTR_VALUE_STRING=%zu\n"
	.align	3
.LC30:
	.string	"constant_signed.GIT_ATTR_VALUE_STRING=%d\n"
	.align	3
.LC31:
	.string	"enum_expression_size.GIT_ATTR_VALUE_TRUE=%zu\n"
	.align	3
.LC32:
	.string	"enum_expression_signed.GIT_ATTR_VALUE_TRUE=%d\n"
	.align	3
.LC33:
	.string	"constant.GIT_ATTR_VALUE_TRUE="
	.align	3
.LC34:
	.string	"constant_size.GIT_ATTR_VALUE_TRUE=%zu\n"
	.align	3
.LC35:
	.string	"constant_signed.GIT_ATTR_VALUE_TRUE=%d\n"
	.align	3
.LC36:
	.string	"enum_expression_size.GIT_ATTR_VALUE_UNSPECIFIED=%zu\n"
	.align	3
.LC37:
	.string	"enum_expression_signed.GIT_ATTR_VALUE_UNSPECIFIED=%d\n"
	.align	3
.LC38:
	.string	"constant.GIT_ATTR_VALUE_UNSPECIFIED="
	.align	3
.LC39:
	.string	"constant_size.GIT_ATTR_VALUE_UNSPECIFIED=%zu\n"
	.align	3
.LC40:
	.string	"constant_signed.GIT_ATTR_VALUE_UNSPECIFIED=%d\n"
	.align	3
.LC41:
	.string	"enum_expression_size.GIT_BLAME_FIRST_PARENT=%zu\n"
	.align	3
.LC42:
	.string	"enum_expression_signed.GIT_BLAME_FIRST_PARENT=%d\n"
	.align	3
.LC43:
	.string	"constant.GIT_BLAME_FIRST_PARENT="
	.align	3
.LC44:
	.string	"constant_size.GIT_BLAME_FIRST_PARENT=%zu\n"
	.align	3
.LC45:
	.string	"constant_signed.GIT_BLAME_FIRST_PARENT=%d\n"
	.align	3
.LC46:
	.string	"enum_expression_size.GIT_BLAME_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC47:
	.string	"enum_expression_signed.GIT_BLAME_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC48:
	.string	"constant.GIT_BLAME_IGNORE_WHITESPACE="
	.align	3
.LC49:
	.string	"constant_size.GIT_BLAME_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC50:
	.string	"constant_signed.GIT_BLAME_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC51:
	.string	"enum_expression_size.GIT_BLAME_NORMAL=%zu\n"
	.align	3
.LC52:
	.string	"enum_expression_signed.GIT_BLAME_NORMAL=%d\n"
	.align	3
.LC53:
	.string	"constant.GIT_BLAME_NORMAL="
	.align	3
.LC54:
	.string	"constant_size.GIT_BLAME_NORMAL=%zu\n"
	.align	3
.LC55:
	.string	"constant_signed.GIT_BLAME_NORMAL=%d\n"
	.align	3
.LC56:
	.string	"enum_expression_size.GIT_BLAME_TRACK_COPIES_ANY_COMMIT_COPIES=%zu\n"
	.align	3
.LC57:
	.string	"enum_expression_signed.GIT_BLAME_TRACK_COPIES_ANY_COMMIT_COPIES=%d\n"
	.align	3
.LC58:
	.string	"constant.GIT_BLAME_TRACK_COPIES_ANY_COMMIT_COPIES="
	.align	3
.LC59:
	.string	"constant_size.GIT_BLAME_TRACK_COPIES_ANY_COMMIT_COPIES=%zu\n"
	.align	3
.LC60:
	.string	"constant_signed.GIT_BLAME_TRACK_COPIES_ANY_COMMIT_COPIES=%d\n"
	.align	3
.LC61:
	.string	"enum_expression_size.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_COPIES=%zu\n"
	.align	3
.LC62:
	.string	"enum_expression_signed.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_COPIES=%d\n"
	.align	3
.LC63:
	.string	"constant.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_COPIES="
	.align	3
.LC64:
	.string	"constant_size.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_COPIES=%zu\n"
	.align	3
.LC65:
	.string	"constant_signed.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_COPIES=%d\n"
	.align	3
.LC66:
	.string	"enum_expression_size.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_MOVES=%zu\n"
	.align	3
.LC67:
	.string	"enum_expression_signed.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_MOVES=%d\n"
	.align	3
.LC68:
	.string	"constant.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_MOVES="
	.align	3
.LC69:
	.string	"constant_size.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_MOVES=%zu\n"
	.align	3
.LC70:
	.string	"constant_signed.GIT_BLAME_TRACK_COPIES_SAME_COMMIT_MOVES=%d\n"
	.align	3
.LC71:
	.string	"enum_expression_size.GIT_BLAME_TRACK_COPIES_SAME_FILE=%zu\n"
	.align	3
.LC72:
	.string	"enum_expression_signed.GIT_BLAME_TRACK_COPIES_SAME_FILE=%d\n"
	.align	3
.LC73:
	.string	"constant.GIT_BLAME_TRACK_COPIES_SAME_FILE="
	.align	3
.LC74:
	.string	"constant_size.GIT_BLAME_TRACK_COPIES_SAME_FILE=%zu\n"
	.align	3
.LC75:
	.string	"constant_signed.GIT_BLAME_TRACK_COPIES_SAME_FILE=%d\n"
	.align	3
.LC76:
	.string	"enum_expression_size.GIT_BLAME_USE_MAILMAP=%zu\n"
	.align	3
.LC77:
	.string	"enum_expression_signed.GIT_BLAME_USE_MAILMAP=%d\n"
	.align	3
.LC78:
	.string	"constant.GIT_BLAME_USE_MAILMAP="
	.align	3
.LC79:
	.string	"constant_size.GIT_BLAME_USE_MAILMAP=%zu\n"
	.align	3
.LC80:
	.string	"constant_signed.GIT_BLAME_USE_MAILMAP=%d\n"
	.align	3
.LC81:
	.string	"enum_expression_size.GIT_BLOB_FILTER_ATTRIBUTES_FROM_COMMIT=%zu\n"
	.align	3
.LC82:
	.string	"enum_expression_signed.GIT_BLOB_FILTER_ATTRIBUTES_FROM_COMMIT=%d\n"
	.align	3
.LC83:
	.string	"constant.GIT_BLOB_FILTER_ATTRIBUTES_FROM_COMMIT="
	.align	3
.LC84:
	.string	"constant_size.GIT_BLOB_FILTER_ATTRIBUTES_FROM_COMMIT=%zu\n"
	.align	3
.LC85:
	.string	"constant_signed.GIT_BLOB_FILTER_ATTRIBUTES_FROM_COMMIT=%d\n"
	.align	3
.LC86:
	.string	"enum_expression_size.GIT_BLOB_FILTER_ATTRIBUTES_FROM_HEAD=%zu\n"
	.align	3
.LC87:
	.string	"enum_expression_signed.GIT_BLOB_FILTER_ATTRIBUTES_FROM_HEAD=%d\n"
	.align	3
.LC88:
	.string	"constant.GIT_BLOB_FILTER_ATTRIBUTES_FROM_HEAD="
	.align	3
.LC89:
	.string	"constant_size.GIT_BLOB_FILTER_ATTRIBUTES_FROM_HEAD=%zu\n"
	.align	3
.LC90:
	.string	"constant_signed.GIT_BLOB_FILTER_ATTRIBUTES_FROM_HEAD=%d\n"
	.align	3
.LC91:
	.string	"enum_expression_size.GIT_BLOB_FILTER_CHECK_FOR_BINARY=%zu\n"
	.align	3
.LC92:
	.string	"enum_expression_signed.GIT_BLOB_FILTER_CHECK_FOR_BINARY=%d\n"
	.align	3
.LC93:
	.string	"constant.GIT_BLOB_FILTER_CHECK_FOR_BINARY="
	.align	3
.LC94:
	.string	"constant_size.GIT_BLOB_FILTER_CHECK_FOR_BINARY=%zu\n"
	.align	3
.LC95:
	.string	"constant_signed.GIT_BLOB_FILTER_CHECK_FOR_BINARY=%d\n"
	.align	3
.LC96:
	.string	"enum_expression_size.GIT_BLOB_FILTER_NO_SYSTEM_ATTRIBUTES=%zu\n"
	.align	3
.LC97:
	.string	"enum_expression_signed.GIT_BLOB_FILTER_NO_SYSTEM_ATTRIBUTES=%d\n"
	.align	3
.LC98:
	.string	"constant.GIT_BLOB_FILTER_NO_SYSTEM_ATTRIBUTES="
	.align	3
.LC99:
	.string	"constant_size.GIT_BLOB_FILTER_NO_SYSTEM_ATTRIBUTES=%zu\n"
	.align	3
.LC100:
	.string	"constant_signed.GIT_BLOB_FILTER_NO_SYSTEM_ATTRIBUTES=%d\n"
	.align	3
.LC101:
	.string	"enum_expression_size.GIT_BRANCH_ALL=%zu\n"
	.align	3
.LC102:
	.string	"enum_expression_signed.GIT_BRANCH_ALL=%d\n"
	.align	3
.LC103:
	.string	"constant.GIT_BRANCH_ALL="
	.align	3
.LC104:
	.string	"constant_size.GIT_BRANCH_ALL=%zu\n"
	.align	3
.LC105:
	.string	"constant_signed.GIT_BRANCH_ALL=%d\n"
	.align	3
.LC106:
	.string	"enum_expression_size.GIT_BRANCH_LOCAL=%zu\n"
	.align	3
.LC107:
	.string	"enum_expression_signed.GIT_BRANCH_LOCAL=%d\n"
	.align	3
.LC108:
	.string	"constant.GIT_BRANCH_LOCAL="
	.align	3
.LC109:
	.string	"constant_size.GIT_BRANCH_LOCAL=%zu\n"
	.align	3
.LC110:
	.string	"constant_signed.GIT_BRANCH_LOCAL=%d\n"
	.align	3
.LC111:
	.string	"enum_expression_size.GIT_BRANCH_REMOTE=%zu\n"
	.align	3
.LC112:
	.string	"enum_expression_signed.GIT_BRANCH_REMOTE=%d\n"
	.align	3
.LC113:
	.string	"constant.GIT_BRANCH_REMOTE="
	.align	3
.LC114:
	.string	"constant_size.GIT_BRANCH_REMOTE=%zu\n"
	.align	3
.LC115:
	.string	"constant_signed.GIT_BRANCH_REMOTE=%d\n"
	.align	3
.LC116:
	.string	"enum_expression_size.GIT_CERT_HOSTKEY_LIBSSH2=%zu\n"
	.align	3
.LC117:
	.string	"enum_expression_signed.GIT_CERT_HOSTKEY_LIBSSH2=%d\n"
	.align	3
.LC118:
	.string	"constant.GIT_CERT_HOSTKEY_LIBSSH2="
	.align	3
.LC119:
	.string	"constant_size.GIT_CERT_HOSTKEY_LIBSSH2=%zu\n"
	.align	3
.LC120:
	.string	"constant_signed.GIT_CERT_HOSTKEY_LIBSSH2=%d\n"
	.align	3
.LC121:
	.string	"enum_expression_size.GIT_CERT_NONE=%zu\n"
	.align	3
.LC122:
	.string	"enum_expression_signed.GIT_CERT_NONE=%d\n"
	.align	3
.LC123:
	.string	"constant.GIT_CERT_NONE="
	.align	3
.LC124:
	.string	"constant_size.GIT_CERT_NONE=%zu\n"
	.align	3
.LC125:
	.string	"constant_signed.GIT_CERT_NONE=%d\n"
	.align	3
.LC126:
	.string	"enum_expression_size.GIT_CERT_SSH_MD5=%zu\n"
	.align	3
.LC127:
	.string	"enum_expression_signed.GIT_CERT_SSH_MD5=%d\n"
	.align	3
.LC128:
	.string	"constant.GIT_CERT_SSH_MD5="
	.align	3
.LC129:
	.string	"constant_size.GIT_CERT_SSH_MD5=%zu\n"
	.align	3
.LC130:
	.string	"constant_signed.GIT_CERT_SSH_MD5=%d\n"
	.align	3
.LC131:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW=%zu\n"
	.align	3
.LC132:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW=%d\n"
	.align	3
.LC133:
	.string	"constant.GIT_CERT_SSH_RAW="
	.align	3
.LC134:
	.string	"constant_size.GIT_CERT_SSH_RAW=%zu\n"
	.align	3
.LC135:
	.string	"constant_signed.GIT_CERT_SSH_RAW=%d\n"
	.align	3
.LC136:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_DSS=%zu\n"
	.align	3
.LC137:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_DSS=%d\n"
	.align	3
.LC138:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_DSS="
	.align	3
.LC139:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_DSS=%zu\n"
	.align	3
.LC140:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_DSS=%d\n"
	.align	3
.LC141:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_256=%zu\n"
	.align	3
.LC142:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_256=%d\n"
	.align	3
.LC143:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_256="
	.align	3
.LC144:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_256=%zu\n"
	.align	3
.LC145:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_256=%d\n"
	.align	3
.LC146:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_384=%zu\n"
	.align	3
.LC147:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_384=%d\n"
	.align	3
.LC148:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_384="
	.align	3
.LC149:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_384=%zu\n"
	.align	3
.LC150:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_384=%d\n"
	.align	3
.LC151:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_521=%zu\n"
	.align	3
.LC152:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_521=%d\n"
	.align	3
.LC153:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_521="
	.align	3
.LC154:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_521=%zu\n"
	.align	3
.LC155:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ECDSA_521=%d\n"
	.align	3
.LC156:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_KEY_ED25519=%zu\n"
	.align	3
.LC157:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ED25519=%d\n"
	.align	3
.LC158:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_KEY_ED25519="
	.align	3
.LC159:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_KEY_ED25519=%zu\n"
	.align	3
.LC160:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_KEY_ED25519=%d\n"
	.align	3
.LC161:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_RSA=%zu\n"
	.align	3
.LC162:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_RSA=%d\n"
	.align	3
.LC163:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_RSA="
	.align	3
.LC164:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_RSA=%zu\n"
	.align	3
.LC165:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_RSA=%d\n"
	.align	3
.LC166:
	.string	"enum_expression_size.GIT_CERT_SSH_RAW_TYPE_UNKNOWN=%zu\n"
	.align	3
.LC167:
	.string	"enum_expression_signed.GIT_CERT_SSH_RAW_TYPE_UNKNOWN=%d\n"
	.align	3
.LC168:
	.string	"constant.GIT_CERT_SSH_RAW_TYPE_UNKNOWN="
	.align	3
.LC169:
	.string	"constant_size.GIT_CERT_SSH_RAW_TYPE_UNKNOWN=%zu\n"
	.align	3
.LC170:
	.string	"constant_signed.GIT_CERT_SSH_RAW_TYPE_UNKNOWN=%d\n"
	.align	3
.LC171:
	.string	"enum_expression_size.GIT_CERT_SSH_SHA1=%zu\n"
	.align	3
.LC172:
	.string	"enum_expression_signed.GIT_CERT_SSH_SHA1=%d\n"
	.align	3
.LC173:
	.string	"constant.GIT_CERT_SSH_SHA1="
	.align	3
.LC174:
	.string	"constant_size.GIT_CERT_SSH_SHA1=%zu\n"
	.align	3
.LC175:
	.string	"constant_signed.GIT_CERT_SSH_SHA1=%d\n"
	.align	3
.LC176:
	.string	"enum_expression_size.GIT_CERT_SSH_SHA256=%zu\n"
	.align	3
.LC177:
	.string	"enum_expression_signed.GIT_CERT_SSH_SHA256=%d\n"
	.align	3
.LC178:
	.string	"constant.GIT_CERT_SSH_SHA256="
	.align	3
.LC179:
	.string	"constant_size.GIT_CERT_SSH_SHA256=%zu\n"
	.align	3
.LC180:
	.string	"constant_signed.GIT_CERT_SSH_SHA256=%d\n"
	.align	3
.LC181:
	.string	"enum_expression_size.GIT_CERT_STRARRAY=%zu\n"
	.align	3
.LC182:
	.string	"enum_expression_signed.GIT_CERT_STRARRAY=%d\n"
	.align	3
.LC183:
	.string	"constant.GIT_CERT_STRARRAY="
	.align	3
.LC184:
	.string	"constant_size.GIT_CERT_STRARRAY=%zu\n"
	.align	3
.LC185:
	.string	"constant_signed.GIT_CERT_STRARRAY=%d\n"
	.align	3
.LC186:
	.string	"enum_expression_size.GIT_CERT_X509=%zu\n"
	.align	3
.LC187:
	.string	"enum_expression_signed.GIT_CERT_X509=%d\n"
	.align	3
.LC188:
	.string	"constant.GIT_CERT_X509="
	.align	3
.LC189:
	.string	"constant_size.GIT_CERT_X509=%zu\n"
	.align	3
.LC190:
	.string	"constant_signed.GIT_CERT_X509=%d\n"
	.align	3
.LC191:
	.string	"enum_expression_size.GIT_CHECKOUT_ALLOW_CONFLICTS=%zu\n"
	.align	3
.LC192:
	.string	"enum_expression_signed.GIT_CHECKOUT_ALLOW_CONFLICTS=%d\n"
	.align	3
.LC193:
	.string	"constant.GIT_CHECKOUT_ALLOW_CONFLICTS="
	.align	3
.LC194:
	.string	"constant_size.GIT_CHECKOUT_ALLOW_CONFLICTS=%zu\n"
	.align	3
.LC195:
	.string	"constant_signed.GIT_CHECKOUT_ALLOW_CONFLICTS=%d\n"
	.align	3
.LC196:
	.string	"enum_expression_size.GIT_CHECKOUT_CONFLICT_STYLE_DIFF3=%zu\n"
	.align	3
.LC197:
	.string	"enum_expression_signed.GIT_CHECKOUT_CONFLICT_STYLE_DIFF3=%d\n"
	.align	3
.LC198:
	.string	"constant.GIT_CHECKOUT_CONFLICT_STYLE_DIFF3="
	.align	3
.LC199:
	.string	"constant_size.GIT_CHECKOUT_CONFLICT_STYLE_DIFF3=%zu\n"
	.align	3
.LC200:
	.string	"constant_signed.GIT_CHECKOUT_CONFLICT_STYLE_DIFF3=%d\n"
	.align	3
.LC201:
	.string	"enum_expression_size.GIT_CHECKOUT_CONFLICT_STYLE_MERGE=%zu\n"
	.align	3
.LC202:
	.string	"enum_expression_signed.GIT_CHECKOUT_CONFLICT_STYLE_MERGE=%d\n"
	.align	3
.LC203:
	.string	"constant.GIT_CHECKOUT_CONFLICT_STYLE_MERGE="
	.align	3
.LC204:
	.string	"constant_size.GIT_CHECKOUT_CONFLICT_STYLE_MERGE=%zu\n"
	.align	3
.LC205:
	.string	"constant_signed.GIT_CHECKOUT_CONFLICT_STYLE_MERGE=%d\n"
	.align	3
.LC206:
	.string	"enum_expression_size.GIT_CHECKOUT_CONFLICT_STYLE_ZDIFF3=%zu\n"
	.align	3
.LC207:
	.string	"enum_expression_signed.GIT_CHECKOUT_CONFLICT_STYLE_ZDIFF3=%d\n"
	.align	3
.LC208:
	.string	"constant.GIT_CHECKOUT_CONFLICT_STYLE_ZDIFF3="
	.align	3
.LC209:
	.string	"constant_size.GIT_CHECKOUT_CONFLICT_STYLE_ZDIFF3=%zu\n"
	.align	3
.LC210:
	.string	"constant_signed.GIT_CHECKOUT_CONFLICT_STYLE_ZDIFF3=%d\n"
	.align	3
.LC211:
	.string	"enum_expression_size.GIT_CHECKOUT_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC212:
	.string	"enum_expression_signed.GIT_CHECKOUT_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC213:
	.string	"constant.GIT_CHECKOUT_DISABLE_PATHSPEC_MATCH="
	.align	3
.LC214:
	.string	"constant_size.GIT_CHECKOUT_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC215:
	.string	"constant_signed.GIT_CHECKOUT_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC216:
	.string	"enum_expression_size.GIT_CHECKOUT_DONT_OVERWRITE_IGNORED=%zu\n"
	.align	3
.LC217:
	.string	"enum_expression_signed.GIT_CHECKOUT_DONT_OVERWRITE_IGNORED=%d\n"
	.align	3
.LC218:
	.string	"constant.GIT_CHECKOUT_DONT_OVERWRITE_IGNORED="
	.align	3
.LC219:
	.string	"constant_size.GIT_CHECKOUT_DONT_OVERWRITE_IGNORED=%zu\n"
	.align	3
.LC220:
	.string	"constant_signed.GIT_CHECKOUT_DONT_OVERWRITE_IGNORED=%d\n"
	.align	3
.LC221:
	.string	"enum_expression_size.GIT_CHECKOUT_DONT_REMOVE_EXISTING=%zu\n"
	.align	3
.LC222:
	.string	"enum_expression_signed.GIT_CHECKOUT_DONT_REMOVE_EXISTING=%d\n"
	.align	3
.LC223:
	.string	"constant.GIT_CHECKOUT_DONT_REMOVE_EXISTING="
	.align	3
.LC224:
	.string	"constant_size.GIT_CHECKOUT_DONT_REMOVE_EXISTING=%zu\n"
	.align	3
.LC225:
	.string	"constant_signed.GIT_CHECKOUT_DONT_REMOVE_EXISTING=%d\n"
	.align	3
.LC226:
	.string	"enum_expression_size.GIT_CHECKOUT_DONT_UPDATE_INDEX=%zu\n"
	.align	3
.LC227:
	.string	"enum_expression_signed.GIT_CHECKOUT_DONT_UPDATE_INDEX=%d\n"
	.align	3
.LC228:
	.string	"constant.GIT_CHECKOUT_DONT_UPDATE_INDEX="
	.align	3
.LC229:
	.string	"constant_size.GIT_CHECKOUT_DONT_UPDATE_INDEX=%zu\n"
	.align	3
.LC230:
	.string	"constant_signed.GIT_CHECKOUT_DONT_UPDATE_INDEX=%d\n"
	.align	3
.LC231:
	.string	"enum_expression_size.GIT_CHECKOUT_DONT_WRITE_INDEX=%zu\n"
	.align	3
.LC232:
	.string	"enum_expression_signed.GIT_CHECKOUT_DONT_WRITE_INDEX=%d\n"
	.align	3
.LC233:
	.string	"constant.GIT_CHECKOUT_DONT_WRITE_INDEX="
	.align	3
.LC234:
	.string	"constant_size.GIT_CHECKOUT_DONT_WRITE_INDEX=%zu\n"
	.align	3
.LC235:
	.string	"constant_signed.GIT_CHECKOUT_DONT_WRITE_INDEX=%d\n"
	.align	3
.LC236:
	.string	"enum_expression_size.GIT_CHECKOUT_DRY_RUN=%zu\n"
	.align	3
.LC237:
	.string	"enum_expression_signed.GIT_CHECKOUT_DRY_RUN=%d\n"
	.align	3
.LC238:
	.string	"constant.GIT_CHECKOUT_DRY_RUN="
	.align	3
.LC239:
	.string	"constant_size.GIT_CHECKOUT_DRY_RUN=%zu\n"
	.align	3
.LC240:
	.string	"constant_signed.GIT_CHECKOUT_DRY_RUN=%d\n"
	.align	3
.LC241:
	.string	"enum_expression_size.GIT_CHECKOUT_FORCE=%zu\n"
	.align	3
.LC242:
	.string	"enum_expression_signed.GIT_CHECKOUT_FORCE=%d\n"
	.align	3
.LC243:
	.string	"constant.GIT_CHECKOUT_FORCE="
	.align	3
.LC244:
	.string	"constant_size.GIT_CHECKOUT_FORCE=%zu\n"
	.align	3
.LC245:
	.string	"constant_signed.GIT_CHECKOUT_FORCE=%d\n"
	.align	3
.LC246:
	.string	"enum_expression_size.GIT_CHECKOUT_NONE=%zu\n"
	.align	3
.LC247:
	.string	"enum_expression_signed.GIT_CHECKOUT_NONE=%d\n"
	.align	3
.LC248:
	.string	"constant.GIT_CHECKOUT_NONE="
	.align	3
.LC249:
	.string	"constant_size.GIT_CHECKOUT_NONE=%zu\n"
	.align	3
.LC250:
	.string	"constant_signed.GIT_CHECKOUT_NONE=%d\n"
	.align	3
.LC251:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_ALL=%zu\n"
	.align	3
.LC252:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_ALL=%d\n"
	.align	3
.LC253:
	.string	"constant.GIT_CHECKOUT_NOTIFY_ALL="
	.align	3
.LC254:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_ALL=%zu\n"
	.align	3
.LC255:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_ALL=%d\n"
	.align	3
.LC256:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_CONFLICT=%zu\n"
	.align	3
.LC257:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_CONFLICT=%d\n"
	.align	3
.LC258:
	.string	"constant.GIT_CHECKOUT_NOTIFY_CONFLICT="
	.align	3
.LC259:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_CONFLICT=%zu\n"
	.align	3
.LC260:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_CONFLICT=%d\n"
	.align	3
.LC261:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_DIRTY=%zu\n"
	.align	3
.LC262:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_DIRTY=%d\n"
	.align	3
.LC263:
	.string	"constant.GIT_CHECKOUT_NOTIFY_DIRTY="
	.align	3
.LC264:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_DIRTY=%zu\n"
	.align	3
.LC265:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_DIRTY=%d\n"
	.align	3
.LC266:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_IGNORED=%zu\n"
	.align	3
.LC267:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_IGNORED=%d\n"
	.align	3
.LC268:
	.string	"constant.GIT_CHECKOUT_NOTIFY_IGNORED="
	.align	3
.LC269:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_IGNORED=%zu\n"
	.align	3
.LC270:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_IGNORED=%d\n"
	.align	3
.LC271:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_NONE=%zu\n"
	.align	3
.LC272:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_NONE=%d\n"
	.align	3
.LC273:
	.string	"constant.GIT_CHECKOUT_NOTIFY_NONE="
	.align	3
.LC274:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_NONE=%zu\n"
	.align	3
.LC275:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_NONE=%d\n"
	.align	3
.LC276:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_UNTRACKED=%zu\n"
	.align	3
.LC277:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_UNTRACKED=%d\n"
	.align	3
.LC278:
	.string	"constant.GIT_CHECKOUT_NOTIFY_UNTRACKED="
	.align	3
.LC279:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_UNTRACKED=%zu\n"
	.align	3
.LC280:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_UNTRACKED=%d\n"
	.align	3
.LC281:
	.string	"enum_expression_size.GIT_CHECKOUT_NOTIFY_UPDATED=%zu\n"
	.align	3
.LC282:
	.string	"enum_expression_signed.GIT_CHECKOUT_NOTIFY_UPDATED=%d\n"
	.align	3
.LC283:
	.string	"constant.GIT_CHECKOUT_NOTIFY_UPDATED="
	.align	3
.LC284:
	.string	"constant_size.GIT_CHECKOUT_NOTIFY_UPDATED=%zu\n"
	.align	3
.LC285:
	.string	"constant_signed.GIT_CHECKOUT_NOTIFY_UPDATED=%d\n"
	.align	3
.LC286:
	.string	"enum_expression_size.GIT_CHECKOUT_NO_REFRESH=%zu\n"
	.align	3
.LC287:
	.string	"enum_expression_signed.GIT_CHECKOUT_NO_REFRESH=%d\n"
	.align	3
.LC288:
	.string	"constant.GIT_CHECKOUT_NO_REFRESH="
	.align	3
.LC289:
	.string	"constant_size.GIT_CHECKOUT_NO_REFRESH=%zu\n"
	.align	3
.LC290:
	.string	"constant_signed.GIT_CHECKOUT_NO_REFRESH=%d\n"
	.align	3
.LC291:
	.string	"enum_expression_size.GIT_CHECKOUT_RECREATE_MISSING=%zu\n"
	.align	3
.LC292:
	.string	"enum_expression_signed.GIT_CHECKOUT_RECREATE_MISSING=%d\n"
	.align	3
.LC293:
	.string	"constant.GIT_CHECKOUT_RECREATE_MISSING="
	.align	3
.LC294:
	.string	"constant_size.GIT_CHECKOUT_RECREATE_MISSING=%zu\n"
	.align	3
.LC295:
	.string	"constant_signed.GIT_CHECKOUT_RECREATE_MISSING=%d\n"
	.align	3
.LC296:
	.string	"enum_expression_size.GIT_CHECKOUT_REMOVE_IGNORED=%zu\n"
	.align	3
.LC297:
	.string	"enum_expression_signed.GIT_CHECKOUT_REMOVE_IGNORED=%d\n"
	.align	3
.LC298:
	.string	"constant.GIT_CHECKOUT_REMOVE_IGNORED="
	.align	3
.LC299:
	.string	"constant_size.GIT_CHECKOUT_REMOVE_IGNORED=%zu\n"
	.align	3
.LC300:
	.string	"constant_signed.GIT_CHECKOUT_REMOVE_IGNORED=%d\n"
	.align	3
.LC301:
	.string	"enum_expression_size.GIT_CHECKOUT_REMOVE_UNTRACKED=%zu\n"
	.align	3
.LC302:
	.string	"enum_expression_signed.GIT_CHECKOUT_REMOVE_UNTRACKED=%d\n"
	.align	3
.LC303:
	.string	"constant.GIT_CHECKOUT_REMOVE_UNTRACKED="
	.align	3
.LC304:
	.string	"constant_size.GIT_CHECKOUT_REMOVE_UNTRACKED=%zu\n"
	.align	3
.LC305:
	.string	"constant_signed.GIT_CHECKOUT_REMOVE_UNTRACKED=%d\n"
	.align	3
.LC306:
	.string	"enum_expression_size.GIT_CHECKOUT_SAFE=%zu\n"
	.align	3
.LC307:
	.string	"enum_expression_signed.GIT_CHECKOUT_SAFE=%d\n"
	.align	3
.LC308:
	.string	"constant.GIT_CHECKOUT_SAFE="
	.align	3
.LC309:
	.string	"constant_size.GIT_CHECKOUT_SAFE=%zu\n"
	.align	3
.LC310:
	.string	"constant_signed.GIT_CHECKOUT_SAFE=%d\n"
	.align	3
.LC311:
	.string	"enum_expression_size.GIT_CHECKOUT_SKIP_LOCKED_DIRECTORIES=%zu\n"
	.align	3
.LC312:
	.string	"enum_expression_signed.GIT_CHECKOUT_SKIP_LOCKED_DIRECTORIES=%d\n"
	.align	3
.LC313:
	.string	"constant.GIT_CHECKOUT_SKIP_LOCKED_DIRECTORIES="
	.align	3
.LC314:
	.string	"constant_size.GIT_CHECKOUT_SKIP_LOCKED_DIRECTORIES=%zu\n"
	.align	3
.LC315:
	.string	"constant_signed.GIT_CHECKOUT_SKIP_LOCKED_DIRECTORIES=%d\n"
	.align	3
.LC316:
	.string	"enum_expression_size.GIT_CHECKOUT_SKIP_UNMERGED=%zu\n"
	.align	3
.LC317:
	.string	"enum_expression_signed.GIT_CHECKOUT_SKIP_UNMERGED=%d\n"
	.align	3
.LC318:
	.string	"constant.GIT_CHECKOUT_SKIP_UNMERGED="
	.align	3
.LC319:
	.string	"constant_size.GIT_CHECKOUT_SKIP_UNMERGED=%zu\n"
	.align	3
.LC320:
	.string	"constant_signed.GIT_CHECKOUT_SKIP_UNMERGED=%d\n"
	.align	3
.LC321:
	.string	"enum_expression_size.GIT_CHECKOUT_UPDATE_ONLY=%zu\n"
	.align	3
.LC322:
	.string	"enum_expression_signed.GIT_CHECKOUT_UPDATE_ONLY=%d\n"
	.align	3
.LC323:
	.string	"constant.GIT_CHECKOUT_UPDATE_ONLY="
	.align	3
.LC324:
	.string	"constant_size.GIT_CHECKOUT_UPDATE_ONLY=%zu\n"
	.align	3
.LC325:
	.string	"constant_signed.GIT_CHECKOUT_UPDATE_ONLY=%d\n"
	.align	3
.LC326:
	.string	"enum_expression_size.GIT_CHECKOUT_UPDATE_SUBMODULES=%zu\n"
	.align	3
.LC327:
	.string	"enum_expression_signed.GIT_CHECKOUT_UPDATE_SUBMODULES=%d\n"
	.align	3
.LC328:
	.string	"constant.GIT_CHECKOUT_UPDATE_SUBMODULES="
	.align	3
.LC329:
	.string	"constant_size.GIT_CHECKOUT_UPDATE_SUBMODULES=%zu\n"
	.align	3
.LC330:
	.string	"constant_signed.GIT_CHECKOUT_UPDATE_SUBMODULES=%d\n"
	.align	3
.LC331:
	.string	"enum_expression_size.GIT_CHECKOUT_UPDATE_SUBMODULES_IF_CHANGED=%zu\n"
	.align	3
.LC332:
	.string	"enum_expression_signed.GIT_CHECKOUT_UPDATE_SUBMODULES_IF_CHANGED=%d\n"
	.align	3
.LC333:
	.string	"constant.GIT_CHECKOUT_UPDATE_SUBMODULES_IF_CHANGED="
	.align	3
.LC334:
	.string	"constant_size.GIT_CHECKOUT_UPDATE_SUBMODULES_IF_CHANGED=%zu\n"
	.align	3
.LC335:
	.string	"constant_signed.GIT_CHECKOUT_UPDATE_SUBMODULES_IF_CHANGED=%d\n"
	.align	3
.LC336:
	.string	"enum_expression_size.GIT_CHECKOUT_USE_OURS=%zu\n"
	.align	3
.LC337:
	.string	"enum_expression_signed.GIT_CHECKOUT_USE_OURS=%d\n"
	.align	3
.LC338:
	.string	"constant.GIT_CHECKOUT_USE_OURS="
	.align	3
.LC339:
	.string	"constant_size.GIT_CHECKOUT_USE_OURS=%zu\n"
	.align	3
.LC340:
	.string	"constant_signed.GIT_CHECKOUT_USE_OURS=%d\n"
	.align	3
.LC341:
	.string	"enum_expression_size.GIT_CHECKOUT_USE_THEIRS=%zu\n"
	.align	3
.LC342:
	.string	"enum_expression_signed.GIT_CHECKOUT_USE_THEIRS=%d\n"
	.align	3
.LC343:
	.string	"constant.GIT_CHECKOUT_USE_THEIRS="
	.align	3
.LC344:
	.string	"constant_size.GIT_CHECKOUT_USE_THEIRS=%zu\n"
	.align	3
.LC345:
	.string	"constant_signed.GIT_CHECKOUT_USE_THEIRS=%d\n"
	.align	3
.LC346:
	.string	"enum_expression_size.GIT_CLONE_LOCAL=%zu\n"
	.align	3
.LC347:
	.string	"enum_expression_signed.GIT_CLONE_LOCAL=%d\n"
	.align	3
.LC348:
	.string	"constant.GIT_CLONE_LOCAL="
	.align	3
.LC349:
	.string	"constant_size.GIT_CLONE_LOCAL=%zu\n"
	.align	3
.LC350:
	.string	"constant_signed.GIT_CLONE_LOCAL=%d\n"
	.align	3
.LC351:
	.string	"enum_expression_size.GIT_CLONE_LOCAL_AUTO=%zu\n"
	.align	3
.LC352:
	.string	"enum_expression_signed.GIT_CLONE_LOCAL_AUTO=%d\n"
	.align	3
.LC353:
	.string	"constant.GIT_CLONE_LOCAL_AUTO="
	.align	3
.LC354:
	.string	"constant_size.GIT_CLONE_LOCAL_AUTO=%zu\n"
	.align	3
.LC355:
	.string	"constant_signed.GIT_CLONE_LOCAL_AUTO=%d\n"
	.align	3
.LC356:
	.string	"enum_expression_size.GIT_CLONE_LOCAL_NO_LINKS=%zu\n"
	.align	3
.LC357:
	.string	"enum_expression_signed.GIT_CLONE_LOCAL_NO_LINKS=%d\n"
	.align	3
.LC358:
	.string	"constant.GIT_CLONE_LOCAL_NO_LINKS="
	.align	3
.LC359:
	.string	"constant_size.GIT_CLONE_LOCAL_NO_LINKS=%zu\n"
	.align	3
.LC360:
	.string	"constant_signed.GIT_CLONE_LOCAL_NO_LINKS=%d\n"
	.align	3
.LC361:
	.string	"enum_expression_size.GIT_CLONE_NO_LOCAL=%zu\n"
	.align	3
.LC362:
	.string	"enum_expression_signed.GIT_CLONE_NO_LOCAL=%d\n"
	.align	3
.LC363:
	.string	"constant.GIT_CLONE_NO_LOCAL="
	.align	3
.LC364:
	.string	"constant_size.GIT_CLONE_NO_LOCAL=%zu\n"
	.align	3
.LC365:
	.string	"constant_signed.GIT_CLONE_NO_LOCAL=%d\n"
	.align	3
.LC366:
	.string	"enum_expression_size.GIT_CONFIGMAP_FALSE=%zu\n"
	.align	3
.LC367:
	.string	"enum_expression_signed.GIT_CONFIGMAP_FALSE=%d\n"
	.align	3
.LC368:
	.string	"constant.GIT_CONFIGMAP_FALSE="
	.align	3
.LC369:
	.string	"constant_size.GIT_CONFIGMAP_FALSE=%zu\n"
	.align	3
.LC370:
	.string	"constant_signed.GIT_CONFIGMAP_FALSE=%d\n"
	.align	3
.LC371:
	.string	"enum_expression_size.GIT_CONFIGMAP_INT32=%zu\n"
	.align	3
.LC372:
	.string	"enum_expression_signed.GIT_CONFIGMAP_INT32=%d\n"
	.align	3
.LC373:
	.string	"constant.GIT_CONFIGMAP_INT32="
	.align	3
.LC374:
	.string	"constant_size.GIT_CONFIGMAP_INT32=%zu\n"
	.align	3
.LC375:
	.string	"constant_signed.GIT_CONFIGMAP_INT32=%d\n"
	.align	3
.LC376:
	.string	"enum_expression_size.GIT_CONFIGMAP_STRING=%zu\n"
	.align	3
.LC377:
	.string	"enum_expression_signed.GIT_CONFIGMAP_STRING=%d\n"
	.align	3
.LC378:
	.string	"constant.GIT_CONFIGMAP_STRING="
	.align	3
.LC379:
	.string	"constant_size.GIT_CONFIGMAP_STRING=%zu\n"
	.align	3
.LC380:
	.string	"constant_signed.GIT_CONFIGMAP_STRING=%d\n"
	.align	3
.LC381:
	.string	"enum_expression_size.GIT_CONFIGMAP_TRUE=%zu\n"
	.align	3
.LC382:
	.string	"enum_expression_signed.GIT_CONFIGMAP_TRUE=%d\n"
	.align	3
.LC383:
	.string	"constant.GIT_CONFIGMAP_TRUE="
	.align	3
.LC384:
	.string	"constant_size.GIT_CONFIGMAP_TRUE=%zu\n"
	.align	3
.LC385:
	.string	"constant_signed.GIT_CONFIGMAP_TRUE=%d\n"
	.align	3
.LC386:
	.string	"enum_expression_size.GIT_CONFIG_HIGHEST_LEVEL=%zu\n"
	.align	3
.LC387:
	.string	"enum_expression_signed.GIT_CONFIG_HIGHEST_LEVEL=%d\n"
	.align	3
.LC388:
	.string	"constant.GIT_CONFIG_HIGHEST_LEVEL="
	.align	3
.LC389:
	.string	"constant_size.GIT_CONFIG_HIGHEST_LEVEL=%zu\n"
	.align	3
.LC390:
	.string	"constant_signed.GIT_CONFIG_HIGHEST_LEVEL=%d\n"
	.align	3
.LC391:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_APP=%zu\n"
	.align	3
.LC392:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_APP=%d\n"
	.align	3
.LC393:
	.string	"constant.GIT_CONFIG_LEVEL_APP="
	.align	3
.LC394:
	.string	"constant_size.GIT_CONFIG_LEVEL_APP=%zu\n"
	.align	3
.LC395:
	.string	"constant_signed.GIT_CONFIG_LEVEL_APP=%d\n"
	.align	3
.LC396:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_GLOBAL=%zu\n"
	.align	3
.LC397:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_GLOBAL=%d\n"
	.align	3
.LC398:
	.string	"constant.GIT_CONFIG_LEVEL_GLOBAL="
	.align	3
.LC399:
	.string	"constant_size.GIT_CONFIG_LEVEL_GLOBAL=%zu\n"
	.align	3
.LC400:
	.string	"constant_signed.GIT_CONFIG_LEVEL_GLOBAL=%d\n"
	.align	3
.LC401:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_LOCAL=%zu\n"
	.align	3
.LC402:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_LOCAL=%d\n"
	.align	3
.LC403:
	.string	"constant.GIT_CONFIG_LEVEL_LOCAL="
	.align	3
.LC404:
	.string	"constant_size.GIT_CONFIG_LEVEL_LOCAL=%zu\n"
	.align	3
.LC405:
	.string	"constant_signed.GIT_CONFIG_LEVEL_LOCAL=%d\n"
	.align	3
.LC406:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_PROGRAMDATA=%zu\n"
	.align	3
.LC407:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_PROGRAMDATA=%d\n"
	.align	3
.LC408:
	.string	"constant.GIT_CONFIG_LEVEL_PROGRAMDATA="
	.align	3
.LC409:
	.string	"constant_size.GIT_CONFIG_LEVEL_PROGRAMDATA=%zu\n"
	.align	3
.LC410:
	.string	"constant_signed.GIT_CONFIG_LEVEL_PROGRAMDATA=%d\n"
	.align	3
.LC411:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_SYSTEM=%zu\n"
	.align	3
.LC412:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_SYSTEM=%d\n"
	.align	3
.LC413:
	.string	"constant.GIT_CONFIG_LEVEL_SYSTEM="
	.align	3
.LC414:
	.string	"constant_size.GIT_CONFIG_LEVEL_SYSTEM=%zu\n"
	.align	3
.LC415:
	.string	"constant_signed.GIT_CONFIG_LEVEL_SYSTEM=%d\n"
	.align	3
.LC416:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_WORKTREE=%zu\n"
	.align	3
.LC417:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_WORKTREE=%d\n"
	.align	3
.LC418:
	.string	"constant.GIT_CONFIG_LEVEL_WORKTREE="
	.align	3
.LC419:
	.string	"constant_size.GIT_CONFIG_LEVEL_WORKTREE=%zu\n"
	.align	3
.LC420:
	.string	"constant_signed.GIT_CONFIG_LEVEL_WORKTREE=%d\n"
	.align	3
.LC421:
	.string	"enum_expression_size.GIT_CONFIG_LEVEL_XDG=%zu\n"
	.align	3
.LC422:
	.string	"enum_expression_signed.GIT_CONFIG_LEVEL_XDG=%d\n"
	.align	3
.LC423:
	.string	"constant.GIT_CONFIG_LEVEL_XDG="
	.align	3
.LC424:
	.string	"constant_size.GIT_CONFIG_LEVEL_XDG=%zu\n"
	.align	3
.LC425:
	.string	"constant_signed.GIT_CONFIG_LEVEL_XDG=%d\n"
	.align	3
.LC426:
	.string	"enum_expression_size.GIT_CREDENTIAL_DEFAULT=%zu\n"
	.align	3
.LC427:
	.string	"enum_expression_signed.GIT_CREDENTIAL_DEFAULT=%d\n"
	.align	3
.LC428:
	.string	"constant.GIT_CREDENTIAL_DEFAULT="
	.align	3
.LC429:
	.string	"constant_size.GIT_CREDENTIAL_DEFAULT=%zu\n"
	.align	3
.LC430:
	.string	"constant_signed.GIT_CREDENTIAL_DEFAULT=%d\n"
	.align	3
.LC431:
	.string	"enum_expression_size.GIT_CREDENTIAL_SSH_CUSTOM=%zu\n"
	.align	3
.LC432:
	.string	"enum_expression_signed.GIT_CREDENTIAL_SSH_CUSTOM=%d\n"
	.align	3
.LC433:
	.string	"constant.GIT_CREDENTIAL_SSH_CUSTOM="
	.align	3
.LC434:
	.string	"constant_size.GIT_CREDENTIAL_SSH_CUSTOM=%zu\n"
	.align	3
.LC435:
	.string	"constant_signed.GIT_CREDENTIAL_SSH_CUSTOM=%d\n"
	.align	3
.LC436:
	.string	"enum_expression_size.GIT_CREDENTIAL_SSH_INTERACTIVE=%zu\n"
	.align	3
.LC437:
	.string	"enum_expression_signed.GIT_CREDENTIAL_SSH_INTERACTIVE=%d\n"
	.align	3
.LC438:
	.string	"constant.GIT_CREDENTIAL_SSH_INTERACTIVE="
	.align	3
.LC439:
	.string	"constant_size.GIT_CREDENTIAL_SSH_INTERACTIVE=%zu\n"
	.align	3
.LC440:
	.string	"constant_signed.GIT_CREDENTIAL_SSH_INTERACTIVE=%d\n"
	.align	3
.LC441:
	.string	"enum_expression_size.GIT_CREDENTIAL_SSH_KEY=%zu\n"
	.align	3
.LC442:
	.string	"enum_expression_signed.GIT_CREDENTIAL_SSH_KEY=%d\n"
	.align	3
.LC443:
	.string	"constant.GIT_CREDENTIAL_SSH_KEY="
	.align	3
.LC444:
	.string	"constant_size.GIT_CREDENTIAL_SSH_KEY=%zu\n"
	.align	3
.LC445:
	.string	"constant_signed.GIT_CREDENTIAL_SSH_KEY=%d\n"
	.align	3
.LC446:
	.string	"enum_expression_size.GIT_CREDENTIAL_SSH_MEMORY=%zu\n"
	.align	3
.LC447:
	.string	"enum_expression_signed.GIT_CREDENTIAL_SSH_MEMORY=%d\n"
	.align	3
.LC448:
	.string	"constant.GIT_CREDENTIAL_SSH_MEMORY="
	.align	3
.LC449:
	.string	"constant_size.GIT_CREDENTIAL_SSH_MEMORY=%zu\n"
	.align	3
.LC450:
	.string	"constant_signed.GIT_CREDENTIAL_SSH_MEMORY=%d\n"
	.align	3
.LC451:
	.string	"enum_expression_size.GIT_CREDENTIAL_USERNAME=%zu\n"
	.align	3
.LC452:
	.string	"enum_expression_signed.GIT_CREDENTIAL_USERNAME=%d\n"
	.align	3
.LC453:
	.string	"constant.GIT_CREDENTIAL_USERNAME="
	.align	3
.LC454:
	.string	"constant_size.GIT_CREDENTIAL_USERNAME=%zu\n"
	.align	3
.LC455:
	.string	"constant_signed.GIT_CREDENTIAL_USERNAME=%d\n"
	.align	3
.LC456:
	.string	"enum_expression_size.GIT_CREDENTIAL_USERPASS_PLAINTEXT=%zu\n"
	.align	3
.LC457:
	.string	"enum_expression_signed.GIT_CREDENTIAL_USERPASS_PLAINTEXT=%d\n"
	.align	3
.LC458:
	.string	"constant.GIT_CREDENTIAL_USERPASS_PLAINTEXT="
	.align	3
.LC459:
	.string	"constant_size.GIT_CREDENTIAL_USERPASS_PLAINTEXT=%zu\n"
	.align	3
.LC460:
	.string	"constant_signed.GIT_CREDENTIAL_USERPASS_PLAINTEXT=%d\n"
	.align	3
.LC461:
	.string	"enum_expression_size.GIT_DELTA_ADDED=%zu\n"
	.align	3
.LC462:
	.string	"enum_expression_signed.GIT_DELTA_ADDED=%d\n"
	.align	3
.LC463:
	.string	"constant.GIT_DELTA_ADDED="
	.align	3
.LC464:
	.string	"constant_size.GIT_DELTA_ADDED=%zu\n"
	.align	3
.LC465:
	.string	"constant_signed.GIT_DELTA_ADDED=%d\n"
	.align	3
.LC466:
	.string	"enum_expression_size.GIT_DELTA_CONFLICTED=%zu\n"
	.align	3
.LC467:
	.string	"enum_expression_signed.GIT_DELTA_CONFLICTED=%d\n"
	.align	3
.LC468:
	.string	"constant.GIT_DELTA_CONFLICTED="
	.align	3
.LC469:
	.string	"constant_size.GIT_DELTA_CONFLICTED=%zu\n"
	.align	3
.LC470:
	.string	"constant_signed.GIT_DELTA_CONFLICTED=%d\n"
	.align	3
.LC471:
	.string	"enum_expression_size.GIT_DELTA_COPIED=%zu\n"
	.align	3
.LC472:
	.string	"enum_expression_signed.GIT_DELTA_COPIED=%d\n"
	.align	3
.LC473:
	.string	"constant.GIT_DELTA_COPIED="
	.align	3
.LC474:
	.string	"constant_size.GIT_DELTA_COPIED=%zu\n"
	.align	3
.LC475:
	.string	"constant_signed.GIT_DELTA_COPIED=%d\n"
	.align	3
.LC476:
	.string	"enum_expression_size.GIT_DELTA_DELETED=%zu\n"
	.align	3
.LC477:
	.string	"enum_expression_signed.GIT_DELTA_DELETED=%d\n"
	.align	3
.LC478:
	.string	"constant.GIT_DELTA_DELETED="
	.align	3
.LC479:
	.string	"constant_size.GIT_DELTA_DELETED=%zu\n"
	.align	3
.LC480:
	.string	"constant_signed.GIT_DELTA_DELETED=%d\n"
	.align	3
.LC481:
	.string	"enum_expression_size.GIT_DELTA_IGNORED=%zu\n"
	.align	3
.LC482:
	.string	"enum_expression_signed.GIT_DELTA_IGNORED=%d\n"
	.align	3
.LC483:
	.string	"constant.GIT_DELTA_IGNORED="
	.align	3
.LC484:
	.string	"constant_size.GIT_DELTA_IGNORED=%zu\n"
	.align	3
.LC485:
	.string	"constant_signed.GIT_DELTA_IGNORED=%d\n"
	.align	3
.LC486:
	.string	"enum_expression_size.GIT_DELTA_MODIFIED=%zu\n"
	.align	3
.LC487:
	.string	"enum_expression_signed.GIT_DELTA_MODIFIED=%d\n"
	.align	3
.LC488:
	.string	"constant.GIT_DELTA_MODIFIED="
	.align	3
.LC489:
	.string	"constant_size.GIT_DELTA_MODIFIED=%zu\n"
	.align	3
.LC490:
	.string	"constant_signed.GIT_DELTA_MODIFIED=%d\n"
	.align	3
.LC491:
	.string	"enum_expression_size.GIT_DELTA_RENAMED=%zu\n"
	.align	3
.LC492:
	.string	"enum_expression_signed.GIT_DELTA_RENAMED=%d\n"
	.align	3
.LC493:
	.string	"constant.GIT_DELTA_RENAMED="
	.align	3
.LC494:
	.string	"constant_size.GIT_DELTA_RENAMED=%zu\n"
	.align	3
.LC495:
	.string	"constant_signed.GIT_DELTA_RENAMED=%d\n"
	.align	3
.LC496:
	.string	"enum_expression_size.GIT_DELTA_TYPECHANGE=%zu\n"
	.align	3
.LC497:
	.string	"enum_expression_signed.GIT_DELTA_TYPECHANGE=%d\n"
	.align	3
.LC498:
	.string	"constant.GIT_DELTA_TYPECHANGE="
	.align	3
.LC499:
	.string	"constant_size.GIT_DELTA_TYPECHANGE=%zu\n"
	.align	3
.LC500:
	.string	"constant_signed.GIT_DELTA_TYPECHANGE=%d\n"
	.align	3
.LC501:
	.string	"enum_expression_size.GIT_DELTA_UNMODIFIED=%zu\n"
	.align	3
.LC502:
	.string	"enum_expression_signed.GIT_DELTA_UNMODIFIED=%d\n"
	.align	3
.LC503:
	.string	"constant.GIT_DELTA_UNMODIFIED="
	.align	3
.LC504:
	.string	"constant_size.GIT_DELTA_UNMODIFIED=%zu\n"
	.align	3
.LC505:
	.string	"constant_signed.GIT_DELTA_UNMODIFIED=%d\n"
	.align	3
.LC506:
	.string	"enum_expression_size.GIT_DELTA_UNREADABLE=%zu\n"
	.align	3
.LC507:
	.string	"enum_expression_signed.GIT_DELTA_UNREADABLE=%d\n"
	.align	3
.LC508:
	.string	"constant.GIT_DELTA_UNREADABLE="
	.align	3
.LC509:
	.string	"constant_size.GIT_DELTA_UNREADABLE=%zu\n"
	.align	3
.LC510:
	.string	"constant_signed.GIT_DELTA_UNREADABLE=%d\n"
	.align	3
.LC511:
	.string	"enum_expression_size.GIT_DELTA_UNTRACKED=%zu\n"
	.align	3
.LC512:
	.string	"enum_expression_signed.GIT_DELTA_UNTRACKED=%d\n"
	.align	3
.LC513:
	.string	"constant.GIT_DELTA_UNTRACKED="
	.align	3
.LC514:
	.string	"constant_size.GIT_DELTA_UNTRACKED=%zu\n"
	.align	3
.LC515:
	.string	"constant_signed.GIT_DELTA_UNTRACKED=%d\n"
	.align	3
.LC516:
	.string	"enum_expression_size.GIT_DESCRIBE_ALL=%zu\n"
	.align	3
.LC517:
	.string	"enum_expression_signed.GIT_DESCRIBE_ALL=%d\n"
	.align	3
.LC518:
	.string	"constant.GIT_DESCRIBE_ALL="
	.align	3
.LC519:
	.string	"constant_size.GIT_DESCRIBE_ALL=%zu\n"
	.align	3
.LC520:
	.string	"constant_signed.GIT_DESCRIBE_ALL=%d\n"
	.align	3
.LC521:
	.string	"enum_expression_size.GIT_DESCRIBE_DEFAULT=%zu\n"
	.align	3
.LC522:
	.string	"enum_expression_signed.GIT_DESCRIBE_DEFAULT=%d\n"
	.align	3
.LC523:
	.string	"constant.GIT_DESCRIBE_DEFAULT="
	.align	3
.LC524:
	.string	"constant_size.GIT_DESCRIBE_DEFAULT=%zu\n"
	.align	3
.LC525:
	.string	"constant_signed.GIT_DESCRIBE_DEFAULT=%d\n"
	.align	3
.LC526:
	.string	"enum_expression_size.GIT_DESCRIBE_TAGS=%zu\n"
	.align	3
.LC527:
	.string	"enum_expression_signed.GIT_DESCRIBE_TAGS=%d\n"
	.align	3
.LC528:
	.string	"constant.GIT_DESCRIBE_TAGS="
	.align	3
.LC529:
	.string	"constant_size.GIT_DESCRIBE_TAGS=%zu\n"
	.align	3
.LC530:
	.string	"constant_signed.GIT_DESCRIBE_TAGS=%d\n"
	.align	3
.LC531:
	.string	"enum_expression_size.GIT_DIFF_BINARY_DELTA=%zu\n"
	.align	3
.LC532:
	.string	"enum_expression_signed.GIT_DIFF_BINARY_DELTA=%d\n"
	.align	3
.LC533:
	.string	"constant.GIT_DIFF_BINARY_DELTA="
	.align	3
.LC534:
	.string	"constant_size.GIT_DIFF_BINARY_DELTA=%zu\n"
	.align	3
.LC535:
	.string	"constant_signed.GIT_DIFF_BINARY_DELTA=%d\n"
	.align	3
.LC536:
	.string	"enum_expression_size.GIT_DIFF_BINARY_LITERAL=%zu\n"
	.align	3
.LC537:
	.string	"enum_expression_signed.GIT_DIFF_BINARY_LITERAL=%d\n"
	.align	3
.LC538:
	.string	"constant.GIT_DIFF_BINARY_LITERAL="
	.align	3
.LC539:
	.string	"constant_size.GIT_DIFF_BINARY_LITERAL=%zu\n"
	.align	3
.LC540:
	.string	"constant_signed.GIT_DIFF_BINARY_LITERAL=%d\n"
	.align	3
.LC541:
	.string	"enum_expression_size.GIT_DIFF_BINARY_NONE=%zu\n"
	.align	3
.LC542:
	.string	"enum_expression_signed.GIT_DIFF_BINARY_NONE=%d\n"
	.align	3
.LC543:
	.string	"constant.GIT_DIFF_BINARY_NONE="
	.align	3
.LC544:
	.string	"constant_size.GIT_DIFF_BINARY_NONE=%zu\n"
	.align	3
.LC545:
	.string	"constant_signed.GIT_DIFF_BINARY_NONE=%d\n"
	.align	3
.LC546:
	.string	"enum_expression_size.GIT_DIFF_BREAK_REWRITES=%zu\n"
	.align	3
.LC547:
	.string	"enum_expression_signed.GIT_DIFF_BREAK_REWRITES=%d\n"
	.align	3
.LC548:
	.string	"constant.GIT_DIFF_BREAK_REWRITES="
	.align	3
.LC549:
	.string	"constant_size.GIT_DIFF_BREAK_REWRITES=%zu\n"
	.align	3
.LC550:
	.string	"constant_signed.GIT_DIFF_BREAK_REWRITES=%d\n"
	.align	3
.LC551:
	.string	"enum_expression_size.GIT_DIFF_BREAK_REWRITES_FOR_RENAMES_ONLY=%zu\n"
	.align	3
.LC552:
	.string	"enum_expression_signed.GIT_DIFF_BREAK_REWRITES_FOR_RENAMES_ONLY=%d\n"
	.align	3
.LC553:
	.string	"constant.GIT_DIFF_BREAK_REWRITES_FOR_RENAMES_ONLY="
	.align	3
.LC554:
	.string	"constant_size.GIT_DIFF_BREAK_REWRITES_FOR_RENAMES_ONLY=%zu\n"
	.align	3
.LC555:
	.string	"constant_signed.GIT_DIFF_BREAK_REWRITES_FOR_RENAMES_ONLY=%d\n"
	.align	3
.LC556:
	.string	"enum_expression_size.GIT_DIFF_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC557:
	.string	"enum_expression_signed.GIT_DIFF_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC558:
	.string	"constant.GIT_DIFF_DISABLE_PATHSPEC_MATCH="
	.align	3
.LC559:
	.string	"constant_size.GIT_DIFF_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC560:
	.string	"constant_signed.GIT_DIFF_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC561:
	.string	"enum_expression_size.GIT_DIFF_ENABLE_FAST_UNTRACKED_DIRS=%zu\n"
	.align	3
.LC562:
	.string	"enum_expression_signed.GIT_DIFF_ENABLE_FAST_UNTRACKED_DIRS=%d\n"
	.align	3
.LC563:
	.string	"constant.GIT_DIFF_ENABLE_FAST_UNTRACKED_DIRS="
	.align	3
.LC564:
	.string	"constant_size.GIT_DIFF_ENABLE_FAST_UNTRACKED_DIRS=%zu\n"
	.align	3
.LC565:
	.string	"constant_signed.GIT_DIFF_ENABLE_FAST_UNTRACKED_DIRS=%d\n"
	.align	3
.LC566:
	.string	"enum_expression_size.GIT_DIFF_FIND_ALL=%zu\n"
	.align	3
.LC567:
	.string	"enum_expression_signed.GIT_DIFF_FIND_ALL=%d\n"
	.align	3
.LC568:
	.string	"constant.GIT_DIFF_FIND_ALL="
	.align	3
.LC569:
	.string	"constant_size.GIT_DIFF_FIND_ALL=%zu\n"
	.align	3
.LC570:
	.string	"constant_signed.GIT_DIFF_FIND_ALL=%d\n"
	.align	3
.LC571:
	.string	"enum_expression_size.GIT_DIFF_FIND_AND_BREAK_REWRITES=%zu\n"
	.align	3
.LC572:
	.string	"enum_expression_signed.GIT_DIFF_FIND_AND_BREAK_REWRITES=%d\n"
	.align	3
.LC573:
	.string	"constant.GIT_DIFF_FIND_AND_BREAK_REWRITES="
	.align	3
.LC574:
	.string	"constant_size.GIT_DIFF_FIND_AND_BREAK_REWRITES=%zu\n"
	.align	3
.LC575:
	.string	"constant_signed.GIT_DIFF_FIND_AND_BREAK_REWRITES=%d\n"
	.align	3
.LC576:
	.string	"enum_expression_size.GIT_DIFF_FIND_BY_CONFIG=%zu\n"
	.align	3
.LC577:
	.string	"enum_expression_signed.GIT_DIFF_FIND_BY_CONFIG=%d\n"
	.align	3
.LC578:
	.string	"constant.GIT_DIFF_FIND_BY_CONFIG="
	.align	3
.LC579:
	.string	"constant_size.GIT_DIFF_FIND_BY_CONFIG=%zu\n"
	.align	3
.LC580:
	.string	"constant_signed.GIT_DIFF_FIND_BY_CONFIG=%d\n"
	.align	3
.LC581:
	.string	"enum_expression_size.GIT_DIFF_FIND_COPIES=%zu\n"
	.align	3
.LC582:
	.string	"enum_expression_signed.GIT_DIFF_FIND_COPIES=%d\n"
	.align	3
.LC583:
	.string	"constant.GIT_DIFF_FIND_COPIES="
	.align	3
.LC584:
	.string	"constant_size.GIT_DIFF_FIND_COPIES=%zu\n"
	.align	3
.LC585:
	.string	"constant_signed.GIT_DIFF_FIND_COPIES=%d\n"
	.align	3
.LC586:
	.string	"enum_expression_size.GIT_DIFF_FIND_COPIES_FROM_UNMODIFIED=%zu\n"
	.align	3
.LC587:
	.string	"enum_expression_signed.GIT_DIFF_FIND_COPIES_FROM_UNMODIFIED=%d\n"
	.align	3
.LC588:
	.string	"constant.GIT_DIFF_FIND_COPIES_FROM_UNMODIFIED="
	.align	3
.LC589:
	.string	"constant_size.GIT_DIFF_FIND_COPIES_FROM_UNMODIFIED=%zu\n"
	.align	3
.LC590:
	.string	"constant_signed.GIT_DIFF_FIND_COPIES_FROM_UNMODIFIED=%d\n"
	.align	3
.LC591:
	.string	"enum_expression_size.GIT_DIFF_FIND_DONT_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC592:
	.string	"enum_expression_signed.GIT_DIFF_FIND_DONT_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC593:
	.string	"constant.GIT_DIFF_FIND_DONT_IGNORE_WHITESPACE="
	.align	3
.LC594:
	.string	"constant_size.GIT_DIFF_FIND_DONT_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC595:
	.string	"constant_signed.GIT_DIFF_FIND_DONT_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC596:
	.string	"enum_expression_size.GIT_DIFF_FIND_EXACT_MATCH_ONLY=%zu\n"
	.align	3
.LC597:
	.string	"enum_expression_signed.GIT_DIFF_FIND_EXACT_MATCH_ONLY=%d\n"
	.align	3
.LC598:
	.string	"constant.GIT_DIFF_FIND_EXACT_MATCH_ONLY="
	.align	3
.LC599:
	.string	"constant_size.GIT_DIFF_FIND_EXACT_MATCH_ONLY=%zu\n"
	.align	3
.LC600:
	.string	"constant_signed.GIT_DIFF_FIND_EXACT_MATCH_ONLY=%d\n"
	.align	3
.LC601:
	.string	"enum_expression_size.GIT_DIFF_FIND_FOR_UNTRACKED=%zu\n"
	.align	3
.LC602:
	.string	"enum_expression_signed.GIT_DIFF_FIND_FOR_UNTRACKED=%d\n"
	.align	3
.LC603:
	.string	"constant.GIT_DIFF_FIND_FOR_UNTRACKED="
	.align	3
.LC604:
	.string	"constant_size.GIT_DIFF_FIND_FOR_UNTRACKED=%zu\n"
	.align	3
.LC605:
	.string	"constant_signed.GIT_DIFF_FIND_FOR_UNTRACKED=%d\n"
	.align	3
.LC606:
	.string	"enum_expression_size.GIT_DIFF_FIND_IGNORE_LEADING_WHITESPACE=%zu\n"
	.align	3
.LC607:
	.string	"enum_expression_signed.GIT_DIFF_FIND_IGNORE_LEADING_WHITESPACE=%d\n"
	.align	3
.LC608:
	.string	"constant.GIT_DIFF_FIND_IGNORE_LEADING_WHITESPACE="
	.align	3
.LC609:
	.string	"constant_size.GIT_DIFF_FIND_IGNORE_LEADING_WHITESPACE=%zu\n"
	.align	3
.LC610:
	.string	"constant_signed.GIT_DIFF_FIND_IGNORE_LEADING_WHITESPACE=%d\n"
	.align	3
.LC611:
	.string	"enum_expression_size.GIT_DIFF_FIND_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC612:
	.string	"enum_expression_signed.GIT_DIFF_FIND_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC613:
	.string	"constant.GIT_DIFF_FIND_IGNORE_WHITESPACE="
	.align	3
.LC614:
	.string	"constant_size.GIT_DIFF_FIND_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC615:
	.string	"constant_signed.GIT_DIFF_FIND_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC616:
	.string	"enum_expression_size.GIT_DIFF_FIND_REMOVE_UNMODIFIED=%zu\n"
	.align	3
.LC617:
	.string	"enum_expression_signed.GIT_DIFF_FIND_REMOVE_UNMODIFIED=%d\n"
	.align	3
.LC618:
	.string	"constant.GIT_DIFF_FIND_REMOVE_UNMODIFIED="
	.align	3
.LC619:
	.string	"constant_size.GIT_DIFF_FIND_REMOVE_UNMODIFIED=%zu\n"
	.align	3
.LC620:
	.string	"constant_signed.GIT_DIFF_FIND_REMOVE_UNMODIFIED=%d\n"
	.align	3
.LC621:
	.string	"enum_expression_size.GIT_DIFF_FIND_RENAMES=%zu\n"
	.align	3
.LC622:
	.string	"enum_expression_signed.GIT_DIFF_FIND_RENAMES=%d\n"
	.align	3
.LC623:
	.string	"constant.GIT_DIFF_FIND_RENAMES="
	.align	3
.LC624:
	.string	"constant_size.GIT_DIFF_FIND_RENAMES=%zu\n"
	.align	3
.LC625:
	.string	"constant_signed.GIT_DIFF_FIND_RENAMES=%d\n"
	.align	3
.LC626:
	.string	"enum_expression_size.GIT_DIFF_FIND_RENAMES_FROM_REWRITES=%zu\n"
	.align	3
.LC627:
	.string	"enum_expression_signed.GIT_DIFF_FIND_RENAMES_FROM_REWRITES=%d\n"
	.align	3
.LC628:
	.string	"constant.GIT_DIFF_FIND_RENAMES_FROM_REWRITES="
	.align	3
.LC629:
	.string	"constant_size.GIT_DIFF_FIND_RENAMES_FROM_REWRITES=%zu\n"
	.align	3
.LC630:
	.string	"constant_signed.GIT_DIFF_FIND_RENAMES_FROM_REWRITES=%d\n"
	.align	3
.LC631:
	.string	"enum_expression_size.GIT_DIFF_FIND_REWRITES=%zu\n"
	.align	3
.LC632:
	.string	"enum_expression_signed.GIT_DIFF_FIND_REWRITES=%d\n"
	.align	3
.LC633:
	.string	"constant.GIT_DIFF_FIND_REWRITES="
	.align	3
.LC634:
	.string	"constant_size.GIT_DIFF_FIND_REWRITES=%zu\n"
	.align	3
.LC635:
	.string	"constant_signed.GIT_DIFF_FIND_REWRITES=%d\n"
	.align	3
.LC636:
	.string	"enum_expression_size.GIT_DIFF_FLAG_BINARY=%zu\n"
	.align	3
.LC637:
	.string	"enum_expression_signed.GIT_DIFF_FLAG_BINARY=%d\n"
	.align	3
.LC638:
	.string	"constant.GIT_DIFF_FLAG_BINARY="
	.align	3
.LC639:
	.string	"constant_size.GIT_DIFF_FLAG_BINARY=%zu\n"
	.align	3
.LC640:
	.string	"constant_signed.GIT_DIFF_FLAG_BINARY=%d\n"
	.align	3
.LC641:
	.string	"enum_expression_size.GIT_DIFF_FLAG_EXISTS=%zu\n"
	.align	3
.LC642:
	.string	"enum_expression_signed.GIT_DIFF_FLAG_EXISTS=%d\n"
	.align	3
.LC643:
	.string	"constant.GIT_DIFF_FLAG_EXISTS="
	.align	3
.LC644:
	.string	"constant_size.GIT_DIFF_FLAG_EXISTS=%zu\n"
	.align	3
.LC645:
	.string	"constant_signed.GIT_DIFF_FLAG_EXISTS=%d\n"
	.align	3
.LC646:
	.string	"enum_expression_size.GIT_DIFF_FLAG_NOT_BINARY=%zu\n"
	.align	3
.LC647:
	.string	"enum_expression_signed.GIT_DIFF_FLAG_NOT_BINARY=%d\n"
	.align	3
.LC648:
	.string	"constant.GIT_DIFF_FLAG_NOT_BINARY="
	.align	3
.LC649:
	.string	"constant_size.GIT_DIFF_FLAG_NOT_BINARY=%zu\n"
	.align	3
.LC650:
	.string	"constant_signed.GIT_DIFF_FLAG_NOT_BINARY=%d\n"
	.align	3
.LC651:
	.string	"enum_expression_size.GIT_DIFF_FLAG_VALID_ID=%zu\n"
	.align	3
.LC652:
	.string	"enum_expression_signed.GIT_DIFF_FLAG_VALID_ID=%d\n"
	.align	3
.LC653:
	.string	"constant.GIT_DIFF_FLAG_VALID_ID="
	.align	3
.LC654:
	.string	"constant_size.GIT_DIFF_FLAG_VALID_ID=%zu\n"
	.align	3
.LC655:
	.string	"constant_signed.GIT_DIFF_FLAG_VALID_ID=%d\n"
	.align	3
.LC656:
	.string	"enum_expression_size.GIT_DIFF_FLAG_VALID_SIZE=%zu\n"
	.align	3
.LC657:
	.string	"enum_expression_signed.GIT_DIFF_FLAG_VALID_SIZE=%d\n"
	.align	3
.LC658:
	.string	"constant.GIT_DIFF_FLAG_VALID_SIZE="
	.align	3
.LC659:
	.string	"constant_size.GIT_DIFF_FLAG_VALID_SIZE=%zu\n"
	.align	3
.LC660:
	.string	"constant_signed.GIT_DIFF_FLAG_VALID_SIZE=%d\n"
	.align	3
.LC661:
	.string	"enum_expression_size.GIT_DIFF_FORCE_BINARY=%zu\n"
	.align	3
.LC662:
	.string	"enum_expression_signed.GIT_DIFF_FORCE_BINARY=%d\n"
	.align	3
.LC663:
	.string	"constant.GIT_DIFF_FORCE_BINARY="
	.align	3
.LC664:
	.string	"constant_size.GIT_DIFF_FORCE_BINARY=%zu\n"
	.align	3
.LC665:
	.string	"constant_signed.GIT_DIFF_FORCE_BINARY=%d\n"
	.align	3
.LC666:
	.string	"enum_expression_size.GIT_DIFF_FORCE_TEXT=%zu\n"
	.align	3
.LC667:
	.string	"enum_expression_signed.GIT_DIFF_FORCE_TEXT=%d\n"
	.align	3
.LC668:
	.string	"constant.GIT_DIFF_FORCE_TEXT="
	.align	3
.LC669:
	.string	"constant_size.GIT_DIFF_FORCE_TEXT=%zu\n"
	.align	3
.LC670:
	.string	"constant_signed.GIT_DIFF_FORCE_TEXT=%d\n"
	.align	3
.LC671:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_EMAIL_EXCLUDE_SUBJECT_PATCH_MARKER=%zu\n"
	.align	3
.LC672:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_EMAIL_EXCLUDE_SUBJECT_PATCH_MARKER=%d\n"
	.align	3
.LC673:
	.string	"constant.GIT_DIFF_FORMAT_EMAIL_EXCLUDE_SUBJECT_PATCH_MARKER="
	.align	3
.LC674:
	.string	"constant_size.GIT_DIFF_FORMAT_EMAIL_EXCLUDE_SUBJECT_PATCH_MARKER=%zu\n"
	.align	3
.LC675:
	.string	"constant_signed.GIT_DIFF_FORMAT_EMAIL_EXCLUDE_SUBJECT_PATCH_MARKER=%d\n"
	.align	3
.LC676:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_EMAIL_NONE=%zu\n"
	.align	3
.LC677:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_EMAIL_NONE=%d\n"
	.align	3
.LC678:
	.string	"constant.GIT_DIFF_FORMAT_EMAIL_NONE="
	.align	3
.LC679:
	.string	"constant_size.GIT_DIFF_FORMAT_EMAIL_NONE=%zu\n"
	.align	3
.LC680:
	.string	"constant_signed.GIT_DIFF_FORMAT_EMAIL_NONE=%d\n"
	.align	3
.LC681:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_NAME_ONLY=%zu\n"
	.align	3
.LC682:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_NAME_ONLY=%d\n"
	.align	3
.LC683:
	.string	"constant.GIT_DIFF_FORMAT_NAME_ONLY="
	.align	3
.LC684:
	.string	"constant_size.GIT_DIFF_FORMAT_NAME_ONLY=%zu\n"
	.align	3
.LC685:
	.string	"constant_signed.GIT_DIFF_FORMAT_NAME_ONLY=%d\n"
	.align	3
.LC686:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_NAME_STATUS=%zu\n"
	.align	3
.LC687:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_NAME_STATUS=%d\n"
	.align	3
.LC688:
	.string	"constant.GIT_DIFF_FORMAT_NAME_STATUS="
	.align	3
.LC689:
	.string	"constant_size.GIT_DIFF_FORMAT_NAME_STATUS=%zu\n"
	.align	3
.LC690:
	.string	"constant_signed.GIT_DIFF_FORMAT_NAME_STATUS=%d\n"
	.align	3
.LC691:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_PATCH=%zu\n"
	.align	3
.LC692:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_PATCH=%d\n"
	.align	3
.LC693:
	.string	"constant.GIT_DIFF_FORMAT_PATCH="
	.align	3
.LC694:
	.string	"constant_size.GIT_DIFF_FORMAT_PATCH=%zu\n"
	.align	3
.LC695:
	.string	"constant_signed.GIT_DIFF_FORMAT_PATCH=%d\n"
	.align	3
.LC696:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_PATCH_HEADER=%zu\n"
	.align	3
.LC697:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_PATCH_HEADER=%d\n"
	.align	3
.LC698:
	.string	"constant.GIT_DIFF_FORMAT_PATCH_HEADER="
	.align	3
.LC699:
	.string	"constant_size.GIT_DIFF_FORMAT_PATCH_HEADER=%zu\n"
	.align	3
.LC700:
	.string	"constant_signed.GIT_DIFF_FORMAT_PATCH_HEADER=%d\n"
	.align	3
.LC701:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_PATCH_ID=%zu\n"
	.align	3
.LC702:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_PATCH_ID=%d\n"
	.align	3
.LC703:
	.string	"constant.GIT_DIFF_FORMAT_PATCH_ID="
	.align	3
.LC704:
	.string	"constant_size.GIT_DIFF_FORMAT_PATCH_ID=%zu\n"
	.align	3
.LC705:
	.string	"constant_signed.GIT_DIFF_FORMAT_PATCH_ID=%d\n"
	.align	3
.LC706:
	.string	"enum_expression_size.GIT_DIFF_FORMAT_RAW=%zu\n"
	.align	3
.LC707:
	.string	"enum_expression_signed.GIT_DIFF_FORMAT_RAW=%d\n"
	.align	3
.LC708:
	.string	"constant.GIT_DIFF_FORMAT_RAW="
	.align	3
.LC709:
	.string	"constant_size.GIT_DIFF_FORMAT_RAW=%zu\n"
	.align	3
.LC710:
	.string	"constant_signed.GIT_DIFF_FORMAT_RAW=%d\n"
	.align	3
.LC711:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_BLANK_LINES=%zu\n"
	.align	3
.LC712:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_BLANK_LINES=%d\n"
	.align	3
.LC713:
	.string	"constant.GIT_DIFF_IGNORE_BLANK_LINES="
	.align	3
.LC714:
	.string	"constant_size.GIT_DIFF_IGNORE_BLANK_LINES=%zu\n"
	.align	3
.LC715:
	.string	"constant_signed.GIT_DIFF_IGNORE_BLANK_LINES=%d\n"
	.align	3
.LC716:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_CASE=%zu\n"
	.align	3
.LC717:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_CASE=%d\n"
	.align	3
.LC718:
	.string	"constant.GIT_DIFF_IGNORE_CASE="
	.align	3
.LC719:
	.string	"constant_size.GIT_DIFF_IGNORE_CASE=%zu\n"
	.align	3
.LC720:
	.string	"constant_signed.GIT_DIFF_IGNORE_CASE=%d\n"
	.align	3
.LC721:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_FILEMODE=%zu\n"
	.align	3
.LC722:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_FILEMODE=%d\n"
	.align	3
.LC723:
	.string	"constant.GIT_DIFF_IGNORE_FILEMODE="
	.align	3
.LC724:
	.string	"constant_size.GIT_DIFF_IGNORE_FILEMODE=%zu\n"
	.align	3
.LC725:
	.string	"constant_signed.GIT_DIFF_IGNORE_FILEMODE=%d\n"
	.align	3
.LC726:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_SUBMODULES=%zu\n"
	.align	3
.LC727:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_SUBMODULES=%d\n"
	.align	3
.LC728:
	.string	"constant.GIT_DIFF_IGNORE_SUBMODULES="
	.align	3
.LC729:
	.string	"constant_size.GIT_DIFF_IGNORE_SUBMODULES=%zu\n"
	.align	3
.LC730:
	.string	"constant_signed.GIT_DIFF_IGNORE_SUBMODULES=%d\n"
	.align	3
.LC731:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC732:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC733:
	.string	"constant.GIT_DIFF_IGNORE_WHITESPACE="
	.align	3
.LC734:
	.string	"constant_size.GIT_DIFF_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC735:
	.string	"constant_signed.GIT_DIFF_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC736:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_WHITESPACE_CHANGE=%zu\n"
	.align	3
.LC737:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_WHITESPACE_CHANGE=%d\n"
	.align	3
.LC738:
	.string	"constant.GIT_DIFF_IGNORE_WHITESPACE_CHANGE="
	.align	3
.LC739:
	.string	"constant_size.GIT_DIFF_IGNORE_WHITESPACE_CHANGE=%zu\n"
	.align	3
.LC740:
	.string	"constant_signed.GIT_DIFF_IGNORE_WHITESPACE_CHANGE=%d\n"
	.align	3
.LC741:
	.string	"enum_expression_size.GIT_DIFF_IGNORE_WHITESPACE_EOL=%zu\n"
	.align	3
.LC742:
	.string	"enum_expression_signed.GIT_DIFF_IGNORE_WHITESPACE_EOL=%d\n"
	.align	3
.LC743:
	.string	"constant.GIT_DIFF_IGNORE_WHITESPACE_EOL="
	.align	3
.LC744:
	.string	"constant_size.GIT_DIFF_IGNORE_WHITESPACE_EOL=%zu\n"
	.align	3
.LC745:
	.string	"constant_signed.GIT_DIFF_IGNORE_WHITESPACE_EOL=%d\n"
	.align	3
.LC746:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_CASECHANGE=%zu\n"
	.align	3
.LC747:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_CASECHANGE=%d\n"
	.align	3
.LC748:
	.string	"constant.GIT_DIFF_INCLUDE_CASECHANGE="
	.align	3
.LC749:
	.string	"constant_size.GIT_DIFF_INCLUDE_CASECHANGE=%zu\n"
	.align	3
.LC750:
	.string	"constant_signed.GIT_DIFF_INCLUDE_CASECHANGE=%d\n"
	.align	3
.LC751:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_IGNORED=%zu\n"
	.align	3
.LC752:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_IGNORED=%d\n"
	.align	3
.LC753:
	.string	"constant.GIT_DIFF_INCLUDE_IGNORED="
	.align	3
.LC754:
	.string	"constant_size.GIT_DIFF_INCLUDE_IGNORED=%zu\n"
	.align	3
.LC755:
	.string	"constant_signed.GIT_DIFF_INCLUDE_IGNORED=%d\n"
	.align	3
.LC756:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_TYPECHANGE=%zu\n"
	.align	3
.LC757:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_TYPECHANGE=%d\n"
	.align	3
.LC758:
	.string	"constant.GIT_DIFF_INCLUDE_TYPECHANGE="
	.align	3
.LC759:
	.string	"constant_size.GIT_DIFF_INCLUDE_TYPECHANGE=%zu\n"
	.align	3
.LC760:
	.string	"constant_signed.GIT_DIFF_INCLUDE_TYPECHANGE=%d\n"
	.align	3
.LC761:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_TYPECHANGE_TREES=%zu\n"
	.align	3
.LC762:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_TYPECHANGE_TREES=%d\n"
	.align	3
.LC763:
	.string	"constant.GIT_DIFF_INCLUDE_TYPECHANGE_TREES="
	.align	3
.LC764:
	.string	"constant_size.GIT_DIFF_INCLUDE_TYPECHANGE_TREES=%zu\n"
	.align	3
.LC765:
	.string	"constant_signed.GIT_DIFF_INCLUDE_TYPECHANGE_TREES=%d\n"
	.align	3
.LC766:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_UNMODIFIED=%zu\n"
	.align	3
.LC767:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_UNMODIFIED=%d\n"
	.align	3
.LC768:
	.string	"constant.GIT_DIFF_INCLUDE_UNMODIFIED="
	.align	3
.LC769:
	.string	"constant_size.GIT_DIFF_INCLUDE_UNMODIFIED=%zu\n"
	.align	3
.LC770:
	.string	"constant_signed.GIT_DIFF_INCLUDE_UNMODIFIED=%d\n"
	.align	3
.LC771:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_UNREADABLE=%zu\n"
	.align	3
.LC772:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_UNREADABLE=%d\n"
	.align	3
.LC773:
	.string	"constant.GIT_DIFF_INCLUDE_UNREADABLE="
	.align	3
.LC774:
	.string	"constant_size.GIT_DIFF_INCLUDE_UNREADABLE=%zu\n"
	.align	3
.LC775:
	.string	"constant_signed.GIT_DIFF_INCLUDE_UNREADABLE=%d\n"
	.align	3
.LC776:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_UNREADABLE_AS_UNTRACKED=%zu\n"
	.align	3
.LC777:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_UNREADABLE_AS_UNTRACKED=%d\n"
	.align	3
.LC778:
	.string	"constant.GIT_DIFF_INCLUDE_UNREADABLE_AS_UNTRACKED="
	.align	3
.LC779:
	.string	"constant_size.GIT_DIFF_INCLUDE_UNREADABLE_AS_UNTRACKED=%zu\n"
	.align	3
.LC780:
	.string	"constant_signed.GIT_DIFF_INCLUDE_UNREADABLE_AS_UNTRACKED=%d\n"
	.align	3
.LC781:
	.string	"enum_expression_size.GIT_DIFF_INCLUDE_UNTRACKED=%zu\n"
	.align	3
.LC782:
	.string	"enum_expression_signed.GIT_DIFF_INCLUDE_UNTRACKED=%d\n"
	.align	3
.LC783:
	.string	"constant.GIT_DIFF_INCLUDE_UNTRACKED="
	.align	3
.LC784:
	.string	"constant_size.GIT_DIFF_INCLUDE_UNTRACKED=%zu\n"
	.align	3
.LC785:
	.string	"constant_signed.GIT_DIFF_INCLUDE_UNTRACKED=%d\n"
	.align	3
.LC786:
	.string	"enum_expression_size.GIT_DIFF_INDENT_HEURISTIC=%zu\n"
	.align	3
.LC787:
	.string	"enum_expression_signed.GIT_DIFF_INDENT_HEURISTIC=%d\n"
	.align	3
.LC788:
	.string	"constant.GIT_DIFF_INDENT_HEURISTIC="
	.align	3
.LC789:
	.string	"constant_size.GIT_DIFF_INDENT_HEURISTIC=%zu\n"
	.align	3
.LC790:
	.string	"constant_signed.GIT_DIFF_INDENT_HEURISTIC=%d\n"
	.align	3
.LC791:
	.string	"enum_expression_size.GIT_DIFF_LINE_ADDITION=%zu\n"
	.align	3
.LC792:
	.string	"enum_expression_signed.GIT_DIFF_LINE_ADDITION=%d\n"
	.align	3
.LC793:
	.string	"constant.GIT_DIFF_LINE_ADDITION="
	.align	3
.LC794:
	.string	"constant_size.GIT_DIFF_LINE_ADDITION=%zu\n"
	.align	3
.LC795:
	.string	"constant_signed.GIT_DIFF_LINE_ADDITION=%d\n"
	.align	3
.LC796:
	.string	"enum_expression_size.GIT_DIFF_LINE_ADD_EOFNL=%zu\n"
	.align	3
.LC797:
	.string	"enum_expression_signed.GIT_DIFF_LINE_ADD_EOFNL=%d\n"
	.align	3
.LC798:
	.string	"constant.GIT_DIFF_LINE_ADD_EOFNL="
	.align	3
.LC799:
	.string	"constant_size.GIT_DIFF_LINE_ADD_EOFNL=%zu\n"
	.align	3
.LC800:
	.string	"constant_signed.GIT_DIFF_LINE_ADD_EOFNL=%d\n"
	.align	3
.LC801:
	.string	"enum_expression_size.GIT_DIFF_LINE_BINARY=%zu\n"
	.align	3
.LC802:
	.string	"enum_expression_signed.GIT_DIFF_LINE_BINARY=%d\n"
	.align	3
.LC803:
	.string	"constant.GIT_DIFF_LINE_BINARY="
	.align	3
.LC804:
	.string	"constant_size.GIT_DIFF_LINE_BINARY=%zu\n"
	.align	3
.LC805:
	.string	"constant_signed.GIT_DIFF_LINE_BINARY=%d\n"
	.align	3
.LC806:
	.string	"enum_expression_size.GIT_DIFF_LINE_CONTEXT=%zu\n"
	.align	3
.LC807:
	.string	"enum_expression_signed.GIT_DIFF_LINE_CONTEXT=%d\n"
	.align	3
.LC808:
	.string	"constant.GIT_DIFF_LINE_CONTEXT="
	.align	3
.LC809:
	.string	"constant_size.GIT_DIFF_LINE_CONTEXT=%zu\n"
	.align	3
.LC810:
	.string	"constant_signed.GIT_DIFF_LINE_CONTEXT=%d\n"
	.align	3
.LC811:
	.string	"enum_expression_size.GIT_DIFF_LINE_CONTEXT_EOFNL=%zu\n"
	.align	3
.LC812:
	.string	"enum_expression_signed.GIT_DIFF_LINE_CONTEXT_EOFNL=%d\n"
	.align	3
.LC813:
	.string	"constant.GIT_DIFF_LINE_CONTEXT_EOFNL="
	.align	3
.LC814:
	.string	"constant_size.GIT_DIFF_LINE_CONTEXT_EOFNL=%zu\n"
	.align	3
.LC815:
	.string	"constant_signed.GIT_DIFF_LINE_CONTEXT_EOFNL=%d\n"
	.align	3
.LC816:
	.string	"enum_expression_size.GIT_DIFF_LINE_DELETION=%zu\n"
	.align	3
.LC817:
	.string	"enum_expression_signed.GIT_DIFF_LINE_DELETION=%d\n"
	.align	3
.LC818:
	.string	"constant.GIT_DIFF_LINE_DELETION="
	.align	3
.LC819:
	.string	"constant_size.GIT_DIFF_LINE_DELETION=%zu\n"
	.align	3
.LC820:
	.string	"constant_signed.GIT_DIFF_LINE_DELETION=%d\n"
	.align	3
.LC821:
	.string	"enum_expression_size.GIT_DIFF_LINE_DEL_EOFNL=%zu\n"
	.align	3
.LC822:
	.string	"enum_expression_signed.GIT_DIFF_LINE_DEL_EOFNL=%d\n"
	.align	3
.LC823:
	.string	"constant.GIT_DIFF_LINE_DEL_EOFNL="
	.align	3
.LC824:
	.string	"constant_size.GIT_DIFF_LINE_DEL_EOFNL=%zu\n"
	.align	3
.LC825:
	.string	"constant_signed.GIT_DIFF_LINE_DEL_EOFNL=%d\n"
	.align	3
.LC826:
	.string	"enum_expression_size.GIT_DIFF_LINE_FILE_HDR=%zu\n"
	.align	3
.LC827:
	.string	"enum_expression_signed.GIT_DIFF_LINE_FILE_HDR=%d\n"
	.align	3
.LC828:
	.string	"constant.GIT_DIFF_LINE_FILE_HDR="
	.align	3
.LC829:
	.string	"constant_size.GIT_DIFF_LINE_FILE_HDR=%zu\n"
	.align	3
.LC830:
	.string	"constant_signed.GIT_DIFF_LINE_FILE_HDR=%d\n"
	.align	3
.LC831:
	.string	"enum_expression_size.GIT_DIFF_LINE_HUNK_HDR=%zu\n"
	.align	3
.LC832:
	.string	"enum_expression_signed.GIT_DIFF_LINE_HUNK_HDR=%d\n"
	.align	3
.LC833:
	.string	"constant.GIT_DIFF_LINE_HUNK_HDR="
	.align	3
.LC834:
	.string	"constant_size.GIT_DIFF_LINE_HUNK_HDR=%zu\n"
	.align	3
.LC835:
	.string	"constant_signed.GIT_DIFF_LINE_HUNK_HDR=%d\n"
	.align	3
.LC836:
	.string	"enum_expression_size.GIT_DIFF_MINIMAL=%zu\n"
	.align	3
.LC837:
	.string	"enum_expression_signed.GIT_DIFF_MINIMAL=%d\n"
	.align	3
.LC838:
	.string	"constant.GIT_DIFF_MINIMAL="
	.align	3
.LC839:
	.string	"constant_size.GIT_DIFF_MINIMAL=%zu\n"
	.align	3
.LC840:
	.string	"constant_signed.GIT_DIFF_MINIMAL=%d\n"
	.align	3
.LC841:
	.string	"enum_expression_size.GIT_DIFF_NORMAL=%zu\n"
	.align	3
.LC842:
	.string	"enum_expression_signed.GIT_DIFF_NORMAL=%d\n"
	.align	3
.LC843:
	.string	"constant.GIT_DIFF_NORMAL="
	.align	3
.LC844:
	.string	"constant_size.GIT_DIFF_NORMAL=%zu\n"
	.align	3
.LC845:
	.string	"constant_signed.GIT_DIFF_NORMAL=%d\n"
	.align	3
.LC846:
	.string	"enum_expression_size.GIT_DIFF_PATIENCE=%zu\n"
	.align	3
.LC847:
	.string	"enum_expression_signed.GIT_DIFF_PATIENCE=%d\n"
	.align	3
.LC848:
	.string	"constant.GIT_DIFF_PATIENCE="
	.align	3
.LC849:
	.string	"constant_size.GIT_DIFF_PATIENCE=%zu\n"
	.align	3
.LC850:
	.string	"constant_signed.GIT_DIFF_PATIENCE=%d\n"
	.align	3
.LC851:
	.string	"enum_expression_size.GIT_DIFF_RECURSE_IGNORED_DIRS=%zu\n"
	.align	3
.LC852:
	.string	"enum_expression_signed.GIT_DIFF_RECURSE_IGNORED_DIRS=%d\n"
	.align	3
.LC853:
	.string	"constant.GIT_DIFF_RECURSE_IGNORED_DIRS="
	.align	3
.LC854:
	.string	"constant_size.GIT_DIFF_RECURSE_IGNORED_DIRS=%zu\n"
	.align	3
.LC855:
	.string	"constant_signed.GIT_DIFF_RECURSE_IGNORED_DIRS=%d\n"
	.align	3
.LC856:
	.string	"enum_expression_size.GIT_DIFF_RECURSE_UNTRACKED_DIRS=%zu\n"
	.align	3
.LC857:
	.string	"enum_expression_signed.GIT_DIFF_RECURSE_UNTRACKED_DIRS=%d\n"
	.align	3
.LC858:
	.string	"constant.GIT_DIFF_RECURSE_UNTRACKED_DIRS="
	.align	3
.LC859:
	.string	"constant_size.GIT_DIFF_RECURSE_UNTRACKED_DIRS=%zu\n"
	.align	3
.LC860:
	.string	"constant_signed.GIT_DIFF_RECURSE_UNTRACKED_DIRS=%d\n"
	.align	3
.LC861:
	.string	"enum_expression_size.GIT_DIFF_REVERSE=%zu\n"
	.align	3
.LC862:
	.string	"enum_expression_signed.GIT_DIFF_REVERSE=%d\n"
	.align	3
.LC863:
	.string	"constant.GIT_DIFF_REVERSE="
	.align	3
.LC864:
	.string	"constant_size.GIT_DIFF_REVERSE=%zu\n"
	.align	3
.LC865:
	.string	"constant_signed.GIT_DIFF_REVERSE=%d\n"
	.align	3
.LC866:
	.string	"enum_expression_size.GIT_DIFF_SHOW_BINARY=%zu\n"
	.align	3
.LC867:
	.string	"enum_expression_signed.GIT_DIFF_SHOW_BINARY=%d\n"
	.align	3
.LC868:
	.string	"constant.GIT_DIFF_SHOW_BINARY="
	.align	3
.LC869:
	.string	"constant_size.GIT_DIFF_SHOW_BINARY=%zu\n"
	.align	3
.LC870:
	.string	"constant_signed.GIT_DIFF_SHOW_BINARY=%d\n"
	.align	3
.LC871:
	.string	"enum_expression_size.GIT_DIFF_SHOW_UNMODIFIED=%zu\n"
	.align	3
.LC872:
	.string	"enum_expression_signed.GIT_DIFF_SHOW_UNMODIFIED=%d\n"
	.align	3
.LC873:
	.string	"constant.GIT_DIFF_SHOW_UNMODIFIED="
	.align	3
.LC874:
	.string	"constant_size.GIT_DIFF_SHOW_UNMODIFIED=%zu\n"
	.align	3
.LC875:
	.string	"constant_signed.GIT_DIFF_SHOW_UNMODIFIED=%d\n"
	.align	3
.LC876:
	.string	"enum_expression_size.GIT_DIFF_SHOW_UNTRACKED_CONTENT=%zu\n"
	.align	3
.LC877:
	.string	"enum_expression_signed.GIT_DIFF_SHOW_UNTRACKED_CONTENT=%d\n"
	.align	3
.LC878:
	.string	"constant.GIT_DIFF_SHOW_UNTRACKED_CONTENT="
	.align	3
.LC879:
	.string	"constant_size.GIT_DIFF_SHOW_UNTRACKED_CONTENT=%zu\n"
	.align	3
.LC880:
	.string	"constant_signed.GIT_DIFF_SHOW_UNTRACKED_CONTENT=%d\n"
	.align	3
.LC881:
	.string	"enum_expression_size.GIT_DIFF_SKIP_BINARY_CHECK=%zu\n"
	.align	3
.LC882:
	.string	"enum_expression_signed.GIT_DIFF_SKIP_BINARY_CHECK=%d\n"
	.align	3
.LC883:
	.string	"constant.GIT_DIFF_SKIP_BINARY_CHECK="
	.align	3
.LC884:
	.string	"constant_size.GIT_DIFF_SKIP_BINARY_CHECK=%zu\n"
	.align	3
.LC885:
	.string	"constant_signed.GIT_DIFF_SKIP_BINARY_CHECK=%d\n"
	.align	3
.LC886:
	.string	"enum_expression_size.GIT_DIFF_STATS_FULL=%zu\n"
	.align	3
.LC887:
	.string	"enum_expression_signed.GIT_DIFF_STATS_FULL=%d\n"
	.align	3
.LC888:
	.string	"constant.GIT_DIFF_STATS_FULL="
	.align	3
.LC889:
	.string	"constant_size.GIT_DIFF_STATS_FULL=%zu\n"
	.align	3
.LC890:
	.string	"constant_signed.GIT_DIFF_STATS_FULL=%d\n"
	.align	3
.LC891:
	.string	"enum_expression_size.GIT_DIFF_STATS_INCLUDE_SUMMARY=%zu\n"
	.align	3
.LC892:
	.string	"enum_expression_signed.GIT_DIFF_STATS_INCLUDE_SUMMARY=%d\n"
	.align	3
.LC893:
	.string	"constant.GIT_DIFF_STATS_INCLUDE_SUMMARY="
	.align	3
.LC894:
	.string	"constant_size.GIT_DIFF_STATS_INCLUDE_SUMMARY=%zu\n"
	.align	3
.LC895:
	.string	"constant_signed.GIT_DIFF_STATS_INCLUDE_SUMMARY=%d\n"
	.align	3
.LC896:
	.string	"enum_expression_size.GIT_DIFF_STATS_NONE=%zu\n"
	.align	3
.LC897:
	.string	"enum_expression_signed.GIT_DIFF_STATS_NONE=%d\n"
	.align	3
.LC898:
	.string	"constant.GIT_DIFF_STATS_NONE="
	.align	3
.LC899:
	.string	"constant_size.GIT_DIFF_STATS_NONE=%zu\n"
	.align	3
.LC900:
	.string	"constant_signed.GIT_DIFF_STATS_NONE=%d\n"
	.align	3
.LC901:
	.string	"enum_expression_size.GIT_DIFF_STATS_NUMBER=%zu\n"
	.align	3
.LC902:
	.string	"enum_expression_signed.GIT_DIFF_STATS_NUMBER=%d\n"
	.align	3
.LC903:
	.string	"constant.GIT_DIFF_STATS_NUMBER="
	.align	3
.LC904:
	.string	"constant_size.GIT_DIFF_STATS_NUMBER=%zu\n"
	.align	3
.LC905:
	.string	"constant_signed.GIT_DIFF_STATS_NUMBER=%d\n"
	.align	3
.LC906:
	.string	"enum_expression_size.GIT_DIFF_STATS_SHORT=%zu\n"
	.align	3
.LC907:
	.string	"enum_expression_signed.GIT_DIFF_STATS_SHORT=%d\n"
	.align	3
.LC908:
	.string	"constant.GIT_DIFF_STATS_SHORT="
	.align	3
.LC909:
	.string	"constant_size.GIT_DIFF_STATS_SHORT=%zu\n"
	.align	3
.LC910:
	.string	"constant_signed.GIT_DIFF_STATS_SHORT=%d\n"
	.align	3
.LC911:
	.string	"enum_expression_size.GIT_DIFF_UPDATE_INDEX=%zu\n"
	.align	3
.LC912:
	.string	"enum_expression_signed.GIT_DIFF_UPDATE_INDEX=%d\n"
	.align	3
.LC913:
	.string	"constant.GIT_DIFF_UPDATE_INDEX="
	.align	3
.LC914:
	.string	"constant_size.GIT_DIFF_UPDATE_INDEX=%zu\n"
	.align	3
.LC915:
	.string	"constant_signed.GIT_DIFF_UPDATE_INDEX=%d\n"
	.align	3
.LC916:
	.string	"enum_expression_size.GIT_DIRECTION_FETCH=%zu\n"
	.align	3
.LC917:
	.string	"enum_expression_signed.GIT_DIRECTION_FETCH=%d\n"
	.align	3
.LC918:
	.string	"constant.GIT_DIRECTION_FETCH="
	.align	3
.LC919:
	.string	"constant_size.GIT_DIRECTION_FETCH=%zu\n"
	.align	3
.LC920:
	.string	"constant_signed.GIT_DIRECTION_FETCH=%d\n"
	.align	3
.LC921:
	.string	"enum_expression_size.GIT_DIRECTION_PUSH=%zu\n"
	.align	3
.LC922:
	.string	"enum_expression_signed.GIT_DIRECTION_PUSH=%d\n"
	.align	3
.LC923:
	.string	"constant.GIT_DIRECTION_PUSH="
	.align	3
.LC924:
	.string	"constant_size.GIT_DIRECTION_PUSH=%zu\n"
	.align	3
.LC925:
	.string	"constant_signed.GIT_DIRECTION_PUSH=%d\n"
	.align	3
.LC926:
	.string	"enum_expression_size.GIT_EAMBIGUOUS=%zu\n"
	.align	3
.LC927:
	.string	"enum_expression_signed.GIT_EAMBIGUOUS=%d\n"
	.align	3
.LC928:
	.string	"constant.GIT_EAMBIGUOUS="
	.align	3
.LC929:
	.string	"constant_size.GIT_EAMBIGUOUS=%zu\n"
	.align	3
.LC930:
	.string	"constant_signed.GIT_EAMBIGUOUS=%d\n"
	.align	3
.LC931:
	.string	"enum_expression_size.GIT_EAPPLIED=%zu\n"
	.align	3
.LC932:
	.string	"enum_expression_signed.GIT_EAPPLIED=%d\n"
	.align	3
.LC933:
	.string	"constant.GIT_EAPPLIED="
	.align	3
.LC934:
	.string	"constant_size.GIT_EAPPLIED=%zu\n"
	.align	3
.LC935:
	.string	"constant_signed.GIT_EAPPLIED=%d\n"
	.align	3
.LC936:
	.string	"enum_expression_size.GIT_EAPPLYFAIL=%zu\n"
	.align	3
.LC937:
	.string	"enum_expression_signed.GIT_EAPPLYFAIL=%d\n"
	.align	3
.LC938:
	.string	"constant.GIT_EAPPLYFAIL="
	.align	3
.LC939:
	.string	"constant_size.GIT_EAPPLYFAIL=%zu\n"
	.align	3
.LC940:
	.string	"constant_signed.GIT_EAPPLYFAIL=%d\n"
	.align	3
.LC941:
	.string	"enum_expression_size.GIT_EAUTH=%zu\n"
	.align	3
.LC942:
	.string	"enum_expression_signed.GIT_EAUTH=%d\n"
	.align	3
.LC943:
	.string	"constant.GIT_EAUTH="
	.align	3
.LC944:
	.string	"constant_size.GIT_EAUTH=%zu\n"
	.align	3
.LC945:
	.string	"constant_signed.GIT_EAUTH=%d\n"
	.align	3
.LC946:
	.string	"enum_expression_size.GIT_EBAREREPO=%zu\n"
	.align	3
.LC947:
	.string	"enum_expression_signed.GIT_EBAREREPO=%d\n"
	.align	3
.LC948:
	.string	"constant.GIT_EBAREREPO="
	.align	3
.LC949:
	.string	"constant_size.GIT_EBAREREPO=%zu\n"
	.align	3
.LC950:
	.string	"constant_signed.GIT_EBAREREPO=%d\n"
	.align	3
.LC951:
	.string	"enum_expression_size.GIT_EBUFS=%zu\n"
	.align	3
.LC952:
	.string	"enum_expression_signed.GIT_EBUFS=%d\n"
	.align	3
.LC953:
	.string	"constant.GIT_EBUFS="
	.align	3
.LC954:
	.string	"constant_size.GIT_EBUFS=%zu\n"
	.align	3
.LC955:
	.string	"constant_signed.GIT_EBUFS=%d\n"
	.align	3
.LC956:
	.string	"enum_expression_size.GIT_ECERTIFICATE=%zu\n"
	.align	3
.LC957:
	.string	"enum_expression_signed.GIT_ECERTIFICATE=%d\n"
	.align	3
.LC958:
	.string	"constant.GIT_ECERTIFICATE="
	.align	3
.LC959:
	.string	"constant_size.GIT_ECERTIFICATE=%zu\n"
	.align	3
.LC960:
	.string	"constant_signed.GIT_ECERTIFICATE=%d\n"
	.align	3
.LC961:
	.string	"enum_expression_size.GIT_ECONFLICT=%zu\n"
	.align	3
.LC962:
	.string	"enum_expression_signed.GIT_ECONFLICT=%d\n"
	.align	3
.LC963:
	.string	"constant.GIT_ECONFLICT="
	.align	3
.LC964:
	.string	"constant_size.GIT_ECONFLICT=%zu\n"
	.align	3
.LC965:
	.string	"constant_signed.GIT_ECONFLICT=%d\n"
	.align	3
.LC966:
	.string	"enum_expression_size.GIT_EDIRECTORY=%zu\n"
	.align	3
.LC967:
	.string	"enum_expression_signed.GIT_EDIRECTORY=%d\n"
	.align	3
.LC968:
	.string	"constant.GIT_EDIRECTORY="
	.align	3
.LC969:
	.string	"constant_size.GIT_EDIRECTORY=%zu\n"
	.align	3
.LC970:
	.string	"constant_signed.GIT_EDIRECTORY=%d\n"
	.align	3
.LC971:
	.string	"enum_expression_size.GIT_EEOF=%zu\n"
	.align	3
.LC972:
	.string	"enum_expression_signed.GIT_EEOF=%d\n"
	.align	3
.LC973:
	.string	"constant.GIT_EEOF="
	.align	3
.LC974:
	.string	"constant_size.GIT_EEOF=%zu\n"
	.align	3
.LC975:
	.string	"constant_signed.GIT_EEOF=%d\n"
	.align	3
.LC976:
	.string	"enum_expression_size.GIT_EEXISTS=%zu\n"
	.align	3
.LC977:
	.string	"enum_expression_signed.GIT_EEXISTS=%d\n"
	.align	3
.LC978:
	.string	"constant.GIT_EEXISTS="
	.align	3
.LC979:
	.string	"constant_size.GIT_EEXISTS=%zu\n"
	.align	3
.LC980:
	.string	"constant_signed.GIT_EEXISTS=%d\n"
	.align	3
.LC981:
	.string	"enum_expression_size.GIT_EINDEXDIRTY=%zu\n"
	.align	3
.LC982:
	.string	"enum_expression_signed.GIT_EINDEXDIRTY=%d\n"
	.align	3
.LC983:
	.string	"constant.GIT_EINDEXDIRTY="
	.align	3
.LC984:
	.string	"constant_size.GIT_EINDEXDIRTY=%zu\n"
	.align	3
.LC985:
	.string	"constant_signed.GIT_EINDEXDIRTY=%d\n"
	.align	3
.LC986:
	.string	"enum_expression_size.GIT_EINVALID=%zu\n"
	.align	3
.LC987:
	.string	"enum_expression_signed.GIT_EINVALID=%d\n"
	.align	3
.LC988:
	.string	"constant.GIT_EINVALID="
	.align	3
.LC989:
	.string	"constant_size.GIT_EINVALID=%zu\n"
	.align	3
.LC990:
	.string	"constant_signed.GIT_EINVALID=%d\n"
	.align	3
.LC991:
	.string	"enum_expression_size.GIT_EINVALIDSPEC=%zu\n"
	.align	3
.LC992:
	.string	"enum_expression_signed.GIT_EINVALIDSPEC=%d\n"
	.align	3
.LC993:
	.string	"constant.GIT_EINVALIDSPEC="
	.align	3
.LC994:
	.string	"constant_size.GIT_EINVALIDSPEC=%zu\n"
	.align	3
.LC995:
	.string	"constant_signed.GIT_EINVALIDSPEC=%d\n"
	.align	3
.LC996:
	.string	"enum_expression_size.GIT_ELOCKED=%zu\n"
	.align	3
.LC997:
	.string	"enum_expression_signed.GIT_ELOCKED=%d\n"
	.align	3
.LC998:
	.string	"constant.GIT_ELOCKED="
	.align	3
.LC999:
	.string	"constant_size.GIT_ELOCKED=%zu\n"
	.align	3
.LC1000:
	.string	"constant_signed.GIT_ELOCKED=%d\n"
	.align	3
.LC1001:
	.string	"enum_expression_size.GIT_EMAIL_CREATE_ALWAYS_NUMBER=%zu\n"
	.align	3
.LC1002:
	.string	"enum_expression_signed.GIT_EMAIL_CREATE_ALWAYS_NUMBER=%d\n"
	.align	3
.LC1003:
	.string	"constant.GIT_EMAIL_CREATE_ALWAYS_NUMBER="
	.align	3
.LC1004:
	.string	"constant_size.GIT_EMAIL_CREATE_ALWAYS_NUMBER=%zu\n"
	.align	3
.LC1005:
	.string	"constant_signed.GIT_EMAIL_CREATE_ALWAYS_NUMBER=%d\n"
	.align	3
.LC1006:
	.string	"enum_expression_size.GIT_EMAIL_CREATE_DEFAULT=%zu\n"
	.align	3
.LC1007:
	.string	"enum_expression_signed.GIT_EMAIL_CREATE_DEFAULT=%d\n"
	.align	3
.LC1008:
	.string	"constant.GIT_EMAIL_CREATE_DEFAULT="
	.align	3
.LC1009:
	.string	"constant_size.GIT_EMAIL_CREATE_DEFAULT=%zu\n"
	.align	3
.LC1010:
	.string	"constant_signed.GIT_EMAIL_CREATE_DEFAULT=%d\n"
	.align	3
.LC1011:
	.string	"enum_expression_size.GIT_EMAIL_CREATE_NO_RENAMES=%zu\n"
	.align	3
.LC1012:
	.string	"enum_expression_signed.GIT_EMAIL_CREATE_NO_RENAMES=%d\n"
	.align	3
.LC1013:
	.string	"constant.GIT_EMAIL_CREATE_NO_RENAMES="
	.align	3
.LC1014:
	.string	"constant_size.GIT_EMAIL_CREATE_NO_RENAMES=%zu\n"
	.align	3
.LC1015:
	.string	"constant_signed.GIT_EMAIL_CREATE_NO_RENAMES=%d\n"
	.align	3
.LC1016:
	.string	"enum_expression_size.GIT_EMAIL_CREATE_OMIT_NUMBERS=%zu\n"
	.align	3
.LC1017:
	.string	"enum_expression_signed.GIT_EMAIL_CREATE_OMIT_NUMBERS=%d\n"
	.align	3
.LC1018:
	.string	"constant.GIT_EMAIL_CREATE_OMIT_NUMBERS="
	.align	3
.LC1019:
	.string	"constant_size.GIT_EMAIL_CREATE_OMIT_NUMBERS=%zu\n"
	.align	3
.LC1020:
	.string	"constant_signed.GIT_EMAIL_CREATE_OMIT_NUMBERS=%d\n"
	.align	3
.LC1021:
	.string	"enum_expression_size.GIT_EMERGECONFLICT=%zu\n"
	.align	3
.LC1022:
	.string	"enum_expression_signed.GIT_EMERGECONFLICT=%d\n"
	.align	3
.LC1023:
	.string	"constant.GIT_EMERGECONFLICT="
	.align	3
.LC1024:
	.string	"constant_size.GIT_EMERGECONFLICT=%zu\n"
	.align	3
.LC1025:
	.string	"constant_signed.GIT_EMERGECONFLICT=%d\n"
	.align	3
.LC1026:
	.string	"enum_expression_size.GIT_EMISMATCH=%zu\n"
	.align	3
.LC1027:
	.string	"enum_expression_signed.GIT_EMISMATCH=%d\n"
	.align	3
.LC1028:
	.string	"constant.GIT_EMISMATCH="
	.align	3
.LC1029:
	.string	"constant_size.GIT_EMISMATCH=%zu\n"
	.align	3
.LC1030:
	.string	"constant_signed.GIT_EMISMATCH=%d\n"
	.align	3
.LC1031:
	.string	"enum_expression_size.GIT_EMODIFIED=%zu\n"
	.align	3
.LC1032:
	.string	"enum_expression_signed.GIT_EMODIFIED=%d\n"
	.align	3
.LC1033:
	.string	"constant.GIT_EMODIFIED="
	.align	3
.LC1034:
	.string	"constant_size.GIT_EMODIFIED=%zu\n"
	.align	3
.LC1035:
	.string	"constant_signed.GIT_EMODIFIED=%d\n"
	.align	3
.LC1036:
	.string	"enum_expression_size.GIT_ENONFASTFORWARD=%zu\n"
	.align	3
.LC1037:
	.string	"enum_expression_signed.GIT_ENONFASTFORWARD=%d\n"
	.align	3
.LC1038:
	.string	"constant.GIT_ENONFASTFORWARD="
	.align	3
.LC1039:
	.string	"constant_size.GIT_ENONFASTFORWARD=%zu\n"
	.align	3
.LC1040:
	.string	"constant_signed.GIT_ENONFASTFORWARD=%d\n"
	.align	3
.LC1041:
	.string	"enum_expression_size.GIT_ENOTFOUND=%zu\n"
	.align	3
.LC1042:
	.string	"enum_expression_signed.GIT_ENOTFOUND=%d\n"
	.align	3
.LC1043:
	.string	"constant.GIT_ENOTFOUND="
	.align	3
.LC1044:
	.string	"constant_size.GIT_ENOTFOUND=%zu\n"
	.align	3
.LC1045:
	.string	"constant_signed.GIT_ENOTFOUND=%d\n"
	.align	3
.LC1046:
	.string	"enum_expression_size.GIT_ENOTSUPPORTED=%zu\n"
	.align	3
.LC1047:
	.string	"enum_expression_signed.GIT_ENOTSUPPORTED=%d\n"
	.align	3
.LC1048:
	.string	"constant.GIT_ENOTSUPPORTED="
	.align	3
.LC1049:
	.string	"constant_size.GIT_ENOTSUPPORTED=%zu\n"
	.align	3
.LC1050:
	.string	"constant_signed.GIT_ENOTSUPPORTED=%d\n"
	.align	3
.LC1051:
	.string	"enum_expression_size.GIT_EOWNER=%zu\n"
	.align	3
.LC1052:
	.string	"enum_expression_signed.GIT_EOWNER=%d\n"
	.align	3
.LC1053:
	.string	"constant.GIT_EOWNER="
	.align	3
.LC1054:
	.string	"constant_size.GIT_EOWNER=%zu\n"
	.align	3
.LC1055:
	.string	"constant_signed.GIT_EOWNER=%d\n"
	.align	3
.LC1056:
	.string	"enum_expression_size.GIT_EPEEL=%zu\n"
	.align	3
.LC1057:
	.string	"enum_expression_signed.GIT_EPEEL=%d\n"
	.align	3
.LC1058:
	.string	"constant.GIT_EPEEL="
	.align	3
.LC1059:
	.string	"constant_size.GIT_EPEEL=%zu\n"
	.align	3
.LC1060:
	.string	"constant_signed.GIT_EPEEL=%d\n"
	.align	3
.LC1061:
	.string	"enum_expression_size.GIT_EREADONLY=%zu\n"
	.align	3
.LC1062:
	.string	"enum_expression_signed.GIT_EREADONLY=%d\n"
	.align	3
.LC1063:
	.string	"constant.GIT_EREADONLY="
	.align	3
.LC1064:
	.string	"constant_size.GIT_EREADONLY=%zu\n"
	.align	3
.LC1065:
	.string	"constant_signed.GIT_EREADONLY=%d\n"
	.align	3
.LC1066:
	.string	"enum_expression_size.GIT_ERROR=%zu\n"
	.align	3
.LC1067:
	.string	"enum_expression_signed.GIT_ERROR=%d\n"
	.align	3
.LC1068:
	.string	"constant.GIT_ERROR="
	.align	3
.LC1069:
	.string	"constant_size.GIT_ERROR=%zu\n"
	.align	3
.LC1070:
	.string	"constant_signed.GIT_ERROR=%d\n"
	.align	3
.LC1071:
	.string	"enum_expression_size.GIT_ERROR_CALLBACK=%zu\n"
	.align	3
.LC1072:
	.string	"enum_expression_signed.GIT_ERROR_CALLBACK=%d\n"
	.align	3
.LC1073:
	.string	"constant.GIT_ERROR_CALLBACK="
	.align	3
.LC1074:
	.string	"constant_size.GIT_ERROR_CALLBACK=%zu\n"
	.align	3
.LC1075:
	.string	"constant_signed.GIT_ERROR_CALLBACK=%d\n"
	.align	3
.LC1076:
	.string	"enum_expression_size.GIT_ERROR_CHECKOUT=%zu\n"
	.align	3
.LC1077:
	.string	"enum_expression_signed.GIT_ERROR_CHECKOUT=%d\n"
	.align	3
.LC1078:
	.string	"constant.GIT_ERROR_CHECKOUT="
	.align	3
.LC1079:
	.string	"constant_size.GIT_ERROR_CHECKOUT=%zu\n"
	.align	3
.LC1080:
	.string	"constant_signed.GIT_ERROR_CHECKOUT=%d\n"
	.align	3
.LC1081:
	.string	"enum_expression_size.GIT_ERROR_CHERRYPICK=%zu\n"
	.align	3
.LC1082:
	.string	"enum_expression_signed.GIT_ERROR_CHERRYPICK=%d\n"
	.align	3
.LC1083:
	.string	"constant.GIT_ERROR_CHERRYPICK="
	.align	3
.LC1084:
	.string	"constant_size.GIT_ERROR_CHERRYPICK=%zu\n"
	.align	3
.LC1085:
	.string	"constant_signed.GIT_ERROR_CHERRYPICK=%d\n"
	.align	3
.LC1086:
	.string	"enum_expression_size.GIT_ERROR_CONFIG=%zu\n"
	.align	3
.LC1087:
	.string	"enum_expression_signed.GIT_ERROR_CONFIG=%d\n"
	.align	3
.LC1088:
	.string	"constant.GIT_ERROR_CONFIG="
	.align	3
.LC1089:
	.string	"constant_size.GIT_ERROR_CONFIG=%zu\n"
	.align	3
.LC1090:
	.string	"constant_signed.GIT_ERROR_CONFIG=%d\n"
	.align	3
.LC1091:
	.string	"enum_expression_size.GIT_ERROR_DESCRIBE=%zu\n"
	.align	3
.LC1092:
	.string	"enum_expression_signed.GIT_ERROR_DESCRIBE=%d\n"
	.align	3
.LC1093:
	.string	"constant.GIT_ERROR_DESCRIBE="
	.align	3
.LC1094:
	.string	"constant_size.GIT_ERROR_DESCRIBE=%zu\n"
	.align	3
.LC1095:
	.string	"constant_signed.GIT_ERROR_DESCRIBE=%d\n"
	.align	3
.LC1096:
	.string	"enum_expression_size.GIT_ERROR_FETCHHEAD=%zu\n"
	.align	3
.LC1097:
	.string	"enum_expression_signed.GIT_ERROR_FETCHHEAD=%d\n"
	.align	3
.LC1098:
	.string	"constant.GIT_ERROR_FETCHHEAD="
	.align	3
.LC1099:
	.string	"constant_size.GIT_ERROR_FETCHHEAD=%zu\n"
	.align	3
.LC1100:
	.string	"constant_signed.GIT_ERROR_FETCHHEAD=%d\n"
	.align	3
.LC1101:
	.string	"enum_expression_size.GIT_ERROR_FILESYSTEM=%zu\n"
	.align	3
.LC1102:
	.string	"enum_expression_signed.GIT_ERROR_FILESYSTEM=%d\n"
	.align	3
.LC1103:
	.string	"constant.GIT_ERROR_FILESYSTEM="
	.align	3
.LC1104:
	.string	"constant_size.GIT_ERROR_FILESYSTEM=%zu\n"
	.align	3
.LC1105:
	.string	"constant_signed.GIT_ERROR_FILESYSTEM=%d\n"
	.align	3
.LC1106:
	.string	"enum_expression_size.GIT_ERROR_FILTER=%zu\n"
	.align	3
.LC1107:
	.string	"enum_expression_signed.GIT_ERROR_FILTER=%d\n"
	.align	3
.LC1108:
	.string	"constant.GIT_ERROR_FILTER="
	.align	3
.LC1109:
	.string	"constant_size.GIT_ERROR_FILTER=%zu\n"
	.align	3
.LC1110:
	.string	"constant_signed.GIT_ERROR_FILTER=%d\n"
	.align	3
.LC1111:
	.string	"enum_expression_size.GIT_ERROR_GRAFTS=%zu\n"
	.align	3
.LC1112:
	.string	"enum_expression_signed.GIT_ERROR_GRAFTS=%d\n"
	.align	3
.LC1113:
	.string	"constant.GIT_ERROR_GRAFTS="
	.align	3
.LC1114:
	.string	"constant_size.GIT_ERROR_GRAFTS=%zu\n"
	.align	3
.LC1115:
	.string	"constant_signed.GIT_ERROR_GRAFTS=%d\n"
	.align	3
.LC1116:
	.string	"enum_expression_size.GIT_ERROR_HTTP=%zu\n"
	.align	3
.LC1117:
	.string	"enum_expression_signed.GIT_ERROR_HTTP=%d\n"
	.align	3
.LC1118:
	.string	"constant.GIT_ERROR_HTTP="
	.align	3
.LC1119:
	.string	"constant_size.GIT_ERROR_HTTP=%zu\n"
	.align	3
.LC1120:
	.string	"constant_signed.GIT_ERROR_HTTP=%d\n"
	.align	3
.LC1121:
	.string	"enum_expression_size.GIT_ERROR_INDEX=%zu\n"
	.align	3
.LC1122:
	.string	"enum_expression_signed.GIT_ERROR_INDEX=%d\n"
	.align	3
.LC1123:
	.string	"constant.GIT_ERROR_INDEX="
	.align	3
.LC1124:
	.string	"constant_size.GIT_ERROR_INDEX=%zu\n"
	.align	3
.LC1125:
	.string	"constant_signed.GIT_ERROR_INDEX=%d\n"
	.align	3
.LC1126:
	.string	"enum_expression_size.GIT_ERROR_INDEXER=%zu\n"
	.align	3
.LC1127:
	.string	"enum_expression_signed.GIT_ERROR_INDEXER=%d\n"
	.align	3
.LC1128:
	.string	"constant.GIT_ERROR_INDEXER="
	.align	3
.LC1129:
	.string	"constant_size.GIT_ERROR_INDEXER=%zu\n"
	.align	3
.LC1130:
	.string	"constant_signed.GIT_ERROR_INDEXER=%d\n"
	.align	3
.LC1131:
	.string	"enum_expression_size.GIT_ERROR_INTERNAL=%zu\n"
	.align	3
.LC1132:
	.string	"enum_expression_signed.GIT_ERROR_INTERNAL=%d\n"
	.align	3
.LC1133:
	.string	"constant.GIT_ERROR_INTERNAL="
	.align	3
.LC1134:
	.string	"constant_size.GIT_ERROR_INTERNAL=%zu\n"
	.align	3
.LC1135:
	.string	"constant_signed.GIT_ERROR_INTERNAL=%d\n"
	.align	3
.LC1136:
	.string	"enum_expression_size.GIT_ERROR_INVALID=%zu\n"
	.align	3
.LC1137:
	.string	"enum_expression_signed.GIT_ERROR_INVALID=%d\n"
	.align	3
.LC1138:
	.string	"constant.GIT_ERROR_INVALID="
	.align	3
.LC1139:
	.string	"constant_size.GIT_ERROR_INVALID=%zu\n"
	.align	3
.LC1140:
	.string	"constant_signed.GIT_ERROR_INVALID=%d\n"
	.align	3
.LC1141:
	.string	"enum_expression_size.GIT_ERROR_MERGE=%zu\n"
	.align	3
.LC1142:
	.string	"enum_expression_signed.GIT_ERROR_MERGE=%d\n"
	.align	3
.LC1143:
	.string	"constant.GIT_ERROR_MERGE="
	.align	3
.LC1144:
	.string	"constant_size.GIT_ERROR_MERGE=%zu\n"
	.align	3
.LC1145:
	.string	"constant_signed.GIT_ERROR_MERGE=%d\n"
	.align	3
.LC1146:
	.string	"enum_expression_size.GIT_ERROR_NET=%zu\n"
	.align	3
.LC1147:
	.string	"enum_expression_signed.GIT_ERROR_NET=%d\n"
	.align	3
.LC1148:
	.string	"constant.GIT_ERROR_NET="
	.align	3
.LC1149:
	.string	"constant_size.GIT_ERROR_NET=%zu\n"
	.align	3
.LC1150:
	.string	"constant_signed.GIT_ERROR_NET=%d\n"
	.align	3
.LC1151:
	.string	"enum_expression_size.GIT_ERROR_NOMEMORY=%zu\n"
	.align	3
.LC1152:
	.string	"enum_expression_signed.GIT_ERROR_NOMEMORY=%d\n"
	.align	3
.LC1153:
	.string	"constant.GIT_ERROR_NOMEMORY="
	.align	3
.LC1154:
	.string	"constant_size.GIT_ERROR_NOMEMORY=%zu\n"
	.align	3
.LC1155:
	.string	"constant_signed.GIT_ERROR_NOMEMORY=%d\n"
	.align	3
.LC1156:
	.string	"enum_expression_size.GIT_ERROR_NONE=%zu\n"
	.align	3
.LC1157:
	.string	"enum_expression_signed.GIT_ERROR_NONE=%d\n"
	.align	3
.LC1158:
	.string	"constant.GIT_ERROR_NONE="
	.align	3
.LC1159:
	.string	"constant_size.GIT_ERROR_NONE=%zu\n"
	.align	3
.LC1160:
	.string	"constant_signed.GIT_ERROR_NONE=%d\n"
	.align	3
.LC1161:
	.string	"enum_expression_size.GIT_ERROR_OBJECT=%zu\n"
	.align	3
.LC1162:
	.string	"enum_expression_signed.GIT_ERROR_OBJECT=%d\n"
	.align	3
.LC1163:
	.string	"constant.GIT_ERROR_OBJECT="
	.align	3
.LC1164:
	.string	"constant_size.GIT_ERROR_OBJECT=%zu\n"
	.align	3
.LC1165:
	.string	"constant_signed.GIT_ERROR_OBJECT=%d\n"
	.align	3
.LC1166:
	.string	"enum_expression_size.GIT_ERROR_ODB=%zu\n"
	.align	3
.LC1167:
	.string	"enum_expression_signed.GIT_ERROR_ODB=%d\n"
	.align	3
.LC1168:
	.string	"constant.GIT_ERROR_ODB="
	.align	3
.LC1169:
	.string	"constant_size.GIT_ERROR_ODB=%zu\n"
	.align	3
.LC1170:
	.string	"constant_signed.GIT_ERROR_ODB=%d\n"
	.align	3
.LC1171:
	.string	"enum_expression_size.GIT_ERROR_OS=%zu\n"
	.align	3
.LC1172:
	.string	"enum_expression_signed.GIT_ERROR_OS=%d\n"
	.align	3
.LC1173:
	.string	"constant.GIT_ERROR_OS="
	.align	3
.LC1174:
	.string	"constant_size.GIT_ERROR_OS=%zu\n"
	.align	3
.LC1175:
	.string	"constant_signed.GIT_ERROR_OS=%d\n"
	.align	3
.LC1176:
	.string	"enum_expression_size.GIT_ERROR_PATCH=%zu\n"
	.align	3
.LC1177:
	.string	"enum_expression_signed.GIT_ERROR_PATCH=%d\n"
	.align	3
.LC1178:
	.string	"constant.GIT_ERROR_PATCH="
	.align	3
.LC1179:
	.string	"constant_size.GIT_ERROR_PATCH=%zu\n"
	.align	3
.LC1180:
	.string	"constant_signed.GIT_ERROR_PATCH=%d\n"
	.align	3
.LC1181:
	.string	"enum_expression_size.GIT_ERROR_REBASE=%zu\n"
	.align	3
.LC1182:
	.string	"enum_expression_signed.GIT_ERROR_REBASE=%d\n"
	.align	3
.LC1183:
	.string	"constant.GIT_ERROR_REBASE="
	.align	3
.LC1184:
	.string	"constant_size.GIT_ERROR_REBASE=%zu\n"
	.align	3
.LC1185:
	.string	"constant_signed.GIT_ERROR_REBASE=%d\n"
	.align	3
.LC1186:
	.string	"enum_expression_size.GIT_ERROR_REFERENCE=%zu\n"
	.align	3
.LC1187:
	.string	"enum_expression_signed.GIT_ERROR_REFERENCE=%d\n"
	.align	3
.LC1188:
	.string	"constant.GIT_ERROR_REFERENCE="
	.align	3
.LC1189:
	.string	"constant_size.GIT_ERROR_REFERENCE=%zu\n"
	.align	3
.LC1190:
	.string	"constant_signed.GIT_ERROR_REFERENCE=%d\n"
	.align	3
.LC1191:
	.string	"enum_expression_size.GIT_ERROR_REGEX=%zu\n"
	.align	3
.LC1192:
	.string	"enum_expression_signed.GIT_ERROR_REGEX=%d\n"
	.align	3
.LC1193:
	.string	"constant.GIT_ERROR_REGEX="
	.align	3
.LC1194:
	.string	"constant_size.GIT_ERROR_REGEX=%zu\n"
	.align	3
.LC1195:
	.string	"constant_signed.GIT_ERROR_REGEX=%d\n"
	.align	3
.LC1196:
	.string	"enum_expression_size.GIT_ERROR_REPOSITORY=%zu\n"
	.align	3
.LC1197:
	.string	"enum_expression_signed.GIT_ERROR_REPOSITORY=%d\n"
	.align	3
.LC1198:
	.string	"constant.GIT_ERROR_REPOSITORY="
	.align	3
.LC1199:
	.string	"constant_size.GIT_ERROR_REPOSITORY=%zu\n"
	.align	3
.LC1200:
	.string	"constant_signed.GIT_ERROR_REPOSITORY=%d\n"
	.align	3
.LC1201:
	.string	"enum_expression_size.GIT_ERROR_REVERT=%zu\n"
	.align	3
.LC1202:
	.string	"enum_expression_signed.GIT_ERROR_REVERT=%d\n"
	.align	3
.LC1203:
	.string	"constant.GIT_ERROR_REVERT="
	.align	3
.LC1204:
	.string	"constant_size.GIT_ERROR_REVERT=%zu\n"
	.align	3
.LC1205:
	.string	"constant_signed.GIT_ERROR_REVERT=%d\n"
	.align	3
.LC1206:
	.string	"enum_expression_size.GIT_ERROR_SHA=%zu\n"
	.align	3
.LC1207:
	.string	"enum_expression_signed.GIT_ERROR_SHA=%d\n"
	.align	3
.LC1208:
	.string	"constant.GIT_ERROR_SHA="
	.align	3
.LC1209:
	.string	"constant_size.GIT_ERROR_SHA=%zu\n"
	.align	3
.LC1210:
	.string	"constant_signed.GIT_ERROR_SHA=%d\n"
	.align	3
.LC1211:
	.string	"enum_expression_size.GIT_ERROR_SSH=%zu\n"
	.align	3
.LC1212:
	.string	"enum_expression_signed.GIT_ERROR_SSH=%d\n"
	.align	3
.LC1213:
	.string	"constant.GIT_ERROR_SSH="
	.align	3
.LC1214:
	.string	"constant_size.GIT_ERROR_SSH=%zu\n"
	.align	3
.LC1215:
	.string	"constant_signed.GIT_ERROR_SSH=%d\n"
	.align	3
.LC1216:
	.string	"enum_expression_size.GIT_ERROR_SSL=%zu\n"
	.align	3
.LC1217:
	.string	"enum_expression_signed.GIT_ERROR_SSL=%d\n"
	.align	3
.LC1218:
	.string	"constant.GIT_ERROR_SSL="
	.align	3
.LC1219:
	.string	"constant_size.GIT_ERROR_SSL=%zu\n"
	.align	3
.LC1220:
	.string	"constant_signed.GIT_ERROR_SSL=%d\n"
	.align	3
.LC1221:
	.string	"enum_expression_size.GIT_ERROR_STASH=%zu\n"
	.align	3
.LC1222:
	.string	"enum_expression_signed.GIT_ERROR_STASH=%d\n"
	.align	3
.LC1223:
	.string	"constant.GIT_ERROR_STASH="
	.align	3
.LC1224:
	.string	"constant_size.GIT_ERROR_STASH=%zu\n"
	.align	3
.LC1225:
	.string	"constant_signed.GIT_ERROR_STASH=%d\n"
	.align	3
.LC1226:
	.string	"enum_expression_size.GIT_ERROR_SUBMODULE=%zu\n"
	.align	3
.LC1227:
	.string	"enum_expression_signed.GIT_ERROR_SUBMODULE=%d\n"
	.align	3
.LC1228:
	.string	"constant.GIT_ERROR_SUBMODULE="
	.align	3
.LC1229:
	.string	"constant_size.GIT_ERROR_SUBMODULE=%zu\n"
	.align	3
.LC1230:
	.string	"constant_signed.GIT_ERROR_SUBMODULE=%d\n"
	.align	3
.LC1231:
	.string	"enum_expression_size.GIT_ERROR_TAG=%zu\n"
	.align	3
.LC1232:
	.string	"enum_expression_signed.GIT_ERROR_TAG=%d\n"
	.align	3
.LC1233:
	.string	"constant.GIT_ERROR_TAG="
	.align	3
.LC1234:
	.string	"constant_size.GIT_ERROR_TAG=%zu\n"
	.align	3
.LC1235:
	.string	"constant_signed.GIT_ERROR_TAG=%d\n"
	.align	3
.LC1236:
	.string	"enum_expression_size.GIT_ERROR_THREAD=%zu\n"
	.align	3
.LC1237:
	.string	"enum_expression_signed.GIT_ERROR_THREAD=%d\n"
	.align	3
.LC1238:
	.string	"constant.GIT_ERROR_THREAD="
	.align	3
.LC1239:
	.string	"constant_size.GIT_ERROR_THREAD=%zu\n"
	.align	3
.LC1240:
	.string	"constant_signed.GIT_ERROR_THREAD=%d\n"
	.align	3
.LC1241:
	.string	"enum_expression_size.GIT_ERROR_TREE=%zu\n"
	.align	3
.LC1242:
	.string	"enum_expression_signed.GIT_ERROR_TREE=%d\n"
	.align	3
.LC1243:
	.string	"constant.GIT_ERROR_TREE="
	.align	3
.LC1244:
	.string	"constant_size.GIT_ERROR_TREE=%zu\n"
	.align	3
.LC1245:
	.string	"constant_signed.GIT_ERROR_TREE=%d\n"
	.align	3
.LC1246:
	.string	"enum_expression_size.GIT_ERROR_WORKTREE=%zu\n"
	.align	3
.LC1247:
	.string	"enum_expression_signed.GIT_ERROR_WORKTREE=%d\n"
	.align	3
.LC1248:
	.string	"constant.GIT_ERROR_WORKTREE="
	.align	3
.LC1249:
	.string	"constant_size.GIT_ERROR_WORKTREE=%zu\n"
	.align	3
.LC1250:
	.string	"constant_signed.GIT_ERROR_WORKTREE=%d\n"
	.align	3
.LC1251:
	.string	"enum_expression_size.GIT_ERROR_ZLIB=%zu\n"
	.align	3
.LC1252:
	.string	"enum_expression_signed.GIT_ERROR_ZLIB=%d\n"
	.align	3
.LC1253:
	.string	"constant.GIT_ERROR_ZLIB="
	.align	3
.LC1254:
	.string	"constant_size.GIT_ERROR_ZLIB=%zu\n"
	.align	3
.LC1255:
	.string	"constant_signed.GIT_ERROR_ZLIB=%d\n"
	.align	3
.LC1256:
	.string	"enum_expression_size.GIT_EUNBORNBRANCH=%zu\n"
	.align	3
.LC1257:
	.string	"enum_expression_signed.GIT_EUNBORNBRANCH=%d\n"
	.align	3
.LC1258:
	.string	"constant.GIT_EUNBORNBRANCH="
	.align	3
.LC1259:
	.string	"constant_size.GIT_EUNBORNBRANCH=%zu\n"
	.align	3
.LC1260:
	.string	"constant_signed.GIT_EUNBORNBRANCH=%d\n"
	.align	3
.LC1261:
	.string	"enum_expression_size.GIT_EUNCHANGED=%zu\n"
	.align	3
.LC1262:
	.string	"enum_expression_signed.GIT_EUNCHANGED=%d\n"
	.align	3
.LC1263:
	.string	"constant.GIT_EUNCHANGED="
	.align	3
.LC1264:
	.string	"constant_size.GIT_EUNCHANGED=%zu\n"
	.align	3
.LC1265:
	.string	"constant_signed.GIT_EUNCHANGED=%d\n"
	.align	3
.LC1266:
	.string	"enum_expression_size.GIT_EUNCOMMITTED=%zu\n"
	.align	3
.LC1267:
	.string	"enum_expression_signed.GIT_EUNCOMMITTED=%d\n"
	.align	3
.LC1268:
	.string	"constant.GIT_EUNCOMMITTED="
	.align	3
.LC1269:
	.string	"constant_size.GIT_EUNCOMMITTED=%zu\n"
	.align	3
.LC1270:
	.string	"constant_signed.GIT_EUNCOMMITTED=%d\n"
	.align	3
.LC1271:
	.string	"enum_expression_size.GIT_EUNMERGED=%zu\n"
	.align	3
.LC1272:
	.string	"enum_expression_signed.GIT_EUNMERGED=%d\n"
	.align	3
.LC1273:
	.string	"constant.GIT_EUNMERGED="
	.align	3
.LC1274:
	.string	"constant_size.GIT_EUNMERGED=%zu\n"
	.align	3
.LC1275:
	.string	"constant_signed.GIT_EUNMERGED=%d\n"
	.align	3
.LC1276:
	.string	"enum_expression_size.GIT_EUSER=%zu\n"
	.align	3
.LC1277:
	.string	"enum_expression_signed.GIT_EUSER=%d\n"
	.align	3
.LC1278:
	.string	"constant.GIT_EUSER="
	.align	3
.LC1279:
	.string	"constant_size.GIT_EUSER=%zu\n"
	.align	3
.LC1280:
	.string	"constant_signed.GIT_EUSER=%d\n"
	.align	3
.LC1281:
	.string	"enum_expression_size.GIT_FEATURE_AUTH_NEGOTIATE=%zu\n"
	.align	3
.LC1282:
	.string	"enum_expression_signed.GIT_FEATURE_AUTH_NEGOTIATE=%d\n"
	.align	3
.LC1283:
	.string	"constant.GIT_FEATURE_AUTH_NEGOTIATE="
	.align	3
.LC1284:
	.string	"constant_size.GIT_FEATURE_AUTH_NEGOTIATE=%zu\n"
	.align	3
.LC1285:
	.string	"constant_signed.GIT_FEATURE_AUTH_NEGOTIATE=%d\n"
	.align	3
.LC1286:
	.string	"enum_expression_size.GIT_FEATURE_AUTH_NTLM=%zu\n"
	.align	3
.LC1287:
	.string	"enum_expression_signed.GIT_FEATURE_AUTH_NTLM=%d\n"
	.align	3
.LC1288:
	.string	"constant.GIT_FEATURE_AUTH_NTLM="
	.align	3
.LC1289:
	.string	"constant_size.GIT_FEATURE_AUTH_NTLM=%zu\n"
	.align	3
.LC1290:
	.string	"constant_signed.GIT_FEATURE_AUTH_NTLM=%d\n"
	.align	3
.LC1291:
	.string	"enum_expression_size.GIT_FEATURE_COMPRESSION=%zu\n"
	.align	3
.LC1292:
	.string	"enum_expression_signed.GIT_FEATURE_COMPRESSION=%d\n"
	.align	3
.LC1293:
	.string	"constant.GIT_FEATURE_COMPRESSION="
	.align	3
.LC1294:
	.string	"constant_size.GIT_FEATURE_COMPRESSION=%zu\n"
	.align	3
.LC1295:
	.string	"constant_signed.GIT_FEATURE_COMPRESSION=%d\n"
	.align	3
.LC1296:
	.string	"enum_expression_size.GIT_FEATURE_HTTPS=%zu\n"
	.align	3
.LC1297:
	.string	"enum_expression_signed.GIT_FEATURE_HTTPS=%d\n"
	.align	3
.LC1298:
	.string	"constant.GIT_FEATURE_HTTPS="
	.align	3
.LC1299:
	.string	"constant_size.GIT_FEATURE_HTTPS=%zu\n"
	.align	3
.LC1300:
	.string	"constant_signed.GIT_FEATURE_HTTPS=%d\n"
	.align	3
.LC1301:
	.string	"enum_expression_size.GIT_FEATURE_HTTP_PARSER=%zu\n"
	.align	3
.LC1302:
	.string	"enum_expression_signed.GIT_FEATURE_HTTP_PARSER=%d\n"
	.align	3
.LC1303:
	.string	"constant.GIT_FEATURE_HTTP_PARSER="
	.align	3
.LC1304:
	.string	"constant_size.GIT_FEATURE_HTTP_PARSER=%zu\n"
	.align	3
.LC1305:
	.string	"constant_signed.GIT_FEATURE_HTTP_PARSER=%d\n"
	.align	3
.LC1306:
	.string	"enum_expression_size.GIT_FEATURE_I18N=%zu\n"
	.align	3
.LC1307:
	.string	"enum_expression_signed.GIT_FEATURE_I18N=%d\n"
	.align	3
.LC1308:
	.string	"constant.GIT_FEATURE_I18N="
	.align	3
.LC1309:
	.string	"constant_size.GIT_FEATURE_I18N=%zu\n"
	.align	3
.LC1310:
	.string	"constant_signed.GIT_FEATURE_I18N=%d\n"
	.align	3
.LC1311:
	.string	"enum_expression_size.GIT_FEATURE_NSEC=%zu\n"
	.align	3
.LC1312:
	.string	"enum_expression_signed.GIT_FEATURE_NSEC=%d\n"
	.align	3
.LC1313:
	.string	"constant.GIT_FEATURE_NSEC="
	.align	3
.LC1314:
	.string	"constant_size.GIT_FEATURE_NSEC=%zu\n"
	.align	3
.LC1315:
	.string	"constant_signed.GIT_FEATURE_NSEC=%d\n"
	.align	3
.LC1316:
	.string	"enum_expression_size.GIT_FEATURE_REGEX=%zu\n"
	.align	3
.LC1317:
	.string	"enum_expression_signed.GIT_FEATURE_REGEX=%d\n"
	.align	3
.LC1318:
	.string	"constant.GIT_FEATURE_REGEX="
	.align	3
.LC1319:
	.string	"constant_size.GIT_FEATURE_REGEX=%zu\n"
	.align	3
.LC1320:
	.string	"constant_signed.GIT_FEATURE_REGEX=%d\n"
	.align	3
.LC1321:
	.string	"enum_expression_size.GIT_FEATURE_SHA1=%zu\n"
	.align	3
.LC1322:
	.string	"enum_expression_signed.GIT_FEATURE_SHA1=%d\n"
	.align	3
.LC1323:
	.string	"constant.GIT_FEATURE_SHA1="
	.align	3
.LC1324:
	.string	"constant_size.GIT_FEATURE_SHA1=%zu\n"
	.align	3
.LC1325:
	.string	"constant_signed.GIT_FEATURE_SHA1=%d\n"
	.align	3
.LC1326:
	.string	"enum_expression_size.GIT_FEATURE_SHA256=%zu\n"
	.align	3
.LC1327:
	.string	"enum_expression_signed.GIT_FEATURE_SHA256=%d\n"
	.align	3
.LC1328:
	.string	"constant.GIT_FEATURE_SHA256="
	.align	3
.LC1329:
	.string	"constant_size.GIT_FEATURE_SHA256=%zu\n"
	.align	3
.LC1330:
	.string	"constant_signed.GIT_FEATURE_SHA256=%d\n"
	.align	3
.LC1331:
	.string	"enum_expression_size.GIT_FEATURE_SSH=%zu\n"
	.align	3
.LC1332:
	.string	"enum_expression_signed.GIT_FEATURE_SSH=%d\n"
	.align	3
.LC1333:
	.string	"constant.GIT_FEATURE_SSH="
	.align	3
.LC1334:
	.string	"constant_size.GIT_FEATURE_SSH=%zu\n"
	.align	3
.LC1335:
	.string	"constant_signed.GIT_FEATURE_SSH=%d\n"
	.align	3
.LC1336:
	.string	"enum_expression_size.GIT_FEATURE_THREADS=%zu\n"
	.align	3
.LC1337:
	.string	"enum_expression_signed.GIT_FEATURE_THREADS=%d\n"
	.align	3
.LC1338:
	.string	"constant.GIT_FEATURE_THREADS="
	.align	3
.LC1339:
	.string	"constant_size.GIT_FEATURE_THREADS=%zu\n"
	.align	3
.LC1340:
	.string	"constant_signed.GIT_FEATURE_THREADS=%d\n"
	.align	3
.LC1341:
	.string	"enum_expression_size.GIT_FETCH_DEPTH_FULL=%zu\n"
	.align	3
.LC1342:
	.string	"enum_expression_signed.GIT_FETCH_DEPTH_FULL=%d\n"
	.align	3
.LC1343:
	.string	"constant.GIT_FETCH_DEPTH_FULL="
	.align	3
.LC1344:
	.string	"constant_size.GIT_FETCH_DEPTH_FULL=%zu\n"
	.align	3
.LC1345:
	.string	"constant_signed.GIT_FETCH_DEPTH_FULL=%d\n"
	.align	3
.LC1346:
	.string	"enum_expression_size.GIT_FETCH_DEPTH_UNSHALLOW=%zu\n"
	.align	3
.LC1347:
	.string	"enum_expression_signed.GIT_FETCH_DEPTH_UNSHALLOW=%d\n"
	.align	3
.LC1348:
	.string	"constant.GIT_FETCH_DEPTH_UNSHALLOW="
	.align	3
.LC1349:
	.string	"constant_size.GIT_FETCH_DEPTH_UNSHALLOW=%zu\n"
	.align	3
.LC1350:
	.string	"constant_signed.GIT_FETCH_DEPTH_UNSHALLOW=%d\n"
	.align	3
.LC1351:
	.string	"enum_expression_size.GIT_FETCH_NO_PRUNE=%zu\n"
	.align	3
.LC1352:
	.string	"enum_expression_signed.GIT_FETCH_NO_PRUNE=%d\n"
	.align	3
.LC1353:
	.string	"constant.GIT_FETCH_NO_PRUNE="
	.align	3
.LC1354:
	.string	"constant_size.GIT_FETCH_NO_PRUNE=%zu\n"
	.align	3
.LC1355:
	.string	"constant_signed.GIT_FETCH_NO_PRUNE=%d\n"
	.align	3
.LC1356:
	.string	"enum_expression_size.GIT_FETCH_PRUNE=%zu\n"
	.align	3
.LC1357:
	.string	"enum_expression_signed.GIT_FETCH_PRUNE=%d\n"
	.align	3
.LC1358:
	.string	"constant.GIT_FETCH_PRUNE="
	.align	3
.LC1359:
	.string	"constant_size.GIT_FETCH_PRUNE=%zu\n"
	.align	3
.LC1360:
	.string	"constant_signed.GIT_FETCH_PRUNE=%d\n"
	.align	3
.LC1361:
	.string	"enum_expression_size.GIT_FETCH_PRUNE_UNSPECIFIED=%zu\n"
	.align	3
.LC1362:
	.string	"enum_expression_signed.GIT_FETCH_PRUNE_UNSPECIFIED=%d\n"
	.align	3
.LC1363:
	.string	"constant.GIT_FETCH_PRUNE_UNSPECIFIED="
	.align	3
.LC1364:
	.string	"constant_size.GIT_FETCH_PRUNE_UNSPECIFIED=%zu\n"
	.align	3
.LC1365:
	.string	"constant_signed.GIT_FETCH_PRUNE_UNSPECIFIED=%d\n"
	.align	3
.LC1366:
	.string	"enum_expression_size.GIT_FILEMODE_BLOB=%zu\n"
	.align	3
.LC1367:
	.string	"enum_expression_signed.GIT_FILEMODE_BLOB=%d\n"
	.align	3
.LC1368:
	.string	"constant.GIT_FILEMODE_BLOB="
	.align	3
.LC1369:
	.string	"constant_size.GIT_FILEMODE_BLOB=%zu\n"
	.align	3
.LC1370:
	.string	"constant_signed.GIT_FILEMODE_BLOB=%d\n"
	.align	3
.LC1371:
	.string	"enum_expression_size.GIT_FILEMODE_BLOB_EXECUTABLE=%zu\n"
	.align	3
.LC1372:
	.string	"enum_expression_signed.GIT_FILEMODE_BLOB_EXECUTABLE=%d\n"
	.align	3
.LC1373:
	.string	"constant.GIT_FILEMODE_BLOB_EXECUTABLE="
	.align	3
.LC1374:
	.string	"constant_size.GIT_FILEMODE_BLOB_EXECUTABLE=%zu\n"
	.align	3
.LC1375:
	.string	"constant_signed.GIT_FILEMODE_BLOB_EXECUTABLE=%d\n"
	.align	3
.LC1376:
	.string	"enum_expression_size.GIT_FILEMODE_COMMIT=%zu\n"
	.align	3
.LC1377:
	.string	"enum_expression_signed.GIT_FILEMODE_COMMIT=%d\n"
	.align	3
.LC1378:
	.string	"constant.GIT_FILEMODE_COMMIT="
	.align	3
.LC1379:
	.string	"constant_size.GIT_FILEMODE_COMMIT=%zu\n"
	.align	3
.LC1380:
	.string	"constant_signed.GIT_FILEMODE_COMMIT=%d\n"
	.align	3
.LC1381:
	.string	"enum_expression_size.GIT_FILEMODE_LINK=%zu\n"
	.align	3
.LC1382:
	.string	"enum_expression_signed.GIT_FILEMODE_LINK=%d\n"
	.align	3
.LC1383:
	.string	"constant.GIT_FILEMODE_LINK="
	.align	3
.LC1384:
	.string	"constant_size.GIT_FILEMODE_LINK=%zu\n"
	.align	3
.LC1385:
	.string	"constant_signed.GIT_FILEMODE_LINK=%d\n"
	.align	3
.LC1386:
	.string	"enum_expression_size.GIT_FILEMODE_TREE=%zu\n"
	.align	3
.LC1387:
	.string	"enum_expression_signed.GIT_FILEMODE_TREE=%d\n"
	.align	3
.LC1388:
	.string	"constant.GIT_FILEMODE_TREE="
	.align	3
.LC1389:
	.string	"constant_size.GIT_FILEMODE_TREE=%zu\n"
	.align	3
.LC1390:
	.string	"constant_signed.GIT_FILEMODE_TREE=%d\n"
	.align	3
.LC1391:
	.string	"enum_expression_size.GIT_FILEMODE_UNREADABLE=%zu\n"
	.align	3
.LC1392:
	.string	"enum_expression_signed.GIT_FILEMODE_UNREADABLE=%d\n"
	.align	3
.LC1393:
	.string	"constant.GIT_FILEMODE_UNREADABLE="
	.align	3
.LC1394:
	.string	"constant_size.GIT_FILEMODE_UNREADABLE=%zu\n"
	.align	3
.LC1395:
	.string	"constant_signed.GIT_FILEMODE_UNREADABLE=%d\n"
	.align	3
.LC1396:
	.string	"enum_expression_size.GIT_FILTER_ALLOW_UNSAFE=%zu\n"
	.align	3
.LC1397:
	.string	"enum_expression_signed.GIT_FILTER_ALLOW_UNSAFE=%d\n"
	.align	3
.LC1398:
	.string	"constant.GIT_FILTER_ALLOW_UNSAFE="
	.align	3
.LC1399:
	.string	"constant_size.GIT_FILTER_ALLOW_UNSAFE=%zu\n"
	.align	3
.LC1400:
	.string	"constant_signed.GIT_FILTER_ALLOW_UNSAFE=%d\n"
	.align	3
.LC1401:
	.string	"enum_expression_size.GIT_FILTER_ATTRIBUTES_FROM_COMMIT=%zu\n"
	.align	3
.LC1402:
	.string	"enum_expression_signed.GIT_FILTER_ATTRIBUTES_FROM_COMMIT=%d\n"
	.align	3
.LC1403:
	.string	"constant.GIT_FILTER_ATTRIBUTES_FROM_COMMIT="
	.align	3
.LC1404:
	.string	"constant_size.GIT_FILTER_ATTRIBUTES_FROM_COMMIT=%zu\n"
	.align	3
.LC1405:
	.string	"constant_signed.GIT_FILTER_ATTRIBUTES_FROM_COMMIT=%d\n"
	.align	3
.LC1406:
	.string	"enum_expression_size.GIT_FILTER_ATTRIBUTES_FROM_HEAD=%zu\n"
	.align	3
.LC1407:
	.string	"enum_expression_signed.GIT_FILTER_ATTRIBUTES_FROM_HEAD=%d\n"
	.align	3
.LC1408:
	.string	"constant.GIT_FILTER_ATTRIBUTES_FROM_HEAD="
	.align	3
.LC1409:
	.string	"constant_size.GIT_FILTER_ATTRIBUTES_FROM_HEAD=%zu\n"
	.align	3
.LC1410:
	.string	"constant_signed.GIT_FILTER_ATTRIBUTES_FROM_HEAD=%d\n"
	.align	3
.LC1411:
	.string	"enum_expression_size.GIT_FILTER_CLEAN=%zu\n"
	.align	3
.LC1412:
	.string	"enum_expression_signed.GIT_FILTER_CLEAN=%d\n"
	.align	3
.LC1413:
	.string	"constant.GIT_FILTER_CLEAN="
	.align	3
.LC1414:
	.string	"constant_size.GIT_FILTER_CLEAN=%zu\n"
	.align	3
.LC1415:
	.string	"constant_signed.GIT_FILTER_CLEAN=%d\n"
	.align	3
.LC1416:
	.string	"enum_expression_size.GIT_FILTER_DEFAULT=%zu\n"
	.align	3
.LC1417:
	.string	"enum_expression_signed.GIT_FILTER_DEFAULT=%d\n"
	.align	3
.LC1418:
	.string	"constant.GIT_FILTER_DEFAULT="
	.align	3
.LC1419:
	.string	"constant_size.GIT_FILTER_DEFAULT=%zu\n"
	.align	3
.LC1420:
	.string	"constant_signed.GIT_FILTER_DEFAULT=%d\n"
	.align	3
.LC1421:
	.string	"enum_expression_size.GIT_FILTER_NO_SYSTEM_ATTRIBUTES=%zu\n"
	.align	3
.LC1422:
	.string	"enum_expression_signed.GIT_FILTER_NO_SYSTEM_ATTRIBUTES=%d\n"
	.align	3
.LC1423:
	.string	"constant.GIT_FILTER_NO_SYSTEM_ATTRIBUTES="
	.align	3
.LC1424:
	.string	"constant_size.GIT_FILTER_NO_SYSTEM_ATTRIBUTES=%zu\n"
	.align	3
.LC1425:
	.string	"constant_signed.GIT_FILTER_NO_SYSTEM_ATTRIBUTES=%d\n"
	.align	3
.LC1426:
	.string	"enum_expression_size.GIT_FILTER_SMUDGE=%zu\n"
	.align	3
.LC1427:
	.string	"enum_expression_signed.GIT_FILTER_SMUDGE=%d\n"
	.align	3
.LC1428:
	.string	"constant.GIT_FILTER_SMUDGE="
	.align	3
.LC1429:
	.string	"constant_size.GIT_FILTER_SMUDGE=%zu\n"
	.align	3
.LC1430:
	.string	"constant_signed.GIT_FILTER_SMUDGE=%d\n"
	.align	3
.LC1431:
	.string	"enum_expression_size.GIT_FILTER_TO_ODB=%zu\n"
	.align	3
.LC1432:
	.string	"enum_expression_signed.GIT_FILTER_TO_ODB=%d\n"
	.align	3
.LC1433:
	.string	"constant.GIT_FILTER_TO_ODB="
	.align	3
.LC1434:
	.string	"constant_size.GIT_FILTER_TO_ODB=%zu\n"
	.align	3
.LC1435:
	.string	"constant_signed.GIT_FILTER_TO_ODB=%d\n"
	.align	3
.LC1436:
	.string	"enum_expression_size.GIT_FILTER_TO_WORKTREE=%zu\n"
	.align	3
.LC1437:
	.string	"enum_expression_signed.GIT_FILTER_TO_WORKTREE=%d\n"
	.align	3
.LC1438:
	.string	"constant.GIT_FILTER_TO_WORKTREE="
	.align	3
.LC1439:
	.string	"constant_size.GIT_FILTER_TO_WORKTREE=%zu\n"
	.align	3
.LC1440:
	.string	"constant_signed.GIT_FILTER_TO_WORKTREE=%d\n"
	.align	3
.LC1441:
	.string	"enum_expression_size.GIT_INDEX_ADD_CHECK_PATHSPEC=%zu\n"
	.align	3
.LC1442:
	.string	"enum_expression_signed.GIT_INDEX_ADD_CHECK_PATHSPEC=%d\n"
	.align	3
.LC1443:
	.string	"constant.GIT_INDEX_ADD_CHECK_PATHSPEC="
	.align	3
.LC1444:
	.string	"constant_size.GIT_INDEX_ADD_CHECK_PATHSPEC=%zu\n"
	.align	3
.LC1445:
	.string	"constant_signed.GIT_INDEX_ADD_CHECK_PATHSPEC=%d\n"
	.align	3
.LC1446:
	.string	"enum_expression_size.GIT_INDEX_ADD_DEFAULT=%zu\n"
	.align	3
.LC1447:
	.string	"enum_expression_signed.GIT_INDEX_ADD_DEFAULT=%d\n"
	.align	3
.LC1448:
	.string	"constant.GIT_INDEX_ADD_DEFAULT="
	.align	3
.LC1449:
	.string	"constant_size.GIT_INDEX_ADD_DEFAULT=%zu\n"
	.align	3
.LC1450:
	.string	"constant_signed.GIT_INDEX_ADD_DEFAULT=%d\n"
	.align	3
.LC1451:
	.string	"enum_expression_size.GIT_INDEX_ADD_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC1452:
	.string	"enum_expression_signed.GIT_INDEX_ADD_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC1453:
	.string	"constant.GIT_INDEX_ADD_DISABLE_PATHSPEC_MATCH="
	.align	3
.LC1454:
	.string	"constant_size.GIT_INDEX_ADD_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC1455:
	.string	"constant_signed.GIT_INDEX_ADD_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC1456:
	.string	"enum_expression_size.GIT_INDEX_ADD_FORCE=%zu\n"
	.align	3
.LC1457:
	.string	"enum_expression_signed.GIT_INDEX_ADD_FORCE=%d\n"
	.align	3
.LC1458:
	.string	"constant.GIT_INDEX_ADD_FORCE="
	.align	3
.LC1459:
	.string	"constant_size.GIT_INDEX_ADD_FORCE=%zu\n"
	.align	3
.LC1460:
	.string	"constant_signed.GIT_INDEX_ADD_FORCE=%d\n"
	.align	3
.LC1461:
	.string	"enum_expression_size.GIT_INDEX_CAPABILITY_FROM_OWNER=%zu\n"
	.align	3
.LC1462:
	.string	"enum_expression_signed.GIT_INDEX_CAPABILITY_FROM_OWNER=%d\n"
	.align	3
.LC1463:
	.string	"constant.GIT_INDEX_CAPABILITY_FROM_OWNER="
	.align	3
.LC1464:
	.string	"constant_size.GIT_INDEX_CAPABILITY_FROM_OWNER=%zu\n"
	.align	3
.LC1465:
	.string	"constant_signed.GIT_INDEX_CAPABILITY_FROM_OWNER=%d\n"
	.align	3
.LC1466:
	.string	"enum_expression_size.GIT_INDEX_CAPABILITY_IGNORE_CASE=%zu\n"
	.align	3
.LC1467:
	.string	"enum_expression_signed.GIT_INDEX_CAPABILITY_IGNORE_CASE=%d\n"
	.align	3
.LC1468:
	.string	"constant.GIT_INDEX_CAPABILITY_IGNORE_CASE="
	.align	3
.LC1469:
	.string	"constant_size.GIT_INDEX_CAPABILITY_IGNORE_CASE=%zu\n"
	.align	3
.LC1470:
	.string	"constant_signed.GIT_INDEX_CAPABILITY_IGNORE_CASE=%d\n"
	.align	3
.LC1471:
	.string	"enum_expression_size.GIT_INDEX_CAPABILITY_NO_FILEMODE=%zu\n"
	.align	3
.LC1472:
	.string	"enum_expression_signed.GIT_INDEX_CAPABILITY_NO_FILEMODE=%d\n"
	.align	3
.LC1473:
	.string	"constant.GIT_INDEX_CAPABILITY_NO_FILEMODE="
	.align	3
.LC1474:
	.string	"constant_size.GIT_INDEX_CAPABILITY_NO_FILEMODE=%zu\n"
	.align	3
.LC1475:
	.string	"constant_signed.GIT_INDEX_CAPABILITY_NO_FILEMODE=%d\n"
	.align	3
.LC1476:
	.string	"enum_expression_size.GIT_INDEX_CAPABILITY_NO_SYMLINKS=%zu\n"
	.align	3
.LC1477:
	.string	"enum_expression_signed.GIT_INDEX_CAPABILITY_NO_SYMLINKS=%d\n"
	.align	3
.LC1478:
	.string	"constant.GIT_INDEX_CAPABILITY_NO_SYMLINKS="
	.align	3
.LC1479:
	.string	"constant_size.GIT_INDEX_CAPABILITY_NO_SYMLINKS=%zu\n"
	.align	3
.LC1480:
	.string	"constant_signed.GIT_INDEX_CAPABILITY_NO_SYMLINKS=%d\n"
	.align	3
.LC1481:
	.string	"enum_expression_size.GIT_INDEX_ENTRY_EXTENDED=%zu\n"
	.align	3
.LC1482:
	.string	"enum_expression_signed.GIT_INDEX_ENTRY_EXTENDED=%d\n"
	.align	3
.LC1483:
	.string	"constant.GIT_INDEX_ENTRY_EXTENDED="
	.align	3
.LC1484:
	.string	"constant_size.GIT_INDEX_ENTRY_EXTENDED=%zu\n"
	.align	3
.LC1485:
	.string	"constant_signed.GIT_INDEX_ENTRY_EXTENDED=%d\n"
	.align	3
.LC1486:
	.string	"enum_expression_size.GIT_INDEX_ENTRY_EXTENDED_FLAGS=%zu\n"
	.align	3
.LC1487:
	.string	"enum_expression_signed.GIT_INDEX_ENTRY_EXTENDED_FLAGS=%d\n"
	.align	3
.LC1488:
	.string	"constant.GIT_INDEX_ENTRY_EXTENDED_FLAGS="
	.align	3
.LC1489:
	.string	"constant_size.GIT_INDEX_ENTRY_EXTENDED_FLAGS=%zu\n"
	.align	3
.LC1490:
	.string	"constant_signed.GIT_INDEX_ENTRY_EXTENDED_FLAGS=%d\n"
	.align	3
.LC1491:
	.string	"enum_expression_size.GIT_INDEX_ENTRY_INTENT_TO_ADD=%zu\n"
	.align	3
.LC1492:
	.string	"enum_expression_signed.GIT_INDEX_ENTRY_INTENT_TO_ADD=%d\n"
	.align	3
.LC1493:
	.string	"constant.GIT_INDEX_ENTRY_INTENT_TO_ADD="
	.align	3
.LC1494:
	.string	"constant_size.GIT_INDEX_ENTRY_INTENT_TO_ADD=%zu\n"
	.align	3
.LC1495:
	.string	"constant_signed.GIT_INDEX_ENTRY_INTENT_TO_ADD=%d\n"
	.align	3
.LC1496:
	.string	"enum_expression_size.GIT_INDEX_ENTRY_SKIP_WORKTREE=%zu\n"
	.align	3
.LC1497:
	.string	"enum_expression_signed.GIT_INDEX_ENTRY_SKIP_WORKTREE=%d\n"
	.align	3
.LC1498:
	.string	"constant.GIT_INDEX_ENTRY_SKIP_WORKTREE="
	.align	3
.LC1499:
	.string	"constant_size.GIT_INDEX_ENTRY_SKIP_WORKTREE=%zu\n"
	.align	3
.LC1500:
	.string	"constant_signed.GIT_INDEX_ENTRY_SKIP_WORKTREE=%d\n"
	.align	3
.LC1501:
	.string	"enum_expression_size.GIT_INDEX_ENTRY_UPTODATE=%zu\n"
	.align	3
.LC1502:
	.string	"enum_expression_signed.GIT_INDEX_ENTRY_UPTODATE=%d\n"
	.align	3
.LC1503:
	.string	"constant.GIT_INDEX_ENTRY_UPTODATE="
	.align	3
.LC1504:
	.string	"constant_size.GIT_INDEX_ENTRY_UPTODATE=%zu\n"
	.align	3
.LC1505:
	.string	"constant_signed.GIT_INDEX_ENTRY_UPTODATE=%d\n"
	.align	3
.LC1506:
	.string	"enum_expression_size.GIT_INDEX_ENTRY_VALID=%zu\n"
	.align	3
.LC1507:
	.string	"enum_expression_signed.GIT_INDEX_ENTRY_VALID=%d\n"
	.align	3
.LC1508:
	.string	"constant.GIT_INDEX_ENTRY_VALID="
	.align	3
.LC1509:
	.string	"constant_size.GIT_INDEX_ENTRY_VALID=%zu\n"
	.align	3
.LC1510:
	.string	"constant_signed.GIT_INDEX_ENTRY_VALID=%d\n"
	.align	3
.LC1511:
	.string	"enum_expression_size.GIT_INDEX_STAGE_ANCESTOR=%zu\n"
	.align	3
.LC1512:
	.string	"enum_expression_signed.GIT_INDEX_STAGE_ANCESTOR=%d\n"
	.align	3
.LC1513:
	.string	"constant.GIT_INDEX_STAGE_ANCESTOR="
	.align	3
.LC1514:
	.string	"constant_size.GIT_INDEX_STAGE_ANCESTOR=%zu\n"
	.align	3
.LC1515:
	.string	"constant_signed.GIT_INDEX_STAGE_ANCESTOR=%d\n"
	.align	3
.LC1516:
	.string	"enum_expression_size.GIT_INDEX_STAGE_ANY=%zu\n"
	.align	3
.LC1517:
	.string	"enum_expression_signed.GIT_INDEX_STAGE_ANY=%d\n"
	.align	3
.LC1518:
	.string	"constant.GIT_INDEX_STAGE_ANY="
	.align	3
.LC1519:
	.string	"constant_size.GIT_INDEX_STAGE_ANY=%zu\n"
	.align	3
.LC1520:
	.string	"constant_signed.GIT_INDEX_STAGE_ANY=%d\n"
	.align	3
.LC1521:
	.string	"enum_expression_size.GIT_INDEX_STAGE_NORMAL=%zu\n"
	.align	3
.LC1522:
	.string	"enum_expression_signed.GIT_INDEX_STAGE_NORMAL=%d\n"
	.align	3
.LC1523:
	.string	"constant.GIT_INDEX_STAGE_NORMAL="
	.align	3
.LC1524:
	.string	"constant_size.GIT_INDEX_STAGE_NORMAL=%zu\n"
	.align	3
.LC1525:
	.string	"constant_signed.GIT_INDEX_STAGE_NORMAL=%d\n"
	.align	3
.LC1526:
	.string	"enum_expression_size.GIT_INDEX_STAGE_OURS=%zu\n"
	.align	3
.LC1527:
	.string	"enum_expression_signed.GIT_INDEX_STAGE_OURS=%d\n"
	.align	3
.LC1528:
	.string	"constant.GIT_INDEX_STAGE_OURS="
	.align	3
.LC1529:
	.string	"constant_size.GIT_INDEX_STAGE_OURS=%zu\n"
	.align	3
.LC1530:
	.string	"constant_signed.GIT_INDEX_STAGE_OURS=%d\n"
	.align	3
.LC1531:
	.string	"enum_expression_size.GIT_INDEX_STAGE_THEIRS=%zu\n"
	.align	3
.LC1532:
	.string	"enum_expression_signed.GIT_INDEX_STAGE_THEIRS=%d\n"
	.align	3
.LC1533:
	.string	"constant.GIT_INDEX_STAGE_THEIRS="
	.align	3
.LC1534:
	.string	"constant_size.GIT_INDEX_STAGE_THEIRS=%zu\n"
	.align	3
.LC1535:
	.string	"constant_signed.GIT_INDEX_STAGE_THEIRS=%d\n"
	.align	3
.LC1536:
	.string	"enum_expression_size.GIT_ITEROVER=%zu\n"
	.align	3
.LC1537:
	.string	"enum_expression_signed.GIT_ITEROVER=%d\n"
	.align	3
.LC1538:
	.string	"constant.GIT_ITEROVER="
	.align	3
.LC1539:
	.string	"constant_size.GIT_ITEROVER=%zu\n"
	.align	3
.LC1540:
	.string	"constant_signed.GIT_ITEROVER=%d\n"
	.align	3
.LC1541:
	.string	"enum_expression_size.GIT_MERGE_ANALYSIS_FASTFORWARD=%zu\n"
	.align	3
.LC1542:
	.string	"enum_expression_signed.GIT_MERGE_ANALYSIS_FASTFORWARD=%d\n"
	.align	3
.LC1543:
	.string	"constant.GIT_MERGE_ANALYSIS_FASTFORWARD="
	.align	3
.LC1544:
	.string	"constant_size.GIT_MERGE_ANALYSIS_FASTFORWARD=%zu\n"
	.align	3
.LC1545:
	.string	"constant_signed.GIT_MERGE_ANALYSIS_FASTFORWARD=%d\n"
	.align	3
.LC1546:
	.string	"enum_expression_size.GIT_MERGE_ANALYSIS_NONE=%zu\n"
	.align	3
.LC1547:
	.string	"enum_expression_signed.GIT_MERGE_ANALYSIS_NONE=%d\n"
	.align	3
.LC1548:
	.string	"constant.GIT_MERGE_ANALYSIS_NONE="
	.align	3
.LC1549:
	.string	"constant_size.GIT_MERGE_ANALYSIS_NONE=%zu\n"
	.align	3
.LC1550:
	.string	"constant_signed.GIT_MERGE_ANALYSIS_NONE=%d\n"
	.align	3
.LC1551:
	.string	"enum_expression_size.GIT_MERGE_ANALYSIS_NORMAL=%zu\n"
	.align	3
.LC1552:
	.string	"enum_expression_signed.GIT_MERGE_ANALYSIS_NORMAL=%d\n"
	.align	3
.LC1553:
	.string	"constant.GIT_MERGE_ANALYSIS_NORMAL="
	.align	3
.LC1554:
	.string	"constant_size.GIT_MERGE_ANALYSIS_NORMAL=%zu\n"
	.align	3
.LC1555:
	.string	"constant_signed.GIT_MERGE_ANALYSIS_NORMAL=%d\n"
	.align	3
.LC1556:
	.string	"enum_expression_size.GIT_MERGE_ANALYSIS_UNBORN=%zu\n"
	.align	3
.LC1557:
	.string	"enum_expression_signed.GIT_MERGE_ANALYSIS_UNBORN=%d\n"
	.align	3
.LC1558:
	.string	"constant.GIT_MERGE_ANALYSIS_UNBORN="
	.align	3
.LC1559:
	.string	"constant_size.GIT_MERGE_ANALYSIS_UNBORN=%zu\n"
	.align	3
.LC1560:
	.string	"constant_signed.GIT_MERGE_ANALYSIS_UNBORN=%d\n"
	.align	3
.LC1561:
	.string	"enum_expression_size.GIT_MERGE_ANALYSIS_UP_TO_DATE=%zu\n"
	.align	3
.LC1562:
	.string	"enum_expression_signed.GIT_MERGE_ANALYSIS_UP_TO_DATE=%d\n"
	.align	3
.LC1563:
	.string	"constant.GIT_MERGE_ANALYSIS_UP_TO_DATE="
	.align	3
.LC1564:
	.string	"constant_size.GIT_MERGE_ANALYSIS_UP_TO_DATE=%zu\n"
	.align	3
.LC1565:
	.string	"constant_signed.GIT_MERGE_ANALYSIS_UP_TO_DATE=%d\n"
	.align	3
.LC1566:
	.string	"enum_expression_size.GIT_MERGE_FAIL_ON_CONFLICT=%zu\n"
	.align	3
.LC1567:
	.string	"enum_expression_signed.GIT_MERGE_FAIL_ON_CONFLICT=%d\n"
	.align	3
.LC1568:
	.string	"constant.GIT_MERGE_FAIL_ON_CONFLICT="
	.align	3
.LC1569:
	.string	"constant_size.GIT_MERGE_FAIL_ON_CONFLICT=%zu\n"
	.align	3
.LC1570:
	.string	"constant_signed.GIT_MERGE_FAIL_ON_CONFLICT=%d\n"
	.align	3
.LC1571:
	.string	"enum_expression_size.GIT_MERGE_FILE_ACCEPT_CONFLICTS=%zu\n"
	.align	3
.LC1572:
	.string	"enum_expression_signed.GIT_MERGE_FILE_ACCEPT_CONFLICTS=%d\n"
	.align	3
.LC1573:
	.string	"constant.GIT_MERGE_FILE_ACCEPT_CONFLICTS="
	.align	3
.LC1574:
	.string	"constant_size.GIT_MERGE_FILE_ACCEPT_CONFLICTS=%zu\n"
	.align	3
.LC1575:
	.string	"constant_signed.GIT_MERGE_FILE_ACCEPT_CONFLICTS=%d\n"
	.align	3
.LC1576:
	.string	"enum_expression_size.GIT_MERGE_FILE_DEFAULT=%zu\n"
	.align	3
.LC1577:
	.string	"enum_expression_signed.GIT_MERGE_FILE_DEFAULT=%d\n"
	.align	3
.LC1578:
	.string	"constant.GIT_MERGE_FILE_DEFAULT="
	.align	3
.LC1579:
	.string	"constant_size.GIT_MERGE_FILE_DEFAULT=%zu\n"
	.align	3
.LC1580:
	.string	"constant_signed.GIT_MERGE_FILE_DEFAULT=%d\n"
	.align	3
.LC1581:
	.string	"enum_expression_size.GIT_MERGE_FILE_DIFF_MINIMAL=%zu\n"
	.align	3
.LC1582:
	.string	"enum_expression_signed.GIT_MERGE_FILE_DIFF_MINIMAL=%d\n"
	.align	3
.LC1583:
	.string	"constant.GIT_MERGE_FILE_DIFF_MINIMAL="
	.align	3
.LC1584:
	.string	"constant_size.GIT_MERGE_FILE_DIFF_MINIMAL=%zu\n"
	.align	3
.LC1585:
	.string	"constant_signed.GIT_MERGE_FILE_DIFF_MINIMAL=%d\n"
	.align	3
.LC1586:
	.string	"enum_expression_size.GIT_MERGE_FILE_DIFF_PATIENCE=%zu\n"
	.align	3
.LC1587:
	.string	"enum_expression_signed.GIT_MERGE_FILE_DIFF_PATIENCE=%d\n"
	.align	3
.LC1588:
	.string	"constant.GIT_MERGE_FILE_DIFF_PATIENCE="
	.align	3
.LC1589:
	.string	"constant_size.GIT_MERGE_FILE_DIFF_PATIENCE=%zu\n"
	.align	3
.LC1590:
	.string	"constant_signed.GIT_MERGE_FILE_DIFF_PATIENCE=%d\n"
	.align	3
.LC1591:
	.string	"enum_expression_size.GIT_MERGE_FILE_FAVOR_NORMAL=%zu\n"
	.align	3
.LC1592:
	.string	"enum_expression_signed.GIT_MERGE_FILE_FAVOR_NORMAL=%d\n"
	.align	3
.LC1593:
	.string	"constant.GIT_MERGE_FILE_FAVOR_NORMAL="
	.align	3
.LC1594:
	.string	"constant_size.GIT_MERGE_FILE_FAVOR_NORMAL=%zu\n"
	.align	3
.LC1595:
	.string	"constant_signed.GIT_MERGE_FILE_FAVOR_NORMAL=%d\n"
	.align	3
.LC1596:
	.string	"enum_expression_size.GIT_MERGE_FILE_FAVOR_OURS=%zu\n"
	.align	3
.LC1597:
	.string	"enum_expression_signed.GIT_MERGE_FILE_FAVOR_OURS=%d\n"
	.align	3
.LC1598:
	.string	"constant.GIT_MERGE_FILE_FAVOR_OURS="
	.align	3
.LC1599:
	.string	"constant_size.GIT_MERGE_FILE_FAVOR_OURS=%zu\n"
	.align	3
.LC1600:
	.string	"constant_signed.GIT_MERGE_FILE_FAVOR_OURS=%d\n"
	.align	3
.LC1601:
	.string	"enum_expression_size.GIT_MERGE_FILE_FAVOR_THEIRS=%zu\n"
	.align	3
.LC1602:
	.string	"enum_expression_signed.GIT_MERGE_FILE_FAVOR_THEIRS=%d\n"
	.align	3
.LC1603:
	.string	"constant.GIT_MERGE_FILE_FAVOR_THEIRS="
	.align	3
.LC1604:
	.string	"constant_size.GIT_MERGE_FILE_FAVOR_THEIRS=%zu\n"
	.align	3
.LC1605:
	.string	"constant_signed.GIT_MERGE_FILE_FAVOR_THEIRS=%d\n"
	.align	3
.LC1606:
	.string	"enum_expression_size.GIT_MERGE_FILE_FAVOR_UNION=%zu\n"
	.align	3
.LC1607:
	.string	"enum_expression_signed.GIT_MERGE_FILE_FAVOR_UNION=%d\n"
	.align	3
.LC1608:
	.string	"constant.GIT_MERGE_FILE_FAVOR_UNION="
	.align	3
.LC1609:
	.string	"constant_size.GIT_MERGE_FILE_FAVOR_UNION=%zu\n"
	.align	3
.LC1610:
	.string	"constant_signed.GIT_MERGE_FILE_FAVOR_UNION=%d\n"
	.align	3
.LC1611:
	.string	"enum_expression_size.GIT_MERGE_FILE_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC1612:
	.string	"enum_expression_signed.GIT_MERGE_FILE_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC1613:
	.string	"constant.GIT_MERGE_FILE_IGNORE_WHITESPACE="
	.align	3
.LC1614:
	.string	"constant_size.GIT_MERGE_FILE_IGNORE_WHITESPACE=%zu\n"
	.align	3
.LC1615:
	.string	"constant_signed.GIT_MERGE_FILE_IGNORE_WHITESPACE=%d\n"
	.align	3
.LC1616:
	.string	"enum_expression_size.GIT_MERGE_FILE_IGNORE_WHITESPACE_CHANGE=%zu\n"
	.align	3
.LC1617:
	.string	"enum_expression_signed.GIT_MERGE_FILE_IGNORE_WHITESPACE_CHANGE=%d\n"
	.align	3
.LC1618:
	.string	"constant.GIT_MERGE_FILE_IGNORE_WHITESPACE_CHANGE="
	.align	3
.LC1619:
	.string	"constant_size.GIT_MERGE_FILE_IGNORE_WHITESPACE_CHANGE=%zu\n"
	.align	3
.LC1620:
	.string	"constant_signed.GIT_MERGE_FILE_IGNORE_WHITESPACE_CHANGE=%d\n"
	.align	3
.LC1621:
	.string	"enum_expression_size.GIT_MERGE_FILE_IGNORE_WHITESPACE_EOL=%zu\n"
	.align	3
.LC1622:
	.string	"enum_expression_signed.GIT_MERGE_FILE_IGNORE_WHITESPACE_EOL=%d\n"
	.align	3
.LC1623:
	.string	"constant.GIT_MERGE_FILE_IGNORE_WHITESPACE_EOL="
	.align	3
.LC1624:
	.string	"constant_size.GIT_MERGE_FILE_IGNORE_WHITESPACE_EOL=%zu\n"
	.align	3
.LC1625:
	.string	"constant_signed.GIT_MERGE_FILE_IGNORE_WHITESPACE_EOL=%d\n"
	.align	3
.LC1626:
	.string	"enum_expression_size.GIT_MERGE_FILE_SIMPLIFY_ALNUM=%zu\n"
	.align	3
.LC1627:
	.string	"enum_expression_signed.GIT_MERGE_FILE_SIMPLIFY_ALNUM=%d\n"
	.align	3
.LC1628:
	.string	"constant.GIT_MERGE_FILE_SIMPLIFY_ALNUM="
	.align	3
.LC1629:
	.string	"constant_size.GIT_MERGE_FILE_SIMPLIFY_ALNUM=%zu\n"
	.align	3
.LC1630:
	.string	"constant_signed.GIT_MERGE_FILE_SIMPLIFY_ALNUM=%d\n"
	.align	3
.LC1631:
	.string	"enum_expression_size.GIT_MERGE_FILE_STYLE_DIFF3=%zu\n"
	.align	3
.LC1632:
	.string	"enum_expression_signed.GIT_MERGE_FILE_STYLE_DIFF3=%d\n"
	.align	3
.LC1633:
	.string	"constant.GIT_MERGE_FILE_STYLE_DIFF3="
	.align	3
.LC1634:
	.string	"constant_size.GIT_MERGE_FILE_STYLE_DIFF3=%zu\n"
	.align	3
.LC1635:
	.string	"constant_signed.GIT_MERGE_FILE_STYLE_DIFF3=%d\n"
	.align	3
.LC1636:
	.string	"enum_expression_size.GIT_MERGE_FILE_STYLE_MERGE=%zu\n"
	.align	3
.LC1637:
	.string	"enum_expression_signed.GIT_MERGE_FILE_STYLE_MERGE=%d\n"
	.align	3
.LC1638:
	.string	"constant.GIT_MERGE_FILE_STYLE_MERGE="
	.align	3
.LC1639:
	.string	"constant_size.GIT_MERGE_FILE_STYLE_MERGE=%zu\n"
	.align	3
.LC1640:
	.string	"constant_signed.GIT_MERGE_FILE_STYLE_MERGE=%d\n"
	.align	3
.LC1641:
	.string	"enum_expression_size.GIT_MERGE_FILE_STYLE_ZDIFF3=%zu\n"
	.align	3
.LC1642:
	.string	"enum_expression_signed.GIT_MERGE_FILE_STYLE_ZDIFF3=%d\n"
	.align	3
.LC1643:
	.string	"constant.GIT_MERGE_FILE_STYLE_ZDIFF3="
	.align	3
.LC1644:
	.string	"constant_size.GIT_MERGE_FILE_STYLE_ZDIFF3=%zu\n"
	.align	3
.LC1645:
	.string	"constant_signed.GIT_MERGE_FILE_STYLE_ZDIFF3=%d\n"
	.align	3
.LC1646:
	.string	"enum_expression_size.GIT_MERGE_FIND_RENAMES=%zu\n"
	.align	3
.LC1647:
	.string	"enum_expression_signed.GIT_MERGE_FIND_RENAMES=%d\n"
	.align	3
.LC1648:
	.string	"constant.GIT_MERGE_FIND_RENAMES="
	.align	3
.LC1649:
	.string	"constant_size.GIT_MERGE_FIND_RENAMES=%zu\n"
	.align	3
.LC1650:
	.string	"constant_signed.GIT_MERGE_FIND_RENAMES=%d\n"
	.align	3
.LC1651:
	.string	"enum_expression_size.GIT_MERGE_NO_RECURSIVE=%zu\n"
	.align	3
.LC1652:
	.string	"enum_expression_signed.GIT_MERGE_NO_RECURSIVE=%d\n"
	.align	3
.LC1653:
	.string	"constant.GIT_MERGE_NO_RECURSIVE="
	.align	3
.LC1654:
	.string	"constant_size.GIT_MERGE_NO_RECURSIVE=%zu\n"
	.align	3
.LC1655:
	.string	"constant_signed.GIT_MERGE_NO_RECURSIVE=%d\n"
	.align	3
.LC1656:
	.string	"enum_expression_size.GIT_MERGE_PREFERENCE_FASTFORWARD_ONLY=%zu\n"
	.align	3
.LC1657:
	.string	"enum_expression_signed.GIT_MERGE_PREFERENCE_FASTFORWARD_ONLY=%d\n"
	.align	3
.LC1658:
	.string	"constant.GIT_MERGE_PREFERENCE_FASTFORWARD_ONLY="
	.align	3
.LC1659:
	.string	"constant_size.GIT_MERGE_PREFERENCE_FASTFORWARD_ONLY=%zu\n"
	.align	3
.LC1660:
	.string	"constant_signed.GIT_MERGE_PREFERENCE_FASTFORWARD_ONLY=%d\n"
	.align	3
.LC1661:
	.string	"enum_expression_size.GIT_MERGE_PREFERENCE_NONE=%zu\n"
	.align	3
.LC1662:
	.string	"enum_expression_signed.GIT_MERGE_PREFERENCE_NONE=%d\n"
	.align	3
.LC1663:
	.string	"constant.GIT_MERGE_PREFERENCE_NONE="
	.align	3
.LC1664:
	.string	"constant_size.GIT_MERGE_PREFERENCE_NONE=%zu\n"
	.align	3
.LC1665:
	.string	"constant_signed.GIT_MERGE_PREFERENCE_NONE=%d\n"
	.align	3
.LC1666:
	.string	"enum_expression_size.GIT_MERGE_PREFERENCE_NO_FASTFORWARD=%zu\n"
	.align	3
.LC1667:
	.string	"enum_expression_signed.GIT_MERGE_PREFERENCE_NO_FASTFORWARD=%d\n"
	.align	3
.LC1668:
	.string	"constant.GIT_MERGE_PREFERENCE_NO_FASTFORWARD="
	.align	3
.LC1669:
	.string	"constant_size.GIT_MERGE_PREFERENCE_NO_FASTFORWARD=%zu\n"
	.align	3
.LC1670:
	.string	"constant_signed.GIT_MERGE_PREFERENCE_NO_FASTFORWARD=%d\n"
	.align	3
.LC1671:
	.string	"enum_expression_size.GIT_MERGE_SKIP_REUC=%zu\n"
	.align	3
.LC1672:
	.string	"enum_expression_signed.GIT_MERGE_SKIP_REUC=%d\n"
	.align	3
.LC1673:
	.string	"constant.GIT_MERGE_SKIP_REUC="
	.align	3
.LC1674:
	.string	"constant_size.GIT_MERGE_SKIP_REUC=%zu\n"
	.align	3
.LC1675:
	.string	"constant_signed.GIT_MERGE_SKIP_REUC=%d\n"
	.align	3
.LC1676:
	.string	"enum_expression_size.GIT_MERGE_VIRTUAL_BASE=%zu\n"
	.align	3
.LC1677:
	.string	"enum_expression_signed.GIT_MERGE_VIRTUAL_BASE=%d\n"
	.align	3
.LC1678:
	.string	"constant.GIT_MERGE_VIRTUAL_BASE="
	.align	3
.LC1679:
	.string	"constant_size.GIT_MERGE_VIRTUAL_BASE=%zu\n"
	.align	3
.LC1680:
	.string	"constant_signed.GIT_MERGE_VIRTUAL_BASE=%d\n"
	.align	3
.LC1681:
	.string	"enum_expression_size.GIT_OBJECT_ANY=%zu\n"
	.align	3
.LC1682:
	.string	"enum_expression_signed.GIT_OBJECT_ANY=%d\n"
	.align	3
.LC1683:
	.string	"constant.GIT_OBJECT_ANY="
	.align	3
.LC1684:
	.string	"constant_size.GIT_OBJECT_ANY=%zu\n"
	.align	3
.LC1685:
	.string	"constant_signed.GIT_OBJECT_ANY=%d\n"
	.align	3
.LC1686:
	.string	"enum_expression_size.GIT_OBJECT_BLOB=%zu\n"
	.align	3
.LC1687:
	.string	"enum_expression_signed.GIT_OBJECT_BLOB=%d\n"
	.align	3
.LC1688:
	.string	"constant.GIT_OBJECT_BLOB="
	.align	3
.LC1689:
	.string	"constant_size.GIT_OBJECT_BLOB=%zu\n"
	.align	3
.LC1690:
	.string	"constant_signed.GIT_OBJECT_BLOB=%d\n"
	.align	3
.LC1691:
	.string	"enum_expression_size.GIT_OBJECT_COMMIT=%zu\n"
	.align	3
.LC1692:
	.string	"enum_expression_signed.GIT_OBJECT_COMMIT=%d\n"
	.align	3
.LC1693:
	.string	"constant.GIT_OBJECT_COMMIT="
	.align	3
.LC1694:
	.string	"constant_size.GIT_OBJECT_COMMIT=%zu\n"
	.align	3
.LC1695:
	.string	"constant_signed.GIT_OBJECT_COMMIT=%d\n"
	.align	3
.LC1696:
	.string	"enum_expression_size.GIT_OBJECT_INVALID=%zu\n"
	.align	3
.LC1697:
	.string	"enum_expression_signed.GIT_OBJECT_INVALID=%d\n"
	.align	3
.LC1698:
	.string	"constant.GIT_OBJECT_INVALID="
	.align	3
.LC1699:
	.string	"constant_size.GIT_OBJECT_INVALID=%zu\n"
	.align	3
.LC1700:
	.string	"constant_signed.GIT_OBJECT_INVALID=%d\n"
	.align	3
.LC1701:
	.string	"enum_expression_size.GIT_OBJECT_OFS_DELTA=%zu\n"
	.align	3
.LC1702:
	.string	"enum_expression_signed.GIT_OBJECT_OFS_DELTA=%d\n"
	.align	3
.LC1703:
	.string	"constant.GIT_OBJECT_OFS_DELTA="
	.align	3
.LC1704:
	.string	"constant_size.GIT_OBJECT_OFS_DELTA=%zu\n"
	.align	3
.LC1705:
	.string	"constant_signed.GIT_OBJECT_OFS_DELTA=%d\n"
	.align	3
.LC1706:
	.string	"enum_expression_size.GIT_OBJECT_REF_DELTA=%zu\n"
	.align	3
.LC1707:
	.string	"enum_expression_signed.GIT_OBJECT_REF_DELTA=%d\n"
	.align	3
.LC1708:
	.string	"constant.GIT_OBJECT_REF_DELTA="
	.align	3
.LC1709:
	.string	"constant_size.GIT_OBJECT_REF_DELTA=%zu\n"
	.align	3
.LC1710:
	.string	"constant_signed.GIT_OBJECT_REF_DELTA=%d\n"
	.align	3
.LC1711:
	.string	"enum_expression_size.GIT_OBJECT_TAG=%zu\n"
	.align	3
.LC1712:
	.string	"enum_expression_signed.GIT_OBJECT_TAG=%d\n"
	.align	3
.LC1713:
	.string	"constant.GIT_OBJECT_TAG="
	.align	3
.LC1714:
	.string	"constant_size.GIT_OBJECT_TAG=%zu\n"
	.align	3
.LC1715:
	.string	"constant_signed.GIT_OBJECT_TAG=%d\n"
	.align	3
.LC1716:
	.string	"enum_expression_size.GIT_OBJECT_TREE=%zu\n"
	.align	3
.LC1717:
	.string	"enum_expression_signed.GIT_OBJECT_TREE=%d\n"
	.align	3
.LC1718:
	.string	"constant.GIT_OBJECT_TREE="
	.align	3
.LC1719:
	.string	"constant_size.GIT_OBJECT_TREE=%zu\n"
	.align	3
.LC1720:
	.string	"constant_signed.GIT_OBJECT_TREE=%d\n"
	.align	3
.LC1721:
	.string	"enum_expression_size.GIT_ODB_BACKEND_LOOSE_FSYNC=%zu\n"
	.align	3
.LC1722:
	.string	"enum_expression_signed.GIT_ODB_BACKEND_LOOSE_FSYNC=%d\n"
	.align	3
.LC1723:
	.string	"constant.GIT_ODB_BACKEND_LOOSE_FSYNC="
	.align	3
.LC1724:
	.string	"constant_size.GIT_ODB_BACKEND_LOOSE_FSYNC=%zu\n"
	.align	3
.LC1725:
	.string	"constant_signed.GIT_ODB_BACKEND_LOOSE_FSYNC=%d\n"
	.align	3
.LC1726:
	.string	"enum_expression_size.GIT_ODB_LOOKUP_NO_REFRESH=%zu\n"
	.align	3
.LC1727:
	.string	"enum_expression_signed.GIT_ODB_LOOKUP_NO_REFRESH=%d\n"
	.align	3
.LC1728:
	.string	"constant.GIT_ODB_LOOKUP_NO_REFRESH="
	.align	3
.LC1729:
	.string	"constant_size.GIT_ODB_LOOKUP_NO_REFRESH=%zu\n"
	.align	3
.LC1730:
	.string	"constant_signed.GIT_ODB_LOOKUP_NO_REFRESH=%d\n"
	.align	3
.LC1731:
	.string	"enum_expression_size.GIT_OID_SHA1=%zu\n"
	.align	3
.LC1732:
	.string	"enum_expression_signed.GIT_OID_SHA1=%d\n"
	.align	3
.LC1733:
	.string	"constant.GIT_OID_SHA1="
	.align	3
.LC1734:
	.string	"constant_size.GIT_OID_SHA1=%zu\n"
	.align	3
.LC1735:
	.string	"constant_signed.GIT_OID_SHA1=%d\n"
	.align	3
.LC1736:
	.string	"enum_expression_size.GIT_OK=%zu\n"
	.align	3
.LC1737:
	.string	"enum_expression_signed.GIT_OK=%d\n"
	.align	3
.LC1738:
	.string	"constant.GIT_OK="
	.align	3
.LC1739:
	.string	"constant_size.GIT_OK=%zu\n"
	.align	3
.LC1740:
	.string	"constant_signed.GIT_OK=%d\n"
	.align	3
.LC1741:
	.string	"enum_expression_size.GIT_OPT_ADD_SSL_X509_CERT=%zu\n"
	.align	3
.LC1742:
	.string	"enum_expression_signed.GIT_OPT_ADD_SSL_X509_CERT=%d\n"
	.align	3
.LC1743:
	.string	"constant.GIT_OPT_ADD_SSL_X509_CERT="
	.align	3
.LC1744:
	.string	"constant_size.GIT_OPT_ADD_SSL_X509_CERT=%zu\n"
	.align	3
.LC1745:
	.string	"constant_signed.GIT_OPT_ADD_SSL_X509_CERT=%d\n"
	.align	3
.LC1746:
	.string	"enum_expression_size.GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS=%zu\n"
	.align	3
.LC1747:
	.string	"enum_expression_signed.GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS=%d\n"
	.align	3
.LC1748:
	.string	"constant.GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS="
	.align	3
.LC1749:
	.string	"constant_size.GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS=%zu\n"
	.align	3
.LC1750:
	.string	"constant_signed.GIT_OPT_DISABLE_PACK_KEEP_FILE_CHECKS=%d\n"
	.align	3
.LC1751:
	.string	"enum_expression_size.GIT_OPT_ENABLE_CACHING=%zu\n"
	.align	3
.LC1752:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_CACHING=%d\n"
	.align	3
.LC1753:
	.string	"constant.GIT_OPT_ENABLE_CACHING="
	.align	3
.LC1754:
	.string	"constant_size.GIT_OPT_ENABLE_CACHING=%zu\n"
	.align	3
.LC1755:
	.string	"constant_signed.GIT_OPT_ENABLE_CACHING=%d\n"
	.align	3
.LC1756:
	.string	"enum_expression_size.GIT_OPT_ENABLE_FSYNC_GITDIR=%zu\n"
	.align	3
.LC1757:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_FSYNC_GITDIR=%d\n"
	.align	3
.LC1758:
	.string	"constant.GIT_OPT_ENABLE_FSYNC_GITDIR="
	.align	3
.LC1759:
	.string	"constant_size.GIT_OPT_ENABLE_FSYNC_GITDIR=%zu\n"
	.align	3
.LC1760:
	.string	"constant_signed.GIT_OPT_ENABLE_FSYNC_GITDIR=%d\n"
	.align	3
.LC1761:
	.string	"enum_expression_size.GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE=%zu\n"
	.align	3
.LC1762:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE=%d\n"
	.align	3
.LC1763:
	.string	"constant.GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE="
	.align	3
.LC1764:
	.string	"constant_size.GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE=%zu\n"
	.align	3
.LC1765:
	.string	"constant_signed.GIT_OPT_ENABLE_HTTP_EXPECT_CONTINUE=%d\n"
	.align	3
.LC1766:
	.string	"enum_expression_size.GIT_OPT_ENABLE_OFS_DELTA=%zu\n"
	.align	3
.LC1767:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_OFS_DELTA=%d\n"
	.align	3
.LC1768:
	.string	"constant.GIT_OPT_ENABLE_OFS_DELTA="
	.align	3
.LC1769:
	.string	"constant_size.GIT_OPT_ENABLE_OFS_DELTA=%zu\n"
	.align	3
.LC1770:
	.string	"constant_signed.GIT_OPT_ENABLE_OFS_DELTA=%d\n"
	.align	3
.LC1771:
	.string	"enum_expression_size.GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION=%zu\n"
	.align	3
.LC1772:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION=%d\n"
	.align	3
.LC1773:
	.string	"constant.GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION="
	.align	3
.LC1774:
	.string	"constant_size.GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION=%zu\n"
	.align	3
.LC1775:
	.string	"constant_signed.GIT_OPT_ENABLE_STRICT_HASH_VERIFICATION=%d\n"
	.align	3
.LC1776:
	.string	"enum_expression_size.GIT_OPT_ENABLE_STRICT_OBJECT_CREATION=%zu\n"
	.align	3
.LC1777:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_STRICT_OBJECT_CREATION=%d\n"
	.align	3
.LC1778:
	.string	"constant.GIT_OPT_ENABLE_STRICT_OBJECT_CREATION="
	.align	3
.LC1779:
	.string	"constant_size.GIT_OPT_ENABLE_STRICT_OBJECT_CREATION=%zu\n"
	.align	3
.LC1780:
	.string	"constant_signed.GIT_OPT_ENABLE_STRICT_OBJECT_CREATION=%d\n"
	.align	3
.LC1781:
	.string	"enum_expression_size.GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION=%zu\n"
	.align	3
.LC1782:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION=%d\n"
	.align	3
.LC1783:
	.string	"constant.GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION="
	.align	3
.LC1784:
	.string	"constant_size.GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION=%zu\n"
	.align	3
.LC1785:
	.string	"constant_signed.GIT_OPT_ENABLE_STRICT_SYMBOLIC_REF_CREATION=%d\n"
	.align	3
.LC1786:
	.string	"enum_expression_size.GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY=%zu\n"
	.align	3
.LC1787:
	.string	"enum_expression_signed.GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY=%d\n"
	.align	3
.LC1788:
	.string	"constant.GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY="
	.align	3
.LC1789:
	.string	"constant_size.GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY=%zu\n"
	.align	3
.LC1790:
	.string	"constant_signed.GIT_OPT_ENABLE_UNSAVED_INDEX_SAFETY=%d\n"
	.align	3
.LC1791:
	.string	"enum_expression_size.GIT_OPT_GET_CACHED_MEMORY=%zu\n"
	.align	3
.LC1792:
	.string	"enum_expression_signed.GIT_OPT_GET_CACHED_MEMORY=%d\n"
	.align	3
.LC1793:
	.string	"constant.GIT_OPT_GET_CACHED_MEMORY="
	.align	3
.LC1794:
	.string	"constant_size.GIT_OPT_GET_CACHED_MEMORY=%zu\n"
	.align	3
.LC1795:
	.string	"constant_signed.GIT_OPT_GET_CACHED_MEMORY=%d\n"
	.align	3
.LC1796:
	.string	"enum_expression_size.GIT_OPT_GET_EXTENSIONS=%zu\n"
	.align	3
.LC1797:
	.string	"enum_expression_signed.GIT_OPT_GET_EXTENSIONS=%d\n"
	.align	3
.LC1798:
	.string	"constant.GIT_OPT_GET_EXTENSIONS="
	.align	3
.LC1799:
	.string	"constant_size.GIT_OPT_GET_EXTENSIONS=%zu\n"
	.align	3
.LC1800:
	.string	"constant_signed.GIT_OPT_GET_EXTENSIONS=%d\n"
	.align	3
.LC1801:
	.string	"enum_expression_size.GIT_OPT_GET_HOMEDIR=%zu\n"
	.align	3
.LC1802:
	.string	"enum_expression_signed.GIT_OPT_GET_HOMEDIR=%d\n"
	.align	3
.LC1803:
	.string	"constant.GIT_OPT_GET_HOMEDIR="
	.align	3
.LC1804:
	.string	"constant_size.GIT_OPT_GET_HOMEDIR=%zu\n"
	.align	3
.LC1805:
	.string	"constant_signed.GIT_OPT_GET_HOMEDIR=%d\n"
	.align	3
.LC1806:
	.string	"enum_expression_size.GIT_OPT_GET_MWINDOW_FILE_LIMIT=%zu\n"
	.align	3
.LC1807:
	.string	"enum_expression_signed.GIT_OPT_GET_MWINDOW_FILE_LIMIT=%d\n"
	.align	3
.LC1808:
	.string	"constant.GIT_OPT_GET_MWINDOW_FILE_LIMIT="
	.align	3
.LC1809:
	.string	"constant_size.GIT_OPT_GET_MWINDOW_FILE_LIMIT=%zu\n"
	.align	3
.LC1810:
	.string	"constant_signed.GIT_OPT_GET_MWINDOW_FILE_LIMIT=%d\n"
	.align	3
.LC1811:
	.string	"enum_expression_size.GIT_OPT_GET_MWINDOW_MAPPED_LIMIT=%zu\n"
	.align	3
.LC1812:
	.string	"enum_expression_signed.GIT_OPT_GET_MWINDOW_MAPPED_LIMIT=%d\n"
	.align	3
.LC1813:
	.string	"constant.GIT_OPT_GET_MWINDOW_MAPPED_LIMIT="
	.align	3
.LC1814:
	.string	"constant_size.GIT_OPT_GET_MWINDOW_MAPPED_LIMIT=%zu\n"
	.align	3
.LC1815:
	.string	"constant_signed.GIT_OPT_GET_MWINDOW_MAPPED_LIMIT=%d\n"
	.align	3
.LC1816:
	.string	"enum_expression_size.GIT_OPT_GET_MWINDOW_SIZE=%zu\n"
	.align	3
.LC1817:
	.string	"enum_expression_signed.GIT_OPT_GET_MWINDOW_SIZE=%d\n"
	.align	3
.LC1818:
	.string	"constant.GIT_OPT_GET_MWINDOW_SIZE="
	.align	3
.LC1819:
	.string	"constant_size.GIT_OPT_GET_MWINDOW_SIZE=%zu\n"
	.align	3
.LC1820:
	.string	"constant_signed.GIT_OPT_GET_MWINDOW_SIZE=%d\n"
	.align	3
.LC1821:
	.string	"enum_expression_size.GIT_OPT_GET_OWNER_VALIDATION=%zu\n"
	.align	3
.LC1822:
	.string	"enum_expression_signed.GIT_OPT_GET_OWNER_VALIDATION=%d\n"
	.align	3
.LC1823:
	.string	"constant.GIT_OPT_GET_OWNER_VALIDATION="
	.align	3
.LC1824:
	.string	"constant_size.GIT_OPT_GET_OWNER_VALIDATION=%zu\n"
	.align	3
.LC1825:
	.string	"constant_signed.GIT_OPT_GET_OWNER_VALIDATION=%d\n"
	.align	3
.LC1826:
	.string	"enum_expression_size.GIT_OPT_GET_PACK_MAX_OBJECTS=%zu\n"
	.align	3
.LC1827:
	.string	"enum_expression_signed.GIT_OPT_GET_PACK_MAX_OBJECTS=%d\n"
	.align	3
.LC1828:
	.string	"constant.GIT_OPT_GET_PACK_MAX_OBJECTS="
	.align	3
.LC1829:
	.string	"constant_size.GIT_OPT_GET_PACK_MAX_OBJECTS=%zu\n"
	.align	3
.LC1830:
	.string	"constant_signed.GIT_OPT_GET_PACK_MAX_OBJECTS=%d\n"
	.align	3
.LC1831:
	.string	"enum_expression_size.GIT_OPT_GET_SEARCH_PATH=%zu\n"
	.align	3
.LC1832:
	.string	"enum_expression_signed.GIT_OPT_GET_SEARCH_PATH=%d\n"
	.align	3
.LC1833:
	.string	"constant.GIT_OPT_GET_SEARCH_PATH="
	.align	3
.LC1834:
	.string	"constant_size.GIT_OPT_GET_SEARCH_PATH=%zu\n"
	.align	3
.LC1835:
	.string	"constant_signed.GIT_OPT_GET_SEARCH_PATH=%d\n"
	.align	3
.LC1836:
	.string	"enum_expression_size.GIT_OPT_GET_SERVER_CONNECT_TIMEOUT=%zu\n"
	.align	3
.LC1837:
	.string	"enum_expression_signed.GIT_OPT_GET_SERVER_CONNECT_TIMEOUT=%d\n"
	.align	3
.LC1838:
	.string	"constant.GIT_OPT_GET_SERVER_CONNECT_TIMEOUT="
	.align	3
.LC1839:
	.string	"constant_size.GIT_OPT_GET_SERVER_CONNECT_TIMEOUT=%zu\n"
	.align	3
.LC1840:
	.string	"constant_signed.GIT_OPT_GET_SERVER_CONNECT_TIMEOUT=%d\n"
	.align	3
.LC1841:
	.string	"enum_expression_size.GIT_OPT_GET_SERVER_TIMEOUT=%zu\n"
	.align	3
.LC1842:
	.string	"enum_expression_signed.GIT_OPT_GET_SERVER_TIMEOUT=%d\n"
	.align	3
.LC1843:
	.string	"constant.GIT_OPT_GET_SERVER_TIMEOUT="
	.align	3
.LC1844:
	.string	"constant_size.GIT_OPT_GET_SERVER_TIMEOUT=%zu\n"
	.align	3
.LC1845:
	.string	"constant_signed.GIT_OPT_GET_SERVER_TIMEOUT=%d\n"
	.align	3
.LC1846:
	.string	"enum_expression_size.GIT_OPT_GET_TEMPLATE_PATH=%zu\n"
	.align	3
.LC1847:
	.string	"enum_expression_signed.GIT_OPT_GET_TEMPLATE_PATH=%d\n"
	.align	3
.LC1848:
	.string	"constant.GIT_OPT_GET_TEMPLATE_PATH="
	.align	3
.LC1849:
	.string	"constant_size.GIT_OPT_GET_TEMPLATE_PATH=%zu\n"
	.align	3
.LC1850:
	.string	"constant_signed.GIT_OPT_GET_TEMPLATE_PATH=%d\n"
	.align	3
.LC1851:
	.string	"enum_expression_size.GIT_OPT_GET_USER_AGENT=%zu\n"
	.align	3
.LC1852:
	.string	"enum_expression_signed.GIT_OPT_GET_USER_AGENT=%d\n"
	.align	3
.LC1853:
	.string	"constant.GIT_OPT_GET_USER_AGENT="
	.align	3
.LC1854:
	.string	"constant_size.GIT_OPT_GET_USER_AGENT=%zu\n"
	.align	3
.LC1855:
	.string	"constant_signed.GIT_OPT_GET_USER_AGENT=%d\n"
	.align	3
.LC1856:
	.string	"enum_expression_size.GIT_OPT_GET_USER_AGENT_PRODUCT=%zu\n"
	.align	3
.LC1857:
	.string	"enum_expression_signed.GIT_OPT_GET_USER_AGENT_PRODUCT=%d\n"
	.align	3
.LC1858:
	.string	"constant.GIT_OPT_GET_USER_AGENT_PRODUCT="
	.align	3
.LC1859:
	.string	"constant_size.GIT_OPT_GET_USER_AGENT_PRODUCT=%zu\n"
	.align	3
.LC1860:
	.string	"constant_signed.GIT_OPT_GET_USER_AGENT_PRODUCT=%d\n"
	.align	3
.LC1861:
	.string	"enum_expression_size.GIT_OPT_GET_WINDOWS_SHAREMODE=%zu\n"
	.align	3
.LC1862:
	.string	"enum_expression_signed.GIT_OPT_GET_WINDOWS_SHAREMODE=%d\n"
	.align	3
.LC1863:
	.string	"constant.GIT_OPT_GET_WINDOWS_SHAREMODE="
	.align	3
.LC1864:
	.string	"constant_size.GIT_OPT_GET_WINDOWS_SHAREMODE=%zu\n"
	.align	3
.LC1865:
	.string	"constant_signed.GIT_OPT_GET_WINDOWS_SHAREMODE=%d\n"
	.align	3
.LC1866:
	.string	"enum_expression_size.GIT_OPT_SET_ALLOCATOR=%zu\n"
	.align	3
.LC1867:
	.string	"enum_expression_signed.GIT_OPT_SET_ALLOCATOR=%d\n"
	.align	3
.LC1868:
	.string	"constant.GIT_OPT_SET_ALLOCATOR="
	.align	3
.LC1869:
	.string	"constant_size.GIT_OPT_SET_ALLOCATOR=%zu\n"
	.align	3
.LC1870:
	.string	"constant_signed.GIT_OPT_SET_ALLOCATOR=%d\n"
	.align	3
.LC1871:
	.string	"enum_expression_size.GIT_OPT_SET_CACHE_MAX_SIZE=%zu\n"
	.align	3
.LC1872:
	.string	"enum_expression_signed.GIT_OPT_SET_CACHE_MAX_SIZE=%d\n"
	.align	3
.LC1873:
	.string	"constant.GIT_OPT_SET_CACHE_MAX_SIZE="
	.align	3
.LC1874:
	.string	"constant_size.GIT_OPT_SET_CACHE_MAX_SIZE=%zu\n"
	.align	3
.LC1875:
	.string	"constant_signed.GIT_OPT_SET_CACHE_MAX_SIZE=%d\n"
	.align	3
.LC1876:
	.string	"enum_expression_size.GIT_OPT_SET_CACHE_OBJECT_LIMIT=%zu\n"
	.align	3
.LC1877:
	.string	"enum_expression_signed.GIT_OPT_SET_CACHE_OBJECT_LIMIT=%d\n"
	.align	3
.LC1878:
	.string	"constant.GIT_OPT_SET_CACHE_OBJECT_LIMIT="
	.align	3
.LC1879:
	.string	"constant_size.GIT_OPT_SET_CACHE_OBJECT_LIMIT=%zu\n"
	.align	3
.LC1880:
	.string	"constant_signed.GIT_OPT_SET_CACHE_OBJECT_LIMIT=%d\n"
	.align	3
.LC1881:
	.string	"enum_expression_size.GIT_OPT_SET_EXTENSIONS=%zu\n"
	.align	3
.LC1882:
	.string	"enum_expression_signed.GIT_OPT_SET_EXTENSIONS=%d\n"
	.align	3
.LC1883:
	.string	"constant.GIT_OPT_SET_EXTENSIONS="
	.align	3
.LC1884:
	.string	"constant_size.GIT_OPT_SET_EXTENSIONS=%zu\n"
	.align	3
.LC1885:
	.string	"constant_signed.GIT_OPT_SET_EXTENSIONS=%d\n"
	.align	3
.LC1886:
	.string	"enum_expression_size.GIT_OPT_SET_HOMEDIR=%zu\n"
	.align	3
.LC1887:
	.string	"enum_expression_signed.GIT_OPT_SET_HOMEDIR=%d\n"
	.align	3
.LC1888:
	.string	"constant.GIT_OPT_SET_HOMEDIR="
	.align	3
.LC1889:
	.string	"constant_size.GIT_OPT_SET_HOMEDIR=%zu\n"
	.align	3
.LC1890:
	.string	"constant_signed.GIT_OPT_SET_HOMEDIR=%d\n"
	.align	3
.LC1891:
	.string	"enum_expression_size.GIT_OPT_SET_MWINDOW_FILE_LIMIT=%zu\n"
	.align	3
.LC1892:
	.string	"enum_expression_signed.GIT_OPT_SET_MWINDOW_FILE_LIMIT=%d\n"
	.align	3
.LC1893:
	.string	"constant.GIT_OPT_SET_MWINDOW_FILE_LIMIT="
	.align	3
.LC1894:
	.string	"constant_size.GIT_OPT_SET_MWINDOW_FILE_LIMIT=%zu\n"
	.align	3
.LC1895:
	.string	"constant_signed.GIT_OPT_SET_MWINDOW_FILE_LIMIT=%d\n"
	.align	3
.LC1896:
	.string	"enum_expression_size.GIT_OPT_SET_MWINDOW_MAPPED_LIMIT=%zu\n"
	.align	3
.LC1897:
	.string	"enum_expression_signed.GIT_OPT_SET_MWINDOW_MAPPED_LIMIT=%d\n"
	.align	3
.LC1898:
	.string	"constant.GIT_OPT_SET_MWINDOW_MAPPED_LIMIT="
	.align	3
.LC1899:
	.string	"constant_size.GIT_OPT_SET_MWINDOW_MAPPED_LIMIT=%zu\n"
	.align	3
.LC1900:
	.string	"constant_signed.GIT_OPT_SET_MWINDOW_MAPPED_LIMIT=%d\n"
	.align	3
.LC1901:
	.string	"enum_expression_size.GIT_OPT_SET_MWINDOW_SIZE=%zu\n"
	.align	3
.LC1902:
	.string	"enum_expression_signed.GIT_OPT_SET_MWINDOW_SIZE=%d\n"
	.align	3
.LC1903:
	.string	"constant.GIT_OPT_SET_MWINDOW_SIZE="
	.align	3
.LC1904:
	.string	"constant_size.GIT_OPT_SET_MWINDOW_SIZE=%zu\n"
	.align	3
.LC1905:
	.string	"constant_signed.GIT_OPT_SET_MWINDOW_SIZE=%d\n"
	.align	3
.LC1906:
	.string	"enum_expression_size.GIT_OPT_SET_ODB_LOOSE_PRIORITY=%zu\n"
	.align	3
.LC1907:
	.string	"enum_expression_signed.GIT_OPT_SET_ODB_LOOSE_PRIORITY=%d\n"
	.align	3
.LC1908:
	.string	"constant.GIT_OPT_SET_ODB_LOOSE_PRIORITY="
	.align	3
.LC1909:
	.string	"constant_size.GIT_OPT_SET_ODB_LOOSE_PRIORITY=%zu\n"
	.align	3
.LC1910:
	.string	"constant_signed.GIT_OPT_SET_ODB_LOOSE_PRIORITY=%d\n"
	.align	3
.LC1911:
	.string	"enum_expression_size.GIT_OPT_SET_ODB_PACKED_PRIORITY=%zu\n"
	.align	3
.LC1912:
	.string	"enum_expression_signed.GIT_OPT_SET_ODB_PACKED_PRIORITY=%d\n"
	.align	3
.LC1913:
	.string	"constant.GIT_OPT_SET_ODB_PACKED_PRIORITY="
	.align	3
.LC1914:
	.string	"constant_size.GIT_OPT_SET_ODB_PACKED_PRIORITY=%zu\n"
	.align	3
.LC1915:
	.string	"constant_signed.GIT_OPT_SET_ODB_PACKED_PRIORITY=%d\n"
	.align	3
.LC1916:
	.string	"enum_expression_size.GIT_OPT_SET_OWNER_VALIDATION=%zu\n"
	.align	3
.LC1917:
	.string	"enum_expression_signed.GIT_OPT_SET_OWNER_VALIDATION=%d\n"
	.align	3
.LC1918:
	.string	"constant.GIT_OPT_SET_OWNER_VALIDATION="
	.align	3
.LC1919:
	.string	"constant_size.GIT_OPT_SET_OWNER_VALIDATION=%zu\n"
	.align	3
.LC1920:
	.string	"constant_signed.GIT_OPT_SET_OWNER_VALIDATION=%d\n"
	.align	3
.LC1921:
	.string	"enum_expression_size.GIT_OPT_SET_PACK_MAX_OBJECTS=%zu\n"
	.align	3
.LC1922:
	.string	"enum_expression_signed.GIT_OPT_SET_PACK_MAX_OBJECTS=%d\n"
	.align	3
.LC1923:
	.string	"constant.GIT_OPT_SET_PACK_MAX_OBJECTS="
	.align	3
.LC1924:
	.string	"constant_size.GIT_OPT_SET_PACK_MAX_OBJECTS=%zu\n"
	.align	3
.LC1925:
	.string	"constant_signed.GIT_OPT_SET_PACK_MAX_OBJECTS=%d\n"
	.align	3
.LC1926:
	.string	"enum_expression_size.GIT_OPT_SET_SEARCH_PATH=%zu\n"
	.align	3
.LC1927:
	.string	"enum_expression_signed.GIT_OPT_SET_SEARCH_PATH=%d\n"
	.align	3
.LC1928:
	.string	"constant.GIT_OPT_SET_SEARCH_PATH="
	.align	3
.LC1929:
	.string	"constant_size.GIT_OPT_SET_SEARCH_PATH=%zu\n"
	.align	3
.LC1930:
	.string	"constant_signed.GIT_OPT_SET_SEARCH_PATH=%d\n"
	.align	3
.LC1931:
	.string	"enum_expression_size.GIT_OPT_SET_SERVER_CONNECT_TIMEOUT=%zu\n"
	.align	3
.LC1932:
	.string	"enum_expression_signed.GIT_OPT_SET_SERVER_CONNECT_TIMEOUT=%d\n"
	.align	3
.LC1933:
	.string	"constant.GIT_OPT_SET_SERVER_CONNECT_TIMEOUT="
	.align	3
.LC1934:
	.string	"constant_size.GIT_OPT_SET_SERVER_CONNECT_TIMEOUT=%zu\n"
	.align	3
.LC1935:
	.string	"constant_signed.GIT_OPT_SET_SERVER_CONNECT_TIMEOUT=%d\n"
	.align	3
.LC1936:
	.string	"enum_expression_size.GIT_OPT_SET_SERVER_TIMEOUT=%zu\n"
	.align	3
.LC1937:
	.string	"enum_expression_signed.GIT_OPT_SET_SERVER_TIMEOUT=%d\n"
	.align	3
.LC1938:
	.string	"constant.GIT_OPT_SET_SERVER_TIMEOUT="
	.align	3
.LC1939:
	.string	"constant_size.GIT_OPT_SET_SERVER_TIMEOUT=%zu\n"
	.align	3
.LC1940:
	.string	"constant_signed.GIT_OPT_SET_SERVER_TIMEOUT=%d\n"
	.align	3
.LC1941:
	.string	"enum_expression_size.GIT_OPT_SET_SSL_CERT_LOCATIONS=%zu\n"
	.align	3
.LC1942:
	.string	"enum_expression_signed.GIT_OPT_SET_SSL_CERT_LOCATIONS=%d\n"
	.align	3
.LC1943:
	.string	"constant.GIT_OPT_SET_SSL_CERT_LOCATIONS="
	.align	3
.LC1944:
	.string	"constant_size.GIT_OPT_SET_SSL_CERT_LOCATIONS=%zu\n"
	.align	3
.LC1945:
	.string	"constant_signed.GIT_OPT_SET_SSL_CERT_LOCATIONS=%d\n"
	.align	3
.LC1946:
	.string	"enum_expression_size.GIT_OPT_SET_SSL_CIPHERS=%zu\n"
	.align	3
.LC1947:
	.string	"enum_expression_signed.GIT_OPT_SET_SSL_CIPHERS=%d\n"
	.align	3
.LC1948:
	.string	"constant.GIT_OPT_SET_SSL_CIPHERS="
	.align	3
.LC1949:
	.string	"constant_size.GIT_OPT_SET_SSL_CIPHERS=%zu\n"
	.align	3
.LC1950:
	.string	"constant_signed.GIT_OPT_SET_SSL_CIPHERS=%d\n"
	.align	3
.LC1951:
	.string	"enum_expression_size.GIT_OPT_SET_TEMPLATE_PATH=%zu\n"
	.align	3
.LC1952:
	.string	"enum_expression_signed.GIT_OPT_SET_TEMPLATE_PATH=%d\n"
	.align	3
.LC1953:
	.string	"constant.GIT_OPT_SET_TEMPLATE_PATH="
	.align	3
.LC1954:
	.string	"constant_size.GIT_OPT_SET_TEMPLATE_PATH=%zu\n"
	.align	3
.LC1955:
	.string	"constant_signed.GIT_OPT_SET_TEMPLATE_PATH=%d\n"
	.align	3
.LC1956:
	.string	"enum_expression_size.GIT_OPT_SET_USER_AGENT=%zu\n"
	.align	3
.LC1957:
	.string	"enum_expression_signed.GIT_OPT_SET_USER_AGENT=%d\n"
	.align	3
.LC1958:
	.string	"constant.GIT_OPT_SET_USER_AGENT="
	.align	3
.LC1959:
	.string	"constant_size.GIT_OPT_SET_USER_AGENT=%zu\n"
	.align	3
.LC1960:
	.string	"constant_signed.GIT_OPT_SET_USER_AGENT=%d\n"
	.align	3
.LC1961:
	.string	"enum_expression_size.GIT_OPT_SET_USER_AGENT_PRODUCT=%zu\n"
	.align	3
.LC1962:
	.string	"enum_expression_signed.GIT_OPT_SET_USER_AGENT_PRODUCT=%d\n"
	.align	3
.LC1963:
	.string	"constant.GIT_OPT_SET_USER_AGENT_PRODUCT="
	.align	3
.LC1964:
	.string	"constant_size.GIT_OPT_SET_USER_AGENT_PRODUCT=%zu\n"
	.align	3
.LC1965:
	.string	"constant_signed.GIT_OPT_SET_USER_AGENT_PRODUCT=%d\n"
	.align	3
.LC1966:
	.string	"enum_expression_size.GIT_OPT_SET_WINDOWS_SHAREMODE=%zu\n"
	.align	3
.LC1967:
	.string	"enum_expression_signed.GIT_OPT_SET_WINDOWS_SHAREMODE=%d\n"
	.align	3
.LC1968:
	.string	"constant.GIT_OPT_SET_WINDOWS_SHAREMODE="
	.align	3
.LC1969:
	.string	"constant_size.GIT_OPT_SET_WINDOWS_SHAREMODE=%zu\n"
	.align	3
.LC1970:
	.string	"constant_signed.GIT_OPT_SET_WINDOWS_SHAREMODE=%d\n"
	.align	3
.LC1971:
	.string	"enum_expression_size.GIT_PACKBUILDER_ADDING_OBJECTS=%zu\n"
	.align	3
.LC1972:
	.string	"enum_expression_signed.GIT_PACKBUILDER_ADDING_OBJECTS=%d\n"
	.align	3
.LC1973:
	.string	"constant.GIT_PACKBUILDER_ADDING_OBJECTS="
	.align	3
.LC1974:
	.string	"constant_size.GIT_PACKBUILDER_ADDING_OBJECTS=%zu\n"
	.align	3
.LC1975:
	.string	"constant_signed.GIT_PACKBUILDER_ADDING_OBJECTS=%d\n"
	.align	3
.LC1976:
	.string	"enum_expression_size.GIT_PACKBUILDER_DELTAFICATION=%zu\n"
	.align	3
.LC1977:
	.string	"enum_expression_signed.GIT_PACKBUILDER_DELTAFICATION=%d\n"
	.align	3
.LC1978:
	.string	"constant.GIT_PACKBUILDER_DELTAFICATION="
	.align	3
.LC1979:
	.string	"constant_size.GIT_PACKBUILDER_DELTAFICATION=%zu\n"
	.align	3
.LC1980:
	.string	"constant_signed.GIT_PACKBUILDER_DELTAFICATION=%d\n"
	.align	3
.LC1981:
	.string	"enum_expression_size.GIT_PASSTHROUGH=%zu\n"
	.align	3
.LC1982:
	.string	"enum_expression_signed.GIT_PASSTHROUGH=%d\n"
	.align	3
.LC1983:
	.string	"constant.GIT_PASSTHROUGH="
	.align	3
.LC1984:
	.string	"constant_size.GIT_PASSTHROUGH=%zu\n"
	.align	3
.LC1985:
	.string	"constant_signed.GIT_PASSTHROUGH=%d\n"
	.align	3
.LC1986:
	.string	"enum_expression_size.GIT_PATHSPEC_DEFAULT=%zu\n"
	.align	3
.LC1987:
	.string	"enum_expression_signed.GIT_PATHSPEC_DEFAULT=%d\n"
	.align	3
.LC1988:
	.string	"constant.GIT_PATHSPEC_DEFAULT="
	.align	3
.LC1989:
	.string	"constant_size.GIT_PATHSPEC_DEFAULT=%zu\n"
	.align	3
.LC1990:
	.string	"constant_signed.GIT_PATHSPEC_DEFAULT=%d\n"
	.align	3
.LC1991:
	.string	"enum_expression_size.GIT_PATHSPEC_FAILURES_ONLY=%zu\n"
	.align	3
.LC1992:
	.string	"enum_expression_signed.GIT_PATHSPEC_FAILURES_ONLY=%d\n"
	.align	3
.LC1993:
	.string	"constant.GIT_PATHSPEC_FAILURES_ONLY="
	.align	3
.LC1994:
	.string	"constant_size.GIT_PATHSPEC_FAILURES_ONLY=%zu\n"
	.align	3
.LC1995:
	.string	"constant_signed.GIT_PATHSPEC_FAILURES_ONLY=%d\n"
	.align	3
.LC1996:
	.string	"enum_expression_size.GIT_PATHSPEC_FIND_FAILURES=%zu\n"
	.align	3
.LC1997:
	.string	"enum_expression_signed.GIT_PATHSPEC_FIND_FAILURES=%d\n"
	.align	3
.LC1998:
	.string	"constant.GIT_PATHSPEC_FIND_FAILURES="
	.align	3
.LC1999:
	.string	"constant_size.GIT_PATHSPEC_FIND_FAILURES=%zu\n"
	.align	3
.LC2000:
	.string	"constant_signed.GIT_PATHSPEC_FIND_FAILURES=%d\n"
	.align	3
.LC2001:
	.string	"enum_expression_size.GIT_PATHSPEC_IGNORE_CASE=%zu\n"
	.align	3
.LC2002:
	.string	"enum_expression_signed.GIT_PATHSPEC_IGNORE_CASE=%d\n"
	.align	3
.LC2003:
	.string	"constant.GIT_PATHSPEC_IGNORE_CASE="
	.align	3
.LC2004:
	.string	"constant_size.GIT_PATHSPEC_IGNORE_CASE=%zu\n"
	.align	3
.LC2005:
	.string	"constant_signed.GIT_PATHSPEC_IGNORE_CASE=%d\n"
	.align	3
.LC2006:
	.string	"enum_expression_size.GIT_PATHSPEC_NO_GLOB=%zu\n"
	.align	3
.LC2007:
	.string	"enum_expression_signed.GIT_PATHSPEC_NO_GLOB=%d\n"
	.align	3
.LC2008:
	.string	"constant.GIT_PATHSPEC_NO_GLOB="
	.align	3
.LC2009:
	.string	"constant_size.GIT_PATHSPEC_NO_GLOB=%zu\n"
	.align	3
.LC2010:
	.string	"constant_signed.GIT_PATHSPEC_NO_GLOB=%d\n"
	.align	3
.LC2011:
	.string	"enum_expression_size.GIT_PATHSPEC_NO_MATCH_ERROR=%zu\n"
	.align	3
.LC2012:
	.string	"enum_expression_signed.GIT_PATHSPEC_NO_MATCH_ERROR=%d\n"
	.align	3
.LC2013:
	.string	"constant.GIT_PATHSPEC_NO_MATCH_ERROR="
	.align	3
.LC2014:
	.string	"constant_size.GIT_PATHSPEC_NO_MATCH_ERROR=%zu\n"
	.align	3
.LC2015:
	.string	"constant_signed.GIT_PATHSPEC_NO_MATCH_ERROR=%d\n"
	.align	3
.LC2016:
	.string	"enum_expression_size.GIT_PATHSPEC_USE_CASE=%zu\n"
	.align	3
.LC2017:
	.string	"enum_expression_signed.GIT_PATHSPEC_USE_CASE=%d\n"
	.align	3
.LC2018:
	.string	"constant.GIT_PATHSPEC_USE_CASE="
	.align	3
.LC2019:
	.string	"constant_size.GIT_PATHSPEC_USE_CASE=%zu\n"
	.align	3
.LC2020:
	.string	"constant_signed.GIT_PATHSPEC_USE_CASE=%d\n"
	.align	3
.LC2021:
	.string	"enum_expression_size.GIT_PROXY_AUTO=%zu\n"
	.align	3
.LC2022:
	.string	"enum_expression_signed.GIT_PROXY_AUTO=%d\n"
	.align	3
.LC2023:
	.string	"constant.GIT_PROXY_AUTO="
	.align	3
.LC2024:
	.string	"constant_size.GIT_PROXY_AUTO=%zu\n"
	.align	3
.LC2025:
	.string	"constant_signed.GIT_PROXY_AUTO=%d\n"
	.align	3
.LC2026:
	.string	"enum_expression_size.GIT_PROXY_NONE=%zu\n"
	.align	3
.LC2027:
	.string	"enum_expression_signed.GIT_PROXY_NONE=%d\n"
	.align	3
.LC2028:
	.string	"constant.GIT_PROXY_NONE="
	.align	3
.LC2029:
	.string	"constant_size.GIT_PROXY_NONE=%zu\n"
	.align	3
.LC2030:
	.string	"constant_signed.GIT_PROXY_NONE=%d\n"
	.align	3
.LC2031:
	.string	"enum_expression_size.GIT_PROXY_SPECIFIED=%zu\n"
	.align	3
.LC2032:
	.string	"enum_expression_signed.GIT_PROXY_SPECIFIED=%d\n"
	.align	3
.LC2033:
	.string	"constant.GIT_PROXY_SPECIFIED="
	.align	3
.LC2034:
	.string	"constant_size.GIT_PROXY_SPECIFIED=%zu\n"
	.align	3
.LC2035:
	.string	"constant_signed.GIT_PROXY_SPECIFIED=%d\n"
	.align	3
.LC2036:
	.string	"enum_expression_size.GIT_REBASE_OPERATION_EDIT=%zu\n"
	.align	3
.LC2037:
	.string	"enum_expression_signed.GIT_REBASE_OPERATION_EDIT=%d\n"
	.align	3
.LC2038:
	.string	"constant.GIT_REBASE_OPERATION_EDIT="
	.align	3
.LC2039:
	.string	"constant_size.GIT_REBASE_OPERATION_EDIT=%zu\n"
	.align	3
.LC2040:
	.string	"constant_signed.GIT_REBASE_OPERATION_EDIT=%d\n"
	.align	3
.LC2041:
	.string	"enum_expression_size.GIT_REBASE_OPERATION_EXEC=%zu\n"
	.align	3
.LC2042:
	.string	"enum_expression_signed.GIT_REBASE_OPERATION_EXEC=%d\n"
	.align	3
.LC2043:
	.string	"constant.GIT_REBASE_OPERATION_EXEC="
	.align	3
.LC2044:
	.string	"constant_size.GIT_REBASE_OPERATION_EXEC=%zu\n"
	.align	3
.LC2045:
	.string	"constant_signed.GIT_REBASE_OPERATION_EXEC=%d\n"
	.align	3
.LC2046:
	.string	"enum_expression_size.GIT_REBASE_OPERATION_FIXUP=%zu\n"
	.align	3
.LC2047:
	.string	"enum_expression_signed.GIT_REBASE_OPERATION_FIXUP=%d\n"
	.align	3
.LC2048:
	.string	"constant.GIT_REBASE_OPERATION_FIXUP="
	.align	3
.LC2049:
	.string	"constant_size.GIT_REBASE_OPERATION_FIXUP=%zu\n"
	.align	3
.LC2050:
	.string	"constant_signed.GIT_REBASE_OPERATION_FIXUP=%d\n"
	.align	3
.LC2051:
	.string	"enum_expression_size.GIT_REBASE_OPERATION_PICK=%zu\n"
	.align	3
.LC2052:
	.string	"enum_expression_signed.GIT_REBASE_OPERATION_PICK=%d\n"
	.align	3
.LC2053:
	.string	"constant.GIT_REBASE_OPERATION_PICK="
	.align	3
.LC2054:
	.string	"constant_size.GIT_REBASE_OPERATION_PICK=%zu\n"
	.align	3
.LC2055:
	.string	"constant_signed.GIT_REBASE_OPERATION_PICK=%d\n"
	.align	3
.LC2056:
	.string	"enum_expression_size.GIT_REBASE_OPERATION_REWORD=%zu\n"
	.align	3
.LC2057:
	.string	"enum_expression_signed.GIT_REBASE_OPERATION_REWORD=%d\n"
	.align	3
.LC2058:
	.string	"constant.GIT_REBASE_OPERATION_REWORD="
	.align	3
.LC2059:
	.string	"constant_size.GIT_REBASE_OPERATION_REWORD=%zu\n"
	.align	3
.LC2060:
	.string	"constant_signed.GIT_REBASE_OPERATION_REWORD=%d\n"
	.align	3
.LC2061:
	.string	"enum_expression_size.GIT_REBASE_OPERATION_SQUASH=%zu\n"
	.align	3
.LC2062:
	.string	"enum_expression_signed.GIT_REBASE_OPERATION_SQUASH=%d\n"
	.align	3
.LC2063:
	.string	"constant.GIT_REBASE_OPERATION_SQUASH="
	.align	3
.LC2064:
	.string	"constant_size.GIT_REBASE_OPERATION_SQUASH=%zu\n"
	.align	3
.LC2065:
	.string	"constant_signed.GIT_REBASE_OPERATION_SQUASH=%d\n"
	.align	3
.LC2066:
	.string	"enum_expression_size.GIT_REFERENCE_ALL=%zu\n"
	.align	3
.LC2067:
	.string	"enum_expression_signed.GIT_REFERENCE_ALL=%d\n"
	.align	3
.LC2068:
	.string	"constant.GIT_REFERENCE_ALL="
	.align	3
.LC2069:
	.string	"constant_size.GIT_REFERENCE_ALL=%zu\n"
	.align	3
.LC2070:
	.string	"constant_signed.GIT_REFERENCE_ALL=%d\n"
	.align	3
.LC2071:
	.string	"enum_expression_size.GIT_REFERENCE_DIRECT=%zu\n"
	.align	3
.LC2072:
	.string	"enum_expression_signed.GIT_REFERENCE_DIRECT=%d\n"
	.align	3
.LC2073:
	.string	"constant.GIT_REFERENCE_DIRECT="
	.align	3
.LC2074:
	.string	"constant_size.GIT_REFERENCE_DIRECT=%zu\n"
	.align	3
.LC2075:
	.string	"constant_signed.GIT_REFERENCE_DIRECT=%d\n"
	.align	3
.LC2076:
	.string	"enum_expression_size.GIT_REFERENCE_FORMAT_ALLOW_ONELEVEL=%zu\n"
	.align	3
.LC2077:
	.string	"enum_expression_signed.GIT_REFERENCE_FORMAT_ALLOW_ONELEVEL=%d\n"
	.align	3
.LC2078:
	.string	"constant.GIT_REFERENCE_FORMAT_ALLOW_ONELEVEL="
	.align	3
.LC2079:
	.string	"constant_size.GIT_REFERENCE_FORMAT_ALLOW_ONELEVEL=%zu\n"
	.align	3
.LC2080:
	.string	"constant_signed.GIT_REFERENCE_FORMAT_ALLOW_ONELEVEL=%d\n"
	.align	3
.LC2081:
	.string	"enum_expression_size.GIT_REFERENCE_FORMAT_NORMAL=%zu\n"
	.align	3
.LC2082:
	.string	"enum_expression_signed.GIT_REFERENCE_FORMAT_NORMAL=%d\n"
	.align	3
.LC2083:
	.string	"constant.GIT_REFERENCE_FORMAT_NORMAL="
	.align	3
.LC2084:
	.string	"constant_size.GIT_REFERENCE_FORMAT_NORMAL=%zu\n"
	.align	3
.LC2085:
	.string	"constant_signed.GIT_REFERENCE_FORMAT_NORMAL=%d\n"
	.align	3
.LC2086:
	.string	"enum_expression_size.GIT_REFERENCE_FORMAT_REFSPEC_PATTERN=%zu\n"
	.align	3
.LC2087:
	.string	"enum_expression_signed.GIT_REFERENCE_FORMAT_REFSPEC_PATTERN=%d\n"
	.align	3
.LC2088:
	.string	"constant.GIT_REFERENCE_FORMAT_REFSPEC_PATTERN="
	.align	3
.LC2089:
	.string	"constant_size.GIT_REFERENCE_FORMAT_REFSPEC_PATTERN=%zu\n"
	.align	3
.LC2090:
	.string	"constant_signed.GIT_REFERENCE_FORMAT_REFSPEC_PATTERN=%d\n"
	.align	3
.LC2091:
	.string	"enum_expression_size.GIT_REFERENCE_FORMAT_REFSPEC_SHORTHAND=%zu\n"
	.align	3
.LC2092:
	.string	"enum_expression_signed.GIT_REFERENCE_FORMAT_REFSPEC_SHORTHAND=%d\n"
	.align	3
.LC2093:
	.string	"constant.GIT_REFERENCE_FORMAT_REFSPEC_SHORTHAND="
	.align	3
.LC2094:
	.string	"constant_size.GIT_REFERENCE_FORMAT_REFSPEC_SHORTHAND=%zu\n"
	.align	3
.LC2095:
	.string	"constant_signed.GIT_REFERENCE_FORMAT_REFSPEC_SHORTHAND=%d\n"
	.align	3
.LC2096:
	.string	"enum_expression_size.GIT_REFERENCE_INVALID=%zu\n"
	.align	3
.LC2097:
	.string	"enum_expression_signed.GIT_REFERENCE_INVALID=%d\n"
	.align	3
.LC2098:
	.string	"constant.GIT_REFERENCE_INVALID="
	.align	3
.LC2099:
	.string	"constant_size.GIT_REFERENCE_INVALID=%zu\n"
	.align	3
.LC2100:
	.string	"constant_signed.GIT_REFERENCE_INVALID=%d\n"
	.align	3
.LC2101:
	.string	"enum_expression_size.GIT_REFERENCE_SYMBOLIC=%zu\n"
	.align	3
.LC2102:
	.string	"enum_expression_signed.GIT_REFERENCE_SYMBOLIC=%d\n"
	.align	3
.LC2103:
	.string	"constant.GIT_REFERENCE_SYMBOLIC="
	.align	3
.LC2104:
	.string	"constant_size.GIT_REFERENCE_SYMBOLIC=%zu\n"
	.align	3
.LC2105:
	.string	"constant_signed.GIT_REFERENCE_SYMBOLIC=%d\n"
	.align	3
.LC2106:
	.string	"enum_expression_size.GIT_REMOTE_COMPLETION_DOWNLOAD=%zu\n"
	.align	3
.LC2107:
	.string	"enum_expression_signed.GIT_REMOTE_COMPLETION_DOWNLOAD=%d\n"
	.align	3
.LC2108:
	.string	"constant.GIT_REMOTE_COMPLETION_DOWNLOAD="
	.align	3
.LC2109:
	.string	"constant_size.GIT_REMOTE_COMPLETION_DOWNLOAD=%zu\n"
	.align	3
.LC2110:
	.string	"constant_signed.GIT_REMOTE_COMPLETION_DOWNLOAD=%d\n"
	.align	3
.LC2111:
	.string	"enum_expression_size.GIT_REMOTE_COMPLETION_ERROR=%zu\n"
	.align	3
.LC2112:
	.string	"enum_expression_signed.GIT_REMOTE_COMPLETION_ERROR=%d\n"
	.align	3
.LC2113:
	.string	"constant.GIT_REMOTE_COMPLETION_ERROR="
	.align	3
.LC2114:
	.string	"constant_size.GIT_REMOTE_COMPLETION_ERROR=%zu\n"
	.align	3
.LC2115:
	.string	"constant_signed.GIT_REMOTE_COMPLETION_ERROR=%d\n"
	.align	3
.LC2116:
	.string	"enum_expression_size.GIT_REMOTE_COMPLETION_INDEXING=%zu\n"
	.align	3
.LC2117:
	.string	"enum_expression_signed.GIT_REMOTE_COMPLETION_INDEXING=%d\n"
	.align	3
.LC2118:
	.string	"constant.GIT_REMOTE_COMPLETION_INDEXING="
	.align	3
.LC2119:
	.string	"constant_size.GIT_REMOTE_COMPLETION_INDEXING=%zu\n"
	.align	3
.LC2120:
	.string	"constant_signed.GIT_REMOTE_COMPLETION_INDEXING=%d\n"
	.align	3
.LC2121:
	.string	"enum_expression_size.GIT_REMOTE_CREATE_SKIP_DEFAULT_FETCHSPEC=%zu\n"
	.align	3
.LC2122:
	.string	"enum_expression_signed.GIT_REMOTE_CREATE_SKIP_DEFAULT_FETCHSPEC=%d\n"
	.align	3
.LC2123:
	.string	"constant.GIT_REMOTE_CREATE_SKIP_DEFAULT_FETCHSPEC="
	.align	3
.LC2124:
	.string	"constant_size.GIT_REMOTE_CREATE_SKIP_DEFAULT_FETCHSPEC=%zu\n"
	.align	3
.LC2125:
	.string	"constant_signed.GIT_REMOTE_CREATE_SKIP_DEFAULT_FETCHSPEC=%d\n"
	.align	3
.LC2126:
	.string	"enum_expression_size.GIT_REMOTE_CREATE_SKIP_INSTEADOF=%zu\n"
	.align	3
.LC2127:
	.string	"enum_expression_signed.GIT_REMOTE_CREATE_SKIP_INSTEADOF=%d\n"
	.align	3
.LC2128:
	.string	"constant.GIT_REMOTE_CREATE_SKIP_INSTEADOF="
	.align	3
.LC2129:
	.string	"constant_size.GIT_REMOTE_CREATE_SKIP_INSTEADOF=%zu\n"
	.align	3
.LC2130:
	.string	"constant_signed.GIT_REMOTE_CREATE_SKIP_INSTEADOF=%d\n"
	.align	3
.LC2131:
	.string	"enum_expression_size.GIT_REMOTE_DOWNLOAD_TAGS_ALL=%zu\n"
	.align	3
.LC2132:
	.string	"enum_expression_signed.GIT_REMOTE_DOWNLOAD_TAGS_ALL=%d\n"
	.align	3
.LC2133:
	.string	"constant.GIT_REMOTE_DOWNLOAD_TAGS_ALL="
	.align	3
.LC2134:
	.string	"constant_size.GIT_REMOTE_DOWNLOAD_TAGS_ALL=%zu\n"
	.align	3
.LC2135:
	.string	"constant_signed.GIT_REMOTE_DOWNLOAD_TAGS_ALL=%d\n"
	.align	3
.LC2136:
	.string	"enum_expression_size.GIT_REMOTE_DOWNLOAD_TAGS_AUTO=%zu\n"
	.align	3
.LC2137:
	.string	"enum_expression_signed.GIT_REMOTE_DOWNLOAD_TAGS_AUTO=%d\n"
	.align	3
.LC2138:
	.string	"constant.GIT_REMOTE_DOWNLOAD_TAGS_AUTO="
	.align	3
.LC2139:
	.string	"constant_size.GIT_REMOTE_DOWNLOAD_TAGS_AUTO=%zu\n"
	.align	3
.LC2140:
	.string	"constant_signed.GIT_REMOTE_DOWNLOAD_TAGS_AUTO=%d\n"
	.align	3
.LC2141:
	.string	"enum_expression_size.GIT_REMOTE_DOWNLOAD_TAGS_NONE=%zu\n"
	.align	3
.LC2142:
	.string	"enum_expression_signed.GIT_REMOTE_DOWNLOAD_TAGS_NONE=%d\n"
	.align	3
.LC2143:
	.string	"constant.GIT_REMOTE_DOWNLOAD_TAGS_NONE="
	.align	3
.LC2144:
	.string	"constant_size.GIT_REMOTE_DOWNLOAD_TAGS_NONE=%zu\n"
	.align	3
.LC2145:
	.string	"constant_signed.GIT_REMOTE_DOWNLOAD_TAGS_NONE=%d\n"
	.align	3
.LC2146:
	.string	"enum_expression_size.GIT_REMOTE_DOWNLOAD_TAGS_UNSPECIFIED=%zu\n"
	.align	3
.LC2147:
	.string	"enum_expression_signed.GIT_REMOTE_DOWNLOAD_TAGS_UNSPECIFIED=%d\n"
	.align	3
.LC2148:
	.string	"constant.GIT_REMOTE_DOWNLOAD_TAGS_UNSPECIFIED="
	.align	3
.LC2149:
	.string	"constant_size.GIT_REMOTE_DOWNLOAD_TAGS_UNSPECIFIED=%zu\n"
	.align	3
.LC2150:
	.string	"constant_signed.GIT_REMOTE_DOWNLOAD_TAGS_UNSPECIFIED=%d\n"
	.align	3
.LC2151:
	.string	"enum_expression_size.GIT_REMOTE_REDIRECT_ALL=%zu\n"
	.align	3
.LC2152:
	.string	"enum_expression_signed.GIT_REMOTE_REDIRECT_ALL=%d\n"
	.align	3
.LC2153:
	.string	"constant.GIT_REMOTE_REDIRECT_ALL="
	.align	3
.LC2154:
	.string	"constant_size.GIT_REMOTE_REDIRECT_ALL=%zu\n"
	.align	3
.LC2155:
	.string	"constant_signed.GIT_REMOTE_REDIRECT_ALL=%d\n"
	.align	3
.LC2156:
	.string	"enum_expression_size.GIT_REMOTE_REDIRECT_INITIAL=%zu\n"
	.align	3
.LC2157:
	.string	"enum_expression_signed.GIT_REMOTE_REDIRECT_INITIAL=%d\n"
	.align	3
.LC2158:
	.string	"constant.GIT_REMOTE_REDIRECT_INITIAL="
	.align	3
.LC2159:
	.string	"constant_size.GIT_REMOTE_REDIRECT_INITIAL=%zu\n"
	.align	3
.LC2160:
	.string	"constant_signed.GIT_REMOTE_REDIRECT_INITIAL=%d\n"
	.align	3
.LC2161:
	.string	"enum_expression_size.GIT_REMOTE_REDIRECT_NONE=%zu\n"
	.align	3
.LC2162:
	.string	"enum_expression_signed.GIT_REMOTE_REDIRECT_NONE=%d\n"
	.align	3
.LC2163:
	.string	"constant.GIT_REMOTE_REDIRECT_NONE="
	.align	3
.LC2164:
	.string	"constant_size.GIT_REMOTE_REDIRECT_NONE=%zu\n"
	.align	3
.LC2165:
	.string	"constant_signed.GIT_REMOTE_REDIRECT_NONE=%d\n"
	.align	3
.LC2166:
	.string	"enum_expression_size.GIT_REMOTE_UPDATE_FETCHHEAD=%zu\n"
	.align	3
.LC2167:
	.string	"enum_expression_signed.GIT_REMOTE_UPDATE_FETCHHEAD=%d\n"
	.align	3
.LC2168:
	.string	"constant.GIT_REMOTE_UPDATE_FETCHHEAD="
	.align	3
.LC2169:
	.string	"constant_size.GIT_REMOTE_UPDATE_FETCHHEAD=%zu\n"
	.align	3
.LC2170:
	.string	"constant_signed.GIT_REMOTE_UPDATE_FETCHHEAD=%d\n"
	.align	3
.LC2171:
	.string	"enum_expression_size.GIT_REMOTE_UPDATE_REPORT_UNCHANGED=%zu\n"
	.align	3
.LC2172:
	.string	"enum_expression_signed.GIT_REMOTE_UPDATE_REPORT_UNCHANGED=%d\n"
	.align	3
.LC2173:
	.string	"constant.GIT_REMOTE_UPDATE_REPORT_UNCHANGED="
	.align	3
.LC2174:
	.string	"constant_size.GIT_REMOTE_UPDATE_REPORT_UNCHANGED=%zu\n"
	.align	3
.LC2175:
	.string	"constant_signed.GIT_REMOTE_UPDATE_REPORT_UNCHANGED=%d\n"
	.align	3
.LC2176:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_BARE=%zu\n"
	.align	3
.LC2177:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_BARE=%d\n"
	.align	3
.LC2178:
	.string	"constant.GIT_REPOSITORY_INIT_BARE="
	.align	3
.LC2179:
	.string	"constant_size.GIT_REPOSITORY_INIT_BARE=%zu\n"
	.align	3
.LC2180:
	.string	"constant_signed.GIT_REPOSITORY_INIT_BARE=%d\n"
	.align	3
.LC2181:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE=%zu\n"
	.align	3
.LC2182:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE=%d\n"
	.align	3
.LC2183:
	.string	"constant.GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE="
	.align	3
.LC2184:
	.string	"constant_size.GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE=%zu\n"
	.align	3
.LC2185:
	.string	"constant_signed.GIT_REPOSITORY_INIT_EXTERNAL_TEMPLATE=%d\n"
	.align	3
.LC2186:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_MKDIR=%zu\n"
	.align	3
.LC2187:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_MKDIR=%d\n"
	.align	3
.LC2188:
	.string	"constant.GIT_REPOSITORY_INIT_MKDIR="
	.align	3
.LC2189:
	.string	"constant_size.GIT_REPOSITORY_INIT_MKDIR=%zu\n"
	.align	3
.LC2190:
	.string	"constant_signed.GIT_REPOSITORY_INIT_MKDIR=%d\n"
	.align	3
.LC2191:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_MKPATH=%zu\n"
	.align	3
.LC2192:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_MKPATH=%d\n"
	.align	3
.LC2193:
	.string	"constant.GIT_REPOSITORY_INIT_MKPATH="
	.align	3
.LC2194:
	.string	"constant_size.GIT_REPOSITORY_INIT_MKPATH=%zu\n"
	.align	3
.LC2195:
	.string	"constant_signed.GIT_REPOSITORY_INIT_MKPATH=%d\n"
	.align	3
.LC2196:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_NO_DOTGIT_DIR=%zu\n"
	.align	3
.LC2197:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_NO_DOTGIT_DIR=%d\n"
	.align	3
.LC2198:
	.string	"constant.GIT_REPOSITORY_INIT_NO_DOTGIT_DIR="
	.align	3
.LC2199:
	.string	"constant_size.GIT_REPOSITORY_INIT_NO_DOTGIT_DIR=%zu\n"
	.align	3
.LC2200:
	.string	"constant_signed.GIT_REPOSITORY_INIT_NO_DOTGIT_DIR=%d\n"
	.align	3
.LC2201:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_NO_REINIT=%zu\n"
	.align	3
.LC2202:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_NO_REINIT=%d\n"
	.align	3
.LC2203:
	.string	"constant.GIT_REPOSITORY_INIT_NO_REINIT="
	.align	3
.LC2204:
	.string	"constant_size.GIT_REPOSITORY_INIT_NO_REINIT=%zu\n"
	.align	3
.LC2205:
	.string	"constant_signed.GIT_REPOSITORY_INIT_NO_REINIT=%d\n"
	.align	3
.LC2206:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_RELATIVE_GITLINK=%zu\n"
	.align	3
.LC2207:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_RELATIVE_GITLINK=%d\n"
	.align	3
.LC2208:
	.string	"constant.GIT_REPOSITORY_INIT_RELATIVE_GITLINK="
	.align	3
.LC2209:
	.string	"constant_size.GIT_REPOSITORY_INIT_RELATIVE_GITLINK=%zu\n"
	.align	3
.LC2210:
	.string	"constant_signed.GIT_REPOSITORY_INIT_RELATIVE_GITLINK=%d\n"
	.align	3
.LC2211:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_SHARED_ALL=%zu\n"
	.align	3
.LC2212:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_SHARED_ALL=%d\n"
	.align	3
.LC2213:
	.string	"constant.GIT_REPOSITORY_INIT_SHARED_ALL="
	.align	3
.LC2214:
	.string	"constant_size.GIT_REPOSITORY_INIT_SHARED_ALL=%zu\n"
	.align	3
.LC2215:
	.string	"constant_signed.GIT_REPOSITORY_INIT_SHARED_ALL=%d\n"
	.align	3
.LC2216:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_SHARED_GROUP=%zu\n"
	.align	3
.LC2217:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_SHARED_GROUP=%d\n"
	.align	3
.LC2218:
	.string	"constant.GIT_REPOSITORY_INIT_SHARED_GROUP="
	.align	3
.LC2219:
	.string	"constant_size.GIT_REPOSITORY_INIT_SHARED_GROUP=%zu\n"
	.align	3
.LC2220:
	.string	"constant_signed.GIT_REPOSITORY_INIT_SHARED_GROUP=%d\n"
	.align	3
.LC2221:
	.string	"enum_expression_size.GIT_REPOSITORY_INIT_SHARED_UMASK=%zu\n"
	.align	3
.LC2222:
	.string	"enum_expression_signed.GIT_REPOSITORY_INIT_SHARED_UMASK=%d\n"
	.align	3
.LC2223:
	.string	"constant.GIT_REPOSITORY_INIT_SHARED_UMASK="
	.align	3
.LC2224:
	.string	"constant_size.GIT_REPOSITORY_INIT_SHARED_UMASK=%zu\n"
	.align	3
.LC2225:
	.string	"constant_signed.GIT_REPOSITORY_INIT_SHARED_UMASK=%d\n"
	.align	3
.LC2226:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_COMMONDIR=%zu\n"
	.align	3
.LC2227:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_COMMONDIR=%d\n"
	.align	3
.LC2228:
	.string	"constant.GIT_REPOSITORY_ITEM_COMMONDIR="
	.align	3
.LC2229:
	.string	"constant_size.GIT_REPOSITORY_ITEM_COMMONDIR=%zu\n"
	.align	3
.LC2230:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_COMMONDIR=%d\n"
	.align	3
.LC2231:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_CONFIG=%zu\n"
	.align	3
.LC2232:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_CONFIG=%d\n"
	.align	3
.LC2233:
	.string	"constant.GIT_REPOSITORY_ITEM_CONFIG="
	.align	3
.LC2234:
	.string	"constant_size.GIT_REPOSITORY_ITEM_CONFIG=%zu\n"
	.align	3
.LC2235:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_CONFIG=%d\n"
	.align	3
.LC2236:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_GITDIR=%zu\n"
	.align	3
.LC2237:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_GITDIR=%d\n"
	.align	3
.LC2238:
	.string	"constant.GIT_REPOSITORY_ITEM_GITDIR="
	.align	3
.LC2239:
	.string	"constant_size.GIT_REPOSITORY_ITEM_GITDIR=%zu\n"
	.align	3
.LC2240:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_GITDIR=%d\n"
	.align	3
.LC2241:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_HOOKS=%zu\n"
	.align	3
.LC2242:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_HOOKS=%d\n"
	.align	3
.LC2243:
	.string	"constant.GIT_REPOSITORY_ITEM_HOOKS="
	.align	3
.LC2244:
	.string	"constant_size.GIT_REPOSITORY_ITEM_HOOKS=%zu\n"
	.align	3
.LC2245:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_HOOKS=%d\n"
	.align	3
.LC2246:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_INDEX=%zu\n"
	.align	3
.LC2247:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_INDEX=%d\n"
	.align	3
.LC2248:
	.string	"constant.GIT_REPOSITORY_ITEM_INDEX="
	.align	3
.LC2249:
	.string	"constant_size.GIT_REPOSITORY_ITEM_INDEX=%zu\n"
	.align	3
.LC2250:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_INDEX=%d\n"
	.align	3
.LC2251:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_INFO=%zu\n"
	.align	3
.LC2252:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_INFO=%d\n"
	.align	3
.LC2253:
	.string	"constant.GIT_REPOSITORY_ITEM_INFO="
	.align	3
.LC2254:
	.string	"constant_size.GIT_REPOSITORY_ITEM_INFO=%zu\n"
	.align	3
.LC2255:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_INFO=%d\n"
	.align	3
.LC2256:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_LOGS=%zu\n"
	.align	3
.LC2257:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_LOGS=%d\n"
	.align	3
.LC2258:
	.string	"constant.GIT_REPOSITORY_ITEM_LOGS="
	.align	3
.LC2259:
	.string	"constant_size.GIT_REPOSITORY_ITEM_LOGS=%zu\n"
	.align	3
.LC2260:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_LOGS=%d\n"
	.align	3
.LC2261:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_MODULES=%zu\n"
	.align	3
.LC2262:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_MODULES=%d\n"
	.align	3
.LC2263:
	.string	"constant.GIT_REPOSITORY_ITEM_MODULES="
	.align	3
.LC2264:
	.string	"constant_size.GIT_REPOSITORY_ITEM_MODULES=%zu\n"
	.align	3
.LC2265:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_MODULES=%d\n"
	.align	3
.LC2266:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_OBJECTS=%zu\n"
	.align	3
.LC2267:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_OBJECTS=%d\n"
	.align	3
.LC2268:
	.string	"constant.GIT_REPOSITORY_ITEM_OBJECTS="
	.align	3
.LC2269:
	.string	"constant_size.GIT_REPOSITORY_ITEM_OBJECTS=%zu\n"
	.align	3
.LC2270:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_OBJECTS=%d\n"
	.align	3
.LC2271:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_PACKED_REFS=%zu\n"
	.align	3
.LC2272:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_PACKED_REFS=%d\n"
	.align	3
.LC2273:
	.string	"constant.GIT_REPOSITORY_ITEM_PACKED_REFS="
	.align	3
.LC2274:
	.string	"constant_size.GIT_REPOSITORY_ITEM_PACKED_REFS=%zu\n"
	.align	3
.LC2275:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_PACKED_REFS=%d\n"
	.align	3
.LC2276:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_REFS=%zu\n"
	.align	3
.LC2277:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_REFS=%d\n"
	.align	3
.LC2278:
	.string	"constant.GIT_REPOSITORY_ITEM_REFS="
	.align	3
.LC2279:
	.string	"constant_size.GIT_REPOSITORY_ITEM_REFS=%zu\n"
	.align	3
.LC2280:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_REFS=%d\n"
	.align	3
.LC2281:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_REMOTES=%zu\n"
	.align	3
.LC2282:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_REMOTES=%d\n"
	.align	3
.LC2283:
	.string	"constant.GIT_REPOSITORY_ITEM_REMOTES="
	.align	3
.LC2284:
	.string	"constant_size.GIT_REPOSITORY_ITEM_REMOTES=%zu\n"
	.align	3
.LC2285:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_REMOTES=%d\n"
	.align	3
.LC2286:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_WORKDIR=%zu\n"
	.align	3
.LC2287:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_WORKDIR=%d\n"
	.align	3
.LC2288:
	.string	"constant.GIT_REPOSITORY_ITEM_WORKDIR="
	.align	3
.LC2289:
	.string	"constant_size.GIT_REPOSITORY_ITEM_WORKDIR=%zu\n"
	.align	3
.LC2290:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_WORKDIR=%d\n"
	.align	3
.LC2291:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_WORKTREES=%zu\n"
	.align	3
.LC2292:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_WORKTREES=%d\n"
	.align	3
.LC2293:
	.string	"constant.GIT_REPOSITORY_ITEM_WORKTREES="
	.align	3
.LC2294:
	.string	"constant_size.GIT_REPOSITORY_ITEM_WORKTREES=%zu\n"
	.align	3
.LC2295:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_WORKTREES=%d\n"
	.align	3
.LC2296:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM_WORKTREE_CONFIG=%zu\n"
	.align	3
.LC2297:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM_WORKTREE_CONFIG=%d\n"
	.align	3
.LC2298:
	.string	"constant.GIT_REPOSITORY_ITEM_WORKTREE_CONFIG="
	.align	3
.LC2299:
	.string	"constant_size.GIT_REPOSITORY_ITEM_WORKTREE_CONFIG=%zu\n"
	.align	3
.LC2300:
	.string	"constant_signed.GIT_REPOSITORY_ITEM_WORKTREE_CONFIG=%d\n"
	.align	3
.LC2301:
	.string	"enum_expression_size.GIT_REPOSITORY_ITEM__LAST=%zu\n"
	.align	3
.LC2302:
	.string	"enum_expression_signed.GIT_REPOSITORY_ITEM__LAST=%d\n"
	.align	3
.LC2303:
	.string	"constant.GIT_REPOSITORY_ITEM__LAST="
	.align	3
.LC2304:
	.string	"constant_size.GIT_REPOSITORY_ITEM__LAST=%zu\n"
	.align	3
.LC2305:
	.string	"constant_signed.GIT_REPOSITORY_ITEM__LAST=%d\n"
	.align	3
.LC2306:
	.string	"enum_expression_size.GIT_REPOSITORY_OPEN_BARE=%zu\n"
	.align	3
.LC2307:
	.string	"enum_expression_signed.GIT_REPOSITORY_OPEN_BARE=%d\n"
	.align	3
.LC2308:
	.string	"constant.GIT_REPOSITORY_OPEN_BARE="
	.align	3
.LC2309:
	.string	"constant_size.GIT_REPOSITORY_OPEN_BARE=%zu\n"
	.align	3
.LC2310:
	.string	"constant_signed.GIT_REPOSITORY_OPEN_BARE=%d\n"
	.align	3
.LC2311:
	.string	"enum_expression_size.GIT_REPOSITORY_OPEN_CROSS_FS=%zu\n"
	.align	3
.LC2312:
	.string	"enum_expression_signed.GIT_REPOSITORY_OPEN_CROSS_FS=%d\n"
	.align	3
.LC2313:
	.string	"constant.GIT_REPOSITORY_OPEN_CROSS_FS="
	.align	3
.LC2314:
	.string	"constant_size.GIT_REPOSITORY_OPEN_CROSS_FS=%zu\n"
	.align	3
.LC2315:
	.string	"constant_signed.GIT_REPOSITORY_OPEN_CROSS_FS=%d\n"
	.align	3
.LC2316:
	.string	"enum_expression_size.GIT_REPOSITORY_OPEN_FROM_ENV=%zu\n"
	.align	3
.LC2317:
	.string	"enum_expression_signed.GIT_REPOSITORY_OPEN_FROM_ENV=%d\n"
	.align	3
.LC2318:
	.string	"constant.GIT_REPOSITORY_OPEN_FROM_ENV="
	.align	3
.LC2319:
	.string	"constant_size.GIT_REPOSITORY_OPEN_FROM_ENV=%zu\n"
	.align	3
.LC2320:
	.string	"constant_signed.GIT_REPOSITORY_OPEN_FROM_ENV=%d\n"
	.align	3
.LC2321:
	.string	"enum_expression_size.GIT_REPOSITORY_OPEN_NO_DOTGIT=%zu\n"
	.align	3
.LC2322:
	.string	"enum_expression_signed.GIT_REPOSITORY_OPEN_NO_DOTGIT=%d\n"
	.align	3
.LC2323:
	.string	"constant.GIT_REPOSITORY_OPEN_NO_DOTGIT="
	.align	3
.LC2324:
	.string	"constant_size.GIT_REPOSITORY_OPEN_NO_DOTGIT=%zu\n"
	.align	3
.LC2325:
	.string	"constant_signed.GIT_REPOSITORY_OPEN_NO_DOTGIT=%d\n"
	.align	3
.LC2326:
	.string	"enum_expression_size.GIT_REPOSITORY_OPEN_NO_SEARCH=%zu\n"
	.align	3
.LC2327:
	.string	"enum_expression_signed.GIT_REPOSITORY_OPEN_NO_SEARCH=%d\n"
	.align	3
.LC2328:
	.string	"constant.GIT_REPOSITORY_OPEN_NO_SEARCH="
	.align	3
.LC2329:
	.string	"constant_size.GIT_REPOSITORY_OPEN_NO_SEARCH=%zu\n"
	.align	3
.LC2330:
	.string	"constant_signed.GIT_REPOSITORY_OPEN_NO_SEARCH=%d\n"
	.align	3
.LC2331:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_APPLY_MAILBOX=%zu\n"
	.align	3
.LC2332:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_APPLY_MAILBOX=%d\n"
	.align	3
.LC2333:
	.string	"constant.GIT_REPOSITORY_STATE_APPLY_MAILBOX="
	.align	3
.LC2334:
	.string	"constant_size.GIT_REPOSITORY_STATE_APPLY_MAILBOX=%zu\n"
	.align	3
.LC2335:
	.string	"constant_signed.GIT_REPOSITORY_STATE_APPLY_MAILBOX=%d\n"
	.align	3
.LC2336:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE=%zu\n"
	.align	3
.LC2337:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE=%d\n"
	.align	3
.LC2338:
	.string	"constant.GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE="
	.align	3
.LC2339:
	.string	"constant_size.GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE=%zu\n"
	.align	3
.LC2340:
	.string	"constant_signed.GIT_REPOSITORY_STATE_APPLY_MAILBOX_OR_REBASE=%d\n"
	.align	3
.LC2341:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_BISECT=%zu\n"
	.align	3
.LC2342:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_BISECT=%d\n"
	.align	3
.LC2343:
	.string	"constant.GIT_REPOSITORY_STATE_BISECT="
	.align	3
.LC2344:
	.string	"constant_size.GIT_REPOSITORY_STATE_BISECT=%zu\n"
	.align	3
.LC2345:
	.string	"constant_signed.GIT_REPOSITORY_STATE_BISECT=%d\n"
	.align	3
.LC2346:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_CHERRYPICK=%zu\n"
	.align	3
.LC2347:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_CHERRYPICK=%d\n"
	.align	3
.LC2348:
	.string	"constant.GIT_REPOSITORY_STATE_CHERRYPICK="
	.align	3
.LC2349:
	.string	"constant_size.GIT_REPOSITORY_STATE_CHERRYPICK=%zu\n"
	.align	3
.LC2350:
	.string	"constant_signed.GIT_REPOSITORY_STATE_CHERRYPICK=%d\n"
	.align	3
.LC2351:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE=%zu\n"
	.align	3
.LC2352:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE=%d\n"
	.align	3
.LC2353:
	.string	"constant.GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE="
	.align	3
.LC2354:
	.string	"constant_size.GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE=%zu\n"
	.align	3
.LC2355:
	.string	"constant_signed.GIT_REPOSITORY_STATE_CHERRYPICK_SEQUENCE=%d\n"
	.align	3
.LC2356:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_MERGE=%zu\n"
	.align	3
.LC2357:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_MERGE=%d\n"
	.align	3
.LC2358:
	.string	"constant.GIT_REPOSITORY_STATE_MERGE="
	.align	3
.LC2359:
	.string	"constant_size.GIT_REPOSITORY_STATE_MERGE=%zu\n"
	.align	3
.LC2360:
	.string	"constant_signed.GIT_REPOSITORY_STATE_MERGE=%d\n"
	.align	3
.LC2361:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_NONE=%zu\n"
	.align	3
.LC2362:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_NONE=%d\n"
	.align	3
.LC2363:
	.string	"constant.GIT_REPOSITORY_STATE_NONE="
	.align	3
.LC2364:
	.string	"constant_size.GIT_REPOSITORY_STATE_NONE=%zu\n"
	.align	3
.LC2365:
	.string	"constant_signed.GIT_REPOSITORY_STATE_NONE=%d\n"
	.align	3
.LC2366:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_REBASE=%zu\n"
	.align	3
.LC2367:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_REBASE=%d\n"
	.align	3
.LC2368:
	.string	"constant.GIT_REPOSITORY_STATE_REBASE="
	.align	3
.LC2369:
	.string	"constant_size.GIT_REPOSITORY_STATE_REBASE=%zu\n"
	.align	3
.LC2370:
	.string	"constant_signed.GIT_REPOSITORY_STATE_REBASE=%d\n"
	.align	3
.LC2371:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_REBASE_INTERACTIVE=%zu\n"
	.align	3
.LC2372:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_REBASE_INTERACTIVE=%d\n"
	.align	3
.LC2373:
	.string	"constant.GIT_REPOSITORY_STATE_REBASE_INTERACTIVE="
	.align	3
.LC2374:
	.string	"constant_size.GIT_REPOSITORY_STATE_REBASE_INTERACTIVE=%zu\n"
	.align	3
.LC2375:
	.string	"constant_signed.GIT_REPOSITORY_STATE_REBASE_INTERACTIVE=%d\n"
	.align	3
.LC2376:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_REBASE_MERGE=%zu\n"
	.align	3
.LC2377:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_REBASE_MERGE=%d\n"
	.align	3
.LC2378:
	.string	"constant.GIT_REPOSITORY_STATE_REBASE_MERGE="
	.align	3
.LC2379:
	.string	"constant_size.GIT_REPOSITORY_STATE_REBASE_MERGE=%zu\n"
	.align	3
.LC2380:
	.string	"constant_signed.GIT_REPOSITORY_STATE_REBASE_MERGE=%d\n"
	.align	3
.LC2381:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_REVERT=%zu\n"
	.align	3
.LC2382:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_REVERT=%d\n"
	.align	3
.LC2383:
	.string	"constant.GIT_REPOSITORY_STATE_REVERT="
	.align	3
.LC2384:
	.string	"constant_size.GIT_REPOSITORY_STATE_REVERT=%zu\n"
	.align	3
.LC2385:
	.string	"constant_signed.GIT_REPOSITORY_STATE_REVERT=%d\n"
	.align	3
.LC2386:
	.string	"enum_expression_size.GIT_REPOSITORY_STATE_REVERT_SEQUENCE=%zu\n"
	.align	3
.LC2387:
	.string	"enum_expression_signed.GIT_REPOSITORY_STATE_REVERT_SEQUENCE=%d\n"
	.align	3
.LC2388:
	.string	"constant.GIT_REPOSITORY_STATE_REVERT_SEQUENCE="
	.align	3
.LC2389:
	.string	"constant_size.GIT_REPOSITORY_STATE_REVERT_SEQUENCE=%zu\n"
	.align	3
.LC2390:
	.string	"constant_signed.GIT_REPOSITORY_STATE_REVERT_SEQUENCE=%d\n"
	.align	3
.LC2391:
	.string	"enum_expression_size.GIT_RESET_HARD=%zu\n"
	.align	3
.LC2392:
	.string	"enum_expression_signed.GIT_RESET_HARD=%d\n"
	.align	3
.LC2393:
	.string	"constant.GIT_RESET_HARD="
	.align	3
.LC2394:
	.string	"constant_size.GIT_RESET_HARD=%zu\n"
	.align	3
.LC2395:
	.string	"constant_signed.GIT_RESET_HARD=%d\n"
	.align	3
.LC2396:
	.string	"enum_expression_size.GIT_RESET_MIXED=%zu\n"
	.align	3
.LC2397:
	.string	"enum_expression_signed.GIT_RESET_MIXED=%d\n"
	.align	3
.LC2398:
	.string	"constant.GIT_RESET_MIXED="
	.align	3
.LC2399:
	.string	"constant_size.GIT_RESET_MIXED=%zu\n"
	.align	3
.LC2400:
	.string	"constant_signed.GIT_RESET_MIXED=%d\n"
	.align	3
.LC2401:
	.string	"enum_expression_size.GIT_RESET_SOFT=%zu\n"
	.align	3
.LC2402:
	.string	"enum_expression_signed.GIT_RESET_SOFT=%d\n"
	.align	3
.LC2403:
	.string	"constant.GIT_RESET_SOFT="
	.align	3
.LC2404:
	.string	"constant_size.GIT_RESET_SOFT=%zu\n"
	.align	3
.LC2405:
	.string	"constant_signed.GIT_RESET_SOFT=%d\n"
	.align	3
.LC2406:
	.string	"enum_expression_size.GIT_RETRY=%zu\n"
	.align	3
.LC2407:
	.string	"enum_expression_signed.GIT_RETRY=%d\n"
	.align	3
.LC2408:
	.string	"constant.GIT_RETRY="
	.align	3
.LC2409:
	.string	"constant_size.GIT_RETRY=%zu\n"
	.align	3
.LC2410:
	.string	"constant_signed.GIT_RETRY=%d\n"
	.align	3
.LC2411:
	.string	"enum_expression_size.GIT_REVSPEC_MERGE_BASE=%zu\n"
	.align	3
.LC2412:
	.string	"enum_expression_signed.GIT_REVSPEC_MERGE_BASE=%d\n"
	.align	3
.LC2413:
	.string	"constant.GIT_REVSPEC_MERGE_BASE="
	.align	3
.LC2414:
	.string	"constant_size.GIT_REVSPEC_MERGE_BASE=%zu\n"
	.align	3
.LC2415:
	.string	"constant_signed.GIT_REVSPEC_MERGE_BASE=%d\n"
	.align	3
.LC2416:
	.string	"enum_expression_size.GIT_REVSPEC_RANGE=%zu\n"
	.align	3
.LC2417:
	.string	"enum_expression_signed.GIT_REVSPEC_RANGE=%d\n"
	.align	3
.LC2418:
	.string	"constant.GIT_REVSPEC_RANGE="
	.align	3
.LC2419:
	.string	"constant_size.GIT_REVSPEC_RANGE=%zu\n"
	.align	3
.LC2420:
	.string	"constant_signed.GIT_REVSPEC_RANGE=%d\n"
	.align	3
.LC2421:
	.string	"enum_expression_size.GIT_REVSPEC_SINGLE=%zu\n"
	.align	3
.LC2422:
	.string	"enum_expression_signed.GIT_REVSPEC_SINGLE=%d\n"
	.align	3
.LC2423:
	.string	"constant.GIT_REVSPEC_SINGLE="
	.align	3
.LC2424:
	.string	"constant_size.GIT_REVSPEC_SINGLE=%zu\n"
	.align	3
.LC2425:
	.string	"constant_signed.GIT_REVSPEC_SINGLE=%d\n"
	.align	3
.LC2426:
	.string	"enum_expression_size.GIT_SORT_NONE=%zu\n"
	.align	3
.LC2427:
	.string	"enum_expression_signed.GIT_SORT_NONE=%d\n"
	.align	3
.LC2428:
	.string	"constant.GIT_SORT_NONE="
	.align	3
.LC2429:
	.string	"constant_size.GIT_SORT_NONE=%zu\n"
	.align	3
.LC2430:
	.string	"constant_signed.GIT_SORT_NONE=%d\n"
	.align	3
.LC2431:
	.string	"enum_expression_size.GIT_SORT_REVERSE=%zu\n"
	.align	3
.LC2432:
	.string	"enum_expression_signed.GIT_SORT_REVERSE=%d\n"
	.align	3
.LC2433:
	.string	"constant.GIT_SORT_REVERSE="
	.align	3
.LC2434:
	.string	"constant_size.GIT_SORT_REVERSE=%zu\n"
	.align	3
.LC2435:
	.string	"constant_signed.GIT_SORT_REVERSE=%d\n"
	.align	3
.LC2436:
	.string	"enum_expression_size.GIT_SORT_TIME=%zu\n"
	.align	3
.LC2437:
	.string	"enum_expression_signed.GIT_SORT_TIME=%d\n"
	.align	3
.LC2438:
	.string	"constant.GIT_SORT_TIME="
	.align	3
.LC2439:
	.string	"constant_size.GIT_SORT_TIME=%zu\n"
	.align	3
.LC2440:
	.string	"constant_signed.GIT_SORT_TIME=%d\n"
	.align	3
.LC2441:
	.string	"enum_expression_size.GIT_SORT_TOPOLOGICAL=%zu\n"
	.align	3
.LC2442:
	.string	"enum_expression_signed.GIT_SORT_TOPOLOGICAL=%d\n"
	.align	3
.LC2443:
	.string	"constant.GIT_SORT_TOPOLOGICAL="
	.align	3
.LC2444:
	.string	"constant_size.GIT_SORT_TOPOLOGICAL=%zu\n"
	.align	3
.LC2445:
	.string	"constant_signed.GIT_SORT_TOPOLOGICAL=%d\n"
	.align	3
.LC2446:
	.string	"enum_expression_size.GIT_STASH_APPLY_DEFAULT=%zu\n"
	.align	3
.LC2447:
	.string	"enum_expression_signed.GIT_STASH_APPLY_DEFAULT=%d\n"
	.align	3
.LC2448:
	.string	"constant.GIT_STASH_APPLY_DEFAULT="
	.align	3
.LC2449:
	.string	"constant_size.GIT_STASH_APPLY_DEFAULT=%zu\n"
	.align	3
.LC2450:
	.string	"constant_signed.GIT_STASH_APPLY_DEFAULT=%d\n"
	.align	3
.LC2451:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_ANALYZE_INDEX=%zu\n"
	.align	3
.LC2452:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_ANALYZE_INDEX=%d\n"
	.align	3
.LC2453:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_ANALYZE_INDEX="
	.align	3
.LC2454:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_ANALYZE_INDEX=%zu\n"
	.align	3
.LC2455:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_ANALYZE_INDEX=%d\n"
	.align	3
.LC2456:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_ANALYZE_MODIFIED=%zu\n"
	.align	3
.LC2457:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_ANALYZE_MODIFIED=%d\n"
	.align	3
.LC2458:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_ANALYZE_MODIFIED="
	.align	3
.LC2459:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_ANALYZE_MODIFIED=%zu\n"
	.align	3
.LC2460:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_ANALYZE_MODIFIED=%d\n"
	.align	3
.LC2461:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_ANALYZE_UNTRACKED=%zu\n"
	.align	3
.LC2462:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_ANALYZE_UNTRACKED=%d\n"
	.align	3
.LC2463:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_ANALYZE_UNTRACKED="
	.align	3
.LC2464:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_ANALYZE_UNTRACKED=%zu\n"
	.align	3
.LC2465:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_ANALYZE_UNTRACKED=%d\n"
	.align	3
.LC2466:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_CHECKOUT_MODIFIED=%zu\n"
	.align	3
.LC2467:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_CHECKOUT_MODIFIED=%d\n"
	.align	3
.LC2468:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_CHECKOUT_MODIFIED="
	.align	3
.LC2469:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_CHECKOUT_MODIFIED=%zu\n"
	.align	3
.LC2470:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_CHECKOUT_MODIFIED=%d\n"
	.align	3
.LC2471:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_CHECKOUT_UNTRACKED=%zu\n"
	.align	3
.LC2472:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_CHECKOUT_UNTRACKED=%d\n"
	.align	3
.LC2473:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_CHECKOUT_UNTRACKED="
	.align	3
.LC2474:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_CHECKOUT_UNTRACKED=%zu\n"
	.align	3
.LC2475:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_CHECKOUT_UNTRACKED=%d\n"
	.align	3
.LC2476:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_DONE=%zu\n"
	.align	3
.LC2477:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_DONE=%d\n"
	.align	3
.LC2478:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_DONE="
	.align	3
.LC2479:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_DONE=%zu\n"
	.align	3
.LC2480:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_DONE=%d\n"
	.align	3
.LC2481:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_LOADING_STASH=%zu\n"
	.align	3
.LC2482:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_LOADING_STASH=%d\n"
	.align	3
.LC2483:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_LOADING_STASH="
	.align	3
.LC2484:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_LOADING_STASH=%zu\n"
	.align	3
.LC2485:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_LOADING_STASH=%d\n"
	.align	3
.LC2486:
	.string	"enum_expression_size.GIT_STASH_APPLY_PROGRESS_NONE=%zu\n"
	.align	3
.LC2487:
	.string	"enum_expression_signed.GIT_STASH_APPLY_PROGRESS_NONE=%d\n"
	.align	3
.LC2488:
	.string	"constant.GIT_STASH_APPLY_PROGRESS_NONE="
	.align	3
.LC2489:
	.string	"constant_size.GIT_STASH_APPLY_PROGRESS_NONE=%zu\n"
	.align	3
.LC2490:
	.string	"constant_signed.GIT_STASH_APPLY_PROGRESS_NONE=%d\n"
	.align	3
.LC2491:
	.string	"enum_expression_size.GIT_STASH_APPLY_REINSTATE_INDEX=%zu\n"
	.align	3
.LC2492:
	.string	"enum_expression_signed.GIT_STASH_APPLY_REINSTATE_INDEX=%d\n"
	.align	3
.LC2493:
	.string	"constant.GIT_STASH_APPLY_REINSTATE_INDEX="
	.align	3
.LC2494:
	.string	"constant_size.GIT_STASH_APPLY_REINSTATE_INDEX=%zu\n"
	.align	3
.LC2495:
	.string	"constant_signed.GIT_STASH_APPLY_REINSTATE_INDEX=%d\n"
	.align	3
.LC2496:
	.string	"enum_expression_size.GIT_STASH_DEFAULT=%zu\n"
	.align	3
.LC2497:
	.string	"enum_expression_signed.GIT_STASH_DEFAULT=%d\n"
	.align	3
.LC2498:
	.string	"constant.GIT_STASH_DEFAULT="
	.align	3
.LC2499:
	.string	"constant_size.GIT_STASH_DEFAULT=%zu\n"
	.align	3
.LC2500:
	.string	"constant_signed.GIT_STASH_DEFAULT=%d\n"
	.align	3
.LC2501:
	.string	"enum_expression_size.GIT_STASH_INCLUDE_IGNORED=%zu\n"
	.align	3
.LC2502:
	.string	"enum_expression_signed.GIT_STASH_INCLUDE_IGNORED=%d\n"
	.align	3
.LC2503:
	.string	"constant.GIT_STASH_INCLUDE_IGNORED="
	.align	3
.LC2504:
	.string	"constant_size.GIT_STASH_INCLUDE_IGNORED=%zu\n"
	.align	3
.LC2505:
	.string	"constant_signed.GIT_STASH_INCLUDE_IGNORED=%d\n"
	.align	3
.LC2506:
	.string	"enum_expression_size.GIT_STASH_INCLUDE_UNTRACKED=%zu\n"
	.align	3
.LC2507:
	.string	"enum_expression_signed.GIT_STASH_INCLUDE_UNTRACKED=%d\n"
	.align	3
.LC2508:
	.string	"constant.GIT_STASH_INCLUDE_UNTRACKED="
	.align	3
.LC2509:
	.string	"constant_size.GIT_STASH_INCLUDE_UNTRACKED=%zu\n"
	.align	3
.LC2510:
	.string	"constant_signed.GIT_STASH_INCLUDE_UNTRACKED=%d\n"
	.align	3
.LC2511:
	.string	"enum_expression_size.GIT_STASH_KEEP_ALL=%zu\n"
	.align	3
.LC2512:
	.string	"enum_expression_signed.GIT_STASH_KEEP_ALL=%d\n"
	.align	3
.LC2513:
	.string	"constant.GIT_STASH_KEEP_ALL="
	.align	3
.LC2514:
	.string	"constant_size.GIT_STASH_KEEP_ALL=%zu\n"
	.align	3
.LC2515:
	.string	"constant_signed.GIT_STASH_KEEP_ALL=%d\n"
	.align	3
.LC2516:
	.string	"enum_expression_size.GIT_STASH_KEEP_INDEX=%zu\n"
	.align	3
.LC2517:
	.string	"enum_expression_signed.GIT_STASH_KEEP_INDEX=%d\n"
	.align	3
.LC2518:
	.string	"constant.GIT_STASH_KEEP_INDEX="
	.align	3
.LC2519:
	.string	"constant_size.GIT_STASH_KEEP_INDEX=%zu\n"
	.align	3
.LC2520:
	.string	"constant_signed.GIT_STASH_KEEP_INDEX=%d\n"
	.align	3
.LC2521:
	.string	"enum_expression_size.GIT_STATUS_CONFLICTED=%zu\n"
	.align	3
.LC2522:
	.string	"enum_expression_signed.GIT_STATUS_CONFLICTED=%d\n"
	.align	3
.LC2523:
	.string	"constant.GIT_STATUS_CONFLICTED="
	.align	3
.LC2524:
	.string	"constant_size.GIT_STATUS_CONFLICTED=%zu\n"
	.align	3
.LC2525:
	.string	"constant_signed.GIT_STATUS_CONFLICTED=%d\n"
	.align	3
.LC2526:
	.string	"enum_expression_size.GIT_STATUS_CURRENT=%zu\n"
	.align	3
.LC2527:
	.string	"enum_expression_signed.GIT_STATUS_CURRENT=%d\n"
	.align	3
.LC2528:
	.string	"constant.GIT_STATUS_CURRENT="
	.align	3
.LC2529:
	.string	"constant_size.GIT_STATUS_CURRENT=%zu\n"
	.align	3
.LC2530:
	.string	"constant_signed.GIT_STATUS_CURRENT=%d\n"
	.align	3
.LC2531:
	.string	"enum_expression_size.GIT_STATUS_IGNORED=%zu\n"
	.align	3
.LC2532:
	.string	"enum_expression_signed.GIT_STATUS_IGNORED=%d\n"
	.align	3
.LC2533:
	.string	"constant.GIT_STATUS_IGNORED="
	.align	3
.LC2534:
	.string	"constant_size.GIT_STATUS_IGNORED=%zu\n"
	.align	3
.LC2535:
	.string	"constant_signed.GIT_STATUS_IGNORED=%d\n"
	.align	3
.LC2536:
	.string	"enum_expression_size.GIT_STATUS_INDEX_DELETED=%zu\n"
	.align	3
.LC2537:
	.string	"enum_expression_signed.GIT_STATUS_INDEX_DELETED=%d\n"
	.align	3
.LC2538:
	.string	"constant.GIT_STATUS_INDEX_DELETED="
	.align	3
.LC2539:
	.string	"constant_size.GIT_STATUS_INDEX_DELETED=%zu\n"
	.align	3
.LC2540:
	.string	"constant_signed.GIT_STATUS_INDEX_DELETED=%d\n"
	.align	3
.LC2541:
	.string	"enum_expression_size.GIT_STATUS_INDEX_MODIFIED=%zu\n"
	.align	3
.LC2542:
	.string	"enum_expression_signed.GIT_STATUS_INDEX_MODIFIED=%d\n"
	.align	3
.LC2543:
	.string	"constant.GIT_STATUS_INDEX_MODIFIED="
	.align	3
.LC2544:
	.string	"constant_size.GIT_STATUS_INDEX_MODIFIED=%zu\n"
	.align	3
.LC2545:
	.string	"constant_signed.GIT_STATUS_INDEX_MODIFIED=%d\n"
	.align	3
.LC2546:
	.string	"enum_expression_size.GIT_STATUS_INDEX_NEW=%zu\n"
	.align	3
.LC2547:
	.string	"enum_expression_signed.GIT_STATUS_INDEX_NEW=%d\n"
	.align	3
.LC2548:
	.string	"constant.GIT_STATUS_INDEX_NEW="
	.align	3
.LC2549:
	.string	"constant_size.GIT_STATUS_INDEX_NEW=%zu\n"
	.align	3
.LC2550:
	.string	"constant_signed.GIT_STATUS_INDEX_NEW=%d\n"
	.align	3
.LC2551:
	.string	"enum_expression_size.GIT_STATUS_INDEX_RENAMED=%zu\n"
	.align	3
.LC2552:
	.string	"enum_expression_signed.GIT_STATUS_INDEX_RENAMED=%d\n"
	.align	3
.LC2553:
	.string	"constant.GIT_STATUS_INDEX_RENAMED="
	.align	3
.LC2554:
	.string	"constant_size.GIT_STATUS_INDEX_RENAMED=%zu\n"
	.align	3
.LC2555:
	.string	"constant_signed.GIT_STATUS_INDEX_RENAMED=%d\n"
	.align	3
.LC2556:
	.string	"enum_expression_size.GIT_STATUS_INDEX_TYPECHANGE=%zu\n"
	.align	3
.LC2557:
	.string	"enum_expression_signed.GIT_STATUS_INDEX_TYPECHANGE=%d\n"
	.align	3
.LC2558:
	.string	"constant.GIT_STATUS_INDEX_TYPECHANGE="
	.align	3
.LC2559:
	.string	"constant_size.GIT_STATUS_INDEX_TYPECHANGE=%zu\n"
	.align	3
.LC2560:
	.string	"constant_signed.GIT_STATUS_INDEX_TYPECHANGE=%d\n"
	.align	3
.LC2561:
	.string	"enum_expression_size.GIT_STATUS_OPT_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC2562:
	.string	"enum_expression_signed.GIT_STATUS_OPT_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC2563:
	.string	"constant.GIT_STATUS_OPT_DISABLE_PATHSPEC_MATCH="
	.align	3
.LC2564:
	.string	"constant_size.GIT_STATUS_OPT_DISABLE_PATHSPEC_MATCH=%zu\n"
	.align	3
.LC2565:
	.string	"constant_signed.GIT_STATUS_OPT_DISABLE_PATHSPEC_MATCH=%d\n"
	.align	3
.LC2566:
	.string	"enum_expression_size.GIT_STATUS_OPT_EXCLUDE_SUBMODULES=%zu\n"
	.align	3
.LC2567:
	.string	"enum_expression_signed.GIT_STATUS_OPT_EXCLUDE_SUBMODULES=%d\n"
	.align	3
.LC2568:
	.string	"constant.GIT_STATUS_OPT_EXCLUDE_SUBMODULES="
	.align	3
.LC2569:
	.string	"constant_size.GIT_STATUS_OPT_EXCLUDE_SUBMODULES=%zu\n"
	.align	3
.LC2570:
	.string	"constant_signed.GIT_STATUS_OPT_EXCLUDE_SUBMODULES=%d\n"
	.align	3
.LC2571:
	.string	"enum_expression_size.GIT_STATUS_OPT_INCLUDE_IGNORED=%zu\n"
	.align	3
.LC2572:
	.string	"enum_expression_signed.GIT_STATUS_OPT_INCLUDE_IGNORED=%d\n"
	.align	3
.LC2573:
	.string	"constant.GIT_STATUS_OPT_INCLUDE_IGNORED="
	.align	3
.LC2574:
	.string	"constant_size.GIT_STATUS_OPT_INCLUDE_IGNORED=%zu\n"
	.align	3
.LC2575:
	.string	"constant_signed.GIT_STATUS_OPT_INCLUDE_IGNORED=%d\n"
	.align	3
.LC2576:
	.string	"enum_expression_size.GIT_STATUS_OPT_INCLUDE_UNMODIFIED=%zu\n"
	.align	3
.LC2577:
	.string	"enum_expression_signed.GIT_STATUS_OPT_INCLUDE_UNMODIFIED=%d\n"
	.align	3
.LC2578:
	.string	"constant.GIT_STATUS_OPT_INCLUDE_UNMODIFIED="
	.align	3
.LC2579:
	.string	"constant_size.GIT_STATUS_OPT_INCLUDE_UNMODIFIED=%zu\n"
	.align	3
.LC2580:
	.string	"constant_signed.GIT_STATUS_OPT_INCLUDE_UNMODIFIED=%d\n"
	.align	3
.LC2581:
	.string	"enum_expression_size.GIT_STATUS_OPT_INCLUDE_UNREADABLE=%zu\n"
	.align	3
.LC2582:
	.string	"enum_expression_signed.GIT_STATUS_OPT_INCLUDE_UNREADABLE=%d\n"
	.align	3
.LC2583:
	.string	"constant.GIT_STATUS_OPT_INCLUDE_UNREADABLE="
	.align	3
.LC2584:
	.string	"constant_size.GIT_STATUS_OPT_INCLUDE_UNREADABLE=%zu\n"
	.align	3
.LC2585:
	.string	"constant_signed.GIT_STATUS_OPT_INCLUDE_UNREADABLE=%d\n"
	.align	3
.LC2586:
	.string	"enum_expression_size.GIT_STATUS_OPT_INCLUDE_UNREADABLE_AS_UNTRACKED=%zu\n"
	.align	3
.LC2587:
	.string	"enum_expression_signed.GIT_STATUS_OPT_INCLUDE_UNREADABLE_AS_UNTRACKED=%d\n"
	.align	3
.LC2588:
	.string	"constant.GIT_STATUS_OPT_INCLUDE_UNREADABLE_AS_UNTRACKED="
	.align	3
.LC2589:
	.string	"constant_size.GIT_STATUS_OPT_INCLUDE_UNREADABLE_AS_UNTRACKED=%zu\n"
	.align	3
.LC2590:
	.string	"constant_signed.GIT_STATUS_OPT_INCLUDE_UNREADABLE_AS_UNTRACKED=%d\n"
	.align	3
.LC2591:
	.string	"enum_expression_size.GIT_STATUS_OPT_INCLUDE_UNTRACKED=%zu\n"
	.align	3
.LC2592:
	.string	"enum_expression_signed.GIT_STATUS_OPT_INCLUDE_UNTRACKED=%d\n"
	.align	3
.LC2593:
	.string	"constant.GIT_STATUS_OPT_INCLUDE_UNTRACKED="
	.align	3
.LC2594:
	.string	"constant_size.GIT_STATUS_OPT_INCLUDE_UNTRACKED=%zu\n"
	.align	3
.LC2595:
	.string	"constant_signed.GIT_STATUS_OPT_INCLUDE_UNTRACKED=%d\n"
	.align	3
.LC2596:
	.string	"enum_expression_size.GIT_STATUS_OPT_NO_REFRESH=%zu\n"
	.align	3
.LC2597:
	.string	"enum_expression_signed.GIT_STATUS_OPT_NO_REFRESH=%d\n"
	.align	3
.LC2598:
	.string	"constant.GIT_STATUS_OPT_NO_REFRESH="
	.align	3
.LC2599:
	.string	"constant_size.GIT_STATUS_OPT_NO_REFRESH=%zu\n"
	.align	3
.LC2600:
	.string	"constant_signed.GIT_STATUS_OPT_NO_REFRESH=%d\n"
	.align	3
.LC2601:
	.string	"enum_expression_size.GIT_STATUS_OPT_RECURSE_IGNORED_DIRS=%zu\n"
	.align	3
.LC2602:
	.string	"enum_expression_signed.GIT_STATUS_OPT_RECURSE_IGNORED_DIRS=%d\n"
	.align	3
.LC2603:
	.string	"constant.GIT_STATUS_OPT_RECURSE_IGNORED_DIRS="
	.align	3
.LC2604:
	.string	"constant_size.GIT_STATUS_OPT_RECURSE_IGNORED_DIRS=%zu\n"
	.align	3
.LC2605:
	.string	"constant_signed.GIT_STATUS_OPT_RECURSE_IGNORED_DIRS=%d\n"
	.align	3
.LC2606:
	.string	"enum_expression_size.GIT_STATUS_OPT_RECURSE_UNTRACKED_DIRS=%zu\n"
	.align	3
.LC2607:
	.string	"enum_expression_signed.GIT_STATUS_OPT_RECURSE_UNTRACKED_DIRS=%d\n"
	.align	3
.LC2608:
	.string	"constant.GIT_STATUS_OPT_RECURSE_UNTRACKED_DIRS="
	.align	3
.LC2609:
	.string	"constant_size.GIT_STATUS_OPT_RECURSE_UNTRACKED_DIRS=%zu\n"
	.align	3
.LC2610:
	.string	"constant_signed.GIT_STATUS_OPT_RECURSE_UNTRACKED_DIRS=%d\n"
	.align	3
.LC2611:
	.string	"enum_expression_size.GIT_STATUS_OPT_RENAMES_FROM_REWRITES=%zu\n"
	.align	3
.LC2612:
	.string	"enum_expression_signed.GIT_STATUS_OPT_RENAMES_FROM_REWRITES=%d\n"
	.align	3
.LC2613:
	.string	"constant.GIT_STATUS_OPT_RENAMES_FROM_REWRITES="
	.align	3
.LC2614:
	.string	"constant_size.GIT_STATUS_OPT_RENAMES_FROM_REWRITES=%zu\n"
	.align	3
.LC2615:
	.string	"constant_signed.GIT_STATUS_OPT_RENAMES_FROM_REWRITES=%d\n"
	.align	3
.LC2616:
	.string	"enum_expression_size.GIT_STATUS_OPT_RENAMES_HEAD_TO_INDEX=%zu\n"
	.align	3
.LC2617:
	.string	"enum_expression_signed.GIT_STATUS_OPT_RENAMES_HEAD_TO_INDEX=%d\n"
	.align	3
.LC2618:
	.string	"constant.GIT_STATUS_OPT_RENAMES_HEAD_TO_INDEX="
	.align	3
.LC2619:
	.string	"constant_size.GIT_STATUS_OPT_RENAMES_HEAD_TO_INDEX=%zu\n"
	.align	3
.LC2620:
	.string	"constant_signed.GIT_STATUS_OPT_RENAMES_HEAD_TO_INDEX=%d\n"
	.align	3
.LC2621:
	.string	"enum_expression_size.GIT_STATUS_OPT_RENAMES_INDEX_TO_WORKDIR=%zu\n"
	.align	3
.LC2622:
	.string	"enum_expression_signed.GIT_STATUS_OPT_RENAMES_INDEX_TO_WORKDIR=%d\n"
	.align	3
.LC2623:
	.string	"constant.GIT_STATUS_OPT_RENAMES_INDEX_TO_WORKDIR="
	.align	3
.LC2624:
	.string	"constant_size.GIT_STATUS_OPT_RENAMES_INDEX_TO_WORKDIR=%zu\n"
	.align	3
.LC2625:
	.string	"constant_signed.GIT_STATUS_OPT_RENAMES_INDEX_TO_WORKDIR=%d\n"
	.align	3
.LC2626:
	.string	"enum_expression_size.GIT_STATUS_OPT_SORT_CASE_INSENSITIVELY=%zu\n"
	.align	3
.LC2627:
	.string	"enum_expression_signed.GIT_STATUS_OPT_SORT_CASE_INSENSITIVELY=%d\n"
	.align	3
.LC2628:
	.string	"constant.GIT_STATUS_OPT_SORT_CASE_INSENSITIVELY="
	.align	3
.LC2629:
	.string	"constant_size.GIT_STATUS_OPT_SORT_CASE_INSENSITIVELY=%zu\n"
	.align	3
.LC2630:
	.string	"constant_signed.GIT_STATUS_OPT_SORT_CASE_INSENSITIVELY=%d\n"
	.align	3
.LC2631:
	.string	"enum_expression_size.GIT_STATUS_OPT_SORT_CASE_SENSITIVELY=%zu\n"
	.align	3
.LC2632:
	.string	"enum_expression_signed.GIT_STATUS_OPT_SORT_CASE_SENSITIVELY=%d\n"
	.align	3
.LC2633:
	.string	"constant.GIT_STATUS_OPT_SORT_CASE_SENSITIVELY="
	.align	3
.LC2634:
	.string	"constant_size.GIT_STATUS_OPT_SORT_CASE_SENSITIVELY=%zu\n"
	.align	3
.LC2635:
	.string	"constant_signed.GIT_STATUS_OPT_SORT_CASE_SENSITIVELY=%d\n"
	.align	3
.LC2636:
	.string	"enum_expression_size.GIT_STATUS_OPT_UPDATE_INDEX=%zu\n"
	.align	3
.LC2637:
	.string	"enum_expression_signed.GIT_STATUS_OPT_UPDATE_INDEX=%d\n"
	.align	3
.LC2638:
	.string	"constant.GIT_STATUS_OPT_UPDATE_INDEX="
	.align	3
.LC2639:
	.string	"constant_size.GIT_STATUS_OPT_UPDATE_INDEX=%zu\n"
	.align	3
.LC2640:
	.string	"constant_signed.GIT_STATUS_OPT_UPDATE_INDEX=%d\n"
	.align	3
.LC2641:
	.string	"enum_expression_size.GIT_STATUS_SHOW_INDEX_AND_WORKDIR=%zu\n"
	.align	3
.LC2642:
	.string	"enum_expression_signed.GIT_STATUS_SHOW_INDEX_AND_WORKDIR=%d\n"
	.align	3
.LC2643:
	.string	"constant.GIT_STATUS_SHOW_INDEX_AND_WORKDIR="
	.align	3
.LC2644:
	.string	"constant_size.GIT_STATUS_SHOW_INDEX_AND_WORKDIR=%zu\n"
	.align	3
.LC2645:
	.string	"constant_signed.GIT_STATUS_SHOW_INDEX_AND_WORKDIR=%d\n"
	.align	3
.LC2646:
	.string	"enum_expression_size.GIT_STATUS_SHOW_INDEX_ONLY=%zu\n"
	.align	3
.LC2647:
	.string	"enum_expression_signed.GIT_STATUS_SHOW_INDEX_ONLY=%d\n"
	.align	3
.LC2648:
	.string	"constant.GIT_STATUS_SHOW_INDEX_ONLY="
	.align	3
.LC2649:
	.string	"constant_size.GIT_STATUS_SHOW_INDEX_ONLY=%zu\n"
	.align	3
.LC2650:
	.string	"constant_signed.GIT_STATUS_SHOW_INDEX_ONLY=%d\n"
	.align	3
.LC2651:
	.string	"enum_expression_size.GIT_STATUS_SHOW_WORKDIR_ONLY=%zu\n"
	.align	3
.LC2652:
	.string	"enum_expression_signed.GIT_STATUS_SHOW_WORKDIR_ONLY=%d\n"
	.align	3
.LC2653:
	.string	"constant.GIT_STATUS_SHOW_WORKDIR_ONLY="
	.align	3
.LC2654:
	.string	"constant_size.GIT_STATUS_SHOW_WORKDIR_ONLY=%zu\n"
	.align	3
.LC2655:
	.string	"constant_signed.GIT_STATUS_SHOW_WORKDIR_ONLY=%d\n"
	.align	3
.LC2656:
	.string	"enum_expression_size.GIT_STATUS_WT_DELETED=%zu\n"
	.align	3
.LC2657:
	.string	"enum_expression_signed.GIT_STATUS_WT_DELETED=%d\n"
	.align	3
.LC2658:
	.string	"constant.GIT_STATUS_WT_DELETED="
	.align	3
.LC2659:
	.string	"constant_size.GIT_STATUS_WT_DELETED=%zu\n"
	.align	3
.LC2660:
	.string	"constant_signed.GIT_STATUS_WT_DELETED=%d\n"
	.align	3
.LC2661:
	.string	"enum_expression_size.GIT_STATUS_WT_MODIFIED=%zu\n"
	.align	3
.LC2662:
	.string	"enum_expression_signed.GIT_STATUS_WT_MODIFIED=%d\n"
	.align	3
.LC2663:
	.string	"constant.GIT_STATUS_WT_MODIFIED="
	.align	3
.LC2664:
	.string	"constant_size.GIT_STATUS_WT_MODIFIED=%zu\n"
	.align	3
.LC2665:
	.string	"constant_signed.GIT_STATUS_WT_MODIFIED=%d\n"
	.align	3
.LC2666:
	.string	"enum_expression_size.GIT_STATUS_WT_NEW=%zu\n"
	.align	3
.LC2667:
	.string	"enum_expression_signed.GIT_STATUS_WT_NEW=%d\n"
	.align	3
.LC2668:
	.string	"constant.GIT_STATUS_WT_NEW="
	.align	3
.LC2669:
	.string	"constant_size.GIT_STATUS_WT_NEW=%zu\n"
	.align	3
.LC2670:
	.string	"constant_signed.GIT_STATUS_WT_NEW=%d\n"
	.align	3
.LC2671:
	.string	"enum_expression_size.GIT_STATUS_WT_RENAMED=%zu\n"
	.align	3
.LC2672:
	.string	"enum_expression_signed.GIT_STATUS_WT_RENAMED=%d\n"
	.align	3
.LC2673:
	.string	"constant.GIT_STATUS_WT_RENAMED="
	.align	3
.LC2674:
	.string	"constant_size.GIT_STATUS_WT_RENAMED=%zu\n"
	.align	3
.LC2675:
	.string	"constant_signed.GIT_STATUS_WT_RENAMED=%d\n"
	.align	3
.LC2676:
	.string	"enum_expression_size.GIT_STATUS_WT_TYPECHANGE=%zu\n"
	.align	3
.LC2677:
	.string	"enum_expression_signed.GIT_STATUS_WT_TYPECHANGE=%d\n"
	.align	3
.LC2678:
	.string	"constant.GIT_STATUS_WT_TYPECHANGE="
	.align	3
.LC2679:
	.string	"constant_size.GIT_STATUS_WT_TYPECHANGE=%zu\n"
	.align	3
.LC2680:
	.string	"constant_signed.GIT_STATUS_WT_TYPECHANGE=%d\n"
	.align	3
.LC2681:
	.string	"enum_expression_size.GIT_STATUS_WT_UNREADABLE=%zu\n"
	.align	3
.LC2682:
	.string	"enum_expression_signed.GIT_STATUS_WT_UNREADABLE=%d\n"
	.align	3
.LC2683:
	.string	"constant.GIT_STATUS_WT_UNREADABLE="
	.align	3
.LC2684:
	.string	"constant_size.GIT_STATUS_WT_UNREADABLE=%zu\n"
	.align	3
.LC2685:
	.string	"constant_signed.GIT_STATUS_WT_UNREADABLE=%d\n"
	.align	3
.LC2686:
	.string	"enum_expression_size.GIT_STREAM_RDONLY=%zu\n"
	.align	3
.LC2687:
	.string	"enum_expression_signed.GIT_STREAM_RDONLY=%d\n"
	.align	3
.LC2688:
	.string	"constant.GIT_STREAM_RDONLY="
	.align	3
.LC2689:
	.string	"constant_size.GIT_STREAM_RDONLY=%zu\n"
	.align	3
.LC2690:
	.string	"constant_signed.GIT_STREAM_RDONLY=%d\n"
	.align	3
.LC2691:
	.string	"enum_expression_size.GIT_STREAM_RW=%zu\n"
	.align	3
.LC2692:
	.string	"enum_expression_signed.GIT_STREAM_RW=%d\n"
	.align	3
.LC2693:
	.string	"constant.GIT_STREAM_RW="
	.align	3
.LC2694:
	.string	"constant_size.GIT_STREAM_RW=%zu\n"
	.align	3
.LC2695:
	.string	"constant_signed.GIT_STREAM_RW=%d\n"
	.align	3
.LC2696:
	.string	"enum_expression_size.GIT_STREAM_WRONLY=%zu\n"
	.align	3
.LC2697:
	.string	"enum_expression_signed.GIT_STREAM_WRONLY=%d\n"
	.align	3
.LC2698:
	.string	"constant.GIT_STREAM_WRONLY="
	.align	3
.LC2699:
	.string	"constant_size.GIT_STREAM_WRONLY=%zu\n"
	.align	3
.LC2700:
	.string	"constant_signed.GIT_STREAM_WRONLY=%d\n"
	.align	3
.LC2701:
	.string	"enum_expression_size.GIT_SUBMODULE_IGNORE_ALL=%zu\n"
	.align	3
.LC2702:
	.string	"enum_expression_signed.GIT_SUBMODULE_IGNORE_ALL=%d\n"
	.align	3
.LC2703:
	.string	"constant.GIT_SUBMODULE_IGNORE_ALL="
	.align	3
.LC2704:
	.string	"constant_size.GIT_SUBMODULE_IGNORE_ALL=%zu\n"
	.align	3
.LC2705:
	.string	"constant_signed.GIT_SUBMODULE_IGNORE_ALL=%d\n"
	.align	3
.LC2706:
	.string	"enum_expression_size.GIT_SUBMODULE_IGNORE_DIRTY=%zu\n"
	.align	3
.LC2707:
	.string	"enum_expression_signed.GIT_SUBMODULE_IGNORE_DIRTY=%d\n"
	.align	3
.LC2708:
	.string	"constant.GIT_SUBMODULE_IGNORE_DIRTY="
	.align	3
.LC2709:
	.string	"constant_size.GIT_SUBMODULE_IGNORE_DIRTY=%zu\n"
	.align	3
.LC2710:
	.string	"constant_signed.GIT_SUBMODULE_IGNORE_DIRTY=%d\n"
	.align	3
.LC2711:
	.string	"enum_expression_size.GIT_SUBMODULE_IGNORE_NONE=%zu\n"
	.align	3
.LC2712:
	.string	"enum_expression_signed.GIT_SUBMODULE_IGNORE_NONE=%d\n"
	.align	3
.LC2713:
	.string	"constant.GIT_SUBMODULE_IGNORE_NONE="
	.align	3
.LC2714:
	.string	"constant_size.GIT_SUBMODULE_IGNORE_NONE=%zu\n"
	.align	3
.LC2715:
	.string	"constant_signed.GIT_SUBMODULE_IGNORE_NONE=%d\n"
	.align	3
.LC2716:
	.string	"enum_expression_size.GIT_SUBMODULE_IGNORE_UNSPECIFIED=%zu\n"
	.align	3
.LC2717:
	.string	"enum_expression_signed.GIT_SUBMODULE_IGNORE_UNSPECIFIED=%d\n"
	.align	3
.LC2718:
	.string	"constant.GIT_SUBMODULE_IGNORE_UNSPECIFIED="
	.align	3
.LC2719:
	.string	"constant_size.GIT_SUBMODULE_IGNORE_UNSPECIFIED=%zu\n"
	.align	3
.LC2720:
	.string	"constant_signed.GIT_SUBMODULE_IGNORE_UNSPECIFIED=%d\n"
	.align	3
.LC2721:
	.string	"enum_expression_size.GIT_SUBMODULE_IGNORE_UNTRACKED=%zu\n"
	.align	3
.LC2722:
	.string	"enum_expression_signed.GIT_SUBMODULE_IGNORE_UNTRACKED=%d\n"
	.align	3
.LC2723:
	.string	"constant.GIT_SUBMODULE_IGNORE_UNTRACKED="
	.align	3
.LC2724:
	.string	"constant_size.GIT_SUBMODULE_IGNORE_UNTRACKED=%zu\n"
	.align	3
.LC2725:
	.string	"constant_signed.GIT_SUBMODULE_IGNORE_UNTRACKED=%d\n"
	.align	3
.LC2726:
	.string	"enum_expression_size.GIT_SUBMODULE_RECURSE_NO=%zu\n"
	.align	3
.LC2727:
	.string	"enum_expression_signed.GIT_SUBMODULE_RECURSE_NO=%d\n"
	.align	3
.LC2728:
	.string	"constant.GIT_SUBMODULE_RECURSE_NO="
	.align	3
.LC2729:
	.string	"constant_size.GIT_SUBMODULE_RECURSE_NO=%zu\n"
	.align	3
.LC2730:
	.string	"constant_signed.GIT_SUBMODULE_RECURSE_NO=%d\n"
	.align	3
.LC2731:
	.string	"enum_expression_size.GIT_SUBMODULE_RECURSE_ONDEMAND=%zu\n"
	.align	3
.LC2732:
	.string	"enum_expression_signed.GIT_SUBMODULE_RECURSE_ONDEMAND=%d\n"
	.align	3
.LC2733:
	.string	"constant.GIT_SUBMODULE_RECURSE_ONDEMAND="
	.align	3
.LC2734:
	.string	"constant_size.GIT_SUBMODULE_RECURSE_ONDEMAND=%zu\n"
	.align	3
.LC2735:
	.string	"constant_signed.GIT_SUBMODULE_RECURSE_ONDEMAND=%d\n"
	.align	3
.LC2736:
	.string	"enum_expression_size.GIT_SUBMODULE_RECURSE_YES=%zu\n"
	.align	3
.LC2737:
	.string	"enum_expression_signed.GIT_SUBMODULE_RECURSE_YES=%d\n"
	.align	3
.LC2738:
	.string	"constant.GIT_SUBMODULE_RECURSE_YES="
	.align	3
.LC2739:
	.string	"constant_size.GIT_SUBMODULE_RECURSE_YES=%zu\n"
	.align	3
.LC2740:
	.string	"constant_signed.GIT_SUBMODULE_RECURSE_YES=%d\n"
	.align	3
.LC2741:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_INDEX_ADDED=%zu\n"
	.align	3
.LC2742:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_INDEX_ADDED=%d\n"
	.align	3
.LC2743:
	.string	"constant.GIT_SUBMODULE_STATUS_INDEX_ADDED="
	.align	3
.LC2744:
	.string	"constant_size.GIT_SUBMODULE_STATUS_INDEX_ADDED=%zu\n"
	.align	3
.LC2745:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_INDEX_ADDED=%d\n"
	.align	3
.LC2746:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_INDEX_DELETED=%zu\n"
	.align	3
.LC2747:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_INDEX_DELETED=%d\n"
	.align	3
.LC2748:
	.string	"constant.GIT_SUBMODULE_STATUS_INDEX_DELETED="
	.align	3
.LC2749:
	.string	"constant_size.GIT_SUBMODULE_STATUS_INDEX_DELETED=%zu\n"
	.align	3
.LC2750:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_INDEX_DELETED=%d\n"
	.align	3
.LC2751:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_INDEX_MODIFIED=%zu\n"
	.align	3
.LC2752:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_INDEX_MODIFIED=%d\n"
	.align	3
.LC2753:
	.string	"constant.GIT_SUBMODULE_STATUS_INDEX_MODIFIED="
	.align	3
.LC2754:
	.string	"constant_size.GIT_SUBMODULE_STATUS_INDEX_MODIFIED=%zu\n"
	.align	3
.LC2755:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_INDEX_MODIFIED=%d\n"
	.align	3
.LC2756:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_IN_CONFIG=%zu\n"
	.align	3
.LC2757:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_IN_CONFIG=%d\n"
	.align	3
.LC2758:
	.string	"constant.GIT_SUBMODULE_STATUS_IN_CONFIG="
	.align	3
.LC2759:
	.string	"constant_size.GIT_SUBMODULE_STATUS_IN_CONFIG=%zu\n"
	.align	3
.LC2760:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_IN_CONFIG=%d\n"
	.align	3
.LC2761:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_IN_HEAD=%zu\n"
	.align	3
.LC2762:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_IN_HEAD=%d\n"
	.align	3
.LC2763:
	.string	"constant.GIT_SUBMODULE_STATUS_IN_HEAD="
	.align	3
.LC2764:
	.string	"constant_size.GIT_SUBMODULE_STATUS_IN_HEAD=%zu\n"
	.align	3
.LC2765:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_IN_HEAD=%d\n"
	.align	3
.LC2766:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_IN_INDEX=%zu\n"
	.align	3
.LC2767:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_IN_INDEX=%d\n"
	.align	3
.LC2768:
	.string	"constant.GIT_SUBMODULE_STATUS_IN_INDEX="
	.align	3
.LC2769:
	.string	"constant_size.GIT_SUBMODULE_STATUS_IN_INDEX=%zu\n"
	.align	3
.LC2770:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_IN_INDEX=%d\n"
	.align	3
.LC2771:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_IN_WD=%zu\n"
	.align	3
.LC2772:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_IN_WD=%d\n"
	.align	3
.LC2773:
	.string	"constant.GIT_SUBMODULE_STATUS_IN_WD="
	.align	3
.LC2774:
	.string	"constant_size.GIT_SUBMODULE_STATUS_IN_WD=%zu\n"
	.align	3
.LC2775:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_IN_WD=%d\n"
	.align	3
.LC2776:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_ADDED=%zu\n"
	.align	3
.LC2777:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_ADDED=%d\n"
	.align	3
.LC2778:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_ADDED="
	.align	3
.LC2779:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_ADDED=%zu\n"
	.align	3
.LC2780:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_ADDED=%d\n"
	.align	3
.LC2781:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_DELETED=%zu\n"
	.align	3
.LC2782:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_DELETED=%d\n"
	.align	3
.LC2783:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_DELETED="
	.align	3
.LC2784:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_DELETED=%zu\n"
	.align	3
.LC2785:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_DELETED=%d\n"
	.align	3
.LC2786:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_INDEX_MODIFIED=%zu\n"
	.align	3
.LC2787:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_INDEX_MODIFIED=%d\n"
	.align	3
.LC2788:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_INDEX_MODIFIED="
	.align	3
.LC2789:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_INDEX_MODIFIED=%zu\n"
	.align	3
.LC2790:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_INDEX_MODIFIED=%d\n"
	.align	3
.LC2791:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_MODIFIED=%zu\n"
	.align	3
.LC2792:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_MODIFIED=%d\n"
	.align	3
.LC2793:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_MODIFIED="
	.align	3
.LC2794:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_MODIFIED=%zu\n"
	.align	3
.LC2795:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_MODIFIED=%d\n"
	.align	3
.LC2796:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_UNINITIALIZED=%zu\n"
	.align	3
.LC2797:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_UNINITIALIZED=%d\n"
	.align	3
.LC2798:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_UNINITIALIZED="
	.align	3
.LC2799:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_UNINITIALIZED=%zu\n"
	.align	3
.LC2800:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_UNINITIALIZED=%d\n"
	.align	3
.LC2801:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_UNTRACKED=%zu\n"
	.align	3
.LC2802:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_UNTRACKED=%d\n"
	.align	3
.LC2803:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_UNTRACKED="
	.align	3
.LC2804:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_UNTRACKED=%zu\n"
	.align	3
.LC2805:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_UNTRACKED=%d\n"
	.align	3
.LC2806:
	.string	"enum_expression_size.GIT_SUBMODULE_STATUS_WD_WD_MODIFIED=%zu\n"
	.align	3
.LC2807:
	.string	"enum_expression_signed.GIT_SUBMODULE_STATUS_WD_WD_MODIFIED=%d\n"
	.align	3
.LC2808:
	.string	"constant.GIT_SUBMODULE_STATUS_WD_WD_MODIFIED="
	.align	3
.LC2809:
	.string	"constant_size.GIT_SUBMODULE_STATUS_WD_WD_MODIFIED=%zu\n"
	.align	3
.LC2810:
	.string	"constant_signed.GIT_SUBMODULE_STATUS_WD_WD_MODIFIED=%d\n"
	.align	3
.LC2811:
	.string	"enum_expression_size.GIT_SUBMODULE_UPDATE_CHECKOUT=%zu\n"
	.align	3
.LC2812:
	.string	"enum_expression_signed.GIT_SUBMODULE_UPDATE_CHECKOUT=%d\n"
	.align	3
.LC2813:
	.string	"constant.GIT_SUBMODULE_UPDATE_CHECKOUT="
	.align	3
.LC2814:
	.string	"constant_size.GIT_SUBMODULE_UPDATE_CHECKOUT=%zu\n"
	.align	3
.LC2815:
	.string	"constant_signed.GIT_SUBMODULE_UPDATE_CHECKOUT=%d\n"
	.align	3
.LC2816:
	.string	"enum_expression_size.GIT_SUBMODULE_UPDATE_DEFAULT=%zu\n"
	.align	3
.LC2817:
	.string	"enum_expression_signed.GIT_SUBMODULE_UPDATE_DEFAULT=%d\n"
	.align	3
.LC2818:
	.string	"constant.GIT_SUBMODULE_UPDATE_DEFAULT="
	.align	3
.LC2819:
	.string	"constant_size.GIT_SUBMODULE_UPDATE_DEFAULT=%zu\n"
	.align	3
.LC2820:
	.string	"constant_signed.GIT_SUBMODULE_UPDATE_DEFAULT=%d\n"
	.align	3
.LC2821:
	.string	"enum_expression_size.GIT_SUBMODULE_UPDATE_MERGE=%zu\n"
	.align	3
.LC2822:
	.string	"enum_expression_signed.GIT_SUBMODULE_UPDATE_MERGE=%d\n"
	.align	3
.LC2823:
	.string	"constant.GIT_SUBMODULE_UPDATE_MERGE="
	.align	3
.LC2824:
	.string	"constant_size.GIT_SUBMODULE_UPDATE_MERGE=%zu\n"
	.align	3
.LC2825:
	.string	"constant_signed.GIT_SUBMODULE_UPDATE_MERGE=%d\n"
	.align	3
.LC2826:
	.string	"enum_expression_size.GIT_SUBMODULE_UPDATE_NONE=%zu\n"
	.align	3
.LC2827:
	.string	"enum_expression_signed.GIT_SUBMODULE_UPDATE_NONE=%d\n"
	.align	3
.LC2828:
	.string	"constant.GIT_SUBMODULE_UPDATE_NONE="
	.align	3
.LC2829:
	.string	"constant_size.GIT_SUBMODULE_UPDATE_NONE=%zu\n"
	.align	3
.LC2830:
	.string	"constant_signed.GIT_SUBMODULE_UPDATE_NONE=%d\n"
	.align	3
.LC2831:
	.string	"enum_expression_size.GIT_SUBMODULE_UPDATE_REBASE=%zu\n"
	.align	3
.LC2832:
	.string	"enum_expression_signed.GIT_SUBMODULE_UPDATE_REBASE=%d\n"
	.align	3
.LC2833:
	.string	"constant.GIT_SUBMODULE_UPDATE_REBASE="
	.align	3
.LC2834:
	.string	"constant_size.GIT_SUBMODULE_UPDATE_REBASE=%zu\n"
	.align	3
.LC2835:
	.string	"constant_signed.GIT_SUBMODULE_UPDATE_REBASE=%d\n"
	.align	3
.LC2836:
	.string	"enum_expression_size.GIT_TIMEOUT=%zu\n"
	.align	3
.LC2837:
	.string	"enum_expression_signed.GIT_TIMEOUT=%d\n"
	.align	3
.LC2838:
	.string	"constant.GIT_TIMEOUT="
	.align	3
.LC2839:
	.string	"constant_size.GIT_TIMEOUT=%zu\n"
	.align	3
.LC2840:
	.string	"constant_signed.GIT_TIMEOUT=%d\n"
	.align	3
.LC2841:
	.string	"enum_expression_size.GIT_TRACE_DEBUG=%zu\n"
	.align	3
.LC2842:
	.string	"enum_expression_signed.GIT_TRACE_DEBUG=%d\n"
	.align	3
.LC2843:
	.string	"constant.GIT_TRACE_DEBUG="
	.align	3
.LC2844:
	.string	"constant_size.GIT_TRACE_DEBUG=%zu\n"
	.align	3
.LC2845:
	.string	"constant_signed.GIT_TRACE_DEBUG=%d\n"
	.align	3
.LC2846:
	.string	"enum_expression_size.GIT_TRACE_ERROR=%zu\n"
	.align	3
.LC2847:
	.string	"enum_expression_signed.GIT_TRACE_ERROR=%d\n"
	.align	3
.LC2848:
	.string	"constant.GIT_TRACE_ERROR="
	.align	3
.LC2849:
	.string	"constant_size.GIT_TRACE_ERROR=%zu\n"
	.align	3
.LC2850:
	.string	"constant_signed.GIT_TRACE_ERROR=%d\n"
	.align	3
.LC2851:
	.string	"enum_expression_size.GIT_TRACE_FATAL=%zu\n"
	.align	3
.LC2852:
	.string	"enum_expression_signed.GIT_TRACE_FATAL=%d\n"
	.align	3
.LC2853:
	.string	"constant.GIT_TRACE_FATAL="
	.align	3
.LC2854:
	.string	"constant_size.GIT_TRACE_FATAL=%zu\n"
	.align	3
.LC2855:
	.string	"constant_signed.GIT_TRACE_FATAL=%d\n"
	.align	3
.LC2856:
	.string	"enum_expression_size.GIT_TRACE_INFO=%zu\n"
	.align	3
.LC2857:
	.string	"enum_expression_signed.GIT_TRACE_INFO=%d\n"
	.align	3
.LC2858:
	.string	"constant.GIT_TRACE_INFO="
	.align	3
.LC2859:
	.string	"constant_size.GIT_TRACE_INFO=%zu\n"
	.align	3
.LC2860:
	.string	"constant_signed.GIT_TRACE_INFO=%d\n"
	.align	3
.LC2861:
	.string	"enum_expression_size.GIT_TRACE_NONE=%zu\n"
	.align	3
.LC2862:
	.string	"enum_expression_signed.GIT_TRACE_NONE=%d\n"
	.align	3
.LC2863:
	.string	"constant.GIT_TRACE_NONE="
	.align	3
.LC2864:
	.string	"constant_size.GIT_TRACE_NONE=%zu\n"
	.align	3
.LC2865:
	.string	"constant_signed.GIT_TRACE_NONE=%d\n"
	.align	3
.LC2866:
	.string	"enum_expression_size.GIT_TRACE_TRACE=%zu\n"
	.align	3
.LC2867:
	.string	"enum_expression_signed.GIT_TRACE_TRACE=%d\n"
	.align	3
.LC2868:
	.string	"constant.GIT_TRACE_TRACE="
	.align	3
.LC2869:
	.string	"constant_size.GIT_TRACE_TRACE=%zu\n"
	.align	3
.LC2870:
	.string	"constant_signed.GIT_TRACE_TRACE=%d\n"
	.align	3
.LC2871:
	.string	"enum_expression_size.GIT_TRACE_WARN=%zu\n"
	.align	3
.LC2872:
	.string	"enum_expression_signed.GIT_TRACE_WARN=%d\n"
	.align	3
.LC2873:
	.string	"constant.GIT_TRACE_WARN="
	.align	3
.LC2874:
	.string	"constant_size.GIT_TRACE_WARN=%zu\n"
	.align	3
.LC2875:
	.string	"constant_signed.GIT_TRACE_WARN=%d\n"
	.align	3
.LC2876:
	.string	"enum_expression_size.GIT_TREEWALK_POST=%zu\n"
	.align	3
.LC2877:
	.string	"enum_expression_signed.GIT_TREEWALK_POST=%d\n"
	.align	3
.LC2878:
	.string	"constant.GIT_TREEWALK_POST="
	.align	3
.LC2879:
	.string	"constant_size.GIT_TREEWALK_POST=%zu\n"
	.align	3
.LC2880:
	.string	"constant_signed.GIT_TREEWALK_POST=%d\n"
	.align	3
.LC2881:
	.string	"enum_expression_size.GIT_TREEWALK_PRE=%zu\n"
	.align	3
.LC2882:
	.string	"enum_expression_signed.GIT_TREEWALK_PRE=%d\n"
	.align	3
.LC2883:
	.string	"constant.GIT_TREEWALK_PRE="
	.align	3
.LC2884:
	.string	"constant_size.GIT_TREEWALK_PRE=%zu\n"
	.align	3
.LC2885:
	.string	"constant_signed.GIT_TREEWALK_PRE=%d\n"
	.align	3
.LC2886:
	.string	"enum_expression_size.GIT_TREE_UPDATE_REMOVE=%zu\n"
	.align	3
.LC2887:
	.string	"enum_expression_signed.GIT_TREE_UPDATE_REMOVE=%d\n"
	.align	3
.LC2888:
	.string	"constant.GIT_TREE_UPDATE_REMOVE="
	.align	3
.LC2889:
	.string	"constant_size.GIT_TREE_UPDATE_REMOVE=%zu\n"
	.align	3
.LC2890:
	.string	"constant_signed.GIT_TREE_UPDATE_REMOVE=%d\n"
	.align	3
.LC2891:
	.string	"enum_expression_size.GIT_TREE_UPDATE_UPSERT=%zu\n"
	.align	3
.LC2892:
	.string	"enum_expression_signed.GIT_TREE_UPDATE_UPSERT=%d\n"
	.align	3
.LC2893:
	.string	"constant.GIT_TREE_UPDATE_UPSERT="
	.align	3
.LC2894:
	.string	"constant_size.GIT_TREE_UPDATE_UPSERT=%zu\n"
	.align	3
.LC2895:
	.string	"constant_signed.GIT_TREE_UPDATE_UPSERT=%d\n"
	.align	3
.LC2896:
	.string	"enum_expression_size.GIT_WORKTREE_PRUNE_LOCKED=%zu\n"
	.align	3
.LC2897:
	.string	"enum_expression_signed.GIT_WORKTREE_PRUNE_LOCKED=%d\n"
	.align	3
.LC2898:
	.string	"constant.GIT_WORKTREE_PRUNE_LOCKED="
	.align	3
.LC2899:
	.string	"constant_size.GIT_WORKTREE_PRUNE_LOCKED=%zu\n"
	.align	3
.LC2900:
	.string	"constant_signed.GIT_WORKTREE_PRUNE_LOCKED=%d\n"
	.align	3
.LC2901:
	.string	"enum_expression_size.GIT_WORKTREE_PRUNE_VALID=%zu\n"
	.align	3
.LC2902:
	.string	"enum_expression_signed.GIT_WORKTREE_PRUNE_VALID=%d\n"
	.align	3
.LC2903:
	.string	"constant.GIT_WORKTREE_PRUNE_VALID="
	.align	3
.LC2904:
	.string	"constant_size.GIT_WORKTREE_PRUNE_VALID=%zu\n"
	.align	3
.LC2905:
	.string	"constant_signed.GIT_WORKTREE_PRUNE_VALID=%d\n"
	.align	3
.LC2906:
	.string	"enum_expression_size.GIT_WORKTREE_PRUNE_WORKING_TREE=%zu\n"
	.align	3
.LC2907:
	.string	"enum_expression_signed.GIT_WORKTREE_PRUNE_WORKING_TREE=%d\n"
	.align	3
.LC2908:
	.string	"constant.GIT_WORKTREE_PRUNE_WORKING_TREE="
	.align	3
.LC2909:
	.string	"constant_size.GIT_WORKTREE_PRUNE_WORKING_TREE=%zu\n"
	.align	3
.LC2910:
	.string	"constant_signed.GIT_WORKTREE_PRUNE_WORKING_TREE=%d\n"
	.align	3
.LC2911:
	.string	"constant.GIT_APPLY_OPTIONS_VERSION="
	.align	3
.LC2912:
	.string	"constant_size.GIT_APPLY_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2913:
	.string	"constant_signed.GIT_APPLY_OPTIONS_VERSION=%d\n"
	.align	3
.LC2914:
	.string	"constant.GIT_ATTR_CHECK_FILE_THEN_INDEX="
	.align	3
.LC2915:
	.string	"constant_size.GIT_ATTR_CHECK_FILE_THEN_INDEX=%zu\n"
	.align	3
.LC2916:
	.string	"constant_signed.GIT_ATTR_CHECK_FILE_THEN_INDEX=%d\n"
	.align	3
.LC2917:
	.string	"constant.GIT_ATTR_CHECK_INCLUDE_COMMIT="
	.align	3
.LC2918:
	.string	"constant_size.GIT_ATTR_CHECK_INCLUDE_COMMIT=%zu\n"
	.align	3
.LC2919:
	.string	"constant_signed.GIT_ATTR_CHECK_INCLUDE_COMMIT=%d\n"
	.align	3
.LC2920:
	.string	"constant.GIT_ATTR_CHECK_INCLUDE_HEAD="
	.align	3
.LC2921:
	.string	"constant_size.GIT_ATTR_CHECK_INCLUDE_HEAD=%zu\n"
	.align	3
.LC2922:
	.string	"constant_signed.GIT_ATTR_CHECK_INCLUDE_HEAD=%d\n"
	.align	3
.LC2923:
	.string	"constant.GIT_ATTR_CHECK_INDEX_ONLY="
	.align	3
.LC2924:
	.string	"constant_size.GIT_ATTR_CHECK_INDEX_ONLY=%zu\n"
	.align	3
.LC2925:
	.string	"constant_signed.GIT_ATTR_CHECK_INDEX_ONLY=%d\n"
	.align	3
.LC2926:
	.string	"constant.GIT_ATTR_CHECK_INDEX_THEN_FILE="
	.align	3
.LC2927:
	.string	"constant_size.GIT_ATTR_CHECK_INDEX_THEN_FILE=%zu\n"
	.align	3
.LC2928:
	.string	"constant_signed.GIT_ATTR_CHECK_INDEX_THEN_FILE=%d\n"
	.align	3
.LC2929:
	.string	"constant.GIT_ATTR_CHECK_NO_SYSTEM="
	.align	3
.LC2930:
	.string	"constant_size.GIT_ATTR_CHECK_NO_SYSTEM=%zu\n"
	.align	3
.LC2931:
	.string	"constant_signed.GIT_ATTR_CHECK_NO_SYSTEM=%d\n"
	.align	3
.LC2932:
	.string	"constant.GIT_ATTR_FALSE_T="
	.align	3
.LC2933:
	.string	"constant_size.GIT_ATTR_FALSE_T=%zu\n"
	.align	3
.LC2934:
	.string	"constant_signed.GIT_ATTR_FALSE_T=%d\n"
	.align	3
.LC2935:
	.string	"constant.GIT_ATTR_OPTIONS_VERSION="
	.align	3
.LC2936:
	.string	"constant_size.GIT_ATTR_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2937:
	.string	"constant_signed.GIT_ATTR_OPTIONS_VERSION=%d\n"
	.align	3
.LC2938:
	.string	"constant.GIT_ATTR_TRUE_T="
	.align	3
.LC2939:
	.string	"constant_size.GIT_ATTR_TRUE_T=%zu\n"
	.align	3
.LC2940:
	.string	"constant_signed.GIT_ATTR_TRUE_T=%d\n"
	.align	3
.LC2941:
	.string	"constant.GIT_ATTR_UNSPECIFIED_T="
	.align	3
.LC2942:
	.string	"constant_size.GIT_ATTR_UNSPECIFIED_T=%zu\n"
	.align	3
.LC2943:
	.string	"constant_signed.GIT_ATTR_UNSPECIFIED_T=%d\n"
	.align	3
.LC2944:
	.string	"constant.GIT_ATTR_VALUE_T="
	.align	3
.LC2945:
	.string	"constant_size.GIT_ATTR_VALUE_T=%zu\n"
	.align	3
.LC2946:
	.string	"constant_signed.GIT_ATTR_VALUE_T=%d\n"
	.align	3
.LC2947:
	.string	"constant.GIT_BLAME_OPTIONS_VERSION="
	.align	3
.LC2948:
	.string	"constant_size.GIT_BLAME_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2949:
	.string	"constant_signed.GIT_BLAME_OPTIONS_VERSION=%d\n"
	.align	3
.LC2950:
	.string	"constant.GIT_BLOB_FILTER_ATTTRIBUTES_FROM_HEAD="
	.align	3
.LC2951:
	.string	"constant_size.GIT_BLOB_FILTER_ATTTRIBUTES_FROM_HEAD=%zu\n"
	.align	3
.LC2952:
	.string	"constant_signed.GIT_BLOB_FILTER_ATTTRIBUTES_FROM_HEAD=%d\n"
	.align	3
.LC2953:
	.string	"constant.GIT_BLOB_FILTER_OPTIONS_VERSION="
	.align	3
.LC2954:
	.string	"constant_size.GIT_BLOB_FILTER_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2955:
	.string	"constant_signed.GIT_BLOB_FILTER_OPTIONS_VERSION=%d\n"
	.align	3
.LC2956:
	.string	"constant.GIT_CHECKOUT_OPTIONS_VERSION="
	.align	3
.LC2957:
	.string	"constant_size.GIT_CHECKOUT_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2958:
	.string	"constant_signed.GIT_CHECKOUT_OPTIONS_VERSION=%d\n"
	.align	3
.LC2959:
	.string	"constant.GIT_CHERRYPICK_OPTIONS_VERSION="
	.align	3
.LC2960:
	.string	"constant_size.GIT_CHERRYPICK_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2961:
	.string	"constant_signed.GIT_CHERRYPICK_OPTIONS_VERSION=%d\n"
	.align	3
.LC2962:
	.string	"constant.GIT_CLONE_OPTIONS_VERSION="
	.align	3
.LC2963:
	.string	"constant_size.GIT_CLONE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2964:
	.string	"constant_signed.GIT_CLONE_OPTIONS_VERSION=%d\n"
	.align	3
.LC2965:
	.string	"constant.GIT_COMMIT_CREATE_OPTIONS_VERSION="
	.align	3
.LC2966:
	.string	"constant_size.GIT_COMMIT_CREATE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC2967:
	.string	"constant_signed.GIT_COMMIT_CREATE_OPTIONS_VERSION=%d\n"
	.align	3
.LC2968:
	.string	"constant.GIT_CREDTYPE_DEFAULT="
	.align	3
.LC2969:
	.string	"constant_size.GIT_CREDTYPE_DEFAULT=%zu\n"
	.align	3
.LC2970:
	.string	"constant_signed.GIT_CREDTYPE_DEFAULT=%d\n"
	.align	3
.LC2971:
	.string	"constant.GIT_CREDTYPE_SSH_CUSTOM="
	.align	3
.LC2972:
	.string	"constant_size.GIT_CREDTYPE_SSH_CUSTOM=%zu\n"
	.align	3
.LC2973:
	.string	"constant_signed.GIT_CREDTYPE_SSH_CUSTOM=%d\n"
	.align	3
.LC2974:
	.string	"constant.GIT_CREDTYPE_SSH_INTERACTIVE="
	.align	3
.LC2975:
	.string	"constant_size.GIT_CREDTYPE_SSH_INTERACTIVE=%zu\n"
	.align	3
.LC2976:
	.string	"constant_signed.GIT_CREDTYPE_SSH_INTERACTIVE=%d\n"
	.align	3
.LC2977:
	.string	"constant.GIT_CREDTYPE_SSH_KEY="
	.align	3
.LC2978:
	.string	"constant_size.GIT_CREDTYPE_SSH_KEY=%zu\n"
	.align	3
.LC2979:
	.string	"constant_signed.GIT_CREDTYPE_SSH_KEY=%d\n"
	.align	3
.LC2980:
	.string	"constant.GIT_CREDTYPE_SSH_MEMORY="
	.align	3
.LC2981:
	.string	"constant_size.GIT_CREDTYPE_SSH_MEMORY=%zu\n"
	.align	3
.LC2982:
	.string	"constant_signed.GIT_CREDTYPE_SSH_MEMORY=%d\n"
	.align	3
.LC2983:
	.string	"constant.GIT_CREDTYPE_USERNAME="
	.align	3
.LC2984:
	.string	"constant_size.GIT_CREDTYPE_USERNAME=%zu\n"
	.align	3
.LC2985:
	.string	"constant_signed.GIT_CREDTYPE_USERNAME=%d\n"
	.align	3
.LC2986:
	.string	"constant.GIT_CREDTYPE_USERPASS_PLAINTEXT="
	.align	3
.LC2987:
	.string	"constant_size.GIT_CREDTYPE_USERPASS_PLAINTEXT=%zu\n"
	.align	3
.LC2988:
	.string	"constant_signed.GIT_CREDTYPE_USERPASS_PLAINTEXT=%d\n"
	.align	3
.LC2989:
	.string	"constant.GIT_CVAR_FALSE="
	.align	3
.LC2990:
	.string	"constant_size.GIT_CVAR_FALSE=%zu\n"
	.align	3
.LC2991:
	.string	"constant_signed.GIT_CVAR_FALSE=%d\n"
	.align	3
.LC2992:
	.string	"constant.GIT_CVAR_INT32="
	.align	3
.LC2993:
	.string	"constant_size.GIT_CVAR_INT32=%zu\n"
	.align	3
.LC2994:
	.string	"constant_signed.GIT_CVAR_INT32=%d\n"
	.align	3
.LC2995:
	.string	"constant.GIT_CVAR_STRING="
	.align	3
.LC2996:
	.string	"constant_size.GIT_CVAR_STRING=%zu\n"
	.align	3
.LC2997:
	.string	"constant_signed.GIT_CVAR_STRING=%d\n"
	.align	3
.LC2998:
	.string	"constant.GIT_CVAR_TRUE="
	.align	3
.LC2999:
	.string	"constant_size.GIT_CVAR_TRUE=%zu\n"
	.align	3
.LC3000:
	.string	"constant_signed.GIT_CVAR_TRUE=%d\n"
	.align	3
.LC3001:
	.string	"constant.GIT_DESCRIBE_DEFAULT_ABBREVIATED_SIZE="
	.align	3
.LC3002:
	.string	"constant_size.GIT_DESCRIBE_DEFAULT_ABBREVIATED_SIZE=%zu\n"
	.align	3
.LC3003:
	.string	"constant_signed.GIT_DESCRIBE_DEFAULT_ABBREVIATED_SIZE=%d\n"
	.align	3
.LC3004:
	.string	"constant.GIT_DESCRIBE_DEFAULT_MAX_CANDIDATES_TAGS="
	.align	3
.LC3005:
	.string	"constant_size.GIT_DESCRIBE_DEFAULT_MAX_CANDIDATES_TAGS=%zu\n"
	.align	3
.LC3006:
	.string	"constant_signed.GIT_DESCRIBE_DEFAULT_MAX_CANDIDATES_TAGS=%d\n"
	.align	3
.LC3007:
	.string	"constant.GIT_DESCRIBE_FORMAT_OPTIONS_VERSION="
	.align	3
.LC3008:
	.string	"constant_size.GIT_DESCRIBE_FORMAT_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3009:
	.string	"constant_signed.GIT_DESCRIBE_FORMAT_OPTIONS_VERSION=%d\n"
	.align	3
.LC3010:
	.string	"constant.GIT_DESCRIBE_OPTIONS_VERSION="
	.align	3
.LC3011:
	.string	"constant_size.GIT_DESCRIBE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3012:
	.string	"constant_signed.GIT_DESCRIBE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3013:
	.string	"constant.GIT_DIFF_FIND_OPTIONS_VERSION="
	.align	3
.LC3014:
	.string	"constant_size.GIT_DIFF_FIND_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3015:
	.string	"constant_signed.GIT_DIFF_FIND_OPTIONS_VERSION=%d\n"
	.align	3
.LC3016:
	.string	"constant.GIT_DIFF_FORMAT_EMAIL_OPTIONS_VERSION="
	.align	3
.LC3017:
	.string	"constant_size.GIT_DIFF_FORMAT_EMAIL_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3018:
	.string	"constant_signed.GIT_DIFF_FORMAT_EMAIL_OPTIONS_VERSION=%d\n"
	.align	3
.LC3019:
	.string	"constant.GIT_DIFF_HUNK_HEADER_SIZE="
	.align	3
.LC3020:
	.string	"constant_size.GIT_DIFF_HUNK_HEADER_SIZE=%zu\n"
	.align	3
.LC3021:
	.string	"constant_signed.GIT_DIFF_HUNK_HEADER_SIZE=%d\n"
	.align	3
.LC3022:
	.string	"constant.GIT_DIFF_OPTIONS_VERSION="
	.align	3
.LC3023:
	.string	"constant_size.GIT_DIFF_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3024:
	.string	"constant_signed.GIT_DIFF_OPTIONS_VERSION=%d\n"
	.align	3
.LC3025:
	.string	"constant.GIT_DIFF_PARSE_OPTIONS_VERSION="
	.align	3
.LC3026:
	.string	"constant_size.GIT_DIFF_PARSE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3027:
	.string	"constant_signed.GIT_DIFF_PARSE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3028:
	.string	"constant.GIT_DIFF_PATCHID_OPTIONS_VERSION="
	.align	3
.LC3029:
	.string	"constant_size.GIT_DIFF_PATCHID_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3030:
	.string	"constant_signed.GIT_DIFF_PATCHID_OPTIONS_VERSION=%d\n"
	.align	3
.LC3031:
	.string	"constant.GIT_EMAIL_CREATE_OPTIONS_VERSION="
	.align	3
.LC3032:
	.string	"constant_size.GIT_EMAIL_CREATE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3033:
	.string	"constant_signed.GIT_EMAIL_CREATE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3034:
	.string	"constant.GIT_ERROR_SHA1="
	.align	3
.LC3035:
	.string	"constant_size.GIT_ERROR_SHA1=%zu\n"
	.align	3
.LC3036:
	.string	"constant_signed.GIT_ERROR_SHA1=%d\n"
	.align	3
.LC3037:
	.string	"constant.GIT_FETCH_OPTIONS_VERSION="
	.align	3
.LC3038:
	.string	"constant_size.GIT_FETCH_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3039:
	.string	"constant_signed.GIT_FETCH_OPTIONS_VERSION=%d\n"
	.align	3
.LC3040:
	.string	"constant.GIT_FILTER_OPTIONS_VERSION="
	.align	3
.LC3041:
	.string	"constant_size.GIT_FILTER_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3042:
	.string	"constant_signed.GIT_FILTER_OPTIONS_VERSION=%d\n"
	.align	3
.LC3043:
	.string	"constant.GIT_IDXENTRY_ADDED="
	.align	3
.LC3044:
	.string	"constant_size.GIT_IDXENTRY_ADDED=%zu\n"
	.align	3
.LC3045:
	.string	"constant_signed.GIT_IDXENTRY_ADDED=%d\n"
	.align	3
.LC3046:
	.string	"constant.GIT_IDXENTRY_CONFLICTED="
	.align	3
.LC3047:
	.string	"constant_size.GIT_IDXENTRY_CONFLICTED=%zu\n"
	.align	3
.LC3048:
	.string	"constant_signed.GIT_IDXENTRY_CONFLICTED=%d\n"
	.align	3
.LC3049:
	.string	"constant.GIT_IDXENTRY_EXTENDED="
	.align	3
.LC3050:
	.string	"constant_size.GIT_IDXENTRY_EXTENDED=%zu\n"
	.align	3
.LC3051:
	.string	"constant_signed.GIT_IDXENTRY_EXTENDED=%d\n"
	.align	3
.LC3052:
	.string	"constant.GIT_IDXENTRY_EXTENDED2="
	.align	3
.LC3053:
	.string	"constant_size.GIT_IDXENTRY_EXTENDED2=%zu\n"
	.align	3
.LC3054:
	.string	"constant_signed.GIT_IDXENTRY_EXTENDED2=%d\n"
	.align	3
.LC3055:
	.string	"constant.GIT_IDXENTRY_EXTENDED_FLAGS="
	.align	3
.LC3056:
	.string	"constant_size.GIT_IDXENTRY_EXTENDED_FLAGS=%zu\n"
	.align	3
.LC3057:
	.string	"constant_signed.GIT_IDXENTRY_EXTENDED_FLAGS=%d\n"
	.align	3
.LC3058:
	.string	"constant.GIT_IDXENTRY_HASHED="
	.align	3
.LC3059:
	.string	"constant_size.GIT_IDXENTRY_HASHED=%zu\n"
	.align	3
.LC3060:
	.string	"constant_signed.GIT_IDXENTRY_HASHED=%d\n"
	.align	3
.LC3061:
	.string	"constant.GIT_IDXENTRY_INTENT_TO_ADD="
	.align	3
.LC3062:
	.string	"constant_size.GIT_IDXENTRY_INTENT_TO_ADD=%zu\n"
	.align	3
.LC3063:
	.string	"constant_signed.GIT_IDXENTRY_INTENT_TO_ADD=%d\n"
	.align	3
.LC3064:
	.string	"constant.GIT_IDXENTRY_NAMEMASK="
	.align	3
.LC3065:
	.string	"constant_size.GIT_IDXENTRY_NAMEMASK=%zu\n"
	.align	3
.LC3066:
	.string	"constant_signed.GIT_IDXENTRY_NAMEMASK=%d\n"
	.align	3
.LC3067:
	.string	"constant.GIT_IDXENTRY_NEW_SKIP_WORKTREE="
	.align	3
.LC3068:
	.string	"constant_size.GIT_IDXENTRY_NEW_SKIP_WORKTREE=%zu\n"
	.align	3
.LC3069:
	.string	"constant_signed.GIT_IDXENTRY_NEW_SKIP_WORKTREE=%d\n"
	.align	3
.LC3070:
	.string	"constant.GIT_IDXENTRY_REMOVE="
	.align	3
.LC3071:
	.string	"constant_size.GIT_IDXENTRY_REMOVE=%zu\n"
	.align	3
.LC3072:
	.string	"constant_signed.GIT_IDXENTRY_REMOVE=%d\n"
	.align	3
.LC3073:
	.string	"constant.GIT_IDXENTRY_SKIP_WORKTREE="
	.align	3
.LC3074:
	.string	"constant_size.GIT_IDXENTRY_SKIP_WORKTREE=%zu\n"
	.align	3
.LC3075:
	.string	"constant_signed.GIT_IDXENTRY_SKIP_WORKTREE=%d\n"
	.align	3
.LC3076:
	.string	"constant.GIT_IDXENTRY_STAGEMASK="
	.align	3
.LC3077:
	.string	"constant_size.GIT_IDXENTRY_STAGEMASK=%zu\n"
	.align	3
.LC3078:
	.string	"constant_signed.GIT_IDXENTRY_STAGEMASK=%d\n"
	.align	3
.LC3079:
	.string	"constant.GIT_IDXENTRY_STAGESHIFT="
	.align	3
.LC3080:
	.string	"constant_size.GIT_IDXENTRY_STAGESHIFT=%zu\n"
	.align	3
.LC3081:
	.string	"constant_signed.GIT_IDXENTRY_STAGESHIFT=%d\n"
	.align	3
.LC3082:
	.string	"constant.GIT_IDXENTRY_UNHASHED="
	.align	3
.LC3083:
	.string	"constant_size.GIT_IDXENTRY_UNHASHED=%zu\n"
	.align	3
.LC3084:
	.string	"constant_signed.GIT_IDXENTRY_UNHASHED=%d\n"
	.align	3
.LC3085:
	.string	"constant.GIT_IDXENTRY_UNPACKED="
	.align	3
.LC3086:
	.string	"constant_size.GIT_IDXENTRY_UNPACKED=%zu\n"
	.align	3
.LC3087:
	.string	"constant_signed.GIT_IDXENTRY_UNPACKED=%d\n"
	.align	3
.LC3088:
	.string	"constant.GIT_IDXENTRY_UPDATE="
	.align	3
.LC3089:
	.string	"constant_size.GIT_IDXENTRY_UPDATE=%zu\n"
	.align	3
.LC3090:
	.string	"constant_signed.GIT_IDXENTRY_UPDATE=%d\n"
	.align	3
.LC3091:
	.string	"constant.GIT_IDXENTRY_UPTODATE="
	.align	3
.LC3092:
	.string	"constant_size.GIT_IDXENTRY_UPTODATE=%zu\n"
	.align	3
.LC3093:
	.string	"constant_signed.GIT_IDXENTRY_UPTODATE=%d\n"
	.align	3
.LC3094:
	.string	"constant.GIT_IDXENTRY_VALID="
	.align	3
.LC3095:
	.string	"constant_size.GIT_IDXENTRY_VALID=%zu\n"
	.align	3
.LC3096:
	.string	"constant_signed.GIT_IDXENTRY_VALID=%d\n"
	.align	3
.LC3097:
	.string	"constant.GIT_IDXENTRY_WT_REMOVE="
	.align	3
.LC3098:
	.string	"constant_size.GIT_IDXENTRY_WT_REMOVE=%zu\n"
	.align	3
.LC3099:
	.string	"constant_signed.GIT_IDXENTRY_WT_REMOVE=%d\n"
	.align	3
.LC3100:
	.string	"constant.GIT_INDEXCAP_FROM_OWNER="
	.align	3
.LC3101:
	.string	"constant_size.GIT_INDEXCAP_FROM_OWNER=%zu\n"
	.align	3
.LC3102:
	.string	"constant_signed.GIT_INDEXCAP_FROM_OWNER=%d\n"
	.align	3
.LC3103:
	.string	"constant.GIT_INDEXCAP_IGNORE_CASE="
	.align	3
.LC3104:
	.string	"constant_size.GIT_INDEXCAP_IGNORE_CASE=%zu\n"
	.align	3
.LC3105:
	.string	"constant_signed.GIT_INDEXCAP_IGNORE_CASE=%d\n"
	.align	3
.LC3106:
	.string	"constant.GIT_INDEXCAP_NO_FILEMODE="
	.align	3
.LC3107:
	.string	"constant_size.GIT_INDEXCAP_NO_FILEMODE=%zu\n"
	.align	3
.LC3108:
	.string	"constant_signed.GIT_INDEXCAP_NO_FILEMODE=%d\n"
	.align	3
.LC3109:
	.string	"constant.GIT_INDEXCAP_NO_SYMLINKS="
	.align	3
.LC3110:
	.string	"constant_size.GIT_INDEXCAP_NO_SYMLINKS=%zu\n"
	.align	3
.LC3111:
	.string	"constant_signed.GIT_INDEXCAP_NO_SYMLINKS=%d\n"
	.align	3
.LC3112:
	.string	"constant.GIT_INDEXER_OPTIONS_VERSION="
	.align	3
.LC3113:
	.string	"constant_size.GIT_INDEXER_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3114:
	.string	"constant_signed.GIT_INDEXER_OPTIONS_VERSION=%d\n"
	.align	3
.LC3115:
	.string	"constant.GIT_INDEX_ENTRY_NAMEMASK="
	.align	3
.LC3116:
	.string	"constant_size.GIT_INDEX_ENTRY_NAMEMASK=%zu\n"
	.align	3
.LC3117:
	.string	"constant_signed.GIT_INDEX_ENTRY_NAMEMASK=%d\n"
	.align	3
.LC3118:
	.string	"constant.GIT_INDEX_ENTRY_STAGEMASK="
	.align	3
.LC3119:
	.string	"constant_size.GIT_INDEX_ENTRY_STAGEMASK=%zu\n"
	.align	3
.LC3120:
	.string	"constant_signed.GIT_INDEX_ENTRY_STAGEMASK=%d\n"
	.align	3
.LC3121:
	.string	"constant.GIT_INDEX_ENTRY_STAGESHIFT="
	.align	3
.LC3122:
	.string	"constant_size.GIT_INDEX_ENTRY_STAGESHIFT=%zu\n"
	.align	3
.LC3123:
	.string	"constant_signed.GIT_INDEX_ENTRY_STAGESHIFT=%d\n"
	.align	3
.LC3124:
	.string	"constant.GIT_MERGE_CONFLICT_MARKER_SIZE="
	.align	3
.LC3125:
	.string	"constant_size.GIT_MERGE_CONFLICT_MARKER_SIZE=%zu\n"
	.align	3
.LC3126:
	.string	"constant_signed.GIT_MERGE_CONFLICT_MARKER_SIZE=%d\n"
	.align	3
.LC3127:
	.string	"constant.GIT_MERGE_FILE_INPUT_VERSION="
	.align	3
.LC3128:
	.string	"constant_size.GIT_MERGE_FILE_INPUT_VERSION=%zu\n"
	.align	3
.LC3129:
	.string	"constant_signed.GIT_MERGE_FILE_INPUT_VERSION=%d\n"
	.align	3
.LC3130:
	.string	"constant.GIT_MERGE_FILE_OPTIONS_VERSION="
	.align	3
.LC3131:
	.string	"constant_size.GIT_MERGE_FILE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3132:
	.string	"constant_signed.GIT_MERGE_FILE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3133:
	.string	"constant.GIT_MERGE_OPTIONS_VERSION="
	.align	3
.LC3134:
	.string	"constant_size.GIT_MERGE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3135:
	.string	"constant_signed.GIT_MERGE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3136:
	.string	"constant.GIT_OBJECT_SIZE_MAX="
	.align	3
.LC3138:
	.string	"constant_size.GIT_OBJECT_SIZE_MAX=%zu\n"
	.align	3
.LC3139:
	.string	"constant_signed.GIT_OBJECT_SIZE_MAX=%d\n"
	.align	3
.LC3140:
	.string	"constant.GIT_OBJ_ANY="
	.align	3
.LC3141:
	.string	"constant_size.GIT_OBJ_ANY=%zu\n"
	.align	3
.LC3142:
	.string	"constant_signed.GIT_OBJ_ANY=%d\n"
	.align	3
.LC3143:
	.string	"constant.GIT_OBJ_BAD="
	.align	3
.LC3144:
	.string	"constant_size.GIT_OBJ_BAD=%zu\n"
	.align	3
.LC3145:
	.string	"constant_signed.GIT_OBJ_BAD=%d\n"
	.align	3
.LC3146:
	.string	"constant.GIT_OBJ_BLOB="
	.align	3
.LC3147:
	.string	"constant_size.GIT_OBJ_BLOB=%zu\n"
	.align	3
.LC3148:
	.string	"constant_signed.GIT_OBJ_BLOB=%d\n"
	.align	3
.LC3149:
	.string	"constant.GIT_OBJ_COMMIT="
	.align	3
.LC3150:
	.string	"constant_size.GIT_OBJ_COMMIT=%zu\n"
	.align	3
.LC3151:
	.string	"constant_signed.GIT_OBJ_COMMIT=%d\n"
	.align	3
.LC3152:
	.string	"constant.GIT_OBJ_OFS_DELTA="
	.align	3
.LC3153:
	.string	"constant_size.GIT_OBJ_OFS_DELTA=%zu\n"
	.align	3
.LC3154:
	.string	"constant_signed.GIT_OBJ_OFS_DELTA=%d\n"
	.align	3
.LC3155:
	.string	"constant.GIT_OBJ_REF_DELTA="
	.align	3
.LC3156:
	.string	"constant_size.GIT_OBJ_REF_DELTA=%zu\n"
	.align	3
.LC3157:
	.string	"constant_signed.GIT_OBJ_REF_DELTA=%d\n"
	.align	3
.LC3158:
	.string	"constant.GIT_OBJ_TAG="
	.align	3
.LC3159:
	.string	"constant_size.GIT_OBJ_TAG=%zu\n"
	.align	3
.LC3160:
	.string	"constant_signed.GIT_OBJ_TAG=%d\n"
	.align	3
.LC3161:
	.string	"constant.GIT_OBJ_TREE="
	.align	3
.LC3162:
	.string	"constant_size.GIT_OBJ_TREE=%zu\n"
	.align	3
.LC3163:
	.string	"constant_signed.GIT_OBJ_TREE=%d\n"
	.align	3
.LC3164:
	.string	"constant.GIT_OBJ__EXT1="
	.align	3
.LC3165:
	.string	"constant_size.GIT_OBJ__EXT1=%zu\n"
	.align	3
.LC3166:
	.string	"constant_signed.GIT_OBJ__EXT1=%d\n"
	.align	3
.LC3167:
	.string	"constant.GIT_OBJ__EXT2="
	.align	3
.LC3168:
	.string	"constant_size.GIT_OBJ__EXT2=%zu\n"
	.align	3
.LC3169:
	.string	"constant_signed.GIT_OBJ__EXT2=%d\n"
	.align	3
.LC3170:
	.string	"constant.GIT_ODB_BACKEND_LOOSE_OPTIONS_VERSION="
	.align	3
.LC3171:
	.string	"constant_size.GIT_ODB_BACKEND_LOOSE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3172:
	.string	"constant_signed.GIT_ODB_BACKEND_LOOSE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3173:
	.string	"constant.GIT_ODB_BACKEND_PACK_OPTIONS_VERSION="
	.align	3
.LC3174:
	.string	"constant_size.GIT_ODB_BACKEND_PACK_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3175:
	.string	"constant_signed.GIT_ODB_BACKEND_PACK_OPTIONS_VERSION=%d\n"
	.align	3
.LC3176:
	.string	"constant.GIT_ODB_OPTIONS_VERSION="
	.align	3
.LC3177:
	.string	"constant_size.GIT_ODB_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3178:
	.string	"constant_signed.GIT_ODB_OPTIONS_VERSION=%d\n"
	.align	3
.LC3179:
	.string	"constant.GIT_OID_DEFAULT="
	.align	3
.LC3180:
	.string	"constant_size.GIT_OID_DEFAULT=%zu\n"
	.align	3
.LC3181:
	.string	"constant_signed.GIT_OID_DEFAULT=%d\n"
	.align	3
.LC3182:
	.string	"constant.GIT_OID_HEXSZ="
	.align	3
.LC3183:
	.string	"constant_size.GIT_OID_HEXSZ=%zu\n"
	.align	3
.LC3184:
	.string	"constant_signed.GIT_OID_HEXSZ=%d\n"
	.align	3
.LC3185:
	.string	"constant.GIT_OID_MAX_HEXSIZE="
	.align	3
.LC3186:
	.string	"constant_size.GIT_OID_MAX_HEXSIZE=%zu\n"
	.align	3
.LC3187:
	.string	"constant_signed.GIT_OID_MAX_HEXSIZE=%d\n"
	.align	3
.LC3188:
	.string	"constant.GIT_OID_MAX_SIZE="
	.align	3
.LC3189:
	.string	"constant_size.GIT_OID_MAX_SIZE=%zu\n"
	.align	3
.LC3190:
	.string	"constant_signed.GIT_OID_MAX_SIZE=%d\n"
	.align	3
.LC3191:
	.string	"constant.GIT_OID_MINPREFIXLEN="
	.align	3
.LC3192:
	.string	"constant_size.GIT_OID_MINPREFIXLEN=%zu\n"
	.align	3
.LC3193:
	.string	"constant_signed.GIT_OID_MINPREFIXLEN=%d\n"
	.align	3
.LC3194:
	.string	"constant.GIT_OID_RAWSZ="
	.align	3
.LC3195:
	.string	"constant_size.GIT_OID_RAWSZ=%zu\n"
	.align	3
.LC3196:
	.string	"constant_signed.GIT_OID_RAWSZ=%d\n"
	.align	3
.LC3197:
	.string	"constant.GIT_OID_SHA1_HEXSIZE="
	.align	3
.LC3198:
	.string	"constant_size.GIT_OID_SHA1_HEXSIZE=%zu\n"
	.align	3
.LC3199:
	.string	"constant_signed.GIT_OID_SHA1_HEXSIZE=%d\n"
	.align	3
.LC3200:
	.string	"constant.GIT_OID_SHA1_SIZE="
	.align	3
.LC3201:
	.string	"constant_size.GIT_OID_SHA1_SIZE=%zu\n"
	.align	3
.LC3202:
	.string	"constant_signed.GIT_OID_SHA1_SIZE=%d\n"
	.align	3
.LC3203:
	.string	"constant.GIT_PATH_LIST_SEPARATOR="
	.align	3
.LC3204:
	.string	"constant_size.GIT_PATH_LIST_SEPARATOR=%zu\n"
	.align	3
.LC3205:
	.string	"constant_signed.GIT_PATH_LIST_SEPARATOR=%d\n"
	.align	3
.LC3206:
	.string	"constant.GIT_PATH_MAX="
	.align	3
.LC3207:
	.string	"constant_size.GIT_PATH_MAX=%zu\n"
	.align	3
.LC3208:
	.string	"constant_signed.GIT_PATH_MAX=%d\n"
	.align	3
.LC3209:
	.string	"constant.GIT_PROXY_OPTIONS_VERSION="
	.align	3
.LC3210:
	.string	"constant_size.GIT_PROXY_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3211:
	.string	"constant_signed.GIT_PROXY_OPTIONS_VERSION=%d\n"
	.align	3
.LC3212:
	.string	"constant.GIT_PUSH_OPTIONS_VERSION="
	.align	3
.LC3213:
	.string	"constant_size.GIT_PUSH_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3214:
	.string	"constant_signed.GIT_PUSH_OPTIONS_VERSION=%d\n"
	.align	3
.LC3215:
	.string	"constant.GIT_REBASE_NO_OPERATION="
	.align	3
.LC3216:
	.string	"constant_size.GIT_REBASE_NO_OPERATION=%zu\n"
	.align	3
.LC3217:
	.string	"constant_signed.GIT_REBASE_NO_OPERATION=%d\n"
	.align	3
.LC3218:
	.string	"constant.GIT_REBASE_OPTIONS_VERSION="
	.align	3
.LC3219:
	.string	"constant_size.GIT_REBASE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3220:
	.string	"constant_signed.GIT_REBASE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3221:
	.string	"constant.GIT_REF_FORMAT_ALLOW_ONELEVEL="
	.align	3
.LC3222:
	.string	"constant_size.GIT_REF_FORMAT_ALLOW_ONELEVEL=%zu\n"
	.align	3
.LC3223:
	.string	"constant_signed.GIT_REF_FORMAT_ALLOW_ONELEVEL=%d\n"
	.align	3
.LC3224:
	.string	"constant.GIT_REF_FORMAT_NORMAL="
	.align	3
.LC3225:
	.string	"constant_size.GIT_REF_FORMAT_NORMAL=%zu\n"
	.align	3
.LC3226:
	.string	"constant_signed.GIT_REF_FORMAT_NORMAL=%d\n"
	.align	3
.LC3227:
	.string	"constant.GIT_REF_FORMAT_REFSPEC_PATTERN="
	.align	3
.LC3228:
	.string	"constant_size.GIT_REF_FORMAT_REFSPEC_PATTERN=%zu\n"
	.align	3
.LC3229:
	.string	"constant_signed.GIT_REF_FORMAT_REFSPEC_PATTERN=%d\n"
	.align	3
.LC3230:
	.string	"constant.GIT_REF_FORMAT_REFSPEC_SHORTHAND="
	.align	3
.LC3231:
	.string	"constant_size.GIT_REF_FORMAT_REFSPEC_SHORTHAND=%zu\n"
	.align	3
.LC3232:
	.string	"constant_signed.GIT_REF_FORMAT_REFSPEC_SHORTHAND=%d\n"
	.align	3
.LC3233:
	.string	"constant.GIT_REF_INVALID="
	.align	3
.LC3234:
	.string	"constant_size.GIT_REF_INVALID=%zu\n"
	.align	3
.LC3235:
	.string	"constant_signed.GIT_REF_INVALID=%d\n"
	.align	3
.LC3236:
	.string	"constant.GIT_REF_LISTALL="
	.align	3
.LC3237:
	.string	"constant_size.GIT_REF_LISTALL=%zu\n"
	.align	3
.LC3238:
	.string	"constant_signed.GIT_REF_LISTALL=%d\n"
	.align	3
.LC3239:
	.string	"constant.GIT_REF_OID="
	.align	3
.LC3240:
	.string	"constant_size.GIT_REF_OID=%zu\n"
	.align	3
.LC3241:
	.string	"constant_signed.GIT_REF_OID=%d\n"
	.align	3
.LC3242:
	.string	"constant.GIT_REF_SYMBOLIC="
	.align	3
.LC3243:
	.string	"constant_size.GIT_REF_SYMBOLIC=%zu\n"
	.align	3
.LC3244:
	.string	"constant_signed.GIT_REF_SYMBOLIC=%d\n"
	.align	3
.LC3245:
	.string	"constant.GIT_REMOTE_CALLBACKS_VERSION="
	.align	3
.LC3246:
	.string	"constant_size.GIT_REMOTE_CALLBACKS_VERSION=%zu\n"
	.align	3
.LC3247:
	.string	"constant_signed.GIT_REMOTE_CALLBACKS_VERSION=%d\n"
	.align	3
.LC3248:
	.string	"constant.GIT_REMOTE_CONNECT_OPTIONS_VERSION="
	.align	3
.LC3249:
	.string	"constant_size.GIT_REMOTE_CONNECT_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3250:
	.string	"constant_signed.GIT_REMOTE_CONNECT_OPTIONS_VERSION=%d\n"
	.align	3
.LC3251:
	.string	"constant.GIT_REMOTE_CREATE_OPTIONS_VERSION="
	.align	3
.LC3252:
	.string	"constant_size.GIT_REMOTE_CREATE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3253:
	.string	"constant_signed.GIT_REMOTE_CREATE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3254:
	.string	"constant.GIT_REPOSITORY_INIT_OPTIONS_VERSION="
	.align	3
.LC3255:
	.string	"constant_size.GIT_REPOSITORY_INIT_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3256:
	.string	"constant_signed.GIT_REPOSITORY_INIT_OPTIONS_VERSION=%d\n"
	.align	3
.LC3257:
	.string	"constant.GIT_REVERT_OPTIONS_VERSION="
	.align	3
.LC3258:
	.string	"constant_size.GIT_REVERT_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3259:
	.string	"constant_signed.GIT_REVERT_OPTIONS_VERSION=%d\n"
	.align	3
.LC3260:
	.string	"constant.GIT_REVPARSE_MERGE_BASE="
	.align	3
.LC3261:
	.string	"constant_size.GIT_REVPARSE_MERGE_BASE=%zu\n"
	.align	3
.LC3262:
	.string	"constant_signed.GIT_REVPARSE_MERGE_BASE=%d\n"
	.align	3
.LC3263:
	.string	"constant.GIT_REVPARSE_RANGE="
	.align	3
.LC3264:
	.string	"constant_size.GIT_REVPARSE_RANGE=%zu\n"
	.align	3
.LC3265:
	.string	"constant_signed.GIT_REVPARSE_RANGE=%d\n"
	.align	3
.LC3266:
	.string	"constant.GIT_REVPARSE_SINGLE="
	.align	3
.LC3267:
	.string	"constant_size.GIT_REVPARSE_SINGLE=%zu\n"
	.align	3
.LC3268:
	.string	"constant_signed.GIT_REVPARSE_SINGLE=%d\n"
	.align	3
.LC3269:
	.string	"constant.GIT_STASH_APPLY_OPTIONS_VERSION="
	.align	3
.LC3270:
	.string	"constant_size.GIT_STASH_APPLY_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3271:
	.string	"constant_signed.GIT_STASH_APPLY_OPTIONS_VERSION=%d\n"
	.align	3
.LC3272:
	.string	"constant.GIT_STASH_SAVE_OPTIONS_VERSION="
	.align	3
.LC3273:
	.string	"constant_size.GIT_STASH_SAVE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3274:
	.string	"constant_signed.GIT_STASH_SAVE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3275:
	.string	"constant.GIT_STATUS_OPTIONS_VERSION="
	.align	3
.LC3276:
	.string	"constant_size.GIT_STATUS_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3277:
	.string	"constant_signed.GIT_STATUS_OPTIONS_VERSION=%d\n"
	.align	3
.LC3278:
	.string	"constant.GIT_STATUS_OPT_DEFAULTS="
	.align	3
.LC3279:
	.string	"constant_size.GIT_STATUS_OPT_DEFAULTS=%zu\n"
	.align	3
.LC3280:
	.string	"constant_signed.GIT_STATUS_OPT_DEFAULTS=%d\n"
	.align	3
.LC3281:
	.string	"constant.GIT_SUBMODULE_STATUS__INDEX_FLAGS="
	.align	3
.LC3282:
	.string	"constant_size.GIT_SUBMODULE_STATUS__INDEX_FLAGS=%zu\n"
	.align	3
.LC3283:
	.string	"constant_signed.GIT_SUBMODULE_STATUS__INDEX_FLAGS=%d\n"
	.align	3
.LC3284:
	.string	"constant.GIT_SUBMODULE_STATUS__IN_FLAGS="
	.align	3
.LC3285:
	.string	"constant_size.GIT_SUBMODULE_STATUS__IN_FLAGS=%zu\n"
	.align	3
.LC3286:
	.string	"constant_signed.GIT_SUBMODULE_STATUS__IN_FLAGS=%d\n"
	.align	3
.LC3287:
	.string	"constant.GIT_SUBMODULE_STATUS__WD_FLAGS="
	.align	3
.LC3288:
	.string	"constant_size.GIT_SUBMODULE_STATUS__WD_FLAGS=%zu\n"
	.align	3
.LC3289:
	.string	"constant_signed.GIT_SUBMODULE_STATUS__WD_FLAGS=%d\n"
	.align	3
.LC3290:
	.string	"constant.GIT_SUBMODULE_UPDATE_OPTIONS_VERSION="
	.align	3
.LC3291:
	.string	"constant_size.GIT_SUBMODULE_UPDATE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3292:
	.string	"constant_signed.GIT_SUBMODULE_UPDATE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3293:
	.string	"constant.GIT_WORKTREE_ADD_OPTIONS_VERSION="
	.align	3
.LC3294:
	.string	"constant_size.GIT_WORKTREE_ADD_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3295:
	.string	"constant_signed.GIT_WORKTREE_ADD_OPTIONS_VERSION=%d\n"
	.align	3
.LC3296:
	.string	"constant.GIT_WORKTREE_PRUNE_OPTIONS_VERSION="
	.align	3
.LC3297:
	.string	"constant_size.GIT_WORKTREE_PRUNE_OPTIONS_VERSION=%zu\n"
	.align	3
.LC3298:
	.string	"constant_signed.GIT_WORKTREE_PRUNE_OPTIONS_VERSION=%d\n"
	.align	3
.LC3299:
	.string	"string.GIT_DEFAULT_PORT="
	.align	3
.LC3300:
	.string	"9418"
	.align	3
.LC3301:
	.string	"%02x"
	.align	3
.LC3302:
	.string	"string.GIT_OID_HEX_ZERO="
	.align	3
.LC3303:
	.string	"0000000000000000000000000000000000000000"
	.align	3
.LC3304:
	.string	"string.GIT_OID_SHA1_HEXZERO="
	.align	3
.LC3305:
	.string	"size.git_oid=%zu\n"
	.align	3
.LC3306:
	.string	"align.git_oid=%zu\n"
	.align	3
.LC3307:
	.string	"offset.git_oid.id=%zu\n"
	.align	3
.LC3308:
	.string	"size.git_buf=%zu\n"
	.align	3
.LC3309:
	.string	"align.git_buf=%zu\n"
	.align	3
.LC3310:
	.string	"offset.git_buf.ptr=%zu\n"
	.align	3
.LC3311:
	.string	"offset.git_buf.reserved=%zu\n"
	.align	3
.LC3312:
	.string	"offset.git_buf.size=%zu\n"
	.align	3
.LC3313:
	.string	"size.git_strarray=%zu\n"
	.align	3
.LC3314:
	.string	"align.git_strarray=%zu\n"
	.align	3
.LC3315:
	.string	"offset.git_strarray.strings=%zu\n"
	.align	3
.LC3316:
	.string	"offset.git_strarray.count=%zu\n"
	.align	3
.LC3317:
	.string	"size.git_time=%zu\n"
	.align	3
.LC3318:
	.string	"align.git_time=%zu\n"
	.align	3
.LC3319:
	.string	"offset.git_time.time=%zu\n"
	.align	3
.LC3320:
	.string	"offset.git_time.offset=%zu\n"
	.align	3
.LC3321:
	.string	"offset.git_time.sign=%zu\n"
	.align	3
.LC3322:
	.string	"size.git_signature=%zu\n"
	.align	3
.LC3323:
	.string	"align.git_signature=%zu\n"
	.align	3
.LC3324:
	.string	"offset.git_signature.name=%zu\n"
	.align	3
.LC3325:
	.string	"offset.git_signature.email=%zu\n"
	.align	3
.LC3326:
	.string	"offset.git_signature.when=%zu\n"
	.align	3
.LC3327:
	.string	"size.git_oidarray=%zu\n"
	.align	3
.LC3328:
	.string	"align.git_oidarray=%zu\n"
	.align	3
.LC3329:
	.string	"offset.git_oidarray.ids=%zu\n"
	.align	3
.LC3330:
	.string	"offset.git_oidarray.count=%zu\n"
	.align	3
.LC3331:
	.string	"size.git_repository_init_options=%zu\n"
	.align	3
.LC3332:
	.string	"align.git_repository_init_options=%zu\n"
	.align	3
.LC3333:
	.string	"offset.git_repository_init_options.version=%zu\n"
	.align	3
.LC3334:
	.string	"offset.git_repository_init_options.flags=%zu\n"
	.align	3
.LC3335:
	.string	"offset.git_repository_init_options.mode=%zu\n"
	.align	3
.LC3336:
	.string	"offset.git_repository_init_options.workdir_path=%zu\n"
	.align	3
.LC3337:
	.string	"offset.git_repository_init_options.description=%zu\n"
	.align	3
.LC3338:
	.string	"offset.git_repository_init_options.template_path=%zu\n"
	.align	3
.LC3339:
	.string	"offset.git_repository_init_options.initial_head=%zu\n"
	.align	3
.LC3340:
	.string	"offset.git_repository_init_options.origin_url=%zu\n"
	.align	3
.LC3341:
	.string	"size.git_commit_create_options=%zu\n"
	.align	3
.LC3342:
	.string	"align.git_commit_create_options=%zu\n"
	.align	3
.LC3343:
	.string	"offset.git_commit_create_options.version=%zu\n"
	.align	3
.LC3344:
	.string	"offset.git_commit_create_options.author=%zu\n"
	.align	3
.LC3345:
	.string	"offset.git_commit_create_options.committer=%zu\n"
	.align	3
.LC3346:
	.string	"offset.git_commit_create_options.message_encoding=%zu\n"
	.section	.text.startup,"ax",@progbits
	.align	2
	.p2align 4,,11
	.global	main
	.type	main, %function
main:
.LFB2:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x1, 4
	adrp	x0, .LC1
	mov	x29, sp
	add	x0, x0, :lo12:.LC1
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -32
	.cfi_offset 20, -24
	adrp	x20, .LC3300
	stp	x21, x22, [sp, 32]
	.cfi_offset 21, -16
	.cfi_offset 22, -8
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2
	add	x0, x0, :lo12:.LC2
	bl	printf
	add	x20, x20, :lo12:.LC3300
	adrp	x0, .LC3
	add	x0, x0, :lo12:.LC3
	bl	printf
	adrp	x19, .LC3300+1
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	adrp	x21, .LC3301
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC4
	add	x0, x0, :lo12:.LC4
	bl	printf
	mov	w1, 0
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	bl	printf
	mov	x1, 4
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	bl	printf
	mov	w1, 1
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
	bl	printf
	adrp	x0, .LC8
	add	x0, x0, :lo12:.LC8
	bl	printf
	add	x20, x20, 5
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	add	x19, x19, :lo12:.LC3300+1
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC9
	add	x0, x0, :lo12:.LC9
	bl	printf
	mov	w1, 0
	adrp	x0, .LC10
	add	x0, x0, :lo12:.LC10
	bl	printf
	mov	x1, 4
	adrp	x0, .LC11
	add	x0, x0, :lo12:.LC11
	bl	printf
	mov	w1, 1
	adrp	x0, .LC12
	add	x0, x0, :lo12:.LC12
	bl	printf
	adrp	x0, .LC13
	add	x0, x0, :lo12:.LC13
	bl	printf
	add	x21, x21, :lo12:.LC3301
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC14
	add	x0, x0, :lo12:.LC14
	bl	printf
	mov	w1, 0
	adrp	x0, .LC15
	add	x0, x0, :lo12:.LC15
	bl	printf
	mov	x1, 4
	adrp	x0, .LC16
	add	x0, x0, :lo12:.LC16
	bl	printf
	mov	w1, 1
	adrp	x0, .LC17
	add	x0, x0, :lo12:.LC17
	bl	printf
	adrp	x0, .LC18
	add	x0, x0, :lo12:.LC18
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC19
	add	x0, x0, :lo12:.LC19
	bl	printf
	mov	w1, 0
	adrp	x0, .LC20
	add	x0, x0, :lo12:.LC20
	bl	printf
	mov	x1, 4
	adrp	x0, .LC21
	add	x0, x0, :lo12:.LC21
	bl	printf
	mov	w1, 1
	adrp	x0, .LC22
	add	x0, x0, :lo12:.LC22
	bl	printf
	adrp	x0, .LC23
	add	x0, x0, :lo12:.LC23
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC24
	add	x0, x0, :lo12:.LC24
	bl	printf
	mov	w1, 0
	adrp	x0, .LC25
	add	x0, x0, :lo12:.LC25
	bl	printf
	mov	x1, 4
	adrp	x0, .LC26
	add	x0, x0, :lo12:.LC26
	bl	printf
	mov	w1, 1
	adrp	x0, .LC27
	add	x0, x0, :lo12:.LC27
	bl	printf
	adrp	x0, .LC28
	add	x0, x0, :lo12:.LC28
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC29
	add	x0, x0, :lo12:.LC29
	bl	printf
	mov	w1, 0
	adrp	x0, .LC30
	add	x0, x0, :lo12:.LC30
	bl	printf
	mov	x1, 4
	adrp	x0, .LC31
	add	x0, x0, :lo12:.LC31
	bl	printf
	mov	w1, 1
	adrp	x0, .LC32
	add	x0, x0, :lo12:.LC32
	bl	printf
	adrp	x0, .LC33
	add	x0, x0, :lo12:.LC33
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC34
	add	x0, x0, :lo12:.LC34
	bl	printf
	mov	w1, 0
	adrp	x0, .LC35
	add	x0, x0, :lo12:.LC35
	bl	printf
	mov	x1, 4
	adrp	x0, .LC36
	add	x0, x0, :lo12:.LC36
	bl	printf
	mov	w1, 1
	adrp	x0, .LC37
	add	x0, x0, :lo12:.LC37
	bl	printf
	adrp	x0, .LC38
	add	x0, x0, :lo12:.LC38
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC39
	add	x0, x0, :lo12:.LC39
	bl	printf
	mov	w1, 0
	adrp	x0, .LC40
	add	x0, x0, :lo12:.LC40
	bl	printf
	mov	x1, 4
	adrp	x0, .LC41
	add	x0, x0, :lo12:.LC41
	bl	printf
	mov	w1, 1
	adrp	x0, .LC42
	add	x0, x0, :lo12:.LC42
	bl	printf
	adrp	x0, .LC43
	add	x0, x0, :lo12:.LC43
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC44
	add	x0, x0, :lo12:.LC44
	bl	printf
	mov	w1, 0
	adrp	x0, .LC45
	add	x0, x0, :lo12:.LC45
	bl	printf
	mov	x1, 4
	adrp	x0, .LC46
	add	x0, x0, :lo12:.LC46
	bl	printf
	mov	w1, 1
	adrp	x0, .LC47
	add	x0, x0, :lo12:.LC47
	bl	printf
	adrp	x0, .LC48
	add	x0, x0, :lo12:.LC48
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC49
	add	x0, x0, :lo12:.LC49
	bl	printf
	mov	w1, 0
	adrp	x0, .LC50
	add	x0, x0, :lo12:.LC50
	bl	printf
	mov	x1, 4
	adrp	x0, .LC51
	add	x0, x0, :lo12:.LC51
	bl	printf
	mov	w1, 1
	adrp	x0, .LC52
	add	x0, x0, :lo12:.LC52
	bl	printf
	adrp	x0, .LC53
	add	x0, x0, :lo12:.LC53
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC54
	add	x0, x0, :lo12:.LC54
	bl	printf
	mov	w1, 0
	adrp	x0, .LC55
	add	x0, x0, :lo12:.LC55
	bl	printf
	mov	x1, 4
	adrp	x0, .LC56
	add	x0, x0, :lo12:.LC56
	bl	printf
	mov	w1, 1
	adrp	x0, .LC57
	add	x0, x0, :lo12:.LC57
	bl	printf
	adrp	x0, .LC58
	add	x0, x0, :lo12:.LC58
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC59
	add	x0, x0, :lo12:.LC59
	bl	printf
	mov	w1, 0
	adrp	x0, .LC60
	add	x0, x0, :lo12:.LC60
	bl	printf
	mov	x1, 4
	adrp	x0, .LC61
	add	x0, x0, :lo12:.LC61
	bl	printf
	mov	w1, 1
	adrp	x0, .LC62
	add	x0, x0, :lo12:.LC62
	bl	printf
	adrp	x0, .LC63
	add	x0, x0, :lo12:.LC63
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC64
	add	x0, x0, :lo12:.LC64
	bl	printf
	mov	w1, 0
	adrp	x0, .LC65
	add	x0, x0, :lo12:.LC65
	bl	printf
	mov	x1, 4
	adrp	x0, .LC66
	add	x0, x0, :lo12:.LC66
	bl	printf
	mov	w1, 1
	adrp	x0, .LC67
	add	x0, x0, :lo12:.LC67
	bl	printf
	adrp	x0, .LC68
	add	x0, x0, :lo12:.LC68
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC69
	add	x0, x0, :lo12:.LC69
	bl	printf
	mov	w1, 0
	adrp	x0, .LC70
	add	x0, x0, :lo12:.LC70
	bl	printf
	mov	x1, 4
	adrp	x0, .LC71
	add	x0, x0, :lo12:.LC71
	bl	printf
	mov	w1, 1
	adrp	x0, .LC72
	add	x0, x0, :lo12:.LC72
	bl	printf
	adrp	x0, .LC73
	add	x0, x0, :lo12:.LC73
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC74
	add	x0, x0, :lo12:.LC74
	bl	printf
	mov	w1, 0
	adrp	x0, .LC75
	add	x0, x0, :lo12:.LC75
	bl	printf
	mov	x1, 4
	adrp	x0, .LC76
	add	x0, x0, :lo12:.LC76
	bl	printf
	mov	w1, 1
	adrp	x0, .LC77
	add	x0, x0, :lo12:.LC77
	bl	printf
	adrp	x0, .LC78
	add	x0, x0, :lo12:.LC78
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC79
	add	x0, x0, :lo12:.LC79
	bl	printf
	mov	w1, 0
	adrp	x0, .LC80
	add	x0, x0, :lo12:.LC80
	bl	printf
	mov	x1, 4
	adrp	x0, .LC81
	add	x0, x0, :lo12:.LC81
	bl	printf
	mov	w1, 1
	adrp	x0, .LC82
	add	x0, x0, :lo12:.LC82
	bl	printf
	adrp	x0, .LC83
	add	x0, x0, :lo12:.LC83
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC84
	add	x0, x0, :lo12:.LC84
	bl	printf
	mov	w1, 0
	adrp	x0, .LC85
	add	x0, x0, :lo12:.LC85
	bl	printf
	mov	x1, 4
	adrp	x0, .LC86
	add	x0, x0, :lo12:.LC86
	bl	printf
	mov	w1, 1
	adrp	x0, .LC87
	add	x0, x0, :lo12:.LC87
	bl	printf
	adrp	x0, .LC88
	add	x0, x0, :lo12:.LC88
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC89
	add	x0, x0, :lo12:.LC89
	bl	printf
	mov	w1, 0
	adrp	x0, .LC90
	add	x0, x0, :lo12:.LC90
	bl	printf
	mov	x1, 4
	adrp	x0, .LC91
	add	x0, x0, :lo12:.LC91
	bl	printf
	mov	w1, 1
	adrp	x0, .LC92
	add	x0, x0, :lo12:.LC92
	bl	printf
	adrp	x0, .LC93
	add	x0, x0, :lo12:.LC93
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC94
	add	x0, x0, :lo12:.LC94
	bl	printf
	mov	w1, 0
	adrp	x0, .LC95
	add	x0, x0, :lo12:.LC95
	bl	printf
	mov	x1, 4
	adrp	x0, .LC96
	add	x0, x0, :lo12:.LC96
	bl	printf
	mov	w1, 1
	adrp	x0, .LC97
	add	x0, x0, :lo12:.LC97
	bl	printf
	adrp	x0, .LC98
	add	x0, x0, :lo12:.LC98
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC99
	add	x0, x0, :lo12:.LC99
	bl	printf
	mov	w1, 0
	adrp	x0, .LC100
	add	x0, x0, :lo12:.LC100
	bl	printf
	mov	x1, 4
	adrp	x0, .LC101
	add	x0, x0, :lo12:.LC101
	bl	printf
	mov	w1, 1
	adrp	x0, .LC102
	add	x0, x0, :lo12:.LC102
	bl	printf
	adrp	x0, .LC103
	add	x0, x0, :lo12:.LC103
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC104
	add	x0, x0, :lo12:.LC104
	bl	printf
	mov	w1, 0
	adrp	x0, .LC105
	add	x0, x0, :lo12:.LC105
	bl	printf
	mov	x1, 4
	adrp	x0, .LC106
	add	x0, x0, :lo12:.LC106
	bl	printf
	mov	w1, 1
	adrp	x0, .LC107
	add	x0, x0, :lo12:.LC107
	bl	printf
	adrp	x0, .LC108
	add	x0, x0, :lo12:.LC108
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC109
	add	x0, x0, :lo12:.LC109
	bl	printf
	mov	w1, 0
	adrp	x0, .LC110
	add	x0, x0, :lo12:.LC110
	bl	printf
	mov	x1, 4
	adrp	x0, .LC111
	add	x0, x0, :lo12:.LC111
	bl	printf
	mov	w1, 1
	adrp	x0, .LC112
	add	x0, x0, :lo12:.LC112
	bl	printf
	adrp	x0, .LC113
	add	x0, x0, :lo12:.LC113
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC114
	add	x0, x0, :lo12:.LC114
	bl	printf
	mov	w1, 0
	adrp	x0, .LC115
	add	x0, x0, :lo12:.LC115
	bl	printf
	mov	x1, 4
	adrp	x0, .LC116
	add	x0, x0, :lo12:.LC116
	bl	printf
	mov	w1, 1
	adrp	x0, .LC117
	add	x0, x0, :lo12:.LC117
	bl	printf
	adrp	x0, .LC118
	add	x0, x0, :lo12:.LC118
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC119
	add	x0, x0, :lo12:.LC119
	bl	printf
	mov	w1, 0
	adrp	x0, .LC120
	add	x0, x0, :lo12:.LC120
	bl	printf
	mov	x1, 4
	adrp	x0, .LC121
	add	x0, x0, :lo12:.LC121
	bl	printf
	mov	w1, 1
	adrp	x0, .LC122
	add	x0, x0, :lo12:.LC122
	bl	printf
	adrp	x0, .LC123
	add	x0, x0, :lo12:.LC123
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC124
	add	x0, x0, :lo12:.LC124
	bl	printf
	mov	w1, 0
	adrp	x0, .LC125
	add	x0, x0, :lo12:.LC125
	bl	printf
	mov	x1, 4
	adrp	x0, .LC126
	add	x0, x0, :lo12:.LC126
	bl	printf
	mov	w1, 1
	adrp	x0, .LC127
	add	x0, x0, :lo12:.LC127
	bl	printf
	adrp	x0, .LC128
	add	x0, x0, :lo12:.LC128
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC129
	add	x0, x0, :lo12:.LC129
	bl	printf
	mov	w1, 0
	adrp	x0, .LC130
	add	x0, x0, :lo12:.LC130
	bl	printf
	mov	x1, 4
	adrp	x0, .LC131
	add	x0, x0, :lo12:.LC131
	bl	printf
	mov	w1, 1
	adrp	x0, .LC132
	add	x0, x0, :lo12:.LC132
	bl	printf
	adrp	x0, .LC133
	add	x0, x0, :lo12:.LC133
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC134
	add	x0, x0, :lo12:.LC134
	bl	printf
	mov	w1, 0
	adrp	x0, .LC135
	add	x0, x0, :lo12:.LC135
	bl	printf
	mov	x1, 4
	adrp	x0, .LC136
	add	x0, x0, :lo12:.LC136
	bl	printf
	mov	w1, 1
	adrp	x0, .LC137
	add	x0, x0, :lo12:.LC137
	bl	printf
	adrp	x0, .LC138
	add	x0, x0, :lo12:.LC138
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC139
	add	x0, x0, :lo12:.LC139
	bl	printf
	mov	w1, 0
	adrp	x0, .LC140
	add	x0, x0, :lo12:.LC140
	bl	printf
	mov	x1, 4
	adrp	x0, .LC141
	add	x0, x0, :lo12:.LC141
	bl	printf
	mov	w1, 1
	adrp	x0, .LC142
	add	x0, x0, :lo12:.LC142
	bl	printf
	adrp	x0, .LC143
	add	x0, x0, :lo12:.LC143
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC144
	add	x0, x0, :lo12:.LC144
	bl	printf
	mov	w1, 0
	adrp	x0, .LC145
	add	x0, x0, :lo12:.LC145
	bl	printf
	mov	x1, 4
	adrp	x0, .LC146
	add	x0, x0, :lo12:.LC146
	bl	printf
	mov	w1, 1
	adrp	x0, .LC147
	add	x0, x0, :lo12:.LC147
	bl	printf
	adrp	x0, .LC148
	add	x0, x0, :lo12:.LC148
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC149
	add	x0, x0, :lo12:.LC149
	bl	printf
	mov	w1, 0
	adrp	x0, .LC150
	add	x0, x0, :lo12:.LC150
	bl	printf
	mov	x1, 4
	adrp	x0, .LC151
	add	x0, x0, :lo12:.LC151
	bl	printf
	mov	w1, 1
	adrp	x0, .LC152
	add	x0, x0, :lo12:.LC152
	bl	printf
	adrp	x0, .LC153
	add	x0, x0, :lo12:.LC153
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC154
	add	x0, x0, :lo12:.LC154
	bl	printf
	mov	w1, 0
	adrp	x0, .LC155
	add	x0, x0, :lo12:.LC155
	bl	printf
	mov	x1, 4
	adrp	x0, .LC156
	add	x0, x0, :lo12:.LC156
	bl	printf
	mov	w1, 1
	adrp	x0, .LC157
	add	x0, x0, :lo12:.LC157
	bl	printf
	adrp	x0, .LC158
	add	x0, x0, :lo12:.LC158
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC159
	add	x0, x0, :lo12:.LC159
	bl	printf
	mov	w1, 0
	adrp	x0, .LC160
	add	x0, x0, :lo12:.LC160
	bl	printf
	mov	x1, 4
	adrp	x0, .LC161
	add	x0, x0, :lo12:.LC161
	bl	printf
	mov	w1, 1
	adrp	x0, .LC162
	add	x0, x0, :lo12:.LC162
	bl	printf
	adrp	x0, .LC163
	add	x0, x0, :lo12:.LC163
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC164
	add	x0, x0, :lo12:.LC164
	bl	printf
	mov	w1, 0
	adrp	x0, .LC165
	add	x0, x0, :lo12:.LC165
	bl	printf
	mov	x1, 4
	adrp	x0, .LC166
	add	x0, x0, :lo12:.LC166
	bl	printf
	mov	w1, 1
	adrp	x0, .LC167
	add	x0, x0, :lo12:.LC167
	bl	printf
	adrp	x0, .LC168
	add	x0, x0, :lo12:.LC168
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC169
	add	x0, x0, :lo12:.LC169
	bl	printf
	mov	w1, 0
	adrp	x0, .LC170
	add	x0, x0, :lo12:.LC170
	bl	printf
	mov	x1, 4
	adrp	x0, .LC171
	add	x0, x0, :lo12:.LC171
	bl	printf
	mov	w1, 1
	adrp	x0, .LC172
	add	x0, x0, :lo12:.LC172
	bl	printf
	adrp	x0, .LC173
	add	x0, x0, :lo12:.LC173
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC174
	add	x0, x0, :lo12:.LC174
	bl	printf
	mov	w1, 0
	adrp	x0, .LC175
	add	x0, x0, :lo12:.LC175
	bl	printf
	mov	x1, 4
	adrp	x0, .LC176
	add	x0, x0, :lo12:.LC176
	bl	printf
	mov	w1, 1
	adrp	x0, .LC177
	add	x0, x0, :lo12:.LC177
	bl	printf
	adrp	x0, .LC178
	add	x0, x0, :lo12:.LC178
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC179
	add	x0, x0, :lo12:.LC179
	bl	printf
	mov	w1, 0
	adrp	x0, .LC180
	add	x0, x0, :lo12:.LC180
	bl	printf
	mov	x1, 4
	adrp	x0, .LC181
	add	x0, x0, :lo12:.LC181
	bl	printf
	mov	w1, 1
	adrp	x0, .LC182
	add	x0, x0, :lo12:.LC182
	bl	printf
	adrp	x0, .LC183
	add	x0, x0, :lo12:.LC183
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC184
	add	x0, x0, :lo12:.LC184
	bl	printf
	mov	w1, 0
	adrp	x0, .LC185
	add	x0, x0, :lo12:.LC185
	bl	printf
	mov	x1, 4
	adrp	x0, .LC186
	add	x0, x0, :lo12:.LC186
	bl	printf
	mov	w1, 1
	adrp	x0, .LC187
	add	x0, x0, :lo12:.LC187
	bl	printf
	adrp	x0, .LC188
	add	x0, x0, :lo12:.LC188
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC189
	add	x0, x0, :lo12:.LC189
	bl	printf
	mov	w1, 0
	adrp	x0, .LC190
	add	x0, x0, :lo12:.LC190
	bl	printf
	mov	x1, 4
	adrp	x0, .LC191
	add	x0, x0, :lo12:.LC191
	bl	printf
	mov	w1, 1
	adrp	x0, .LC192
	add	x0, x0, :lo12:.LC192
	bl	printf
	adrp	x0, .LC193
	add	x0, x0, :lo12:.LC193
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC194
	add	x0, x0, :lo12:.LC194
	bl	printf
	mov	w1, 0
	adrp	x0, .LC195
	add	x0, x0, :lo12:.LC195
	bl	printf
	mov	x1, 4
	adrp	x0, .LC196
	add	x0, x0, :lo12:.LC196
	bl	printf
	mov	w1, 1
	adrp	x0, .LC197
	add	x0, x0, :lo12:.LC197
	bl	printf
	adrp	x0, .LC198
	add	x0, x0, :lo12:.LC198
	bl	printf
	mov	x1, 0
	mov	x0, 2097152
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC199
	add	x0, x0, :lo12:.LC199
	bl	printf
	mov	w1, 0
	adrp	x0, .LC200
	add	x0, x0, :lo12:.LC200
	bl	printf
	mov	x1, 4
	adrp	x0, .LC201
	add	x0, x0, :lo12:.LC201
	bl	printf
	mov	w1, 1
	adrp	x0, .LC202
	add	x0, x0, :lo12:.LC202
	bl	printf
	adrp	x0, .LC203
	add	x0, x0, :lo12:.LC203
	bl	printf
	mov	x1, 0
	mov	x0, 1048576
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC204
	add	x0, x0, :lo12:.LC204
	bl	printf
	mov	w1, 0
	adrp	x0, .LC205
	add	x0, x0, :lo12:.LC205
	bl	printf
	mov	x1, 4
	adrp	x0, .LC206
	add	x0, x0, :lo12:.LC206
	bl	printf
	mov	w1, 1
	adrp	x0, .LC207
	add	x0, x0, :lo12:.LC207
	bl	printf
	adrp	x0, .LC208
	add	x0, x0, :lo12:.LC208
	bl	printf
	mov	x1, 0
	mov	x0, 33554432
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC209
	add	x0, x0, :lo12:.LC209
	bl	printf
	mov	w1, 0
	adrp	x0, .LC210
	add	x0, x0, :lo12:.LC210
	bl	printf
	mov	x1, 4
	adrp	x0, .LC211
	add	x0, x0, :lo12:.LC211
	bl	printf
	mov	w1, 1
	adrp	x0, .LC212
	add	x0, x0, :lo12:.LC212
	bl	printf
	adrp	x0, .LC213
	add	x0, x0, :lo12:.LC213
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC214
	add	x0, x0, :lo12:.LC214
	bl	printf
	mov	w1, 0
	adrp	x0, .LC215
	add	x0, x0, :lo12:.LC215
	bl	printf
	mov	x1, 4
	adrp	x0, .LC216
	add	x0, x0, :lo12:.LC216
	bl	printf
	mov	w1, 1
	adrp	x0, .LC217
	add	x0, x0, :lo12:.LC217
	bl	printf
	adrp	x0, .LC218
	add	x0, x0, :lo12:.LC218
	bl	printf
	mov	x1, 0
	mov	x0, 524288
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC219
	add	x0, x0, :lo12:.LC219
	bl	printf
	mov	w1, 0
	adrp	x0, .LC220
	add	x0, x0, :lo12:.LC220
	bl	printf
	mov	x1, 4
	adrp	x0, .LC221
	add	x0, x0, :lo12:.LC221
	bl	printf
	mov	w1, 1
	adrp	x0, .LC222
	add	x0, x0, :lo12:.LC222
	bl	printf
	adrp	x0, .LC223
	add	x0, x0, :lo12:.LC223
	bl	printf
	mov	x1, 0
	mov	x0, 4194304
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC224
	add	x0, x0, :lo12:.LC224
	bl	printf
	mov	w1, 0
	adrp	x0, .LC225
	add	x0, x0, :lo12:.LC225
	bl	printf
	mov	x1, 4
	adrp	x0, .LC226
	add	x0, x0, :lo12:.LC226
	bl	printf
	mov	w1, 1
	adrp	x0, .LC227
	add	x0, x0, :lo12:.LC227
	bl	printf
	adrp	x0, .LC228
	add	x0, x0, :lo12:.LC228
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC229
	add	x0, x0, :lo12:.LC229
	bl	printf
	mov	w1, 0
	adrp	x0, .LC230
	add	x0, x0, :lo12:.LC230
	bl	printf
	mov	x1, 4
	adrp	x0, .LC231
	add	x0, x0, :lo12:.LC231
	bl	printf
	mov	w1, 1
	adrp	x0, .LC232
	add	x0, x0, :lo12:.LC232
	bl	printf
	adrp	x0, .LC233
	add	x0, x0, :lo12:.LC233
	bl	printf
	mov	x1, 0
	mov	x0, 8388608
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC234
	add	x0, x0, :lo12:.LC234
	bl	printf
	mov	w1, 0
	adrp	x0, .LC235
	add	x0, x0, :lo12:.LC235
	bl	printf
	mov	x1, 4
	adrp	x0, .LC236
	add	x0, x0, :lo12:.LC236
	bl	printf
	mov	w1, 1
	adrp	x0, .LC237
	add	x0, x0, :lo12:.LC237
	bl	printf
	adrp	x0, .LC238
	add	x0, x0, :lo12:.LC238
	bl	printf
	mov	x1, 0
	mov	x0, 16777216
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC239
	add	x0, x0, :lo12:.LC239
	bl	printf
	mov	w1, 0
	adrp	x0, .LC240
	add	x0, x0, :lo12:.LC240
	bl	printf
	mov	x1, 4
	adrp	x0, .LC241
	add	x0, x0, :lo12:.LC241
	bl	printf
	mov	w1, 1
	adrp	x0, .LC242
	add	x0, x0, :lo12:.LC242
	bl	printf
	adrp	x0, .LC243
	add	x0, x0, :lo12:.LC243
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC244
	add	x0, x0, :lo12:.LC244
	bl	printf
	mov	w1, 0
	adrp	x0, .LC245
	add	x0, x0, :lo12:.LC245
	bl	printf
	mov	x1, 4
	adrp	x0, .LC246
	add	x0, x0, :lo12:.LC246
	bl	printf
	mov	w1, 1
	adrp	x0, .LC247
	add	x0, x0, :lo12:.LC247
	bl	printf
	adrp	x0, .LC248
	add	x0, x0, :lo12:.LC248
	bl	printf
	mov	x1, 0
	mov	x0, 1073741824
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC249
	add	x0, x0, :lo12:.LC249
	bl	printf
	mov	w1, 0
	adrp	x0, .LC250
	add	x0, x0, :lo12:.LC250
	bl	printf
	mov	x1, 4
	adrp	x0, .LC251
	add	x0, x0, :lo12:.LC251
	bl	printf
	mov	w1, 1
	adrp	x0, .LC252
	add	x0, x0, :lo12:.LC252
	bl	printf
	adrp	x0, .LC253
	add	x0, x0, :lo12:.LC253
	bl	printf
	mov	x1, 0
	mov	x0, 65535
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC254
	add	x0, x0, :lo12:.LC254
	bl	printf
	mov	w1, 0
	adrp	x0, .LC255
	add	x0, x0, :lo12:.LC255
	bl	printf
	mov	x1, 4
	adrp	x0, .LC256
	add	x0, x0, :lo12:.LC256
	bl	printf
	mov	w1, 1
	adrp	x0, .LC257
	add	x0, x0, :lo12:.LC257
	bl	printf
	adrp	x0, .LC258
	add	x0, x0, :lo12:.LC258
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC259
	add	x0, x0, :lo12:.LC259
	bl	printf
	mov	w1, 0
	adrp	x0, .LC260
	add	x0, x0, :lo12:.LC260
	bl	printf
	mov	x1, 4
	adrp	x0, .LC261
	add	x0, x0, :lo12:.LC261
	bl	printf
	mov	w1, 1
	adrp	x0, .LC262
	add	x0, x0, :lo12:.LC262
	bl	printf
	adrp	x0, .LC263
	add	x0, x0, :lo12:.LC263
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC264
	add	x0, x0, :lo12:.LC264
	bl	printf
	mov	w1, 0
	adrp	x0, .LC265
	add	x0, x0, :lo12:.LC265
	bl	printf
	mov	x1, 4
	adrp	x0, .LC266
	add	x0, x0, :lo12:.LC266
	bl	printf
	mov	w1, 1
	adrp	x0, .LC267
	add	x0, x0, :lo12:.LC267
	bl	printf
	adrp	x0, .LC268
	add	x0, x0, :lo12:.LC268
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC269
	add	x0, x0, :lo12:.LC269
	bl	printf
	mov	w1, 0
	adrp	x0, .LC270
	add	x0, x0, :lo12:.LC270
	bl	printf
	mov	x1, 4
	adrp	x0, .LC271
	add	x0, x0, :lo12:.LC271
	bl	printf
	mov	w1, 1
	adrp	x0, .LC272
	add	x0, x0, :lo12:.LC272
	bl	printf
	adrp	x0, .LC273
	add	x0, x0, :lo12:.LC273
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC274
	add	x0, x0, :lo12:.LC274
	bl	printf
	mov	w1, 0
	adrp	x0, .LC275
	add	x0, x0, :lo12:.LC275
	bl	printf
	mov	x1, 4
	adrp	x0, .LC276
	add	x0, x0, :lo12:.LC276
	bl	printf
	mov	w1, 1
	adrp	x0, .LC277
	add	x0, x0, :lo12:.LC277
	bl	printf
	adrp	x0, .LC278
	add	x0, x0, :lo12:.LC278
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC279
	add	x0, x0, :lo12:.LC279
	bl	printf
	mov	w1, 0
	adrp	x0, .LC280
	add	x0, x0, :lo12:.LC280
	bl	printf
	mov	x1, 4
	adrp	x0, .LC281
	add	x0, x0, :lo12:.LC281
	bl	printf
	mov	w1, 1
	adrp	x0, .LC282
	add	x0, x0, :lo12:.LC282
	bl	printf
	adrp	x0, .LC283
	add	x0, x0, :lo12:.LC283
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC284
	add	x0, x0, :lo12:.LC284
	bl	printf
	mov	w1, 0
	adrp	x0, .LC285
	add	x0, x0, :lo12:.LC285
	bl	printf
	mov	x1, 4
	adrp	x0, .LC286
	add	x0, x0, :lo12:.LC286
	bl	printf
	mov	w1, 1
	adrp	x0, .LC287
	add	x0, x0, :lo12:.LC287
	bl	printf
	adrp	x0, .LC288
	add	x0, x0, :lo12:.LC288
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC289
	add	x0, x0, :lo12:.LC289
	bl	printf
	mov	w1, 0
	adrp	x0, .LC290
	add	x0, x0, :lo12:.LC290
	bl	printf
	mov	x1, 4
	adrp	x0, .LC291
	add	x0, x0, :lo12:.LC291
	bl	printf
	mov	w1, 1
	adrp	x0, .LC292
	add	x0, x0, :lo12:.LC292
	bl	printf
	adrp	x0, .LC293
	add	x0, x0, :lo12:.LC293
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC294
	add	x0, x0, :lo12:.LC294
	bl	printf
	mov	w1, 0
	adrp	x0, .LC295
	add	x0, x0, :lo12:.LC295
	bl	printf
	mov	x1, 4
	adrp	x0, .LC296
	add	x0, x0, :lo12:.LC296
	bl	printf
	mov	w1, 1
	adrp	x0, .LC297
	add	x0, x0, :lo12:.LC297
	bl	printf
	adrp	x0, .LC298
	add	x0, x0, :lo12:.LC298
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC299
	add	x0, x0, :lo12:.LC299
	bl	printf
	mov	w1, 0
	adrp	x0, .LC300
	add	x0, x0, :lo12:.LC300
	bl	printf
	mov	x1, 4
	adrp	x0, .LC301
	add	x0, x0, :lo12:.LC301
	bl	printf
	mov	w1, 1
	adrp	x0, .LC302
	add	x0, x0, :lo12:.LC302
	bl	printf
	adrp	x0, .LC303
	add	x0, x0, :lo12:.LC303
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC304
	add	x0, x0, :lo12:.LC304
	bl	printf
	mov	w1, 0
	adrp	x0, .LC305
	add	x0, x0, :lo12:.LC305
	bl	printf
	mov	x1, 4
	adrp	x0, .LC306
	add	x0, x0, :lo12:.LC306
	bl	printf
	mov	w1, 1
	adrp	x0, .LC307
	add	x0, x0, :lo12:.LC307
	bl	printf
	adrp	x0, .LC308
	add	x0, x0, :lo12:.LC308
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC309
	add	x0, x0, :lo12:.LC309
	bl	printf
	mov	w1, 0
	adrp	x0, .LC310
	add	x0, x0, :lo12:.LC310
	bl	printf
	mov	x1, 4
	adrp	x0, .LC311
	add	x0, x0, :lo12:.LC311
	bl	printf
	mov	w1, 1
	adrp	x0, .LC312
	add	x0, x0, :lo12:.LC312
	bl	printf
	adrp	x0, .LC313
	add	x0, x0, :lo12:.LC313
	bl	printf
	mov	x1, 0
	mov	x0, 262144
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC314
	add	x0, x0, :lo12:.LC314
	bl	printf
	mov	w1, 0
	adrp	x0, .LC315
	add	x0, x0, :lo12:.LC315
	bl	printf
	mov	x1, 4
	adrp	x0, .LC316
	add	x0, x0, :lo12:.LC316
	bl	printf
	mov	w1, 1
	adrp	x0, .LC317
	add	x0, x0, :lo12:.LC317
	bl	printf
	adrp	x0, .LC318
	add	x0, x0, :lo12:.LC318
	bl	printf
	mov	x1, 0
	mov	x0, 1024
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC319
	add	x0, x0, :lo12:.LC319
	bl	printf
	mov	w1, 0
	adrp	x0, .LC320
	add	x0, x0, :lo12:.LC320
	bl	printf
	mov	x1, 4
	adrp	x0, .LC321
	add	x0, x0, :lo12:.LC321
	bl	printf
	mov	w1, 1
	adrp	x0, .LC322
	add	x0, x0, :lo12:.LC322
	bl	printf
	adrp	x0, .LC323
	add	x0, x0, :lo12:.LC323
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC324
	add	x0, x0, :lo12:.LC324
	bl	printf
	mov	w1, 0
	adrp	x0, .LC325
	add	x0, x0, :lo12:.LC325
	bl	printf
	mov	x1, 4
	adrp	x0, .LC326
	add	x0, x0, :lo12:.LC326
	bl	printf
	mov	w1, 1
	adrp	x0, .LC327
	add	x0, x0, :lo12:.LC327
	bl	printf
	adrp	x0, .LC328
	add	x0, x0, :lo12:.LC328
	bl	printf
	mov	x1, 0
	mov	x0, 65536
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC329
	add	x0, x0, :lo12:.LC329
	bl	printf
	mov	w1, 0
	adrp	x0, .LC330
	add	x0, x0, :lo12:.LC330
	bl	printf
	mov	x1, 4
	adrp	x0, .LC331
	add	x0, x0, :lo12:.LC331
	bl	printf
	mov	w1, 1
	adrp	x0, .LC332
	add	x0, x0, :lo12:.LC332
	bl	printf
	adrp	x0, .LC333
	add	x0, x0, :lo12:.LC333
	bl	printf
	mov	x1, 0
	mov	x0, 131072
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC334
	add	x0, x0, :lo12:.LC334
	bl	printf
	mov	w1, 0
	adrp	x0, .LC335
	add	x0, x0, :lo12:.LC335
	bl	printf
	mov	x1, 4
	adrp	x0, .LC336
	add	x0, x0, :lo12:.LC336
	bl	printf
	mov	w1, 1
	adrp	x0, .LC337
	add	x0, x0, :lo12:.LC337
	bl	printf
	adrp	x0, .LC338
	add	x0, x0, :lo12:.LC338
	bl	printf
	mov	x1, 0
	mov	x0, 2048
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC339
	add	x0, x0, :lo12:.LC339
	bl	printf
	mov	w1, 0
	adrp	x0, .LC340
	add	x0, x0, :lo12:.LC340
	bl	printf
	mov	x1, 4
	adrp	x0, .LC341
	add	x0, x0, :lo12:.LC341
	bl	printf
	mov	w1, 1
	adrp	x0, .LC342
	add	x0, x0, :lo12:.LC342
	bl	printf
	adrp	x0, .LC343
	add	x0, x0, :lo12:.LC343
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC344
	add	x0, x0, :lo12:.LC344
	bl	printf
	mov	w1, 0
	adrp	x0, .LC345
	add	x0, x0, :lo12:.LC345
	bl	printf
	mov	x1, 4
	adrp	x0, .LC346
	add	x0, x0, :lo12:.LC346
	bl	printf
	mov	w1, 1
	adrp	x0, .LC347
	add	x0, x0, :lo12:.LC347
	bl	printf
	adrp	x0, .LC348
	add	x0, x0, :lo12:.LC348
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC349
	add	x0, x0, :lo12:.LC349
	bl	printf
	mov	w1, 0
	adrp	x0, .LC350
	add	x0, x0, :lo12:.LC350
	bl	printf
	mov	x1, 4
	adrp	x0, .LC351
	add	x0, x0, :lo12:.LC351
	bl	printf
	mov	w1, 1
	adrp	x0, .LC352
	add	x0, x0, :lo12:.LC352
	bl	printf
	adrp	x0, .LC353
	add	x0, x0, :lo12:.LC353
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC354
	add	x0, x0, :lo12:.LC354
	bl	printf
	mov	w1, 0
	adrp	x0, .LC355
	add	x0, x0, :lo12:.LC355
	bl	printf
	mov	x1, 4
	adrp	x0, .LC356
	add	x0, x0, :lo12:.LC356
	bl	printf
	mov	w1, 1
	adrp	x0, .LC357
	add	x0, x0, :lo12:.LC357
	bl	printf
	adrp	x0, .LC358
	add	x0, x0, :lo12:.LC358
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC359
	add	x0, x0, :lo12:.LC359
	bl	printf
	mov	w1, 0
	adrp	x0, .LC360
	add	x0, x0, :lo12:.LC360
	bl	printf
	mov	x1, 4
	adrp	x0, .LC361
	add	x0, x0, :lo12:.LC361
	bl	printf
	mov	w1, 1
	adrp	x0, .LC362
	add	x0, x0, :lo12:.LC362
	bl	printf
	adrp	x0, .LC363
	add	x0, x0, :lo12:.LC363
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC364
	add	x0, x0, :lo12:.LC364
	bl	printf
	mov	w1, 0
	adrp	x0, .LC365
	add	x0, x0, :lo12:.LC365
	bl	printf
	mov	x1, 4
	adrp	x0, .LC366
	add	x0, x0, :lo12:.LC366
	bl	printf
	mov	w1, 1
	adrp	x0, .LC367
	add	x0, x0, :lo12:.LC367
	bl	printf
	adrp	x0, .LC368
	add	x0, x0, :lo12:.LC368
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC369
	add	x0, x0, :lo12:.LC369
	bl	printf
	mov	w1, 0
	adrp	x0, .LC370
	add	x0, x0, :lo12:.LC370
	bl	printf
	mov	x1, 4
	adrp	x0, .LC371
	add	x0, x0, :lo12:.LC371
	bl	printf
	mov	w1, 1
	adrp	x0, .LC372
	add	x0, x0, :lo12:.LC372
	bl	printf
	adrp	x0, .LC373
	add	x0, x0, :lo12:.LC373
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC374
	add	x0, x0, :lo12:.LC374
	bl	printf
	mov	w1, 0
	adrp	x0, .LC375
	add	x0, x0, :lo12:.LC375
	bl	printf
	mov	x1, 4
	adrp	x0, .LC376
	add	x0, x0, :lo12:.LC376
	bl	printf
	mov	w1, 1
	adrp	x0, .LC377
	add	x0, x0, :lo12:.LC377
	bl	printf
	adrp	x0, .LC378
	add	x0, x0, :lo12:.LC378
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC379
	add	x0, x0, :lo12:.LC379
	bl	printf
	mov	w1, 0
	adrp	x0, .LC380
	add	x0, x0, :lo12:.LC380
	bl	printf
	mov	x1, 4
	adrp	x0, .LC381
	add	x0, x0, :lo12:.LC381
	bl	printf
	mov	w1, 1
	adrp	x0, .LC382
	add	x0, x0, :lo12:.LC382
	bl	printf
	adrp	x0, .LC383
	add	x0, x0, :lo12:.LC383
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC384
	add	x0, x0, :lo12:.LC384
	bl	printf
	mov	w1, 0
	adrp	x0, .LC385
	add	x0, x0, :lo12:.LC385
	bl	printf
	mov	x1, 4
	adrp	x0, .LC386
	add	x0, x0, :lo12:.LC386
	bl	printf
	mov	w1, 1
	adrp	x0, .LC387
	add	x0, x0, :lo12:.LC387
	bl	printf
	adrp	x0, .LC388
	add	x0, x0, :lo12:.LC388
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC389
	add	x0, x0, :lo12:.LC389
	bl	printf
	mov	w1, 1
	adrp	x0, .LC390
	add	x0, x0, :lo12:.LC390
	bl	printf
	mov	x1, 4
	adrp	x0, .LC391
	add	x0, x0, :lo12:.LC391
	bl	printf
	mov	w1, 1
	adrp	x0, .LC392
	add	x0, x0, :lo12:.LC392
	bl	printf
	adrp	x0, .LC393
	add	x0, x0, :lo12:.LC393
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC394
	add	x0, x0, :lo12:.LC394
	bl	printf
	mov	w1, 1
	adrp	x0, .LC395
	add	x0, x0, :lo12:.LC395
	bl	printf
	mov	x1, 4
	adrp	x0, .LC396
	add	x0, x0, :lo12:.LC396
	bl	printf
	mov	w1, 1
	adrp	x0, .LC397
	add	x0, x0, :lo12:.LC397
	bl	printf
	adrp	x0, .LC398
	add	x0, x0, :lo12:.LC398
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC399
	add	x0, x0, :lo12:.LC399
	bl	printf
	mov	w1, 1
	adrp	x0, .LC400
	add	x0, x0, :lo12:.LC400
	bl	printf
	mov	x1, 4
	adrp	x0, .LC401
	add	x0, x0, :lo12:.LC401
	bl	printf
	mov	w1, 1
	adrp	x0, .LC402
	add	x0, x0, :lo12:.LC402
	bl	printf
	adrp	x0, .LC403
	add	x0, x0, :lo12:.LC403
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC404
	add	x0, x0, :lo12:.LC404
	bl	printf
	mov	w1, 1
	adrp	x0, .LC405
	add	x0, x0, :lo12:.LC405
	bl	printf
	mov	x1, 4
	adrp	x0, .LC406
	add	x0, x0, :lo12:.LC406
	bl	printf
	mov	w1, 1
	adrp	x0, .LC407
	add	x0, x0, :lo12:.LC407
	bl	printf
	adrp	x0, .LC408
	add	x0, x0, :lo12:.LC408
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC409
	add	x0, x0, :lo12:.LC409
	bl	printf
	mov	w1, 1
	adrp	x0, .LC410
	add	x0, x0, :lo12:.LC410
	bl	printf
	mov	x1, 4
	adrp	x0, .LC411
	add	x0, x0, :lo12:.LC411
	bl	printf
	mov	w1, 1
	adrp	x0, .LC412
	add	x0, x0, :lo12:.LC412
	bl	printf
	adrp	x0, .LC413
	add	x0, x0, :lo12:.LC413
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC414
	add	x0, x0, :lo12:.LC414
	bl	printf
	mov	w1, 1
	adrp	x0, .LC415
	add	x0, x0, :lo12:.LC415
	bl	printf
	mov	x1, 4
	adrp	x0, .LC416
	add	x0, x0, :lo12:.LC416
	bl	printf
	mov	w1, 1
	adrp	x0, .LC417
	add	x0, x0, :lo12:.LC417
	bl	printf
	adrp	x0, .LC418
	add	x0, x0, :lo12:.LC418
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC419
	add	x0, x0, :lo12:.LC419
	bl	printf
	mov	w1, 1
	adrp	x0, .LC420
	add	x0, x0, :lo12:.LC420
	bl	printf
	mov	x1, 4
	adrp	x0, .LC421
	add	x0, x0, :lo12:.LC421
	bl	printf
	mov	w1, 1
	adrp	x0, .LC422
	add	x0, x0, :lo12:.LC422
	bl	printf
	adrp	x0, .LC423
	add	x0, x0, :lo12:.LC423
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC424
	add	x0, x0, :lo12:.LC424
	bl	printf
	mov	w1, 1
	adrp	x0, .LC425
	add	x0, x0, :lo12:.LC425
	bl	printf
	mov	x1, 4
	adrp	x0, .LC426
	add	x0, x0, :lo12:.LC426
	bl	printf
	mov	w1, 1
	adrp	x0, .LC427
	add	x0, x0, :lo12:.LC427
	bl	printf
	adrp	x0, .LC428
	add	x0, x0, :lo12:.LC428
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC429
	add	x0, x0, :lo12:.LC429
	bl	printf
	mov	w1, 0
	adrp	x0, .LC430
	add	x0, x0, :lo12:.LC430
	bl	printf
	mov	x1, 4
	adrp	x0, .LC431
	add	x0, x0, :lo12:.LC431
	bl	printf
	mov	w1, 1
	adrp	x0, .LC432
	add	x0, x0, :lo12:.LC432
	bl	printf
	adrp	x0, .LC433
	add	x0, x0, :lo12:.LC433
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC434
	add	x0, x0, :lo12:.LC434
	bl	printf
	mov	w1, 0
	adrp	x0, .LC435
	add	x0, x0, :lo12:.LC435
	bl	printf
	mov	x1, 4
	adrp	x0, .LC436
	add	x0, x0, :lo12:.LC436
	bl	printf
	mov	w1, 1
	adrp	x0, .LC437
	add	x0, x0, :lo12:.LC437
	bl	printf
	adrp	x0, .LC438
	add	x0, x0, :lo12:.LC438
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC439
	add	x0, x0, :lo12:.LC439
	bl	printf
	mov	w1, 0
	adrp	x0, .LC440
	add	x0, x0, :lo12:.LC440
	bl	printf
	mov	x1, 4
	adrp	x0, .LC441
	add	x0, x0, :lo12:.LC441
	bl	printf
	mov	w1, 1
	adrp	x0, .LC442
	add	x0, x0, :lo12:.LC442
	bl	printf
	adrp	x0, .LC443
	add	x0, x0, :lo12:.LC443
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC444
	add	x0, x0, :lo12:.LC444
	bl	printf
	mov	w1, 0
	adrp	x0, .LC445
	add	x0, x0, :lo12:.LC445
	bl	printf
	mov	x1, 4
	adrp	x0, .LC446
	add	x0, x0, :lo12:.LC446
	bl	printf
	mov	w1, 1
	adrp	x0, .LC447
	add	x0, x0, :lo12:.LC447
	bl	printf
	adrp	x0, .LC448
	add	x0, x0, :lo12:.LC448
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC449
	add	x0, x0, :lo12:.LC449
	bl	printf
	mov	w1, 0
	adrp	x0, .LC450
	add	x0, x0, :lo12:.LC450
	bl	printf
	mov	x1, 4
	adrp	x0, .LC451
	add	x0, x0, :lo12:.LC451
	bl	printf
	mov	w1, 1
	adrp	x0, .LC452
	add	x0, x0, :lo12:.LC452
	bl	printf
	adrp	x0, .LC453
	add	x0, x0, :lo12:.LC453
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC454
	add	x0, x0, :lo12:.LC454
	bl	printf
	mov	w1, 0
	adrp	x0, .LC455
	add	x0, x0, :lo12:.LC455
	bl	printf
	mov	x1, 4
	adrp	x0, .LC456
	add	x0, x0, :lo12:.LC456
	bl	printf
	mov	w1, 1
	adrp	x0, .LC457
	add	x0, x0, :lo12:.LC457
	bl	printf
	adrp	x0, .LC458
	add	x0, x0, :lo12:.LC458
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC459
	add	x0, x0, :lo12:.LC459
	bl	printf
	mov	w1, 0
	adrp	x0, .LC460
	add	x0, x0, :lo12:.LC460
	bl	printf
	mov	x1, 4
	adrp	x0, .LC461
	add	x0, x0, :lo12:.LC461
	bl	printf
	mov	w1, 1
	adrp	x0, .LC462
	add	x0, x0, :lo12:.LC462
	bl	printf
	adrp	x0, .LC463
	add	x0, x0, :lo12:.LC463
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC464
	add	x0, x0, :lo12:.LC464
	bl	printf
	mov	w1, 0
	adrp	x0, .LC465
	add	x0, x0, :lo12:.LC465
	bl	printf
	mov	x1, 4
	adrp	x0, .LC466
	add	x0, x0, :lo12:.LC466
	bl	printf
	mov	w1, 1
	adrp	x0, .LC467
	add	x0, x0, :lo12:.LC467
	bl	printf
	adrp	x0, .LC468
	add	x0, x0, :lo12:.LC468
	bl	printf
	mov	x1, 0
	mov	x0, 10
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC469
	add	x0, x0, :lo12:.LC469
	bl	printf
	mov	w1, 0
	adrp	x0, .LC470
	add	x0, x0, :lo12:.LC470
	bl	printf
	mov	x1, 4
	adrp	x0, .LC471
	add	x0, x0, :lo12:.LC471
	bl	printf
	mov	w1, 1
	adrp	x0, .LC472
	add	x0, x0, :lo12:.LC472
	bl	printf
	adrp	x0, .LC473
	add	x0, x0, :lo12:.LC473
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC474
	add	x0, x0, :lo12:.LC474
	bl	printf
	mov	w1, 0
	adrp	x0, .LC475
	add	x0, x0, :lo12:.LC475
	bl	printf
	mov	x1, 4
	adrp	x0, .LC476
	add	x0, x0, :lo12:.LC476
	bl	printf
	mov	w1, 1
	adrp	x0, .LC477
	add	x0, x0, :lo12:.LC477
	bl	printf
	adrp	x0, .LC478
	add	x0, x0, :lo12:.LC478
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC479
	add	x0, x0, :lo12:.LC479
	bl	printf
	mov	w1, 0
	adrp	x0, .LC480
	add	x0, x0, :lo12:.LC480
	bl	printf
	mov	x1, 4
	adrp	x0, .LC481
	add	x0, x0, :lo12:.LC481
	bl	printf
	mov	w1, 1
	adrp	x0, .LC482
	add	x0, x0, :lo12:.LC482
	bl	printf
	adrp	x0, .LC483
	add	x0, x0, :lo12:.LC483
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC484
	add	x0, x0, :lo12:.LC484
	bl	printf
	mov	w1, 0
	adrp	x0, .LC485
	add	x0, x0, :lo12:.LC485
	bl	printf
	mov	x1, 4
	adrp	x0, .LC486
	add	x0, x0, :lo12:.LC486
	bl	printf
	mov	w1, 1
	adrp	x0, .LC487
	add	x0, x0, :lo12:.LC487
	bl	printf
	adrp	x0, .LC488
	add	x0, x0, :lo12:.LC488
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC489
	add	x0, x0, :lo12:.LC489
	bl	printf
	mov	w1, 0
	adrp	x0, .LC490
	add	x0, x0, :lo12:.LC490
	bl	printf
	mov	x1, 4
	adrp	x0, .LC491
	add	x0, x0, :lo12:.LC491
	bl	printf
	mov	w1, 1
	adrp	x0, .LC492
	add	x0, x0, :lo12:.LC492
	bl	printf
	adrp	x0, .LC493
	add	x0, x0, :lo12:.LC493
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC494
	add	x0, x0, :lo12:.LC494
	bl	printf
	mov	w1, 0
	adrp	x0, .LC495
	add	x0, x0, :lo12:.LC495
	bl	printf
	mov	x1, 4
	adrp	x0, .LC496
	add	x0, x0, :lo12:.LC496
	bl	printf
	mov	w1, 1
	adrp	x0, .LC497
	add	x0, x0, :lo12:.LC497
	bl	printf
	adrp	x0, .LC498
	add	x0, x0, :lo12:.LC498
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC499
	add	x0, x0, :lo12:.LC499
	bl	printf
	mov	w1, 0
	adrp	x0, .LC500
	add	x0, x0, :lo12:.LC500
	bl	printf
	mov	x1, 4
	adrp	x0, .LC501
	add	x0, x0, :lo12:.LC501
	bl	printf
	mov	w1, 1
	adrp	x0, .LC502
	add	x0, x0, :lo12:.LC502
	bl	printf
	adrp	x0, .LC503
	add	x0, x0, :lo12:.LC503
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC504
	add	x0, x0, :lo12:.LC504
	bl	printf
	mov	w1, 0
	adrp	x0, .LC505
	add	x0, x0, :lo12:.LC505
	bl	printf
	mov	x1, 4
	adrp	x0, .LC506
	add	x0, x0, :lo12:.LC506
	bl	printf
	mov	w1, 1
	adrp	x0, .LC507
	add	x0, x0, :lo12:.LC507
	bl	printf
	adrp	x0, .LC508
	add	x0, x0, :lo12:.LC508
	bl	printf
	mov	x1, 0
	mov	x0, 9
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC509
	add	x0, x0, :lo12:.LC509
	bl	printf
	mov	w1, 0
	adrp	x0, .LC510
	add	x0, x0, :lo12:.LC510
	bl	printf
	mov	x1, 4
	adrp	x0, .LC511
	add	x0, x0, :lo12:.LC511
	bl	printf
	mov	w1, 1
	adrp	x0, .LC512
	add	x0, x0, :lo12:.LC512
	bl	printf
	adrp	x0, .LC513
	add	x0, x0, :lo12:.LC513
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC514
	add	x0, x0, :lo12:.LC514
	bl	printf
	mov	w1, 0
	adrp	x0, .LC515
	add	x0, x0, :lo12:.LC515
	bl	printf
	mov	x1, 4
	adrp	x0, .LC516
	add	x0, x0, :lo12:.LC516
	bl	printf
	mov	w1, 1
	adrp	x0, .LC517
	add	x0, x0, :lo12:.LC517
	bl	printf
	adrp	x0, .LC518
	add	x0, x0, :lo12:.LC518
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC519
	add	x0, x0, :lo12:.LC519
	bl	printf
	mov	w1, 0
	adrp	x0, .LC520
	add	x0, x0, :lo12:.LC520
	bl	printf
	mov	x1, 4
	adrp	x0, .LC521
	add	x0, x0, :lo12:.LC521
	bl	printf
	mov	w1, 1
	adrp	x0, .LC522
	add	x0, x0, :lo12:.LC522
	bl	printf
	adrp	x0, .LC523
	add	x0, x0, :lo12:.LC523
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC524
	add	x0, x0, :lo12:.LC524
	bl	printf
	mov	w1, 0
	adrp	x0, .LC525
	add	x0, x0, :lo12:.LC525
	bl	printf
	mov	x1, 4
	adrp	x0, .LC526
	add	x0, x0, :lo12:.LC526
	bl	printf
	mov	w1, 1
	adrp	x0, .LC527
	add	x0, x0, :lo12:.LC527
	bl	printf
	adrp	x0, .LC528
	add	x0, x0, :lo12:.LC528
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC529
	add	x0, x0, :lo12:.LC529
	bl	printf
	mov	w1, 0
	adrp	x0, .LC530
	add	x0, x0, :lo12:.LC530
	bl	printf
	mov	x1, 4
	adrp	x0, .LC531
	add	x0, x0, :lo12:.LC531
	bl	printf
	mov	w1, 1
	adrp	x0, .LC532
	add	x0, x0, :lo12:.LC532
	bl	printf
	adrp	x0, .LC533
	add	x0, x0, :lo12:.LC533
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC534
	add	x0, x0, :lo12:.LC534
	bl	printf
	mov	w1, 0
	adrp	x0, .LC535
	add	x0, x0, :lo12:.LC535
	bl	printf
	mov	x1, 4
	adrp	x0, .LC536
	add	x0, x0, :lo12:.LC536
	bl	printf
	mov	w1, 1
	adrp	x0, .LC537
	add	x0, x0, :lo12:.LC537
	bl	printf
	adrp	x0, .LC538
	add	x0, x0, :lo12:.LC538
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC539
	add	x0, x0, :lo12:.LC539
	bl	printf
	mov	w1, 0
	adrp	x0, .LC540
	add	x0, x0, :lo12:.LC540
	bl	printf
	mov	x1, 4
	adrp	x0, .LC541
	add	x0, x0, :lo12:.LC541
	bl	printf
	mov	w1, 1
	adrp	x0, .LC542
	add	x0, x0, :lo12:.LC542
	bl	printf
	adrp	x0, .LC543
	add	x0, x0, :lo12:.LC543
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC544
	add	x0, x0, :lo12:.LC544
	bl	printf
	mov	w1, 0
	adrp	x0, .LC545
	add	x0, x0, :lo12:.LC545
	bl	printf
	mov	x1, 4
	adrp	x0, .LC546
	add	x0, x0, :lo12:.LC546
	bl	printf
	mov	w1, 1
	adrp	x0, .LC547
	add	x0, x0, :lo12:.LC547
	bl	printf
	adrp	x0, .LC548
	add	x0, x0, :lo12:.LC548
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC549
	add	x0, x0, :lo12:.LC549
	bl	printf
	mov	w1, 0
	adrp	x0, .LC550
	add	x0, x0, :lo12:.LC550
	bl	printf
	mov	x1, 4
	adrp	x0, .LC551
	add	x0, x0, :lo12:.LC551
	bl	printf
	mov	w1, 1
	adrp	x0, .LC552
	add	x0, x0, :lo12:.LC552
	bl	printf
	adrp	x0, .LC553
	add	x0, x0, :lo12:.LC553
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC554
	add	x0, x0, :lo12:.LC554
	bl	printf
	mov	w1, 0
	adrp	x0, .LC555
	add	x0, x0, :lo12:.LC555
	bl	printf
	mov	x1, 4
	adrp	x0, .LC556
	add	x0, x0, :lo12:.LC556
	bl	printf
	mov	w1, 1
	adrp	x0, .LC557
	add	x0, x0, :lo12:.LC557
	bl	printf
	adrp	x0, .LC558
	add	x0, x0, :lo12:.LC558
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC559
	add	x0, x0, :lo12:.LC559
	bl	printf
	mov	w1, 0
	adrp	x0, .LC560
	add	x0, x0, :lo12:.LC560
	bl	printf
	mov	x1, 4
	adrp	x0, .LC561
	add	x0, x0, :lo12:.LC561
	bl	printf
	mov	w1, 1
	adrp	x0, .LC562
	add	x0, x0, :lo12:.LC562
	bl	printf
	adrp	x0, .LC563
	add	x0, x0, :lo12:.LC563
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC564
	add	x0, x0, :lo12:.LC564
	bl	printf
	mov	w1, 0
	adrp	x0, .LC565
	add	x0, x0, :lo12:.LC565
	bl	printf
	mov	x1, 4
	adrp	x0, .LC566
	add	x0, x0, :lo12:.LC566
	bl	printf
	mov	w1, 1
	adrp	x0, .LC567
	add	x0, x0, :lo12:.LC567
	bl	printf
	adrp	x0, .LC568
	add	x0, x0, :lo12:.LC568
	bl	printf
	mov	x1, 0
	mov	x0, 255
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC569
	add	x0, x0, :lo12:.LC569
	bl	printf
	mov	w1, 0
	adrp	x0, .LC570
	add	x0, x0, :lo12:.LC570
	bl	printf
	mov	x1, 4
	adrp	x0, .LC571
	add	x0, x0, :lo12:.LC571
	bl	printf
	mov	w1, 1
	adrp	x0, .LC572
	add	x0, x0, :lo12:.LC572
	bl	printf
	adrp	x0, .LC573
	add	x0, x0, :lo12:.LC573
	bl	printf
	mov	x1, 0
	mov	x0, 48
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC574
	add	x0, x0, :lo12:.LC574
	bl	printf
	mov	w1, 0
	adrp	x0, .LC575
	add	x0, x0, :lo12:.LC575
	bl	printf
	mov	x1, 4
	adrp	x0, .LC576
	add	x0, x0, :lo12:.LC576
	bl	printf
	mov	w1, 1
	adrp	x0, .LC577
	add	x0, x0, :lo12:.LC577
	bl	printf
	adrp	x0, .LC578
	add	x0, x0, :lo12:.LC578
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC579
	add	x0, x0, :lo12:.LC579
	bl	printf
	mov	w1, 0
	adrp	x0, .LC580
	add	x0, x0, :lo12:.LC580
	bl	printf
	mov	x1, 4
	adrp	x0, .LC581
	add	x0, x0, :lo12:.LC581
	bl	printf
	mov	w1, 1
	adrp	x0, .LC582
	add	x0, x0, :lo12:.LC582
	bl	printf
	adrp	x0, .LC583
	add	x0, x0, :lo12:.LC583
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC584
	add	x0, x0, :lo12:.LC584
	bl	printf
	mov	w1, 0
	adrp	x0, .LC585
	add	x0, x0, :lo12:.LC585
	bl	printf
	mov	x1, 4
	adrp	x0, .LC586
	add	x0, x0, :lo12:.LC586
	bl	printf
	mov	w1, 1
	adrp	x0, .LC587
	add	x0, x0, :lo12:.LC587
	bl	printf
	adrp	x0, .LC588
	add	x0, x0, :lo12:.LC588
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC589
	add	x0, x0, :lo12:.LC589
	bl	printf
	mov	w1, 0
	adrp	x0, .LC590
	add	x0, x0, :lo12:.LC590
	bl	printf
	mov	x1, 4
	adrp	x0, .LC591
	add	x0, x0, :lo12:.LC591
	bl	printf
	mov	w1, 1
	adrp	x0, .LC592
	add	x0, x0, :lo12:.LC592
	bl	printf
	adrp	x0, .LC593
	add	x0, x0, :lo12:.LC593
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC594
	add	x0, x0, :lo12:.LC594
	bl	printf
	mov	w1, 0
	adrp	x0, .LC595
	add	x0, x0, :lo12:.LC595
	bl	printf
	mov	x1, 4
	adrp	x0, .LC596
	add	x0, x0, :lo12:.LC596
	bl	printf
	mov	w1, 1
	adrp	x0, .LC597
	add	x0, x0, :lo12:.LC597
	bl	printf
	adrp	x0, .LC598
	add	x0, x0, :lo12:.LC598
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC599
	add	x0, x0, :lo12:.LC599
	bl	printf
	mov	w1, 0
	adrp	x0, .LC600
	add	x0, x0, :lo12:.LC600
	bl	printf
	mov	x1, 4
	adrp	x0, .LC601
	add	x0, x0, :lo12:.LC601
	bl	printf
	mov	w1, 1
	adrp	x0, .LC602
	add	x0, x0, :lo12:.LC602
	bl	printf
	adrp	x0, .LC603
	add	x0, x0, :lo12:.LC603
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC604
	add	x0, x0, :lo12:.LC604
	bl	printf
	mov	w1, 0
	adrp	x0, .LC605
	add	x0, x0, :lo12:.LC605
	bl	printf
	mov	x1, 4
	adrp	x0, .LC606
	add	x0, x0, :lo12:.LC606
	bl	printf
	mov	w1, 1
	adrp	x0, .LC607
	add	x0, x0, :lo12:.LC607
	bl	printf
	adrp	x0, .LC608
	add	x0, x0, :lo12:.LC608
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC609
	add	x0, x0, :lo12:.LC609
	bl	printf
	mov	w1, 0
	adrp	x0, .LC610
	add	x0, x0, :lo12:.LC610
	bl	printf
	mov	x1, 4
	adrp	x0, .LC611
	add	x0, x0, :lo12:.LC611
	bl	printf
	mov	w1, 1
	adrp	x0, .LC612
	add	x0, x0, :lo12:.LC612
	bl	printf
	adrp	x0, .LC613
	add	x0, x0, :lo12:.LC613
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC614
	add	x0, x0, :lo12:.LC614
	bl	printf
	mov	w1, 0
	adrp	x0, .LC615
	add	x0, x0, :lo12:.LC615
	bl	printf
	mov	x1, 4
	adrp	x0, .LC616
	add	x0, x0, :lo12:.LC616
	bl	printf
	mov	w1, 1
	adrp	x0, .LC617
	add	x0, x0, :lo12:.LC617
	bl	printf
	adrp	x0, .LC618
	add	x0, x0, :lo12:.LC618
	bl	printf
	mov	x1, 0
	mov	x0, 65536
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC619
	add	x0, x0, :lo12:.LC619
	bl	printf
	mov	w1, 0
	adrp	x0, .LC620
	add	x0, x0, :lo12:.LC620
	bl	printf
	mov	x1, 4
	adrp	x0, .LC621
	add	x0, x0, :lo12:.LC621
	bl	printf
	mov	w1, 1
	adrp	x0, .LC622
	add	x0, x0, :lo12:.LC622
	bl	printf
	adrp	x0, .LC623
	add	x0, x0, :lo12:.LC623
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC624
	add	x0, x0, :lo12:.LC624
	bl	printf
	mov	w1, 0
	adrp	x0, .LC625
	add	x0, x0, :lo12:.LC625
	bl	printf
	mov	x1, 4
	adrp	x0, .LC626
	add	x0, x0, :lo12:.LC626
	bl	printf
	mov	w1, 1
	adrp	x0, .LC627
	add	x0, x0, :lo12:.LC627
	bl	printf
	adrp	x0, .LC628
	add	x0, x0, :lo12:.LC628
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC629
	add	x0, x0, :lo12:.LC629
	bl	printf
	mov	w1, 0
	adrp	x0, .LC630
	add	x0, x0, :lo12:.LC630
	bl	printf
	mov	x1, 4
	adrp	x0, .LC631
	add	x0, x0, :lo12:.LC631
	bl	printf
	mov	w1, 1
	adrp	x0, .LC632
	add	x0, x0, :lo12:.LC632
	bl	printf
	adrp	x0, .LC633
	add	x0, x0, :lo12:.LC633
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC634
	add	x0, x0, :lo12:.LC634
	bl	printf
	mov	w1, 0
	adrp	x0, .LC635
	add	x0, x0, :lo12:.LC635
	bl	printf
	mov	x1, 4
	adrp	x0, .LC636
	add	x0, x0, :lo12:.LC636
	bl	printf
	mov	w1, 1
	adrp	x0, .LC637
	add	x0, x0, :lo12:.LC637
	bl	printf
	adrp	x0, .LC638
	add	x0, x0, :lo12:.LC638
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC639
	add	x0, x0, :lo12:.LC639
	bl	printf
	mov	w1, 0
	adrp	x0, .LC640
	add	x0, x0, :lo12:.LC640
	bl	printf
	mov	x1, 4
	adrp	x0, .LC641
	add	x0, x0, :lo12:.LC641
	bl	printf
	mov	w1, 1
	adrp	x0, .LC642
	add	x0, x0, :lo12:.LC642
	bl	printf
	adrp	x0, .LC643
	add	x0, x0, :lo12:.LC643
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC644
	add	x0, x0, :lo12:.LC644
	bl	printf
	mov	w1, 0
	adrp	x0, .LC645
	add	x0, x0, :lo12:.LC645
	bl	printf
	mov	x1, 4
	adrp	x0, .LC646
	add	x0, x0, :lo12:.LC646
	bl	printf
	mov	w1, 1
	adrp	x0, .LC647
	add	x0, x0, :lo12:.LC647
	bl	printf
	adrp	x0, .LC648
	add	x0, x0, :lo12:.LC648
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC649
	add	x0, x0, :lo12:.LC649
	bl	printf
	mov	w1, 0
	adrp	x0, .LC650
	add	x0, x0, :lo12:.LC650
	bl	printf
	mov	x1, 4
	adrp	x0, .LC651
	add	x0, x0, :lo12:.LC651
	bl	printf
	mov	w1, 1
	adrp	x0, .LC652
	add	x0, x0, :lo12:.LC652
	bl	printf
	adrp	x0, .LC653
	add	x0, x0, :lo12:.LC653
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC654
	add	x0, x0, :lo12:.LC654
	bl	printf
	mov	w1, 0
	adrp	x0, .LC655
	add	x0, x0, :lo12:.LC655
	bl	printf
	mov	x1, 4
	adrp	x0, .LC656
	add	x0, x0, :lo12:.LC656
	bl	printf
	mov	w1, 1
	adrp	x0, .LC657
	add	x0, x0, :lo12:.LC657
	bl	printf
	adrp	x0, .LC658
	add	x0, x0, :lo12:.LC658
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC659
	add	x0, x0, :lo12:.LC659
	bl	printf
	mov	w1, 0
	adrp	x0, .LC660
	add	x0, x0, :lo12:.LC660
	bl	printf
	mov	x1, 4
	adrp	x0, .LC661
	add	x0, x0, :lo12:.LC661
	bl	printf
	mov	w1, 1
	adrp	x0, .LC662
	add	x0, x0, :lo12:.LC662
	bl	printf
	adrp	x0, .LC663
	add	x0, x0, :lo12:.LC663
	bl	printf
	mov	x1, 0
	mov	x0, 2097152
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC664
	add	x0, x0, :lo12:.LC664
	bl	printf
	mov	w1, 0
	adrp	x0, .LC665
	add	x0, x0, :lo12:.LC665
	bl	printf
	mov	x1, 4
	adrp	x0, .LC666
	add	x0, x0, :lo12:.LC666
	bl	printf
	mov	w1, 1
	adrp	x0, .LC667
	add	x0, x0, :lo12:.LC667
	bl	printf
	adrp	x0, .LC668
	add	x0, x0, :lo12:.LC668
	bl	printf
	mov	x1, 0
	mov	x0, 1048576
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC669
	add	x0, x0, :lo12:.LC669
	bl	printf
	mov	w1, 0
	adrp	x0, .LC670
	add	x0, x0, :lo12:.LC670
	bl	printf
	mov	x1, 4
	adrp	x0, .LC671
	add	x0, x0, :lo12:.LC671
	bl	printf
	mov	w1, 1
	adrp	x0, .LC672
	add	x0, x0, :lo12:.LC672
	bl	printf
	adrp	x0, .LC673
	add	x0, x0, :lo12:.LC673
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC674
	add	x0, x0, :lo12:.LC674
	bl	printf
	mov	w1, 0
	adrp	x0, .LC675
	add	x0, x0, :lo12:.LC675
	bl	printf
	mov	x1, 4
	adrp	x0, .LC676
	add	x0, x0, :lo12:.LC676
	bl	printf
	mov	w1, 1
	adrp	x0, .LC677
	add	x0, x0, :lo12:.LC677
	bl	printf
	adrp	x0, .LC678
	add	x0, x0, :lo12:.LC678
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC679
	add	x0, x0, :lo12:.LC679
	bl	printf
	mov	w1, 0
	adrp	x0, .LC680
	add	x0, x0, :lo12:.LC680
	bl	printf
	mov	x1, 4
	adrp	x0, .LC681
	add	x0, x0, :lo12:.LC681
	bl	printf
	mov	w1, 1
	adrp	x0, .LC682
	add	x0, x0, :lo12:.LC682
	bl	printf
	adrp	x0, .LC683
	add	x0, x0, :lo12:.LC683
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC684
	add	x0, x0, :lo12:.LC684
	bl	printf
	mov	w1, 0
	adrp	x0, .LC685
	add	x0, x0, :lo12:.LC685
	bl	printf
	mov	x1, 4
	adrp	x0, .LC686
	add	x0, x0, :lo12:.LC686
	bl	printf
	mov	w1, 1
	adrp	x0, .LC687
	add	x0, x0, :lo12:.LC687
	bl	printf
	adrp	x0, .LC688
	add	x0, x0, :lo12:.LC688
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC689
	add	x0, x0, :lo12:.LC689
	bl	printf
	mov	w1, 0
	adrp	x0, .LC690
	add	x0, x0, :lo12:.LC690
	bl	printf
	mov	x1, 4
	adrp	x0, .LC691
	add	x0, x0, :lo12:.LC691
	bl	printf
	mov	w1, 1
	adrp	x0, .LC692
	add	x0, x0, :lo12:.LC692
	bl	printf
	adrp	x0, .LC693
	add	x0, x0, :lo12:.LC693
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC694
	add	x0, x0, :lo12:.LC694
	bl	printf
	mov	w1, 0
	adrp	x0, .LC695
	add	x0, x0, :lo12:.LC695
	bl	printf
	mov	x1, 4
	adrp	x0, .LC696
	add	x0, x0, :lo12:.LC696
	bl	printf
	mov	w1, 1
	adrp	x0, .LC697
	add	x0, x0, :lo12:.LC697
	bl	printf
	adrp	x0, .LC698
	add	x0, x0, :lo12:.LC698
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC699
	add	x0, x0, :lo12:.LC699
	bl	printf
	mov	w1, 0
	adrp	x0, .LC700
	add	x0, x0, :lo12:.LC700
	bl	printf
	mov	x1, 4
	adrp	x0, .LC701
	add	x0, x0, :lo12:.LC701
	bl	printf
	mov	w1, 1
	adrp	x0, .LC702
	add	x0, x0, :lo12:.LC702
	bl	printf
	adrp	x0, .LC703
	add	x0, x0, :lo12:.LC703
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC704
	add	x0, x0, :lo12:.LC704
	bl	printf
	mov	w1, 0
	adrp	x0, .LC705
	add	x0, x0, :lo12:.LC705
	bl	printf
	mov	x1, 4
	adrp	x0, .LC706
	add	x0, x0, :lo12:.LC706
	bl	printf
	mov	w1, 1
	adrp	x0, .LC707
	add	x0, x0, :lo12:.LC707
	bl	printf
	adrp	x0, .LC708
	add	x0, x0, :lo12:.LC708
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC709
	add	x0, x0, :lo12:.LC709
	bl	printf
	mov	w1, 0
	adrp	x0, .LC710
	add	x0, x0, :lo12:.LC710
	bl	printf
	mov	x1, 4
	adrp	x0, .LC711
	add	x0, x0, :lo12:.LC711
	bl	printf
	mov	w1, 1
	adrp	x0, .LC712
	add	x0, x0, :lo12:.LC712
	bl	printf
	adrp	x0, .LC713
	add	x0, x0, :lo12:.LC713
	bl	printf
	mov	x1, 0
	mov	x0, 524288
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC714
	add	x0, x0, :lo12:.LC714
	bl	printf
	mov	w1, 0
	adrp	x0, .LC715
	add	x0, x0, :lo12:.LC715
	bl	printf
	mov	x1, 4
	adrp	x0, .LC716
	add	x0, x0, :lo12:.LC716
	bl	printf
	mov	w1, 1
	adrp	x0, .LC717
	add	x0, x0, :lo12:.LC717
	bl	printf
	adrp	x0, .LC718
	add	x0, x0, :lo12:.LC718
	bl	printf
	mov	x1, 0
	mov	x0, 1024
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC719
	add	x0, x0, :lo12:.LC719
	bl	printf
	mov	w1, 0
	adrp	x0, .LC720
	add	x0, x0, :lo12:.LC720
	bl	printf
	mov	x1, 4
	adrp	x0, .LC721
	add	x0, x0, :lo12:.LC721
	bl	printf
	mov	w1, 1
	adrp	x0, .LC722
	add	x0, x0, :lo12:.LC722
	bl	printf
	adrp	x0, .LC723
	add	x0, x0, :lo12:.LC723
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC724
	add	x0, x0, :lo12:.LC724
	bl	printf
	mov	w1, 0
	adrp	x0, .LC725
	add	x0, x0, :lo12:.LC725
	bl	printf
	mov	x1, 4
	adrp	x0, .LC726
	add	x0, x0, :lo12:.LC726
	bl	printf
	mov	w1, 1
	adrp	x0, .LC727
	add	x0, x0, :lo12:.LC727
	bl	printf
	adrp	x0, .LC728
	add	x0, x0, :lo12:.LC728
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC729
	add	x0, x0, :lo12:.LC729
	bl	printf
	mov	w1, 0
	adrp	x0, .LC730
	add	x0, x0, :lo12:.LC730
	bl	printf
	mov	x1, 4
	adrp	x0, .LC731
	add	x0, x0, :lo12:.LC731
	bl	printf
	mov	w1, 1
	adrp	x0, .LC732
	add	x0, x0, :lo12:.LC732
	bl	printf
	adrp	x0, .LC733
	add	x0, x0, :lo12:.LC733
	bl	printf
	mov	x1, 0
	mov	x0, 4194304
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC734
	add	x0, x0, :lo12:.LC734
	bl	printf
	mov	w1, 0
	adrp	x0, .LC735
	add	x0, x0, :lo12:.LC735
	bl	printf
	mov	x1, 4
	adrp	x0, .LC736
	add	x0, x0, :lo12:.LC736
	bl	printf
	mov	w1, 1
	adrp	x0, .LC737
	add	x0, x0, :lo12:.LC737
	bl	printf
	adrp	x0, .LC738
	add	x0, x0, :lo12:.LC738
	bl	printf
	mov	x1, 0
	mov	x0, 8388608
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC739
	add	x0, x0, :lo12:.LC739
	bl	printf
	mov	w1, 0
	adrp	x0, .LC740
	add	x0, x0, :lo12:.LC740
	bl	printf
	mov	x1, 4
	adrp	x0, .LC741
	add	x0, x0, :lo12:.LC741
	bl	printf
	mov	w1, 1
	adrp	x0, .LC742
	add	x0, x0, :lo12:.LC742
	bl	printf
	adrp	x0, .LC743
	add	x0, x0, :lo12:.LC743
	bl	printf
	mov	x1, 0
	mov	x0, 16777216
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC744
	add	x0, x0, :lo12:.LC744
	bl	printf
	mov	w1, 0
	adrp	x0, .LC745
	add	x0, x0, :lo12:.LC745
	bl	printf
	mov	x1, 4
	adrp	x0, .LC746
	add	x0, x0, :lo12:.LC746
	bl	printf
	mov	w1, 1
	adrp	x0, .LC747
	add	x0, x0, :lo12:.LC747
	bl	printf
	adrp	x0, .LC748
	add	x0, x0, :lo12:.LC748
	bl	printf
	mov	x1, 0
	mov	x0, 2048
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC749
	add	x0, x0, :lo12:.LC749
	bl	printf
	mov	w1, 0
	adrp	x0, .LC750
	add	x0, x0, :lo12:.LC750
	bl	printf
	mov	x1, 4
	adrp	x0, .LC751
	add	x0, x0, :lo12:.LC751
	bl	printf
	mov	w1, 1
	adrp	x0, .LC752
	add	x0, x0, :lo12:.LC752
	bl	printf
	adrp	x0, .LC753
	add	x0, x0, :lo12:.LC753
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC754
	add	x0, x0, :lo12:.LC754
	bl	printf
	mov	w1, 0
	adrp	x0, .LC755
	add	x0, x0, :lo12:.LC755
	bl	printf
	mov	x1, 4
	adrp	x0, .LC756
	add	x0, x0, :lo12:.LC756
	bl	printf
	mov	w1, 1
	adrp	x0, .LC757
	add	x0, x0, :lo12:.LC757
	bl	printf
	adrp	x0, .LC758
	add	x0, x0, :lo12:.LC758
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC759
	add	x0, x0, :lo12:.LC759
	bl	printf
	mov	w1, 0
	adrp	x0, .LC760
	add	x0, x0, :lo12:.LC760
	bl	printf
	mov	x1, 4
	adrp	x0, .LC761
	add	x0, x0, :lo12:.LC761
	bl	printf
	mov	w1, 1
	adrp	x0, .LC762
	add	x0, x0, :lo12:.LC762
	bl	printf
	adrp	x0, .LC763
	add	x0, x0, :lo12:.LC763
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC764
	add	x0, x0, :lo12:.LC764
	bl	printf
	mov	w1, 0
	adrp	x0, .LC765
	add	x0, x0, :lo12:.LC765
	bl	printf
	mov	x1, 4
	adrp	x0, .LC766
	add	x0, x0, :lo12:.LC766
	bl	printf
	mov	w1, 1
	adrp	x0, .LC767
	add	x0, x0, :lo12:.LC767
	bl	printf
	adrp	x0, .LC768
	add	x0, x0, :lo12:.LC768
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC769
	add	x0, x0, :lo12:.LC769
	bl	printf
	mov	w1, 0
	adrp	x0, .LC770
	add	x0, x0, :lo12:.LC770
	bl	printf
	mov	x1, 4
	adrp	x0, .LC771
	add	x0, x0, :lo12:.LC771
	bl	printf
	mov	w1, 1
	adrp	x0, .LC772
	add	x0, x0, :lo12:.LC772
	bl	printf
	adrp	x0, .LC773
	add	x0, x0, :lo12:.LC773
	bl	printf
	mov	x1, 0
	mov	x0, 65536
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC774
	add	x0, x0, :lo12:.LC774
	bl	printf
	mov	w1, 0
	adrp	x0, .LC775
	add	x0, x0, :lo12:.LC775
	bl	printf
	mov	x1, 4
	adrp	x0, .LC776
	add	x0, x0, :lo12:.LC776
	bl	printf
	mov	w1, 1
	adrp	x0, .LC777
	add	x0, x0, :lo12:.LC777
	bl	printf
	adrp	x0, .LC778
	add	x0, x0, :lo12:.LC778
	bl	printf
	mov	x1, 0
	mov	x0, 131072
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC779
	add	x0, x0, :lo12:.LC779
	bl	printf
	mov	w1, 0
	adrp	x0, .LC780
	add	x0, x0, :lo12:.LC780
	bl	printf
	mov	x1, 4
	adrp	x0, .LC781
	add	x0, x0, :lo12:.LC781
	bl	printf
	mov	w1, 1
	adrp	x0, .LC782
	add	x0, x0, :lo12:.LC782
	bl	printf
	adrp	x0, .LC783
	add	x0, x0, :lo12:.LC783
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC784
	add	x0, x0, :lo12:.LC784
	bl	printf
	mov	w1, 0
	adrp	x0, .LC785
	add	x0, x0, :lo12:.LC785
	bl	printf
	mov	x1, 4
	adrp	x0, .LC786
	add	x0, x0, :lo12:.LC786
	bl	printf
	mov	w1, 1
	adrp	x0, .LC787
	add	x0, x0, :lo12:.LC787
	bl	printf
	adrp	x0, .LC788
	add	x0, x0, :lo12:.LC788
	bl	printf
	mov	x1, 0
	mov	x0, 262144
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC789
	add	x0, x0, :lo12:.LC789
	bl	printf
	mov	w1, 0
	adrp	x0, .LC790
	add	x0, x0, :lo12:.LC790
	bl	printf
	mov	x1, 4
	adrp	x0, .LC791
	add	x0, x0, :lo12:.LC791
	bl	printf
	mov	w1, 1
	adrp	x0, .LC792
	add	x0, x0, :lo12:.LC792
	bl	printf
	adrp	x0, .LC793
	add	x0, x0, :lo12:.LC793
	bl	printf
	mov	x1, 0
	mov	x0, 43
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC794
	add	x0, x0, :lo12:.LC794
	bl	printf
	mov	w1, 0
	adrp	x0, .LC795
	add	x0, x0, :lo12:.LC795
	bl	printf
	mov	x1, 4
	adrp	x0, .LC796
	add	x0, x0, :lo12:.LC796
	bl	printf
	mov	w1, 1
	adrp	x0, .LC797
	add	x0, x0, :lo12:.LC797
	bl	printf
	adrp	x0, .LC798
	add	x0, x0, :lo12:.LC798
	bl	printf
	mov	x1, 0
	mov	x0, 62
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC799
	add	x0, x0, :lo12:.LC799
	bl	printf
	mov	w1, 0
	adrp	x0, .LC800
	add	x0, x0, :lo12:.LC800
	bl	printf
	mov	x1, 4
	adrp	x0, .LC801
	add	x0, x0, :lo12:.LC801
	bl	printf
	mov	w1, 1
	adrp	x0, .LC802
	add	x0, x0, :lo12:.LC802
	bl	printf
	adrp	x0, .LC803
	add	x0, x0, :lo12:.LC803
	bl	printf
	mov	x1, 0
	mov	x0, 66
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC804
	add	x0, x0, :lo12:.LC804
	bl	printf
	mov	w1, 0
	adrp	x0, .LC805
	add	x0, x0, :lo12:.LC805
	bl	printf
	mov	x1, 4
	adrp	x0, .LC806
	add	x0, x0, :lo12:.LC806
	bl	printf
	mov	w1, 1
	adrp	x0, .LC807
	add	x0, x0, :lo12:.LC807
	bl	printf
	adrp	x0, .LC808
	add	x0, x0, :lo12:.LC808
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC809
	add	x0, x0, :lo12:.LC809
	bl	printf
	mov	w1, 0
	adrp	x0, .LC810
	add	x0, x0, :lo12:.LC810
	bl	printf
	mov	x1, 4
	adrp	x0, .LC811
	add	x0, x0, :lo12:.LC811
	bl	printf
	mov	w1, 1
	adrp	x0, .LC812
	add	x0, x0, :lo12:.LC812
	bl	printf
	adrp	x0, .LC813
	add	x0, x0, :lo12:.LC813
	bl	printf
	mov	x1, 0
	mov	x0, 61
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC814
	add	x0, x0, :lo12:.LC814
	bl	printf
	mov	w1, 0
	adrp	x0, .LC815
	add	x0, x0, :lo12:.LC815
	bl	printf
	mov	x1, 4
	adrp	x0, .LC816
	add	x0, x0, :lo12:.LC816
	bl	printf
	mov	w1, 1
	adrp	x0, .LC817
	add	x0, x0, :lo12:.LC817
	bl	printf
	adrp	x0, .LC818
	add	x0, x0, :lo12:.LC818
	bl	printf
	mov	x1, 0
	mov	x0, 45
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC819
	add	x0, x0, :lo12:.LC819
	bl	printf
	mov	w1, 0
	adrp	x0, .LC820
	add	x0, x0, :lo12:.LC820
	bl	printf
	mov	x1, 4
	adrp	x0, .LC821
	add	x0, x0, :lo12:.LC821
	bl	printf
	mov	w1, 1
	adrp	x0, .LC822
	add	x0, x0, :lo12:.LC822
	bl	printf
	adrp	x0, .LC823
	add	x0, x0, :lo12:.LC823
	bl	printf
	mov	x1, 0
	mov	x0, 60
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC824
	add	x0, x0, :lo12:.LC824
	bl	printf
	mov	w1, 0
	adrp	x0, .LC825
	add	x0, x0, :lo12:.LC825
	bl	printf
	mov	x1, 4
	adrp	x0, .LC826
	add	x0, x0, :lo12:.LC826
	bl	printf
	mov	w1, 1
	adrp	x0, .LC827
	add	x0, x0, :lo12:.LC827
	bl	printf
	adrp	x0, .LC828
	add	x0, x0, :lo12:.LC828
	bl	printf
	mov	x1, 0
	mov	x0, 70
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC829
	add	x0, x0, :lo12:.LC829
	bl	printf
	mov	w1, 0
	adrp	x0, .LC830
	add	x0, x0, :lo12:.LC830
	bl	printf
	mov	x1, 4
	adrp	x0, .LC831
	add	x0, x0, :lo12:.LC831
	bl	printf
	mov	w1, 1
	adrp	x0, .LC832
	add	x0, x0, :lo12:.LC832
	bl	printf
	adrp	x0, .LC833
	add	x0, x0, :lo12:.LC833
	bl	printf
	mov	x1, 0
	mov	x0, 72
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC834
	add	x0, x0, :lo12:.LC834
	bl	printf
	mov	w1, 0
	adrp	x0, .LC835
	add	x0, x0, :lo12:.LC835
	bl	printf
	mov	x1, 4
	adrp	x0, .LC836
	add	x0, x0, :lo12:.LC836
	bl	printf
	mov	w1, 1
	adrp	x0, .LC837
	add	x0, x0, :lo12:.LC837
	bl	printf
	adrp	x0, .LC838
	add	x0, x0, :lo12:.LC838
	bl	printf
	mov	x1, 0
	mov	x0, 536870912
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC839
	add	x0, x0, :lo12:.LC839
	bl	printf
	mov	w1, 0
	adrp	x0, .LC840
	add	x0, x0, :lo12:.LC840
	bl	printf
	mov	x1, 4
	adrp	x0, .LC841
	add	x0, x0, :lo12:.LC841
	bl	printf
	mov	w1, 1
	adrp	x0, .LC842
	add	x0, x0, :lo12:.LC842
	bl	printf
	adrp	x0, .LC843
	add	x0, x0, :lo12:.LC843
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC844
	add	x0, x0, :lo12:.LC844
	bl	printf
	mov	w1, 0
	adrp	x0, .LC845
	add	x0, x0, :lo12:.LC845
	bl	printf
	mov	x1, 4
	adrp	x0, .LC846
	add	x0, x0, :lo12:.LC846
	bl	printf
	mov	w1, 1
	adrp	x0, .LC847
	add	x0, x0, :lo12:.LC847
	bl	printf
	adrp	x0, .LC848
	add	x0, x0, :lo12:.LC848
	bl	printf
	mov	x1, 0
	mov	x0, 268435456
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC849
	add	x0, x0, :lo12:.LC849
	bl	printf
	mov	w1, 0
	adrp	x0, .LC850
	add	x0, x0, :lo12:.LC850
	bl	printf
	mov	x1, 4
	adrp	x0, .LC851
	add	x0, x0, :lo12:.LC851
	bl	printf
	mov	w1, 1
	adrp	x0, .LC852
	add	x0, x0, :lo12:.LC852
	bl	printf
	adrp	x0, .LC853
	add	x0, x0, :lo12:.LC853
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC854
	add	x0, x0, :lo12:.LC854
	bl	printf
	mov	w1, 0
	adrp	x0, .LC855
	add	x0, x0, :lo12:.LC855
	bl	printf
	mov	x1, 4
	adrp	x0, .LC856
	add	x0, x0, :lo12:.LC856
	bl	printf
	mov	w1, 1
	adrp	x0, .LC857
	add	x0, x0, :lo12:.LC857
	bl	printf
	adrp	x0, .LC858
	add	x0, x0, :lo12:.LC858
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC859
	add	x0, x0, :lo12:.LC859
	bl	printf
	mov	w1, 0
	adrp	x0, .LC860
	add	x0, x0, :lo12:.LC860
	bl	printf
	mov	x1, 4
	adrp	x0, .LC861
	add	x0, x0, :lo12:.LC861
	bl	printf
	mov	w1, 1
	adrp	x0, .LC862
	add	x0, x0, :lo12:.LC862
	bl	printf
	adrp	x0, .LC863
	add	x0, x0, :lo12:.LC863
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC864
	add	x0, x0, :lo12:.LC864
	bl	printf
	mov	w1, 0
	adrp	x0, .LC865
	add	x0, x0, :lo12:.LC865
	bl	printf
	mov	x1, 4
	adrp	x0, .LC866
	add	x0, x0, :lo12:.LC866
	bl	printf
	mov	w1, 1
	adrp	x0, .LC867
	add	x0, x0, :lo12:.LC867
	bl	printf
	adrp	x0, .LC868
	add	x0, x0, :lo12:.LC868
	bl	printf
	mov	x1, 0
	mov	x0, 1073741824
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC869
	add	x0, x0, :lo12:.LC869
	bl	printf
	mov	w1, 0
	adrp	x0, .LC870
	add	x0, x0, :lo12:.LC870
	bl	printf
	mov	x1, 4
	adrp	x0, .LC871
	add	x0, x0, :lo12:.LC871
	bl	printf
	mov	w1, 1
	adrp	x0, .LC872
	add	x0, x0, :lo12:.LC872
	bl	printf
	adrp	x0, .LC873
	add	x0, x0, :lo12:.LC873
	bl	printf
	mov	x1, 0
	mov	x0, 67108864
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC874
	add	x0, x0, :lo12:.LC874
	bl	printf
	mov	w1, 0
	adrp	x0, .LC875
	add	x0, x0, :lo12:.LC875
	bl	printf
	mov	x1, 4
	adrp	x0, .LC876
	add	x0, x0, :lo12:.LC876
	bl	printf
	mov	w1, 1
	adrp	x0, .LC877
	add	x0, x0, :lo12:.LC877
	bl	printf
	adrp	x0, .LC878
	add	x0, x0, :lo12:.LC878
	bl	printf
	mov	x1, 0
	mov	x0, 33554432
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC879
	add	x0, x0, :lo12:.LC879
	bl	printf
	mov	w1, 0
	adrp	x0, .LC880
	add	x0, x0, :lo12:.LC880
	bl	printf
	mov	x1, 4
	adrp	x0, .LC881
	add	x0, x0, :lo12:.LC881
	bl	printf
	mov	w1, 1
	adrp	x0, .LC882
	add	x0, x0, :lo12:.LC882
	bl	printf
	adrp	x0, .LC883
	add	x0, x0, :lo12:.LC883
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC884
	add	x0, x0, :lo12:.LC884
	bl	printf
	mov	w1, 0
	adrp	x0, .LC885
	add	x0, x0, :lo12:.LC885
	bl	printf
	mov	x1, 4
	adrp	x0, .LC886
	add	x0, x0, :lo12:.LC886
	bl	printf
	mov	w1, 1
	adrp	x0, .LC887
	add	x0, x0, :lo12:.LC887
	bl	printf
	adrp	x0, .LC888
	add	x0, x0, :lo12:.LC888
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC889
	add	x0, x0, :lo12:.LC889
	bl	printf
	mov	w1, 0
	adrp	x0, .LC890
	add	x0, x0, :lo12:.LC890
	bl	printf
	mov	x1, 4
	adrp	x0, .LC891
	add	x0, x0, :lo12:.LC891
	bl	printf
	mov	w1, 1
	adrp	x0, .LC892
	add	x0, x0, :lo12:.LC892
	bl	printf
	adrp	x0, .LC893
	add	x0, x0, :lo12:.LC893
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC894
	add	x0, x0, :lo12:.LC894
	bl	printf
	mov	w1, 0
	adrp	x0, .LC895
	add	x0, x0, :lo12:.LC895
	bl	printf
	mov	x1, 4
	adrp	x0, .LC896
	add	x0, x0, :lo12:.LC896
	bl	printf
	mov	w1, 1
	adrp	x0, .LC897
	add	x0, x0, :lo12:.LC897
	bl	printf
	adrp	x0, .LC898
	add	x0, x0, :lo12:.LC898
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC899
	add	x0, x0, :lo12:.LC899
	bl	printf
	mov	w1, 0
	adrp	x0, .LC900
	add	x0, x0, :lo12:.LC900
	bl	printf
	mov	x1, 4
	adrp	x0, .LC901
	add	x0, x0, :lo12:.LC901
	bl	printf
	mov	w1, 1
	adrp	x0, .LC902
	add	x0, x0, :lo12:.LC902
	bl	printf
	adrp	x0, .LC903
	add	x0, x0, :lo12:.LC903
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC904
	add	x0, x0, :lo12:.LC904
	bl	printf
	mov	w1, 0
	adrp	x0, .LC905
	add	x0, x0, :lo12:.LC905
	bl	printf
	mov	x1, 4
	adrp	x0, .LC906
	add	x0, x0, :lo12:.LC906
	bl	printf
	mov	w1, 1
	adrp	x0, .LC907
	add	x0, x0, :lo12:.LC907
	bl	printf
	adrp	x0, .LC908
	add	x0, x0, :lo12:.LC908
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC909
	add	x0, x0, :lo12:.LC909
	bl	printf
	mov	w1, 0
	adrp	x0, .LC910
	add	x0, x0, :lo12:.LC910
	bl	printf
	mov	x1, 4
	adrp	x0, .LC911
	add	x0, x0, :lo12:.LC911
	bl	printf
	mov	w1, 1
	adrp	x0, .LC912
	add	x0, x0, :lo12:.LC912
	bl	printf
	adrp	x0, .LC913
	add	x0, x0, :lo12:.LC913
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC914
	add	x0, x0, :lo12:.LC914
	bl	printf
	mov	w1, 0
	adrp	x0, .LC915
	add	x0, x0, :lo12:.LC915
	bl	printf
	mov	x1, 4
	adrp	x0, .LC916
	add	x0, x0, :lo12:.LC916
	bl	printf
	mov	w1, 1
	adrp	x0, .LC917
	add	x0, x0, :lo12:.LC917
	bl	printf
	adrp	x0, .LC918
	add	x0, x0, :lo12:.LC918
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC919
	add	x0, x0, :lo12:.LC919
	bl	printf
	mov	w1, 0
	adrp	x0, .LC920
	add	x0, x0, :lo12:.LC920
	bl	printf
	mov	x1, 4
	adrp	x0, .LC921
	add	x0, x0, :lo12:.LC921
	bl	printf
	mov	w1, 1
	adrp	x0, .LC922
	add	x0, x0, :lo12:.LC922
	bl	printf
	adrp	x0, .LC923
	add	x0, x0, :lo12:.LC923
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC924
	add	x0, x0, :lo12:.LC924
	bl	printf
	mov	w1, 0
	adrp	x0, .LC925
	add	x0, x0, :lo12:.LC925
	bl	printf
	mov	x1, 4
	adrp	x0, .LC926
	add	x0, x0, :lo12:.LC926
	bl	printf
	mov	w1, 1
	adrp	x0, .LC927
	add	x0, x0, :lo12:.LC927
	bl	printf
	adrp	x0, .LC928
	add	x0, x0, :lo12:.LC928
	bl	printf
	mov	x1, -1
	mov	x0, -5
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC929
	add	x0, x0, :lo12:.LC929
	bl	printf
	mov	w1, 1
	adrp	x0, .LC930
	add	x0, x0, :lo12:.LC930
	bl	printf
	mov	x1, 4
	adrp	x0, .LC931
	add	x0, x0, :lo12:.LC931
	bl	printf
	mov	w1, 1
	adrp	x0, .LC932
	add	x0, x0, :lo12:.LC932
	bl	printf
	adrp	x0, .LC933
	add	x0, x0, :lo12:.LC933
	bl	printf
	mov	x1, -1
	mov	x0, -18
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC934
	add	x0, x0, :lo12:.LC934
	bl	printf
	mov	w1, 1
	adrp	x0, .LC935
	add	x0, x0, :lo12:.LC935
	bl	printf
	mov	x1, 4
	adrp	x0, .LC936
	add	x0, x0, :lo12:.LC936
	bl	printf
	mov	w1, 1
	adrp	x0, .LC937
	add	x0, x0, :lo12:.LC937
	bl	printf
	adrp	x0, .LC938
	add	x0, x0, :lo12:.LC938
	bl	printf
	mov	x1, -1
	mov	x0, -35
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC939
	add	x0, x0, :lo12:.LC939
	bl	printf
	mov	w1, 1
	adrp	x0, .LC940
	add	x0, x0, :lo12:.LC940
	bl	printf
	mov	x1, 4
	adrp	x0, .LC941
	add	x0, x0, :lo12:.LC941
	bl	printf
	mov	w1, 1
	adrp	x0, .LC942
	add	x0, x0, :lo12:.LC942
	bl	printf
	adrp	x0, .LC943
	add	x0, x0, :lo12:.LC943
	bl	printf
	mov	x1, -1
	mov	x0, -16
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC944
	add	x0, x0, :lo12:.LC944
	bl	printf
	mov	w1, 1
	adrp	x0, .LC945
	add	x0, x0, :lo12:.LC945
	bl	printf
	mov	x1, 4
	adrp	x0, .LC946
	add	x0, x0, :lo12:.LC946
	bl	printf
	mov	w1, 1
	adrp	x0, .LC947
	add	x0, x0, :lo12:.LC947
	bl	printf
	adrp	x0, .LC948
	add	x0, x0, :lo12:.LC948
	bl	printf
	mov	x1, -1
	mov	x0, -8
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC949
	add	x0, x0, :lo12:.LC949
	bl	printf
	mov	w1, 1
	adrp	x0, .LC950
	add	x0, x0, :lo12:.LC950
	bl	printf
	mov	x1, 4
	adrp	x0, .LC951
	add	x0, x0, :lo12:.LC951
	bl	printf
	mov	w1, 1
	adrp	x0, .LC952
	add	x0, x0, :lo12:.LC952
	bl	printf
	adrp	x0, .LC953
	add	x0, x0, :lo12:.LC953
	bl	printf
	mov	x1, -1
	mov	x0, -6
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC954
	add	x0, x0, :lo12:.LC954
	bl	printf
	mov	w1, 1
	adrp	x0, .LC955
	add	x0, x0, :lo12:.LC955
	bl	printf
	mov	x1, 4
	adrp	x0, .LC956
	add	x0, x0, :lo12:.LC956
	bl	printf
	mov	w1, 1
	adrp	x0, .LC957
	add	x0, x0, :lo12:.LC957
	bl	printf
	adrp	x0, .LC958
	add	x0, x0, :lo12:.LC958
	bl	printf
	mov	x1, -1
	mov	x0, -17
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC959
	add	x0, x0, :lo12:.LC959
	bl	printf
	mov	w1, 1
	adrp	x0, .LC960
	add	x0, x0, :lo12:.LC960
	bl	printf
	mov	x1, 4
	adrp	x0, .LC961
	add	x0, x0, :lo12:.LC961
	bl	printf
	mov	w1, 1
	adrp	x0, .LC962
	add	x0, x0, :lo12:.LC962
	bl	printf
	adrp	x0, .LC963
	add	x0, x0, :lo12:.LC963
	bl	printf
	mov	x1, -1
	mov	x0, -13
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC964
	add	x0, x0, :lo12:.LC964
	bl	printf
	mov	w1, 1
	adrp	x0, .LC965
	add	x0, x0, :lo12:.LC965
	bl	printf
	mov	x1, 4
	adrp	x0, .LC966
	add	x0, x0, :lo12:.LC966
	bl	printf
	mov	w1, 1
	adrp	x0, .LC967
	add	x0, x0, :lo12:.LC967
	bl	printf
	adrp	x0, .LC968
	add	x0, x0, :lo12:.LC968
	bl	printf
	mov	x1, -1
	mov	x0, -23
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC969
	add	x0, x0, :lo12:.LC969
	bl	printf
	mov	w1, 1
	adrp	x0, .LC970
	add	x0, x0, :lo12:.LC970
	bl	printf
	mov	x1, 4
	adrp	x0, .LC971
	add	x0, x0, :lo12:.LC971
	bl	printf
	mov	w1, 1
	adrp	x0, .LC972
	add	x0, x0, :lo12:.LC972
	bl	printf
	adrp	x0, .LC973
	add	x0, x0, :lo12:.LC973
	bl	printf
	mov	x1, -1
	mov	x0, -20
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC974
	add	x0, x0, :lo12:.LC974
	bl	printf
	mov	w1, 1
	adrp	x0, .LC975
	add	x0, x0, :lo12:.LC975
	bl	printf
	mov	x1, 4
	adrp	x0, .LC976
	add	x0, x0, :lo12:.LC976
	bl	printf
	mov	w1, 1
	adrp	x0, .LC977
	add	x0, x0, :lo12:.LC977
	bl	printf
	adrp	x0, .LC978
	add	x0, x0, :lo12:.LC978
	bl	printf
	mov	x1, -1
	mov	x0, -4
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC979
	add	x0, x0, :lo12:.LC979
	bl	printf
	mov	w1, 1
	adrp	x0, .LC980
	add	x0, x0, :lo12:.LC980
	bl	printf
	mov	x1, 4
	adrp	x0, .LC981
	add	x0, x0, :lo12:.LC981
	bl	printf
	mov	w1, 1
	adrp	x0, .LC982
	add	x0, x0, :lo12:.LC982
	bl	printf
	adrp	x0, .LC983
	add	x0, x0, :lo12:.LC983
	bl	printf
	mov	x1, -1
	mov	x0, -34
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC984
	add	x0, x0, :lo12:.LC984
	bl	printf
	mov	w1, 1
	adrp	x0, .LC985
	add	x0, x0, :lo12:.LC985
	bl	printf
	mov	x1, 4
	adrp	x0, .LC986
	add	x0, x0, :lo12:.LC986
	bl	printf
	mov	w1, 1
	adrp	x0, .LC987
	add	x0, x0, :lo12:.LC987
	bl	printf
	adrp	x0, .LC988
	add	x0, x0, :lo12:.LC988
	bl	printf
	mov	x1, -1
	mov	x0, -21
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC989
	add	x0, x0, :lo12:.LC989
	bl	printf
	mov	w1, 1
	adrp	x0, .LC990
	add	x0, x0, :lo12:.LC990
	bl	printf
	mov	x1, 4
	adrp	x0, .LC991
	add	x0, x0, :lo12:.LC991
	bl	printf
	mov	w1, 1
	adrp	x0, .LC992
	add	x0, x0, :lo12:.LC992
	bl	printf
	adrp	x0, .LC993
	add	x0, x0, :lo12:.LC993
	bl	printf
	mov	x1, -1
	mov	x0, -12
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC994
	add	x0, x0, :lo12:.LC994
	bl	printf
	mov	w1, 1
	adrp	x0, .LC995
	add	x0, x0, :lo12:.LC995
	bl	printf
	mov	x1, 4
	adrp	x0, .LC996
	add	x0, x0, :lo12:.LC996
	bl	printf
	mov	w1, 1
	adrp	x0, .LC997
	add	x0, x0, :lo12:.LC997
	bl	printf
	adrp	x0, .LC998
	add	x0, x0, :lo12:.LC998
	bl	printf
	mov	x1, -1
	mov	x0, -14
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC999
	add	x0, x0, :lo12:.LC999
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1000
	add	x0, x0, :lo12:.LC1000
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1001
	add	x0, x0, :lo12:.LC1001
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1002
	add	x0, x0, :lo12:.LC1002
	bl	printf
	adrp	x0, .LC1003
	add	x0, x0, :lo12:.LC1003
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1004
	add	x0, x0, :lo12:.LC1004
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1005
	add	x0, x0, :lo12:.LC1005
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1006
	add	x0, x0, :lo12:.LC1006
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1007
	add	x0, x0, :lo12:.LC1007
	bl	printf
	adrp	x0, .LC1008
	add	x0, x0, :lo12:.LC1008
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1009
	add	x0, x0, :lo12:.LC1009
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1010
	add	x0, x0, :lo12:.LC1010
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1011
	add	x0, x0, :lo12:.LC1011
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1012
	add	x0, x0, :lo12:.LC1012
	bl	printf
	adrp	x0, .LC1013
	add	x0, x0, :lo12:.LC1013
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1014
	add	x0, x0, :lo12:.LC1014
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1015
	add	x0, x0, :lo12:.LC1015
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1016
	add	x0, x0, :lo12:.LC1016
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1017
	add	x0, x0, :lo12:.LC1017
	bl	printf
	adrp	x0, .LC1018
	add	x0, x0, :lo12:.LC1018
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1019
	add	x0, x0, :lo12:.LC1019
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1020
	add	x0, x0, :lo12:.LC1020
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1021
	add	x0, x0, :lo12:.LC1021
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1022
	add	x0, x0, :lo12:.LC1022
	bl	printf
	adrp	x0, .LC1023
	add	x0, x0, :lo12:.LC1023
	bl	printf
	mov	x1, -1
	mov	x0, -24
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1024
	add	x0, x0, :lo12:.LC1024
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1025
	add	x0, x0, :lo12:.LC1025
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1026
	add	x0, x0, :lo12:.LC1026
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1027
	add	x0, x0, :lo12:.LC1027
	bl	printf
	adrp	x0, .LC1028
	add	x0, x0, :lo12:.LC1028
	bl	printf
	mov	x1, -1
	mov	x0, -33
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1029
	add	x0, x0, :lo12:.LC1029
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1030
	add	x0, x0, :lo12:.LC1030
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1031
	add	x0, x0, :lo12:.LC1031
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1032
	add	x0, x0, :lo12:.LC1032
	bl	printf
	adrp	x0, .LC1033
	add	x0, x0, :lo12:.LC1033
	bl	printf
	mov	x1, -1
	mov	x0, -15
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1034
	add	x0, x0, :lo12:.LC1034
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1035
	add	x0, x0, :lo12:.LC1035
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1036
	add	x0, x0, :lo12:.LC1036
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1037
	add	x0, x0, :lo12:.LC1037
	bl	printf
	adrp	x0, .LC1038
	add	x0, x0, :lo12:.LC1038
	bl	printf
	mov	x1, -1
	mov	x0, -11
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1039
	add	x0, x0, :lo12:.LC1039
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1040
	add	x0, x0, :lo12:.LC1040
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1041
	add	x0, x0, :lo12:.LC1041
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1042
	add	x0, x0, :lo12:.LC1042
	bl	printf
	adrp	x0, .LC1043
	add	x0, x0, :lo12:.LC1043
	bl	printf
	mov	x1, -1
	mov	x0, -3
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1044
	add	x0, x0, :lo12:.LC1044
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1045
	add	x0, x0, :lo12:.LC1045
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1046
	add	x0, x0, :lo12:.LC1046
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1047
	add	x0, x0, :lo12:.LC1047
	bl	printf
	adrp	x0, .LC1048
	add	x0, x0, :lo12:.LC1048
	bl	printf
	mov	x1, -1
	mov	x0, -39
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1049
	add	x0, x0, :lo12:.LC1049
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1050
	add	x0, x0, :lo12:.LC1050
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1051
	add	x0, x0, :lo12:.LC1051
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1052
	add	x0, x0, :lo12:.LC1052
	bl	printf
	adrp	x0, .LC1053
	add	x0, x0, :lo12:.LC1053
	bl	printf
	mov	x1, -1
	mov	x0, -36
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1054
	add	x0, x0, :lo12:.LC1054
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1055
	add	x0, x0, :lo12:.LC1055
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1056
	add	x0, x0, :lo12:.LC1056
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1057
	add	x0, x0, :lo12:.LC1057
	bl	printf
	adrp	x0, .LC1058
	add	x0, x0, :lo12:.LC1058
	bl	printf
	mov	x1, -1
	mov	x0, -19
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1059
	add	x0, x0, :lo12:.LC1059
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1060
	add	x0, x0, :lo12:.LC1060
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1061
	add	x0, x0, :lo12:.LC1061
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1062
	add	x0, x0, :lo12:.LC1062
	bl	printf
	adrp	x0, .LC1063
	add	x0, x0, :lo12:.LC1063
	bl	printf
	mov	x1, -1
	mov	x0, -40
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1064
	add	x0, x0, :lo12:.LC1064
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1065
	add	x0, x0, :lo12:.LC1065
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1066
	add	x0, x0, :lo12:.LC1066
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1067
	add	x0, x0, :lo12:.LC1067
	bl	printf
	adrp	x0, .LC1068
	add	x0, x0, :lo12:.LC1068
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1069
	add	x0, x0, :lo12:.LC1069
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1070
	add	x0, x0, :lo12:.LC1070
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1071
	add	x0, x0, :lo12:.LC1071
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1072
	add	x0, x0, :lo12:.LC1072
	bl	printf
	adrp	x0, .LC1073
	add	x0, x0, :lo12:.LC1073
	bl	printf
	mov	x1, 0
	mov	x0, 26
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1074
	add	x0, x0, :lo12:.LC1074
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1075
	add	x0, x0, :lo12:.LC1075
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1076
	add	x0, x0, :lo12:.LC1076
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1077
	add	x0, x0, :lo12:.LC1077
	bl	printf
	adrp	x0, .LC1078
	add	x0, x0, :lo12:.LC1078
	bl	printf
	mov	x1, 0
	mov	x0, 20
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1079
	add	x0, x0, :lo12:.LC1079
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1080
	add	x0, x0, :lo12:.LC1080
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1081
	add	x0, x0, :lo12:.LC1081
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1082
	add	x0, x0, :lo12:.LC1082
	bl	printf
	adrp	x0, .LC1083
	add	x0, x0, :lo12:.LC1083
	bl	printf
	mov	x1, 0
	mov	x0, 27
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1084
	add	x0, x0, :lo12:.LC1084
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1085
	add	x0, x0, :lo12:.LC1085
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1086
	add	x0, x0, :lo12:.LC1086
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1087
	add	x0, x0, :lo12:.LC1087
	bl	printf
	adrp	x0, .LC1088
	add	x0, x0, :lo12:.LC1088
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1089
	add	x0, x0, :lo12:.LC1089
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1090
	add	x0, x0, :lo12:.LC1090
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1091
	add	x0, x0, :lo12:.LC1091
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1092
	add	x0, x0, :lo12:.LC1092
	bl	printf
	adrp	x0, .LC1093
	add	x0, x0, :lo12:.LC1093
	bl	printf
	mov	x1, 0
	mov	x0, 28
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1094
	add	x0, x0, :lo12:.LC1094
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1095
	add	x0, x0, :lo12:.LC1095
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1096
	add	x0, x0, :lo12:.LC1096
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1097
	add	x0, x0, :lo12:.LC1097
	bl	printf
	adrp	x0, .LC1098
	add	x0, x0, :lo12:.LC1098
	bl	printf
	mov	x1, 0
	mov	x0, 21
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1099
	add	x0, x0, :lo12:.LC1099
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1100
	add	x0, x0, :lo12:.LC1100
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1101
	add	x0, x0, :lo12:.LC1101
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1102
	add	x0, x0, :lo12:.LC1102
	bl	printf
	adrp	x0, .LC1103
	add	x0, x0, :lo12:.LC1103
	bl	printf
	mov	x1, 0
	mov	x0, 30
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1104
	add	x0, x0, :lo12:.LC1104
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1105
	add	x0, x0, :lo12:.LC1105
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1106
	add	x0, x0, :lo12:.LC1106
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1107
	add	x0, x0, :lo12:.LC1107
	bl	printf
	adrp	x0, .LC1108
	add	x0, x0, :lo12:.LC1108
	bl	printf
	mov	x1, 0
	mov	x0, 24
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1109
	add	x0, x0, :lo12:.LC1109
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1110
	add	x0, x0, :lo12:.LC1110
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1111
	add	x0, x0, :lo12:.LC1111
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1112
	add	x0, x0, :lo12:.LC1112
	bl	printf
	adrp	x0, .LC1113
	add	x0, x0, :lo12:.LC1113
	bl	printf
	mov	x1, 0
	mov	x0, 36
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1114
	add	x0, x0, :lo12:.LC1114
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1115
	add	x0, x0, :lo12:.LC1115
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1116
	add	x0, x0, :lo12:.LC1116
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1117
	add	x0, x0, :lo12:.LC1117
	bl	printf
	adrp	x0, .LC1118
	add	x0, x0, :lo12:.LC1118
	bl	printf
	mov	x1, 0
	mov	x0, 34
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1119
	add	x0, x0, :lo12:.LC1119
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1120
	add	x0, x0, :lo12:.LC1120
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1121
	add	x0, x0, :lo12:.LC1121
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1122
	add	x0, x0, :lo12:.LC1122
	bl	printf
	adrp	x0, .LC1123
	add	x0, x0, :lo12:.LC1123
	bl	printf
	mov	x1, 0
	mov	x0, 10
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1124
	add	x0, x0, :lo12:.LC1124
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1125
	add	x0, x0, :lo12:.LC1125
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1126
	add	x0, x0, :lo12:.LC1126
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1127
	add	x0, x0, :lo12:.LC1127
	bl	printf
	adrp	x0, .LC1128
	add	x0, x0, :lo12:.LC1128
	bl	printf
	mov	x1, 0
	mov	x0, 15
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1129
	add	x0, x0, :lo12:.LC1129
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1130
	add	x0, x0, :lo12:.LC1130
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1131
	add	x0, x0, :lo12:.LC1131
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1132
	add	x0, x0, :lo12:.LC1132
	bl	printf
	adrp	x0, .LC1133
	add	x0, x0, :lo12:.LC1133
	bl	printf
	mov	x1, 0
	mov	x0, 35
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1134
	add	x0, x0, :lo12:.LC1134
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1135
	add	x0, x0, :lo12:.LC1135
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1136
	add	x0, x0, :lo12:.LC1136
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1137
	add	x0, x0, :lo12:.LC1137
	bl	printf
	adrp	x0, .LC1138
	add	x0, x0, :lo12:.LC1138
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1139
	add	x0, x0, :lo12:.LC1139
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1140
	add	x0, x0, :lo12:.LC1140
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1141
	add	x0, x0, :lo12:.LC1141
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1142
	add	x0, x0, :lo12:.LC1142
	bl	printf
	adrp	x0, .LC1143
	add	x0, x0, :lo12:.LC1143
	bl	printf
	mov	x1, 0
	mov	x0, 22
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1144
	add	x0, x0, :lo12:.LC1144
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1145
	add	x0, x0, :lo12:.LC1145
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1146
	add	x0, x0, :lo12:.LC1146
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1147
	add	x0, x0, :lo12:.LC1147
	bl	printf
	adrp	x0, .LC1148
	add	x0, x0, :lo12:.LC1148
	bl	printf
	mov	x1, 0
	mov	x0, 12
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1149
	add	x0, x0, :lo12:.LC1149
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1150
	add	x0, x0, :lo12:.LC1150
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1151
	add	x0, x0, :lo12:.LC1151
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1152
	add	x0, x0, :lo12:.LC1152
	bl	printf
	adrp	x0, .LC1153
	add	x0, x0, :lo12:.LC1153
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1154
	add	x0, x0, :lo12:.LC1154
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1155
	add	x0, x0, :lo12:.LC1155
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1156
	add	x0, x0, :lo12:.LC1156
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1157
	add	x0, x0, :lo12:.LC1157
	bl	printf
	adrp	x0, .LC1158
	add	x0, x0, :lo12:.LC1158
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1159
	add	x0, x0, :lo12:.LC1159
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1160
	add	x0, x0, :lo12:.LC1160
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1161
	add	x0, x0, :lo12:.LC1161
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1162
	add	x0, x0, :lo12:.LC1162
	bl	printf
	adrp	x0, .LC1163
	add	x0, x0, :lo12:.LC1163
	bl	printf
	mov	x1, 0
	mov	x0, 11
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1164
	add	x0, x0, :lo12:.LC1164
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1165
	add	x0, x0, :lo12:.LC1165
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1166
	add	x0, x0, :lo12:.LC1166
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1167
	add	x0, x0, :lo12:.LC1167
	bl	printf
	adrp	x0, .LC1168
	add	x0, x0, :lo12:.LC1168
	bl	printf
	mov	x1, 0
	mov	x0, 9
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1169
	add	x0, x0, :lo12:.LC1169
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1170
	add	x0, x0, :lo12:.LC1170
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1171
	add	x0, x0, :lo12:.LC1171
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1172
	add	x0, x0, :lo12:.LC1172
	bl	printf
	adrp	x0, .LC1173
	add	x0, x0, :lo12:.LC1173
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1174
	add	x0, x0, :lo12:.LC1174
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1175
	add	x0, x0, :lo12:.LC1175
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1176
	add	x0, x0, :lo12:.LC1176
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1177
	add	x0, x0, :lo12:.LC1177
	bl	printf
	adrp	x0, .LC1178
	add	x0, x0, :lo12:.LC1178
	bl	printf
	mov	x1, 0
	mov	x0, 31
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1179
	add	x0, x0, :lo12:.LC1179
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1180
	add	x0, x0, :lo12:.LC1180
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1181
	add	x0, x0, :lo12:.LC1181
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1182
	add	x0, x0, :lo12:.LC1182
	bl	printf
	adrp	x0, .LC1183
	add	x0, x0, :lo12:.LC1183
	bl	printf
	mov	x1, 0
	mov	x0, 29
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1184
	add	x0, x0, :lo12:.LC1184
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1185
	add	x0, x0, :lo12:.LC1185
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1186
	add	x0, x0, :lo12:.LC1186
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1187
	add	x0, x0, :lo12:.LC1187
	bl	printf
	adrp	x0, .LC1188
	add	x0, x0, :lo12:.LC1188
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1189
	add	x0, x0, :lo12:.LC1189
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1190
	add	x0, x0, :lo12:.LC1190
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1191
	add	x0, x0, :lo12:.LC1191
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1192
	add	x0, x0, :lo12:.LC1192
	bl	printf
	adrp	x0, .LC1193
	add	x0, x0, :lo12:.LC1193
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1194
	add	x0, x0, :lo12:.LC1194
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1195
	add	x0, x0, :lo12:.LC1195
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1196
	add	x0, x0, :lo12:.LC1196
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1197
	add	x0, x0, :lo12:.LC1197
	bl	printf
	adrp	x0, .LC1198
	add	x0, x0, :lo12:.LC1198
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1199
	add	x0, x0, :lo12:.LC1199
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1200
	add	x0, x0, :lo12:.LC1200
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1201
	add	x0, x0, :lo12:.LC1201
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1202
	add	x0, x0, :lo12:.LC1202
	bl	printf
	adrp	x0, .LC1203
	add	x0, x0, :lo12:.LC1203
	bl	printf
	mov	x1, 0
	mov	x0, 25
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1204
	add	x0, x0, :lo12:.LC1204
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1205
	add	x0, x0, :lo12:.LC1205
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1206
	add	x0, x0, :lo12:.LC1206
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1207
	add	x0, x0, :lo12:.LC1207
	bl	printf
	adrp	x0, .LC1208
	add	x0, x0, :lo12:.LC1208
	bl	printf
	mov	x1, 0
	mov	x0, 33
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1209
	add	x0, x0, :lo12:.LC1209
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1210
	add	x0, x0, :lo12:.LC1210
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1211
	add	x0, x0, :lo12:.LC1211
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1212
	add	x0, x0, :lo12:.LC1212
	bl	printf
	adrp	x0, .LC1213
	add	x0, x0, :lo12:.LC1213
	bl	printf
	mov	x1, 0
	mov	x0, 23
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1214
	add	x0, x0, :lo12:.LC1214
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1215
	add	x0, x0, :lo12:.LC1215
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1216
	add	x0, x0, :lo12:.LC1216
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1217
	add	x0, x0, :lo12:.LC1217
	bl	printf
	adrp	x0, .LC1218
	add	x0, x0, :lo12:.LC1218
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1219
	add	x0, x0, :lo12:.LC1219
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1220
	add	x0, x0, :lo12:.LC1220
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1221
	add	x0, x0, :lo12:.LC1221
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1222
	add	x0, x0, :lo12:.LC1222
	bl	printf
	adrp	x0, .LC1223
	add	x0, x0, :lo12:.LC1223
	bl	printf
	mov	x1, 0
	mov	x0, 19
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1224
	add	x0, x0, :lo12:.LC1224
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1225
	add	x0, x0, :lo12:.LC1225
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1226
	add	x0, x0, :lo12:.LC1226
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1227
	add	x0, x0, :lo12:.LC1227
	bl	printf
	adrp	x0, .LC1228
	add	x0, x0, :lo12:.LC1228
	bl	printf
	mov	x1, 0
	mov	x0, 17
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1229
	add	x0, x0, :lo12:.LC1229
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1230
	add	x0, x0, :lo12:.LC1230
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1231
	add	x0, x0, :lo12:.LC1231
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1232
	add	x0, x0, :lo12:.LC1232
	bl	printf
	adrp	x0, .LC1233
	add	x0, x0, :lo12:.LC1233
	bl	printf
	mov	x1, 0
	mov	x0, 13
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1234
	add	x0, x0, :lo12:.LC1234
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1235
	add	x0, x0, :lo12:.LC1235
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1236
	add	x0, x0, :lo12:.LC1236
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1237
	add	x0, x0, :lo12:.LC1237
	bl	printf
	adrp	x0, .LC1238
	add	x0, x0, :lo12:.LC1238
	bl	printf
	mov	x1, 0
	mov	x0, 18
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1239
	add	x0, x0, :lo12:.LC1239
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1240
	add	x0, x0, :lo12:.LC1240
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1241
	add	x0, x0, :lo12:.LC1241
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1242
	add	x0, x0, :lo12:.LC1242
	bl	printf
	adrp	x0, .LC1243
	add	x0, x0, :lo12:.LC1243
	bl	printf
	mov	x1, 0
	mov	x0, 14
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1244
	add	x0, x0, :lo12:.LC1244
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1245
	add	x0, x0, :lo12:.LC1245
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1246
	add	x0, x0, :lo12:.LC1246
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1247
	add	x0, x0, :lo12:.LC1247
	bl	printf
	adrp	x0, .LC1248
	add	x0, x0, :lo12:.LC1248
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1249
	add	x0, x0, :lo12:.LC1249
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1250
	add	x0, x0, :lo12:.LC1250
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1251
	add	x0, x0, :lo12:.LC1251
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1252
	add	x0, x0, :lo12:.LC1252
	bl	printf
	adrp	x0, .LC1253
	add	x0, x0, :lo12:.LC1253
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1254
	add	x0, x0, :lo12:.LC1254
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1255
	add	x0, x0, :lo12:.LC1255
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1256
	add	x0, x0, :lo12:.LC1256
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1257
	add	x0, x0, :lo12:.LC1257
	bl	printf
	adrp	x0, .LC1258
	add	x0, x0, :lo12:.LC1258
	bl	printf
	mov	x1, -1
	mov	x0, -9
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1259
	add	x0, x0, :lo12:.LC1259
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1260
	add	x0, x0, :lo12:.LC1260
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1261
	add	x0, x0, :lo12:.LC1261
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1262
	add	x0, x0, :lo12:.LC1262
	bl	printf
	adrp	x0, .LC1263
	add	x0, x0, :lo12:.LC1263
	bl	printf
	mov	x1, -1
	mov	x0, -38
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1264
	add	x0, x0, :lo12:.LC1264
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1265
	add	x0, x0, :lo12:.LC1265
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1266
	add	x0, x0, :lo12:.LC1266
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1267
	add	x0, x0, :lo12:.LC1267
	bl	printf
	adrp	x0, .LC1268
	add	x0, x0, :lo12:.LC1268
	bl	printf
	mov	x1, -1
	mov	x0, -22
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1269
	add	x0, x0, :lo12:.LC1269
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1270
	add	x0, x0, :lo12:.LC1270
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1271
	add	x0, x0, :lo12:.LC1271
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1272
	add	x0, x0, :lo12:.LC1272
	bl	printf
	adrp	x0, .LC1273
	add	x0, x0, :lo12:.LC1273
	bl	printf
	mov	x1, -1
	mov	x0, -10
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1274
	add	x0, x0, :lo12:.LC1274
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1275
	add	x0, x0, :lo12:.LC1275
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1276
	add	x0, x0, :lo12:.LC1276
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1277
	add	x0, x0, :lo12:.LC1277
	bl	printf
	adrp	x0, .LC1278
	add	x0, x0, :lo12:.LC1278
	bl	printf
	mov	x1, -1
	mov	x0, -7
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1279
	add	x0, x0, :lo12:.LC1279
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1280
	add	x0, x0, :lo12:.LC1280
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1281
	add	x0, x0, :lo12:.LC1281
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1282
	add	x0, x0, :lo12:.LC1282
	bl	printf
	adrp	x0, .LC1283
	add	x0, x0, :lo12:.LC1283
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1284
	add	x0, x0, :lo12:.LC1284
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1285
	add	x0, x0, :lo12:.LC1285
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1286
	add	x0, x0, :lo12:.LC1286
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1287
	add	x0, x0, :lo12:.LC1287
	bl	printf
	adrp	x0, .LC1288
	add	x0, x0, :lo12:.LC1288
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1289
	add	x0, x0, :lo12:.LC1289
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1290
	add	x0, x0, :lo12:.LC1290
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1291
	add	x0, x0, :lo12:.LC1291
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1292
	add	x0, x0, :lo12:.LC1292
	bl	printf
	adrp	x0, .LC1293
	add	x0, x0, :lo12:.LC1293
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1294
	add	x0, x0, :lo12:.LC1294
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1295
	add	x0, x0, :lo12:.LC1295
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1296
	add	x0, x0, :lo12:.LC1296
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1297
	add	x0, x0, :lo12:.LC1297
	bl	printf
	adrp	x0, .LC1298
	add	x0, x0, :lo12:.LC1298
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1299
	add	x0, x0, :lo12:.LC1299
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1300
	add	x0, x0, :lo12:.LC1300
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1301
	add	x0, x0, :lo12:.LC1301
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1302
	add	x0, x0, :lo12:.LC1302
	bl	printf
	adrp	x0, .LC1303
	add	x0, x0, :lo12:.LC1303
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1304
	add	x0, x0, :lo12:.LC1304
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1305
	add	x0, x0, :lo12:.LC1305
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1306
	add	x0, x0, :lo12:.LC1306
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1307
	add	x0, x0, :lo12:.LC1307
	bl	printf
	adrp	x0, .LC1308
	add	x0, x0, :lo12:.LC1308
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1309
	add	x0, x0, :lo12:.LC1309
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1310
	add	x0, x0, :lo12:.LC1310
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1311
	add	x0, x0, :lo12:.LC1311
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1312
	add	x0, x0, :lo12:.LC1312
	bl	printf
	adrp	x0, .LC1313
	add	x0, x0, :lo12:.LC1313
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1314
	add	x0, x0, :lo12:.LC1314
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1315
	add	x0, x0, :lo12:.LC1315
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1316
	add	x0, x0, :lo12:.LC1316
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1317
	add	x0, x0, :lo12:.LC1317
	bl	printf
	adrp	x0, .LC1318
	add	x0, x0, :lo12:.LC1318
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1319
	add	x0, x0, :lo12:.LC1319
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1320
	add	x0, x0, :lo12:.LC1320
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1321
	add	x0, x0, :lo12:.LC1321
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1322
	add	x0, x0, :lo12:.LC1322
	bl	printf
	adrp	x0, .LC1323
	add	x0, x0, :lo12:.LC1323
	bl	printf
	mov	x1, 0
	mov	x0, 1024
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1324
	add	x0, x0, :lo12:.LC1324
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1325
	add	x0, x0, :lo12:.LC1325
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1326
	add	x0, x0, :lo12:.LC1326
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1327
	add	x0, x0, :lo12:.LC1327
	bl	printf
	adrp	x0, .LC1328
	add	x0, x0, :lo12:.LC1328
	bl	printf
	mov	x1, 0
	mov	x0, 2048
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1329
	add	x0, x0, :lo12:.LC1329
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1330
	add	x0, x0, :lo12:.LC1330
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1331
	add	x0, x0, :lo12:.LC1331
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1332
	add	x0, x0, :lo12:.LC1332
	bl	printf
	adrp	x0, .LC1333
	add	x0, x0, :lo12:.LC1333
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1334
	add	x0, x0, :lo12:.LC1334
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1335
	add	x0, x0, :lo12:.LC1335
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1336
	add	x0, x0, :lo12:.LC1336
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1337
	add	x0, x0, :lo12:.LC1337
	bl	printf
	adrp	x0, .LC1338
	add	x0, x0, :lo12:.LC1338
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1339
	add	x0, x0, :lo12:.LC1339
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1340
	add	x0, x0, :lo12:.LC1340
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1341
	add	x0, x0, :lo12:.LC1341
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1342
	add	x0, x0, :lo12:.LC1342
	bl	printf
	adrp	x0, .LC1343
	add	x0, x0, :lo12:.LC1343
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1344
	add	x0, x0, :lo12:.LC1344
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1345
	add	x0, x0, :lo12:.LC1345
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1346
	add	x0, x0, :lo12:.LC1346
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1347
	add	x0, x0, :lo12:.LC1347
	bl	printf
	adrp	x0, .LC1348
	add	x0, x0, :lo12:.LC1348
	bl	printf
	mov	x1, 0
	mov	x0, 2147483647
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1349
	add	x0, x0, :lo12:.LC1349
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1350
	add	x0, x0, :lo12:.LC1350
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1351
	add	x0, x0, :lo12:.LC1351
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1352
	add	x0, x0, :lo12:.LC1352
	bl	printf
	adrp	x0, .LC1353
	add	x0, x0, :lo12:.LC1353
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1354
	add	x0, x0, :lo12:.LC1354
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1355
	add	x0, x0, :lo12:.LC1355
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1356
	add	x0, x0, :lo12:.LC1356
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1357
	add	x0, x0, :lo12:.LC1357
	bl	printf
	adrp	x0, .LC1358
	add	x0, x0, :lo12:.LC1358
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1359
	add	x0, x0, :lo12:.LC1359
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1360
	add	x0, x0, :lo12:.LC1360
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1361
	add	x0, x0, :lo12:.LC1361
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1362
	add	x0, x0, :lo12:.LC1362
	bl	printf
	adrp	x0, .LC1363
	add	x0, x0, :lo12:.LC1363
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1364
	add	x0, x0, :lo12:.LC1364
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1365
	add	x0, x0, :lo12:.LC1365
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1366
	add	x0, x0, :lo12:.LC1366
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1367
	add	x0, x0, :lo12:.LC1367
	bl	printf
	adrp	x0, .LC1368
	add	x0, x0, :lo12:.LC1368
	bl	printf
	mov	x1, 0
	mov	x0, 33188
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1369
	add	x0, x0, :lo12:.LC1369
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1370
	add	x0, x0, :lo12:.LC1370
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1371
	add	x0, x0, :lo12:.LC1371
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1372
	add	x0, x0, :lo12:.LC1372
	bl	printf
	adrp	x0, .LC1373
	add	x0, x0, :lo12:.LC1373
	bl	printf
	mov	x1, 0
	mov	x0, 33261
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1374
	add	x0, x0, :lo12:.LC1374
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1375
	add	x0, x0, :lo12:.LC1375
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1376
	add	x0, x0, :lo12:.LC1376
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1377
	add	x0, x0, :lo12:.LC1377
	bl	printf
	adrp	x0, .LC1378
	add	x0, x0, :lo12:.LC1378
	bl	printf
	mov	x1, 0
	mov	x0, 57344
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1379
	add	x0, x0, :lo12:.LC1379
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1380
	add	x0, x0, :lo12:.LC1380
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1381
	add	x0, x0, :lo12:.LC1381
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1382
	add	x0, x0, :lo12:.LC1382
	bl	printf
	adrp	x0, .LC1383
	add	x0, x0, :lo12:.LC1383
	bl	printf
	mov	x1, 0
	mov	x0, 40960
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1384
	add	x0, x0, :lo12:.LC1384
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1385
	add	x0, x0, :lo12:.LC1385
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1386
	add	x0, x0, :lo12:.LC1386
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1387
	add	x0, x0, :lo12:.LC1387
	bl	printf
	adrp	x0, .LC1388
	add	x0, x0, :lo12:.LC1388
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1389
	add	x0, x0, :lo12:.LC1389
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1390
	add	x0, x0, :lo12:.LC1390
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1391
	add	x0, x0, :lo12:.LC1391
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1392
	add	x0, x0, :lo12:.LC1392
	bl	printf
	adrp	x0, .LC1393
	add	x0, x0, :lo12:.LC1393
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1394
	add	x0, x0, :lo12:.LC1394
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1395
	add	x0, x0, :lo12:.LC1395
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1396
	add	x0, x0, :lo12:.LC1396
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1397
	add	x0, x0, :lo12:.LC1397
	bl	printf
	adrp	x0, .LC1398
	add	x0, x0, :lo12:.LC1398
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1399
	add	x0, x0, :lo12:.LC1399
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1400
	add	x0, x0, :lo12:.LC1400
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1401
	add	x0, x0, :lo12:.LC1401
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1402
	add	x0, x0, :lo12:.LC1402
	bl	printf
	adrp	x0, .LC1403
	add	x0, x0, :lo12:.LC1403
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1404
	add	x0, x0, :lo12:.LC1404
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1405
	add	x0, x0, :lo12:.LC1405
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1406
	add	x0, x0, :lo12:.LC1406
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1407
	add	x0, x0, :lo12:.LC1407
	bl	printf
	adrp	x0, .LC1408
	add	x0, x0, :lo12:.LC1408
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1409
	add	x0, x0, :lo12:.LC1409
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1410
	add	x0, x0, :lo12:.LC1410
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1411
	add	x0, x0, :lo12:.LC1411
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1412
	add	x0, x0, :lo12:.LC1412
	bl	printf
	adrp	x0, .LC1413
	add	x0, x0, :lo12:.LC1413
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1414
	add	x0, x0, :lo12:.LC1414
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1415
	add	x0, x0, :lo12:.LC1415
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1416
	add	x0, x0, :lo12:.LC1416
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1417
	add	x0, x0, :lo12:.LC1417
	bl	printf
	adrp	x0, .LC1418
	add	x0, x0, :lo12:.LC1418
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1419
	add	x0, x0, :lo12:.LC1419
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1420
	add	x0, x0, :lo12:.LC1420
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1421
	add	x0, x0, :lo12:.LC1421
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1422
	add	x0, x0, :lo12:.LC1422
	bl	printf
	adrp	x0, .LC1423
	add	x0, x0, :lo12:.LC1423
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1424
	add	x0, x0, :lo12:.LC1424
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1425
	add	x0, x0, :lo12:.LC1425
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1426
	add	x0, x0, :lo12:.LC1426
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1427
	add	x0, x0, :lo12:.LC1427
	bl	printf
	adrp	x0, .LC1428
	add	x0, x0, :lo12:.LC1428
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1429
	add	x0, x0, :lo12:.LC1429
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1430
	add	x0, x0, :lo12:.LC1430
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1431
	add	x0, x0, :lo12:.LC1431
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1432
	add	x0, x0, :lo12:.LC1432
	bl	printf
	adrp	x0, .LC1433
	add	x0, x0, :lo12:.LC1433
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1434
	add	x0, x0, :lo12:.LC1434
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1435
	add	x0, x0, :lo12:.LC1435
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1436
	add	x0, x0, :lo12:.LC1436
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1437
	add	x0, x0, :lo12:.LC1437
	bl	printf
	adrp	x0, .LC1438
	add	x0, x0, :lo12:.LC1438
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1439
	add	x0, x0, :lo12:.LC1439
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1440
	add	x0, x0, :lo12:.LC1440
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1441
	add	x0, x0, :lo12:.LC1441
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1442
	add	x0, x0, :lo12:.LC1442
	bl	printf
	adrp	x0, .LC1443
	add	x0, x0, :lo12:.LC1443
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1444
	add	x0, x0, :lo12:.LC1444
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1445
	add	x0, x0, :lo12:.LC1445
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1446
	add	x0, x0, :lo12:.LC1446
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1447
	add	x0, x0, :lo12:.LC1447
	bl	printf
	adrp	x0, .LC1448
	add	x0, x0, :lo12:.LC1448
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1449
	add	x0, x0, :lo12:.LC1449
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1450
	add	x0, x0, :lo12:.LC1450
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1451
	add	x0, x0, :lo12:.LC1451
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1452
	add	x0, x0, :lo12:.LC1452
	bl	printf
	adrp	x0, .LC1453
	add	x0, x0, :lo12:.LC1453
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1454
	add	x0, x0, :lo12:.LC1454
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1455
	add	x0, x0, :lo12:.LC1455
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1456
	add	x0, x0, :lo12:.LC1456
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1457
	add	x0, x0, :lo12:.LC1457
	bl	printf
	adrp	x0, .LC1458
	add	x0, x0, :lo12:.LC1458
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1459
	add	x0, x0, :lo12:.LC1459
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1460
	add	x0, x0, :lo12:.LC1460
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1461
	add	x0, x0, :lo12:.LC1461
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1462
	add	x0, x0, :lo12:.LC1462
	bl	printf
	adrp	x0, .LC1463
	add	x0, x0, :lo12:.LC1463
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1464
	add	x0, x0, :lo12:.LC1464
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1465
	add	x0, x0, :lo12:.LC1465
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1466
	add	x0, x0, :lo12:.LC1466
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1467
	add	x0, x0, :lo12:.LC1467
	bl	printf
	adrp	x0, .LC1468
	add	x0, x0, :lo12:.LC1468
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1469
	add	x0, x0, :lo12:.LC1469
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1470
	add	x0, x0, :lo12:.LC1470
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1471
	add	x0, x0, :lo12:.LC1471
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1472
	add	x0, x0, :lo12:.LC1472
	bl	printf
	adrp	x0, .LC1473
	add	x0, x0, :lo12:.LC1473
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1474
	add	x0, x0, :lo12:.LC1474
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1475
	add	x0, x0, :lo12:.LC1475
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1476
	add	x0, x0, :lo12:.LC1476
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1477
	add	x0, x0, :lo12:.LC1477
	bl	printf
	adrp	x0, .LC1478
	add	x0, x0, :lo12:.LC1478
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1479
	add	x0, x0, :lo12:.LC1479
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1480
	add	x0, x0, :lo12:.LC1480
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1481
	add	x0, x0, :lo12:.LC1481
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1482
	add	x0, x0, :lo12:.LC1482
	bl	printf
	adrp	x0, .LC1483
	add	x0, x0, :lo12:.LC1483
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1484
	add	x0, x0, :lo12:.LC1484
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1485
	add	x0, x0, :lo12:.LC1485
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1486
	add	x0, x0, :lo12:.LC1486
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1487
	add	x0, x0, :lo12:.LC1487
	bl	printf
	adrp	x0, .LC1488
	add	x0, x0, :lo12:.LC1488
	bl	printf
	mov	x1, 0
	mov	x0, 24576
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1489
	add	x0, x0, :lo12:.LC1489
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1490
	add	x0, x0, :lo12:.LC1490
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1491
	add	x0, x0, :lo12:.LC1491
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1492
	add	x0, x0, :lo12:.LC1492
	bl	printf
	adrp	x0, .LC1493
	add	x0, x0, :lo12:.LC1493
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1494
	add	x0, x0, :lo12:.LC1494
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1495
	add	x0, x0, :lo12:.LC1495
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1496
	add	x0, x0, :lo12:.LC1496
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1497
	add	x0, x0, :lo12:.LC1497
	bl	printf
	adrp	x0, .LC1498
	add	x0, x0, :lo12:.LC1498
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1499
	add	x0, x0, :lo12:.LC1499
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1500
	add	x0, x0, :lo12:.LC1500
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1501
	add	x0, x0, :lo12:.LC1501
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1502
	add	x0, x0, :lo12:.LC1502
	bl	printf
	adrp	x0, .LC1503
	add	x0, x0, :lo12:.LC1503
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1504
	add	x0, x0, :lo12:.LC1504
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1505
	add	x0, x0, :lo12:.LC1505
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1506
	add	x0, x0, :lo12:.LC1506
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1507
	add	x0, x0, :lo12:.LC1507
	bl	printf
	adrp	x0, .LC1508
	add	x0, x0, :lo12:.LC1508
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1509
	add	x0, x0, :lo12:.LC1509
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1510
	add	x0, x0, :lo12:.LC1510
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1511
	add	x0, x0, :lo12:.LC1511
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1512
	add	x0, x0, :lo12:.LC1512
	bl	printf
	adrp	x0, .LC1513
	add	x0, x0, :lo12:.LC1513
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1514
	add	x0, x0, :lo12:.LC1514
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1515
	add	x0, x0, :lo12:.LC1515
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1516
	add	x0, x0, :lo12:.LC1516
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1517
	add	x0, x0, :lo12:.LC1517
	bl	printf
	adrp	x0, .LC1518
	add	x0, x0, :lo12:.LC1518
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1519
	add	x0, x0, :lo12:.LC1519
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1520
	add	x0, x0, :lo12:.LC1520
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1521
	add	x0, x0, :lo12:.LC1521
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1522
	add	x0, x0, :lo12:.LC1522
	bl	printf
	adrp	x0, .LC1523
	add	x0, x0, :lo12:.LC1523
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1524
	add	x0, x0, :lo12:.LC1524
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1525
	add	x0, x0, :lo12:.LC1525
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1526
	add	x0, x0, :lo12:.LC1526
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1527
	add	x0, x0, :lo12:.LC1527
	bl	printf
	adrp	x0, .LC1528
	add	x0, x0, :lo12:.LC1528
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1529
	add	x0, x0, :lo12:.LC1529
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1530
	add	x0, x0, :lo12:.LC1530
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1531
	add	x0, x0, :lo12:.LC1531
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1532
	add	x0, x0, :lo12:.LC1532
	bl	printf
	adrp	x0, .LC1533
	add	x0, x0, :lo12:.LC1533
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1534
	add	x0, x0, :lo12:.LC1534
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1535
	add	x0, x0, :lo12:.LC1535
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1536
	add	x0, x0, :lo12:.LC1536
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1537
	add	x0, x0, :lo12:.LC1537
	bl	printf
	adrp	x0, .LC1538
	add	x0, x0, :lo12:.LC1538
	bl	printf
	mov	x1, -1
	mov	x0, -31
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1539
	add	x0, x0, :lo12:.LC1539
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1540
	add	x0, x0, :lo12:.LC1540
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1541
	add	x0, x0, :lo12:.LC1541
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1542
	add	x0, x0, :lo12:.LC1542
	bl	printf
	adrp	x0, .LC1543
	add	x0, x0, :lo12:.LC1543
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1544
	add	x0, x0, :lo12:.LC1544
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1545
	add	x0, x0, :lo12:.LC1545
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1546
	add	x0, x0, :lo12:.LC1546
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1547
	add	x0, x0, :lo12:.LC1547
	bl	printf
	adrp	x0, .LC1548
	add	x0, x0, :lo12:.LC1548
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1549
	add	x0, x0, :lo12:.LC1549
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1550
	add	x0, x0, :lo12:.LC1550
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1551
	add	x0, x0, :lo12:.LC1551
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1552
	add	x0, x0, :lo12:.LC1552
	bl	printf
	adrp	x0, .LC1553
	add	x0, x0, :lo12:.LC1553
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1554
	add	x0, x0, :lo12:.LC1554
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1555
	add	x0, x0, :lo12:.LC1555
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1556
	add	x0, x0, :lo12:.LC1556
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1557
	add	x0, x0, :lo12:.LC1557
	bl	printf
	adrp	x0, .LC1558
	add	x0, x0, :lo12:.LC1558
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1559
	add	x0, x0, :lo12:.LC1559
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1560
	add	x0, x0, :lo12:.LC1560
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1561
	add	x0, x0, :lo12:.LC1561
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1562
	add	x0, x0, :lo12:.LC1562
	bl	printf
	adrp	x0, .LC1563
	add	x0, x0, :lo12:.LC1563
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1564
	add	x0, x0, :lo12:.LC1564
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1565
	add	x0, x0, :lo12:.LC1565
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1566
	add	x0, x0, :lo12:.LC1566
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1567
	add	x0, x0, :lo12:.LC1567
	bl	printf
	adrp	x0, .LC1568
	add	x0, x0, :lo12:.LC1568
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1569
	add	x0, x0, :lo12:.LC1569
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1570
	add	x0, x0, :lo12:.LC1570
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1571
	add	x0, x0, :lo12:.LC1571
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1572
	add	x0, x0, :lo12:.LC1572
	bl	printf
	adrp	x0, .LC1573
	add	x0, x0, :lo12:.LC1573
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1574
	add	x0, x0, :lo12:.LC1574
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1575
	add	x0, x0, :lo12:.LC1575
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1576
	add	x0, x0, :lo12:.LC1576
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1577
	add	x0, x0, :lo12:.LC1577
	bl	printf
	adrp	x0, .LC1578
	add	x0, x0, :lo12:.LC1578
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1579
	add	x0, x0, :lo12:.LC1579
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1580
	add	x0, x0, :lo12:.LC1580
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1581
	add	x0, x0, :lo12:.LC1581
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1582
	add	x0, x0, :lo12:.LC1582
	bl	printf
	adrp	x0, .LC1583
	add	x0, x0, :lo12:.LC1583
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1584
	add	x0, x0, :lo12:.LC1584
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1585
	add	x0, x0, :lo12:.LC1585
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1586
	add	x0, x0, :lo12:.LC1586
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1587
	add	x0, x0, :lo12:.LC1587
	bl	printf
	adrp	x0, .LC1588
	add	x0, x0, :lo12:.LC1588
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1589
	add	x0, x0, :lo12:.LC1589
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1590
	add	x0, x0, :lo12:.LC1590
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1591
	add	x0, x0, :lo12:.LC1591
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1592
	add	x0, x0, :lo12:.LC1592
	bl	printf
	adrp	x0, .LC1593
	add	x0, x0, :lo12:.LC1593
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1594
	add	x0, x0, :lo12:.LC1594
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1595
	add	x0, x0, :lo12:.LC1595
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1596
	add	x0, x0, :lo12:.LC1596
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1597
	add	x0, x0, :lo12:.LC1597
	bl	printf
	adrp	x0, .LC1598
	add	x0, x0, :lo12:.LC1598
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1599
	add	x0, x0, :lo12:.LC1599
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1600
	add	x0, x0, :lo12:.LC1600
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1601
	add	x0, x0, :lo12:.LC1601
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1602
	add	x0, x0, :lo12:.LC1602
	bl	printf
	adrp	x0, .LC1603
	add	x0, x0, :lo12:.LC1603
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1604
	add	x0, x0, :lo12:.LC1604
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1605
	add	x0, x0, :lo12:.LC1605
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1606
	add	x0, x0, :lo12:.LC1606
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1607
	add	x0, x0, :lo12:.LC1607
	bl	printf
	adrp	x0, .LC1608
	add	x0, x0, :lo12:.LC1608
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1609
	add	x0, x0, :lo12:.LC1609
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1610
	add	x0, x0, :lo12:.LC1610
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1611
	add	x0, x0, :lo12:.LC1611
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1612
	add	x0, x0, :lo12:.LC1612
	bl	printf
	adrp	x0, .LC1613
	add	x0, x0, :lo12:.LC1613
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1614
	add	x0, x0, :lo12:.LC1614
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1615
	add	x0, x0, :lo12:.LC1615
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1616
	add	x0, x0, :lo12:.LC1616
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1617
	add	x0, x0, :lo12:.LC1617
	bl	printf
	adrp	x0, .LC1618
	add	x0, x0, :lo12:.LC1618
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1619
	add	x0, x0, :lo12:.LC1619
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1620
	add	x0, x0, :lo12:.LC1620
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1621
	add	x0, x0, :lo12:.LC1621
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1622
	add	x0, x0, :lo12:.LC1622
	bl	printf
	adrp	x0, .LC1623
	add	x0, x0, :lo12:.LC1623
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1624
	add	x0, x0, :lo12:.LC1624
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1625
	add	x0, x0, :lo12:.LC1625
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1626
	add	x0, x0, :lo12:.LC1626
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1627
	add	x0, x0, :lo12:.LC1627
	bl	printf
	adrp	x0, .LC1628
	add	x0, x0, :lo12:.LC1628
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1629
	add	x0, x0, :lo12:.LC1629
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1630
	add	x0, x0, :lo12:.LC1630
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1631
	add	x0, x0, :lo12:.LC1631
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1632
	add	x0, x0, :lo12:.LC1632
	bl	printf
	adrp	x0, .LC1633
	add	x0, x0, :lo12:.LC1633
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1634
	add	x0, x0, :lo12:.LC1634
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1635
	add	x0, x0, :lo12:.LC1635
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1636
	add	x0, x0, :lo12:.LC1636
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1637
	add	x0, x0, :lo12:.LC1637
	bl	printf
	adrp	x0, .LC1638
	add	x0, x0, :lo12:.LC1638
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1639
	add	x0, x0, :lo12:.LC1639
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1640
	add	x0, x0, :lo12:.LC1640
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1641
	add	x0, x0, :lo12:.LC1641
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1642
	add	x0, x0, :lo12:.LC1642
	bl	printf
	adrp	x0, .LC1643
	add	x0, x0, :lo12:.LC1643
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1644
	add	x0, x0, :lo12:.LC1644
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1645
	add	x0, x0, :lo12:.LC1645
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1646
	add	x0, x0, :lo12:.LC1646
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1647
	add	x0, x0, :lo12:.LC1647
	bl	printf
	adrp	x0, .LC1648
	add	x0, x0, :lo12:.LC1648
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1649
	add	x0, x0, :lo12:.LC1649
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1650
	add	x0, x0, :lo12:.LC1650
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1651
	add	x0, x0, :lo12:.LC1651
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1652
	add	x0, x0, :lo12:.LC1652
	bl	printf
	adrp	x0, .LC1653
	add	x0, x0, :lo12:.LC1653
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1654
	add	x0, x0, :lo12:.LC1654
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1655
	add	x0, x0, :lo12:.LC1655
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1656
	add	x0, x0, :lo12:.LC1656
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1657
	add	x0, x0, :lo12:.LC1657
	bl	printf
	adrp	x0, .LC1658
	add	x0, x0, :lo12:.LC1658
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1659
	add	x0, x0, :lo12:.LC1659
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1660
	add	x0, x0, :lo12:.LC1660
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1661
	add	x0, x0, :lo12:.LC1661
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1662
	add	x0, x0, :lo12:.LC1662
	bl	printf
	adrp	x0, .LC1663
	add	x0, x0, :lo12:.LC1663
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1664
	add	x0, x0, :lo12:.LC1664
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1665
	add	x0, x0, :lo12:.LC1665
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1666
	add	x0, x0, :lo12:.LC1666
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1667
	add	x0, x0, :lo12:.LC1667
	bl	printf
	adrp	x0, .LC1668
	add	x0, x0, :lo12:.LC1668
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1669
	add	x0, x0, :lo12:.LC1669
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1670
	add	x0, x0, :lo12:.LC1670
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1671
	add	x0, x0, :lo12:.LC1671
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1672
	add	x0, x0, :lo12:.LC1672
	bl	printf
	adrp	x0, .LC1673
	add	x0, x0, :lo12:.LC1673
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1674
	add	x0, x0, :lo12:.LC1674
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1675
	add	x0, x0, :lo12:.LC1675
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1676
	add	x0, x0, :lo12:.LC1676
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1677
	add	x0, x0, :lo12:.LC1677
	bl	printf
	adrp	x0, .LC1678
	add	x0, x0, :lo12:.LC1678
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1679
	add	x0, x0, :lo12:.LC1679
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1680
	add	x0, x0, :lo12:.LC1680
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1681
	add	x0, x0, :lo12:.LC1681
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1682
	add	x0, x0, :lo12:.LC1682
	bl	printf
	adrp	x0, .LC1683
	add	x0, x0, :lo12:.LC1683
	bl	printf
	mov	x1, -1
	mov	x0, -2
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1684
	add	x0, x0, :lo12:.LC1684
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1685
	add	x0, x0, :lo12:.LC1685
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1686
	add	x0, x0, :lo12:.LC1686
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1687
	add	x0, x0, :lo12:.LC1687
	bl	printf
	adrp	x0, .LC1688
	add	x0, x0, :lo12:.LC1688
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1689
	add	x0, x0, :lo12:.LC1689
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1690
	add	x0, x0, :lo12:.LC1690
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1691
	add	x0, x0, :lo12:.LC1691
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1692
	add	x0, x0, :lo12:.LC1692
	bl	printf
	adrp	x0, .LC1693
	add	x0, x0, :lo12:.LC1693
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1694
	add	x0, x0, :lo12:.LC1694
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1695
	add	x0, x0, :lo12:.LC1695
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1696
	add	x0, x0, :lo12:.LC1696
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1697
	add	x0, x0, :lo12:.LC1697
	bl	printf
	adrp	x0, .LC1698
	add	x0, x0, :lo12:.LC1698
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1699
	add	x0, x0, :lo12:.LC1699
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1700
	add	x0, x0, :lo12:.LC1700
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1701
	add	x0, x0, :lo12:.LC1701
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1702
	add	x0, x0, :lo12:.LC1702
	bl	printf
	adrp	x0, .LC1703
	add	x0, x0, :lo12:.LC1703
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1704
	add	x0, x0, :lo12:.LC1704
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1705
	add	x0, x0, :lo12:.LC1705
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1706
	add	x0, x0, :lo12:.LC1706
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1707
	add	x0, x0, :lo12:.LC1707
	bl	printf
	adrp	x0, .LC1708
	add	x0, x0, :lo12:.LC1708
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1709
	add	x0, x0, :lo12:.LC1709
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1710
	add	x0, x0, :lo12:.LC1710
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1711
	add	x0, x0, :lo12:.LC1711
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1712
	add	x0, x0, :lo12:.LC1712
	bl	printf
	adrp	x0, .LC1713
	add	x0, x0, :lo12:.LC1713
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1714
	add	x0, x0, :lo12:.LC1714
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1715
	add	x0, x0, :lo12:.LC1715
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1716
	add	x0, x0, :lo12:.LC1716
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1717
	add	x0, x0, :lo12:.LC1717
	bl	printf
	adrp	x0, .LC1718
	add	x0, x0, :lo12:.LC1718
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1719
	add	x0, x0, :lo12:.LC1719
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1720
	add	x0, x0, :lo12:.LC1720
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1721
	add	x0, x0, :lo12:.LC1721
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1722
	add	x0, x0, :lo12:.LC1722
	bl	printf
	adrp	x0, .LC1723
	add	x0, x0, :lo12:.LC1723
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1724
	add	x0, x0, :lo12:.LC1724
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1725
	add	x0, x0, :lo12:.LC1725
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1726
	add	x0, x0, :lo12:.LC1726
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1727
	add	x0, x0, :lo12:.LC1727
	bl	printf
	adrp	x0, .LC1728
	add	x0, x0, :lo12:.LC1728
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1729
	add	x0, x0, :lo12:.LC1729
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1730
	add	x0, x0, :lo12:.LC1730
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1731
	add	x0, x0, :lo12:.LC1731
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1732
	add	x0, x0, :lo12:.LC1732
	bl	printf
	adrp	x0, .LC1733
	add	x0, x0, :lo12:.LC1733
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1734
	add	x0, x0, :lo12:.LC1734
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1735
	add	x0, x0, :lo12:.LC1735
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1736
	add	x0, x0, :lo12:.LC1736
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1737
	add	x0, x0, :lo12:.LC1737
	bl	printf
	adrp	x0, .LC1738
	add	x0, x0, :lo12:.LC1738
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1739
	add	x0, x0, :lo12:.LC1739
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1740
	add	x0, x0, :lo12:.LC1740
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1741
	add	x0, x0, :lo12:.LC1741
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1742
	add	x0, x0, :lo12:.LC1742
	bl	printf
	adrp	x0, .LC1743
	add	x0, x0, :lo12:.LC1743
	bl	printf
	mov	x1, 0
	mov	x0, 45
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1744
	add	x0, x0, :lo12:.LC1744
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1745
	add	x0, x0, :lo12:.LC1745
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1746
	add	x0, x0, :lo12:.LC1746
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1747
	add	x0, x0, :lo12:.LC1747
	bl	printf
	adrp	x0, .LC1748
	add	x0, x0, :lo12:.LC1748
	bl	printf
	mov	x1, 0
	mov	x0, 27
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1749
	add	x0, x0, :lo12:.LC1749
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1750
	add	x0, x0, :lo12:.LC1750
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1751
	add	x0, x0, :lo12:.LC1751
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1752
	add	x0, x0, :lo12:.LC1752
	bl	printf
	adrp	x0, .LC1753
	add	x0, x0, :lo12:.LC1753
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1754
	add	x0, x0, :lo12:.LC1754
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1755
	add	x0, x0, :lo12:.LC1755
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1756
	add	x0, x0, :lo12:.LC1756
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1757
	add	x0, x0, :lo12:.LC1757
	bl	printf
	adrp	x0, .LC1758
	add	x0, x0, :lo12:.LC1758
	bl	printf
	mov	x1, 0
	mov	x0, 19
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1759
	add	x0, x0, :lo12:.LC1759
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1760
	add	x0, x0, :lo12:.LC1760
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1761
	add	x0, x0, :lo12:.LC1761
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1762
	add	x0, x0, :lo12:.LC1762
	bl	printf
	adrp	x0, .LC1763
	add	x0, x0, :lo12:.LC1763
	bl	printf
	mov	x1, 0
	mov	x0, 28
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1764
	add	x0, x0, :lo12:.LC1764
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1765
	add	x0, x0, :lo12:.LC1765
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1766
	add	x0, x0, :lo12:.LC1766
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1767
	add	x0, x0, :lo12:.LC1767
	bl	printf
	adrp	x0, .LC1768
	add	x0, x0, :lo12:.LC1768
	bl	printf
	mov	x1, 0
	mov	x0, 18
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1769
	add	x0, x0, :lo12:.LC1769
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1770
	add	x0, x0, :lo12:.LC1770
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1771
	add	x0, x0, :lo12:.LC1771
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1772
	add	x0, x0, :lo12:.LC1772
	bl	printf
	adrp	x0, .LC1773
	add	x0, x0, :lo12:.LC1773
	bl	printf
	mov	x1, 0
	mov	x0, 22
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1774
	add	x0, x0, :lo12:.LC1774
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1775
	add	x0, x0, :lo12:.LC1775
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1776
	add	x0, x0, :lo12:.LC1776
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1777
	add	x0, x0, :lo12:.LC1777
	bl	printf
	adrp	x0, .LC1778
	add	x0, x0, :lo12:.LC1778
	bl	printf
	mov	x1, 0
	mov	x0, 14
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1779
	add	x0, x0, :lo12:.LC1779
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1780
	add	x0, x0, :lo12:.LC1780
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1781
	add	x0, x0, :lo12:.LC1781
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1782
	add	x0, x0, :lo12:.LC1782
	bl	printf
	adrp	x0, .LC1783
	add	x0, x0, :lo12:.LC1783
	bl	printf
	mov	x1, 0
	mov	x0, 15
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1784
	add	x0, x0, :lo12:.LC1784
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1785
	add	x0, x0, :lo12:.LC1785
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1786
	add	x0, x0, :lo12:.LC1786
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1787
	add	x0, x0, :lo12:.LC1787
	bl	printf
	adrp	x0, .LC1788
	add	x0, x0, :lo12:.LC1788
	bl	printf
	mov	x1, 0
	mov	x0, 24
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1789
	add	x0, x0, :lo12:.LC1789
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1790
	add	x0, x0, :lo12:.LC1790
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1791
	add	x0, x0, :lo12:.LC1791
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1792
	add	x0, x0, :lo12:.LC1792
	bl	printf
	adrp	x0, .LC1793
	add	x0, x0, :lo12:.LC1793
	bl	printf
	mov	x1, 0
	mov	x0, 9
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1794
	add	x0, x0, :lo12:.LC1794
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1795
	add	x0, x0, :lo12:.LC1795
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1796
	add	x0, x0, :lo12:.LC1796
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1797
	add	x0, x0, :lo12:.LC1797
	bl	printf
	adrp	x0, .LC1798
	add	x0, x0, :lo12:.LC1798
	bl	printf
	mov	x1, 0
	mov	x0, 33
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1799
	add	x0, x0, :lo12:.LC1799
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1800
	add	x0, x0, :lo12:.LC1800
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1801
	add	x0, x0, :lo12:.LC1801
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1802
	add	x0, x0, :lo12:.LC1802
	bl	printf
	adrp	x0, .LC1803
	add	x0, x0, :lo12:.LC1803
	bl	printf
	mov	x1, 0
	mov	x0, 37
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1804
	add	x0, x0, :lo12:.LC1804
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1805
	add	x0, x0, :lo12:.LC1805
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1806
	add	x0, x0, :lo12:.LC1806
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1807
	add	x0, x0, :lo12:.LC1807
	bl	printf
	adrp	x0, .LC1808
	add	x0, x0, :lo12:.LC1808
	bl	printf
	mov	x1, 0
	mov	x0, 29
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1809
	add	x0, x0, :lo12:.LC1809
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1810
	add	x0, x0, :lo12:.LC1810
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1811
	add	x0, x0, :lo12:.LC1811
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1812
	add	x0, x0, :lo12:.LC1812
	bl	printf
	adrp	x0, .LC1813
	add	x0, x0, :lo12:.LC1813
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1814
	add	x0, x0, :lo12:.LC1814
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1815
	add	x0, x0, :lo12:.LC1815
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1816
	add	x0, x0, :lo12:.LC1816
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1817
	add	x0, x0, :lo12:.LC1817
	bl	printf
	adrp	x0, .LC1818
	add	x0, x0, :lo12:.LC1818
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1819
	add	x0, x0, :lo12:.LC1819
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1820
	add	x0, x0, :lo12:.LC1820
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1821
	add	x0, x0, :lo12:.LC1821
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1822
	add	x0, x0, :lo12:.LC1822
	bl	printf
	adrp	x0, .LC1823
	add	x0, x0, :lo12:.LC1823
	bl	printf
	mov	x1, 0
	mov	x0, 35
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1824
	add	x0, x0, :lo12:.LC1824
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1825
	add	x0, x0, :lo12:.LC1825
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1826
	add	x0, x0, :lo12:.LC1826
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1827
	add	x0, x0, :lo12:.LC1827
	bl	printf
	adrp	x0, .LC1828
	add	x0, x0, :lo12:.LC1828
	bl	printf
	mov	x1, 0
	mov	x0, 25
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1829
	add	x0, x0, :lo12:.LC1829
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1830
	add	x0, x0, :lo12:.LC1830
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1831
	add	x0, x0, :lo12:.LC1831
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1832
	add	x0, x0, :lo12:.LC1832
	bl	printf
	adrp	x0, .LC1833
	add	x0, x0, :lo12:.LC1833
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1834
	add	x0, x0, :lo12:.LC1834
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1835
	add	x0, x0, :lo12:.LC1835
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1836
	add	x0, x0, :lo12:.LC1836
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1837
	add	x0, x0, :lo12:.LC1837
	bl	printf
	adrp	x0, .LC1838
	add	x0, x0, :lo12:.LC1838
	bl	printf
	mov	x1, 0
	mov	x0, 40
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1839
	add	x0, x0, :lo12:.LC1839
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1840
	add	x0, x0, :lo12:.LC1840
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1841
	add	x0, x0, :lo12:.LC1841
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1842
	add	x0, x0, :lo12:.LC1842
	bl	printf
	adrp	x0, .LC1843
	add	x0, x0, :lo12:.LC1843
	bl	printf
	mov	x1, 0
	mov	x0, 42
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1844
	add	x0, x0, :lo12:.LC1844
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1845
	add	x0, x0, :lo12:.LC1845
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1846
	add	x0, x0, :lo12:.LC1846
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1847
	add	x0, x0, :lo12:.LC1847
	bl	printf
	adrp	x0, .LC1848
	add	x0, x0, :lo12:.LC1848
	bl	printf
	mov	x1, 0
	mov	x0, 10
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1849
	add	x0, x0, :lo12:.LC1849
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1850
	add	x0, x0, :lo12:.LC1850
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1851
	add	x0, x0, :lo12:.LC1851
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1852
	add	x0, x0, :lo12:.LC1852
	bl	printf
	adrp	x0, .LC1853
	add	x0, x0, :lo12:.LC1853
	bl	printf
	mov	x1, 0
	mov	x0, 17
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1854
	add	x0, x0, :lo12:.LC1854
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1855
	add	x0, x0, :lo12:.LC1855
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1856
	add	x0, x0, :lo12:.LC1856
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1857
	add	x0, x0, :lo12:.LC1857
	bl	printf
	adrp	x0, .LC1858
	add	x0, x0, :lo12:.LC1858
	bl	printf
	mov	x1, 0
	mov	x0, 44
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1859
	add	x0, x0, :lo12:.LC1859
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1860
	add	x0, x0, :lo12:.LC1860
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1861
	add	x0, x0, :lo12:.LC1861
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1862
	add	x0, x0, :lo12:.LC1862
	bl	printf
	adrp	x0, .LC1863
	add	x0, x0, :lo12:.LC1863
	bl	printf
	mov	x1, 0
	mov	x0, 20
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1864
	add	x0, x0, :lo12:.LC1864
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1865
	add	x0, x0, :lo12:.LC1865
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1866
	add	x0, x0, :lo12:.LC1866
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1867
	add	x0, x0, :lo12:.LC1867
	bl	printf
	adrp	x0, .LC1868
	add	x0, x0, :lo12:.LC1868
	bl	printf
	mov	x1, 0
	mov	x0, 23
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1869
	add	x0, x0, :lo12:.LC1869
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1870
	add	x0, x0, :lo12:.LC1870
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1871
	add	x0, x0, :lo12:.LC1871
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1872
	add	x0, x0, :lo12:.LC1872
	bl	printf
	adrp	x0, .LC1873
	add	x0, x0, :lo12:.LC1873
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1874
	add	x0, x0, :lo12:.LC1874
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1875
	add	x0, x0, :lo12:.LC1875
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1876
	add	x0, x0, :lo12:.LC1876
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1877
	add	x0, x0, :lo12:.LC1877
	bl	printf
	adrp	x0, .LC1878
	add	x0, x0, :lo12:.LC1878
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1879
	add	x0, x0, :lo12:.LC1879
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1880
	add	x0, x0, :lo12:.LC1880
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1881
	add	x0, x0, :lo12:.LC1881
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1882
	add	x0, x0, :lo12:.LC1882
	bl	printf
	adrp	x0, .LC1883
	add	x0, x0, :lo12:.LC1883
	bl	printf
	mov	x1, 0
	mov	x0, 34
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1884
	add	x0, x0, :lo12:.LC1884
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1885
	add	x0, x0, :lo12:.LC1885
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1886
	add	x0, x0, :lo12:.LC1886
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1887
	add	x0, x0, :lo12:.LC1887
	bl	printf
	adrp	x0, .LC1888
	add	x0, x0, :lo12:.LC1888
	bl	printf
	mov	x1, 0
	mov	x0, 38
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1889
	add	x0, x0, :lo12:.LC1889
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1890
	add	x0, x0, :lo12:.LC1890
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1891
	add	x0, x0, :lo12:.LC1891
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1892
	add	x0, x0, :lo12:.LC1892
	bl	printf
	adrp	x0, .LC1893
	add	x0, x0, :lo12:.LC1893
	bl	printf
	mov	x1, 0
	mov	x0, 30
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1894
	add	x0, x0, :lo12:.LC1894
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1895
	add	x0, x0, :lo12:.LC1895
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1896
	add	x0, x0, :lo12:.LC1896
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1897
	add	x0, x0, :lo12:.LC1897
	bl	printf
	adrp	x0, .LC1898
	add	x0, x0, :lo12:.LC1898
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1899
	add	x0, x0, :lo12:.LC1899
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1900
	add	x0, x0, :lo12:.LC1900
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1901
	add	x0, x0, :lo12:.LC1901
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1902
	add	x0, x0, :lo12:.LC1902
	bl	printf
	adrp	x0, .LC1903
	add	x0, x0, :lo12:.LC1903
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1904
	add	x0, x0, :lo12:.LC1904
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1905
	add	x0, x0, :lo12:.LC1905
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1906
	add	x0, x0, :lo12:.LC1906
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1907
	add	x0, x0, :lo12:.LC1907
	bl	printf
	adrp	x0, .LC1908
	add	x0, x0, :lo12:.LC1908
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1909
	add	x0, x0, :lo12:.LC1909
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1910
	add	x0, x0, :lo12:.LC1910
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1911
	add	x0, x0, :lo12:.LC1911
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1912
	add	x0, x0, :lo12:.LC1912
	bl	printf
	adrp	x0, .LC1913
	add	x0, x0, :lo12:.LC1913
	bl	printf
	mov	x1, 0
	mov	x0, 31
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1914
	add	x0, x0, :lo12:.LC1914
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1915
	add	x0, x0, :lo12:.LC1915
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1916
	add	x0, x0, :lo12:.LC1916
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1917
	add	x0, x0, :lo12:.LC1917
	bl	printf
	adrp	x0, .LC1918
	add	x0, x0, :lo12:.LC1918
	bl	printf
	mov	x1, 0
	mov	x0, 36
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1919
	add	x0, x0, :lo12:.LC1919
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1920
	add	x0, x0, :lo12:.LC1920
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1921
	add	x0, x0, :lo12:.LC1921
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1922
	add	x0, x0, :lo12:.LC1922
	bl	printf
	adrp	x0, .LC1923
	add	x0, x0, :lo12:.LC1923
	bl	printf
	mov	x1, 0
	mov	x0, 26
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1924
	add	x0, x0, :lo12:.LC1924
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1925
	add	x0, x0, :lo12:.LC1925
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1926
	add	x0, x0, :lo12:.LC1926
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1927
	add	x0, x0, :lo12:.LC1927
	bl	printf
	adrp	x0, .LC1928
	add	x0, x0, :lo12:.LC1928
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1929
	add	x0, x0, :lo12:.LC1929
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1930
	add	x0, x0, :lo12:.LC1930
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1931
	add	x0, x0, :lo12:.LC1931
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1932
	add	x0, x0, :lo12:.LC1932
	bl	printf
	adrp	x0, .LC1933
	add	x0, x0, :lo12:.LC1933
	bl	printf
	mov	x1, 0
	mov	x0, 39
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1934
	add	x0, x0, :lo12:.LC1934
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1935
	add	x0, x0, :lo12:.LC1935
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1936
	add	x0, x0, :lo12:.LC1936
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1937
	add	x0, x0, :lo12:.LC1937
	bl	printf
	adrp	x0, .LC1938
	add	x0, x0, :lo12:.LC1938
	bl	printf
	mov	x1, 0
	mov	x0, 41
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1939
	add	x0, x0, :lo12:.LC1939
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1940
	add	x0, x0, :lo12:.LC1940
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1941
	add	x0, x0, :lo12:.LC1941
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1942
	add	x0, x0, :lo12:.LC1942
	bl	printf
	adrp	x0, .LC1943
	add	x0, x0, :lo12:.LC1943
	bl	printf
	mov	x1, 0
	mov	x0, 12
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1944
	add	x0, x0, :lo12:.LC1944
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1945
	add	x0, x0, :lo12:.LC1945
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1946
	add	x0, x0, :lo12:.LC1946
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1947
	add	x0, x0, :lo12:.LC1947
	bl	printf
	adrp	x0, .LC1948
	add	x0, x0, :lo12:.LC1948
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1949
	add	x0, x0, :lo12:.LC1949
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1950
	add	x0, x0, :lo12:.LC1950
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1951
	add	x0, x0, :lo12:.LC1951
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1952
	add	x0, x0, :lo12:.LC1952
	bl	printf
	adrp	x0, .LC1953
	add	x0, x0, :lo12:.LC1953
	bl	printf
	mov	x1, 0
	mov	x0, 11
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1954
	add	x0, x0, :lo12:.LC1954
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1955
	add	x0, x0, :lo12:.LC1955
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1956
	add	x0, x0, :lo12:.LC1956
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1957
	add	x0, x0, :lo12:.LC1957
	bl	printf
	adrp	x0, .LC1958
	add	x0, x0, :lo12:.LC1958
	bl	printf
	mov	x1, 0
	mov	x0, 13
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1959
	add	x0, x0, :lo12:.LC1959
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1960
	add	x0, x0, :lo12:.LC1960
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1961
	add	x0, x0, :lo12:.LC1961
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1962
	add	x0, x0, :lo12:.LC1962
	bl	printf
	adrp	x0, .LC1963
	add	x0, x0, :lo12:.LC1963
	bl	printf
	mov	x1, 0
	mov	x0, 43
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1964
	add	x0, x0, :lo12:.LC1964
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1965
	add	x0, x0, :lo12:.LC1965
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1966
	add	x0, x0, :lo12:.LC1966
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1967
	add	x0, x0, :lo12:.LC1967
	bl	printf
	adrp	x0, .LC1968
	add	x0, x0, :lo12:.LC1968
	bl	printf
	mov	x1, 0
	mov	x0, 21
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1969
	add	x0, x0, :lo12:.LC1969
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1970
	add	x0, x0, :lo12:.LC1970
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1971
	add	x0, x0, :lo12:.LC1971
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1972
	add	x0, x0, :lo12:.LC1972
	bl	printf
	adrp	x0, .LC1973
	add	x0, x0, :lo12:.LC1973
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1974
	add	x0, x0, :lo12:.LC1974
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1975
	add	x0, x0, :lo12:.LC1975
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1976
	add	x0, x0, :lo12:.LC1976
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1977
	add	x0, x0, :lo12:.LC1977
	bl	printf
	adrp	x0, .LC1978
	add	x0, x0, :lo12:.LC1978
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1979
	add	x0, x0, :lo12:.LC1979
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1980
	add	x0, x0, :lo12:.LC1980
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1981
	add	x0, x0, :lo12:.LC1981
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1982
	add	x0, x0, :lo12:.LC1982
	bl	printf
	adrp	x0, .LC1983
	add	x0, x0, :lo12:.LC1983
	bl	printf
	mov	x1, -1
	mov	x0, -30
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1984
	add	x0, x0, :lo12:.LC1984
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1985
	add	x0, x0, :lo12:.LC1985
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1986
	add	x0, x0, :lo12:.LC1986
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1987
	add	x0, x0, :lo12:.LC1987
	bl	printf
	adrp	x0, .LC1988
	add	x0, x0, :lo12:.LC1988
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1989
	add	x0, x0, :lo12:.LC1989
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1990
	add	x0, x0, :lo12:.LC1990
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1991
	add	x0, x0, :lo12:.LC1991
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1992
	add	x0, x0, :lo12:.LC1992
	bl	printf
	adrp	x0, .LC1993
	add	x0, x0, :lo12:.LC1993
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1994
	add	x0, x0, :lo12:.LC1994
	bl	printf
	mov	w1, 0
	adrp	x0, .LC1995
	add	x0, x0, :lo12:.LC1995
	bl	printf
	mov	x1, 4
	adrp	x0, .LC1996
	add	x0, x0, :lo12:.LC1996
	bl	printf
	mov	w1, 1
	adrp	x0, .LC1997
	add	x0, x0, :lo12:.LC1997
	bl	printf
	adrp	x0, .LC1998
	add	x0, x0, :lo12:.LC1998
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC1999
	add	x0, x0, :lo12:.LC1999
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2000
	add	x0, x0, :lo12:.LC2000
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2001
	add	x0, x0, :lo12:.LC2001
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2002
	add	x0, x0, :lo12:.LC2002
	bl	printf
	adrp	x0, .LC2003
	add	x0, x0, :lo12:.LC2003
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2004
	add	x0, x0, :lo12:.LC2004
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2005
	add	x0, x0, :lo12:.LC2005
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2006
	add	x0, x0, :lo12:.LC2006
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2007
	add	x0, x0, :lo12:.LC2007
	bl	printf
	adrp	x0, .LC2008
	add	x0, x0, :lo12:.LC2008
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2009
	add	x0, x0, :lo12:.LC2009
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2010
	add	x0, x0, :lo12:.LC2010
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2011
	add	x0, x0, :lo12:.LC2011
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2012
	add	x0, x0, :lo12:.LC2012
	bl	printf
	adrp	x0, .LC2013
	add	x0, x0, :lo12:.LC2013
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2014
	add	x0, x0, :lo12:.LC2014
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2015
	add	x0, x0, :lo12:.LC2015
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2016
	add	x0, x0, :lo12:.LC2016
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2017
	add	x0, x0, :lo12:.LC2017
	bl	printf
	adrp	x0, .LC2018
	add	x0, x0, :lo12:.LC2018
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2019
	add	x0, x0, :lo12:.LC2019
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2020
	add	x0, x0, :lo12:.LC2020
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2021
	add	x0, x0, :lo12:.LC2021
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2022
	add	x0, x0, :lo12:.LC2022
	bl	printf
	adrp	x0, .LC2023
	add	x0, x0, :lo12:.LC2023
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2024
	add	x0, x0, :lo12:.LC2024
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2025
	add	x0, x0, :lo12:.LC2025
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2026
	add	x0, x0, :lo12:.LC2026
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2027
	add	x0, x0, :lo12:.LC2027
	bl	printf
	adrp	x0, .LC2028
	add	x0, x0, :lo12:.LC2028
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2029
	add	x0, x0, :lo12:.LC2029
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2030
	add	x0, x0, :lo12:.LC2030
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2031
	add	x0, x0, :lo12:.LC2031
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2032
	add	x0, x0, :lo12:.LC2032
	bl	printf
	adrp	x0, .LC2033
	add	x0, x0, :lo12:.LC2033
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2034
	add	x0, x0, :lo12:.LC2034
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2035
	add	x0, x0, :lo12:.LC2035
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2036
	add	x0, x0, :lo12:.LC2036
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2037
	add	x0, x0, :lo12:.LC2037
	bl	printf
	adrp	x0, .LC2038
	add	x0, x0, :lo12:.LC2038
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2039
	add	x0, x0, :lo12:.LC2039
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2040
	add	x0, x0, :lo12:.LC2040
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2041
	add	x0, x0, :lo12:.LC2041
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2042
	add	x0, x0, :lo12:.LC2042
	bl	printf
	adrp	x0, .LC2043
	add	x0, x0, :lo12:.LC2043
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2044
	add	x0, x0, :lo12:.LC2044
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2045
	add	x0, x0, :lo12:.LC2045
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2046
	add	x0, x0, :lo12:.LC2046
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2047
	add	x0, x0, :lo12:.LC2047
	bl	printf
	adrp	x0, .LC2048
	add	x0, x0, :lo12:.LC2048
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2049
	add	x0, x0, :lo12:.LC2049
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2050
	add	x0, x0, :lo12:.LC2050
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2051
	add	x0, x0, :lo12:.LC2051
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2052
	add	x0, x0, :lo12:.LC2052
	bl	printf
	adrp	x0, .LC2053
	add	x0, x0, :lo12:.LC2053
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2054
	add	x0, x0, :lo12:.LC2054
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2055
	add	x0, x0, :lo12:.LC2055
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2056
	add	x0, x0, :lo12:.LC2056
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2057
	add	x0, x0, :lo12:.LC2057
	bl	printf
	adrp	x0, .LC2058
	add	x0, x0, :lo12:.LC2058
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2059
	add	x0, x0, :lo12:.LC2059
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2060
	add	x0, x0, :lo12:.LC2060
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2061
	add	x0, x0, :lo12:.LC2061
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2062
	add	x0, x0, :lo12:.LC2062
	bl	printf
	adrp	x0, .LC2063
	add	x0, x0, :lo12:.LC2063
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2064
	add	x0, x0, :lo12:.LC2064
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2065
	add	x0, x0, :lo12:.LC2065
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2066
	add	x0, x0, :lo12:.LC2066
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2067
	add	x0, x0, :lo12:.LC2067
	bl	printf
	adrp	x0, .LC2068
	add	x0, x0, :lo12:.LC2068
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2069
	add	x0, x0, :lo12:.LC2069
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2070
	add	x0, x0, :lo12:.LC2070
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2071
	add	x0, x0, :lo12:.LC2071
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2072
	add	x0, x0, :lo12:.LC2072
	bl	printf
	adrp	x0, .LC2073
	add	x0, x0, :lo12:.LC2073
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2074
	add	x0, x0, :lo12:.LC2074
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2075
	add	x0, x0, :lo12:.LC2075
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2076
	add	x0, x0, :lo12:.LC2076
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2077
	add	x0, x0, :lo12:.LC2077
	bl	printf
	adrp	x0, .LC2078
	add	x0, x0, :lo12:.LC2078
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2079
	add	x0, x0, :lo12:.LC2079
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2080
	add	x0, x0, :lo12:.LC2080
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2081
	add	x0, x0, :lo12:.LC2081
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2082
	add	x0, x0, :lo12:.LC2082
	bl	printf
	adrp	x0, .LC2083
	add	x0, x0, :lo12:.LC2083
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2084
	add	x0, x0, :lo12:.LC2084
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2085
	add	x0, x0, :lo12:.LC2085
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2086
	add	x0, x0, :lo12:.LC2086
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2087
	add	x0, x0, :lo12:.LC2087
	bl	printf
	adrp	x0, .LC2088
	add	x0, x0, :lo12:.LC2088
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2089
	add	x0, x0, :lo12:.LC2089
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2090
	add	x0, x0, :lo12:.LC2090
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2091
	add	x0, x0, :lo12:.LC2091
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2092
	add	x0, x0, :lo12:.LC2092
	bl	printf
	adrp	x0, .LC2093
	add	x0, x0, :lo12:.LC2093
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2094
	add	x0, x0, :lo12:.LC2094
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2095
	add	x0, x0, :lo12:.LC2095
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2096
	add	x0, x0, :lo12:.LC2096
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2097
	add	x0, x0, :lo12:.LC2097
	bl	printf
	adrp	x0, .LC2098
	add	x0, x0, :lo12:.LC2098
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2099
	add	x0, x0, :lo12:.LC2099
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2100
	add	x0, x0, :lo12:.LC2100
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2101
	add	x0, x0, :lo12:.LC2101
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2102
	add	x0, x0, :lo12:.LC2102
	bl	printf
	adrp	x0, .LC2103
	add	x0, x0, :lo12:.LC2103
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2104
	add	x0, x0, :lo12:.LC2104
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2105
	add	x0, x0, :lo12:.LC2105
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2106
	add	x0, x0, :lo12:.LC2106
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2107
	add	x0, x0, :lo12:.LC2107
	bl	printf
	adrp	x0, .LC2108
	add	x0, x0, :lo12:.LC2108
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2109
	add	x0, x0, :lo12:.LC2109
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2110
	add	x0, x0, :lo12:.LC2110
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2111
	add	x0, x0, :lo12:.LC2111
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2112
	add	x0, x0, :lo12:.LC2112
	bl	printf
	adrp	x0, .LC2113
	add	x0, x0, :lo12:.LC2113
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2114
	add	x0, x0, :lo12:.LC2114
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2115
	add	x0, x0, :lo12:.LC2115
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2116
	add	x0, x0, :lo12:.LC2116
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2117
	add	x0, x0, :lo12:.LC2117
	bl	printf
	adrp	x0, .LC2118
	add	x0, x0, :lo12:.LC2118
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2119
	add	x0, x0, :lo12:.LC2119
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2120
	add	x0, x0, :lo12:.LC2120
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2121
	add	x0, x0, :lo12:.LC2121
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2122
	add	x0, x0, :lo12:.LC2122
	bl	printf
	adrp	x0, .LC2123
	add	x0, x0, :lo12:.LC2123
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2124
	add	x0, x0, :lo12:.LC2124
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2125
	add	x0, x0, :lo12:.LC2125
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2126
	add	x0, x0, :lo12:.LC2126
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2127
	add	x0, x0, :lo12:.LC2127
	bl	printf
	adrp	x0, .LC2128
	add	x0, x0, :lo12:.LC2128
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2129
	add	x0, x0, :lo12:.LC2129
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2130
	add	x0, x0, :lo12:.LC2130
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2131
	add	x0, x0, :lo12:.LC2131
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2132
	add	x0, x0, :lo12:.LC2132
	bl	printf
	adrp	x0, .LC2133
	add	x0, x0, :lo12:.LC2133
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2134
	add	x0, x0, :lo12:.LC2134
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2135
	add	x0, x0, :lo12:.LC2135
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2136
	add	x0, x0, :lo12:.LC2136
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2137
	add	x0, x0, :lo12:.LC2137
	bl	printf
	adrp	x0, .LC2138
	add	x0, x0, :lo12:.LC2138
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2139
	add	x0, x0, :lo12:.LC2139
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2140
	add	x0, x0, :lo12:.LC2140
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2141
	add	x0, x0, :lo12:.LC2141
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2142
	add	x0, x0, :lo12:.LC2142
	bl	printf
	adrp	x0, .LC2143
	add	x0, x0, :lo12:.LC2143
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2144
	add	x0, x0, :lo12:.LC2144
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2145
	add	x0, x0, :lo12:.LC2145
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2146
	add	x0, x0, :lo12:.LC2146
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2147
	add	x0, x0, :lo12:.LC2147
	bl	printf
	adrp	x0, .LC2148
	add	x0, x0, :lo12:.LC2148
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2149
	add	x0, x0, :lo12:.LC2149
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2150
	add	x0, x0, :lo12:.LC2150
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2151
	add	x0, x0, :lo12:.LC2151
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2152
	add	x0, x0, :lo12:.LC2152
	bl	printf
	adrp	x0, .LC2153
	add	x0, x0, :lo12:.LC2153
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2154
	add	x0, x0, :lo12:.LC2154
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2155
	add	x0, x0, :lo12:.LC2155
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2156
	add	x0, x0, :lo12:.LC2156
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2157
	add	x0, x0, :lo12:.LC2157
	bl	printf
	adrp	x0, .LC2158
	add	x0, x0, :lo12:.LC2158
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2159
	add	x0, x0, :lo12:.LC2159
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2160
	add	x0, x0, :lo12:.LC2160
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2161
	add	x0, x0, :lo12:.LC2161
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2162
	add	x0, x0, :lo12:.LC2162
	bl	printf
	adrp	x0, .LC2163
	add	x0, x0, :lo12:.LC2163
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2164
	add	x0, x0, :lo12:.LC2164
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2165
	add	x0, x0, :lo12:.LC2165
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2166
	add	x0, x0, :lo12:.LC2166
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2167
	add	x0, x0, :lo12:.LC2167
	bl	printf
	adrp	x0, .LC2168
	add	x0, x0, :lo12:.LC2168
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2169
	add	x0, x0, :lo12:.LC2169
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2170
	add	x0, x0, :lo12:.LC2170
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2171
	add	x0, x0, :lo12:.LC2171
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2172
	add	x0, x0, :lo12:.LC2172
	bl	printf
	adrp	x0, .LC2173
	add	x0, x0, :lo12:.LC2173
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2174
	add	x0, x0, :lo12:.LC2174
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2175
	add	x0, x0, :lo12:.LC2175
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2176
	add	x0, x0, :lo12:.LC2176
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2177
	add	x0, x0, :lo12:.LC2177
	bl	printf
	adrp	x0, .LC2178
	add	x0, x0, :lo12:.LC2178
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2179
	add	x0, x0, :lo12:.LC2179
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2180
	add	x0, x0, :lo12:.LC2180
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2181
	add	x0, x0, :lo12:.LC2181
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2182
	add	x0, x0, :lo12:.LC2182
	bl	printf
	adrp	x0, .LC2183
	add	x0, x0, :lo12:.LC2183
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2184
	add	x0, x0, :lo12:.LC2184
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2185
	add	x0, x0, :lo12:.LC2185
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2186
	add	x0, x0, :lo12:.LC2186
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2187
	add	x0, x0, :lo12:.LC2187
	bl	printf
	adrp	x0, .LC2188
	add	x0, x0, :lo12:.LC2188
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2189
	add	x0, x0, :lo12:.LC2189
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2190
	add	x0, x0, :lo12:.LC2190
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2191
	add	x0, x0, :lo12:.LC2191
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2192
	add	x0, x0, :lo12:.LC2192
	bl	printf
	adrp	x0, .LC2193
	add	x0, x0, :lo12:.LC2193
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2194
	add	x0, x0, :lo12:.LC2194
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2195
	add	x0, x0, :lo12:.LC2195
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2196
	add	x0, x0, :lo12:.LC2196
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2197
	add	x0, x0, :lo12:.LC2197
	bl	printf
	adrp	x0, .LC2198
	add	x0, x0, :lo12:.LC2198
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2199
	add	x0, x0, :lo12:.LC2199
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2200
	add	x0, x0, :lo12:.LC2200
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2201
	add	x0, x0, :lo12:.LC2201
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2202
	add	x0, x0, :lo12:.LC2202
	bl	printf
	adrp	x0, .LC2203
	add	x0, x0, :lo12:.LC2203
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2204
	add	x0, x0, :lo12:.LC2204
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2205
	add	x0, x0, :lo12:.LC2205
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2206
	add	x0, x0, :lo12:.LC2206
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2207
	add	x0, x0, :lo12:.LC2207
	bl	printf
	adrp	x0, .LC2208
	add	x0, x0, :lo12:.LC2208
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2209
	add	x0, x0, :lo12:.LC2209
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2210
	add	x0, x0, :lo12:.LC2210
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2211
	add	x0, x0, :lo12:.LC2211
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2212
	add	x0, x0, :lo12:.LC2212
	bl	printf
	adrp	x0, .LC2213
	add	x0, x0, :lo12:.LC2213
	bl	printf
	mov	x1, 0
	mov	x0, 1535
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2214
	add	x0, x0, :lo12:.LC2214
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2215
	add	x0, x0, :lo12:.LC2215
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2216
	add	x0, x0, :lo12:.LC2216
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2217
	add	x0, x0, :lo12:.LC2217
	bl	printf
	adrp	x0, .LC2218
	add	x0, x0, :lo12:.LC2218
	bl	printf
	mov	x1, 0
	mov	x0, 1533
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2219
	add	x0, x0, :lo12:.LC2219
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2220
	add	x0, x0, :lo12:.LC2220
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2221
	add	x0, x0, :lo12:.LC2221
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2222
	add	x0, x0, :lo12:.LC2222
	bl	printf
	adrp	x0, .LC2223
	add	x0, x0, :lo12:.LC2223
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2224
	add	x0, x0, :lo12:.LC2224
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2225
	add	x0, x0, :lo12:.LC2225
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2226
	add	x0, x0, :lo12:.LC2226
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2227
	add	x0, x0, :lo12:.LC2227
	bl	printf
	adrp	x0, .LC2228
	add	x0, x0, :lo12:.LC2228
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2229
	add	x0, x0, :lo12:.LC2229
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2230
	add	x0, x0, :lo12:.LC2230
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2231
	add	x0, x0, :lo12:.LC2231
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2232
	add	x0, x0, :lo12:.LC2232
	bl	printf
	adrp	x0, .LC2233
	add	x0, x0, :lo12:.LC2233
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2234
	add	x0, x0, :lo12:.LC2234
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2235
	add	x0, x0, :lo12:.LC2235
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2236
	add	x0, x0, :lo12:.LC2236
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2237
	add	x0, x0, :lo12:.LC2237
	bl	printf
	adrp	x0, .LC2238
	add	x0, x0, :lo12:.LC2238
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2239
	add	x0, x0, :lo12:.LC2239
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2240
	add	x0, x0, :lo12:.LC2240
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2241
	add	x0, x0, :lo12:.LC2241
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2242
	add	x0, x0, :lo12:.LC2242
	bl	printf
	adrp	x0, .LC2243
	add	x0, x0, :lo12:.LC2243
	bl	printf
	mov	x1, 0
	mov	x0, 10
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2244
	add	x0, x0, :lo12:.LC2244
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2245
	add	x0, x0, :lo12:.LC2245
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2246
	add	x0, x0, :lo12:.LC2246
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2247
	add	x0, x0, :lo12:.LC2247
	bl	printf
	adrp	x0, .LC2248
	add	x0, x0, :lo12:.LC2248
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2249
	add	x0, x0, :lo12:.LC2249
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2250
	add	x0, x0, :lo12:.LC2250
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2251
	add	x0, x0, :lo12:.LC2251
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2252
	add	x0, x0, :lo12:.LC2252
	bl	printf
	adrp	x0, .LC2253
	add	x0, x0, :lo12:.LC2253
	bl	printf
	mov	x1, 0
	mov	x0, 9
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2254
	add	x0, x0, :lo12:.LC2254
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2255
	add	x0, x0, :lo12:.LC2255
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2256
	add	x0, x0, :lo12:.LC2256
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2257
	add	x0, x0, :lo12:.LC2257
	bl	printf
	adrp	x0, .LC2258
	add	x0, x0, :lo12:.LC2258
	bl	printf
	mov	x1, 0
	mov	x0, 11
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2259
	add	x0, x0, :lo12:.LC2259
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2260
	add	x0, x0, :lo12:.LC2260
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2261
	add	x0, x0, :lo12:.LC2261
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2262
	add	x0, x0, :lo12:.LC2262
	bl	printf
	adrp	x0, .LC2263
	add	x0, x0, :lo12:.LC2263
	bl	printf
	mov	x1, 0
	mov	x0, 12
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2264
	add	x0, x0, :lo12:.LC2264
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2265
	add	x0, x0, :lo12:.LC2265
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2266
	add	x0, x0, :lo12:.LC2266
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2267
	add	x0, x0, :lo12:.LC2267
	bl	printf
	adrp	x0, .LC2268
	add	x0, x0, :lo12:.LC2268
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2269
	add	x0, x0, :lo12:.LC2269
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2270
	add	x0, x0, :lo12:.LC2270
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2271
	add	x0, x0, :lo12:.LC2271
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2272
	add	x0, x0, :lo12:.LC2272
	bl	printf
	adrp	x0, .LC2273
	add	x0, x0, :lo12:.LC2273
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2274
	add	x0, x0, :lo12:.LC2274
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2275
	add	x0, x0, :lo12:.LC2275
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2276
	add	x0, x0, :lo12:.LC2276
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2277
	add	x0, x0, :lo12:.LC2277
	bl	printf
	adrp	x0, .LC2278
	add	x0, x0, :lo12:.LC2278
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2279
	add	x0, x0, :lo12:.LC2279
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2280
	add	x0, x0, :lo12:.LC2280
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2281
	add	x0, x0, :lo12:.LC2281
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2282
	add	x0, x0, :lo12:.LC2282
	bl	printf
	adrp	x0, .LC2283
	add	x0, x0, :lo12:.LC2283
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2284
	add	x0, x0, :lo12:.LC2284
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2285
	add	x0, x0, :lo12:.LC2285
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2286
	add	x0, x0, :lo12:.LC2286
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2287
	add	x0, x0, :lo12:.LC2287
	bl	printf
	adrp	x0, .LC2288
	add	x0, x0, :lo12:.LC2288
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2289
	add	x0, x0, :lo12:.LC2289
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2290
	add	x0, x0, :lo12:.LC2290
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2291
	add	x0, x0, :lo12:.LC2291
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2292
	add	x0, x0, :lo12:.LC2292
	bl	printf
	adrp	x0, .LC2293
	add	x0, x0, :lo12:.LC2293
	bl	printf
	mov	x1, 0
	mov	x0, 13
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2294
	add	x0, x0, :lo12:.LC2294
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2295
	add	x0, x0, :lo12:.LC2295
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2296
	add	x0, x0, :lo12:.LC2296
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2297
	add	x0, x0, :lo12:.LC2297
	bl	printf
	adrp	x0, .LC2298
	add	x0, x0, :lo12:.LC2298
	bl	printf
	mov	x1, 0
	mov	x0, 14
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2299
	add	x0, x0, :lo12:.LC2299
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2300
	add	x0, x0, :lo12:.LC2300
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2301
	add	x0, x0, :lo12:.LC2301
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2302
	add	x0, x0, :lo12:.LC2302
	bl	printf
	adrp	x0, .LC2303
	add	x0, x0, :lo12:.LC2303
	bl	printf
	mov	x1, 0
	mov	x0, 15
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2304
	add	x0, x0, :lo12:.LC2304
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2305
	add	x0, x0, :lo12:.LC2305
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2306
	add	x0, x0, :lo12:.LC2306
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2307
	add	x0, x0, :lo12:.LC2307
	bl	printf
	adrp	x0, .LC2308
	add	x0, x0, :lo12:.LC2308
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2309
	add	x0, x0, :lo12:.LC2309
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2310
	add	x0, x0, :lo12:.LC2310
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2311
	add	x0, x0, :lo12:.LC2311
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2312
	add	x0, x0, :lo12:.LC2312
	bl	printf
	adrp	x0, .LC2313
	add	x0, x0, :lo12:.LC2313
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2314
	add	x0, x0, :lo12:.LC2314
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2315
	add	x0, x0, :lo12:.LC2315
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2316
	add	x0, x0, :lo12:.LC2316
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2317
	add	x0, x0, :lo12:.LC2317
	bl	printf
	adrp	x0, .LC2318
	add	x0, x0, :lo12:.LC2318
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2319
	add	x0, x0, :lo12:.LC2319
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2320
	add	x0, x0, :lo12:.LC2320
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2321
	add	x0, x0, :lo12:.LC2321
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2322
	add	x0, x0, :lo12:.LC2322
	bl	printf
	adrp	x0, .LC2323
	add	x0, x0, :lo12:.LC2323
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2324
	add	x0, x0, :lo12:.LC2324
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2325
	add	x0, x0, :lo12:.LC2325
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2326
	add	x0, x0, :lo12:.LC2326
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2327
	add	x0, x0, :lo12:.LC2327
	bl	printf
	adrp	x0, .LC2328
	add	x0, x0, :lo12:.LC2328
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2329
	add	x0, x0, :lo12:.LC2329
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2330
	add	x0, x0, :lo12:.LC2330
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2331
	add	x0, x0, :lo12:.LC2331
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2332
	add	x0, x0, :lo12:.LC2332
	bl	printf
	adrp	x0, .LC2333
	add	x0, x0, :lo12:.LC2333
	bl	printf
	mov	x1, 0
	mov	x0, 10
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2334
	add	x0, x0, :lo12:.LC2334
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2335
	add	x0, x0, :lo12:.LC2335
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2336
	add	x0, x0, :lo12:.LC2336
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2337
	add	x0, x0, :lo12:.LC2337
	bl	printf
	adrp	x0, .LC2338
	add	x0, x0, :lo12:.LC2338
	bl	printf
	mov	x1, 0
	mov	x0, 11
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2339
	add	x0, x0, :lo12:.LC2339
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2340
	add	x0, x0, :lo12:.LC2340
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2341
	add	x0, x0, :lo12:.LC2341
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2342
	add	x0, x0, :lo12:.LC2342
	bl	printf
	adrp	x0, .LC2343
	add	x0, x0, :lo12:.LC2343
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2344
	add	x0, x0, :lo12:.LC2344
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2345
	add	x0, x0, :lo12:.LC2345
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2346
	add	x0, x0, :lo12:.LC2346
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2347
	add	x0, x0, :lo12:.LC2347
	bl	printf
	adrp	x0, .LC2348
	add	x0, x0, :lo12:.LC2348
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2349
	add	x0, x0, :lo12:.LC2349
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2350
	add	x0, x0, :lo12:.LC2350
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2351
	add	x0, x0, :lo12:.LC2351
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2352
	add	x0, x0, :lo12:.LC2352
	bl	printf
	adrp	x0, .LC2353
	add	x0, x0, :lo12:.LC2353
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2354
	add	x0, x0, :lo12:.LC2354
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2355
	add	x0, x0, :lo12:.LC2355
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2356
	add	x0, x0, :lo12:.LC2356
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2357
	add	x0, x0, :lo12:.LC2357
	bl	printf
	adrp	x0, .LC2358
	add	x0, x0, :lo12:.LC2358
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2359
	add	x0, x0, :lo12:.LC2359
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2360
	add	x0, x0, :lo12:.LC2360
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2361
	add	x0, x0, :lo12:.LC2361
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2362
	add	x0, x0, :lo12:.LC2362
	bl	printf
	adrp	x0, .LC2363
	add	x0, x0, :lo12:.LC2363
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2364
	add	x0, x0, :lo12:.LC2364
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2365
	add	x0, x0, :lo12:.LC2365
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2366
	add	x0, x0, :lo12:.LC2366
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2367
	add	x0, x0, :lo12:.LC2367
	bl	printf
	adrp	x0, .LC2368
	add	x0, x0, :lo12:.LC2368
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2369
	add	x0, x0, :lo12:.LC2369
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2370
	add	x0, x0, :lo12:.LC2370
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2371
	add	x0, x0, :lo12:.LC2371
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2372
	add	x0, x0, :lo12:.LC2372
	bl	printf
	adrp	x0, .LC2373
	add	x0, x0, :lo12:.LC2373
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2374
	add	x0, x0, :lo12:.LC2374
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2375
	add	x0, x0, :lo12:.LC2375
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2376
	add	x0, x0, :lo12:.LC2376
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2377
	add	x0, x0, :lo12:.LC2377
	bl	printf
	adrp	x0, .LC2378
	add	x0, x0, :lo12:.LC2378
	bl	printf
	mov	x1, 0
	mov	x0, 9
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2379
	add	x0, x0, :lo12:.LC2379
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2380
	add	x0, x0, :lo12:.LC2380
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2381
	add	x0, x0, :lo12:.LC2381
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2382
	add	x0, x0, :lo12:.LC2382
	bl	printf
	adrp	x0, .LC2383
	add	x0, x0, :lo12:.LC2383
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2384
	add	x0, x0, :lo12:.LC2384
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2385
	add	x0, x0, :lo12:.LC2385
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2386
	add	x0, x0, :lo12:.LC2386
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2387
	add	x0, x0, :lo12:.LC2387
	bl	printf
	adrp	x0, .LC2388
	add	x0, x0, :lo12:.LC2388
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2389
	add	x0, x0, :lo12:.LC2389
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2390
	add	x0, x0, :lo12:.LC2390
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2391
	add	x0, x0, :lo12:.LC2391
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2392
	add	x0, x0, :lo12:.LC2392
	bl	printf
	adrp	x0, .LC2393
	add	x0, x0, :lo12:.LC2393
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2394
	add	x0, x0, :lo12:.LC2394
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2395
	add	x0, x0, :lo12:.LC2395
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2396
	add	x0, x0, :lo12:.LC2396
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2397
	add	x0, x0, :lo12:.LC2397
	bl	printf
	adrp	x0, .LC2398
	add	x0, x0, :lo12:.LC2398
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2399
	add	x0, x0, :lo12:.LC2399
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2400
	add	x0, x0, :lo12:.LC2400
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2401
	add	x0, x0, :lo12:.LC2401
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2402
	add	x0, x0, :lo12:.LC2402
	bl	printf
	adrp	x0, .LC2403
	add	x0, x0, :lo12:.LC2403
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2404
	add	x0, x0, :lo12:.LC2404
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2405
	add	x0, x0, :lo12:.LC2405
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2406
	add	x0, x0, :lo12:.LC2406
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2407
	add	x0, x0, :lo12:.LC2407
	bl	printf
	adrp	x0, .LC2408
	add	x0, x0, :lo12:.LC2408
	bl	printf
	mov	x1, -1
	mov	x0, -32
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2409
	add	x0, x0, :lo12:.LC2409
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2410
	add	x0, x0, :lo12:.LC2410
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2411
	add	x0, x0, :lo12:.LC2411
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2412
	add	x0, x0, :lo12:.LC2412
	bl	printf
	adrp	x0, .LC2413
	add	x0, x0, :lo12:.LC2413
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2414
	add	x0, x0, :lo12:.LC2414
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2415
	add	x0, x0, :lo12:.LC2415
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2416
	add	x0, x0, :lo12:.LC2416
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2417
	add	x0, x0, :lo12:.LC2417
	bl	printf
	adrp	x0, .LC2418
	add	x0, x0, :lo12:.LC2418
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2419
	add	x0, x0, :lo12:.LC2419
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2420
	add	x0, x0, :lo12:.LC2420
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2421
	add	x0, x0, :lo12:.LC2421
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2422
	add	x0, x0, :lo12:.LC2422
	bl	printf
	adrp	x0, .LC2423
	add	x0, x0, :lo12:.LC2423
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2424
	add	x0, x0, :lo12:.LC2424
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2425
	add	x0, x0, :lo12:.LC2425
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2426
	add	x0, x0, :lo12:.LC2426
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2427
	add	x0, x0, :lo12:.LC2427
	bl	printf
	adrp	x0, .LC2428
	add	x0, x0, :lo12:.LC2428
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2429
	add	x0, x0, :lo12:.LC2429
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2430
	add	x0, x0, :lo12:.LC2430
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2431
	add	x0, x0, :lo12:.LC2431
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2432
	add	x0, x0, :lo12:.LC2432
	bl	printf
	adrp	x0, .LC2433
	add	x0, x0, :lo12:.LC2433
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2434
	add	x0, x0, :lo12:.LC2434
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2435
	add	x0, x0, :lo12:.LC2435
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2436
	add	x0, x0, :lo12:.LC2436
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2437
	add	x0, x0, :lo12:.LC2437
	bl	printf
	adrp	x0, .LC2438
	add	x0, x0, :lo12:.LC2438
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2439
	add	x0, x0, :lo12:.LC2439
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2440
	add	x0, x0, :lo12:.LC2440
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2441
	add	x0, x0, :lo12:.LC2441
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2442
	add	x0, x0, :lo12:.LC2442
	bl	printf
	adrp	x0, .LC2443
	add	x0, x0, :lo12:.LC2443
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2444
	add	x0, x0, :lo12:.LC2444
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2445
	add	x0, x0, :lo12:.LC2445
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2446
	add	x0, x0, :lo12:.LC2446
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2447
	add	x0, x0, :lo12:.LC2447
	bl	printf
	adrp	x0, .LC2448
	add	x0, x0, :lo12:.LC2448
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2449
	add	x0, x0, :lo12:.LC2449
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2450
	add	x0, x0, :lo12:.LC2450
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2451
	add	x0, x0, :lo12:.LC2451
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2452
	add	x0, x0, :lo12:.LC2452
	bl	printf
	adrp	x0, .LC2453
	add	x0, x0, :lo12:.LC2453
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2454
	add	x0, x0, :lo12:.LC2454
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2455
	add	x0, x0, :lo12:.LC2455
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2456
	add	x0, x0, :lo12:.LC2456
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2457
	add	x0, x0, :lo12:.LC2457
	bl	printf
	adrp	x0, .LC2458
	add	x0, x0, :lo12:.LC2458
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2459
	add	x0, x0, :lo12:.LC2459
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2460
	add	x0, x0, :lo12:.LC2460
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2461
	add	x0, x0, :lo12:.LC2461
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2462
	add	x0, x0, :lo12:.LC2462
	bl	printf
	adrp	x0, .LC2463
	add	x0, x0, :lo12:.LC2463
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2464
	add	x0, x0, :lo12:.LC2464
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2465
	add	x0, x0, :lo12:.LC2465
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2466
	add	x0, x0, :lo12:.LC2466
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2467
	add	x0, x0, :lo12:.LC2467
	bl	printf
	adrp	x0, .LC2468
	add	x0, x0, :lo12:.LC2468
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2469
	add	x0, x0, :lo12:.LC2469
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2470
	add	x0, x0, :lo12:.LC2470
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2471
	add	x0, x0, :lo12:.LC2471
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2472
	add	x0, x0, :lo12:.LC2472
	bl	printf
	adrp	x0, .LC2473
	add	x0, x0, :lo12:.LC2473
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2474
	add	x0, x0, :lo12:.LC2474
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2475
	add	x0, x0, :lo12:.LC2475
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2476
	add	x0, x0, :lo12:.LC2476
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2477
	add	x0, x0, :lo12:.LC2477
	bl	printf
	adrp	x0, .LC2478
	add	x0, x0, :lo12:.LC2478
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2479
	add	x0, x0, :lo12:.LC2479
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2480
	add	x0, x0, :lo12:.LC2480
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2481
	add	x0, x0, :lo12:.LC2481
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2482
	add	x0, x0, :lo12:.LC2482
	bl	printf
	adrp	x0, .LC2483
	add	x0, x0, :lo12:.LC2483
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2484
	add	x0, x0, :lo12:.LC2484
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2485
	add	x0, x0, :lo12:.LC2485
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2486
	add	x0, x0, :lo12:.LC2486
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2487
	add	x0, x0, :lo12:.LC2487
	bl	printf
	adrp	x0, .LC2488
	add	x0, x0, :lo12:.LC2488
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2489
	add	x0, x0, :lo12:.LC2489
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2490
	add	x0, x0, :lo12:.LC2490
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2491
	add	x0, x0, :lo12:.LC2491
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2492
	add	x0, x0, :lo12:.LC2492
	bl	printf
	adrp	x0, .LC2493
	add	x0, x0, :lo12:.LC2493
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2494
	add	x0, x0, :lo12:.LC2494
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2495
	add	x0, x0, :lo12:.LC2495
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2496
	add	x0, x0, :lo12:.LC2496
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2497
	add	x0, x0, :lo12:.LC2497
	bl	printf
	adrp	x0, .LC2498
	add	x0, x0, :lo12:.LC2498
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2499
	add	x0, x0, :lo12:.LC2499
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2500
	add	x0, x0, :lo12:.LC2500
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2501
	add	x0, x0, :lo12:.LC2501
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2502
	add	x0, x0, :lo12:.LC2502
	bl	printf
	adrp	x0, .LC2503
	add	x0, x0, :lo12:.LC2503
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2504
	add	x0, x0, :lo12:.LC2504
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2505
	add	x0, x0, :lo12:.LC2505
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2506
	add	x0, x0, :lo12:.LC2506
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2507
	add	x0, x0, :lo12:.LC2507
	bl	printf
	adrp	x0, .LC2508
	add	x0, x0, :lo12:.LC2508
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2509
	add	x0, x0, :lo12:.LC2509
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2510
	add	x0, x0, :lo12:.LC2510
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2511
	add	x0, x0, :lo12:.LC2511
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2512
	add	x0, x0, :lo12:.LC2512
	bl	printf
	adrp	x0, .LC2513
	add	x0, x0, :lo12:.LC2513
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2514
	add	x0, x0, :lo12:.LC2514
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2515
	add	x0, x0, :lo12:.LC2515
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2516
	add	x0, x0, :lo12:.LC2516
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2517
	add	x0, x0, :lo12:.LC2517
	bl	printf
	adrp	x0, .LC2518
	add	x0, x0, :lo12:.LC2518
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2519
	add	x0, x0, :lo12:.LC2519
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2520
	add	x0, x0, :lo12:.LC2520
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2521
	add	x0, x0, :lo12:.LC2521
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2522
	add	x0, x0, :lo12:.LC2522
	bl	printf
	adrp	x0, .LC2523
	add	x0, x0, :lo12:.LC2523
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2524
	add	x0, x0, :lo12:.LC2524
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2525
	add	x0, x0, :lo12:.LC2525
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2526
	add	x0, x0, :lo12:.LC2526
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2527
	add	x0, x0, :lo12:.LC2527
	bl	printf
	adrp	x0, .LC2528
	add	x0, x0, :lo12:.LC2528
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2529
	add	x0, x0, :lo12:.LC2529
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2530
	add	x0, x0, :lo12:.LC2530
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2531
	add	x0, x0, :lo12:.LC2531
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2532
	add	x0, x0, :lo12:.LC2532
	bl	printf
	adrp	x0, .LC2533
	add	x0, x0, :lo12:.LC2533
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2534
	add	x0, x0, :lo12:.LC2534
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2535
	add	x0, x0, :lo12:.LC2535
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2536
	add	x0, x0, :lo12:.LC2536
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2537
	add	x0, x0, :lo12:.LC2537
	bl	printf
	adrp	x0, .LC2538
	add	x0, x0, :lo12:.LC2538
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2539
	add	x0, x0, :lo12:.LC2539
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2540
	add	x0, x0, :lo12:.LC2540
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2541
	add	x0, x0, :lo12:.LC2541
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2542
	add	x0, x0, :lo12:.LC2542
	bl	printf
	adrp	x0, .LC2543
	add	x0, x0, :lo12:.LC2543
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2544
	add	x0, x0, :lo12:.LC2544
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2545
	add	x0, x0, :lo12:.LC2545
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2546
	add	x0, x0, :lo12:.LC2546
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2547
	add	x0, x0, :lo12:.LC2547
	bl	printf
	adrp	x0, .LC2548
	add	x0, x0, :lo12:.LC2548
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2549
	add	x0, x0, :lo12:.LC2549
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2550
	add	x0, x0, :lo12:.LC2550
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2551
	add	x0, x0, :lo12:.LC2551
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2552
	add	x0, x0, :lo12:.LC2552
	bl	printf
	adrp	x0, .LC2553
	add	x0, x0, :lo12:.LC2553
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2554
	add	x0, x0, :lo12:.LC2554
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2555
	add	x0, x0, :lo12:.LC2555
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2556
	add	x0, x0, :lo12:.LC2556
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2557
	add	x0, x0, :lo12:.LC2557
	bl	printf
	adrp	x0, .LC2558
	add	x0, x0, :lo12:.LC2558
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2559
	add	x0, x0, :lo12:.LC2559
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2560
	add	x0, x0, :lo12:.LC2560
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2561
	add	x0, x0, :lo12:.LC2561
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2562
	add	x0, x0, :lo12:.LC2562
	bl	printf
	adrp	x0, .LC2563
	add	x0, x0, :lo12:.LC2563
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2564
	add	x0, x0, :lo12:.LC2564
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2565
	add	x0, x0, :lo12:.LC2565
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2566
	add	x0, x0, :lo12:.LC2566
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2567
	add	x0, x0, :lo12:.LC2567
	bl	printf
	adrp	x0, .LC2568
	add	x0, x0, :lo12:.LC2568
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2569
	add	x0, x0, :lo12:.LC2569
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2570
	add	x0, x0, :lo12:.LC2570
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2571
	add	x0, x0, :lo12:.LC2571
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2572
	add	x0, x0, :lo12:.LC2572
	bl	printf
	adrp	x0, .LC2573
	add	x0, x0, :lo12:.LC2573
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2574
	add	x0, x0, :lo12:.LC2574
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2575
	add	x0, x0, :lo12:.LC2575
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2576
	add	x0, x0, :lo12:.LC2576
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2577
	add	x0, x0, :lo12:.LC2577
	bl	printf
	adrp	x0, .LC2578
	add	x0, x0, :lo12:.LC2578
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2579
	add	x0, x0, :lo12:.LC2579
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2580
	add	x0, x0, :lo12:.LC2580
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2581
	add	x0, x0, :lo12:.LC2581
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2582
	add	x0, x0, :lo12:.LC2582
	bl	printf
	adrp	x0, .LC2583
	add	x0, x0, :lo12:.LC2583
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2584
	add	x0, x0, :lo12:.LC2584
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2585
	add	x0, x0, :lo12:.LC2585
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2586
	add	x0, x0, :lo12:.LC2586
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2587
	add	x0, x0, :lo12:.LC2587
	bl	printf
	adrp	x0, .LC2588
	add	x0, x0, :lo12:.LC2588
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2589
	add	x0, x0, :lo12:.LC2589
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2590
	add	x0, x0, :lo12:.LC2590
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2591
	add	x0, x0, :lo12:.LC2591
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2592
	add	x0, x0, :lo12:.LC2592
	bl	printf
	adrp	x0, .LC2593
	add	x0, x0, :lo12:.LC2593
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2594
	add	x0, x0, :lo12:.LC2594
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2595
	add	x0, x0, :lo12:.LC2595
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2596
	add	x0, x0, :lo12:.LC2596
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2597
	add	x0, x0, :lo12:.LC2597
	bl	printf
	adrp	x0, .LC2598
	add	x0, x0, :lo12:.LC2598
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2599
	add	x0, x0, :lo12:.LC2599
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2600
	add	x0, x0, :lo12:.LC2600
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2601
	add	x0, x0, :lo12:.LC2601
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2602
	add	x0, x0, :lo12:.LC2602
	bl	printf
	adrp	x0, .LC2603
	add	x0, x0, :lo12:.LC2603
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2604
	add	x0, x0, :lo12:.LC2604
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2605
	add	x0, x0, :lo12:.LC2605
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2606
	add	x0, x0, :lo12:.LC2606
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2607
	add	x0, x0, :lo12:.LC2607
	bl	printf
	adrp	x0, .LC2608
	add	x0, x0, :lo12:.LC2608
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2609
	add	x0, x0, :lo12:.LC2609
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2610
	add	x0, x0, :lo12:.LC2610
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2611
	add	x0, x0, :lo12:.LC2611
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2612
	add	x0, x0, :lo12:.LC2612
	bl	printf
	adrp	x0, .LC2613
	add	x0, x0, :lo12:.LC2613
	bl	printf
	mov	x1, 0
	mov	x0, 2048
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2614
	add	x0, x0, :lo12:.LC2614
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2615
	add	x0, x0, :lo12:.LC2615
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2616
	add	x0, x0, :lo12:.LC2616
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2617
	add	x0, x0, :lo12:.LC2617
	bl	printf
	adrp	x0, .LC2618
	add	x0, x0, :lo12:.LC2618
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2619
	add	x0, x0, :lo12:.LC2619
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2620
	add	x0, x0, :lo12:.LC2620
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2621
	add	x0, x0, :lo12:.LC2621
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2622
	add	x0, x0, :lo12:.LC2622
	bl	printf
	adrp	x0, .LC2623
	add	x0, x0, :lo12:.LC2623
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2624
	add	x0, x0, :lo12:.LC2624
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2625
	add	x0, x0, :lo12:.LC2625
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2626
	add	x0, x0, :lo12:.LC2626
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2627
	add	x0, x0, :lo12:.LC2627
	bl	printf
	adrp	x0, .LC2628
	add	x0, x0, :lo12:.LC2628
	bl	printf
	mov	x1, 0
	mov	x0, 1024
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2629
	add	x0, x0, :lo12:.LC2629
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2630
	add	x0, x0, :lo12:.LC2630
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2631
	add	x0, x0, :lo12:.LC2631
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2632
	add	x0, x0, :lo12:.LC2632
	bl	printf
	adrp	x0, .LC2633
	add	x0, x0, :lo12:.LC2633
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2634
	add	x0, x0, :lo12:.LC2634
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2635
	add	x0, x0, :lo12:.LC2635
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2636
	add	x0, x0, :lo12:.LC2636
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2637
	add	x0, x0, :lo12:.LC2637
	bl	printf
	adrp	x0, .LC2638
	add	x0, x0, :lo12:.LC2638
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2639
	add	x0, x0, :lo12:.LC2639
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2640
	add	x0, x0, :lo12:.LC2640
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2641
	add	x0, x0, :lo12:.LC2641
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2642
	add	x0, x0, :lo12:.LC2642
	bl	printf
	adrp	x0, .LC2643
	add	x0, x0, :lo12:.LC2643
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2644
	add	x0, x0, :lo12:.LC2644
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2645
	add	x0, x0, :lo12:.LC2645
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2646
	add	x0, x0, :lo12:.LC2646
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2647
	add	x0, x0, :lo12:.LC2647
	bl	printf
	adrp	x0, .LC2648
	add	x0, x0, :lo12:.LC2648
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2649
	add	x0, x0, :lo12:.LC2649
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2650
	add	x0, x0, :lo12:.LC2650
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2651
	add	x0, x0, :lo12:.LC2651
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2652
	add	x0, x0, :lo12:.LC2652
	bl	printf
	adrp	x0, .LC2653
	add	x0, x0, :lo12:.LC2653
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2654
	add	x0, x0, :lo12:.LC2654
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2655
	add	x0, x0, :lo12:.LC2655
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2656
	add	x0, x0, :lo12:.LC2656
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2657
	add	x0, x0, :lo12:.LC2657
	bl	printf
	adrp	x0, .LC2658
	add	x0, x0, :lo12:.LC2658
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2659
	add	x0, x0, :lo12:.LC2659
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2660
	add	x0, x0, :lo12:.LC2660
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2661
	add	x0, x0, :lo12:.LC2661
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2662
	add	x0, x0, :lo12:.LC2662
	bl	printf
	adrp	x0, .LC2663
	add	x0, x0, :lo12:.LC2663
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2664
	add	x0, x0, :lo12:.LC2664
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2665
	add	x0, x0, :lo12:.LC2665
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2666
	add	x0, x0, :lo12:.LC2666
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2667
	add	x0, x0, :lo12:.LC2667
	bl	printf
	adrp	x0, .LC2668
	add	x0, x0, :lo12:.LC2668
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2669
	add	x0, x0, :lo12:.LC2669
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2670
	add	x0, x0, :lo12:.LC2670
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2671
	add	x0, x0, :lo12:.LC2671
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2672
	add	x0, x0, :lo12:.LC2672
	bl	printf
	adrp	x0, .LC2673
	add	x0, x0, :lo12:.LC2673
	bl	printf
	mov	x1, 0
	mov	x0, 2048
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2674
	add	x0, x0, :lo12:.LC2674
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2675
	add	x0, x0, :lo12:.LC2675
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2676
	add	x0, x0, :lo12:.LC2676
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2677
	add	x0, x0, :lo12:.LC2677
	bl	printf
	adrp	x0, .LC2678
	add	x0, x0, :lo12:.LC2678
	bl	printf
	mov	x1, 0
	mov	x0, 1024
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2679
	add	x0, x0, :lo12:.LC2679
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2680
	add	x0, x0, :lo12:.LC2680
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2681
	add	x0, x0, :lo12:.LC2681
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2682
	add	x0, x0, :lo12:.LC2682
	bl	printf
	adrp	x0, .LC2683
	add	x0, x0, :lo12:.LC2683
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2684
	add	x0, x0, :lo12:.LC2684
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2685
	add	x0, x0, :lo12:.LC2685
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2686
	add	x0, x0, :lo12:.LC2686
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2687
	add	x0, x0, :lo12:.LC2687
	bl	printf
	adrp	x0, .LC2688
	add	x0, x0, :lo12:.LC2688
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2689
	add	x0, x0, :lo12:.LC2689
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2690
	add	x0, x0, :lo12:.LC2690
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2691
	add	x0, x0, :lo12:.LC2691
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2692
	add	x0, x0, :lo12:.LC2692
	bl	printf
	adrp	x0, .LC2693
	add	x0, x0, :lo12:.LC2693
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2694
	add	x0, x0, :lo12:.LC2694
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2695
	add	x0, x0, :lo12:.LC2695
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2696
	add	x0, x0, :lo12:.LC2696
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2697
	add	x0, x0, :lo12:.LC2697
	bl	printf
	adrp	x0, .LC2698
	add	x0, x0, :lo12:.LC2698
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2699
	add	x0, x0, :lo12:.LC2699
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2700
	add	x0, x0, :lo12:.LC2700
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2701
	add	x0, x0, :lo12:.LC2701
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2702
	add	x0, x0, :lo12:.LC2702
	bl	printf
	adrp	x0, .LC2703
	add	x0, x0, :lo12:.LC2703
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2704
	add	x0, x0, :lo12:.LC2704
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2705
	add	x0, x0, :lo12:.LC2705
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2706
	add	x0, x0, :lo12:.LC2706
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2707
	add	x0, x0, :lo12:.LC2707
	bl	printf
	adrp	x0, .LC2708
	add	x0, x0, :lo12:.LC2708
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2709
	add	x0, x0, :lo12:.LC2709
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2710
	add	x0, x0, :lo12:.LC2710
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2711
	add	x0, x0, :lo12:.LC2711
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2712
	add	x0, x0, :lo12:.LC2712
	bl	printf
	adrp	x0, .LC2713
	add	x0, x0, :lo12:.LC2713
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2714
	add	x0, x0, :lo12:.LC2714
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2715
	add	x0, x0, :lo12:.LC2715
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2716
	add	x0, x0, :lo12:.LC2716
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2717
	add	x0, x0, :lo12:.LC2717
	bl	printf
	adrp	x0, .LC2718
	add	x0, x0, :lo12:.LC2718
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2719
	add	x0, x0, :lo12:.LC2719
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2720
	add	x0, x0, :lo12:.LC2720
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2721
	add	x0, x0, :lo12:.LC2721
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2722
	add	x0, x0, :lo12:.LC2722
	bl	printf
	adrp	x0, .LC2723
	add	x0, x0, :lo12:.LC2723
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2724
	add	x0, x0, :lo12:.LC2724
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2725
	add	x0, x0, :lo12:.LC2725
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2726
	add	x0, x0, :lo12:.LC2726
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2727
	add	x0, x0, :lo12:.LC2727
	bl	printf
	adrp	x0, .LC2728
	add	x0, x0, :lo12:.LC2728
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2729
	add	x0, x0, :lo12:.LC2729
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2730
	add	x0, x0, :lo12:.LC2730
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2731
	add	x0, x0, :lo12:.LC2731
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2732
	add	x0, x0, :lo12:.LC2732
	bl	printf
	adrp	x0, .LC2733
	add	x0, x0, :lo12:.LC2733
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2734
	add	x0, x0, :lo12:.LC2734
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2735
	add	x0, x0, :lo12:.LC2735
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2736
	add	x0, x0, :lo12:.LC2736
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2737
	add	x0, x0, :lo12:.LC2737
	bl	printf
	adrp	x0, .LC2738
	add	x0, x0, :lo12:.LC2738
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2739
	add	x0, x0, :lo12:.LC2739
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2740
	add	x0, x0, :lo12:.LC2740
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2741
	add	x0, x0, :lo12:.LC2741
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2742
	add	x0, x0, :lo12:.LC2742
	bl	printf
	adrp	x0, .LC2743
	add	x0, x0, :lo12:.LC2743
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2744
	add	x0, x0, :lo12:.LC2744
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2745
	add	x0, x0, :lo12:.LC2745
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2746
	add	x0, x0, :lo12:.LC2746
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2747
	add	x0, x0, :lo12:.LC2747
	bl	printf
	adrp	x0, .LC2748
	add	x0, x0, :lo12:.LC2748
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2749
	add	x0, x0, :lo12:.LC2749
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2750
	add	x0, x0, :lo12:.LC2750
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2751
	add	x0, x0, :lo12:.LC2751
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2752
	add	x0, x0, :lo12:.LC2752
	bl	printf
	adrp	x0, .LC2753
	add	x0, x0, :lo12:.LC2753
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2754
	add	x0, x0, :lo12:.LC2754
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2755
	add	x0, x0, :lo12:.LC2755
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2756
	add	x0, x0, :lo12:.LC2756
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2757
	add	x0, x0, :lo12:.LC2757
	bl	printf
	adrp	x0, .LC2758
	add	x0, x0, :lo12:.LC2758
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2759
	add	x0, x0, :lo12:.LC2759
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2760
	add	x0, x0, :lo12:.LC2760
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2761
	add	x0, x0, :lo12:.LC2761
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2762
	add	x0, x0, :lo12:.LC2762
	bl	printf
	adrp	x0, .LC2763
	add	x0, x0, :lo12:.LC2763
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2764
	add	x0, x0, :lo12:.LC2764
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2765
	add	x0, x0, :lo12:.LC2765
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2766
	add	x0, x0, :lo12:.LC2766
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2767
	add	x0, x0, :lo12:.LC2767
	bl	printf
	adrp	x0, .LC2768
	add	x0, x0, :lo12:.LC2768
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2769
	add	x0, x0, :lo12:.LC2769
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2770
	add	x0, x0, :lo12:.LC2770
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2771
	add	x0, x0, :lo12:.LC2771
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2772
	add	x0, x0, :lo12:.LC2772
	bl	printf
	adrp	x0, .LC2773
	add	x0, x0, :lo12:.LC2773
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2774
	add	x0, x0, :lo12:.LC2774
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2775
	add	x0, x0, :lo12:.LC2775
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2776
	add	x0, x0, :lo12:.LC2776
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2777
	add	x0, x0, :lo12:.LC2777
	bl	printf
	adrp	x0, .LC2778
	add	x0, x0, :lo12:.LC2778
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2779
	add	x0, x0, :lo12:.LC2779
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2780
	add	x0, x0, :lo12:.LC2780
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2781
	add	x0, x0, :lo12:.LC2781
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2782
	add	x0, x0, :lo12:.LC2782
	bl	printf
	adrp	x0, .LC2783
	add	x0, x0, :lo12:.LC2783
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2784
	add	x0, x0, :lo12:.LC2784
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2785
	add	x0, x0, :lo12:.LC2785
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2786
	add	x0, x0, :lo12:.LC2786
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2787
	add	x0, x0, :lo12:.LC2787
	bl	printf
	adrp	x0, .LC2788
	add	x0, x0, :lo12:.LC2788
	bl	printf
	mov	x1, 0
	mov	x0, 2048
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2789
	add	x0, x0, :lo12:.LC2789
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2790
	add	x0, x0, :lo12:.LC2790
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2791
	add	x0, x0, :lo12:.LC2791
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2792
	add	x0, x0, :lo12:.LC2792
	bl	printf
	adrp	x0, .LC2793
	add	x0, x0, :lo12:.LC2793
	bl	printf
	mov	x1, 0
	mov	x0, 1024
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2794
	add	x0, x0, :lo12:.LC2794
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2795
	add	x0, x0, :lo12:.LC2795
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2796
	add	x0, x0, :lo12:.LC2796
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2797
	add	x0, x0, :lo12:.LC2797
	bl	printf
	adrp	x0, .LC2798
	add	x0, x0, :lo12:.LC2798
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2799
	add	x0, x0, :lo12:.LC2799
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2800
	add	x0, x0, :lo12:.LC2800
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2801
	add	x0, x0, :lo12:.LC2801
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2802
	add	x0, x0, :lo12:.LC2802
	bl	printf
	adrp	x0, .LC2803
	add	x0, x0, :lo12:.LC2803
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2804
	add	x0, x0, :lo12:.LC2804
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2805
	add	x0, x0, :lo12:.LC2805
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2806
	add	x0, x0, :lo12:.LC2806
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2807
	add	x0, x0, :lo12:.LC2807
	bl	printf
	adrp	x0, .LC2808
	add	x0, x0, :lo12:.LC2808
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2809
	add	x0, x0, :lo12:.LC2809
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2810
	add	x0, x0, :lo12:.LC2810
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2811
	add	x0, x0, :lo12:.LC2811
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2812
	add	x0, x0, :lo12:.LC2812
	bl	printf
	adrp	x0, .LC2813
	add	x0, x0, :lo12:.LC2813
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2814
	add	x0, x0, :lo12:.LC2814
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2815
	add	x0, x0, :lo12:.LC2815
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2816
	add	x0, x0, :lo12:.LC2816
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2817
	add	x0, x0, :lo12:.LC2817
	bl	printf
	adrp	x0, .LC2818
	add	x0, x0, :lo12:.LC2818
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2819
	add	x0, x0, :lo12:.LC2819
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2820
	add	x0, x0, :lo12:.LC2820
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2821
	add	x0, x0, :lo12:.LC2821
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2822
	add	x0, x0, :lo12:.LC2822
	bl	printf
	adrp	x0, .LC2823
	add	x0, x0, :lo12:.LC2823
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2824
	add	x0, x0, :lo12:.LC2824
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2825
	add	x0, x0, :lo12:.LC2825
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2826
	add	x0, x0, :lo12:.LC2826
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2827
	add	x0, x0, :lo12:.LC2827
	bl	printf
	adrp	x0, .LC2828
	add	x0, x0, :lo12:.LC2828
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2829
	add	x0, x0, :lo12:.LC2829
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2830
	add	x0, x0, :lo12:.LC2830
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2831
	add	x0, x0, :lo12:.LC2831
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2832
	add	x0, x0, :lo12:.LC2832
	bl	printf
	adrp	x0, .LC2833
	add	x0, x0, :lo12:.LC2833
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2834
	add	x0, x0, :lo12:.LC2834
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2835
	add	x0, x0, :lo12:.LC2835
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2836
	add	x0, x0, :lo12:.LC2836
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2837
	add	x0, x0, :lo12:.LC2837
	bl	printf
	adrp	x0, .LC2838
	add	x0, x0, :lo12:.LC2838
	bl	printf
	mov	x1, -1
	mov	x0, -37
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2839
	add	x0, x0, :lo12:.LC2839
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2840
	add	x0, x0, :lo12:.LC2840
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2841
	add	x0, x0, :lo12:.LC2841
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2842
	add	x0, x0, :lo12:.LC2842
	bl	printf
	adrp	x0, .LC2843
	add	x0, x0, :lo12:.LC2843
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2844
	add	x0, x0, :lo12:.LC2844
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2845
	add	x0, x0, :lo12:.LC2845
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2846
	add	x0, x0, :lo12:.LC2846
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2847
	add	x0, x0, :lo12:.LC2847
	bl	printf
	adrp	x0, .LC2848
	add	x0, x0, :lo12:.LC2848
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2849
	add	x0, x0, :lo12:.LC2849
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2850
	add	x0, x0, :lo12:.LC2850
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2851
	add	x0, x0, :lo12:.LC2851
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2852
	add	x0, x0, :lo12:.LC2852
	bl	printf
	adrp	x0, .LC2853
	add	x0, x0, :lo12:.LC2853
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2854
	add	x0, x0, :lo12:.LC2854
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2855
	add	x0, x0, :lo12:.LC2855
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2856
	add	x0, x0, :lo12:.LC2856
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2857
	add	x0, x0, :lo12:.LC2857
	bl	printf
	adrp	x0, .LC2858
	add	x0, x0, :lo12:.LC2858
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2859
	add	x0, x0, :lo12:.LC2859
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2860
	add	x0, x0, :lo12:.LC2860
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2861
	add	x0, x0, :lo12:.LC2861
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2862
	add	x0, x0, :lo12:.LC2862
	bl	printf
	adrp	x0, .LC2863
	add	x0, x0, :lo12:.LC2863
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2864
	add	x0, x0, :lo12:.LC2864
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2865
	add	x0, x0, :lo12:.LC2865
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2866
	add	x0, x0, :lo12:.LC2866
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2867
	add	x0, x0, :lo12:.LC2867
	bl	printf
	adrp	x0, .LC2868
	add	x0, x0, :lo12:.LC2868
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2869
	add	x0, x0, :lo12:.LC2869
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2870
	add	x0, x0, :lo12:.LC2870
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2871
	add	x0, x0, :lo12:.LC2871
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2872
	add	x0, x0, :lo12:.LC2872
	bl	printf
	adrp	x0, .LC2873
	add	x0, x0, :lo12:.LC2873
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2874
	add	x0, x0, :lo12:.LC2874
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2875
	add	x0, x0, :lo12:.LC2875
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2876
	add	x0, x0, :lo12:.LC2876
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2877
	add	x0, x0, :lo12:.LC2877
	bl	printf
	adrp	x0, .LC2878
	add	x0, x0, :lo12:.LC2878
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2879
	add	x0, x0, :lo12:.LC2879
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2880
	add	x0, x0, :lo12:.LC2880
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2881
	add	x0, x0, :lo12:.LC2881
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2882
	add	x0, x0, :lo12:.LC2882
	bl	printf
	adrp	x0, .LC2883
	add	x0, x0, :lo12:.LC2883
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2884
	add	x0, x0, :lo12:.LC2884
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2885
	add	x0, x0, :lo12:.LC2885
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2886
	add	x0, x0, :lo12:.LC2886
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2887
	add	x0, x0, :lo12:.LC2887
	bl	printf
	adrp	x0, .LC2888
	add	x0, x0, :lo12:.LC2888
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2889
	add	x0, x0, :lo12:.LC2889
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2890
	add	x0, x0, :lo12:.LC2890
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2891
	add	x0, x0, :lo12:.LC2891
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2892
	add	x0, x0, :lo12:.LC2892
	bl	printf
	adrp	x0, .LC2893
	add	x0, x0, :lo12:.LC2893
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2894
	add	x0, x0, :lo12:.LC2894
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2895
	add	x0, x0, :lo12:.LC2895
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2896
	add	x0, x0, :lo12:.LC2896
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2897
	add	x0, x0, :lo12:.LC2897
	bl	printf
	adrp	x0, .LC2898
	add	x0, x0, :lo12:.LC2898
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2899
	add	x0, x0, :lo12:.LC2899
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2900
	add	x0, x0, :lo12:.LC2900
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2901
	add	x0, x0, :lo12:.LC2901
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2902
	add	x0, x0, :lo12:.LC2902
	bl	printf
	adrp	x0, .LC2903
	add	x0, x0, :lo12:.LC2903
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2904
	add	x0, x0, :lo12:.LC2904
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2905
	add	x0, x0, :lo12:.LC2905
	bl	printf
	mov	x1, 4
	adrp	x0, .LC2906
	add	x0, x0, :lo12:.LC2906
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2907
	add	x0, x0, :lo12:.LC2907
	bl	printf
	adrp	x0, .LC2908
	add	x0, x0, :lo12:.LC2908
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2909
	add	x0, x0, :lo12:.LC2909
	bl	printf
	mov	w1, 0
	adrp	x0, .LC2910
	add	x0, x0, :lo12:.LC2910
	bl	printf
	adrp	x0, .LC2911
	add	x0, x0, :lo12:.LC2911
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2912
	add	x0, x0, :lo12:.LC2912
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2913
	add	x0, x0, :lo12:.LC2913
	bl	printf
	adrp	x0, .LC2914
	add	x0, x0, :lo12:.LC2914
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2915
	add	x0, x0, :lo12:.LC2915
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2916
	add	x0, x0, :lo12:.LC2916
	bl	printf
	adrp	x0, .LC2917
	add	x0, x0, :lo12:.LC2917
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2918
	add	x0, x0, :lo12:.LC2918
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2919
	add	x0, x0, :lo12:.LC2919
	bl	printf
	adrp	x0, .LC2920
	add	x0, x0, :lo12:.LC2920
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2921
	add	x0, x0, :lo12:.LC2921
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2922
	add	x0, x0, :lo12:.LC2922
	bl	printf
	adrp	x0, .LC2923
	add	x0, x0, :lo12:.LC2923
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2924
	add	x0, x0, :lo12:.LC2924
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2925
	add	x0, x0, :lo12:.LC2925
	bl	printf
	adrp	x0, .LC2926
	add	x0, x0, :lo12:.LC2926
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2927
	add	x0, x0, :lo12:.LC2927
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2928
	add	x0, x0, :lo12:.LC2928
	bl	printf
	adrp	x0, .LC2929
	add	x0, x0, :lo12:.LC2929
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2930
	add	x0, x0, :lo12:.LC2930
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2931
	add	x0, x0, :lo12:.LC2931
	bl	printf
	adrp	x0, .LC2932
	add	x0, x0, :lo12:.LC2932
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2933
	add	x0, x0, :lo12:.LC2933
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2934
	add	x0, x0, :lo12:.LC2934
	bl	printf
	adrp	x0, .LC2935
	add	x0, x0, :lo12:.LC2935
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2936
	add	x0, x0, :lo12:.LC2936
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2937
	add	x0, x0, :lo12:.LC2937
	bl	printf
	adrp	x0, .LC2938
	add	x0, x0, :lo12:.LC2938
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2939
	add	x0, x0, :lo12:.LC2939
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2940
	add	x0, x0, :lo12:.LC2940
	bl	printf
	adrp	x0, .LC2941
	add	x0, x0, :lo12:.LC2941
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2942
	add	x0, x0, :lo12:.LC2942
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2943
	add	x0, x0, :lo12:.LC2943
	bl	printf
	adrp	x0, .LC2944
	add	x0, x0, :lo12:.LC2944
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2945
	add	x0, x0, :lo12:.LC2945
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2946
	add	x0, x0, :lo12:.LC2946
	bl	printf
	adrp	x0, .LC2947
	add	x0, x0, :lo12:.LC2947
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2948
	add	x0, x0, :lo12:.LC2948
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2949
	add	x0, x0, :lo12:.LC2949
	bl	printf
	adrp	x0, .LC2950
	add	x0, x0, :lo12:.LC2950
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2951
	add	x0, x0, :lo12:.LC2951
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2952
	add	x0, x0, :lo12:.LC2952
	bl	printf
	adrp	x0, .LC2953
	add	x0, x0, :lo12:.LC2953
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2954
	add	x0, x0, :lo12:.LC2954
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2955
	add	x0, x0, :lo12:.LC2955
	bl	printf
	adrp	x0, .LC2956
	add	x0, x0, :lo12:.LC2956
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2957
	add	x0, x0, :lo12:.LC2957
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2958
	add	x0, x0, :lo12:.LC2958
	bl	printf
	adrp	x0, .LC2959
	add	x0, x0, :lo12:.LC2959
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2960
	add	x0, x0, :lo12:.LC2960
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2961
	add	x0, x0, :lo12:.LC2961
	bl	printf
	adrp	x0, .LC2962
	add	x0, x0, :lo12:.LC2962
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2963
	add	x0, x0, :lo12:.LC2963
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2964
	add	x0, x0, :lo12:.LC2964
	bl	printf
	adrp	x0, .LC2965
	add	x0, x0, :lo12:.LC2965
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2966
	add	x0, x0, :lo12:.LC2966
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2967
	add	x0, x0, :lo12:.LC2967
	bl	printf
	adrp	x0, .LC2968
	add	x0, x0, :lo12:.LC2968
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2969
	add	x0, x0, :lo12:.LC2969
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2970
	add	x0, x0, :lo12:.LC2970
	bl	printf
	adrp	x0, .LC2971
	add	x0, x0, :lo12:.LC2971
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2972
	add	x0, x0, :lo12:.LC2972
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2973
	add	x0, x0, :lo12:.LC2973
	bl	printf
	adrp	x0, .LC2974
	add	x0, x0, :lo12:.LC2974
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2975
	add	x0, x0, :lo12:.LC2975
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2976
	add	x0, x0, :lo12:.LC2976
	bl	printf
	adrp	x0, .LC2977
	add	x0, x0, :lo12:.LC2977
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2978
	add	x0, x0, :lo12:.LC2978
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2979
	add	x0, x0, :lo12:.LC2979
	bl	printf
	adrp	x0, .LC2980
	add	x0, x0, :lo12:.LC2980
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2981
	add	x0, x0, :lo12:.LC2981
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2982
	add	x0, x0, :lo12:.LC2982
	bl	printf
	adrp	x0, .LC2983
	add	x0, x0, :lo12:.LC2983
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2984
	add	x0, x0, :lo12:.LC2984
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2985
	add	x0, x0, :lo12:.LC2985
	bl	printf
	adrp	x0, .LC2986
	add	x0, x0, :lo12:.LC2986
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2987
	add	x0, x0, :lo12:.LC2987
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2988
	add	x0, x0, :lo12:.LC2988
	bl	printf
	adrp	x0, .LC2989
	add	x0, x0, :lo12:.LC2989
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2990
	add	x0, x0, :lo12:.LC2990
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2991
	add	x0, x0, :lo12:.LC2991
	bl	printf
	adrp	x0, .LC2992
	add	x0, x0, :lo12:.LC2992
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2993
	add	x0, x0, :lo12:.LC2993
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2994
	add	x0, x0, :lo12:.LC2994
	bl	printf
	adrp	x0, .LC2995
	add	x0, x0, :lo12:.LC2995
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2996
	add	x0, x0, :lo12:.LC2996
	bl	printf
	mov	w1, 1
	adrp	x0, .LC2997
	add	x0, x0, :lo12:.LC2997
	bl	printf
	adrp	x0, .LC2998
	add	x0, x0, :lo12:.LC2998
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2999
	add	x0, x0, :lo12:.LC2999
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3000
	add	x0, x0, :lo12:.LC3000
	bl	printf
	adrp	x0, .LC3001
	add	x0, x0, :lo12:.LC3001
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3002
	add	x0, x0, :lo12:.LC3002
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3003
	add	x0, x0, :lo12:.LC3003
	bl	printf
	adrp	x0, .LC3004
	add	x0, x0, :lo12:.LC3004
	bl	printf
	mov	x1, 0
	mov	x0, 10
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3005
	add	x0, x0, :lo12:.LC3005
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3006
	add	x0, x0, :lo12:.LC3006
	bl	printf
	adrp	x0, .LC3007
	add	x0, x0, :lo12:.LC3007
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3008
	add	x0, x0, :lo12:.LC3008
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3009
	add	x0, x0, :lo12:.LC3009
	bl	printf
	adrp	x0, .LC3010
	add	x0, x0, :lo12:.LC3010
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3011
	add	x0, x0, :lo12:.LC3011
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3012
	add	x0, x0, :lo12:.LC3012
	bl	printf
	adrp	x0, .LC3013
	add	x0, x0, :lo12:.LC3013
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3014
	add	x0, x0, :lo12:.LC3014
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3015
	add	x0, x0, :lo12:.LC3015
	bl	printf
	adrp	x0, .LC3016
	add	x0, x0, :lo12:.LC3016
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3017
	add	x0, x0, :lo12:.LC3017
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3018
	add	x0, x0, :lo12:.LC3018
	bl	printf
	adrp	x0, .LC3019
	add	x0, x0, :lo12:.LC3019
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3020
	add	x0, x0, :lo12:.LC3020
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3021
	add	x0, x0, :lo12:.LC3021
	bl	printf
	adrp	x0, .LC3022
	add	x0, x0, :lo12:.LC3022
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3023
	add	x0, x0, :lo12:.LC3023
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3024
	add	x0, x0, :lo12:.LC3024
	bl	printf
	adrp	x0, .LC3025
	add	x0, x0, :lo12:.LC3025
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3026
	add	x0, x0, :lo12:.LC3026
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3027
	add	x0, x0, :lo12:.LC3027
	bl	printf
	adrp	x0, .LC3028
	add	x0, x0, :lo12:.LC3028
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3029
	add	x0, x0, :lo12:.LC3029
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3030
	add	x0, x0, :lo12:.LC3030
	bl	printf
	adrp	x0, .LC3031
	add	x0, x0, :lo12:.LC3031
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3032
	add	x0, x0, :lo12:.LC3032
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3033
	add	x0, x0, :lo12:.LC3033
	bl	printf
	adrp	x0, .LC3034
	add	x0, x0, :lo12:.LC3034
	bl	printf
	mov	x1, 0
	mov	x0, 33
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3035
	add	x0, x0, :lo12:.LC3035
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3036
	add	x0, x0, :lo12:.LC3036
	bl	printf
	adrp	x0, .LC3037
	add	x0, x0, :lo12:.LC3037
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3038
	add	x0, x0, :lo12:.LC3038
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3039
	add	x0, x0, :lo12:.LC3039
	bl	printf
	adrp	x0, .LC3040
	add	x0, x0, :lo12:.LC3040
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3041
	add	x0, x0, :lo12:.LC3041
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3042
	add	x0, x0, :lo12:.LC3042
	bl	printf
	adrp	x0, .LC3043
	add	x0, x0, :lo12:.LC3043
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3044
	add	x0, x0, :lo12:.LC3044
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3045
	add	x0, x0, :lo12:.LC3045
	bl	printf
	adrp	x0, .LC3046
	add	x0, x0, :lo12:.LC3046
	bl	printf
	mov	x1, 0
	mov	x0, 128
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3047
	add	x0, x0, :lo12:.LC3047
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3048
	add	x0, x0, :lo12:.LC3048
	bl	printf
	adrp	x0, .LC3049
	add	x0, x0, :lo12:.LC3049
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3050
	add	x0, x0, :lo12:.LC3050
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3051
	add	x0, x0, :lo12:.LC3051
	bl	printf
	adrp	x0, .LC3052
	add	x0, x0, :lo12:.LC3052
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3053
	add	x0, x0, :lo12:.LC3053
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3054
	add	x0, x0, :lo12:.LC3054
	bl	printf
	adrp	x0, .LC3055
	add	x0, x0, :lo12:.LC3055
	bl	printf
	mov	x1, 0
	mov	x0, 24576
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3056
	add	x0, x0, :lo12:.LC3056
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3057
	add	x0, x0, :lo12:.LC3057
	bl	printf
	adrp	x0, .LC3058
	add	x0, x0, :lo12:.LC3058
	bl	printf
	mov	x1, 0
	mov	x0, 16
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3059
	add	x0, x0, :lo12:.LC3059
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3060
	add	x0, x0, :lo12:.LC3060
	bl	printf
	adrp	x0, .LC3061
	add	x0, x0, :lo12:.LC3061
	bl	printf
	mov	x1, 0
	mov	x0, 8192
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3062
	add	x0, x0, :lo12:.LC3062
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3063
	add	x0, x0, :lo12:.LC3063
	bl	printf
	adrp	x0, .LC3064
	add	x0, x0, :lo12:.LC3064
	bl	printf
	mov	x1, 0
	mov	x0, 4095
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3065
	add	x0, x0, :lo12:.LC3065
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3066
	add	x0, x0, :lo12:.LC3066
	bl	printf
	adrp	x0, .LC3067
	add	x0, x0, :lo12:.LC3067
	bl	printf
	mov	x1, 0
	mov	x0, 512
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3068
	add	x0, x0, :lo12:.LC3068
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3069
	add	x0, x0, :lo12:.LC3069
	bl	printf
	adrp	x0, .LC3070
	add	x0, x0, :lo12:.LC3070
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3071
	add	x0, x0, :lo12:.LC3071
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3072
	add	x0, x0, :lo12:.LC3072
	bl	printf
	adrp	x0, .LC3073
	add	x0, x0, :lo12:.LC3073
	bl	printf
	mov	x1, 0
	mov	x0, 16384
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3074
	add	x0, x0, :lo12:.LC3074
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3075
	add	x0, x0, :lo12:.LC3075
	bl	printf
	adrp	x0, .LC3076
	add	x0, x0, :lo12:.LC3076
	bl	printf
	mov	x1, 0
	mov	x0, 12288
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3077
	add	x0, x0, :lo12:.LC3077
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3078
	add	x0, x0, :lo12:.LC3078
	bl	printf
	adrp	x0, .LC3079
	add	x0, x0, :lo12:.LC3079
	bl	printf
	mov	x1, 0
	mov	x0, 12
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3080
	add	x0, x0, :lo12:.LC3080
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3081
	add	x0, x0, :lo12:.LC3081
	bl	printf
	adrp	x0, .LC3082
	add	x0, x0, :lo12:.LC3082
	bl	printf
	mov	x1, 0
	mov	x0, 32
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3083
	add	x0, x0, :lo12:.LC3083
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3084
	add	x0, x0, :lo12:.LC3084
	bl	printf
	adrp	x0, .LC3085
	add	x0, x0, :lo12:.LC3085
	bl	printf
	mov	x1, 0
	mov	x0, 256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3086
	add	x0, x0, :lo12:.LC3086
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3087
	add	x0, x0, :lo12:.LC3087
	bl	printf
	adrp	x0, .LC3088
	add	x0, x0, :lo12:.LC3088
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3089
	add	x0, x0, :lo12:.LC3089
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3090
	add	x0, x0, :lo12:.LC3090
	bl	printf
	adrp	x0, .LC3091
	add	x0, x0, :lo12:.LC3091
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3092
	add	x0, x0, :lo12:.LC3092
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3093
	add	x0, x0, :lo12:.LC3093
	bl	printf
	adrp	x0, .LC3094
	add	x0, x0, :lo12:.LC3094
	bl	printf
	mov	x1, 0
	mov	x0, 32768
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3095
	add	x0, x0, :lo12:.LC3095
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3096
	add	x0, x0, :lo12:.LC3096
	bl	printf
	adrp	x0, .LC3097
	add	x0, x0, :lo12:.LC3097
	bl	printf
	mov	x1, 0
	mov	x0, 64
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3098
	add	x0, x0, :lo12:.LC3098
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3099
	add	x0, x0, :lo12:.LC3099
	bl	printf
	adrp	x0, .LC3100
	add	x0, x0, :lo12:.LC3100
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3101
	add	x0, x0, :lo12:.LC3101
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3102
	add	x0, x0, :lo12:.LC3102
	bl	printf
	adrp	x0, .LC3103
	add	x0, x0, :lo12:.LC3103
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3104
	add	x0, x0, :lo12:.LC3104
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3105
	add	x0, x0, :lo12:.LC3105
	bl	printf
	adrp	x0, .LC3106
	add	x0, x0, :lo12:.LC3106
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3107
	add	x0, x0, :lo12:.LC3107
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3108
	add	x0, x0, :lo12:.LC3108
	bl	printf
	adrp	x0, .LC3109
	add	x0, x0, :lo12:.LC3109
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3110
	add	x0, x0, :lo12:.LC3110
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3111
	add	x0, x0, :lo12:.LC3111
	bl	printf
	adrp	x0, .LC3112
	add	x0, x0, :lo12:.LC3112
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3113
	add	x0, x0, :lo12:.LC3113
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3114
	add	x0, x0, :lo12:.LC3114
	bl	printf
	adrp	x0, .LC3115
	add	x0, x0, :lo12:.LC3115
	bl	printf
	mov	x1, 0
	mov	x0, 4095
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3116
	add	x0, x0, :lo12:.LC3116
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3117
	add	x0, x0, :lo12:.LC3117
	bl	printf
	adrp	x0, .LC3118
	add	x0, x0, :lo12:.LC3118
	bl	printf
	mov	x1, 0
	mov	x0, 12288
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3119
	add	x0, x0, :lo12:.LC3119
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3120
	add	x0, x0, :lo12:.LC3120
	bl	printf
	adrp	x0, .LC3121
	add	x0, x0, :lo12:.LC3121
	bl	printf
	mov	x1, 0
	mov	x0, 12
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3122
	add	x0, x0, :lo12:.LC3122
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3123
	add	x0, x0, :lo12:.LC3123
	bl	printf
	adrp	x0, .LC3124
	add	x0, x0, :lo12:.LC3124
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3125
	add	x0, x0, :lo12:.LC3125
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3126
	add	x0, x0, :lo12:.LC3126
	bl	printf
	adrp	x0, .LC3127
	add	x0, x0, :lo12:.LC3127
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3128
	add	x0, x0, :lo12:.LC3128
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3129
	add	x0, x0, :lo12:.LC3129
	bl	printf
	adrp	x0, .LC3130
	add	x0, x0, :lo12:.LC3130
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3131
	add	x0, x0, :lo12:.LC3131
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3132
	add	x0, x0, :lo12:.LC3132
	bl	printf
	adrp	x0, .LC3133
	add	x0, x0, :lo12:.LC3133
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3134
	add	x0, x0, :lo12:.LC3134
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3135
	add	x0, x0, :lo12:.LC3135
	bl	printf
	adrp	x0, .LC3136
	add	x0, x0, :lo12:.LC3136
	bl	printf
	mov	x1, 0
	mov	x0, -1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 8
	adrp	x0, .LC3138
	add	x0, x0, :lo12:.LC3138
	bl	printf
	mov	w1, 0
	adrp	x0, .LC3139
	add	x0, x0, :lo12:.LC3139
	bl	printf
	adrp	x0, .LC3140
	add	x0, x0, :lo12:.LC3140
	bl	printf
	mov	x1, -1
	mov	x0, -2
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3141
	add	x0, x0, :lo12:.LC3141
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3142
	add	x0, x0, :lo12:.LC3142
	bl	printf
	adrp	x0, .LC3143
	add	x0, x0, :lo12:.LC3143
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3144
	add	x0, x0, :lo12:.LC3144
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3145
	add	x0, x0, :lo12:.LC3145
	bl	printf
	adrp	x0, .LC3146
	add	x0, x0, :lo12:.LC3146
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3147
	add	x0, x0, :lo12:.LC3147
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3148
	add	x0, x0, :lo12:.LC3148
	bl	printf
	adrp	x0, .LC3149
	add	x0, x0, :lo12:.LC3149
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3150
	add	x0, x0, :lo12:.LC3150
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3151
	add	x0, x0, :lo12:.LC3151
	bl	printf
	adrp	x0, .LC3152
	add	x0, x0, :lo12:.LC3152
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3153
	add	x0, x0, :lo12:.LC3153
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3154
	add	x0, x0, :lo12:.LC3154
	bl	printf
	adrp	x0, .LC3155
	add	x0, x0, :lo12:.LC3155
	bl	printf
	mov	x1, 0
	mov	x0, 7
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3156
	add	x0, x0, :lo12:.LC3156
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3157
	add	x0, x0, :lo12:.LC3157
	bl	printf
	adrp	x0, .LC3158
	add	x0, x0, :lo12:.LC3158
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3159
	add	x0, x0, :lo12:.LC3159
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3160
	add	x0, x0, :lo12:.LC3160
	bl	printf
	adrp	x0, .LC3161
	add	x0, x0, :lo12:.LC3161
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3162
	add	x0, x0, :lo12:.LC3162
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3163
	add	x0, x0, :lo12:.LC3163
	bl	printf
	adrp	x0, .LC3164
	add	x0, x0, :lo12:.LC3164
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3165
	add	x0, x0, :lo12:.LC3165
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3166
	add	x0, x0, :lo12:.LC3166
	bl	printf
	adrp	x0, .LC3167
	add	x0, x0, :lo12:.LC3167
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3168
	add	x0, x0, :lo12:.LC3168
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3169
	add	x0, x0, :lo12:.LC3169
	bl	printf
	adrp	x0, .LC3170
	add	x0, x0, :lo12:.LC3170
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3171
	add	x0, x0, :lo12:.LC3171
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3172
	add	x0, x0, :lo12:.LC3172
	bl	printf
	adrp	x0, .LC3173
	add	x0, x0, :lo12:.LC3173
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3174
	add	x0, x0, :lo12:.LC3174
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3175
	add	x0, x0, :lo12:.LC3175
	bl	printf
	adrp	x0, .LC3176
	add	x0, x0, :lo12:.LC3176
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3177
	add	x0, x0, :lo12:.LC3177
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3178
	add	x0, x0, :lo12:.LC3178
	bl	printf
	adrp	x0, .LC3179
	add	x0, x0, :lo12:.LC3179
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3180
	add	x0, x0, :lo12:.LC3180
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3181
	add	x0, x0, :lo12:.LC3181
	bl	printf
	adrp	x0, .LC3182
	add	x0, x0, :lo12:.LC3182
	bl	printf
	mov	x1, 0
	mov	x0, 40
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3183
	add	x0, x0, :lo12:.LC3183
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3184
	add	x0, x0, :lo12:.LC3184
	bl	printf
	adrp	x0, .LC3185
	add	x0, x0, :lo12:.LC3185
	bl	printf
	mov	x1, 0
	mov	x0, 40
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3186
	add	x0, x0, :lo12:.LC3186
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3187
	add	x0, x0, :lo12:.LC3187
	bl	printf
	adrp	x0, .LC3188
	add	x0, x0, :lo12:.LC3188
	bl	printf
	mov	x1, 0
	mov	x0, 20
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3189
	add	x0, x0, :lo12:.LC3189
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3190
	add	x0, x0, :lo12:.LC3190
	bl	printf
	adrp	x0, .LC3191
	add	x0, x0, :lo12:.LC3191
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3192
	add	x0, x0, :lo12:.LC3192
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3193
	add	x0, x0, :lo12:.LC3193
	bl	printf
	adrp	x0, .LC3194
	add	x0, x0, :lo12:.LC3194
	bl	printf
	mov	x1, 0
	mov	x0, 20
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3195
	add	x0, x0, :lo12:.LC3195
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3196
	add	x0, x0, :lo12:.LC3196
	bl	printf
	adrp	x0, .LC3197
	add	x0, x0, :lo12:.LC3197
	bl	printf
	mov	x1, 0
	mov	x0, 40
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3198
	add	x0, x0, :lo12:.LC3198
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3199
	add	x0, x0, :lo12:.LC3199
	bl	printf
	adrp	x0, .LC3200
	add	x0, x0, :lo12:.LC3200
	bl	printf
	mov	x1, 0
	mov	x0, 20
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3201
	add	x0, x0, :lo12:.LC3201
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3202
	add	x0, x0, :lo12:.LC3202
	bl	printf
	adrp	x0, .LC3203
	add	x0, x0, :lo12:.LC3203
	bl	printf
	mov	x1, 0
	mov	x0, 58
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3204
	add	x0, x0, :lo12:.LC3204
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3205
	add	x0, x0, :lo12:.LC3205
	bl	printf
	adrp	x0, .LC3206
	add	x0, x0, :lo12:.LC3206
	bl	printf
	mov	x1, 0
	mov	x0, 4096
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3207
	add	x0, x0, :lo12:.LC3207
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3208
	add	x0, x0, :lo12:.LC3208
	bl	printf
	adrp	x0, .LC3209
	add	x0, x0, :lo12:.LC3209
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3210
	add	x0, x0, :lo12:.LC3210
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3211
	add	x0, x0, :lo12:.LC3211
	bl	printf
	adrp	x0, .LC3212
	add	x0, x0, :lo12:.LC3212
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3213
	add	x0, x0, :lo12:.LC3213
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3214
	add	x0, x0, :lo12:.LC3214
	bl	printf
	adrp	x0, .LC3215
	add	x0, x0, :lo12:.LC3215
	bl	printf
	mov	x1, 0
	mov	x0, -1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 8
	adrp	x0, .LC3216
	add	x0, x0, :lo12:.LC3216
	bl	printf
	mov	w1, 0
	adrp	x0, .LC3217
	add	x0, x0, :lo12:.LC3217
	bl	printf
	adrp	x0, .LC3218
	add	x0, x0, :lo12:.LC3218
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3219
	add	x0, x0, :lo12:.LC3219
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3220
	add	x0, x0, :lo12:.LC3220
	bl	printf
	adrp	x0, .LC3221
	add	x0, x0, :lo12:.LC3221
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3222
	add	x0, x0, :lo12:.LC3222
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3223
	add	x0, x0, :lo12:.LC3223
	bl	printf
	adrp	x0, .LC3224
	add	x0, x0, :lo12:.LC3224
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3225
	add	x0, x0, :lo12:.LC3225
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3226
	add	x0, x0, :lo12:.LC3226
	bl	printf
	adrp	x0, .LC3227
	add	x0, x0, :lo12:.LC3227
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3228
	add	x0, x0, :lo12:.LC3228
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3229
	add	x0, x0, :lo12:.LC3229
	bl	printf
	adrp	x0, .LC3230
	add	x0, x0, :lo12:.LC3230
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3231
	add	x0, x0, :lo12:.LC3231
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3232
	add	x0, x0, :lo12:.LC3232
	bl	printf
	adrp	x0, .LC3233
	add	x0, x0, :lo12:.LC3233
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3234
	add	x0, x0, :lo12:.LC3234
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3235
	add	x0, x0, :lo12:.LC3235
	bl	printf
	adrp	x0, .LC3236
	add	x0, x0, :lo12:.LC3236
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3237
	add	x0, x0, :lo12:.LC3237
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3238
	add	x0, x0, :lo12:.LC3238
	bl	printf
	adrp	x0, .LC3239
	add	x0, x0, :lo12:.LC3239
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3240
	add	x0, x0, :lo12:.LC3240
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3241
	add	x0, x0, :lo12:.LC3241
	bl	printf
	adrp	x0, .LC3242
	add	x0, x0, :lo12:.LC3242
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3243
	add	x0, x0, :lo12:.LC3243
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3244
	add	x0, x0, :lo12:.LC3244
	bl	printf
	adrp	x0, .LC3245
	add	x0, x0, :lo12:.LC3245
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3246
	add	x0, x0, :lo12:.LC3246
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3247
	add	x0, x0, :lo12:.LC3247
	bl	printf
	adrp	x0, .LC3248
	add	x0, x0, :lo12:.LC3248
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3249
	add	x0, x0, :lo12:.LC3249
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3250
	add	x0, x0, :lo12:.LC3250
	bl	printf
	adrp	x0, .LC3251
	add	x0, x0, :lo12:.LC3251
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3252
	add	x0, x0, :lo12:.LC3252
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3253
	add	x0, x0, :lo12:.LC3253
	bl	printf
	adrp	x0, .LC3254
	add	x0, x0, :lo12:.LC3254
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3255
	add	x0, x0, :lo12:.LC3255
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3256
	add	x0, x0, :lo12:.LC3256
	bl	printf
	adrp	x0, .LC3257
	add	x0, x0, :lo12:.LC3257
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3258
	add	x0, x0, :lo12:.LC3258
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3259
	add	x0, x0, :lo12:.LC3259
	bl	printf
	adrp	x0, .LC3260
	add	x0, x0, :lo12:.LC3260
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3261
	add	x0, x0, :lo12:.LC3261
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3262
	add	x0, x0, :lo12:.LC3262
	bl	printf
	adrp	x0, .LC3263
	add	x0, x0, :lo12:.LC3263
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3264
	add	x0, x0, :lo12:.LC3264
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3265
	add	x0, x0, :lo12:.LC3265
	bl	printf
	adrp	x0, .LC3266
	add	x0, x0, :lo12:.LC3266
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3267
	add	x0, x0, :lo12:.LC3267
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3268
	add	x0, x0, :lo12:.LC3268
	bl	printf
	adrp	x0, .LC3269
	add	x0, x0, :lo12:.LC3269
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3270
	add	x0, x0, :lo12:.LC3270
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3271
	add	x0, x0, :lo12:.LC3271
	bl	printf
	adrp	x0, .LC3272
	add	x0, x0, :lo12:.LC3272
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3273
	add	x0, x0, :lo12:.LC3273
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3274
	add	x0, x0, :lo12:.LC3274
	bl	printf
	adrp	x0, .LC3275
	add	x0, x0, :lo12:.LC3275
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3276
	add	x0, x0, :lo12:.LC3276
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3277
	add	x0, x0, :lo12:.LC3277
	bl	printf
	adrp	x0, .LC3278
	add	x0, x0, :lo12:.LC3278
	bl	printf
	mov	x1, 0
	mov	x0, 19
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3279
	add	x0, x0, :lo12:.LC3279
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3280
	add	x0, x0, :lo12:.LC3280
	bl	printf
	adrp	x0, .LC3281
	add	x0, x0, :lo12:.LC3281
	bl	printf
	mov	x1, 0
	mov	x0, 112
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3282
	add	x0, x0, :lo12:.LC3282
	bl	printf
	mov	w1, 0
	adrp	x0, .LC3283
	add	x0, x0, :lo12:.LC3283
	bl	printf
	adrp	x0, .LC3284
	add	x0, x0, :lo12:.LC3284
	bl	printf
	mov	x1, 0
	mov	x0, 15
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3285
	add	x0, x0, :lo12:.LC3285
	bl	printf
	mov	w1, 0
	adrp	x0, .LC3286
	add	x0, x0, :lo12:.LC3286
	bl	printf
	adrp	x0, .LC3287
	add	x0, x0, :lo12:.LC3287
	bl	printf
	mov	x1, 0
	mov	x0, 16256
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3288
	add	x0, x0, :lo12:.LC3288
	bl	printf
	mov	w1, 0
	adrp	x0, .LC3289
	add	x0, x0, :lo12:.LC3289
	bl	printf
	adrp	x0, .LC3290
	add	x0, x0, :lo12:.LC3290
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3291
	add	x0, x0, :lo12:.LC3291
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3292
	add	x0, x0, :lo12:.LC3292
	bl	printf
	adrp	x0, .LC3293
	add	x0, x0, :lo12:.LC3293
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3294
	add	x0, x0, :lo12:.LC3294
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3295
	add	x0, x0, :lo12:.LC3295
	bl	printf
	adrp	x0, .LC3296
	add	x0, x0, :lo12:.LC3296
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC3297
	add	x0, x0, :lo12:.LC3297
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3298
	add	x0, x0, :lo12:.LC3298
	bl	printf
	adrp	x0, .LC3299
	add	x0, x0, :lo12:.LC3299
	bl	printf
	mov	w1, 57
	b	.L20
	.p2align 2,,3
.L26:
	ldrb	w1, [x19], 1
.L20:
	mov	x0, x21
	bl	printf
	cmp	x19, x20
	bne	.L26
	mov	w0, 10
	bl	putchar
	adrp	x0, .LC3302
	adrp	x19, .LC3303+1
	add	x0, x0, :lo12:.LC3302
	add	x19, x19, :lo12:.LC3303+1
	adrp	x22, .LC3303
	bl	printf
	add	x22, x22, :lo12:.LC3303
	mov	x20, x19
	add	x22, x22, 41
	mov	w1, 48
	b	.L22
	.p2align 2,,3
.L27:
	ldrb	w1, [x20], 1
.L22:
	mov	x0, x21
	bl	printf
	cmp	x20, x22
	bne	.L27
	mov	w0, 10
	bl	putchar
	adrp	x0, .LC3304
	add	x0, x0, :lo12:.LC3304
	bl	printf
	mov	w1, 48
	b	.L24
	.p2align 2,,3
.L28:
	ldrb	w1, [x19], 1
.L24:
	mov	x0, x21
	bl	printf
	cmp	x19, x22
	bne	.L28
	mov	w0, 10
	bl	putchar
	mov	x1, 20
	adrp	x0, .LC3305
	add	x0, x0, :lo12:.LC3305
	bl	printf
	mov	x1, 1
	adrp	x0, .LC3306
	add	x0, x0, :lo12:.LC3306
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3307
	add	x0, x0, :lo12:.LC3307
	bl	printf
	mov	x1, 24
	adrp	x0, .LC3308
	add	x0, x0, :lo12:.LC3308
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3309
	add	x0, x0, :lo12:.LC3309
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3310
	add	x0, x0, :lo12:.LC3310
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3311
	add	x0, x0, :lo12:.LC3311
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3312
	add	x0, x0, :lo12:.LC3312
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3313
	add	x0, x0, :lo12:.LC3313
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3314
	add	x0, x0, :lo12:.LC3314
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3315
	add	x0, x0, :lo12:.LC3315
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3316
	add	x0, x0, :lo12:.LC3316
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3317
	add	x0, x0, :lo12:.LC3317
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3318
	add	x0, x0, :lo12:.LC3318
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3319
	add	x0, x0, :lo12:.LC3319
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3320
	add	x0, x0, :lo12:.LC3320
	bl	printf
	mov	x1, 12
	adrp	x0, .LC3321
	add	x0, x0, :lo12:.LC3321
	bl	printf
	mov	x1, 32
	adrp	x0, .LC3322
	add	x0, x0, :lo12:.LC3322
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3323
	add	x0, x0, :lo12:.LC3323
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3324
	add	x0, x0, :lo12:.LC3324
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3325
	add	x0, x0, :lo12:.LC3325
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3326
	add	x0, x0, :lo12:.LC3326
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3327
	add	x0, x0, :lo12:.LC3327
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3328
	add	x0, x0, :lo12:.LC3328
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3329
	add	x0, x0, :lo12:.LC3329
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3330
	add	x0, x0, :lo12:.LC3330
	bl	printf
	mov	x1, 56
	adrp	x0, .LC3331
	add	x0, x0, :lo12:.LC3331
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3332
	add	x0, x0, :lo12:.LC3332
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3333
	add	x0, x0, :lo12:.LC3333
	bl	printf
	mov	x1, 4
	adrp	x0, .LC3334
	add	x0, x0, :lo12:.LC3334
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3335
	add	x0, x0, :lo12:.LC3335
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3336
	add	x0, x0, :lo12:.LC3336
	bl	printf
	mov	x1, 24
	adrp	x0, .LC3337
	add	x0, x0, :lo12:.LC3337
	bl	printf
	mov	x1, 32
	adrp	x0, .LC3338
	add	x0, x0, :lo12:.LC3338
	bl	printf
	mov	x1, 40
	adrp	x0, .LC3339
	add	x0, x0, :lo12:.LC3339
	bl	printf
	mov	x1, 48
	adrp	x0, .LC3340
	add	x0, x0, :lo12:.LC3340
	bl	printf
	mov	x1, 32
	adrp	x0, .LC3341
	add	x0, x0, :lo12:.LC3341
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3342
	add	x0, x0, :lo12:.LC3342
	bl	printf
	mov	x1, 0
	adrp	x0, .LC3343
	add	x0, x0, :lo12:.LC3343
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3344
	add	x0, x0, :lo12:.LC3344
	bl	printf
	mov	x1, 16
	adrp	x0, .LC3345
	add	x0, x0, :lo12:.LC3345
	bl	printf
	mov	x1, 24
	adrp	x0, .LC3346
	add	x0, x0, :lo12:.LC3346
	bl	printf
	ldp	x19, x20, [sp, 16]
	mov	w0, 0
	ldp	x21, x22, [sp, 32]
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 21
	.cfi_restore 22
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE2:
	.size	main, .-main
	.section	.rodata.cst16,"aM",@progbits,16
	.align	4
.LC0:
	.xword	-3689348814741910323
	.xword	-3689348814741910324
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
