	.arch armv8-a
	.file	"records.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC0:
	.string	"size.__builtin_va_list_record=%zu\n"
	.align	3
.LC1:
	.string	"align.__builtin_va_list_record=%zu\n"
	.align	3
.LC2:
	.string	"offset.__builtin_va_list_record.__stack=%zu\n"
	.align	3
.LC3:
	.string	"offset.__builtin_va_list_record.__gr_top=%zu\n"
	.align	3
.LC4:
	.string	"offset.__builtin_va_list_record.__vr_top=%zu\n"
	.align	3
.LC5:
	.string	"offset.__builtin_va_list_record.__gr_offs=%zu\n"
	.align	3
.LC6:
	.string	"offset.__builtin_va_list_record.__vr_offs=%zu\n"
	.align	3
.LC7:
	.string	"size.sqlite3_file=%zu\n"
	.align	3
.LC8:
	.string	"align.sqlite3_file=%zu\n"
	.align	3
.LC9:
	.string	"offset.sqlite3_file.pMethods=%zu\n"
	.align	3
.LC10:
	.string	"size.sqlite3_index_constraint=%zu\n"
	.align	3
.LC11:
	.string	"align.sqlite3_index_constraint=%zu\n"
	.align	3
.LC12:
	.string	"offset.sqlite3_index_constraint.iColumn=%zu\n"
	.align	3
.LC13:
	.string	"offset.sqlite3_index_constraint.op=%zu\n"
	.align	3
.LC14:
	.string	"offset.sqlite3_index_constraint.usable=%zu\n"
	.align	3
.LC15:
	.string	"offset.sqlite3_index_constraint.iTermOffset=%zu\n"
	.align	3
.LC16:
	.string	"size.sqlite3_index_constraint_usage=%zu\n"
	.align	3
.LC17:
	.string	"align.sqlite3_index_constraint_usage=%zu\n"
	.align	3
.LC18:
	.string	"offset.sqlite3_index_constraint_usage.argvIndex=%zu\n"
	.align	3
.LC19:
	.string	"offset.sqlite3_index_constraint_usage.omit=%zu\n"
	.align	3
.LC20:
	.string	"size.sqlite3_index_info=%zu\n"
	.align	3
.LC21:
	.string	"align.sqlite3_index_info=%zu\n"
	.align	3
.LC22:
	.string	"offset.sqlite3_index_info.nConstraint=%zu\n"
	.align	3
.LC23:
	.string	"offset.sqlite3_index_info.aConstraint=%zu\n"
	.align	3
.LC24:
	.string	"offset.sqlite3_index_info.nOrderBy=%zu\n"
	.align	3
.LC25:
	.string	"offset.sqlite3_index_info.aOrderBy=%zu\n"
	.align	3
.LC26:
	.string	"offset.sqlite3_index_info.aConstraintUsage=%zu\n"
	.align	3
.LC27:
	.string	"offset.sqlite3_index_info.idxNum=%zu\n"
	.align	3
.LC28:
	.string	"offset.sqlite3_index_info.idxStr=%zu\n"
	.align	3
.LC29:
	.string	"offset.sqlite3_index_info.needToFreeIdxStr=%zu\n"
	.align	3
.LC30:
	.string	"offset.sqlite3_index_info.orderByConsumed=%zu\n"
	.align	3
.LC31:
	.string	"offset.sqlite3_index_info.estimatedCost=%zu\n"
	.align	3
.LC32:
	.string	"offset.sqlite3_index_info.estimatedRows=%zu\n"
	.align	3
.LC33:
	.string	"offset.sqlite3_index_info.idxFlags=%zu\n"
	.align	3
.LC34:
	.string	"offset.sqlite3_index_info.colUsed=%zu\n"
	.align	3
.LC35:
	.string	"size.sqlite3_index_orderby=%zu\n"
	.align	3
.LC36:
	.string	"align.sqlite3_index_orderby=%zu\n"
	.align	3
.LC37:
	.string	"offset.sqlite3_index_orderby.iColumn=%zu\n"
	.align	3
.LC38:
	.string	"offset.sqlite3_index_orderby.desc=%zu\n"
	.align	3
.LC39:
	.string	"size.sqlite3_io_methods=%zu\n"
	.align	3
.LC40:
	.string	"align.sqlite3_io_methods=%zu\n"
	.align	3
.LC41:
	.string	"offset.sqlite3_io_methods.iVersion=%zu\n"
	.align	3
.LC42:
	.string	"offset.sqlite3_io_methods.xClose=%zu\n"
	.align	3
.LC43:
	.string	"offset.sqlite3_io_methods.xRead=%zu\n"
	.align	3
.LC44:
	.string	"offset.sqlite3_io_methods.xWrite=%zu\n"
	.align	3
.LC45:
	.string	"offset.sqlite3_io_methods.xTruncate=%zu\n"
	.align	3
.LC46:
	.string	"offset.sqlite3_io_methods.xSync=%zu\n"
	.align	3
.LC47:
	.string	"offset.sqlite3_io_methods.xFileSize=%zu\n"
	.align	3
.LC48:
	.string	"offset.sqlite3_io_methods.xLock=%zu\n"
	.align	3
.LC49:
	.string	"offset.sqlite3_io_methods.xUnlock=%zu\n"
	.align	3
.LC50:
	.string	"offset.sqlite3_io_methods.xCheckReservedLock=%zu\n"
	.align	3
.LC51:
	.string	"offset.sqlite3_io_methods.xFileControl=%zu\n"
	.align	3
.LC52:
	.string	"offset.sqlite3_io_methods.xSectorSize=%zu\n"
	.align	3
.LC53:
	.string	"offset.sqlite3_io_methods.xDeviceCharacteristics=%zu\n"
	.align	3
.LC54:
	.string	"offset.sqlite3_io_methods.xShmMap=%zu\n"
	.align	3
.LC55:
	.string	"offset.sqlite3_io_methods.xShmLock=%zu\n"
	.align	3
.LC56:
	.string	"offset.sqlite3_io_methods.xShmBarrier=%zu\n"
	.align	3
.LC57:
	.string	"offset.sqlite3_io_methods.xShmUnmap=%zu\n"
	.align	3
.LC58:
	.string	"offset.sqlite3_io_methods.xFetch=%zu\n"
	.align	3
.LC59:
	.string	"offset.sqlite3_io_methods.xUnfetch=%zu\n"
	.align	3
.LC60:
	.string	"size.sqlite3_mem_methods=%zu\n"
	.align	3
.LC61:
	.string	"align.sqlite3_mem_methods=%zu\n"
	.align	3
.LC62:
	.string	"offset.sqlite3_mem_methods.xMalloc=%zu\n"
	.align	3
.LC63:
	.string	"offset.sqlite3_mem_methods.xFree=%zu\n"
	.align	3
.LC64:
	.string	"offset.sqlite3_mem_methods.xRealloc=%zu\n"
	.align	3
.LC65:
	.string	"offset.sqlite3_mem_methods.xSize=%zu\n"
	.align	3
.LC66:
	.string	"offset.sqlite3_mem_methods.xRoundup=%zu\n"
	.align	3
.LC67:
	.string	"offset.sqlite3_mem_methods.xInit=%zu\n"
	.align	3
.LC68:
	.string	"offset.sqlite3_mem_methods.xShutdown=%zu\n"
	.align	3
.LC69:
	.string	"offset.sqlite3_mem_methods.pAppData=%zu\n"
	.align	3
.LC70:
	.string	"size.sqlite3_module=%zu\n"
	.align	3
.LC71:
	.string	"align.sqlite3_module=%zu\n"
	.align	3
.LC72:
	.string	"offset.sqlite3_module.iVersion=%zu\n"
	.align	3
.LC73:
	.string	"offset.sqlite3_module.xCreate=%zu\n"
	.align	3
.LC74:
	.string	"offset.sqlite3_module.xConnect=%zu\n"
	.align	3
.LC75:
	.string	"offset.sqlite3_module.xBestIndex=%zu\n"
	.align	3
.LC76:
	.string	"offset.sqlite3_module.xDisconnect=%zu\n"
	.align	3
.LC77:
	.string	"offset.sqlite3_module.xDestroy=%zu\n"
	.align	3
.LC78:
	.string	"offset.sqlite3_module.xOpen=%zu\n"
	.align	3
.LC79:
	.string	"offset.sqlite3_module.xClose=%zu\n"
	.align	3
.LC80:
	.string	"offset.sqlite3_module.xFilter=%zu\n"
	.align	3
.LC81:
	.string	"offset.sqlite3_module.xNext=%zu\n"
	.align	3
.LC82:
	.string	"offset.sqlite3_module.xEof=%zu\n"
	.align	3
.LC83:
	.string	"offset.sqlite3_module.xColumn=%zu\n"
	.align	3
.LC84:
	.string	"offset.sqlite3_module.xRowid=%zu\n"
	.align	3
.LC85:
	.string	"offset.sqlite3_module.xUpdate=%zu\n"
	.align	3
.LC86:
	.string	"offset.sqlite3_module.xBegin=%zu\n"
	.align	3
.LC87:
	.string	"offset.sqlite3_module.xSync=%zu\n"
	.align	3
.LC88:
	.string	"offset.sqlite3_module.xCommit=%zu\n"
	.align	3
.LC89:
	.string	"offset.sqlite3_module.xRollback=%zu\n"
	.align	3
.LC90:
	.string	"offset.sqlite3_module.xFindFunction=%zu\n"
	.align	3
.LC91:
	.string	"offset.sqlite3_module.xRename=%zu\n"
	.align	3
.LC92:
	.string	"offset.sqlite3_module.xSavepoint=%zu\n"
	.align	3
.LC93:
	.string	"offset.sqlite3_module.xRelease=%zu\n"
	.align	3
.LC94:
	.string	"offset.sqlite3_module.xRollbackTo=%zu\n"
	.align	3
.LC95:
	.string	"offset.sqlite3_module.xShadowName=%zu\n"
	.align	3
.LC96:
	.string	"offset.sqlite3_module.xIntegrity=%zu\n"
	.align	3
.LC97:
	.string	"size.sqlite3_mutex_methods=%zu\n"
	.align	3
.LC98:
	.string	"align.sqlite3_mutex_methods=%zu\n"
	.align	3
.LC99:
	.string	"offset.sqlite3_mutex_methods.xMutexInit=%zu\n"
	.align	3
.LC100:
	.string	"offset.sqlite3_mutex_methods.xMutexEnd=%zu\n"
	.align	3
.LC101:
	.string	"offset.sqlite3_mutex_methods.xMutexAlloc=%zu\n"
	.align	3
.LC102:
	.string	"offset.sqlite3_mutex_methods.xMutexFree=%zu\n"
	.align	3
.LC103:
	.string	"offset.sqlite3_mutex_methods.xMutexEnter=%zu\n"
	.align	3
.LC104:
	.string	"offset.sqlite3_mutex_methods.xMutexTry=%zu\n"
	.align	3
.LC105:
	.string	"offset.sqlite3_mutex_methods.xMutexLeave=%zu\n"
	.align	3
.LC106:
	.string	"offset.sqlite3_mutex_methods.xMutexHeld=%zu\n"
	.align	3
.LC107:
	.string	"offset.sqlite3_mutex_methods.xMutexNotheld=%zu\n"
	.align	3
.LC108:
	.string	"size.sqlite3_pcache_methods=%zu\n"
	.align	3
.LC109:
	.string	"align.sqlite3_pcache_methods=%zu\n"
	.align	3
.LC110:
	.string	"offset.sqlite3_pcache_methods.pArg=%zu\n"
	.align	3
.LC111:
	.string	"offset.sqlite3_pcache_methods.xInit=%zu\n"
	.align	3
.LC112:
	.string	"offset.sqlite3_pcache_methods.xShutdown=%zu\n"
	.align	3
.LC113:
	.string	"offset.sqlite3_pcache_methods.xCreate=%zu\n"
	.align	3
.LC114:
	.string	"offset.sqlite3_pcache_methods.xCachesize=%zu\n"
	.align	3
.LC115:
	.string	"offset.sqlite3_pcache_methods.xPagecount=%zu\n"
	.align	3
.LC116:
	.string	"offset.sqlite3_pcache_methods.xFetch=%zu\n"
	.align	3
.LC117:
	.string	"offset.sqlite3_pcache_methods.xUnpin=%zu\n"
	.align	3
.LC118:
	.string	"offset.sqlite3_pcache_methods.xRekey=%zu\n"
	.align	3
.LC119:
	.string	"offset.sqlite3_pcache_methods.xTruncate=%zu\n"
	.align	3
.LC120:
	.string	"offset.sqlite3_pcache_methods.xDestroy=%zu\n"
	.align	3
.LC121:
	.string	"size.sqlite3_pcache_methods2=%zu\n"
	.align	3
.LC122:
	.string	"align.sqlite3_pcache_methods2=%zu\n"
	.align	3
.LC123:
	.string	"offset.sqlite3_pcache_methods2.iVersion=%zu\n"
	.align	3
.LC124:
	.string	"offset.sqlite3_pcache_methods2.pArg=%zu\n"
	.align	3
.LC125:
	.string	"offset.sqlite3_pcache_methods2.xInit=%zu\n"
	.align	3
.LC126:
	.string	"offset.sqlite3_pcache_methods2.xShutdown=%zu\n"
	.align	3
.LC127:
	.string	"offset.sqlite3_pcache_methods2.xCreate=%zu\n"
	.align	3
.LC128:
	.string	"offset.sqlite3_pcache_methods2.xCachesize=%zu\n"
	.align	3
.LC129:
	.string	"offset.sqlite3_pcache_methods2.xPagecount=%zu\n"
	.align	3
.LC130:
	.string	"offset.sqlite3_pcache_methods2.xFetch=%zu\n"
	.align	3
.LC131:
	.string	"offset.sqlite3_pcache_methods2.xUnpin=%zu\n"
	.align	3
.LC132:
	.string	"offset.sqlite3_pcache_methods2.xRekey=%zu\n"
	.align	3
.LC133:
	.string	"offset.sqlite3_pcache_methods2.xTruncate=%zu\n"
	.align	3
.LC134:
	.string	"offset.sqlite3_pcache_methods2.xDestroy=%zu\n"
	.align	3
.LC135:
	.string	"offset.sqlite3_pcache_methods2.xShrink=%zu\n"
	.align	3
.LC136:
	.string	"size.sqlite3_pcache_page=%zu\n"
	.align	3
.LC137:
	.string	"align.sqlite3_pcache_page=%zu\n"
	.align	3
.LC138:
	.string	"offset.sqlite3_pcache_page.pBuf=%zu\n"
	.align	3
.LC139:
	.string	"offset.sqlite3_pcache_page.pExtra=%zu\n"
	.align	3
.LC140:
	.string	"size.sqlite3_rtree_geometry=%zu\n"
	.align	3
.LC141:
	.string	"align.sqlite3_rtree_geometry=%zu\n"
	.align	3
.LC142:
	.string	"offset.sqlite3_rtree_geometry.pContext=%zu\n"
	.align	3
.LC143:
	.string	"offset.sqlite3_rtree_geometry.nParam=%zu\n"
	.align	3
.LC144:
	.string	"offset.sqlite3_rtree_geometry.aParam=%zu\n"
	.align	3
.LC145:
	.string	"offset.sqlite3_rtree_geometry.pUser=%zu\n"
	.align	3
.LC146:
	.string	"offset.sqlite3_rtree_geometry.xDelUser=%zu\n"
	.align	3
.LC147:
	.string	"size.sqlite3_rtree_query_info=%zu\n"
	.align	3
.LC148:
	.string	"align.sqlite3_rtree_query_info=%zu\n"
	.align	3
.LC149:
	.string	"offset.sqlite3_rtree_query_info.pContext=%zu\n"
	.align	3
.LC150:
	.string	"offset.sqlite3_rtree_query_info.nParam=%zu\n"
	.align	3
.LC151:
	.string	"offset.sqlite3_rtree_query_info.aParam=%zu\n"
	.align	3
.LC152:
	.string	"offset.sqlite3_rtree_query_info.pUser=%zu\n"
	.align	3
.LC153:
	.string	"offset.sqlite3_rtree_query_info.xDelUser=%zu\n"
	.align	3
.LC154:
	.string	"offset.sqlite3_rtree_query_info.aCoord=%zu\n"
	.align	3
.LC155:
	.string	"offset.sqlite3_rtree_query_info.anQueue=%zu\n"
	.align	3
.LC156:
	.string	"offset.sqlite3_rtree_query_info.nCoord=%zu\n"
	.align	3
.LC157:
	.string	"offset.sqlite3_rtree_query_info.iLevel=%zu\n"
	.align	3
.LC158:
	.string	"offset.sqlite3_rtree_query_info.mxLevel=%zu\n"
	.align	3
.LC159:
	.string	"offset.sqlite3_rtree_query_info.iRowid=%zu\n"
	.align	3
.LC160:
	.string	"offset.sqlite3_rtree_query_info.rParentScore=%zu\n"
	.align	3
.LC161:
	.string	"offset.sqlite3_rtree_query_info.eParentWithin=%zu\n"
	.align	3
.LC162:
	.string	"offset.sqlite3_rtree_query_info.eWithin=%zu\n"
	.align	3
.LC163:
	.string	"offset.sqlite3_rtree_query_info.rScore=%zu\n"
	.align	3
.LC164:
	.string	"offset.sqlite3_rtree_query_info.apSqlParam=%zu\n"
	.align	3
.LC165:
	.string	"size.sqlite3_snapshot=%zu\n"
	.align	3
.LC166:
	.string	"align.sqlite3_snapshot=%zu\n"
	.align	3
.LC167:
	.string	"offset.sqlite3_snapshot.hidden=%zu\n"
	.align	3
.LC168:
	.string	"size.sqlite3_vfs=%zu\n"
	.align	3
.LC169:
	.string	"align.sqlite3_vfs=%zu\n"
	.align	3
.LC170:
	.string	"offset.sqlite3_vfs.iVersion=%zu\n"
	.align	3
.LC171:
	.string	"offset.sqlite3_vfs.szOsFile=%zu\n"
	.align	3
.LC172:
	.string	"offset.sqlite3_vfs.mxPathname=%zu\n"
	.align	3
.LC173:
	.string	"offset.sqlite3_vfs.pNext=%zu\n"
	.align	3
.LC174:
	.string	"offset.sqlite3_vfs.zName=%zu\n"
	.align	3
.LC175:
	.string	"offset.sqlite3_vfs.pAppData=%zu\n"
	.align	3
.LC176:
	.string	"offset.sqlite3_vfs.xOpen=%zu\n"
	.align	3
.LC177:
	.string	"offset.sqlite3_vfs.xDelete=%zu\n"
	.align	3
.LC178:
	.string	"offset.sqlite3_vfs.xAccess=%zu\n"
	.align	3
.LC179:
	.string	"offset.sqlite3_vfs.xFullPathname=%zu\n"
	.align	3
.LC180:
	.string	"offset.sqlite3_vfs.xDlOpen=%zu\n"
	.align	3
.LC181:
	.string	"offset.sqlite3_vfs.xDlError=%zu\n"
	.align	3
.LC182:
	.string	"offset.sqlite3_vfs.xDlSym=%zu\n"
	.align	3
.LC183:
	.string	"offset.sqlite3_vfs.xDlClose=%zu\n"
	.align	3
.LC184:
	.string	"offset.sqlite3_vfs.xRandomness=%zu\n"
	.align	3
.LC185:
	.string	"offset.sqlite3_vfs.xSleep=%zu\n"
	.align	3
.LC186:
	.string	"offset.sqlite3_vfs.xCurrentTime=%zu\n"
	.align	3
.LC187:
	.string	"offset.sqlite3_vfs.xGetLastError=%zu\n"
	.align	3
.LC188:
	.string	"offset.sqlite3_vfs.xCurrentTimeInt64=%zu\n"
	.align	3
.LC189:
	.string	"offset.sqlite3_vfs.xSetSystemCall=%zu\n"
	.align	3
.LC190:
	.string	"offset.sqlite3_vfs.xGetSystemCall=%zu\n"
	.align	3
.LC191:
	.string	"offset.sqlite3_vfs.xNextSystemCall=%zu\n"
	.align	3
.LC192:
	.string	"size.sqlite3_vtab=%zu\n"
	.align	3
.LC193:
	.string	"align.sqlite3_vtab=%zu\n"
	.align	3
.LC194:
	.string	"offset.sqlite3_vtab.pModule=%zu\n"
	.align	3
.LC195:
	.string	"offset.sqlite3_vtab.nRef=%zu\n"
	.align	3
.LC196:
	.string	"offset.sqlite3_vtab.zErrMsg=%zu\n"
	.align	3
.LC197:
	.string	"size.sqlite3_vtab_cursor=%zu\n"
	.align	3
.LC198:
	.string	"align.sqlite3_vtab_cursor=%zu\n"
	.align	3
.LC199:
	.string	"offset.sqlite3_vtab_cursor.pVtab=%zu\n"
	.section	.text.startup,"ax",@progbits
	.align	2
	.p2align 4,,11
	.global	main
	.type	main, %function
main:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	mov	x1, 32
	adrp	x0, .LC0
	mov	x29, sp
	add	x0, x0, :lo12:.LC0
	bl	printf
	mov	x1, 8
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
	bl	printf
	mov	x1, 0
	adrp	x0, .LC2
	add	x0, x0, :lo12:.LC2
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3
	add	x0, x0, :lo12:.LC3
	bl	printf
	mov	x1, 16
	adrp	x0, .LC4
	add	x0, x0, :lo12:.LC4
	bl	printf
	mov	x1, 24
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	bl	printf
	mov	x1, 28
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	bl	printf
	mov	x1, 8
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
	bl	printf
	mov	x1, 8
	adrp	x0, .LC8
	add	x0, x0, :lo12:.LC8
	bl	printf
	mov	x1, 0
	adrp	x0, .LC9
	add	x0, x0, :lo12:.LC9
	bl	printf
	mov	x1, 12
	adrp	x0, .LC10
	add	x0, x0, :lo12:.LC10
	bl	printf
	mov	x1, 4
	adrp	x0, .LC11
	add	x0, x0, :lo12:.LC11
	bl	printf
	mov	x1, 0
	adrp	x0, .LC12
	add	x0, x0, :lo12:.LC12
	bl	printf
	mov	x1, 4
	adrp	x0, .LC13
	add	x0, x0, :lo12:.LC13
	bl	printf
	mov	x1, 5
	adrp	x0, .LC14
	add	x0, x0, :lo12:.LC14
	bl	printf
	mov	x1, 8
	adrp	x0, .LC15
	add	x0, x0, :lo12:.LC15
	bl	printf
	mov	x1, 8
	adrp	x0, .LC16
	add	x0, x0, :lo12:.LC16
	bl	printf
	mov	x1, 4
	adrp	x0, .LC17
	add	x0, x0, :lo12:.LC17
	bl	printf
	mov	x1, 0
	adrp	x0, .LC18
	add	x0, x0, :lo12:.LC18
	bl	printf
	mov	x1, 4
	adrp	x0, .LC19
	add	x0, x0, :lo12:.LC19
	bl	printf
	mov	x1, 96
	adrp	x0, .LC20
	add	x0, x0, :lo12:.LC20
	bl	printf
	mov	x1, 8
	adrp	x0, .LC21
	add	x0, x0, :lo12:.LC21
	bl	printf
	mov	x1, 0
	adrp	x0, .LC22
	add	x0, x0, :lo12:.LC22
	bl	printf
	mov	x1, 8
	adrp	x0, .LC23
	add	x0, x0, :lo12:.LC23
	bl	printf
	mov	x1, 16
	adrp	x0, .LC24
	add	x0, x0, :lo12:.LC24
	bl	printf
	mov	x1, 24
	adrp	x0, .LC25
	add	x0, x0, :lo12:.LC25
	bl	printf
	mov	x1, 32
	adrp	x0, .LC26
	add	x0, x0, :lo12:.LC26
	bl	printf
	mov	x1, 40
	adrp	x0, .LC27
	add	x0, x0, :lo12:.LC27
	bl	printf
	mov	x1, 48
	adrp	x0, .LC28
	add	x0, x0, :lo12:.LC28
	bl	printf
	mov	x1, 56
	adrp	x0, .LC29
	add	x0, x0, :lo12:.LC29
	bl	printf
	mov	x1, 60
	adrp	x0, .LC30
	add	x0, x0, :lo12:.LC30
	bl	printf
	mov	x1, 64
	adrp	x0, .LC31
	add	x0, x0, :lo12:.LC31
	bl	printf
	mov	x1, 72
	adrp	x0, .LC32
	add	x0, x0, :lo12:.LC32
	bl	printf
	mov	x1, 80
	adrp	x0, .LC33
	add	x0, x0, :lo12:.LC33
	bl	printf
	mov	x1, 88
	adrp	x0, .LC34
	add	x0, x0, :lo12:.LC34
	bl	printf
	mov	x1, 8
	adrp	x0, .LC35
	add	x0, x0, :lo12:.LC35
	bl	printf
	mov	x1, 4
	adrp	x0, .LC36
	add	x0, x0, :lo12:.LC36
	bl	printf
	mov	x1, 0
	adrp	x0, .LC37
	add	x0, x0, :lo12:.LC37
	bl	printf
	mov	x1, 4
	adrp	x0, .LC38
	add	x0, x0, :lo12:.LC38
	bl	printf
	mov	x1, 152
	adrp	x0, .LC39
	add	x0, x0, :lo12:.LC39
	bl	printf
	mov	x1, 8
	adrp	x0, .LC40
	add	x0, x0, :lo12:.LC40
	bl	printf
	mov	x1, 0
	adrp	x0, .LC41
	add	x0, x0, :lo12:.LC41
	bl	printf
	mov	x1, 8
	adrp	x0, .LC42
	add	x0, x0, :lo12:.LC42
	bl	printf
	mov	x1, 16
	adrp	x0, .LC43
	add	x0, x0, :lo12:.LC43
	bl	printf
	mov	x1, 24
	adrp	x0, .LC44
	add	x0, x0, :lo12:.LC44
	bl	printf
	mov	x1, 32
	adrp	x0, .LC45
	add	x0, x0, :lo12:.LC45
	bl	printf
	mov	x1, 40
	adrp	x0, .LC46
	add	x0, x0, :lo12:.LC46
	bl	printf
	mov	x1, 48
	adrp	x0, .LC47
	add	x0, x0, :lo12:.LC47
	bl	printf
	mov	x1, 56
	adrp	x0, .LC48
	add	x0, x0, :lo12:.LC48
	bl	printf
	mov	x1, 64
	adrp	x0, .LC49
	add	x0, x0, :lo12:.LC49
	bl	printf
	mov	x1, 72
	adrp	x0, .LC50
	add	x0, x0, :lo12:.LC50
	bl	printf
	mov	x1, 80
	adrp	x0, .LC51
	add	x0, x0, :lo12:.LC51
	bl	printf
	mov	x1, 88
	adrp	x0, .LC52
	add	x0, x0, :lo12:.LC52
	bl	printf
	mov	x1, 96
	adrp	x0, .LC53
	add	x0, x0, :lo12:.LC53
	bl	printf
	mov	x1, 104
	adrp	x0, .LC54
	add	x0, x0, :lo12:.LC54
	bl	printf
	mov	x1, 112
	adrp	x0, .LC55
	add	x0, x0, :lo12:.LC55
	bl	printf
	mov	x1, 120
	adrp	x0, .LC56
	add	x0, x0, :lo12:.LC56
	bl	printf
	mov	x1, 128
	adrp	x0, .LC57
	add	x0, x0, :lo12:.LC57
	bl	printf
	mov	x1, 136
	adrp	x0, .LC58
	add	x0, x0, :lo12:.LC58
	bl	printf
	mov	x1, 144
	adrp	x0, .LC59
	add	x0, x0, :lo12:.LC59
	bl	printf
	mov	x1, 64
	adrp	x0, .LC60
	add	x0, x0, :lo12:.LC60
	bl	printf
	mov	x1, 8
	adrp	x0, .LC61
	add	x0, x0, :lo12:.LC61
	bl	printf
	mov	x1, 0
	adrp	x0, .LC62
	add	x0, x0, :lo12:.LC62
	bl	printf
	mov	x1, 8
	adrp	x0, .LC63
	add	x0, x0, :lo12:.LC63
	bl	printf
	mov	x1, 16
	adrp	x0, .LC64
	add	x0, x0, :lo12:.LC64
	bl	printf
	mov	x1, 24
	adrp	x0, .LC65
	add	x0, x0, :lo12:.LC65
	bl	printf
	mov	x1, 32
	adrp	x0, .LC66
	add	x0, x0, :lo12:.LC66
	bl	printf
	mov	x1, 40
	adrp	x0, .LC67
	add	x0, x0, :lo12:.LC67
	bl	printf
	mov	x1, 48
	adrp	x0, .LC68
	add	x0, x0, :lo12:.LC68
	bl	printf
	mov	x1, 56
	adrp	x0, .LC69
	add	x0, x0, :lo12:.LC69
	bl	printf
	mov	x1, 200
	adrp	x0, .LC70
	add	x0, x0, :lo12:.LC70
	bl	printf
	mov	x1, 8
	adrp	x0, .LC71
	add	x0, x0, :lo12:.LC71
	bl	printf
	mov	x1, 0
	adrp	x0, .LC72
	add	x0, x0, :lo12:.LC72
	bl	printf
	mov	x1, 8
	adrp	x0, .LC73
	add	x0, x0, :lo12:.LC73
	bl	printf
	mov	x1, 16
	adrp	x0, .LC74
	add	x0, x0, :lo12:.LC74
	bl	printf
	mov	x1, 24
	adrp	x0, .LC75
	add	x0, x0, :lo12:.LC75
	bl	printf
	mov	x1, 32
	adrp	x0, .LC76
	add	x0, x0, :lo12:.LC76
	bl	printf
	mov	x1, 40
	adrp	x0, .LC77
	add	x0, x0, :lo12:.LC77
	bl	printf
	mov	x1, 48
	adrp	x0, .LC78
	add	x0, x0, :lo12:.LC78
	bl	printf
	mov	x1, 56
	adrp	x0, .LC79
	add	x0, x0, :lo12:.LC79
	bl	printf
	mov	x1, 64
	adrp	x0, .LC80
	add	x0, x0, :lo12:.LC80
	bl	printf
	mov	x1, 72
	adrp	x0, .LC81
	add	x0, x0, :lo12:.LC81
	bl	printf
	mov	x1, 80
	adrp	x0, .LC82
	add	x0, x0, :lo12:.LC82
	bl	printf
	mov	x1, 88
	adrp	x0, .LC83
	add	x0, x0, :lo12:.LC83
	bl	printf
	mov	x1, 96
	adrp	x0, .LC84
	add	x0, x0, :lo12:.LC84
	bl	printf
	mov	x1, 104
	adrp	x0, .LC85
	add	x0, x0, :lo12:.LC85
	bl	printf
	mov	x1, 112
	adrp	x0, .LC86
	add	x0, x0, :lo12:.LC86
	bl	printf
	mov	x1, 120
	adrp	x0, .LC87
	add	x0, x0, :lo12:.LC87
	bl	printf
	mov	x1, 128
	adrp	x0, .LC88
	add	x0, x0, :lo12:.LC88
	bl	printf
	mov	x1, 136
	adrp	x0, .LC89
	add	x0, x0, :lo12:.LC89
	bl	printf
	mov	x1, 144
	adrp	x0, .LC90
	add	x0, x0, :lo12:.LC90
	bl	printf
	mov	x1, 152
	adrp	x0, .LC91
	add	x0, x0, :lo12:.LC91
	bl	printf
	mov	x1, 160
	adrp	x0, .LC92
	add	x0, x0, :lo12:.LC92
	bl	printf
	mov	x1, 168
	adrp	x0, .LC93
	add	x0, x0, :lo12:.LC93
	bl	printf
	mov	x1, 176
	adrp	x0, .LC94
	add	x0, x0, :lo12:.LC94
	bl	printf
	mov	x1, 184
	adrp	x0, .LC95
	add	x0, x0, :lo12:.LC95
	bl	printf
	mov	x1, 192
	adrp	x0, .LC96
	add	x0, x0, :lo12:.LC96
	bl	printf
	mov	x1, 72
	adrp	x0, .LC97
	add	x0, x0, :lo12:.LC97
	bl	printf
	mov	x1, 8
	adrp	x0, .LC98
	add	x0, x0, :lo12:.LC98
	bl	printf
	mov	x1, 0
	adrp	x0, .LC99
	add	x0, x0, :lo12:.LC99
	bl	printf
	mov	x1, 8
	adrp	x0, .LC100
	add	x0, x0, :lo12:.LC100
	bl	printf
	mov	x1, 16
	adrp	x0, .LC101
	add	x0, x0, :lo12:.LC101
	bl	printf
	mov	x1, 24
	adrp	x0, .LC102
	add	x0, x0, :lo12:.LC102
	bl	printf
	mov	x1, 32
	adrp	x0, .LC103
	add	x0, x0, :lo12:.LC103
	bl	printf
	mov	x1, 40
	adrp	x0, .LC104
	add	x0, x0, :lo12:.LC104
	bl	printf
	mov	x1, 48
	adrp	x0, .LC105
	add	x0, x0, :lo12:.LC105
	bl	printf
	mov	x1, 56
	adrp	x0, .LC106
	add	x0, x0, :lo12:.LC106
	bl	printf
	mov	x1, 64
	adrp	x0, .LC107
	add	x0, x0, :lo12:.LC107
	bl	printf
	mov	x1, 88
	adrp	x0, .LC108
	add	x0, x0, :lo12:.LC108
	bl	printf
	mov	x1, 8
	adrp	x0, .LC109
	add	x0, x0, :lo12:.LC109
	bl	printf
	mov	x1, 0
	adrp	x0, .LC110
	add	x0, x0, :lo12:.LC110
	bl	printf
	mov	x1, 8
	adrp	x0, .LC111
	add	x0, x0, :lo12:.LC111
	bl	printf
	mov	x1, 16
	adrp	x0, .LC112
	add	x0, x0, :lo12:.LC112
	bl	printf
	mov	x1, 24
	adrp	x0, .LC113
	add	x0, x0, :lo12:.LC113
	bl	printf
	mov	x1, 32
	adrp	x0, .LC114
	add	x0, x0, :lo12:.LC114
	bl	printf
	mov	x1, 40
	adrp	x0, .LC115
	add	x0, x0, :lo12:.LC115
	bl	printf
	mov	x1, 48
	adrp	x0, .LC116
	add	x0, x0, :lo12:.LC116
	bl	printf
	mov	x1, 56
	adrp	x0, .LC117
	add	x0, x0, :lo12:.LC117
	bl	printf
	mov	x1, 64
	adrp	x0, .LC118
	add	x0, x0, :lo12:.LC118
	bl	printf
	mov	x1, 72
	adrp	x0, .LC119
	add	x0, x0, :lo12:.LC119
	bl	printf
	mov	x1, 80
	adrp	x0, .LC120
	add	x0, x0, :lo12:.LC120
	bl	printf
	mov	x1, 104
	adrp	x0, .LC121
	add	x0, x0, :lo12:.LC121
	bl	printf
	mov	x1, 8
	adrp	x0, .LC122
	add	x0, x0, :lo12:.LC122
	bl	printf
	mov	x1, 0
	adrp	x0, .LC123
	add	x0, x0, :lo12:.LC123
	bl	printf
	mov	x1, 8
	adrp	x0, .LC124
	add	x0, x0, :lo12:.LC124
	bl	printf
	mov	x1, 16
	adrp	x0, .LC125
	add	x0, x0, :lo12:.LC125
	bl	printf
	mov	x1, 24
	adrp	x0, .LC126
	add	x0, x0, :lo12:.LC126
	bl	printf
	mov	x1, 32
	adrp	x0, .LC127
	add	x0, x0, :lo12:.LC127
	bl	printf
	mov	x1, 40
	adrp	x0, .LC128
	add	x0, x0, :lo12:.LC128
	bl	printf
	mov	x1, 48
	adrp	x0, .LC129
	add	x0, x0, :lo12:.LC129
	bl	printf
	mov	x1, 56
	adrp	x0, .LC130
	add	x0, x0, :lo12:.LC130
	bl	printf
	mov	x1, 64
	adrp	x0, .LC131
	add	x0, x0, :lo12:.LC131
	bl	printf
	mov	x1, 72
	adrp	x0, .LC132
	add	x0, x0, :lo12:.LC132
	bl	printf
	mov	x1, 80
	adrp	x0, .LC133
	add	x0, x0, :lo12:.LC133
	bl	printf
	mov	x1, 88
	adrp	x0, .LC134
	add	x0, x0, :lo12:.LC134
	bl	printf
	mov	x1, 96
	adrp	x0, .LC135
	add	x0, x0, :lo12:.LC135
	bl	printf
	mov	x1, 16
	adrp	x0, .LC136
	add	x0, x0, :lo12:.LC136
	bl	printf
	mov	x1, 8
	adrp	x0, .LC137
	add	x0, x0, :lo12:.LC137
	bl	printf
	mov	x1, 0
	adrp	x0, .LC138
	add	x0, x0, :lo12:.LC138
	bl	printf
	mov	x1, 8
	adrp	x0, .LC139
	add	x0, x0, :lo12:.LC139
	bl	printf
	mov	x1, 40
	adrp	x0, .LC140
	add	x0, x0, :lo12:.LC140
	bl	printf
	mov	x1, 8
	adrp	x0, .LC141
	add	x0, x0, :lo12:.LC141
	bl	printf
	mov	x1, 0
	adrp	x0, .LC142
	add	x0, x0, :lo12:.LC142
	bl	printf
	mov	x1, 8
	adrp	x0, .LC143
	add	x0, x0, :lo12:.LC143
	bl	printf
	mov	x1, 16
	adrp	x0, .LC144
	add	x0, x0, :lo12:.LC144
	bl	printf
	mov	x1, 24
	adrp	x0, .LC145
	add	x0, x0, :lo12:.LC145
	bl	printf
	mov	x1, 32
	adrp	x0, .LC146
	add	x0, x0, :lo12:.LC146
	bl	printf
	mov	x1, 112
	adrp	x0, .LC147
	add	x0, x0, :lo12:.LC147
	bl	printf
	mov	x1, 8
	adrp	x0, .LC148
	add	x0, x0, :lo12:.LC148
	bl	printf
	mov	x1, 0
	adrp	x0, .LC149
	add	x0, x0, :lo12:.LC149
	bl	printf
	mov	x1, 8
	adrp	x0, .LC150
	add	x0, x0, :lo12:.LC150
	bl	printf
	mov	x1, 16
	adrp	x0, .LC151
	add	x0, x0, :lo12:.LC151
	bl	printf
	mov	x1, 24
	adrp	x0, .LC152
	add	x0, x0, :lo12:.LC152
	bl	printf
	mov	x1, 32
	adrp	x0, .LC153
	add	x0, x0, :lo12:.LC153
	bl	printf
	mov	x1, 40
	adrp	x0, .LC154
	add	x0, x0, :lo12:.LC154
	bl	printf
	mov	x1, 48
	adrp	x0, .LC155
	add	x0, x0, :lo12:.LC155
	bl	printf
	mov	x1, 56
	adrp	x0, .LC156
	add	x0, x0, :lo12:.LC156
	bl	printf
	mov	x1, 60
	adrp	x0, .LC157
	add	x0, x0, :lo12:.LC157
	bl	printf
	mov	x1, 64
	adrp	x0, .LC158
	add	x0, x0, :lo12:.LC158
	bl	printf
	mov	x1, 72
	adrp	x0, .LC159
	add	x0, x0, :lo12:.LC159
	bl	printf
	mov	x1, 80
	adrp	x0, .LC160
	add	x0, x0, :lo12:.LC160
	bl	printf
	mov	x1, 88
	adrp	x0, .LC161
	add	x0, x0, :lo12:.LC161
	bl	printf
	mov	x1, 92
	adrp	x0, .LC162
	add	x0, x0, :lo12:.LC162
	bl	printf
	mov	x1, 96
	adrp	x0, .LC163
	add	x0, x0, :lo12:.LC163
	bl	printf
	mov	x1, 104
	adrp	x0, .LC164
	add	x0, x0, :lo12:.LC164
	bl	printf
	mov	x1, 48
	adrp	x0, .LC165
	add	x0, x0, :lo12:.LC165
	bl	printf
	mov	x1, 1
	adrp	x0, .LC166
	add	x0, x0, :lo12:.LC166
	bl	printf
	mov	x1, 0
	adrp	x0, .LC167
	add	x0, x0, :lo12:.LC167
	bl	printf
	mov	x1, 168
	adrp	x0, .LC168
	add	x0, x0, :lo12:.LC168
	bl	printf
	mov	x1, 8
	adrp	x0, .LC169
	add	x0, x0, :lo12:.LC169
	bl	printf
	mov	x1, 0
	adrp	x0, .LC170
	add	x0, x0, :lo12:.LC170
	bl	printf
	mov	x1, 4
	adrp	x0, .LC171
	add	x0, x0, :lo12:.LC171
	bl	printf
	mov	x1, 8
	adrp	x0, .LC172
	add	x0, x0, :lo12:.LC172
	bl	printf
	mov	x1, 16
	adrp	x0, .LC173
	add	x0, x0, :lo12:.LC173
	bl	printf
	mov	x1, 24
	adrp	x0, .LC174
	add	x0, x0, :lo12:.LC174
	bl	printf
	mov	x1, 32
	adrp	x0, .LC175
	add	x0, x0, :lo12:.LC175
	bl	printf
	mov	x1, 40
	adrp	x0, .LC176
	add	x0, x0, :lo12:.LC176
	bl	printf
	mov	x1, 48
	adrp	x0, .LC177
	add	x0, x0, :lo12:.LC177
	bl	printf
	mov	x1, 56
	adrp	x0, .LC178
	add	x0, x0, :lo12:.LC178
	bl	printf
	mov	x1, 64
	adrp	x0, .LC179
	add	x0, x0, :lo12:.LC179
	bl	printf
	mov	x1, 72
	adrp	x0, .LC180
	add	x0, x0, :lo12:.LC180
	bl	printf
	mov	x1, 80
	adrp	x0, .LC181
	add	x0, x0, :lo12:.LC181
	bl	printf
	mov	x1, 88
	adrp	x0, .LC182
	add	x0, x0, :lo12:.LC182
	bl	printf
	mov	x1, 96
	adrp	x0, .LC183
	add	x0, x0, :lo12:.LC183
	bl	printf
	mov	x1, 104
	adrp	x0, .LC184
	add	x0, x0, :lo12:.LC184
	bl	printf
	mov	x1, 112
	adrp	x0, .LC185
	add	x0, x0, :lo12:.LC185
	bl	printf
	mov	x1, 120
	adrp	x0, .LC186
	add	x0, x0, :lo12:.LC186
	bl	printf
	mov	x1, 128
	adrp	x0, .LC187
	add	x0, x0, :lo12:.LC187
	bl	printf
	mov	x1, 136
	adrp	x0, .LC188
	add	x0, x0, :lo12:.LC188
	bl	printf
	mov	x1, 144
	adrp	x0, .LC189
	add	x0, x0, :lo12:.LC189
	bl	printf
	mov	x1, 152
	adrp	x0, .LC190
	add	x0, x0, :lo12:.LC190
	bl	printf
	mov	x1, 160
	adrp	x0, .LC191
	add	x0, x0, :lo12:.LC191
	bl	printf
	mov	x1, 24
	adrp	x0, .LC192
	add	x0, x0, :lo12:.LC192
	bl	printf
	mov	x1, 8
	adrp	x0, .LC193
	add	x0, x0, :lo12:.LC193
	bl	printf
	mov	x1, 0
	adrp	x0, .LC194
	add	x0, x0, :lo12:.LC194
	bl	printf
	mov	x1, 8
	adrp	x0, .LC195
	add	x0, x0, :lo12:.LC195
	bl	printf
	mov	x1, 16
	adrp	x0, .LC196
	add	x0, x0, :lo12:.LC196
	bl	printf
	mov	x1, 8
	adrp	x0, .LC197
	add	x0, x0, :lo12:.LC197
	bl	printf
	mov	x1, 8
	adrp	x0, .LC198
	add	x0, x0, :lo12:.LC198
	bl	printf
	mov	x1, 0
	adrp	x0, .LC199
	add	x0, x0, :lo12:.LC199
	bl	printf
	mov	w0, 0
	ldp	x29, x30, [sp], 16
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
