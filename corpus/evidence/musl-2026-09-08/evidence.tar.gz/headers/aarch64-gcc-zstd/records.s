	.arch armv8-a
	.file	"records.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC0:
	.string	"size.ZSTD_bounds=%zu\n"
	.align	3
.LC1:
	.string	"align.ZSTD_bounds=%zu\n"
	.align	3
.LC2:
	.string	"offset.ZSTD_bounds.error=%zu\n"
	.align	3
.LC3:
	.string	"offset.ZSTD_bounds.lowerBound=%zu\n"
	.align	3
.LC4:
	.string	"offset.ZSTD_bounds.upperBound=%zu\n"
	.align	3
.LC5:
	.string	"size.ZSTD_inBuffer_s=%zu\n"
	.align	3
.LC6:
	.string	"align.ZSTD_inBuffer_s=%zu\n"
	.align	3
.LC7:
	.string	"offset.ZSTD_inBuffer_s.src=%zu\n"
	.align	3
.LC8:
	.string	"offset.ZSTD_inBuffer_s.size=%zu\n"
	.align	3
.LC9:
	.string	"offset.ZSTD_inBuffer_s.pos=%zu\n"
	.align	3
.LC10:
	.string	"size.ZSTD_outBuffer_s=%zu\n"
	.align	3
.LC11:
	.string	"align.ZSTD_outBuffer_s=%zu\n"
	.align	3
.LC12:
	.string	"offset.ZSTD_outBuffer_s.dst=%zu\n"
	.align	3
.LC13:
	.string	"offset.ZSTD_outBuffer_s.size=%zu\n"
	.align	3
.LC14:
	.string	"offset.ZSTD_outBuffer_s.pos=%zu\n"
	.section	.text.startup,"ax",@progbits
	.align	2
	.p2align 4,,11
	.global	main
	.type	main, %function
main:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	mov	x1, 16
	adrp	x0, .LC0
	mov	x29, sp
	add	x0, x0, :lo12:.LC0
	bl	printf
	mov	x1, 8
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
	bl	printf
	mov	x1, 0
	adrp	x0, .LC2
	add	x0, x0, :lo12:.LC2
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3
	add	x0, x0, :lo12:.LC3
	bl	printf
	mov	x1, 12
	adrp	x0, .LC4
	add	x0, x0, :lo12:.LC4
	bl	printf
	mov	x1, 24
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	bl	printf
	mov	x1, 8
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	bl	printf
	mov	x1, 0
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
	bl	printf
	mov	x1, 8
	adrp	x0, .LC8
	add	x0, x0, :lo12:.LC8
	bl	printf
	mov	x1, 16
	adrp	x0, .LC9
	add	x0, x0, :lo12:.LC9
	bl	printf
	mov	x1, 24
	adrp	x0, .LC10
	add	x0, x0, :lo12:.LC10
	bl	printf
	mov	x1, 8
	adrp	x0, .LC11
	add	x0, x0, :lo12:.LC11
	bl	printf
	mov	x1, 0
	adrp	x0, .LC12
	add	x0, x0, :lo12:.LC12
	bl	printf
	mov	x1, 8
	adrp	x0, .LC13
	add	x0, x0, :lo12:.LC13
	bl	printf
	mov	x1, 16
	adrp	x0, .LC14
	add	x0, x0, :lo12:.LC14
	bl	printf
	mov	w0, 0
	ldp	x29, x30, [sp], 16
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
