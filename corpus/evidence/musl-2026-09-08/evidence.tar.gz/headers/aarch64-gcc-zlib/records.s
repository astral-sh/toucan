	.arch armv8-a
	.file	"records.c"
	.text
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC0:
	.string	"size.__builtin_va_list_record=%zu\n"
	.align	3
.LC1:
	.string	"align.__builtin_va_list_record=%zu\n"
	.align	3
.LC2:
	.string	"offset.__builtin_va_list_record.__stack=%zu\n"
	.align	3
.LC3:
	.string	"offset.__builtin_va_list_record.__gr_top=%zu\n"
	.align	3
.LC4:
	.string	"offset.__builtin_va_list_record.__vr_top=%zu\n"
	.align	3
.LC5:
	.string	"offset.__builtin_va_list_record.__gr_offs=%zu\n"
	.align	3
.LC6:
	.string	"offset.__builtin_va_list_record.__vr_offs=%zu\n"
	.align	3
.LC7:
	.string	"size.gzFile_s=%zu\n"
	.align	3
.LC8:
	.string	"align.gzFile_s=%zu\n"
	.align	3
.LC9:
	.string	"offset.gzFile_s.have=%zu\n"
	.align	3
.LC10:
	.string	"offset.gzFile_s.next=%zu\n"
	.align	3
.LC11:
	.string	"offset.gzFile_s.pos=%zu\n"
	.align	3
.LC12:
	.string	"size.gz_header_s=%zu\n"
	.align	3
.LC13:
	.string	"align.gz_header_s=%zu\n"
	.align	3
.LC14:
	.string	"offset.gz_header_s.text=%zu\n"
	.align	3
.LC15:
	.string	"offset.gz_header_s.time=%zu\n"
	.align	3
.LC16:
	.string	"offset.gz_header_s.xflags=%zu\n"
	.align	3
.LC17:
	.string	"offset.gz_header_s.os=%zu\n"
	.align	3
.LC18:
	.string	"offset.gz_header_s.extra=%zu\n"
	.align	3
.LC19:
	.string	"offset.gz_header_s.extra_len=%zu\n"
	.align	3
.LC20:
	.string	"offset.gz_header_s.extra_max=%zu\n"
	.align	3
.LC21:
	.string	"offset.gz_header_s.name=%zu\n"
	.align	3
.LC22:
	.string	"offset.gz_header_s.name_max=%zu\n"
	.align	3
.LC23:
	.string	"offset.gz_header_s.comment=%zu\n"
	.align	3
.LC24:
	.string	"offset.gz_header_s.comm_max=%zu\n"
	.align	3
.LC25:
	.string	"offset.gz_header_s.hcrc=%zu\n"
	.align	3
.LC26:
	.string	"offset.gz_header_s.done=%zu\n"
	.align	3
.LC27:
	.string	"size.z_stream_s=%zu\n"
	.align	3
.LC28:
	.string	"align.z_stream_s=%zu\n"
	.align	3
.LC29:
	.string	"offset.z_stream_s.next_in=%zu\n"
	.align	3
.LC30:
	.string	"offset.z_stream_s.avail_in=%zu\n"
	.align	3
.LC31:
	.string	"offset.z_stream_s.total_in=%zu\n"
	.align	3
.LC32:
	.string	"offset.z_stream_s.next_out=%zu\n"
	.align	3
.LC33:
	.string	"offset.z_stream_s.avail_out=%zu\n"
	.align	3
.LC34:
	.string	"offset.z_stream_s.total_out=%zu\n"
	.align	3
.LC35:
	.string	"offset.z_stream_s.msg=%zu\n"
	.align	3
.LC36:
	.string	"offset.z_stream_s.state=%zu\n"
	.align	3
.LC37:
	.string	"offset.z_stream_s.zalloc=%zu\n"
	.align	3
.LC38:
	.string	"offset.z_stream_s.zfree=%zu\n"
	.align	3
.LC39:
	.string	"offset.z_stream_s.opaque=%zu\n"
	.align	3
.LC40:
	.string	"offset.z_stream_s.data_type=%zu\n"
	.align	3
.LC41:
	.string	"offset.z_stream_s.adler=%zu\n"
	.align	3
.LC42:
	.string	"offset.z_stream_s.reserved=%zu\n"
	.section	.text.startup,"ax",@progbits
	.align	2
	.p2align 4,,11
	.global	main
	.type	main, %function
main:
.LFB0:
	.cfi_startproc
	stp	x29, x30, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	mov	x1, 32
	adrp	x0, .LC0
	mov	x29, sp
	add	x0, x0, :lo12:.LC0
	bl	printf
	mov	x1, 8
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
	bl	printf
	mov	x1, 0
	adrp	x0, .LC2
	add	x0, x0, :lo12:.LC2
	bl	printf
	mov	x1, 8
	adrp	x0, .LC3
	add	x0, x0, :lo12:.LC3
	bl	printf
	mov	x1, 16
	adrp	x0, .LC4
	add	x0, x0, :lo12:.LC4
	bl	printf
	mov	x1, 24
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	bl	printf
	mov	x1, 28
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	bl	printf
	mov	x1, 24
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
	bl	printf
	mov	x1, 8
	adrp	x0, .LC8
	add	x0, x0, :lo12:.LC8
	bl	printf
	mov	x1, 0
	adrp	x0, .LC9
	add	x0, x0, :lo12:.LC9
	bl	printf
	mov	x1, 8
	adrp	x0, .LC10
	add	x0, x0, :lo12:.LC10
	bl	printf
	mov	x1, 16
	adrp	x0, .LC11
	add	x0, x0, :lo12:.LC11
	bl	printf
	mov	x1, 80
	adrp	x0, .LC12
	add	x0, x0, :lo12:.LC12
	bl	printf
	mov	x1, 8
	adrp	x0, .LC13
	add	x0, x0, :lo12:.LC13
	bl	printf
	mov	x1, 0
	adrp	x0, .LC14
	add	x0, x0, :lo12:.LC14
	bl	printf
	mov	x1, 8
	adrp	x0, .LC15
	add	x0, x0, :lo12:.LC15
	bl	printf
	mov	x1, 16
	adrp	x0, .LC16
	add	x0, x0, :lo12:.LC16
	bl	printf
	mov	x1, 20
	adrp	x0, .LC17
	add	x0, x0, :lo12:.LC17
	bl	printf
	mov	x1, 24
	adrp	x0, .LC18
	add	x0, x0, :lo12:.LC18
	bl	printf
	mov	x1, 32
	adrp	x0, .LC19
	add	x0, x0, :lo12:.LC19
	bl	printf
	mov	x1, 36
	adrp	x0, .LC20
	add	x0, x0, :lo12:.LC20
	bl	printf
	mov	x1, 40
	adrp	x0, .LC21
	add	x0, x0, :lo12:.LC21
	bl	printf
	mov	x1, 48
	adrp	x0, .LC22
	add	x0, x0, :lo12:.LC22
	bl	printf
	mov	x1, 56
	adrp	x0, .LC23
	add	x0, x0, :lo12:.LC23
	bl	printf
	mov	x1, 64
	adrp	x0, .LC24
	add	x0, x0, :lo12:.LC24
	bl	printf
	mov	x1, 68
	adrp	x0, .LC25
	add	x0, x0, :lo12:.LC25
	bl	printf
	mov	x1, 72
	adrp	x0, .LC26
	add	x0, x0, :lo12:.LC26
	bl	printf
	mov	x1, 112
	adrp	x0, .LC27
	add	x0, x0, :lo12:.LC27
	bl	printf
	mov	x1, 8
	adrp	x0, .LC28
	add	x0, x0, :lo12:.LC28
	bl	printf
	mov	x1, 0
	adrp	x0, .LC29
	add	x0, x0, :lo12:.LC29
	bl	printf
	mov	x1, 8
	adrp	x0, .LC30
	add	x0, x0, :lo12:.LC30
	bl	printf
	mov	x1, 16
	adrp	x0, .LC31
	add	x0, x0, :lo12:.LC31
	bl	printf
	mov	x1, 24
	adrp	x0, .LC32
	add	x0, x0, :lo12:.LC32
	bl	printf
	mov	x1, 32
	adrp	x0, .LC33
	add	x0, x0, :lo12:.LC33
	bl	printf
	mov	x1, 40
	adrp	x0, .LC34
	add	x0, x0, :lo12:.LC34
	bl	printf
	mov	x1, 48
	adrp	x0, .LC35
	add	x0, x0, :lo12:.LC35
	bl	printf
	mov	x1, 56
	adrp	x0, .LC36
	add	x0, x0, :lo12:.LC36
	bl	printf
	mov	x1, 64
	adrp	x0, .LC37
	add	x0, x0, :lo12:.LC37
	bl	printf
	mov	x1, 72
	adrp	x0, .LC38
	add	x0, x0, :lo12:.LC38
	bl	printf
	mov	x1, 80
	adrp	x0, .LC39
	add	x0, x0, :lo12:.LC39
	bl	printf
	mov	x1, 88
	adrp	x0, .LC40
	add	x0, x0, :lo12:.LC40
	bl	printf
	mov	x1, 96
	adrp	x0, .LC41
	add	x0, x0, :lo12:.LC41
	bl	printf
	mov	x1, 104
	adrp	x0, .LC42
	add	x0, x0, :lo12:.LC42
	bl	printf
	mov	w0, 0
	ldp	x29, x30, [sp], 16
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
