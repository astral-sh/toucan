	.arch armv8-a
	.file	"constants.c"
	.text
	.align	2
	.p2align 4,,11
	.type	print_unsigned, %function
print_unsigned:
.LFB0:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	adrp	x2, .LC0
	adrp	x3, :got:__stack_chk_guard
	ldr	x3, [x3, :got_lo12:__stack_chk_guard]
	add	x2, x2, :lo12:.LC0
	stp	x29, x30, [sp, 48]
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	add	x29, sp, 48
	mov	x11, -3689348814741910324
	ldp	x5, x8, [x2]
	stp	x19, x20, [sp, 64]
	.cfi_offset 19, -16
	.cfi_offset 20, -8
	mov	x20, sp
	ldr	x2, [x3]
	str	x2, [sp, 40]
	mov	x2, 0
	mov	x6, 1
	movk	x11, 0xcccd, lsl 0
	.p2align 3,,7
.L12:
	adds	x2, x0, x1
	mov	x9, x1
	cinc	x2, x2, cs
	add	x7, x20, x6
	mov	x12, x0
	mov	x19, x6
	add	x6, x6, 1
	umulh	x3, x2, x11
	and	x4, x3, -4
	add	x3, x4, x3, lsr 2
	sub	x2, x2, x3
	subs	x2, x0, x2
	sbc	x1, x1, xzr
	umulh	x3, x2, x5
	madd	x3, x1, x5, x3
	mul	x10, x2, x5
	madd	x3, x2, x8, x3
	umulh	x4, x2, x5
	madd	x4, x1, x5, x4
	madd	x4, x2, x8, x4
	extr	x3, x3, x10, 1
	add	x3, x3, x3, lsl 2
	lsr	x1, x4, 1
	sub	x3, x0, x3, lsl 1
	extr	x0, x4, x10, 1
	add	w3, w3, 48
	strb	w3, [x7, -1]
	cbnz	x9, .L12
	cmp	x12, 9
	bhi	.L12
	sub	w19, w19, #1
	add	x19, x20, x19
	.p2align 3,,7
.L8:
	ldrb	w0, [x19]
	bl	putchar
	cmp	x19, x20
	sub	x19, x19, #1
	bne	.L8
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 40]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	bne	.L15
	ldp	x29, x30, [sp, 48]
	ldp	x19, x20, [sp, 64]
	add	sp, sp, 80
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret
.L15:
	.cfi_restore_state
	bl	__stack_chk_fail
	.cfi_endproc
.LFE0:
	.size	print_unsigned, .-print_unsigned
	.align	2
	.p2align 4,,11
	.type	print_signed.part.0, %function
print_signed.part.0:
.LFB3:
	.cfi_startproc
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -16
	.cfi_offset 20, -8
	mov	x19, x0
	mov	x20, x1
	mov	w0, 45
	bl	putchar
	negs	x0, x19
	sbc	x1, xzr, x20
	ldp	x19, x20, [sp, 16]
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	b	print_unsigned
	.cfi_endproc
.LFE3:
	.size	print_signed.part.0, .-print_signed.part.0
	.section	.rodata.str1.8,"aMS",@progbits,1
	.align	3
.LC1:
	.string	"constant.ZLIB_VERNUM="
	.align	3
.LC2:
	.string	"constant_size.ZLIB_VERNUM=%zu\n"
	.align	3
.LC3:
	.string	"constant_signed.ZLIB_VERNUM=%d\n"
	.align	3
.LC4:
	.string	"constant.ZLIB_VER_MAJOR="
	.align	3
.LC5:
	.string	"constant_size.ZLIB_VER_MAJOR=%zu\n"
	.align	3
.LC6:
	.string	"constant_signed.ZLIB_VER_MAJOR=%d\n"
	.align	3
.LC7:
	.string	"constant.ZLIB_VER_MINOR="
	.align	3
.LC8:
	.string	"constant_size.ZLIB_VER_MINOR=%zu\n"
	.align	3
.LC9:
	.string	"constant_signed.ZLIB_VER_MINOR=%d\n"
	.align	3
.LC10:
	.string	"constant.ZLIB_VER_REVISION="
	.align	3
.LC11:
	.string	"constant_size.ZLIB_VER_REVISION=%zu\n"
	.align	3
.LC12:
	.string	"constant_signed.ZLIB_VER_REVISION=%d\n"
	.align	3
.LC13:
	.string	"constant.ZLIB_VER_SUBREVISION="
	.align	3
.LC14:
	.string	"constant_size.ZLIB_VER_SUBREVISION=%zu\n"
	.align	3
.LC15:
	.string	"constant_signed.ZLIB_VER_SUBREVISION=%d\n"
	.align	3
.LC16:
	.string	"constant.Z_ASCII="
	.align	3
.LC17:
	.string	"constant_size.Z_ASCII=%zu\n"
	.align	3
.LC18:
	.string	"constant_signed.Z_ASCII=%d\n"
	.align	3
.LC19:
	.string	"constant.Z_BEST_COMPRESSION="
	.align	3
.LC20:
	.string	"constant_size.Z_BEST_COMPRESSION=%zu\n"
	.align	3
.LC21:
	.string	"constant_signed.Z_BEST_COMPRESSION=%d\n"
	.align	3
.LC22:
	.string	"constant.Z_BEST_SPEED="
	.align	3
.LC23:
	.string	"constant_size.Z_BEST_SPEED=%zu\n"
	.align	3
.LC24:
	.string	"constant_signed.Z_BEST_SPEED=%d\n"
	.align	3
.LC25:
	.string	"constant.Z_BINARY="
	.align	3
.LC26:
	.string	"constant_size.Z_BINARY=%zu\n"
	.align	3
.LC27:
	.string	"constant_signed.Z_BINARY=%d\n"
	.align	3
.LC28:
	.string	"constant.Z_BLOCK="
	.align	3
.LC29:
	.string	"constant_size.Z_BLOCK=%zu\n"
	.align	3
.LC30:
	.string	"constant_signed.Z_BLOCK=%d\n"
	.align	3
.LC31:
	.string	"constant.Z_BUF_ERROR="
	.align	3
.LC32:
	.string	"constant_size.Z_BUF_ERROR=%zu\n"
	.align	3
.LC33:
	.string	"constant_signed.Z_BUF_ERROR=%d\n"
	.align	3
.LC34:
	.string	"constant.Z_DATA_ERROR="
	.align	3
.LC35:
	.string	"constant_size.Z_DATA_ERROR=%zu\n"
	.align	3
.LC36:
	.string	"constant_signed.Z_DATA_ERROR=%d\n"
	.align	3
.LC37:
	.string	"constant.Z_DEFAULT_COMPRESSION="
	.align	3
.LC38:
	.string	"constant_size.Z_DEFAULT_COMPRESSION=%zu\n"
	.align	3
.LC39:
	.string	"constant_signed.Z_DEFAULT_COMPRESSION=%d\n"
	.align	3
.LC40:
	.string	"constant.Z_DEFAULT_STRATEGY="
	.align	3
.LC41:
	.string	"constant_size.Z_DEFAULT_STRATEGY=%zu\n"
	.align	3
.LC42:
	.string	"constant_signed.Z_DEFAULT_STRATEGY=%d\n"
	.align	3
.LC43:
	.string	"constant.Z_DEFLATED="
	.align	3
.LC44:
	.string	"constant_size.Z_DEFLATED=%zu\n"
	.align	3
.LC45:
	.string	"constant_signed.Z_DEFLATED=%d\n"
	.align	3
.LC46:
	.string	"constant.Z_ERRNO="
	.align	3
.LC47:
	.string	"constant_size.Z_ERRNO=%zu\n"
	.align	3
.LC48:
	.string	"constant_signed.Z_ERRNO=%d\n"
	.align	3
.LC49:
	.string	"constant.Z_FILTERED="
	.align	3
.LC50:
	.string	"constant_size.Z_FILTERED=%zu\n"
	.align	3
.LC51:
	.string	"constant_signed.Z_FILTERED=%d\n"
	.align	3
.LC52:
	.string	"constant.Z_FINISH="
	.align	3
.LC53:
	.string	"constant_size.Z_FINISH=%zu\n"
	.align	3
.LC54:
	.string	"constant_signed.Z_FINISH=%d\n"
	.align	3
.LC55:
	.string	"constant.Z_FIXED="
	.align	3
.LC56:
	.string	"constant_size.Z_FIXED=%zu\n"
	.align	3
.LC57:
	.string	"constant_signed.Z_FIXED=%d\n"
	.align	3
.LC58:
	.string	"constant.Z_FULL_FLUSH="
	.align	3
.LC59:
	.string	"constant_size.Z_FULL_FLUSH=%zu\n"
	.align	3
.LC60:
	.string	"constant_signed.Z_FULL_FLUSH=%d\n"
	.align	3
.LC61:
	.string	"constant.Z_HUFFMAN_ONLY="
	.align	3
.LC62:
	.string	"constant_size.Z_HUFFMAN_ONLY=%zu\n"
	.align	3
.LC63:
	.string	"constant_signed.Z_HUFFMAN_ONLY=%d\n"
	.align	3
.LC64:
	.string	"constant.Z_MEM_ERROR="
	.align	3
.LC65:
	.string	"constant_size.Z_MEM_ERROR=%zu\n"
	.align	3
.LC66:
	.string	"constant_signed.Z_MEM_ERROR=%d\n"
	.align	3
.LC67:
	.string	"constant.Z_NEED_DICT="
	.align	3
.LC68:
	.string	"constant_size.Z_NEED_DICT=%zu\n"
	.align	3
.LC69:
	.string	"constant_signed.Z_NEED_DICT=%d\n"
	.align	3
.LC70:
	.string	"constant.Z_NO_COMPRESSION="
	.align	3
.LC71:
	.string	"constant_size.Z_NO_COMPRESSION=%zu\n"
	.align	3
.LC72:
	.string	"constant_signed.Z_NO_COMPRESSION=%d\n"
	.align	3
.LC73:
	.string	"constant.Z_NO_FLUSH="
	.align	3
.LC74:
	.string	"constant_size.Z_NO_FLUSH=%zu\n"
	.align	3
.LC75:
	.string	"constant_signed.Z_NO_FLUSH=%d\n"
	.align	3
.LC76:
	.string	"constant.Z_NULL="
	.align	3
.LC77:
	.string	"constant_size.Z_NULL=%zu\n"
	.align	3
.LC78:
	.string	"constant_signed.Z_NULL=%d\n"
	.align	3
.LC79:
	.string	"constant.Z_OK="
	.align	3
.LC80:
	.string	"constant_size.Z_OK=%zu\n"
	.align	3
.LC81:
	.string	"constant_signed.Z_OK=%d\n"
	.align	3
.LC82:
	.string	"constant.Z_PARTIAL_FLUSH="
	.align	3
.LC83:
	.string	"constant_size.Z_PARTIAL_FLUSH=%zu\n"
	.align	3
.LC84:
	.string	"constant_signed.Z_PARTIAL_FLUSH=%d\n"
	.align	3
.LC85:
	.string	"constant.Z_RLE="
	.align	3
.LC86:
	.string	"constant_size.Z_RLE=%zu\n"
	.align	3
.LC87:
	.string	"constant_signed.Z_RLE=%d\n"
	.align	3
.LC88:
	.string	"constant.Z_STREAM_END="
	.align	3
.LC89:
	.string	"constant_size.Z_STREAM_END=%zu\n"
	.align	3
.LC90:
	.string	"constant_signed.Z_STREAM_END=%d\n"
	.align	3
.LC91:
	.string	"constant.Z_STREAM_ERROR="
	.align	3
.LC92:
	.string	"constant_size.Z_STREAM_ERROR=%zu\n"
	.align	3
.LC93:
	.string	"constant_signed.Z_STREAM_ERROR=%d\n"
	.align	3
.LC94:
	.string	"constant.Z_SYNC_FLUSH="
	.align	3
.LC95:
	.string	"constant_size.Z_SYNC_FLUSH=%zu\n"
	.align	3
.LC96:
	.string	"constant_signed.Z_SYNC_FLUSH=%d\n"
	.align	3
.LC97:
	.string	"constant.Z_TEXT="
	.align	3
.LC98:
	.string	"constant_size.Z_TEXT=%zu\n"
	.align	3
.LC99:
	.string	"constant_signed.Z_TEXT=%d\n"
	.align	3
.LC100:
	.string	"constant.Z_TREES="
	.align	3
.LC101:
	.string	"constant_size.Z_TREES=%zu\n"
	.align	3
.LC102:
	.string	"constant_signed.Z_TREES=%d\n"
	.align	3
.LC103:
	.string	"constant.Z_UNKNOWN="
	.align	3
.LC104:
	.string	"constant_size.Z_UNKNOWN=%zu\n"
	.align	3
.LC105:
	.string	"constant_signed.Z_UNKNOWN=%d\n"
	.align	3
.LC106:
	.string	"constant.Z_VERSION_ERROR="
	.align	3
.LC107:
	.string	"constant_size.Z_VERSION_ERROR=%zu\n"
	.align	3
.LC108:
	.string	"constant_signed.Z_VERSION_ERROR=%d\n"
	.align	3
.LC109:
	.string	"string.ZLIB_VERSION="
	.align	3
.LC110:
	.string	"1.3.1"
	.align	3
.LC111:
	.string	"%02x"
	.align	3
.LC112:
	.string	"size.z_stream=%zu\n"
	.align	3
.LC113:
	.string	"align.z_stream=%zu\n"
	.align	3
.LC114:
	.string	"offset.z_stream.next_in=%zu\n"
	.align	3
.LC115:
	.string	"offset.z_stream.avail_in=%zu\n"
	.align	3
.LC116:
	.string	"offset.z_stream.total_in=%zu\n"
	.align	3
.LC117:
	.string	"offset.z_stream.next_out=%zu\n"
	.align	3
.LC118:
	.string	"offset.z_stream.avail_out=%zu\n"
	.align	3
.LC119:
	.string	"offset.z_stream.total_out=%zu\n"
	.align	3
.LC120:
	.string	"offset.z_stream.msg=%zu\n"
	.align	3
.LC121:
	.string	"offset.z_stream.state=%zu\n"
	.align	3
.LC122:
	.string	"offset.z_stream.zalloc=%zu\n"
	.align	3
.LC123:
	.string	"offset.z_stream.zfree=%zu\n"
	.align	3
.LC124:
	.string	"offset.z_stream.opaque=%zu\n"
	.align	3
.LC125:
	.string	"offset.z_stream.data_type=%zu\n"
	.align	3
.LC126:
	.string	"offset.z_stream.adler=%zu\n"
	.align	3
.LC127:
	.string	"offset.z_stream.reserved=%zu\n"
	.align	3
.LC128:
	.string	"size.gz_header=%zu\n"
	.align	3
.LC129:
	.string	"align.gz_header=%zu\n"
	.align	3
.LC130:
	.string	"offset.gz_header.text=%zu\n"
	.align	3
.LC131:
	.string	"offset.gz_header.time=%zu\n"
	.align	3
.LC132:
	.string	"offset.gz_header.xflags=%zu\n"
	.align	3
.LC133:
	.string	"offset.gz_header.os=%zu\n"
	.align	3
.LC134:
	.string	"offset.gz_header.extra=%zu\n"
	.align	3
.LC135:
	.string	"offset.gz_header.extra_len=%zu\n"
	.align	3
.LC136:
	.string	"offset.gz_header.extra_max=%zu\n"
	.align	3
.LC137:
	.string	"offset.gz_header.name=%zu\n"
	.align	3
.LC138:
	.string	"offset.gz_header.name_max=%zu\n"
	.align	3
.LC139:
	.string	"offset.gz_header.comment=%zu\n"
	.align	3
.LC140:
	.string	"offset.gz_header.comm_max=%zu\n"
	.align	3
.LC141:
	.string	"offset.gz_header.hcrc=%zu\n"
	.align	3
.LC142:
	.string	"offset.gz_header.done=%zu\n"
	.section	.text.startup,"ax",@progbits
	.align	2
	.p2align 4,,11
	.global	main
	.type	main, %function
main:
.LFB2:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	adrp	x0, .LC1
	add	x0, x0, :lo12:.LC1
	mov	x29, sp
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -32
	.cfi_offset 20, -24
	adrp	x19, .LC110
	add	x19, x19, :lo12:.LC110
	str	x21, [sp, 32]
	.cfi_offset 21, -16
	bl	printf
	mov	x1, 0
	mov	x0, 4880
	bl	print_unsigned
	adrp	x20, .LC111
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC2
	add	x0, x0, :lo12:.LC2
	bl	printf
	mov	w1, 1
	adrp	x0, .LC3
	add	x0, x0, :lo12:.LC3
	bl	printf
	adrp	x0, .LC4
	add	x0, x0, :lo12:.LC4
	bl	printf
	add	x20, x20, :lo12:.LC111
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	add	x21, x19, 6
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC5
	add	x0, x0, :lo12:.LC5
	bl	printf
	mov	w1, 1
	adrp	x0, .LC6
	add	x0, x0, :lo12:.LC6
	bl	printf
	adrp	x0, .LC7
	add	x0, x0, :lo12:.LC7
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC8
	add	x0, x0, :lo12:.LC8
	bl	printf
	mov	w1, 1
	adrp	x0, .LC9
	add	x0, x0, :lo12:.LC9
	bl	printf
	adrp	x0, .LC10
	add	x0, x0, :lo12:.LC10
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC11
	add	x0, x0, :lo12:.LC11
	bl	printf
	mov	w1, 1
	adrp	x0, .LC12
	add	x0, x0, :lo12:.LC12
	bl	printf
	adrp	x0, .LC13
	add	x0, x0, :lo12:.LC13
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC14
	add	x0, x0, :lo12:.LC14
	bl	printf
	mov	w1, 1
	adrp	x0, .LC15
	add	x0, x0, :lo12:.LC15
	bl	printf
	adrp	x0, .LC16
	add	x0, x0, :lo12:.LC16
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC17
	add	x0, x0, :lo12:.LC17
	bl	printf
	mov	w1, 1
	adrp	x0, .LC18
	add	x0, x0, :lo12:.LC18
	bl	printf
	adrp	x0, .LC19
	add	x0, x0, :lo12:.LC19
	bl	printf
	mov	x1, 0
	mov	x0, 9
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC20
	add	x0, x0, :lo12:.LC20
	bl	printf
	mov	w1, 1
	adrp	x0, .LC21
	add	x0, x0, :lo12:.LC21
	bl	printf
	adrp	x0, .LC22
	add	x0, x0, :lo12:.LC22
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC23
	add	x0, x0, :lo12:.LC23
	bl	printf
	mov	w1, 1
	adrp	x0, .LC24
	add	x0, x0, :lo12:.LC24
	bl	printf
	adrp	x0, .LC25
	add	x0, x0, :lo12:.LC25
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC26
	add	x0, x0, :lo12:.LC26
	bl	printf
	mov	w1, 1
	adrp	x0, .LC27
	add	x0, x0, :lo12:.LC27
	bl	printf
	adrp	x0, .LC28
	add	x0, x0, :lo12:.LC28
	bl	printf
	mov	x1, 0
	mov	x0, 5
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC29
	add	x0, x0, :lo12:.LC29
	bl	printf
	mov	w1, 1
	adrp	x0, .LC30
	add	x0, x0, :lo12:.LC30
	bl	printf
	adrp	x0, .LC31
	add	x0, x0, :lo12:.LC31
	bl	printf
	mov	x1, -1
	mov	x0, -5
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC32
	add	x0, x0, :lo12:.LC32
	bl	printf
	mov	w1, 1
	adrp	x0, .LC33
	add	x0, x0, :lo12:.LC33
	bl	printf
	adrp	x0, .LC34
	add	x0, x0, :lo12:.LC34
	bl	printf
	mov	x1, -1
	mov	x0, -3
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC35
	add	x0, x0, :lo12:.LC35
	bl	printf
	mov	w1, 1
	adrp	x0, .LC36
	add	x0, x0, :lo12:.LC36
	bl	printf
	adrp	x0, .LC37
	add	x0, x0, :lo12:.LC37
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC38
	add	x0, x0, :lo12:.LC38
	bl	printf
	mov	w1, 1
	adrp	x0, .LC39
	add	x0, x0, :lo12:.LC39
	bl	printf
	adrp	x0, .LC40
	add	x0, x0, :lo12:.LC40
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC41
	add	x0, x0, :lo12:.LC41
	bl	printf
	mov	w1, 1
	adrp	x0, .LC42
	add	x0, x0, :lo12:.LC42
	bl	printf
	adrp	x0, .LC43
	add	x0, x0, :lo12:.LC43
	bl	printf
	mov	x1, 0
	mov	x0, 8
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC44
	add	x0, x0, :lo12:.LC44
	bl	printf
	mov	w1, 1
	adrp	x0, .LC45
	add	x0, x0, :lo12:.LC45
	bl	printf
	adrp	x0, .LC46
	add	x0, x0, :lo12:.LC46
	bl	printf
	mov	x1, -1
	mov	x0, -1
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC47
	add	x0, x0, :lo12:.LC47
	bl	printf
	mov	w1, 1
	adrp	x0, .LC48
	add	x0, x0, :lo12:.LC48
	bl	printf
	adrp	x0, .LC49
	add	x0, x0, :lo12:.LC49
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC50
	add	x0, x0, :lo12:.LC50
	bl	printf
	mov	w1, 1
	adrp	x0, .LC51
	add	x0, x0, :lo12:.LC51
	bl	printf
	adrp	x0, .LC52
	add	x0, x0, :lo12:.LC52
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC53
	add	x0, x0, :lo12:.LC53
	bl	printf
	mov	w1, 1
	adrp	x0, .LC54
	add	x0, x0, :lo12:.LC54
	bl	printf
	adrp	x0, .LC55
	add	x0, x0, :lo12:.LC55
	bl	printf
	mov	x1, 0
	mov	x0, 4
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC56
	add	x0, x0, :lo12:.LC56
	bl	printf
	mov	w1, 1
	adrp	x0, .LC57
	add	x0, x0, :lo12:.LC57
	bl	printf
	adrp	x0, .LC58
	add	x0, x0, :lo12:.LC58
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC59
	add	x0, x0, :lo12:.LC59
	bl	printf
	mov	w1, 1
	adrp	x0, .LC60
	add	x0, x0, :lo12:.LC60
	bl	printf
	adrp	x0, .LC61
	add	x0, x0, :lo12:.LC61
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC62
	add	x0, x0, :lo12:.LC62
	bl	printf
	mov	w1, 1
	adrp	x0, .LC63
	add	x0, x0, :lo12:.LC63
	bl	printf
	adrp	x0, .LC64
	add	x0, x0, :lo12:.LC64
	bl	printf
	mov	x1, -1
	mov	x0, -4
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC65
	add	x0, x0, :lo12:.LC65
	bl	printf
	mov	w1, 1
	adrp	x0, .LC66
	add	x0, x0, :lo12:.LC66
	bl	printf
	adrp	x0, .LC67
	add	x0, x0, :lo12:.LC67
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC68
	add	x0, x0, :lo12:.LC68
	bl	printf
	mov	w1, 1
	adrp	x0, .LC69
	add	x0, x0, :lo12:.LC69
	bl	printf
	adrp	x0, .LC70
	add	x0, x0, :lo12:.LC70
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC71
	add	x0, x0, :lo12:.LC71
	bl	printf
	mov	w1, 1
	adrp	x0, .LC72
	add	x0, x0, :lo12:.LC72
	bl	printf
	adrp	x0, .LC73
	add	x0, x0, :lo12:.LC73
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC74
	add	x0, x0, :lo12:.LC74
	bl	printf
	mov	w1, 1
	adrp	x0, .LC75
	add	x0, x0, :lo12:.LC75
	bl	printf
	adrp	x0, .LC76
	add	x0, x0, :lo12:.LC76
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC77
	add	x0, x0, :lo12:.LC77
	bl	printf
	mov	w1, 1
	adrp	x0, .LC78
	add	x0, x0, :lo12:.LC78
	bl	printf
	adrp	x0, .LC79
	add	x0, x0, :lo12:.LC79
	bl	printf
	mov	x1, 0
	mov	x0, 0
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC80
	add	x0, x0, :lo12:.LC80
	bl	printf
	mov	w1, 1
	adrp	x0, .LC81
	add	x0, x0, :lo12:.LC81
	bl	printf
	adrp	x0, .LC82
	add	x0, x0, :lo12:.LC82
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC83
	add	x0, x0, :lo12:.LC83
	bl	printf
	mov	w1, 1
	adrp	x0, .LC84
	add	x0, x0, :lo12:.LC84
	bl	printf
	adrp	x0, .LC85
	add	x0, x0, :lo12:.LC85
	bl	printf
	mov	x1, 0
	mov	x0, 3
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC86
	add	x0, x0, :lo12:.LC86
	bl	printf
	mov	w1, 1
	adrp	x0, .LC87
	add	x0, x0, :lo12:.LC87
	bl	printf
	adrp	x0, .LC88
	add	x0, x0, :lo12:.LC88
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC89
	add	x0, x0, :lo12:.LC89
	bl	printf
	mov	w1, 1
	adrp	x0, .LC90
	add	x0, x0, :lo12:.LC90
	bl	printf
	adrp	x0, .LC91
	add	x0, x0, :lo12:.LC91
	bl	printf
	mov	x1, -1
	mov	x0, -2
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC92
	add	x0, x0, :lo12:.LC92
	bl	printf
	mov	w1, 1
	adrp	x0, .LC93
	add	x0, x0, :lo12:.LC93
	bl	printf
	adrp	x0, .LC94
	add	x0, x0, :lo12:.LC94
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC95
	add	x0, x0, :lo12:.LC95
	bl	printf
	mov	w1, 1
	adrp	x0, .LC96
	add	x0, x0, :lo12:.LC96
	bl	printf
	adrp	x0, .LC97
	add	x0, x0, :lo12:.LC97
	bl	printf
	mov	x1, 0
	mov	x0, 1
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC98
	add	x0, x0, :lo12:.LC98
	bl	printf
	mov	w1, 1
	adrp	x0, .LC99
	add	x0, x0, :lo12:.LC99
	bl	printf
	adrp	x0, .LC100
	add	x0, x0, :lo12:.LC100
	bl	printf
	mov	x1, 0
	mov	x0, 6
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC101
	add	x0, x0, :lo12:.LC101
	bl	printf
	mov	w1, 1
	adrp	x0, .LC102
	add	x0, x0, :lo12:.LC102
	bl	printf
	adrp	x0, .LC103
	add	x0, x0, :lo12:.LC103
	bl	printf
	mov	x1, 0
	mov	x0, 2
	bl	print_unsigned
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC104
	add	x0, x0, :lo12:.LC104
	bl	printf
	mov	w1, 1
	adrp	x0, .LC105
	add	x0, x0, :lo12:.LC105
	bl	printf
	adrp	x0, .LC106
	add	x0, x0, :lo12:.LC106
	bl	printf
	mov	x1, -1
	mov	x0, -6
	bl	print_signed.part.0
	mov	w0, 10
	bl	putchar
	mov	x1, 4
	adrp	x0, .LC107
	add	x0, x0, :lo12:.LC107
	bl	printf
	mov	w1, 1
	adrp	x0, .LC108
	add	x0, x0, :lo12:.LC108
	bl	printf
	adrp	x0, .LC109
	add	x0, x0, :lo12:.LC109
	bl	printf
	mov	w1, 49
	b	.L20
	.p2align 2,,3
.L22:
	ldrb	w1, [x19]
.L20:
	mov	x0, x20
	add	x19, x19, 1
	bl	printf
	cmp	x19, x21
	bne	.L22
	mov	w0, 10
	bl	putchar
	mov	x1, 112
	adrp	x0, .LC112
	add	x0, x0, :lo12:.LC112
	bl	printf
	mov	x1, 8
	adrp	x0, .LC113
	add	x0, x0, :lo12:.LC113
	bl	printf
	mov	x1, 0
	adrp	x0, .LC114
	add	x0, x0, :lo12:.LC114
	bl	printf
	mov	x1, 8
	adrp	x0, .LC115
	add	x0, x0, :lo12:.LC115
	bl	printf
	mov	x1, 16
	adrp	x0, .LC116
	add	x0, x0, :lo12:.LC116
	bl	printf
	mov	x1, 24
	adrp	x0, .LC117
	add	x0, x0, :lo12:.LC117
	bl	printf
	mov	x1, 32
	adrp	x0, .LC118
	add	x0, x0, :lo12:.LC118
	bl	printf
	mov	x1, 40
	adrp	x0, .LC119
	add	x0, x0, :lo12:.LC119
	bl	printf
	mov	x1, 48
	adrp	x0, .LC120
	add	x0, x0, :lo12:.LC120
	bl	printf
	mov	x1, 56
	adrp	x0, .LC121
	add	x0, x0, :lo12:.LC121
	bl	printf
	mov	x1, 64
	adrp	x0, .LC122
	add	x0, x0, :lo12:.LC122
	bl	printf
	mov	x1, 72
	adrp	x0, .LC123
	add	x0, x0, :lo12:.LC123
	bl	printf
	mov	x1, 80
	adrp	x0, .LC124
	add	x0, x0, :lo12:.LC124
	bl	printf
	mov	x1, 88
	adrp	x0, .LC125
	add	x0, x0, :lo12:.LC125
	bl	printf
	mov	x1, 96
	adrp	x0, .LC126
	add	x0, x0, :lo12:.LC126
	bl	printf
	mov	x1, 104
	adrp	x0, .LC127
	add	x0, x0, :lo12:.LC127
	bl	printf
	mov	x1, 80
	adrp	x0, .LC128
	add	x0, x0, :lo12:.LC128
	bl	printf
	mov	x1, 8
	adrp	x0, .LC129
	add	x0, x0, :lo12:.LC129
	bl	printf
	mov	x1, 0
	adrp	x0, .LC130
	add	x0, x0, :lo12:.LC130
	bl	printf
	mov	x1, 8
	adrp	x0, .LC131
	add	x0, x0, :lo12:.LC131
	bl	printf
	mov	x1, 16
	adrp	x0, .LC132
	add	x0, x0, :lo12:.LC132
	bl	printf
	mov	x1, 20
	adrp	x0, .LC133
	add	x0, x0, :lo12:.LC133
	bl	printf
	mov	x1, 24
	adrp	x0, .LC134
	add	x0, x0, :lo12:.LC134
	bl	printf
	mov	x1, 32
	adrp	x0, .LC135
	add	x0, x0, :lo12:.LC135
	bl	printf
	mov	x1, 36
	adrp	x0, .LC136
	add	x0, x0, :lo12:.LC136
	bl	printf
	mov	x1, 40
	adrp	x0, .LC137
	add	x0, x0, :lo12:.LC137
	bl	printf
	mov	x1, 48
	adrp	x0, .LC138
	add	x0, x0, :lo12:.LC138
	bl	printf
	mov	x1, 56
	adrp	x0, .LC139
	add	x0, x0, :lo12:.LC139
	bl	printf
	mov	x1, 64
	adrp	x0, .LC140
	add	x0, x0, :lo12:.LC140
	bl	printf
	mov	x1, 68
	adrp	x0, .LC141
	add	x0, x0, :lo12:.LC141
	bl	printf
	mov	x1, 72
	adrp	x0, .LC142
	add	x0, x0, :lo12:.LC142
	bl	printf
	ldp	x19, x20, [sp, 16]
	mov	w0, 0
	ldr	x21, [sp, 32]
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 21
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE2:
	.size	main, .-main
	.section	.rodata.cst16,"aM",@progbits,16
	.align	4
.LC0:
	.xword	-3689348814741910323
	.xword	-3689348814741910324
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
