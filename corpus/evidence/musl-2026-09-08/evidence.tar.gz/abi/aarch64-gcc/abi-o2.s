	.arch armv8-a
	.file	"abi.c"
	.text
	.align	2
	.p2align 4,,11
	.type	musl_variadic_copy, %function
musl_variadic_copy:
.LFB7:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	adrp	x1, :got:__stack_chk_guard
	ldr	x1, [x1, :got_lo12:__stack_chk_guard]
	stp	x29, x30, [sp, 48]
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	add	x29, sp, 48
	ldp	q0, q1, [x0]
	ldr	x0, [x1]
	str	x0, [sp, 40]
	mov	x0, 0
	add	x0, sp, 8
	stp	q0, q1, [x0]
	ldr	w3, [sp, 32]
	ldr	x1, [sp, 8]
	tbnz	w3, #31, .L2
	add	x0, x1, 11
	and	x0, x0, -8
	str	x0, [sp, 8]
.L3:
	ldr	w4, [sp, 36]
	ldr	w1, [x1]
	tbnz	w4, #31, .L5
.L18:
	add	x2, x0, 15
	ldr	d0, [x0]
	and	x2, x2, -8
	str	x2, [sp, 8]
	tbnz	w3, #31, .L8
.L19:
	ldr	x4, [x2]
	add	x0, x2, 15
	and	x0, x0, -8
.L14:
	add	x2, x0, 15
	and	x2, x2, -8
	str	x2, [sp, 8]
.L12:
	ldr	x3, [x0]
	fcvtzs	x0, d0
	adrp	x2, :got:__stack_chk_guard
	ldr	x2, [x2, :got_lo12:__stack_chk_guard]
	ldr	x3, [x3]
	add	x1, x0, w1, sxtw
	mov	x0, x2
	add	x1, x1, x4
	ldr	x4, [sp, 40]
	ldr	x2, [x0]
	subs	x4, x4, x2
	mov	x2, 0
	add	x0, x1, x3
	bne	.L21
	ldp	x29, x30, [sp, 48]
	add	sp, sp, 64
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.p2align 2,,3
.L2:
	.cfi_restore_state
	add	w2, w3, 8
	str	w2, [sp, 32]
	cmp	w2, 0
	ble	.L4
	ldr	w4, [sp, 36]
	add	x0, x1, 11
	and	x0, x0, -8
	str	x0, [sp, 8]
	ldr	w1, [x1]
	mov	w3, w2
	tbz	w4, #31, .L18
.L5:
	add	w2, w4, 16
	str	w2, [sp, 36]
	cmp	w2, 0
	bgt	.L18
	ldr	x5, [sp, 24]
	mov	x2, x0
	add	x0, x5, w4, sxtw
	ldr	d0, [x0]
	tbz	w3, #31, .L19
	.p2align 3,,7
.L8:
	add	w0, w3, 8
	str	w0, [sp, 32]
	cmp	w0, 0
	bgt	.L19
	ldr	x5, [sp, 16]
	ldr	x4, [x5, w3, sxtw]
	beq	.L22
	cmn	w3, #15
	blt	.L13
	add	x3, x2, 15
	mov	x0, x2
	and	x2, x3, -8
	str	x2, [sp, 8]
	b	.L12
	.p2align 2,,3
.L13:
	add	x0, x5, w0, sxtw
	b	.L12
	.p2align 2,,3
.L4:
	ldr	x4, [sp, 16]
	mov	x0, x1
	add	x1, x4, w3, sxtw
	mov	w3, w2
	b	.L3
.L21:
	bl	__stack_chk_fail
.L22:
	mov	x0, x2
	b	.L14
	.cfi_endproc
.LFE7:
	.size	musl_variadic_copy, .-musl_variadic_copy
	.align	2
	.p2align 4,,11
	.global	musl_pair
	.type	musl_pair, %function
musl_pair:
.LFB0:
	.cfi_startproc
	fmov	w2, s1
	fmov	x0, d0
	fmov	s3, 2.0e+0
	fmov	s2, 3.0e+0
	mov	x1, 0
	bfi	x0, x2, 32, 32
	fmov	d0, x0
	sbfx	x2, x0, 0, 32
	ushr	d0, d0, 32
	fmov	d1, x2
	fadd	s1, s1, s3
	fsub	s0, s0, s2
	fmov	w2, s1
	fmov	w0, s0
	bfi	x1, x2, 0, 32
	bfi	x1, x0, 32, 32
	lsr	x0, x1, 32
	lsr	w1, w1, 0
	fmov	s1, w0
	fmov	s0, w1
	ret
	.cfi_endproc
.LFE0:
	.size	musl_pair, .-musl_pair
	.align	2
	.p2align 4,,11
	.global	musl_triplet
	.type	musl_triplet, %function
musl_triplet:
.LFB1:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	mov	w1, w0
	add	w2, w0, 1
	ubfx	x1, x1, 8, 8
	add	w1, w1, 2
	strb	w2, [sp, 24]
	strb	w1, [sp, 25]
	ubfx	x1, x0, 16, 8
	add	w1, w1, 3
	mov	x0, 0
	ldrh	w2, [sp, 24]
	add	sp, sp, 32
	.cfi_def_cfa_offset 0
	bfi	x0, x2, 0, 16
	bfi	x0, x1, 16, 8
	ret
	.cfi_endproc
.LFE1:
	.size	musl_triplet, .-musl_triplet
	.align	2
	.p2align 4,,11
	.global	musl_mixed
	.type	musl_mixed, %function
musl_mixed:
.LFB2:
	.cfi_startproc
	ldr	d0, [x0, 16]
	mov	w2, 7
	ldr	x1, [x0, 8]
	strb	w2, [x0]
	fadd	d0, d0, d0
	add	x1, x1, 17
	str	x1, [x0, 8]
	str	d0, [x0, 16]
	ldp	q0, q1, [x0]
	stp	q0, q1, [x8]
	ret
	.cfi_endproc
.LFE2:
	.size	musl_mixed, .-musl_mixed
	.align	2
	.p2align 4,,11
	.global	musl_packed
	.type	musl_packed, %function
musl_packed:
.LFB3:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp]
	mov	w0, 9
	strb	w1, [sp, 8]
	strb	w0, [sp, 16]
	ldr	x0, [sp, 1]
	add	x0, x0, 19
	str	x0, [sp, 17]
	ldr	x0, [sp, 16]
	ldrb	w1, [sp, 24]
	add	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE3:
	.size	musl_packed, .-musl_packed
	.align	2
	.p2align 4,,11
	.global	musl_union
	.type	musl_union, %function
musl_union:
.LFB4:
	.cfi_startproc
	mov	x1, 52719
	movk	x1, 0x89ab, lsl 16
	movk	x1, 0x4567, lsl 32
	movk	x1, 0x8123, lsl 48
	eor	x0, x0, x1
	ret
	.cfi_endproc
.LFE4:
	.size	musl_union, .-musl_union
	.align	2
	.p2align 4,,11
	.global	musl_callback
	.type	musl_callback, %function
musl_callback:
.LFB5:
	.cfi_startproc
	fmov	w3, s1
	fmov	x2, d0
	stp	x29, x30, [sp, -32]!
	.cfi_def_cfa_offset 32
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	mov	x29, sp
	bfi	x2, x3, 32, 32
	stp	x19, x20, [sp, 16]
	.cfi_offset 19, -16
	.cfi_offset 20, -8
	mov	x19, x0
	lsr	x3, x2, 32
	lsr	w2, w2, 0
	fmov	s1, w3
	fmov	s0, w2
	mov	x20, x1
	mov	x0, 5
	blr	x19
	fmov	w3, s1
	fmov	x2, d0
	mov	x1, x20
	mov	x16, x19
	mov	x0, 11
	ldp	x19, x20, [sp, 16]
	ldp	x29, x30, [sp], 32
	.cfi_restore 30
	.cfi_restore 29
	.cfi_restore 19
	.cfi_restore 20
	.cfi_def_cfa_offset 0
	bfi	x2, x3, 32, 32
	lsr	x3, x2, 32
	lsr	w2, w2, 0
	fmov	s1, w3
	fmov	s0, w2
	br	x16
	.cfi_endproc
.LFE5:
	.size	musl_callback, .-musl_callback
	.align	2
	.p2align 4,,11
	.global	musl_stack
	.type	musl_stack, %function
musl_stack:
.LFB6:
	.cfi_startproc
	fmov	d16, 2.0e+0
	fmov	d21, 3.0e+0
	fmov	d20, 4.0e+0
	fmov	d19, 5.0e+0
	fmadd	d0, d1, d16, d0
	fmov	d18, 6.0e+0
	fmov	d17, 7.0e+0
	fmov	d16, 8.0e+0
	fmov	d1, 9.0e+0
	add	x1, x0, x1, lsl 1
	add	x2, x2, x2, lsl 1
	add	x4, x4, x4, lsl 2
	fmadd	d0, d2, d21, d0
	ldr	d2, [sp]
	add	x1, x1, x2
	add	x5, x5, x5, lsl 1
	add	x3, x1, x3, lsl 2
	add	x3, x3, x4
	fmadd	d0, d3, d20, d0
	add	x5, x3, x5, lsl 1
	add	x5, x5, x6, lsl 3
	sub	x5, x5, x6
	add	x7, x5, x7, lsl 3
	fmadd	d0, d4, d19, d0
	fmadd	d0, d5, d18, d0
	fmadd	d0, d6, d17, d0
	fmadd	d0, d7, d16, d0
	fmadd	d0, d2, d1, d0
	fcvtzs	x0, d0
	add	x0, x0, x7
	ret
	.cfi_endproc
.LFE6:
	.size	musl_stack, .-musl_stack
	.align	2
	.p2align 4,,11
	.global	musl_variadic
	.type	musl_variadic, %function
musl_variadic:
.LFB8:
	.cfi_startproc
	sub	sp, sp, #304
	.cfi_def_cfa_offset 304
	mov	w11, -56
	adrp	x9, :got:__stack_chk_guard
	ldr	x9, [x9, :got_lo12:__stack_chk_guard]
	add	x12, sp, 240
	stp	x29, x30, [sp, 80]
	.cfi_offset 29, -224
	.cfi_offset 30, -216
	add	x29, sp, 80
	mov	w10, -128
	mov	x8, sp
	str	x19, [sp, 96]
	.cfi_offset 19, -208
	mov	w19, w0
	str	q0, [sp, 112]
	mov	x0, x8
	str	q1, [sp, 128]
	str	q2, [sp, 144]
	str	q3, [sp, 160]
	str	q4, [sp, 176]
	str	q5, [sp, 192]
	str	q6, [sp, 208]
	str	q7, [sp, 224]
	stp	x1, x2, [sp, 248]
	stp	x3, x4, [sp, 264]
	stp	x5, x6, [sp, 280]
	str	x7, [sp, 296]
	ldr	x1, [x9]
	str	x1, [sp, 72]
	mov	x1, 0
	str	x12, [sp, 56]
	add	x1, sp, 304
	stp	x1, x1, [sp, 40]
	add	x1, sp, 40
	stp	w11, w10, [sp, 64]
	ldp	q0, q1, [x1]
	stp	q0, q1, [x8]
	bl	musl_variadic_copy
	add	x0, x0, w19, sxtw
	adrp	x1, :got:__stack_chk_guard
	ldr	x1, [x1, :got_lo12:__stack_chk_guard]
	ldr	x3, [sp, 72]
	ldr	x2, [x1]
	subs	x3, x3, x2
	mov	x2, 0
	bne	.L36
	ldp	x29, x30, [sp, 80]
	ldr	x19, [sp, 96]
	add	sp, sp, 304
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret
.L36:
	.cfi_restore_state
	bl	__stack_chk_fail
	.cfi_endproc
.LFE8:
	.size	musl_variadic, .-musl_variadic
	.align	2
	.p2align 4,,11
	.global	musl_bits_write
	.type	musl_bits_write, %function
musl_bits_write:
.LFB9:
	.cfi_startproc
	ldr	w1, [x0]
	mov	w2, 32215
	movk	w2, 0xc01, lsl 16
	and	w1, w1, 16646144
	orr	w1, w1, w2
	str	w1, [x0]
	ret
	.cfi_endproc
.LFE9:
	.size	musl_bits_write, .-musl_bits_write
	.align	2
	.p2align 4,,11
	.global	musl_bits_read
	.type	musl_bits_read, %function
musl_bits_read:
.LFB10:
	.cfi_startproc
	ldr	w1, [x0]
	mov	w6, 100
	ldrb	w0, [x0, 3]
	mov	w4, 1000
	mov	w3, 16960
	sbfx	x5, x1, 0, 5
	ubfx	x2, x1, 5, 3
	ubfx	x1, x1, 8, 9
	movk	w3, 0xf, lsl 16
	madd	w2, w2, w6, w5
	madd	w1, w1, w4, w2
	madd	w0, w0, w3, w1
	sxtw	x0, w0
	ret
	.cfi_endproc
.LFE10:
	.size	musl_bits_read, .-musl_bits_read
	.align	2
	.p2align 4,,11
	.global	musl_atomic_store
	.type	musl_atomic_store, %function
musl_atomic_store:
.LFB11:
	.cfi_startproc
	stlr	x1, [x0]
	ret
	.cfi_endproc
.LFE11:
	.size	musl_atomic_store, .-musl_atomic_store
	.align	2
	.p2align 4,,11
	.global	musl_atomic_load
	.type	musl_atomic_load, %function
musl_atomic_load:
.LFB12:
	.cfi_startproc
	ldar	x0, [x0]
	ret
	.cfi_endproc
.LFE12:
	.size	musl_atomic_load, .-musl_atomic_load
	.align	2
	.p2align 4,,11
	.global	musl_dimensions
	.type	musl_dimensions, %function
musl_dimensions:
.LFB13:
	.cfi_startproc
	sub	sp, sp, #432
	.cfi_def_cfa_offset 432
	mov	x2, 392
	adrp	x1, :got:__stack_chk_guard
	ldr	x1, [x1, :got_lo12:__stack_chk_guard]
	mov	x3, sp
	stp	x29, x30, [sp, 400]
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	add	x29, sp, 400
	str	x19, [sp, 416]
	.cfi_offset 19, -16
	mov	x19, x0
	ldr	x0, [x1]
	str	x0, [sp, 392]
	mov	x0, 0
	adrp	x1, .LANCHOR0
	mov	x0, x3
	add	x1, x1, :lo12:.LANCHOR0
	bl	memcpy
	mov	x1, x0
	mov	x2, 392
	mov	x0, x19
	bl	memcpy
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 392]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	bne	.L44
	ldp	x29, x30, [sp, 400]
	ldr	x19, [sp, 416]
	add	sp, sp, 432
	.cfi_remember_state
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret
.L44:
	.cfi_restore_state
	bl	__stack_chk_fail
	.cfi_endproc
.LFE13:
	.size	musl_dimensions, .-musl_dimensions
	.section	.rodata
	.align	3
	.set	.LANCHOR0,. + 0
.LC0:
	.xword	1
	.xword	1
	.xword	2
	.xword	2
	.xword	4
	.xword	4
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	4
	.xword	4
	.xword	4
	.xword	4
	.xword	4
	.xword	4
	.xword	8
	.xword	8
	.xword	16
	.xword	16
	.xword	32
	.xword	8
	.xword	8
	.xword	4
	.xword	3
	.xword	1
	.xword	32
	.xword	8
	.xword	9
	.xword	1
	.xword	4
	.xword	4
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	4
	.xword	2
	.xword	8
	.xword	16
	.xword	24
	.xword	1
	.xword	3
	.xword	1
	.xword	1
	.xword	1
	.xword	1
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
