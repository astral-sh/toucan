	.arch armv8-a
	.file	"abi.c"
	.text
	.align	2
	.global	musl_pair
	.type	musl_pair, %function
musl_pair:
.LFB0:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	fmov	s2, s0
	fmov	s0, s1
	fmov	x0, d2
	fmov	w1, s0
	bfi	x0, x1, 32, 32
	str	x0, [sp, 8]
	ldr	s1, [sp, 8]
	fmov	s0, 2.0e+0
	fadd	s0, s1, s0
	str	s0, [sp, 8]
	ldr	s1, [sp, 12]
	fmov	s0, 3.0e+0
	fsub	s0, s1, s0
	str	s0, [sp, 12]
	ldr	x0, [sp, 8]
	mov	x1, x0
	lsr	w1, w1, 0
	lsr	x0, x0, 32
	fmov	s0, w1
	fmov	s1, w0
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE0:
	.size	musl_pair, .-musl_pair
	.align	2
	.global	musl_triplet
	.type	musl_triplet, %function
musl_triplet:
.LFB1:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp, 8]
	ldrb	w0, [sp, 8]
	add	w0, w0, 1
	and	w0, w0, 255
	strb	w0, [sp, 8]
	ldrb	w0, [sp, 9]
	add	w0, w0, 2
	and	w0, w0, 255
	strb	w0, [sp, 9]
	ldrb	w0, [sp, 10]
	add	w0, w0, 3
	and	w0, w0, 255
	strb	w0, [sp, 10]
	add	x0, sp, 24
	add	x1, sp, 8
	ldrh	w2, [x1]
	strh	w2, [x0]
	ldrb	w1, [x1, 2]
	strb	w1, [x0, 2]
	mov	x0, 0
	ldrh	w1, [sp, 24]
	bfi	x0, x1, 0, 16
	ldrb	w1, [sp, 26]
	bfi	x0, x1, 16, 8
	add	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE1:
	.size	musl_triplet, .-musl_triplet
	.align	2
	.global	musl_mixed
	.type	musl_mixed, %function
musl_mixed:
.LFB2:
	.cfi_startproc
	str	x19, [sp, -16]!
	.cfi_def_cfa_offset 16
	.cfi_offset 19, -16
	mov	x1, x8
	mov	x19, x0
	mov	w0, 7
	strb	w0, [x19]
	ldr	x0, [x19, 8]
	add	x0, x0, 17
	str	x0, [x19, 8]
	ldr	d0, [x19, 16]
	fadd	d0, d0, d0
	str	d0, [x19, 16]
	mov	x0, x1
	mov	x1, x19
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	ldr	x19, [sp], 16
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE2:
	.size	musl_mixed, .-musl_mixed
	.align	2
	.global	musl_packed
	.type	musl_packed, %function
musl_packed:
.LFB3:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	str	x0, [sp]
	ldrb	w0, [sp, 8]
	bfi	w0, w1, 0, 8
	strb	w0, [sp, 8]
	mov	w0, 9
	strb	w0, [sp]
	ldr	x0, [sp, 1]
	add	x0, x0, 19
	str	x0, [sp, 1]
	add	x0, sp, 16
	mov	x1, sp
	ldr	x2, [x1]
	str	x2, [x0]
	ldrb	w1, [x1, 8]
	strb	w1, [x0, 8]
	ldr	x2, [sp, 16]
	mov	x0, 0
	ldrb	w1, [sp, 24]
	bfi	x0, x1, 0, 8
	mov	x4, x2
	mov	x5, x0
	mov	x0, x4
	mov	x1, x5
	add	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE3:
	.size	musl_packed, .-musl_packed
	.align	2
	.global	musl_union
	.type	musl_union, %function
musl_union:
.LFB4:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x1, [sp, 8]
	mov	x0, 52719
	movk	x0, 0x89ab, lsl 16
	movk	x0, 0x4567, lsl 32
	movk	x0, 0x8123, lsl 48
	eor	x0, x1, x0
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE4:
	.size	musl_union, .-musl_union
	.align	2
	.global	musl_callback
	.type	musl_callback, %function
musl_callback:
.LFB5:
	.cfi_startproc
	stp	x29, x30, [sp, -48]!
	.cfi_def_cfa_offset 48
	.cfi_offset 29, -48
	.cfi_offset 30, -40
	mov	x29, sp
	str	x0, [sp, 40]
	fmov	s2, s0
	fmov	s0, s1
	fmov	x0, d2
	fmov	w2, s0
	bfi	x0, x2, 32, 32
	str	x0, [sp, 32]
	str	x1, [sp, 24]
	ldr	s0, [sp, 32]
	ldr	s1, [sp, 36]
	ldr	x2, [sp, 40]
	ldr	x1, [sp, 24]
	mov	x0, 5
	blr	x2
	fmov	s2, s0
	fmov	s0, s1
	fmov	x0, d2
	fmov	w1, s0
	bfi	x0, x1, 32, 32
	mov	x1, x0
	lsr	w3, w1, 0
	lsr	x0, x0, 32
	fmov	s1, w0
	ldr	x2, [sp, 40]
	ldr	x1, [sp, 24]
	mov	x0, 11
	fmov	s0, w3
	blr	x2
	fmov	s2, s0
	fmov	s0, s1
	fmov	x0, d2
	fmov	w1, s0
	bfi	x0, x1, 32, 32
	mov	x1, x0
	lsr	w1, w1, 0
	lsr	x0, x0, 32
	fmov	s0, w1
	fmov	s1, w0
	ldp	x29, x30, [sp], 48
	.cfi_restore 30
	.cfi_restore 29
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE5:
	.size	musl_callback, .-musl_callback
	.align	2
	.global	musl_stack
	.type	musl_stack, %function
musl_stack:
.LFB6:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	str	x0, [sp, 120]
	str	x1, [sp, 112]
	str	x2, [sp, 104]
	str	x3, [sp, 96]
	str	x4, [sp, 88]
	str	x5, [sp, 80]
	str	x6, [sp, 72]
	str	x7, [sp, 64]
	str	d0, [sp, 56]
	str	d1, [sp, 48]
	str	d2, [sp, 40]
	str	d3, [sp, 32]
	str	d4, [sp, 24]
	str	d5, [sp, 16]
	str	d6, [sp, 8]
	str	d7, [sp]
	ldr	x0, [sp, 112]
	lsl	x1, x0, 1
	ldr	x0, [sp, 120]
	add	x2, x1, x0
	ldr	x1, [sp, 104]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	add	x1, x2, x0
	ldr	x0, [sp, 96]
	lsl	x0, x0, 2
	add	x2, x1, x0
	ldr	x1, [sp, 88]
	mov	x0, x1
	lsl	x0, x0, 2
	add	x0, x0, x1
	add	x2, x2, x0
	ldr	x1, [sp, 80]
	mov	x0, x1
	lsl	x0, x0, 1
	add	x0, x0, x1
	lsl	x0, x0, 1
	add	x2, x2, x0
	ldr	x1, [sp, 72]
	mov	x0, x1
	lsl	x0, x0, 3
	sub	x0, x0, x1
	add	x1, x2, x0
	ldr	x0, [sp, 64]
	lsl	x0, x0, 3
	add	x0, x1, x0
	ldr	d0, [sp, 48]
	fadd	d1, d0, d0
	ldr	d0, [sp, 56]
	fadd	d1, d1, d0
	ldr	d2, [sp, 40]
	fmov	d0, 3.0e+0
	fmul	d0, d2, d0
	fadd	d1, d1, d0
	ldr	d2, [sp, 32]
	fmov	d0, 4.0e+0
	fmul	d0, d2, d0
	fadd	d1, d1, d0
	ldr	d2, [sp, 24]
	fmov	d0, 5.0e+0
	fmul	d0, d2, d0
	fadd	d1, d1, d0
	ldr	d2, [sp, 16]
	fmov	d0, 6.0e+0
	fmul	d0, d2, d0
	fadd	d1, d1, d0
	ldr	d2, [sp, 8]
	fmov	d0, 7.0e+0
	fmul	d0, d2, d0
	fadd	d1, d1, d0
	ldr	d2, [sp]
	fmov	d0, 8.0e+0
	fmul	d0, d2, d0
	fadd	d1, d1, d0
	ldr	d2, [sp, 128]
	fmov	d0, 9.0e+0
	fmul	d0, d2, d0
	fadd	d0, d1, d0
	fcvtzs	d0, d0
	fmov	x1, d0
	add	x0, x0, x1
	add	sp, sp, 128
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE6:
	.size	musl_stack, .-musl_stack
	.align	2
	.type	musl_variadic_copy, %function
musl_variadic_copy:
.LFB7:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, 80]
	.cfi_offset 29, -32
	.cfi_offset 30, -24
	add	x29, sp, 80
	str	x19, [sp, 96]
	.cfi_offset 19, -16
	mov	x19, x0
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 72]
	mov	x1, 0
	add	x0, sp, 40
	mov	x1, x19
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	ldr	w1, [sp, 64]
	ldr	x0, [sp, 40]
	cmp	w1, 0
	blt	.L16
	add	x1, x0, 11
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L17
.L16:
	add	w2, w1, 8
	str	w2, [sp, 64]
	ldr	w2, [sp, 64]
	cmp	w2, 0
	ble	.L18
	add	x1, x0, 11
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L17
.L18:
	ldr	x2, [sp, 48]
	sxtw	x0, w1
	add	x0, x2, x0
.L17:
	ldr	w0, [x0]
	str	w0, [sp, 12]
	ldr	w1, [sp, 68]
	ldr	x0, [sp, 40]
	cmp	w1, 0
	blt	.L20
	add	x1, x0, 15
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L21
.L20:
	add	w2, w1, 16
	str	w2, [sp, 68]
	ldr	w2, [sp, 68]
	cmp	w2, 0
	ble	.L22
	add	x1, x0, 15
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L21
.L22:
	ldr	x2, [sp, 56]
	sxtw	x0, w1
	add	x0, x2, x0
.L21:
	ldr	d0, [x0]
	str	d0, [sp, 16]
	ldr	w1, [sp, 64]
	ldr	x0, [sp, 40]
	cmp	w1, 0
	blt	.L24
	add	x1, x0, 15
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L25
.L24:
	add	w2, w1, 8
	str	w2, [sp, 64]
	ldr	w2, [sp, 64]
	cmp	w2, 0
	ble	.L26
	add	x1, x0, 15
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L25
.L26:
	ldr	x2, [sp, 48]
	sxtw	x0, w1
	add	x0, x2, x0
.L25:
	ldr	x0, [x0]
	str	x0, [sp, 24]
	ldr	w1, [sp, 64]
	ldr	x0, [sp, 40]
	cmp	w1, 0
	blt	.L28
	add	x1, x0, 15
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L29
.L28:
	add	w2, w1, 8
	str	w2, [sp, 64]
	ldr	w2, [sp, 64]
	cmp	w2, 0
	ble	.L30
	add	x1, x0, 15
	and	x1, x1, -8
	str	x1, [sp, 40]
	b	.L29
.L30:
	ldr	x2, [sp, 48]
	sxtw	x0, w1
	add	x0, x2, x0
.L29:
	ldr	x0, [x0]
	str	x0, [sp, 32]
	ldrsw	x0, [sp, 12]
	ldr	d0, [sp, 16]
	fcvtzs	d0, d0
	fmov	x1, d0
	add	x1, x0, x1
	ldr	x0, [sp, 24]
	add	x1, x1, x0
	ldr	x0, [sp, 32]
	ldr	x0, [x0]
	add	x0, x1, x0
	mov	x1, x0
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x3, [sp, 72]
	ldr	x2, [x0]
	subs	x3, x3, x2
	mov	x2, 0
	beq	.L33
	bl	__stack_chk_fail
.L33:
	mov	x0, x1
	ldr	x19, [sp, 96]
	ldp	x29, x30, [sp, 80]
	add	sp, sp, 112
	.cfi_restore 29
	.cfi_restore 30
	.cfi_restore 19
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE7:
	.size	musl_variadic_copy, .-musl_variadic_copy
	.align	2
	.global	musl_variadic
	.type	musl_variadic, %function
musl_variadic:
.LFB8:
	.cfi_startproc
	sub	sp, sp, #304
	.cfi_def_cfa_offset 304
	stp	x29, x30, [sp, 96]
	.cfi_offset 29, -208
	.cfi_offset 30, -200
	add	x29, sp, 96
	str	w0, [sp, 44]
	str	x1, [sp, 248]
	str	x2, [sp, 256]
	str	x3, [sp, 264]
	str	x4, [sp, 272]
	str	x5, [sp, 280]
	str	x6, [sp, 288]
	str	x7, [sp, 296]
	str	q0, [sp, 112]
	str	q1, [sp, 128]
	str	q2, [sp, 144]
	str	q3, [sp, 160]
	str	q4, [sp, 176]
	str	q5, [sp, 192]
	str	q6, [sp, 208]
	str	q7, [sp, 224]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 88]
	mov	x1, 0
	add	x0, sp, 304
	str	x0, [sp, 56]
	add	x0, sp, 304
	str	x0, [sp, 64]
	add	x0, sp, 240
	str	x0, [sp, 72]
	mov	w0, -56
	str	w0, [sp, 80]
	mov	w0, -128
	str	w0, [sp, 84]
	mov	x0, sp
	add	x1, sp, 56
	ldp	q0, q1, [x1]
	stp	q0, q1, [x0]
	mov	x0, sp
	bl	musl_variadic_copy
	str	x0, [sp, 48]
	ldrsw	x1, [sp, 44]
	ldr	x0, [sp, 48]
	add	x0, x1, x0
	mov	x1, x0
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x3, [sp, 88]
	ldr	x2, [x0]
	subs	x3, x3, x2
	mov	x2, 0
	beq	.L36
	bl	__stack_chk_fail
.L36:
	mov	x0, x1
	ldp	x29, x30, [sp, 96]
	add	sp, sp, 304
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE8:
	.size	musl_variadic, .-musl_variadic
	.align	2
	.global	musl_bits_write
	.type	musl_bits_write, %function
musl_bits_write:
.LFB9:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x1, [sp, 8]
	ldrh	w0, [x1]
	mov	w2, -9
	bfi	w0, w2, 0, 5
	strh	w0, [x1]
	ldr	x1, [sp, 8]
	ldrh	w0, [x1]
	mov	w2, 6
	bfi	w0, w2, 5, 3
	strh	w0, [x1]
	ldr	x0, [sp, 8]
	ldrh	w1, [x0]
	and	w1, w1, 255
	mov	w2, w1
	mov	w1, 32000
	orr	w1, w2, w1
	strh	w1, [x0]
	ldrb	w1, [x0, 2]
	orr	w1, w1, 1
	strb	w1, [x0, 2]
	ldr	x0, [sp, 8]
	mov	w1, 12
	strb	w1, [x0, 3]
	nop
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE9:
	.size	musl_bits_write, .-musl_bits_write
	.align	2
	.global	musl_bits_read
	.type	musl_bits_read, %function
musl_bits_read:
.LFB10:
	.cfi_startproc
	sub	sp, sp, #16
	.cfi_def_cfa_offset 16
	str	x0, [sp, 8]
	ldr	x0, [sp, 8]
	ldr	w0, [x0]
	sbfx	x0, x0, 0, 5
	sxtb	w0, w0
	mov	w1, w0
	ldr	x0, [sp, 8]
	ldr	w0, [x0]
	ubfx	x0, x0, 5, 3
	and	w0, w0, 255
	mov	w2, w0
	mov	w0, 100
	mul	w0, w2, w0
	add	w1, w1, w0
	ldr	x0, [sp, 8]
	ldr	w0, [x0]
	ubfx	x0, x0, 8, 9
	and	w0, w0, 65535
	mov	w2, w0
	mov	w0, 1000
	mul	w0, w2, w0
	add	w1, w1, w0
	ldr	x0, [sp, 8]
	ldrb	w0, [x0, 3]
	mov	w2, w0
	mov	w0, 16960
	movk	w0, 0xf, lsl 16
	mul	w0, w2, w0
	add	w0, w1, w0
	sxtw	x0, w0
	add	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE10:
	.size	musl_bits_read, .-musl_bits_read
	.align	2
	.global	musl_atomic_store
	.type	musl_atomic_store, %function
musl_atomic_store:
.LFB11:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, 48]
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	add	x29, sp, 48
	str	x0, [sp, 8]
	str	x1, [sp]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 40]
	mov	x1, 0
	ldr	x0, [sp, 8]
	str	x0, [sp, 32]
	ldr	x0, [sp]
	str	x0, [sp, 24]
	ldr	x1, [sp, 24]
	ldr	x0, [sp, 32]
	stlr	x1, [x0]
	nop
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 40]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	beq	.L41
	bl	__stack_chk_fail
.L41:
	ldp	x29, x30, [sp, 48]
	add	sp, sp, 64
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE11:
	.size	musl_atomic_store, .-musl_atomic_store
	.align	2
	.global	musl_atomic_load
	.type	musl_atomic_load, %function
musl_atomic_load:
.LFB12:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, 48]
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	add	x29, sp, 48
	str	x0, [sp, 8]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 40]
	mov	x1, 0
	ldr	x0, [sp, 8]
	str	x0, [sp, 32]
	ldr	x0, [sp, 32]
	ldar	x0, [x0]
	str	x0, [sp, 24]
	ldr	x0, [sp, 24]
	mov	x1, x0
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x3, [sp, 40]
	ldr	x2, [x0]
	subs	x3, x3, x2
	mov	x2, 0
	beq	.L44
	bl	__stack_chk_fail
.L44:
	mov	x0, x1
	ldp	x29, x30, [sp, 48]
	add	sp, sp, 64
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE12:
	.size	musl_atomic_load, .-musl_atomic_load
	.align	2
	.global	musl_dimensions
	.type	musl_dimensions, %function
musl_dimensions:
.LFB13:
	.cfi_startproc
	sub	sp, sp, #448
	.cfi_def_cfa_offset 448
	stp	x29, x30, [sp, 432]
	.cfi_offset 29, -16
	.cfi_offset 30, -8
	add	x29, sp, 432
	str	x0, [sp, 8]
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x1, [x0]
	str	x1, [sp, 424]
	mov	x1, 0
	adrp	x0, .LC0
	add	x1, x0, :lo12:.LC0
	add	x0, sp, 32
	mov	x3, x1
	mov	x1, 392
	mov	x2, x1
	mov	x1, x3
	bl	memcpy
	str	xzr, [sp, 24]
	b	.L46
.L47:
	ldr	x0, [sp, 24]
	lsl	x0, x0, 3
	ldr	x1, [sp, 8]
	add	x0, x1, x0
	ldr	x1, [sp, 24]
	lsl	x1, x1, 3
	add	x2, sp, 32
	ldr	x1, [x2, x1]
	str	x1, [x0]
	ldr	x0, [sp, 24]
	add	x0, x0, 1
	str	x0, [sp, 24]
.L46:
	ldr	x0, [sp, 24]
	cmp	x0, 48
	bls	.L47
	nop
	adrp	x0, :got:__stack_chk_guard
	ldr	x0, [x0, :got_lo12:__stack_chk_guard]
	ldr	x2, [sp, 424]
	ldr	x1, [x0]
	subs	x2, x2, x1
	mov	x1, 0
	beq	.L48
	bl	__stack_chk_fail
.L48:
	ldp	x29, x30, [sp, 432]
	add	sp, sp, 448
	.cfi_restore 29
	.cfi_restore 30
	.cfi_def_cfa_offset 0
	ret
	.cfi_endproc
.LFE13:
	.size	musl_dimensions, .-musl_dimensions
	.section	.rodata
	.align	3
.LC0:
	.xword	1
	.xword	1
	.xword	2
	.xword	2
	.xword	4
	.xword	4
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	4
	.xword	4
	.xword	4
	.xword	4
	.xword	4
	.xword	4
	.xword	8
	.xword	8
	.xword	16
	.xword	16
	.xword	32
	.xword	8
	.xword	8
	.xword	4
	.xword	3
	.xword	1
	.xword	32
	.xword	8
	.xword	9
	.xword	1
	.xword	4
	.xword	4
	.xword	8
	.xword	8
	.xword	8
	.xword	8
	.xword	4
	.xword	2
	.xword	8
	.xword	16
	.xword	24
	.xword	1
	.xword	3
	.xword	1
	.xword	1
	.xword	1
	.xword	1
	.text
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
