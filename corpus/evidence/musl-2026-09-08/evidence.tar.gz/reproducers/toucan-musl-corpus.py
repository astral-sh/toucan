import pathlib,subprocess,shutil,json,hashlib,sys
root=pathlib.Path('/home/dev-user/.codex/worktrees/toucan-musl-targets');cache=pathlib.Path('/home/dev-user/.cache/toucan/musl-validation');out=cache/'headers';out.mkdir(exist_ok=True);sys.path.insert(0,str(root/'scripts'));from verify_corpus import generate_probes,parse_output;from probe_record_layouts import record_probes
projects=json.loads(pathlib.Path('/home/dev-user/.cache/toucan/corpus/prepared.json').read_text())['projects'];toucan=pathlib.Path('/home/dev-user/.cache/toucan/musl-target/debug/toucan');analyzer=pathlib.Path('/home/dev-user/.cache/toucan/musl-compare-target/debug/toucan-binding-compare');rust=pathlib.Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc');lld=rust.parent.parent/'lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/ld.lld';rows=[]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def run(cmd,row,name):
 cmd=list(map(str,cmd));r=subprocess.run(cmd,cwd=row['directory'],capture_output=True,text=True,timeout=180);base=pathlib.Path(row['directory'])/name
 for stream in ['stdout','stderr']:base.with_suffix('.'+stream).write_text(getattr(r,stream))
 row['commands'].append({'command':cmd,'exit_code':r.returncode,'stdout_sha256':sha(base.with_suffix('.stdout')),'stderr_sha256':sha(base.with_suffix('.stderr'))})
 if r.returncode:raise RuntimeError(f'{name}: {r.stderr[-3000:]}')
 return r.stdout
try:
 for arch,pkg in [('x86_64','amd64'),('aarch64','arm64')]:
  target=arch+'-unknown-linux-musl';sysroot=cache/pkg;inc=sysroot/'usr/include'/f'{arch}-linux-musl';lib=sysroot/'usr/lib'/f'{arch}-linux-musl';runner=['qemu-aarch64-static'] if arch=='aarch64' else []
  for compiler in ['gcc','clang']:
   resource=pathlib.Path('/usr/lib/llvm-18/lib/clang/18/include') if compiler=='clang' else (pathlib.Path('/usr/lib/gcc/x86_64-linux-gnu/13/include') if arch=='x86_64' else cache/'gcc-arm64/usr/lib/gcc-cross/aarch64-linux-gnu/13/include')
   cc=['clang','--target='+target] if compiler=='clang' else (['gcc'] if arch=='x86_64' else ['/home/dev-user/.cache/toucan/aarch64-gcc-13/usr/bin/aarch64-linux-gnu-gcc-13'])
   gccdir=pathlib.Path('/usr/lib/gcc/x86_64-linux-gnu/13') if arch=='x86_64' else cache/'gcc-arm64/usr/lib/gcc-cross/aarch64-linux-gnu/13'
   for p in projects:
    name=p['name'];directory=out/f'{arch}-{compiler}-{name}';directory.mkdir(exist_ok=True);row={'target':target,'compiler':compiler,'name':name,'execution':'qemu-user' if runner else 'native','directory':str(directory),'commands':[]};rows.append(row)
    includes=['-I',inc,'-I',resource]
    for path in p['include_dirs']: includes.extend(['-I',path])
    patterns=[]
    for pattern in p['allowlist']:patterns.extend(['--allowlist',pattern])
    run([toucan,'bindgen',p['header'],'--target',target,'--compiler',compiler,'--sysroot',sysroot,*includes,*patterns,'--report','bindings-report.json','-o','bindings.rs'],row,'bindings')
    report=json.loads((directory/'bindings-report.json').read_text());row['dependencies']={path:sha(path) for path in report['dependencies'] if pathlib.Path(path).is_file()};row['bindings_sha256']=sha(directory/'bindings.rs')
    c,rs,coverage=generate_probes(name,pathlib.Path(p['header']),(directory/'bindings.rs').read_text(),report,run_ffi=False);row['coverage']=coverage
    inventory=json.loads(run([analyzer,directory/'bindings.rs',target],row,'inventory'));(directory/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n');c_layout,r_layout,records,offsets=record_probes(inventory,directory/'bindings.rs',pathlib.Path(p['header']),target,None);row.update(record_count=len(records),offset_count=offsets)
    for suffix,csrc,rsrc in [('constants',c,rs),('records',c_layout,r_layout)]:
     (directory/f'{suffix}.c').write_text(csrc);(directory/f'{suffix}.rs').write_text(rsrc)
     cflags=['-nostdinc','-isystem',inc,'-isystem',resource]
     for path in p['include_dirs']:cflags.extend(['-I',path])
     if arch=='aarch64' and compiler=='gcc':
      run([*cc,*cflags,'-std=c11','-O2','-S',directory/f'{suffix}.c','-o',directory/f'{suffix}.s'],row,f'compile-{suffix}');run(['clang','--target='+target,'-c',directory/f'{suffix}.s','-o',directory/f'{suffix}.o'],row,f'assemble-{suffix}')
     else:run([*cc,*cflags,'-std=c11','-O2','-c',directory/f'{suffix}.c','-o',directory/f'{suffix}.o'],row,f'compile-{suffix}')
     run(['clang','--target='+target,'-fuse-ld='+str(lld),'-static','-nostdlib',lib/'crt1.o',lib/'crti.o',directory/f'{suffix}.o',lib/'libc.a',gccdir/'libgcc.a',lib/'crtn.o','-o',directory/f'c-{suffix}'],row,f'link-{suffix}')
     run([rust,'--edition=2024','--target',target,'-C','linker='+str(cache/'abi'/f'{arch}-linker'),'-D','improper_ctypes',directory/f'{suffix}.rs','-o',directory/f'r-{suffix}'],row,f'rust-{suffix}')
     expected=parse_output(run([*runner,directory/f'c-{suffix}'],row,f'run-c-{suffix}'));actual=parse_output(run([*runner,directory/f'r-{suffix}'],row,f'run-r-{suffix}'))
     diff={k:(expected.get(k),actual.get(k)) for k in expected.keys()|actual.keys() if expected.get(k)!=actual.get(k)}
     row[suffix+'_comparisons']=len(expected);row[suffix+'_differences']=diff
     assert not diff,diff
    row['status']='passed';print(target,compiler,name,row['constants_comparisons'],row['record_count'],row['offset_count'],flush=True)
finally:(out/'evidence.json').write_text(json.dumps({'toucan_sha256':sha(toucan),'rows':rows},indent=2)+'\n')
