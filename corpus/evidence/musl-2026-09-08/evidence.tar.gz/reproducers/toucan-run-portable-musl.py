from pathlib import Path
import subprocess,shlex
root=Path('/home/dev-user/.codex/worktrees/toucan-musl-targets');cache=Path('/home/dev-user/.cache/toucan/musl-validation');tools=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains')
for arch,pkg in [('x86_64','amd64'),('aarch64','arm64')]:
 for compiler in ['gcc','clang']:
  target=arch+'-unknown-linux-musl';include=cache/pkg/'usr/include'/f'{arch}-linux-musl'
  if compiler=='gcc':
   command=['gcc'] if arch=='x86_64' else ['/home/dev-user/.cache/toucan/aarch64-gcc-13/usr/bin/aarch64-linux-gnu-gcc-13']
   resource=Path('/usr/lib/gcc/x86_64-linux-gnu/13/include') if arch=='x86_64' else cache/'gcc-arm64/usr/lib/gcc-cross/aarch64-linux-gnu/13/include'
  else:command=['clang','--target='+target];resource=Path('/usr/lib/llvm-18/lib/clang/18/include')
  command.extend(['-nostdinc','-isystem',str(include),'-isystem',str(resource)])
  args=['python',str(root/'scripts/verify_musl_abi.py'),'--target',target,'--compiler',compiler,'--sysroot',str(cache/pkg),'--include-dir',str(include),'--include-dir',str(resource),'--cc',shlex.join(command),'--rust-linker',str(cache/'abi'/f'{arch}-linker'),'--toucan','/home/dev-user/.cache/toucan/musl-target/debug/toucan','--output',str(cache/f'portable-{arch}-{compiler}')]
  for version in ['stable','1.64.0']:args.extend(['--rustc',str(tools/(version+'-x86_64-unknown-linux-gnu')/'bin/rustc')])
  if arch=='aarch64':args.extend(['--runner','qemu-aarch64-static'])
  if arch=='aarch64' and compiler=='gcc':args.extend(['--assembler','clang --target='+target])
  subprocess.run(args,cwd=root,check=True)
