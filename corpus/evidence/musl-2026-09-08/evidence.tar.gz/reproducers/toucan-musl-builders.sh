set -e
export CARGO_HOME=/home/dev-user/.cache/toucan/cargo
export CARGO_TARGET_DIR=/home/dev-user/.cache/toucan/musl-consumer-target
export RUSTUP_HOME=/home/dev-user/.cache/toucan/msrv-rustup
export RUSTUP_TOOLCHAIN=stable
export CARGO_PROFILE_RELEASE_LTO=false
export CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_LINKER=/home/dev-user/.cache/toucan/musl-validation/abi/x86_64-linker
export CARGO_TARGET_AARCH64_UNKNOWN_LINUX_MUSL_LINKER=/home/dev-user/.cache/toucan/musl-validation/abi/aarch64-linker
export CC_x86_64_unknown_linux_musl=/home/dev-user/.cache/toucan/musl-validation/wrappers/x86_64-musl-clang
export CC_aarch64_unknown_linux_musl=/home/dev-user/.cache/toucan/musl-validation/wrappers/aarch64-musl-clang
export BINDGEN_EXTRA_CLANG_ARGS_x86_64_unknown_linux_musl='--sysroot=/home/dev-user/.cache/toucan/musl-validation/amd64 -I/home/dev-user/.cache/toucan/musl-validation/amd64/usr/include/x86_64-linux-musl -I/usr/lib/llvm-18/lib/clang/18/include'
export BINDGEN_EXTRA_CLANG_ARGS_aarch64_unknown_linux_musl='--sysroot=/home/dev-user/.cache/toucan/musl-validation/arm64 -I/home/dev-user/.cache/toucan/musl-validation/arm64/usr/include/aarch64-linux-musl -I/usr/lib/llvm-18/lib/clang/18/include'
python scripts/verify_bindgen_builder.py --cache /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache --output /home/dev-user/.cache/toucan/musl-validation/builder-x64/evidence --target x86_64-unknown-linux-musl > /tmp/toucan-musl-builder-x64.log 2>&1
python scripts/verify_bindgen_builder.py --cache /home/dev-user/.cache/toucan/musl-validation/builder-arm/cache --output /home/dev-user/.cache/toucan/musl-validation/builder-arm/evidence --target aarch64-unknown-linux-musl --runner qemu-aarch64-static > /tmp/toucan-musl-builder-arm.log 2>&1
