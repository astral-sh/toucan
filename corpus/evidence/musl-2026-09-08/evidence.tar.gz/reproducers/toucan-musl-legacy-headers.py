from pathlib import Path
import subprocess,json,hashlib
cache=Path('/home/dev-user/.cache/toucan/musl-validation');evidence=json.loads((cache/'headers/evidence.json').read_text());rust=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains/1.64.0-x86_64-unknown-linux-gnu/bin/rustc');rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,directory,name,guard=False):
 r=subprocess.run(list(map(str,cmd)),cwd=directory,capture_output=True,text=True,timeout=90)
 for stream in ['stdout','stderr']:(directory/f'{name}.{stream}').write_text(getattr(r,stream))
 entry={'command':list(map(str,cmd)),'exit_code':r.returncode,'stdout_sha256':sha(directory/f'{name}.stdout'),'stderr_sha256':sha(directory/f'{name}.stderr')}
 if guard:
  assert r.returncode==1 and 'these C bindings were generated for a different target' in r.stderr and not any(x in r.stderr.lower() for x in ['internal compiler error','panicked','llvm error']),r.stderr
 else:assert r.returncode==0,r.stderr[-3000:]
 return r.stdout,entry
try:
 for row in evidence['rows']:
  directory=Path(row['directory']);target=row['target'];arch=target.split('-')[0];entry={'target':target,'compiler':row['compiler'],'project':row['name'],'commands':[]};rows.append(entry)
  cmd=[x.replace('bindings-report.json','bindings-164-report.json').replace('bindings.rs','bindings-164.rs') for x in row['commands'][0]['command']]+['--rust-target','1.64'];_,command=run(cmd,directory,'generate-164');entry['commands'].append(command)
  _,command=run([rust,'--edition=2021','--test','--target',target,'-C','linker='+str(cache/'abi'/f'{arch}-linker'),'-D','improper_ctypes',directory/'bindings-164.rs','-o',directory/'layout-164'],directory,'compile-164');entry['commands'].append(command)
  text,command=run((['qemu-aarch64-static'] if arch=='aarch64' else [])+[directory/'layout-164'],directory,'run-164');entry['commands'].append(command)
  _,command=run([rust,'--edition=2021','--crate-type=lib','--emit=metadata','--target',target.replace('musl','gnu'),directory/'bindings-164.rs','-o',directory/'wrong-environment.rmeta'],directory,'wrong-environment',True);entry['commands'].append(command)
  entry.update(status='passed',result=text,bindings_sha256=sha(directory/'bindings-164.rs'),binary_sha256=sha(directory/'layout-164'));print(target,row['compiler'],row['name'],'Rust1.64 layout and wrong-libc rejection passed',flush=True)
finally:(cache/'headers/legacy-evidence.json').write_text(json.dumps({'rustc':str(rust),'rustc_sha256':sha(rust),'rows':rows},indent=2)+'\n')
