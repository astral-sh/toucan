/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/zstd_sys-2c15a05aa07f1fbb.d: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-1fef307178d2e4a4/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-2c15a05aa07f1fbb.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-1fef307178d2e4a4/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-2c15a05aa07f1fbb.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-1fef307178d2e4a4/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-1fef307178d2e4a4/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-1fef307178d2e4a4/out
