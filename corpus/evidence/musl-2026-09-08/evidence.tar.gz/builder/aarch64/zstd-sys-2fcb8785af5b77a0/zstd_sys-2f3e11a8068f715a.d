/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/zstd_sys-2f3e11a8068f715a.d: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-2fcb8785af5b77a0/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-2f3e11a8068f715a.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-2fcb8785af5b77a0/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-2f3e11a8068f715a.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-2fcb8785af5b77a0/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-2fcb8785af5b77a0/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-2fcb8785af5b77a0/out
