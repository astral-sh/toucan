/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/zstd_sys-efa8867c8efdc88c.d: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-a844c73047af0dbb/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-efa8867c8efdc88c.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-a844c73047af0dbb/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-efa8867c8efdc88c.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-a844c73047af0dbb/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-a844c73047af0dbb/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-a844c73047af0dbb/out
