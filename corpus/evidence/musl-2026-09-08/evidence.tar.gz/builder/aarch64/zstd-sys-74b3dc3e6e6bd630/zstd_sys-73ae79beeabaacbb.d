/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/zstd_sys-73ae79beeabaacbb.d: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-74b3dc3e6e6bd630/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-73ae79beeabaacbb.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-74b3dc3e6e6bd630/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/deps/libzstd_sys-73ae79beeabaacbb.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-74b3dc3e6e6bd630/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-arm2/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-74b3dc3e6e6bd630/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/aarch64-unknown-linux-musl/release/build/zstd-sys-74b3dc3e6e6bd630/out
