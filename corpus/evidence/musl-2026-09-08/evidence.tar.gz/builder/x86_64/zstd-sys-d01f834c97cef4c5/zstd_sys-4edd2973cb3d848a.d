/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/zstd_sys-4edd2973cb3d848a.d: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-d01f834c97cef4c5/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-4edd2973cb3d848a.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-d01f834c97cef4c5/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-4edd2973cb3d848a.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-d01f834c97cef4c5/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-d01f834c97cef4c5/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-d01f834c97cef4c5/out
