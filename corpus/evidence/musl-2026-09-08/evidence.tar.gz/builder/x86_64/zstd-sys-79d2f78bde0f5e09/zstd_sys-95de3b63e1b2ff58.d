/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/zstd_sys-95de3b63e1b2ff58.d: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-79d2f78bde0f5e09/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-95de3b63e1b2ff58.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-79d2f78bde0f5e09/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-95de3b63e1b2ff58.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-79d2f78bde0f5e09/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-79d2f78bde0f5e09/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-79d2f78bde0f5e09/out
