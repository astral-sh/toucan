/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/zstd_sys-239542f5373de85f.d: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-6d88ecc50aece8bb/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-239542f5373de85f.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-6d88ecc50aece8bb/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-239542f5373de85f.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-6d88ecc50aece8bb/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-6d88ecc50aece8bb/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-6d88ecc50aece8bb/out
