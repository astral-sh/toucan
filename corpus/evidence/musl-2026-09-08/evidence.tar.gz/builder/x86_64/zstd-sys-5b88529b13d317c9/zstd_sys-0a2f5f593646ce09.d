/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/zstd_sys-0a2f5f593646ce09.d: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-5b88529b13d317c9/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-0a2f5f593646ce09.rlib: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-5b88529b13d317c9/out/bindings.rs

/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/deps/libzstd_sys-0a2f5f593646ce09.rmeta: /home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-5b88529b13d317c9/out/bindings.rs

/home/dev-user/.cache/toucan/musl-validation/builder-x64/cache/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-5b88529b13d317c9/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/musl-consumer-target/x86_64-unknown-linux-musl/release/build/zstd-sys-5b88529b13d317c9/out
