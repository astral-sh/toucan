from pathlib import Path
import subprocess,json
out=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-linkage')
attrs=['dllimport','dllimport(1)','dllimport(unknown)','dllexport','dllexport(1)','dllexport(unknown)','thread','thread(1)','thread(unknown)','selectany','selectany(1)','selectany(unknown)','dllimport dllexport','dllexport dllimport','dllimport thread','dllexport thread']
subjects=['ATTR int object;','ATTR extern int object;','ATTR int object=7;','ATTR const int object=7;','ATTR static int object;','ATTR typedef int T;','ATTR void f(void);','ATTR void f(void){}','ATTR inline void f(void){}','ATTR static void f(void);','ATTR static inline void f(void){}','ATTR typedef void (*F)(void);','ATTR void (*f)(void);','ATTR struct S{int x;};','struct ATTR S{int x;};','struct S{ATTR int x;};','void f(ATTR int x);','void f(void){ATTR int x;}','void f(void){ATTR static int x;}','void f(void){ATTR extern int x;}']
rows=[]
for attribute in attrs:
 for template in subjects:
  source=template.replace('ATTR','__declspec('+attribute+')');cmd=['clang','--target=x86_64-pc-windows-msvc','-std=gnu11','-fsyntax-only','-xc','-'];p=subprocess.run(cmd,input=source,text=True,capture_output=True)
  assert p.returncode>=0 and not any(x in p.stderr for x in ['PLEASE submit a bug','Stack dump:','frontend command failed due to signal']),(source,p.stderr)
  rows.append(dict(attribute=attribute,template=template,source=source,command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr))
(out/'storage-subjects.json').write_text(json.dumps(rows,indent=2)+'\n')
for attribute in attrs:print(attribute,''.join('Y' if r['status']==0 else 'N' for r in rows if r['attribute']==attribute))
print('subjects:',subjects)
