from pathlib import Path
import subprocess,json,hashlib
root=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/dll-semantics-output');root.mkdir(exist_ok=True)
toolchains=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains')
cli=Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/toucan')
lld=toolchains/'stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/lld-link'
rows=[]
def run(cmd,accepted=True):
 cmd=list(map(str,cmd));p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=60);rows.append(dict(command=cmd,status=p.returncode,stdout=p.stdout,stderr=p.stderr));assert (p.returncode==0)==accepted,(cmd,p.stderr);return p
(root/'api.h').write_text('__declspec(dllimport) int value; __declspec(dllimport) inline int function(void){return value;}\n')
base=[cli,'bindgen','api.h','--target','x86_64-pc-windows-msvc','--rust-target','1.64']
rejected=run(base,False);assert 'scoped DLL linkage configuration' in rejected.stderr
p=run(base+['--allowlist','function','-o','bindings.rs']);assert 'pub fn function' in (root/'bindings.rs').read_text()
(root/'dll.c').write_text('__declspec(dllexport) int value=19; __declspec(dllexport) int function(void){return value;}\n')
run(['clang','--target=x86_64-pc-windows-msvc','-O2','-fno-stack-protector','-c','dll.c','-o','dll.obj'])
run([lld,'/dll','/noentry','/nodefaultlib','/out:probe.dll','/implib:probe.lib','dll.obj'])
(root/'consumer.c').write_text('__declspec(dllimport) int function(void); int entry(void){return function();}\n')
run(['clang','--target=x86_64-pc-windows-msvc','-O2','-fno-stack-protector','-c','consumer.c','-o','consumer.obj'])
run([lld,'/entry:entry','/subsystem:console','/nodefaultlib','/out:c.exe','consumer.obj','probe.lib'])
(root/'consumer.rs').write_text('#![no_std]\ninclude!("bindings.rs");\n#[no_mangle]pub unsafe extern "C" fn entry()->i32{function()}\n')
for version in ['1.64.0','stable']:
 rustc=toolchains/(version+'-x86_64-unknown-linux-gnu/bin/rustc');run([rustc,'--version'])
 for opt in [0,3]:
  dest=root/(version+'-O'+str(opt));dest.mkdir(exist_ok=True)
  run([rustc,'--edition=2021','--crate-type=lib','--target=x86_64-pc-windows-msvc','--emit=llvm-ir,obj','-C','opt-level='+str(opt),'consumer.rs','--out-dir',dest])
  run([lld,'/entry:entry','/subsystem:console','/nodefaultlib','/out:'+str(dest/'consumer.exe'),dest/'consumer.o','probe.lib'])
  imports=run(['llvm-readobj-18','--coff-imports',dest/'consumer.exe']);assert 'Symbol: function ' in imports.stdout
out={'native_execution':False,'target':'x86_64-pc-windows-msvc','generated_inline_import_symbol':True,'unconfigured_imported_data_rejected':True,'commands':rows,'cli_sha256':hashlib.sha256(cli.read_bytes()).hexdigest(),'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and p.name!='evidence.json'}}
(root/'evidence.json').write_text(json.dumps(out,indent=2)+'\n')
print('Generated imported-inline function bindings link at O0/O3 with Rust1.64/current; PE imports verified, no native execution. Imported data diagnostic verified.')
