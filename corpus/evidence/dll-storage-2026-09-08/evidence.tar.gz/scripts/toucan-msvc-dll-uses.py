from pathlib import Path
import subprocess,json
out=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-linkage')
uses={
'none':'',
'read':'int read(void){return value;}',
'address':'int *address(void){return &value;}',
'static_address':'int *address=&value;',
'dead_if':'int read(void){if(0)return value;return 0;}',
'sizeof':'int size=sizeof(value);',
'alignof':'int size=__alignof__(value);',
'typeof':'typedef __typeof__(value) T;',
'generic_control':'int read(void){return _Generic(value,int:0);}',
'generic_selected':'int read(void){return _Generic(0,int:value);}',
'generic_unselected':'int read(void){return _Generic(0,int:0,default:value);}',
'choose_selected':'int read(void){return __builtin_choose_expr(1,value,0);}',
'choose_unselected':'int read(void){return __builtin_choose_expr(1,0,value);}',
'constant_p':'int read(void){return __builtin_constant_p(value);}',
'object_size':'int read(void){return __builtin_object_size(&value,0);}',
'logical_dead':'int read(void){return 0 && value;}',
'conditional_dead':'int read(void){return 1 ? 0 : value;}',
'vla_sizeof':'int read(void){return sizeof(int[(value,2)]);}',
'vla_typeof':'int read(void){__typeof__(int[(value,2)]) a;return sizeof(a);}',
'prototype_bound':'void function(int arg[(value,2)]);',
'local_shadow':'int read(void){int value=0;return value;}',
'local_static_shadow':'int read(void){static int value;return value;}',
'local_extern':'int read(void){extern int value;return value;}',
}
rows=[]
for name,use in uses.items():
 for attribute in ['dllimport','dllexport']:
  source=f'extern int value;\n{use}\n__declspec({attribute}) extern int value;\n'
  command=['clang','--target=x86_64-pc-windows-msvc','-std=gnu11','-fsyntax-only','-xc','-']
  p=subprocess.run(command,input=source,text=True,capture_output=True,timeout=15)
  assert p.returncode>=0 and 'PLEASE submit' not in p.stderr
  rows.append(dict(name=name,attribute=attribute,source=source,command=command,status=p.returncode,stdout=p.stdout,stderr=p.stderr))
(out/'uses-before-attributes.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 if r['attribute']=='dllimport': print(r['name'],r['status'],r['stderr'].splitlines()[:1])
