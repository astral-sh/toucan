from pathlib import Path
import subprocess,json
root=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-linkage');out=root/'bindgen';out.mkdir(exist_ok=True)
bindgen='/home/dev-user/.cache/toucan/tools/bin/bindgen'
rustc='/home/dev-user/.cache/toucan/msrv-rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc'
lld='/home/dev-user/.cache/toucan/msrv-rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/lld-link'
attribute='#[link(name="probe",kind="dylib")]'
headers={'data_first':'__declspec(dllimport) extern int value;\n__declspec(dllimport) int function(void);\n','function_first':'__declspec(dllimport) int function(void);\n__declspec(dllimport) extern int value;\n','typedef_first':'typedef int Number;\n__declspec(dllimport) extern Number value;\n__declspec(dllimport) Number function(void);\n'}
rows=[]
for header,source in headers.items():
 (out/f'{header}.h').write_text(source)
 for mode in ['default','link_lib','empty_block','raw_line','merged_raw_line','scoped_link']:
  name=f'{header}_{mode}';options=['--raw-line',attribute] if mode in ['raw_line','merged_raw_line'] else []
  if mode=='merged_raw_line':options+=['--merge-extern-blocks']
  command=[bindgen,str(out/f'{header}.h'),'--no-doc-comments','--no-layout-tests','--formatter','none','--use-core','--rust-target','1.64',*options,'--','-x','c','-std=c11','--target=x86_64-pc-windows-msvc']
  p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,p.stderr
  generated=p.stdout
  if mode=='scoped_link':generated=generated.replace('extern "C"',attribute+'\nextern "C"')
  (out/f'{name}_bindings.rs').write_text(generated)
  prefix=attribute+'\nextern "C"{}\n' if mode=='empty_block' else ''
  (out/f'{name}.rs').write_text(f'#![no_std]\n#![allow(non_camel_case_types)]\n{prefix}include!("{name}_bindings.rs");\n#[no_mangle]pub unsafe extern "C" fn entry()->i32{{value+function()}}\n')
  compile=[rustc,'--edition=2021','--crate-type=lib','--target=x86_64-pc-windows-msvc','--emit=llvm-ir,obj','-C','opt-level=2',f'{name}.rs']
  if mode=='link_lib':compile+=['-l','dylib=probe']
  c=subprocess.run(compile,cwd=out,capture_output=True,text=True)
  link=[lld,'/entry:entry','/subsystem:console','/nodefaultlib',f'/out:{name}.exe',f'{name}.o',str(root/'probe.lib')]
  l=subprocess.run(link,cwd=out,capture_output=True,text=True) if c.returncode==0 else None
  row={'header':header,'mode':mode,'generate':{'command':command,'status':p.returncode,'stdout':p.stdout,'stderr':p.stderr},'compile':{'command':compile,'status':c.returncode,'stdout':c.stdout,'stderr':c.stderr},'link':None if l is None else {'command':link,'status':l.returncode,'stdout':l.stdout,'stderr':l.stderr}}
  rows.append(row);print(header,mode,'compile',c.returncode,'link',None if l is None else l.returncode)
(root/'bindgen-evidence.json').write_text(json.dumps({'bindgen_version':'0.72.1','native_execution':False,'rows':rows},indent=2)+'\n')
