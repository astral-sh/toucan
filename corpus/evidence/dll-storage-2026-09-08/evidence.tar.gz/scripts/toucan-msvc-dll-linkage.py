import subprocess,json,hashlib
from pathlib import Path
root=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-linkage');root.mkdir(exist_ok=True)
rustc=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc')
lld=Path('/home/dev-user/.cache/toucan/msrv-rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld/lld-link')
rows=[]
def run(cmd,accepted=True):
 p=subprocess.run(list(map(str,cmd)),cwd=root,capture_output=True,text=True);rows.append(dict(command=list(map(str,cmd)),status=p.returncode,stdout=p.stdout,stderr=p.stderr));assert (p.returncode==0)==accepted,(cmd,p.stderr);return p
(root/'dll.c').write_text('__declspec(dllexport) int value=19; __declspec(dllexport) int function(void){return 23;}\n')
run(['clang','--target=x86_64-pc-windows-msvc','-O2','-fno-stack-protector','-c','dll.c','-o','dll.obj'])
run([lld,'/dll','/noentry','/nodefaultlib','/out:probe.dll','/implib:probe.lib','dll.obj'])
(root/'consumer.c').write_text('__declspec(dllimport) extern int value; __declspec(dllimport) int function(void); int entry(void){return value+function();}\n')
run(['clang','--target=x86_64-pc-windows-msvc','-O2','-fno-stack-protector','-c','consumer.c','-o','consumer-c.obj'])
run([lld,'/entry:entry','/subsystem:console','/nodefaultlib','/out:consumer-c.exe','consumer-c.obj','probe.lib'])
for kind,attr in [('plain',''),('dylib','#[link(name="probe",kind="dylib")]')]:
 (root/f'{kind}.rs').write_text(f'#![no_std]\n{attr}\nextern "C" {{static value:i32; fn function()->i32;}}\n#[no_mangle]pub unsafe extern "C" fn entry()->i32{{value+function()}}\n')
 run([rustc,'--edition=2021','--crate-type=lib','--target=x86_64-pc-windows-msvc','--emit=llvm-ir,obj','-C','opt-level=2',f'{kind}.rs'])
 run([lld,'/entry:entry','/subsystem:console','/nodefaultlib',f'/out:consumer-{kind}.exe',f'{kind}.o','probe.lib'],accepted=kind=='dylib')
run(['llvm-readobj-18','--coff-imports','consumer-dylib.exe'])
(root/'evidence.json').write_text(json.dumps(dict(native_execution=False,target='x86_64-pc-windows-msvc',commands=rows),indent=2)+'\n')
for row in rows:
 if row['status']!=0:print(row['stderr'])
print('C dllimport and named Rust dylib link; plain generated-style Rust imported-data consumer fails as expected. PE binaries were not executed.')
