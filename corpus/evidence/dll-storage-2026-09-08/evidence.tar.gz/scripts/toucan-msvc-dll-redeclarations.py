from pathlib import Path
import subprocess,json
out=Path('/home/dev-user/.cache/toucan/windows-arm64-probes/msvc-linkage');out.mkdir(exist_ok=True)
cases={
'import_then_extern':'__declspec(dllimport) int value; extern int value; int read(void){return value;}',
'extern_then_import':'extern int value; __declspec(dllimport) int value; int read(void){return value;}',
'import_then_tentative':'__declspec(dllimport) int value; int value; int read(void){return value;}',
'tentative_then_import':'int value; __declspec(dllimport) int value; int read(void){return value;}',
'import_then_definition':'__declspec(dllimport) int value; int value=3; int read(void){return value;}',
'definition_then_import':'int value=3; __declspec(dllimport) int value; int read(void){return value;}',
'import_export':'__declspec(dllimport) int value; __declspec(dllexport) int value; int read(void){return value;}',
'export_import':'__declspec(dllexport) int value; __declspec(dllimport) int value; int read(void){return value;}',
'import_static_redecl':'__declspec(dllimport) int value; static int value; int read(void){return value;}',
'block_extern_import':'int read(void){__declspec(dllimport) extern int value; return value;}',
'block_import':'int read(void){__declspec(dllimport) int value; return value;}',
'block_import_then_file_extern':'int read(void){__declspec(dllimport) extern int value; return value;} extern int value;',
'block_import_then_file_definition':'int read(void){__declspec(dllimport) extern int value; return value;} int value=3;',
'function_import_definition':'__declspec(dllimport) int function(void); int function(void){return 3;}',
'function_definition_import':'int function(void){return 3;} __declspec(dllimport) int function(void);',
'function_import_inline':'__declspec(dllimport) int function(void); inline int function(void){return 3;}',
'function_inline_import':'inline int function(void){return 3;} __declspec(dllimport) int function(void);',
'function_import_export':'__declspec(dllimport) int function(void); __declspec(dllexport) int function(void);',
'imported_data_static_address':'__declspec(dllimport) int value; int *address=&value;',
'imported_data_array_static_address':'__declspec(dllimport) int value[4]; int *address=&value[2];',
'imported_data_runtime_address':'__declspec(dllimport) int value; int *address(void){return &value;}',
'imported_function_static_address':'__declspec(dllimport) int function(void); int (*address)(void)=function;',
'imported_function_runtime_address':'__declspec(dllimport) int function(void); int (*address(void))(void){return function;}',
'imported_tls':'__declspec(dllimport) _Thread_local int value;',
'exported_tls':'__declspec(dllexport) _Thread_local int value;',
}
rows=[]
for name,source in cases.items():
 for target in ['x86_64-pc-windows-msvc','aarch64-pc-windows-msvc']:
  command=['clang','--target='+target,'-std=c11','-S','-emit-llvm','-O0','-x','c','-','-o','-']
  p=subprocess.run(command,input=source+'\n',capture_output=True,text=True,timeout=15)
  rows.append(dict(name=name,target=target,source=source,command=command,status=p.returncode,stdout=p.stdout,stderr=p.stderr))
(out/'redeclarations.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 if r['target'].startswith('x86_64'):
  lines=[l for l in r['stdout'].splitlines() if l.startswith('@') or l.startswith('declare') or l.startswith('define')]
  print(r['name'],r['status'],lines, r['stderr'].splitlines()[:2])
