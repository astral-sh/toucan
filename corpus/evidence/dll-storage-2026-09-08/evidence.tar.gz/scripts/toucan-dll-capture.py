from pathlib import Path
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
repo=Path('/home/dev-user/.codex/worktrees/toucan-msvc-dll-semantics')
cache=Path('/home/dev-user/.cache/toucan/windows-arm64-probes')
out=repo/'corpus/evidence/dll-storage-2026-09-08';out.mkdir(parents=True,exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
files=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
source={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{p:sha((repo/p).read_bytes()) for p in sorted(set(files)) if not p.startswith('corpus/evidence/')}}
write(out/'source.json',source)
archive={}
for folder,label in [('msvc-linkage','prior-linkage-and-native-probes'),('dll-semantics-output','generated-output')]:
 for p in (cache/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.c','.h','.rs','.ll','.txt'}:
   archive[label+'/'+str(p.relative_to(cache/folder))]=p.read_bytes()
for f in ['crates/toucan/tests/dll_storage.rs','crates/toucan_semantic/tests/thread_local.rs','fuzz/fuzz_targets/checked_invariants.rs']:
 archive['regression/'+Path(f).name]=(repo/f).read_bytes()
for name in ['dll-capture','dll-generated-output','dll-existing-outputs','msvc-dll-linkage','msvc-bindgen-dll','msvc-storage-probes','msvc-dll-redeclarations','msvc-dll-uses']:
 p=Path('/tmp/toucan-'+name+'.py')
 if p.exists():archive['scripts/'+p.name]=p.read_bytes()
archive['scripts/toucan-dll-replay.rs']=Path('/tmp/toucan-dll-replay.rs').read_bytes()
archive['existing-output/evidence.json']=Path('/home/dev-user/.cache/toucan/dll-existing-outputs/evidence.json').read_bytes()
logs={}
for name in ['workspace-final','native-final','tls-native-final','clippy','fuzz-clippy','replay','replay-build','existing-outputs','generated-output','fmt','diff']:
 p=Path('/tmp/toucan-dll-'+name+'.log');data=p.read_bytes();archive['logs/'+p.name]=data;logs[name]={'sha256':sha(data),'text':data.decode()}
counts=[tuple(map(int,m)) for m in re.findall(r'(\d+) passed; (\d+) failed; (\d+) ignored',logs['workspace-final']['text'])]
assert tuple(map(sum,zip(*counts)))==(759,0,199)
assert 'test result: ok. 7 passed; 0 failed; 0 ignored' in logs['native-final']['text']
assert 'test result: ok. 5 passed; 0 failed; 0 ignored' in logs['native-final']['text']
assert 'test result: ok. 4 passed; 0 failed; 0 ignored' in logs['tls-native-final']['text']
for name in ['clippy','fuzz-clippy']:assert 'error:' not in logs[name]['text'] and 'Finished' in logs[name]['text']
assert 'accepted=2605 rejected=1267' in logs['replay']['text']
assert 'FAILED' not in logs['workspace-final']['text']
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w') as tar:
 for name,data in sorted(archive.items()):
  info=tarfile.TarInfo(name);info.mode=0o644;info.size=len(data);tar.addfile(info,io.BytesIO(data))
(out/'evidence.tar.gz').write_bytes(gzip.compress(stream.getvalue(),mtime=0))
write(out/'files.json',{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(archive.items())})
write(out/'checks.json',logs)
primary={name:{'url':'https://raw.githubusercontent.com/llvm/llvm-project/llvmorg-18.1.3/clang/lib/Sema/'+name,'sha256':sha((cache/'msvc-linkage'/name).read_bytes())} for name in ['SemaDecl.cpp','SemaDeclAttr.cpp']}
write(out/'summary.json',{'base':source['base'],'source_manifest_sha256':sha((out/'source.json').read_bytes()),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes()),'primary':primary,'workspace':{'passed':759,'failed':0,'ignored':199},'focused':{'passed':12,'dll_source_acceptance_cases':252,'dll_sequence_and_final_ast_cases':363,'all_mode_external_linkage_llvm_cases':24,'tls_native_tests':4},'checked_seed_matrix':{'pairs':3872,'accepted':2605,'matching_rejections':1267,'retained_graph_invariants':'passed'},'compact_nodes':{'Declaration_bytes':136,'Entity_bytes':88},'bindings':{'existing_project_and_musl_outputs':8,'existing_outputs_byte_identical':True,'generated_imported_inline_function':{'rust_versions':['1.64.0','1.98.1'],'rust_optimizations':[0,3],'target':'x86_64-pc-windows-msvc','COFF_import_library_link':'passed','PE_import_table':'verified'},'unconfigured_imported_data':'explicit diagnostic','prior_bindgen_comparison':{'version':'0.72.1','header_orders':['data-first','function-first','typedef-first'],'configurations':6,'rust_versions':['1.64.0','1.98.1'],'correct_scoped_foreign_block_linkage':'required for data'}},'notes':['DLL metadata describes declarations, not the storage of instructions previously emitted by Clang.','The Microsoft later-static extension is accepted in non-pedantic mode and rejected by -pedantic-errors.','Workspace test count was taken before the test-only strict/non-pedantic TLS oracle correction; the corrected entire TLS suite passed with native compilers afterward.'],'remaining':['caller-supplied scoped DLL library linkage configuration','inline ownership finalization integration with the parallel inline metadata layer','native Windows SDK/consumer/runtime gates','Microsoft thread/selectany and other unimplemented attributes'],'not_claimed':['native Windows execution','Windows ARM physical target','performance measurement','sanitizer campaign']})
frozen=cache/'dll-storage-frozen-binaries';frozen.mkdir(exist_ok=True)
paths=[Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/toucan'),Path('/tmp/toucan-dll-replay')]
for stem in ['dll_storage-','declspec-','thread_local-']:
 candidates=[p for p in Path('/home/dev-user/.cache/toucan/msvc-declarations-target/debug/deps').glob(stem+'*') if p.is_file() and p.suffix=='']
 paths.append(max(candidates,key=lambda p:p.stat().st_mtime))
manifest={}
for p in paths:
 dest=frozen/p.name;shutil.copy2(p,dest);manifest[p.name]={'source':str(p),'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes())}
write(frozen/'manifest.json',manifest)
print(json.dumps({'source_manifest':sha((out/'source.json').read_bytes()),'archive':sha((out/'evidence.tar.gz').read_bytes()),'files':len(archive),'archive_bytes':(out/'evidence.tar.gz').stat().st_size,'binaries':manifest},indent=2))
