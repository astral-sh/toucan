__declspec(dllimport) int value; __declspec(dllimport) inline int function(void){return value;}
