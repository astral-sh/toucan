__declspec(dllexport) int value=19; __declspec(dllexport) int function(void){return value;}
