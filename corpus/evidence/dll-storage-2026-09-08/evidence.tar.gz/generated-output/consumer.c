__declspec(dllimport) int function(void); int entry(void){return function();}
