; ModuleID = 'consumer.26609c7a-cgu.0'
source_filename = "consumer.26609c7a-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

; Function Attrs: uwtable
define i32 @entry() unnamed_addr #0 {
start:
  %0 = tail call i32 @function()
  ret i32 %0
}

; Function Attrs: uwtable
declare i32 @function() unnamed_addr #0

attributes #0 = { uwtable "target-cpu"="x86-64" }

!llvm.module.flags = !{!0}

!0 = !{i32 7, !"PIC Level", i32 2}
