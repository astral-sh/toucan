#![no_std]
include!("bindings.rs");
#[no_mangle]pub unsafe extern "C" fn entry()->i32{function()}
