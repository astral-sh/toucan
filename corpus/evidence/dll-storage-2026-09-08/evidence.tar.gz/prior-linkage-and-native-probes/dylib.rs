#![no_std]
#[link(name="probe",kind="dylib")]
extern "C" {static value:i32; fn function()->i32;}
#[no_mangle]pub unsafe extern "C" fn entry()->i32{value+function()}
