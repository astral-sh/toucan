#![no_std]
#![allow(non_camel_case_types)]
include!("function_first_merged_raw_line_bindings.rs");
#[no_mangle]pub unsafe extern "C" fn entry()->i32{value+function()}
