#![no_std]
#![allow(non_camel_case_types)]
include!("function_first_link_lib_bindings.rs");
#[no_mangle]pub unsafe extern "C" fn entry()->i32{value+function()}
