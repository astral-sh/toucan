; ModuleID = 'typedef_first_scoped_link.3a5683aa99e81015-cgu.0'
source_filename = "typedef_first_scoped_link.3a5683aa99e81015-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@value = external dllimport local_unnamed_addr global i32

; Function Attrs: nounwind uwtable
define noundef i32 @entry() unnamed_addr #0 {
start:
  %_1 = load i32, ptr @value, align 4, !noundef !3
  %_3 = tail call noundef i32 @function() #1
  %_0 = add i32 %_3, %_1
  ret i32 %_0
}

; Function Attrs: nounwind uwtable
declare dllimport noundef i32 @function() unnamed_addr #0

attributes #0 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"uwtable", i32 2}
!2 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
!3 = !{}
