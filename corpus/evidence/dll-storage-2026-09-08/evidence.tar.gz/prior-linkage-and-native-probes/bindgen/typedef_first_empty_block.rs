#![no_std]
#![allow(non_camel_case_types)]
#[link(name="probe",kind="dylib")]
extern "C"{}
include!("typedef_first_empty_block_bindings.rs");
#[no_mangle]pub unsafe extern "C" fn entry()->i32{value+function()}
