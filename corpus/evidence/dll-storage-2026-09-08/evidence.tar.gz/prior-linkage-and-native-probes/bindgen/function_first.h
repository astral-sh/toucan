__declspec(dllimport) int function(void);
__declspec(dllimport) extern int value;
