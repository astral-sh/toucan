__declspec(dllimport) extern int value;
__declspec(dllimport) int function(void);
