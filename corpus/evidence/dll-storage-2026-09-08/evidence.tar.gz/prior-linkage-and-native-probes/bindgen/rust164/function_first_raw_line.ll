; ModuleID = 'function_first_raw_line.120af65d-cgu.0'
source_filename = "function_first_raw_line.120af65d-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@value = external local_unnamed_addr global i32

; Function Attrs: uwtable
define i32 @entry() unnamed_addr #0 {
start:
  %_1 = load i32, i32* @value, align 4
  %_3 = tail call i32 @function()
  %0 = add i32 %_3, %_1
  ret i32 %0
}

; Function Attrs: uwtable
declare dllimport i32 @function() unnamed_addr #0

attributes #0 = { uwtable "target-cpu"="x86-64" }

!llvm.module.flags = !{!0}

!0 = !{i32 7, !"PIC Level", i32 2}
