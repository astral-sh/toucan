#![no_std]
#![allow(non_camel_case_types)]
include!("typedef_first_default_bindings.rs");
#[no_mangle]pub unsafe extern "C" fn entry()->i32{value+function()}
