typedef int Number;
__declspec(dllimport) extern Number value;
__declspec(dllimport) Number function(void);
