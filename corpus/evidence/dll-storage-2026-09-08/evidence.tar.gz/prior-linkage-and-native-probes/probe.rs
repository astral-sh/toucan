extern "C" { static value:i32; fn function()->i32; }
#[no_mangle] pub unsafe extern "C" fn read_value()->i32 {value+function()}
