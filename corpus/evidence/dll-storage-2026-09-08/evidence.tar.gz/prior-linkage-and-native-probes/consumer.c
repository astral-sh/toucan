__declspec(dllimport) extern int value; __declspec(dllimport) int function(void); int entry(void){return value+function();}
