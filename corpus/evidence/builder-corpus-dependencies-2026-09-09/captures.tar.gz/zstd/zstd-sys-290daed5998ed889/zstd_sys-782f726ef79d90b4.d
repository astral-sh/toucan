/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/zstd_sys-782f726ef79d90b4.d: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-290daed5998ed889/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-782f726ef79d90b4.rlib: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-290daed5998ed889/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-782f726ef79d90b4.rmeta: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-290daed5998ed889/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-290daed5998ed889/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-290daed5998ed889/out
