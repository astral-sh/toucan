/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/zstd_sys-f56f9c37a8fd3640.d: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-bee1a908572e68ec/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-f56f9c37a8fd3640.rlib: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-bee1a908572e68ec/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-f56f9c37a8fd3640.rmeta: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-bee1a908572e68ec/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-bee1a908572e68ec/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-bee1a908572e68ec/out
