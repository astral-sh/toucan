/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/zstd_sys-582da15179b0d3a1.d: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-d871cdfe0894c51c/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-582da15179b0d3a1.rlib: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-d871cdfe0894c51c/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-582da15179b0d3a1.rmeta: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-d871cdfe0894c51c/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-d871cdfe0894c51c/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-d871cdfe0894c51c/out
