/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/zstd_sys-6af8b6df355c82af.d: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-cce01488c0495dc9/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-6af8b6df355c82af.rlib: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-cce01488c0495dc9/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/deps/libzstd_sys-6af8b6df355c82af.rmeta: /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs /home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-cce01488c0495dc9/out/bindings.rs

/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/zstd-sys/src/lib.rs:
/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-cce01488c0495dc9/out/bindings.rs:

# env-dep:OUT_DIR=/home/dev-user/.cache/toucan/builder-macros-zstd-2026-09-09/consumer/target/x86_64-unknown-linux-gnu/release/build/zstd-sys-cce01488c0495dc9/out
