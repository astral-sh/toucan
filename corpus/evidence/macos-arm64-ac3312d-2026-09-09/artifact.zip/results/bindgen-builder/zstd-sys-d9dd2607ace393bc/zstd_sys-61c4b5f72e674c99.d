/Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/deps/zstd_sys-61c4b5f72e674c99.d: /Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/zstd-sys/src/lib.rs /Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/build/zstd-sys-d9dd2607ace393bc/out/bindings.rs

/Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/deps/libzstd_sys-61c4b5f72e674c99.rlib: /Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/zstd-sys/src/lib.rs /Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/build/zstd-sys-d9dd2607ace393bc/out/bindings.rs

/Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/deps/libzstd_sys-61c4b5f72e674c99.rmeta: /Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/zstd-sys/src/lib.rs /Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/build/zstd-sys-d9dd2607ace393bc/out/bindings.rs

/Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/zstd-sys/src/lib.rs:
/Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/build/zstd-sys-d9dd2607ace393bc/out/bindings.rs:

# env-dep:OUT_DIR=/Users/runner/work/toucan/toucan/corpus/cache/bindgen-builder/consumer/target/aarch64-apple-darwin/release/build/zstd-sys-d9dd2607ace393bc/out
