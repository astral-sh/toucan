#include "/Users/runner/work/toucan/toucan/corpus/cache/sources/zlib-1.3.1/zlib.h"
#include <stddef.h>
#include <stdio.h>
int main(void) {
printf("size.gzFile_s=%zu\n", sizeof(struct gzFile_s));
printf("align.gzFile_s=%zu\n", _Alignof(struct gzFile_s));
printf("offset.gzFile_s.have=%zu\n", offsetof(struct gzFile_s, have));
printf("offset.gzFile_s.next=%zu\n", offsetof(struct gzFile_s, next));
printf("offset.gzFile_s.pos=%zu\n", offsetof(struct gzFile_s, pos));
printf("size.gz_header_s=%zu\n", sizeof(gz_header));
printf("align.gz_header_s=%zu\n", _Alignof(gz_header));
printf("offset.gz_header_s.text=%zu\n", offsetof(gz_header, text));
printf("offset.gz_header_s.time=%zu\n", offsetof(gz_header, time));
printf("offset.gz_header_s.xflags=%zu\n", offsetof(gz_header, xflags));
printf("offset.gz_header_s.os=%zu\n", offsetof(gz_header, os));
printf("offset.gz_header_s.extra=%zu\n", offsetof(gz_header, extra));
printf("offset.gz_header_s.extra_len=%zu\n", offsetof(gz_header, extra_len));
printf("offset.gz_header_s.extra_max=%zu\n", offsetof(gz_header, extra_max));
printf("offset.gz_header_s.name=%zu\n", offsetof(gz_header, name));
printf("offset.gz_header_s.name_max=%zu\n", offsetof(gz_header, name_max));
printf("offset.gz_header_s.comment=%zu\n", offsetof(gz_header, comment));
printf("offset.gz_header_s.comm_max=%zu\n", offsetof(gz_header, comm_max));
printf("offset.gz_header_s.hcrc=%zu\n", offsetof(gz_header, hcrc));
printf("offset.gz_header_s.done=%zu\n", offsetof(gz_header, done));
printf("size.z_stream_s=%zu\n", sizeof(z_stream));
printf("align.z_stream_s=%zu\n", _Alignof(z_stream));
printf("offset.z_stream_s.next_in=%zu\n", offsetof(z_stream, next_in));
printf("offset.z_stream_s.avail_in=%zu\n", offsetof(z_stream, avail_in));
printf("offset.z_stream_s.total_in=%zu\n", offsetof(z_stream, total_in));
printf("offset.z_stream_s.next_out=%zu\n", offsetof(z_stream, next_out));
printf("offset.z_stream_s.avail_out=%zu\n", offsetof(z_stream, avail_out));
printf("offset.z_stream_s.total_out=%zu\n", offsetof(z_stream, total_out));
printf("offset.z_stream_s.msg=%zu\n", offsetof(z_stream, msg));
printf("offset.z_stream_s.state=%zu\n", offsetof(z_stream, state));
printf("offset.z_stream_s.zalloc=%zu\n", offsetof(z_stream, zalloc));
printf("offset.z_stream_s.zfree=%zu\n", offsetof(z_stream, zfree));
printf("offset.z_stream_s.opaque=%zu\n", offsetof(z_stream, opaque));
printf("offset.z_stream_s.data_type=%zu\n", offsetof(z_stream, data_type));
printf("offset.z_stream_s.adler=%zu\n", offsetof(z_stream, adler));
printf("offset.z_stream_s.reserved=%zu\n", offsetof(z_stream, reserved));
return 0; }
