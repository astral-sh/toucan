#![allow(dead_code, non_camel_case_types, non_upper_case_globals, non_snake_case)]
mod b { include!("/Users/runner/work/toucan/toucan/corpus/results/equivalence/zlib/bindings.rs"); }
fn main() {
println!("size.gzFile_s={}", core::mem::size_of::<b::gzFile_s>());
println!("align.gzFile_s={}", core::mem::align_of::<b::gzFile_s>());
println!("offset.gzFile_s.have={}", core::mem::offset_of!(b::gzFile_s, r#have));
println!("offset.gzFile_s.next={}", core::mem::offset_of!(b::gzFile_s, r#next));
println!("offset.gzFile_s.pos={}", core::mem::offset_of!(b::gzFile_s, r#pos));
println!("size.gz_header_s={}", core::mem::size_of::<b::gz_header_s>());
println!("align.gz_header_s={}", core::mem::align_of::<b::gz_header_s>());
println!("offset.gz_header_s.text={}", core::mem::offset_of!(b::gz_header_s, r#text));
println!("offset.gz_header_s.time={}", core::mem::offset_of!(b::gz_header_s, r#time));
println!("offset.gz_header_s.xflags={}", core::mem::offset_of!(b::gz_header_s, r#xflags));
println!("offset.gz_header_s.os={}", core::mem::offset_of!(b::gz_header_s, r#os));
println!("offset.gz_header_s.extra={}", core::mem::offset_of!(b::gz_header_s, r#extra));
println!("offset.gz_header_s.extra_len={}", core::mem::offset_of!(b::gz_header_s, r#extra_len));
println!("offset.gz_header_s.extra_max={}", core::mem::offset_of!(b::gz_header_s, r#extra_max));
println!("offset.gz_header_s.name={}", core::mem::offset_of!(b::gz_header_s, r#name));
println!("offset.gz_header_s.name_max={}", core::mem::offset_of!(b::gz_header_s, r#name_max));
println!("offset.gz_header_s.comment={}", core::mem::offset_of!(b::gz_header_s, r#comment));
println!("offset.gz_header_s.comm_max={}", core::mem::offset_of!(b::gz_header_s, r#comm_max));
println!("offset.gz_header_s.hcrc={}", core::mem::offset_of!(b::gz_header_s, r#hcrc));
println!("offset.gz_header_s.done={}", core::mem::offset_of!(b::gz_header_s, r#done));
println!("size.z_stream_s={}", core::mem::size_of::<b::z_stream_s>());
println!("align.z_stream_s={}", core::mem::align_of::<b::z_stream_s>());
println!("offset.z_stream_s.next_in={}", core::mem::offset_of!(b::z_stream_s, r#next_in));
println!("offset.z_stream_s.avail_in={}", core::mem::offset_of!(b::z_stream_s, r#avail_in));
println!("offset.z_stream_s.total_in={}", core::mem::offset_of!(b::z_stream_s, r#total_in));
println!("offset.z_stream_s.next_out={}", core::mem::offset_of!(b::z_stream_s, r#next_out));
println!("offset.z_stream_s.avail_out={}", core::mem::offset_of!(b::z_stream_s, r#avail_out));
println!("offset.z_stream_s.total_out={}", core::mem::offset_of!(b::z_stream_s, r#total_out));
println!("offset.z_stream_s.msg={}", core::mem::offset_of!(b::z_stream_s, r#msg));
println!("offset.z_stream_s.state={}", core::mem::offset_of!(b::z_stream_s, r#state));
println!("offset.z_stream_s.zalloc={}", core::mem::offset_of!(b::z_stream_s, r#zalloc));
println!("offset.z_stream_s.zfree={}", core::mem::offset_of!(b::z_stream_s, r#zfree));
println!("offset.z_stream_s.opaque={}", core::mem::offset_of!(b::z_stream_s, r#opaque));
println!("offset.z_stream_s.data_type={}", core::mem::offset_of!(b::z_stream_s, r#data_type));
println!("offset.z_stream_s.adler={}", core::mem::offset_of!(b::z_stream_s, r#adler));
println!("offset.z_stream_s.reserved={}", core::mem::offset_of!(b::z_stream_s, r#reserved));
}
