#![allow(dead_code, non_camel_case_types, non_upper_case_globals, non_snake_case)]
mod b { include!("/Users/runner/work/toucan/toucan/corpus/results/equivalence/zstd/bindings.rs"); }
fn main() {
println!("size.ZSTD_bounds={}", core::mem::size_of::<b::__toucan_record_2>());
println!("align.ZSTD_bounds={}", core::mem::align_of::<b::__toucan_record_2>());
println!("offset.ZSTD_bounds.error={}", core::mem::offset_of!(b::__toucan_record_2, r#error));
println!("offset.ZSTD_bounds.lowerBound={}", core::mem::offset_of!(b::__toucan_record_2, r#lowerBound));
println!("offset.ZSTD_bounds.upperBound={}", core::mem::offset_of!(b::__toucan_record_2, r#upperBound));
println!("size.ZSTD_inBuffer_s={}", core::mem::size_of::<b::ZSTD_inBuffer_s>());
println!("align.ZSTD_inBuffer_s={}", core::mem::align_of::<b::ZSTD_inBuffer_s>());
println!("offset.ZSTD_inBuffer_s.src={}", core::mem::offset_of!(b::ZSTD_inBuffer_s, r#src));
println!("offset.ZSTD_inBuffer_s.size={}", core::mem::offset_of!(b::ZSTD_inBuffer_s, r#size));
println!("offset.ZSTD_inBuffer_s.pos={}", core::mem::offset_of!(b::ZSTD_inBuffer_s, r#pos));
println!("size.ZSTD_outBuffer_s={}", core::mem::size_of::<b::ZSTD_outBuffer_s>());
println!("align.ZSTD_outBuffer_s={}", core::mem::align_of::<b::ZSTD_outBuffer_s>());
println!("offset.ZSTD_outBuffer_s.dst={}", core::mem::offset_of!(b::ZSTD_outBuffer_s, r#dst));
println!("offset.ZSTD_outBuffer_s.size={}", core::mem::offset_of!(b::ZSTD_outBuffer_s, r#size));
println!("offset.ZSTD_outBuffer_s.pos={}", core::mem::offset_of!(b::ZSTD_outBuffer_s, r#pos));
}
