#include "/Users/runner/work/toucan/toucan/corpus/cache/sources/zstd-1.5.7/lib/zstd.h"
#include <stddef.h>
#include <stdio.h>
#include "/Users/runner/work/toucan/toucan/corpus/oracles/zstd.c"
int main(void) {
printf("size.ZSTD_bounds=%zu\n", sizeof(ZSTD_bounds));
printf("align.ZSTD_bounds=%zu\n", _Alignof(ZSTD_bounds));
printf("offset.ZSTD_bounds.error=%zu\n", offsetof(ZSTD_bounds, error));
printf("offset.ZSTD_bounds.lowerBound=%zu\n", offsetof(ZSTD_bounds, lowerBound));
printf("offset.ZSTD_bounds.upperBound=%zu\n", offsetof(ZSTD_bounds, upperBound));
printf("size.ZSTD_inBuffer_s=%zu\n", sizeof(ZSTD_inBuffer));
printf("align.ZSTD_inBuffer_s=%zu\n", _Alignof(ZSTD_inBuffer));
printf("offset.ZSTD_inBuffer_s.src=%zu\n", offsetof(ZSTD_inBuffer, src));
printf("offset.ZSTD_inBuffer_s.size=%zu\n", offsetof(ZSTD_inBuffer, size));
printf("offset.ZSTD_inBuffer_s.pos=%zu\n", offsetof(ZSTD_inBuffer, pos));
printf("size.ZSTD_outBuffer_s=%zu\n", sizeof(ZSTD_outBuffer));
printf("align.ZSTD_outBuffer_s=%zu\n", _Alignof(ZSTD_outBuffer));
printf("offset.ZSTD_outBuffer_s.dst=%zu\n", offsetof(ZSTD_outBuffer, dst));
printf("offset.ZSTD_outBuffer_s.size=%zu\n", offsetof(ZSTD_outBuffer, size));
printf("offset.ZSTD_outBuffer_s.pos=%zu\n", offsetof(ZSTD_outBuffer, pos));
return 0; }
