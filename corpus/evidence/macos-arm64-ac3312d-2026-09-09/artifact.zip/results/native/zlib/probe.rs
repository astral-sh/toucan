#![allow(dead_code, non_camel_case_types, non_upper_case_globals, non_snake_case)]
mod b { include!("bindings.rs"); }
fn main() {
println!("constant.ZLIB_VERNUM={}", b::ZLIB_VERNUM);
println!("constant_size.ZLIB_VERNUM={}", core::mem::size_of_val(&b::ZLIB_VERNUM));
println!("constant_signed.ZLIB_VERNUM=1");
println!("constant.ZLIB_VER_MAJOR={}", b::ZLIB_VER_MAJOR);
println!("constant_size.ZLIB_VER_MAJOR={}", core::mem::size_of_val(&b::ZLIB_VER_MAJOR));
println!("constant_signed.ZLIB_VER_MAJOR=1");
println!("constant.ZLIB_VER_MINOR={}", b::ZLIB_VER_MINOR);
println!("constant_size.ZLIB_VER_MINOR={}", core::mem::size_of_val(&b::ZLIB_VER_MINOR));
println!("constant_signed.ZLIB_VER_MINOR=1");
println!("constant.ZLIB_VER_REVISION={}", b::ZLIB_VER_REVISION);
println!("constant_size.ZLIB_VER_REVISION={}", core::mem::size_of_val(&b::ZLIB_VER_REVISION));
println!("constant_signed.ZLIB_VER_REVISION=1");
println!("constant.ZLIB_VER_SUBREVISION={}", b::ZLIB_VER_SUBREVISION);
println!("constant_size.ZLIB_VER_SUBREVISION={}", core::mem::size_of_val(&b::ZLIB_VER_SUBREVISION));
println!("constant_signed.ZLIB_VER_SUBREVISION=1");
println!("constant.Z_ASCII={}", b::Z_ASCII);
println!("constant_size.Z_ASCII={}", core::mem::size_of_val(&b::Z_ASCII));
println!("constant_signed.Z_ASCII=1");
println!("constant.Z_BEST_COMPRESSION={}", b::Z_BEST_COMPRESSION);
println!("constant_size.Z_BEST_COMPRESSION={}", core::mem::size_of_val(&b::Z_BEST_COMPRESSION));
println!("constant_signed.Z_BEST_COMPRESSION=1");
println!("constant.Z_BEST_SPEED={}", b::Z_BEST_SPEED);
println!("constant_size.Z_BEST_SPEED={}", core::mem::size_of_val(&b::Z_BEST_SPEED));
println!("constant_signed.Z_BEST_SPEED=1");
println!("constant.Z_BINARY={}", b::Z_BINARY);
println!("constant_size.Z_BINARY={}", core::mem::size_of_val(&b::Z_BINARY));
println!("constant_signed.Z_BINARY=1");
println!("constant.Z_BLOCK={}", b::Z_BLOCK);
println!("constant_size.Z_BLOCK={}", core::mem::size_of_val(&b::Z_BLOCK));
println!("constant_signed.Z_BLOCK=1");
println!("constant.Z_BUF_ERROR={}", b::Z_BUF_ERROR);
println!("constant_size.Z_BUF_ERROR={}", core::mem::size_of_val(&b::Z_BUF_ERROR));
println!("constant_signed.Z_BUF_ERROR=1");
println!("constant.Z_DATA_ERROR={}", b::Z_DATA_ERROR);
println!("constant_size.Z_DATA_ERROR={}", core::mem::size_of_val(&b::Z_DATA_ERROR));
println!("constant_signed.Z_DATA_ERROR=1");
println!("constant.Z_DEFAULT_COMPRESSION={}", b::Z_DEFAULT_COMPRESSION);
println!("constant_size.Z_DEFAULT_COMPRESSION={}", core::mem::size_of_val(&b::Z_DEFAULT_COMPRESSION));
println!("constant_signed.Z_DEFAULT_COMPRESSION=1");
println!("constant.Z_DEFAULT_STRATEGY={}", b::Z_DEFAULT_STRATEGY);
println!("constant_size.Z_DEFAULT_STRATEGY={}", core::mem::size_of_val(&b::Z_DEFAULT_STRATEGY));
println!("constant_signed.Z_DEFAULT_STRATEGY=1");
println!("constant.Z_DEFLATED={}", b::Z_DEFLATED);
println!("constant_size.Z_DEFLATED={}", core::mem::size_of_val(&b::Z_DEFLATED));
println!("constant_signed.Z_DEFLATED=1");
println!("constant.Z_ERRNO={}", b::Z_ERRNO);
println!("constant_size.Z_ERRNO={}", core::mem::size_of_val(&b::Z_ERRNO));
println!("constant_signed.Z_ERRNO=1");
println!("constant.Z_FILTERED={}", b::Z_FILTERED);
println!("constant_size.Z_FILTERED={}", core::mem::size_of_val(&b::Z_FILTERED));
println!("constant_signed.Z_FILTERED=1");
println!("constant.Z_FINISH={}", b::Z_FINISH);
println!("constant_size.Z_FINISH={}", core::mem::size_of_val(&b::Z_FINISH));
println!("constant_signed.Z_FINISH=1");
println!("constant.Z_FIXED={}", b::Z_FIXED);
println!("constant_size.Z_FIXED={}", core::mem::size_of_val(&b::Z_FIXED));
println!("constant_signed.Z_FIXED=1");
println!("constant.Z_FULL_FLUSH={}", b::Z_FULL_FLUSH);
println!("constant_size.Z_FULL_FLUSH={}", core::mem::size_of_val(&b::Z_FULL_FLUSH));
println!("constant_signed.Z_FULL_FLUSH=1");
println!("constant.Z_HUFFMAN_ONLY={}", b::Z_HUFFMAN_ONLY);
println!("constant_size.Z_HUFFMAN_ONLY={}", core::mem::size_of_val(&b::Z_HUFFMAN_ONLY));
println!("constant_signed.Z_HUFFMAN_ONLY=1");
println!("constant.Z_MEM_ERROR={}", b::Z_MEM_ERROR);
println!("constant_size.Z_MEM_ERROR={}", core::mem::size_of_val(&b::Z_MEM_ERROR));
println!("constant_signed.Z_MEM_ERROR=1");
println!("constant.Z_NEED_DICT={}", b::Z_NEED_DICT);
println!("constant_size.Z_NEED_DICT={}", core::mem::size_of_val(&b::Z_NEED_DICT));
println!("constant_signed.Z_NEED_DICT=1");
println!("constant.Z_NO_COMPRESSION={}", b::Z_NO_COMPRESSION);
println!("constant_size.Z_NO_COMPRESSION={}", core::mem::size_of_val(&b::Z_NO_COMPRESSION));
println!("constant_signed.Z_NO_COMPRESSION=1");
println!("constant.Z_NO_FLUSH={}", b::Z_NO_FLUSH);
println!("constant_size.Z_NO_FLUSH={}", core::mem::size_of_val(&b::Z_NO_FLUSH));
println!("constant_signed.Z_NO_FLUSH=1");
println!("constant.Z_NULL={}", b::Z_NULL);
println!("constant_size.Z_NULL={}", core::mem::size_of_val(&b::Z_NULL));
println!("constant_signed.Z_NULL=1");
println!("constant.Z_OK={}", b::Z_OK);
println!("constant_size.Z_OK={}", core::mem::size_of_val(&b::Z_OK));
println!("constant_signed.Z_OK=1");
println!("constant.Z_PARTIAL_FLUSH={}", b::Z_PARTIAL_FLUSH);
println!("constant_size.Z_PARTIAL_FLUSH={}", core::mem::size_of_val(&b::Z_PARTIAL_FLUSH));
println!("constant_signed.Z_PARTIAL_FLUSH=1");
println!("constant.Z_RLE={}", b::Z_RLE);
println!("constant_size.Z_RLE={}", core::mem::size_of_val(&b::Z_RLE));
println!("constant_signed.Z_RLE=1");
println!("constant.Z_STREAM_END={}", b::Z_STREAM_END);
println!("constant_size.Z_STREAM_END={}", core::mem::size_of_val(&b::Z_STREAM_END));
println!("constant_signed.Z_STREAM_END=1");
println!("constant.Z_STREAM_ERROR={}", b::Z_STREAM_ERROR);
println!("constant_size.Z_STREAM_ERROR={}", core::mem::size_of_val(&b::Z_STREAM_ERROR));
println!("constant_signed.Z_STREAM_ERROR=1");
println!("constant.Z_SYNC_FLUSH={}", b::Z_SYNC_FLUSH);
println!("constant_size.Z_SYNC_FLUSH={}", core::mem::size_of_val(&b::Z_SYNC_FLUSH));
println!("constant_signed.Z_SYNC_FLUSH=1");
println!("constant.Z_TEXT={}", b::Z_TEXT);
println!("constant_size.Z_TEXT={}", core::mem::size_of_val(&b::Z_TEXT));
println!("constant_signed.Z_TEXT=1");
println!("constant.Z_TREES={}", b::Z_TREES);
println!("constant_size.Z_TREES={}", core::mem::size_of_val(&b::Z_TREES));
println!("constant_signed.Z_TREES=1");
println!("constant.Z_UNKNOWN={}", b::Z_UNKNOWN);
println!("constant_size.Z_UNKNOWN={}", core::mem::size_of_val(&b::Z_UNKNOWN));
println!("constant_signed.Z_UNKNOWN=1");
println!("constant.Z_VERSION_ERROR={}", b::Z_VERSION_ERROR);
println!("constant_size.Z_VERSION_ERROR={}", core::mem::size_of_val(&b::Z_VERSION_ERROR));
println!("constant_signed.Z_VERSION_ERROR=1");
print!("string.ZLIB_VERSION="); for byte in b::ZLIB_VERSION { print!("{byte:02x}"); } println!();
println!("size.z_stream={}", core::mem::size_of::<b::z_stream>());
println!("align.z_stream={}", core::mem::align_of::<b::z_stream>());
println!("offset.z_stream.next_in={}", core::mem::offset_of!(b::z_stream, next_in));
println!("offset.z_stream.avail_in={}", core::mem::offset_of!(b::z_stream, avail_in));
println!("offset.z_stream.total_in={}", core::mem::offset_of!(b::z_stream, total_in));
println!("offset.z_stream.next_out={}", core::mem::offset_of!(b::z_stream, next_out));
println!("offset.z_stream.avail_out={}", core::mem::offset_of!(b::z_stream, avail_out));
println!("offset.z_stream.total_out={}", core::mem::offset_of!(b::z_stream, total_out));
println!("offset.z_stream.msg={}", core::mem::offset_of!(b::z_stream, msg));
println!("offset.z_stream.state={}", core::mem::offset_of!(b::z_stream, state));
println!("offset.z_stream.zalloc={}", core::mem::offset_of!(b::z_stream, zalloc));
println!("offset.z_stream.zfree={}", core::mem::offset_of!(b::z_stream, zfree));
println!("offset.z_stream.opaque={}", core::mem::offset_of!(b::z_stream, opaque));
println!("offset.z_stream.data_type={}", core::mem::offset_of!(b::z_stream, data_type));
println!("offset.z_stream.adler={}", core::mem::offset_of!(b::z_stream, adler));
println!("offset.z_stream.reserved={}", core::mem::offset_of!(b::z_stream, reserved));
println!("size.gz_header={}", core::mem::size_of::<b::gz_header>());
println!("align.gz_header={}", core::mem::align_of::<b::gz_header>());
println!("offset.gz_header.text={}", core::mem::offset_of!(b::gz_header, text));
println!("offset.gz_header.time={}", core::mem::offset_of!(b::gz_header, time));
println!("offset.gz_header.xflags={}", core::mem::offset_of!(b::gz_header, xflags));
println!("offset.gz_header.os={}", core::mem::offset_of!(b::gz_header, os));
println!("offset.gz_header.extra={}", core::mem::offset_of!(b::gz_header, extra));
println!("offset.gz_header.extra_len={}", core::mem::offset_of!(b::gz_header, extra_len));
println!("offset.gz_header.extra_max={}", core::mem::offset_of!(b::gz_header, extra_max));
println!("offset.gz_header.name={}", core::mem::offset_of!(b::gz_header, name));
println!("offset.gz_header.name_max={}", core::mem::offset_of!(b::gz_header, name_max));
println!("offset.gz_header.comment={}", core::mem::offset_of!(b::gz_header, comment));
println!("offset.gz_header.comm_max={}", core::mem::offset_of!(b::gz_header, comm_max));
println!("offset.gz_header.hcrc={}", core::mem::offset_of!(b::gz_header, hcrc));
println!("offset.gz_header.done={}", core::mem::offset_of!(b::gz_header, done));
ffi_test();
}
fn ffi_test() {
    let input = b"Toucan calls the upstream zlib library. Toucan calls the upstream zlib library.";
    unsafe {
        assert_eq!(
            std::ffi::CStr::from_ptr(b::zlibVersion()).to_bytes(),
            b"1.3.1"
        );
        let mut compressed = vec![0_u8; b::compressBound(input.len().try_into().unwrap()) as usize];
        let mut compressed_len: b::uLongf = compressed.len().try_into().unwrap();
        assert_eq!(
            b::compress2(
                compressed.as_mut_ptr(),
                &mut compressed_len,
                input.as_ptr(),
                input.len().try_into().unwrap(),
                b::Z_BEST_COMPRESSION
            ),
            b::Z_OK
        );
        let mut output = vec![0_u8; input.len()];
        let mut output_len: b::uLongf = output.len().try_into().unwrap();
        assert_eq!(
            b::uncompress(
                output.as_mut_ptr(),
                &mut output_len,
                compressed.as_ptr(),
                compressed_len
            ),
            b::Z_OK
        );
        assert_eq!(output_len as usize, input.len());
        assert_eq!(output, input);
        let initial = b::crc32(0, std::ptr::null(), 0);
        assert_ne!(
            b::crc32(initial, input.as_ptr(), input.len().try_into().unwrap()),
            initial
        );
    }
}

