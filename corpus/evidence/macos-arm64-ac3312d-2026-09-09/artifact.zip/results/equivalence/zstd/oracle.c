#include "/Users/runner/work/toucan/toucan/corpus/cache/sources/zstd-1.5.7/lib/zstd.h"
#include "/Users/runner/work/toucan/toucan/corpus/oracles/zstd.c"
_Static_assert(_Generic((ZSTD_MAGICNUMBER), unsigned int: 1, default: 0), "ZSTD_MAGICNUMBER has C unsigned int type");
_Static_assert(_Generic((ZSTD_MAGIC_DICTIONARY), unsigned int: 1, default: 0), "ZSTD_MAGIC_DICTIONARY has C unsigned int type");
_Static_assert(_Generic((ZSTD_MAGIC_SKIPPABLE_MASK), unsigned int: 1, default: 0), "ZSTD_MAGIC_SKIPPABLE_MASK has C unsigned int type");
