#include "/Users/runner/work/toucan/toucan/corpus/cache/sources/libgit2-1.9.1/include/git2.h"
#include "/Users/runner/work/toucan/toucan/corpus/oracles/libgit2.c"
_Static_assert(__builtin_types_compatible_p(git_attr_t, git_attr_value_t), "deprecated typedef identity");
_Static_assert(__builtin_types_compatible_p(git_revparse_mode_t, git_revspec_t), "deprecated typedef identity");
_Static_assert(_Generic((GIT_PATH_LIST_SEPARATOR), int: 1, default: 0), "GIT_PATH_LIST_SEPARATOR has C int type");
_Static_assert(_Generic((GIT_SUBMODULE_STATUS__INDEX_FLAGS), unsigned int: 1, default: 0), "GIT_SUBMODULE_STATUS__INDEX_FLAGS has C unsigned int type");
_Static_assert(_Generic((GIT_SUBMODULE_STATUS__IN_FLAGS), unsigned int: 1, default: 0), "GIT_SUBMODULE_STATUS__IN_FLAGS has C unsigned int type");
_Static_assert(_Generic((GIT_SUBMODULE_STATUS__WD_FLAGS), unsigned int: 1, default: 0), "GIT_SUBMODULE_STATUS__WD_FLAGS has C unsigned int type");
