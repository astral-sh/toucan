#include "/Users/runner/work/toucan/toucan/corpus/cache/build/sqlite/sqlite3.h"
#include "/Users/runner/work/toucan/toucan/corpus/oracles/sqlite.c"
