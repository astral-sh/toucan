int
main()
{
 if (0)
  return 1;
 if (0)
  return 1;
 if (0)
  return 1;
 if (0)
  return 1;
 if (0)
  return 1;
 if (0)
  return 1;
 if (0)
  return 1;
 return 0;
}
