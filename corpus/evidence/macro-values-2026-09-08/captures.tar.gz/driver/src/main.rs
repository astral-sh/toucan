#[path = "/home/dev-user/.cache/toucan/macro-compat-evaluator-source/crates/toucan_bindgen/src/macro_values.rs"]
mod macro_values;
use macro_values::{Context, Limits, Value, Character};
use serde_json::{json,Value as Json};
use std::path::Path;
use toucan::{CompilerProfile,Compiler,Target,LanguageMode};
use toucan_preprocessor::{Config,Preprocessor};
fn main() {
 let args=std::env::args().collect::<Vec<_>>();
 let rows:Json=serde_json::from_slice(&std::fs::read(&args[1]).unwrap()).unwrap();
 let rows=rows.get("rows").unwrap_or(&rows).as_array().unwrap();
 let mut results=Vec::new();
 for row in rows {
  let source=row["source"].as_str().unwrap_or("");
  let source=if source.is_empty(){std::fs::read_to_string(&args[2]).unwrap()}else{source.to_owned()};
  let target=row["target"].as_str().unwrap_or("x86_64-unknown-linux-gnu").parse::<Target>().unwrap();
  let mode=row["mode"].as_str().unwrap_or("gnu11").parse::<LanguageMode>().unwrap();
  let profile=CompilerProfile::new(target,Compiler::Clang).unwrap().with_language_mode(mode);
  let mut config=Config{record_macro_definitions:true,allow_filesystem:false,..Config::default()};
  config.defines.insert("COMMANDLINE".into(),"7".into());
  let parsed=Preprocessor::new(config.clone()).preprocess_str(Path::new("input.h"),&source);
  let (entries,preprocessor_error,final_functions)=match parsed {
   Ok(output)=>(output.macro_definitions().unwrap().iter().map(|entry|(entry.name().to_owned(),entry.definition().clone())).collect::<Vec<_>>(),None,output.macros.iter().filter(|(_,definition)|definition.parameters.is_some()).map(|(name,_)|name.clone()).collect::<std::collections::BTreeSet<_>>()),
   Err(error)=>{
    let mut entries=Vec::new();
    for line in source.lines().filter(|line|line.starts_with("#define ")) {
     let output=Preprocessor::new(config.clone()).preprocess_str(Path::new("isolated-definition.h"),line).unwrap();
     entries.extend(output.macro_definitions().unwrap().iter().map(|entry|(entry.name().to_owned(),entry.definition().clone())));
    }
    (entries,Some(error.to_string()),std::collections::BTreeSet::new())
   }
  };
  let mut context=Context::new(Limits::default(),profile);
  let callbacks=row["callback"].as_bool().or_else(||row["callbacks"].as_bool()).unwrap_or(false);
  let mut constants=Vec::new();let mut definitions=Vec::new();
  for (name,definition) in &entries {
   match context.define(name,definition,callbacks && final_functions.contains(name)) {
    Ok(Some(parsed))=> {
     let value=match parsed.value {Value::Integer(value)=>json!({"kind":"integer","value":value}),Value::Float(value)=>json!({"kind":"float","bits":value.to_bits()}),Value::Bytes(value)=>json!({"kind":"bytes","value":value}),Value::Character(Character::Unicode(value))=>json!({"kind":"unicode","value":u32::from(value)}),Value::Character(Character::Raw(value))=>json!({"kind":"raw","value":value}),Value::Invalid=>json!({"kind":"invalid"})};
     if parsed.first_definition { constants.push(json!({"name":name,"value":value})); }
     definitions.push(json!({"name":name,"first":parsed.first_definition,"value":value}));
    }
    Ok(None)=> definitions.push(json!({"name":name,"skipped_function":true})),
    Err(error)=> definitions.push(json!({"name":name,"error":format!("{:?}",error.kind),"offset":error.offset})),
   }
  }
  results.push(json!({"name":row["name"],"target":target.to_string(),"mode":mode.to_string(),"callbacks":callbacks,"preprocessor_error":preprocessor_error,"final_functions":final_functions,"constants":constants,"definitions":definitions}));
 }
 std::fs::write(&args[3],serde_json::to_vec_pretty(&results).unwrap()).unwrap();
}
