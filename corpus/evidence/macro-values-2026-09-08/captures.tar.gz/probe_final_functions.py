from pathlib import Path
import os,json,re,subprocess
root=Path(__file__).resolve().parent;binary='/home/dev-user/.cache/toucan/aws-lc-policy-target/release/toucan-bindgen-policy-reference';rows=[]
cases={
 'object_function':'#define A 7\n#undef A\n#define A(Known)\n',
 'object_function_undef':'#define A 7\n#undef A\n#define A(Known)\n#undef A\n',
 'object_function_object':'#define A 7\n#undef A\n#define A(Known)\n#undef A\n#define A 11\n',
 'function_object':'#define A(Known)\n#undef A\n#define A 11\n',
 'function_object_undef':'#define A(Known)\n#undef A\n#define A 11\n#undef A\n',
 'function_undef':'#define A(Known)\n#undef A\n',
 'function_active':'#define A(Known)\n',
 'function_invalid_undef':'#define A(Unknown)\n#undef A\n',
}
for name,body in cases.items():
 source='#define Known 9\n'+body+'#define Alias A\n';header=root/f'{name}.h';header.write_text(source)
 for callbacks in [False,True]:
  output=root/f'{name}-{callbacks}.rs';cmd=[binary,str(header),'-',str(output)]+(['unused_'] if callbacks else []);p=subprocess.run(cmd,text=True,capture_output=True,env=dict(os.environ,LIBCLANG_PATH='/usr/lib/llvm-18/lib'),timeout=30);assert p.returncode==0,p.stderr
  bindings=output.read_text();constants=re.findall(r'pub const ([^:]+):\s*([^=]+)=\s*([^;]+);',bindings);rows.append(dict(name=name,callbacks=callbacks,source=source,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,constants=constants,bindings=bindings));print(name,callbacks,constants,flush=True)
(root/'final-function-reference.json').write_text(json.dumps(rows,indent=2)+'\n')
