from pathlib import Path
import os,subprocess,json,hashlib,shutil
root=Path(__file__).resolve().parent;source=Path('/home/dev-user/.cache/toucan/macro-compat-evaluator-source')
files=['Cargo.lock','crates/toucan_bindgen/Cargo.toml','crates/toucan_bindgen/src/macro_values.rs','crates/toucan_bindgen/tests/macro_values.rs'];snapshot=lambda:{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in files};before=snapshot()
env=dict(os.environ,CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/home/dev-user/.cache/toucan/macro-compat-evaluator-target');rows=[]
for name,command,extra in [
 ('ordinary',['cargo','test','-p','toucan_bindgen','--test','macro_values'],{}),
 ('clippy',['cargo','clippy','-p','toucan_bindgen','--all-targets','--all-features','--','-D','warnings'],{}),
 ('asan',['cargo','test','-p','toucan_bindgen','--test','macro_values','--target','x86_64-unknown-linux-gnu'],{'RUSTUP_HOME':'/home/dev-user/.cache/toucan/rustup','RUSTUP_TOOLCHAIN':'nightly','RUSTFLAGS':'-Zsanitizer=address','ASAN_OPTIONS':'detect_leaks=0','CARGO_TARGET_DIR':'/home/dev-user/.cache/toucan/macro-compat-evaluator-asan-target'}),
]:
 p=subprocess.run(command,cwd=source,env=dict(env,**extra),text=True,capture_output=True);rows.append(dict(name=name,command=command,environment=extra,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));print(name,p.returncode,flush=True);assert p.returncode==0,p.stdout+p.stderr
binary=max(Path('/home/dev-user/.cache/toucan/macro-compat-evaluator-asan-target/x86_64-unknown-linux-gnu/debug/build').glob('toucan_bindgen/*/out/macro_values-*'),key=lambda p:p.stat().st_mtime);assert '__asan_init' in subprocess.check_output(['nm',str(binary)],text=True);shutil.copy2(binary,root/'asan-tests')
(root/'validation.json').write_text(json.dumps(dict(rows=rows,source_sha256=before,source_unchanged=before==snapshot(),asan_binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest()),indent=2)+'\n');assert before==snapshot()
