from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path(__file__).resolve().parent
text=(root/'TokenKinds.def').read_text()
names=set(re.findall(r'^(?:KEYWORD|[A-Z0-9_]*KEYWORD|TYPE_TRAIT_[12N]|UNARY_EXPR_OR_TYPE_TRAIT|CXX11_UNARY_EXPR_OR_TYPE_TRAIT)\((\w+)\s*[,)]',text,re.M))
names.update(re.findall(r'^ALIAS\("(\w+)"',text,re.M))
names.discard("defined") # Clang rejects this preprocessing operator as a macro name.
names=sorted(names)
source=''.join(f'#define {name} {index+1}\n#define TC_PROBE_{index} {name}\n' for index,name in enumerate(names))
header=root/'keywords.h';header.write_text(source)
binary='/home/dev-user/.cache/toucan/aws-lc-policy-target/release/toucan-bindgen-policy-reference';rows=[]
for target in ['x86_64-unknown-linux-gnu','x86_64-apple-darwin','x86_64-pc-windows-msvc']:
 for mode in ['c90','gnu90','c99','gnu99','c11','gnu11','c17','gnu17']:
  out=root/f'keywords-{target}-{mode}.rs';cmd=[binary,str(header),'-',str(out)];env=dict(os.environ,LIBCLANG_PATH='/usr/lib/llvm-18/lib',BINDGEN_EXTRA_CLANG_ARGS=f'--target={target} -std={mode}')
  p=subprocess.run(cmd,text=True,capture_output=True,env=env,timeout=30);assert p.returncode==0,(target,mode,p.stderr)
  bindings=out.read_text();emitted=set(re.findall(r'pub const (\w+)\s*:',bindings));keywords=[name for name in names if name not in emitted]
  keywords=[name for index,name in enumerate(names) if f'TC_PROBE_{index}' not in emitted]
  rows.append(dict(target=target,mode=mode,command=cmd,environment={k:env[k] for k in ['LIBCLANG_PATH','BINDGEN_EXTRA_CLANG_ARGS']},returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,keywords=keywords,bindings=bindings))
  print(target,mode,len(names),len(keywords),flush=True)
(root/'keyword-reference.json').write_text(json.dumps(dict(source_url='https://raw.githubusercontent.com/llvm/llvm-project/llvmorg-18.1.3/clang/include/clang/Basic/TokenKinds.def',token_kinds_sha256=hashlib.sha256((root/'TokenKinds.def').read_bytes()).hexdigest(),names=names,source=source,rows=rows),indent=2)+'\n')
