from pathlib import Path
import subprocess,json,hashlib,ast,re,struct,math
root=Path(__file__).resolve().parent;binary=root/'driver-target/debug/macro-value-probe';rows=[]
for kind,input in [('history',Path('/home/dev-user/.cache/toucan/macro-history-reference-probes/report.json')),('additional',root/'additional-reference.json'),('final-functions',root/'final-function-reference.json'),('literal-tokens',root/'literal-token-reference.json'),('keywords',root/'keyword-reference.json')]:
 output=root/f'{kind}-candidate.json';cmd=[str(binary),str(input),str(root/'keywords.h'),str(output)];p=subprocess.run(cmd,text=True,capture_output=True);assert p.returncode==0,p.stderr
 reference=json.loads(input.read_text());reference=reference.get('rows',reference) if isinstance(reference,dict) else reference
 actual=json.loads(output.read_text());assert len(actual)==len(reference)
 for old,new in zip(reference,actual):
  if kind=='keywords':
   absent=[name for index,name in enumerate(json.loads(input.read_text())['names']) if f'TC_PROBE_{index}' not in {x['name'] for x in new['constants']}]
   assert absent==old['keywords'],(old['target'],old['mode'],set(absent)^set(old['keywords']));same=True
  elif old.get('exit_code',old.get('returncode'))!=0: same=None
  else:
   expected={}
   macro_names=set(re.findall(r"^#define (\w+)",old["source"],re.M))
   for name,typ,raw in old['constants']:
    name=name.strip();typ=typ.strip();raw=raw.strip()
    if name not in macro_names:continue
    if typ=='f64':
     f={'f64::INFINITY':math.inf,'f64::NEG_INFINITY':-math.inf,'f64::NAN':math.nan}.get(re.sub(r'\s','',raw))
     if f is None:f=float(re.sub(r'\s','',raw))
     expected[name]={'kind':'float','bits':struct.unpack('Q',struct.pack('d',f))[0]}
    elif raw.startswith('b"'):
     b=ast.literal_eval(raw);assert b[-1]==0;expected[name]={'kind':'bytes','value':list(b[:-1])}
    elif raw.endswith('u8'):expected[name]={'kind':'unicode','value':int(raw[:-2])}
    else:expected[name]={'kind':'integer','value':int(re.sub(r'\s','',raw))}
   observed={item['name']:item['value'] for item in new['constants'] if item['value']['kind']!='invalid'}
   for name,value in expected.items():
    if value['kind']=='float' and math.isnan(struct.unpack('d',struct.pack('Q',value['bits']))[0]):
     if name in observed and observed[name]['kind']=='float' and math.isnan(struct.unpack('d',struct.pack('Q',observed[name]['bits']))[0]):observed[name]=value
   same=observed==expected
   if not same:print('MISMATCH',kind,old['name'],old.get('callback',old.get('callbacks')),expected,observed,flush=True)
   assert same
  rows.append({'kind':kind,'name':old.get('name'),'target':old.get('target'),'mode':old.get('mode'),'callback':old.get('callback',old.get('callbacks')),'equivalent_values':same,'reference_failed':same is None,'preprocessor_error':new['preprocessor_error']})
 print(kind,'rows',len(actual),'pass',flush=True)
(root/'comparison.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
