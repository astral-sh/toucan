from pathlib import Path
import hashlib,json,os,re,subprocess
out=Path('/home/dev-user/.cache/toucan/macro-history-reference-probes');out.mkdir(exist_ok=False)
binary=Path('/home/dev-user/.cache/toucan/aws-lc-policy-target/release/toucan-bindgen-policy-reference')
cases={
'redefine_after_undef':'#define VALUE 10\n#undef VALUE\n#define VALUE 11\n',
'undef':'#define VALUE 20\n#undef VALUE\n',
'alias_then_redefine':'#define A 1\n#define B A\n#undef A\n#define A 2\n#define C B\n#define D A\n',
'alias_after_undef':'#define A 1\n#undef A\n#define B A\n',
'forward_alias':'#define A B\n#define B 2\n#define C A\n',
'forward_retried':'#define A B\n#define B 2\n#undef A\n#define A B\n#define C A\n',
'invalid_then_number':'#define VALUE missing\n#undef VALUE\n#define VALUE 11\n',
'empty_then_number':'#define VALUE\n#undef VALUE\n#define VALUE 11\n',
'function_then_number':'#define VALUE(x) (x)\n#undef VALUE\n#define VALUE 11\n',
'number_then_function':'#define VALUE 10\n#undef VALUE\n#define VALUE(x) (x)\n#define OTHER VALUE\n',
'function_use':'#define INC(x) ((x)+1)\n#define VALUE INC(2)\n',
'function_zero':'#define VALUE() 10\n#undef VALUE\n#define VALUE 11\n',
'enum_alias':'enum E{VALUE=4};\n#define OTHER VALUE\n#define VALUE VALUE\n',
'cast':'#define VALUE ((unsigned) -1)\n#define OTHER VALUE\n',
'sizeof':'#define VALUE sizeof(int)\n#define OTHER VALUE\n',
'string_alias':'#define A "hello"\n#define B A\n#undef A\n#define A "bye"\n#define C B\n#define D A\n',
'concatenate':'#define A "hello"\n#define B A " world"\n',
'float_alias':'#define A 1.5f\n#define B A\n#undef A\n#define A 2.5f\n#define C B\n',
'redefinition_warning':'#define VALUE 10\n#define VALUE 11\n#define OTHER VALUE\n',
'predefines':'#define A __GNUC__\n#define B __SIZEOF_POINTER__\n#define C __LINE__\n#define D __FILE__\n',
'commandline':'#define A COMMANDLINE\n#undef COMMANDLINE\n#define COMMANDLINE 3\n#define B COMMANDLINE\n',
'short_circuit':'#define A (0 && unknown)\n#define B (1 || unknown)\n#define C (1 ? 3 : unknown)\n',
'self_update':'#define A 1\n#undef A\n#define A (A+1)\n#define B A\n',
'prior_failed_duplicate':'#define A missing\n#undef A\n#define A 9\n#define B A\n',
}
report={'reference_version':'0.72.1','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'rows':[]}
for name,source in cases.items():
 path=out/(name+'.h');path.write_text(source)
 for callback in [False,True]:
  result=out/(name+('-callback' if callback else '')+'.rs')
  cmd=[str(binary),str(path),'-',str(result)]+(['unused_prefix_'] if callback else [])
  env=dict(os.environ,LIBCLANG_PATH='/usr/lib/llvm-18/lib',BINDGEN_EXTRA_CLANG_ARGS='-DCOMMANDLINE=7')
  r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=30)
  output=result.read_text() if result.exists() else ''
  row={'name':name,'callback':callback,'source':source,'command':cmd,'environment':{'LIBCLANG_PATH':env['LIBCLANG_PATH'],'BINDGEN_EXTRA_CLANG_ARGS':env['BINDGEN_EXTRA_CLANG_ARGS']},'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'bindings':output,'constants':re.findall(r'pub const ([^:]+):\s*([^=]+)=\s*([^;]+);',output)}
  report['rows'].append(row);assert r.returncode==0,row
  if not callback:print(name,row['constants'],flush=True)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
