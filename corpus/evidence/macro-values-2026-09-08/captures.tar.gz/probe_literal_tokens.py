from pathlib import Path
import os,json,re,subprocess
root=Path(__file__).resolve().parent;binary='/home/dev-user/.cache/toucan/aws-lc-policy-target/release/toucan-bindgen-policy-reference';source=''.join(f'#define {name} {value}\n' for name,value in [('NARROW_S','"a"'),('WIDE_S','L"a"'),('UTF8_S','u8"a"'),('UTF16_S','u"a"'),('UTF32_S','U"a"'),('NARROW_C',"'a'"),('WIDE_C',"L'a'"),('UTF8_C',"u8'a'"),('UTF16_C',"u'a'"),('UTF32_C',"U'a'")]);header=root/'literal-tokens.h';header.write_text(source);rows=[]
for mode in ['c90','gnu90','c99','gnu99','c11','gnu11','c17','gnu17']:
 output=root/f'literal-tokens-{mode}.rs';cmd=[binary,str(header),'-',str(output)];env=dict(os.environ,LIBCLANG_PATH='/usr/lib/llvm-18/lib',BINDGEN_EXTRA_CLANG_ARGS=f'-std={mode}');p=subprocess.run(cmd,text=True,capture_output=True,env=env,timeout=30);assert p.returncode==0,p.stderr
 bindings=output.read_text();constants=re.findall(r'pub const ([^:]+):\s*([^=]+)=\s*([^;]+);',bindings);rows.append(dict(name='literal-tokens',mode=mode,source=source,command=cmd,environment={'LIBCLANG_PATH':env['LIBCLANG_PATH'],'BINDGEN_EXTRA_CLANG_ARGS':env['BINDGEN_EXTRA_CLANG_ARGS']},returncode=p.returncode,stdout=p.stdout,stderr=p.stderr,constants=constants,bindings=bindings));print(mode,constants,flush=True)
(root/'literal-token-reference.json').write_text(json.dumps(rows,indent=2)+'\n')
